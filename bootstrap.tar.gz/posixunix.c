/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:16
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: posixunix.scm -optimize-level 2 -include-path . -include-path . -explicit-use -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set_9(v) \
        (C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)))

#define C_tm_get_08(v) \
        (C_set_block_item(v, 0, C_fix(C_tm.tm_sec)), \
        C_set_block_item(v, 1, C_fix(C_tm.tm_min)), \
        C_set_block_item(v, 2, C_fix(C_tm.tm_hour)), \
        C_set_block_item(v, 3, C_fix(C_tm.tm_mday)), \
        C_set_block_item(v, 4, C_fix(C_tm.tm_mon)), \
        C_set_block_item(v, 5, C_fix(C_tm.tm_year)), \
        C_set_block_item(v, 6, C_fix(C_tm.tm_wday)), \
        C_set_block_item(v, 7, C_fix(C_tm.tm_yday)), \
        C_set_block_item(v, 8, (C_tm.tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define C_tm_get_9(v) \
        (C_set_block_item(v, 9, C_fix(C_tm.tm_gmtoff)))

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  return &C_tm;
}

static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  return v;
}

#else

static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  C_tm_set_9 (v);
  return &C_tm;
}

static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  C_tm_get_9 (v);
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[465];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,51,48,32,108,111,99,51,49,32,109,115,103,51,50,32,46,32,97,114,103,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,51,57,52,50,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,52,53,52,56,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,49,51,55,32,99,109,100,49,51,56,32,46,32,116,109,112,49,51,54,49,51,57,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,49,53,57,32,102,108,97,103,115,49,54,48,32,46,32,109,111,100,101,49,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,99,108,111,115,101,32,102,100,49,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,37),40,102,105,108,101,45,114,101,97,100,32,102,100,49,56,50,32,115,105,122,101,49,56,51,32,46,32,98,117,102,102,101,114,49,56,52,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,119,114,105,116,101,32,102,100,50,48,49,32,98,117,102,102,101,114,50,48,50,32,46,32,115,105,122,101,50,48,51,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,50,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,9),40,102,100,95,122,101,114,111,41,0,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,16),40,102,100,95,115,101,116,32,97,50,52,51,50,52,56,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,17),40,102,100,95,116,101,115,116,32,97,50,53,48,50,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,51,56,57,54,32,102,100,51,51,51,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,97,51,57,50,49,32,102,100,51,50,52,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,13),40,97,51,57,54,49,32,102,100,50,57,56,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,51,57,56,55,32,102,100,50,55,57,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,50,53,56,32,102,100,115,119,50,53,57,32,46,32,116,105,109,101,111,117,116,50,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,51,54,51,32,108,105,110,107,51,54,52,32,108,111,99,51,54,53,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,51,56,50,32,46,32,108,105,110,107,51,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,51,57,54,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,52,48,49,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,52,48,54,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,52,49,49,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,52,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,52,50,49,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,52,50,54,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,52,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,114,101,103,117,108,97,114,63,32,102,110,97,109,101,52,52,52,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,115,116,97,116,45,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,52,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,28),40,115,116,97,116,45,99,104,97,114,45,100,101,118,105,99,101,63,32,102,110,97,109,101,52,54,50,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,29),40,115,116,97,116,45,98,108,111,99,107,45,100,101,118,105,99,101,63,32,102,110,97,109,101,52,55,49,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,21),40,115,116,97,116,45,102,105,102,111,63,32,102,110,97,109,101,52,56,48,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,115,121,109,108,105,110,107,63,32,102,110,97,109,101,52,56,57,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,115,116,97,116,45,115,111,99,107,101,116,63,32,102,110,97,109,101,52,57,56,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,16),40,102,95,52,50,52,49,32,110,97,109,101,53,57,49,41};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,16),40,102,95,52,50,53,55,32,110,97,109,101,53,56,48,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,16),40,102,95,52,50,51,48,32,110,97,109,101,53,55,54,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,97,52,50,50,48,32,120,53,55,52,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,16),40,102,95,52,50,49,53,32,110,97,109,101,53,55,48,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,16),40,102,95,52,50,57,54,32,110,97,109,101,53,57,54,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,53,53,55,32,46,32,116,109,112,53,53,54,53,53,56,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,54,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,54,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,54,51,51,32,115,112,101,99,54,52,51,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,54,52,52,41,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,54,51,54,32,37,115,112,101,99,54,51,49,54,57,49,41,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,54,51,53,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,54,50,51,54,50,52,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,55,48,54,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,55,50,49,55,50,50,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,20),40,105,115,112,101,114,115,101,32,103,55,54,55,55,54,56,55,54,57,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,52,54,52,52,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,19),40,97,52,54,51,56,32,101,120,118,97,114,55,56,49,55,57,55,41,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,52,54,54,50,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,7),40,97,52,54,55,52,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,20),40,97,52,54,54,56,32,46,32,97,114,103,115,55,57,48,56,49,53,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,52,54,53,54,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,15),40,97,52,54,51,50,32,107,55,56,57,55,57,53,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,56,53,50,32,114,56,53,51,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,56,49,57,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,56,54,53,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,56,54,55,32,99,109,100,56,54,56,32,105,110,112,56,54,57,32,114,56,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,56,55,53,32,46,32,109,56,55,54,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,56,56,57,32,46,32,109,56,57,48,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,57,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,7),40,97,53,49,50,54,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,20),40,97,53,49,51,50,32,46,32,114,101,115,117,108,116,115,57,51,48,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,57,50,51,32,112,114,111,99,57,50,52,32,46,32,109,111,100,101,57,50,53,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,7),40,97,53,49,53,48,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,20),40,97,53,49,53,54,32,46,32,114,101,115,117,108,116,115,57,52,48,41,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,57,51,51,32,112,114,111,99,57,51,52,32,46,32,109,111,100,101,57,51,53,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,20),40,97,53,49,55,53,32,46,32,114,101,115,117,108,116,115,57,53,48,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,57,52,51,32,116,104,117,110,107,57,52,52,32,46,32,109,111,100,101,57,52,53,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,20),40,97,53,49,57,53,32,46,32,114,101,115,117,108,116,115,57,54,50,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,57,53,53,32,116,104,117,110,107,57,53,54,32,46,32,109,111,100,101,57,53,55,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,49,48,51,51,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,38),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,49,48,51,54,32,112,114,111,99,49,48,51,55,41,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,49,48,52,51,32,115,116,97,116,101,49,48,52,52,41,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,13),40,97,53,51,49,48,32,115,49,48,53,52,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,27),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,49,48,53,50,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,115,105,103,115,49,48,54,57,32,109,97,115,107,49,48,55,48,41};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,49,48,55,56,41};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,22),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,49,48,56,51,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,49,48,57,49,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,41),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,49,49,54,51,32,46,32,116,109,112,49,49,54,50,49,49,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,50,56,41,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,43),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,49,50,48,54,32,46,32,116,109,112,49,50,48,53,49,50,48,55,41,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,16),40,95,101,110,115,117,114,101,45,103,114,111,117,112,115,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,54,54,41,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,49,50,55,57,32,108,115,116,49,50,56,55,32,105,49,50,56,56,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,49,50,55,53,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,35),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,49,51,49,52,32,105,100,49,51,49,53,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,34),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,49,51,56,54,32,109,49,51,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,42),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,49,51,57,52,32,117,105,100,49,51,57,53,32,103,105,100,49,51,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,49,52,48,57,32,97,99,99,49,52,49,48,32,108,111,99,49,52,49,49,41,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,49,57,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,50,51,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,49,52,53,54,32,110,101,119,49,52,53,55,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,49,52,54,56,41,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,27),40,102,105,108,101,45,108,105,110,107,32,111,108,100,49,52,57,50,32,110,101,119,49,52,57,51,41,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,20),40,109,111,100,101,32,105,110,112,49,53,48,57,32,109,49,53,49,48,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,108,111,99,49,53,50,57,32,102,100,49,53,51,48,32,105,110,112,49,53,51,49,32,114,49,53,51,50,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,33),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,49,53,51,55,32,46,32,109,49,53,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,34),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,49,53,52,49,32,46,32,109,49,53,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,23),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,49,53,52,57,41,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,36),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,49,53,54,53,32,46,32,110,101,119,49,53,54,54,41,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,8),40,114,101,97,100,121,63,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,7),40,102,101,116,99,104,41,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,7),40,97,54,51,52,55,41,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,7),40,97,54,51,54,48,41,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,7),40,97,54,51,55,50,41,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,7),40,97,54,51,57,51,41,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,110,49,54,57,54,32,109,49,54,57,55,32,115,116,97,114,116,49,54,57,56,41,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,41),40,97,54,52,48,50,32,112,111,114,116,49,54,56,55,32,110,49,54,56,56,32,100,101,115,116,49,54,56,57,32,115,116,97,114,116,49,54,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,24),40,98,117,109,112,101,114,32,99,117,114,49,55,51,52,32,112,116,114,49,55,51,53,41};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,7),40,97,54,53,54,52,41,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,42),40,97,54,53,55,48,32,100,101,115,116,49,55,55,52,49,55,55,53,49,55,55,57,32,99,111,110,116,63,49,55,55,54,49,55,55,55,49,55,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,49,55,51,49,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,26),40,97,54,52,55,56,32,112,111,114,116,49,55,50,52,32,108,105,109,105,116,49,55,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,49,54,48,49,32,110,111,110,98,108,111,99,107,105,110,103,63,49,54,49,51,32,98,117,102,105,49,54,49,52,32,111,110,45,99,108,111,115,101,49,54,49,53,32,109,111,114,101,63,49,54,49,54,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,69),40,100,101,102,45,109,111,114,101,63,49,54,48,54,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,57,55,49,55,57,52,32,37,98,117,102,105,49,53,57,56,49,55,57,53,32,37,111,110,45,99,108,111,115,101,49,53,57,57,49,55,57,54,41,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,54,48,53,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,57,55,49,56,48,48,32,37,98,117,102,105,49,53,57,56,49,56,48,49,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,54,48,52,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,57,55,49,56,48,53,41,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,54,48,51,41,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,62),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,53,56,55,32,110,97,109,49,53,56,56,32,102,100,49,53,56,57,32,46,32,116,109,112,49,53,56,54,49,53,57,48,41,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,22),40,112,111,107,101,32,115,116,114,49,56,54,56,32,108,101,110,49,56,54,57,41,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,15),40,97,54,55,54,49,32,115,116,114,49,57,49,57,41,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,7),40,97,54,55,54,55,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,7),40,97,54,55,56,56,41,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,16),40,102,95,54,55,57,55,32,115,116,114,49,56,56,51,41};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,32,114,101,109,49,56,57,54,32,115,116,97,114,116,49,56,57,55,32,108,101,110,49,56,57,56,41};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,16),40,102,95,54,56,49,50,32,115,116,114,49,56,57,48,41};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,49),40,98,111,100,121,49,56,52,55,32,110,111,110,98,108,111,99,107,105,110,103,63,49,56,53,56,32,98,117,102,105,49,56,53,57,32,111,110,45,99,108,111,115,101,49,56,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,56,53,49,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,56,52,52,49,57,51,54,32,37,98,117,102,105,49,56,52,53,49,57,51,55,41,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,56,53,48,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,56,52,52,49,57,52,49,41,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,56,52,57,41,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,63),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,56,51,52,32,110,97,109,49,56,51,53,32,102,100,49,56,51,54,32,46,32,116,109,112,49,56,51,51,49,56,51,55,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,49,57,53,56,32,111,102,102,49,57,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,32,112,111,114,116,49,57,55,56,32,97,114,103,115,49,57,55,57,32,108,111,99,49,57,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,30),40,101,114,114,32,109,115,103,50,48,48,50,32,108,111,99,107,50,48,48,51,32,108,111,99,50,48,48,52,41,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,50,48,48,54,32,46,32,97,114,103,115,50,48,48,55,41,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,40),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,50,48,49,49,32,46,32,97,114,103,115,50,48,49,50,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,36),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,50,48,49,54,32,46,32,97,114,103,115,50,48,49,55,41,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,50,48,52,49,41,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,34),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,50,48,52,56,32,46,32,109,111,100,101,50,48,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,20),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,50,48,53,56,41,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,50,48,54,52,32,118,97,108,50,48,54,53,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,50,48,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,50,48,57,57,41,0,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,50,48,57,49,41,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,21),40,99,117,114,114,101,110,116,45,101,110,118,105,114,111,110,109,101,110,116,41,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,72),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,50,49,52,54,32,108,101,110,50,49,52,55,32,112,114,111,116,50,49,52,56,32,102,108,97,103,50,49,52,57,32,102,100,50,49,53,48,32,46,32,111,102,102,50,49,53,49,41};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,43),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,50,49,55,57,32,46,32,108,101,110,50,49,56,48,41,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,37),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,50,49,56,57,41,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,50,49,57,52,41,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,30),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,50,49,57,56,41,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,28),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,50,50,48,51,41,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,26),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,50,50,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,50,50,52,54,32,46,32,116,109,112,50,50,52,53,50,50,52,55,41,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,36),40,115,116,114,105,110,103,45,62,116,105,109,101,32,116,105,109,50,50,57,48,32,46,32,116,109,112,50,50,56,57,50,50,57,49,41,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,50,51,48,55,41,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,26),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,50,51,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,50,51,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,97,108,97,114,109,33,32,97,50,51,51,56,50,51,52,49,41,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,50,51,52,56,32,109,111,100,101,50,51,52,57,32,46,32,115,105,122,101,50,51,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,50,51,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,50,51,55,56,32,112,111,114,116,50,51,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,50,51,57,54,41};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,50,52,49,49,41};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,7),40,97,55,57,55,48,41,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,50,52,57,57,41,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,55),40,97,55,57,55,54,32,100,105,114,50,52,54,53,50,52,54,54,50,52,55,51,32,102,105,108,50,52,54,55,50,52,54,56,50,52,55,52,32,101,120,116,50,52,54,57,50,52,55,48,50,52,55,53,41,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,50,52,54,48,41,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,50,52,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,18),40,102,95,56,48,56,56,32,97,50,53,52,51,50,53,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,50,53,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,28),40,115,101,116,97,114,103,32,97,50,53,53,54,50,53,54,50,32,97,50,53,53,53,50,53,54,51,41,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,28),40,115,101,116,101,110,118,32,97,50,53,55,49,50,53,55,55,32,97,50,53,55,48,50,53,55,56,41,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,50,54,51,48,32,105,50,54,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,25),40,100,111,108,111,111,112,50,54,49,55,32,97,108,50,54,50,53,32,105,50,54,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,50,54,48,50,32,97,114,103,108,105,115,116,50,54,49,50,32,101,110,118,108,105,115,116,50,54,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,34),40,100,101,102,45,101,110,118,108,105,115,116,50,54,48,53,32,37,97,114,103,108,105,115,116,50,54,48,48,50,54,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,97,114,103,108,105,115,116,50,54,48,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,50,53,57,50,32,46,32,116,109,112,50,53,57,49,50,53,57,51,41,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,50,54,57,48,32,110,111,104,97,110,103,50,54,57,49,41,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,7),40,97,56,51,55,48,41,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,36),40,97,56,51,55,54,32,101,112,105,100,50,55,51,54,32,101,110,111,114,109,50,55,51,55,32,101,99,111,100,101,50,55,51,56,41,0,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,50,55,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,50,55,53,48,50,55,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,50,55,53,54,32,46,32,115,105,103,50,55,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,50,55,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,50,55,56,53,32,46,32,97,114,103,115,50,55,56,54,41,0,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,7),40,97,56,53,52,54,41,0};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,29),40,97,56,53,53,50,32,95,50,56,51,53,32,102,108,103,50,56,51,54,32,99,111,100,50,56,51,55,41,0,0,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,8),40,102,95,56,53,51,50,41};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,111,110,45,99,108,111,115,101,32,108,111,99,50,56,50,48,32,112,105,100,50,56,50,49,32,99,108,115,118,101,99,50,56,50,50,32,105,100,120,50,56,50,51,32,105,100,120,97,50,56,50,52,32,105,100,120,98,50,56,50,53,41,0,0,0,0};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,7),40,97,56,53,55,53,41,0};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,19),40,97,56,53,56,49,32,105,50,56,53,48,32,111,50,56,53,49,41,0,0,0,0,0};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,101,100,45,112,105,112,101,32,112,111,114,116,50,56,52,51,41,0,0};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,34),40,99,111,110,110,101,99,116,45,112,97,114,101,110,116,32,112,105,112,101,50,56,53,52,32,112,111,114,116,50,56,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,43),40,99,111,110,110,101,99,116,45,99,104,105,108,100,32,112,105,112,101,50,56,54,53,32,112,111,114,116,50,56,54,54,32,115,116,100,102,100,50,56,54,55,41,0,0,0,0,0};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,14),40,115,119,97,112,112,101,100,45,101,110,100,115,41,0,0};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,7),40,97,56,54,53,54,41,0};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,67),40,115,112,97,119,110,32,99,109,100,50,56,56,54,32,97,114,103,115,50,56,56,55,32,101,110,118,50,56,56,56,32,115,116,100,111,117,116,102,50,56,56,57,32,115,116,100,105,110,102,50,56,57,48,32,115,116,100,101,114,114,102,50,56,57,49,41,0,0,0,0,0};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,59),40,105,110,112,117,116,45,112,111,114,116,32,108,111,99,50,57,48,49,32,99,109,100,50,57,48,51,32,112,105,112,101,50,57,48,52,32,115,116,100,102,50,57,48,53,32,111,110,45,99,108,111,115,101,50,57,48,55,41,0,0,0,0,0};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,60),40,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,50,57,49,52,32,99,109,100,50,57,49,54,32,112,105,112,101,50,57,49,55,32,115,116,100,102,50,57,49,56,32,111,110,45,99,108,111,115,101,50,57,50,48,41,0,0,0,0};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,7),40,97,56,55,48,54,41,0};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,50),40,97,56,55,49,50,32,105,110,112,105,112,101,50,57,51,57,32,111,117,116,112,105,112,101,50,57,52,48,32,101,114,114,112,105,112,101,50,57,52,49,32,112,105,100,50,57,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,50,57,50,56,32,99,109,100,50,57,50,57,32,97,114,103,115,50,57,51,48,32,101,110,118,50,57,51,49,32,115,116,100,111,117,116,102,50,57,51,50,32,115,116,100,105,110,102,50,57,51,51,32,115,116,100,101,114,114,102,50,57,51,52,41,0,0,0,0,0};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,21),40,97,56,55,54,57,32,103,50,57,54,52,50,57,54,53,50,57,54,54,41,0,0,0};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,50,57,53,55,41,0,0,0,0,0};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,7),40,97,56,55,56,55,41,0};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,38),40,97,56,55,57,51,32,105,110,50,57,55,54,32,111,117,116,50,57,55,55,32,112,105,100,50,57,55,56,32,101,114,114,50,57,55,57,41,0,0};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,52),40,37,112,114,111,99,101,115,115,32,108,111,99,50,57,53,48,32,101,114,114,63,50,57,53,49,32,99,109,100,50,57,53,50,32,97,114,103,115,50,57,53,51,32,101,110,118,50,57,53,52,41,0,0,0,0};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,51,48,48,49,32,97,114,103,115,51,48,49,49,32,101,110,118,51,48,49,50,41,0,0,0,0,0};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,51,48,48,52,32,37,97,114,103,115,50,57,57,57,51,48,49,54,41,0,0,0,0,0};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,51,48,48,51,41,0,0};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,50,57,57,49,32,46,32,116,109,112,50,57,57,48,50,57,57,50,41,0};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,51,48,52,53,32,97,114,103,115,51,48,53,53,32,101,110,118,51,48,53,54,41,0,0,0,0,0};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,51,48,52,56,32,37,97,114,103,115,51,48,52,51,51,48,54,48,41,0,0,0,0,0};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,51,48,52,55,41,0,0};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,51,48,51,53,32,46,32,116,109,112,51,48,51,52,51,48,51,54,41};
static C_char C_TLS li239[] C_aligned={C_lihdr(0,0,14),40,102,95,57,48,56,51,32,120,51,49,51,48,41,0,0};
static C_char C_TLS li240[] C_aligned={C_lihdr(0,0,7),40,97,57,48,48,54,41,0};
static C_char C_TLS li241[] C_aligned={C_lihdr(0,0,7),40,97,57,48,49,49,41,0};
static C_char C_TLS li242[] C_aligned={C_lihdr(0,0,7),40,97,57,48,51,53,41,0};
static C_char C_TLS li243[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,51,49,51,56,32,114,51,49,51,57,41,0,0,0,0,0};
static C_char C_TLS li244[] C_aligned={C_lihdr(0,0,16),40,102,95,57,49,48,50,32,46,32,95,51,49,50,48,41};
static C_char C_TLS li245[] C_aligned={C_lihdr(0,0,16),40,102,95,57,48,57,52,32,46,32,95,51,49,49,56,41};
static C_char C_TLS li246[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,51,48,57,50,32,97,99,116,105,111,110,51,49,48,51,32,105,100,51,49,48,52,32,108,105,109,105,116,51,49,48,53,41,0,0};
static C_char C_TLS li247[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,51,48,57,54,32,37,97,99,116,105,111,110,51,48,56,57,51,49,55,57,32,37,105,100,51,48,57,48,51,49,56,48,41,0,0,0,0,0};
static C_char C_TLS li248[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,51,48,57,53,32,37,97,99,116,105,111,110,51,48,56,57,51,49,56,52,41,0,0,0,0};
static C_char C_TLS li249[] C_aligned={C_lihdr(0,0,19),40,97,57,49,50,50,32,120,51,49,56,57,32,121,51,49,57,48,41,0,0,0,0,0};
static C_char C_TLS li250[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,51,48,57,52,41};
static C_char C_TLS li251[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,51,48,56,48,32,112,114,101,100,51,48,56,49,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,51,48,56,50,41,0,0,0,0,0};
static C_char C_TLS li252[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,51,50,49,52,41,0,0,0};
static C_char C_TLS li253[] C_aligned={C_lihdr(0,0,15),40,97,57,50,50,49,32,112,105,100,49,52,51,56,41,0};
static C_char C_TLS li254[] C_aligned={C_lihdr(0,0,24),40,97,57,50,51,57,32,112,105,100,49,52,52,55,32,112,103,105,100,49,52,52,56,41};
static C_char C_TLS li255[] C_aligned={C_lihdr(0,0,7),40,97,57,50,54,48,41,0};
static C_char C_TLS li256[] C_aligned={C_lihdr(0,0,14),40,97,57,50,54,51,32,105,100,49,49,52,51,41,0,0};
static C_char C_TLS li257[] C_aligned={C_lihdr(0,0,7),40,97,57,50,55,56,41,0};
static C_char C_TLS li258[] C_aligned={C_lihdr(0,0,14),40,97,57,50,56,49,32,105,100,49,49,51,52,41,0,0};
static C_char C_TLS li259[] C_aligned={C_lihdr(0,0,7),40,97,57,50,57,54,41,0};
static C_char C_TLS li260[] C_aligned={C_lihdr(0,0,14),40,97,57,50,57,57,32,105,100,49,49,50,53,41,0,0};
static C_char C_TLS li261[] C_aligned={C_lihdr(0,0,7),40,97,57,51,49,52,41,0};
static C_char C_TLS li262[] C_aligned={C_lihdr(0,0,14),40,97,57,51,49,55,32,105,100,49,49,49,54,41,0,0};
static C_char C_TLS li263[] C_aligned={C_lihdr(0,0,13),40,97,57,51,51,50,32,110,49,48,57,56,41,0,0,0};
static C_char C_TLS li264[] C_aligned={C_lihdr(0,0,15),40,97,57,51,51,56,32,112,111,114,116,53,48,54,41,0};
static C_char C_TLS li265[] C_aligned={C_lihdr(0,0,34),40,97,57,51,55,53,32,112,111,114,116,53,50,48,32,112,111,115,53,50,49,32,46,32,119,104,101,110,99,101,53,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li266[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k9189 in set-root-directory! in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall stub3206(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3206(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k8428 */
static C_word C_fcall stub2751(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2751(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall stub2746(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2746(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall stub2742(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2742(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub2582(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2582(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k8134 */
static C_word C_fcall stub2573(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2573(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub2567(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2567(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k8115 */
static C_word C_fcall stub2558(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2558(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k8091 */
static C_word C_fcall stub2544(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2544(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub2526(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2526(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2433(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2433(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k7900 */
static C_word C_fcall stub2404(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2404(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k7877 */
static C_word C_fcall stub2389(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2389(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k7766 */
static C_word C_fcall stub2339(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2339(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k7744 */
static C_word C_fcall stub2330(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2330(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2322(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2322(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub2277(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2277(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub2232(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2232(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub2224(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2224(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k7515 */
static C_word C_fcall stub2209(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2209(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k7434 */
static C_word C_fcall stub2170(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2170(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k7372 */
static C_word C_fcall stub2131(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub2131(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k7272 */
static C_word C_fcall stub2079(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2079(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k6031 in k6027 in file-link in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall stub1480(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1480(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k5768 */
static C_word C_fcall stub1305(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1305(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k5637 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub1242(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1242(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from k5630 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1236(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1236(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from k5544 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1192(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1192(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a9260 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall stub1140(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1140(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a9278 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall stub1131(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1131(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a9296 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall stub1122(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1122(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a9314 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall stub1113(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1113(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k3812 */
static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k3802 */
static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k3792 */
static C_word C_fcall stub239(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub239(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k3574 */
static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from k3523 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub46(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub46(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from k3516 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub40(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub40(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k3492 */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9376)
static void C_ccall f_9376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9376)
static void C_ccall f_9376r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9389)
static void C_ccall f_9389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9401)
static void C_ccall f_9401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9395)
static void C_ccall f_9395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9339)
static void C_ccall f_9339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9355)
static void C_ccall f_9355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9343)
static void C_ccall f_9343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9346)
static void C_ccall f_9346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9333)
static void C_ccall f_9333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9318)
static void C_ccall f_9318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9328)
static void C_ccall f_9328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9315)
static void C_ccall f_9315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9300)
static void C_ccall f_9300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9310)
static void C_ccall f_9310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9297)
static void C_ccall f_9297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9282)
static void C_ccall f_9282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9292)
static void C_ccall f_9292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9279)
static void C_ccall f_9279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9264)
static void C_ccall f_9264(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9274)
static void C_ccall f_9274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9261)
static void C_ccall f_9261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9240)
static void C_ccall f_9240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9256)
static void C_ccall f_9256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9222)
static void C_ccall f_9222(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9229)
static void C_ccall f_9229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5958)
static void C_ccall f_5958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9199)
static void C_ccall f_9199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9191)
static void C_ccall f_9191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8940)
static void C_ccall f_8940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8940)
static void C_ccall f_8940r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9117)
static void C_fcall f_9117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9123)
static void C_ccall f_9123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9112)
static void C_fcall f_9112(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9107)
static void C_fcall f_9107(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8942)
static void C_fcall f_8942(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9094)
static void C_ccall f_9094(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9102)
static void C_ccall f_9102(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8949)
static void C_fcall f_8949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9082)
static void C_ccall f_9082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9076)
static void C_ccall f_9076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8959)
static void C_ccall f_8959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8961)
static void C_fcall f_8961(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9062)
static void C_ccall f_9062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9069)
static void C_ccall f_9069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9056)
static void C_ccall f_9056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_ccall f_8995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9049)
static void C_ccall f_9049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9046)
static void C_ccall f_9046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9036)
static void C_ccall f_9036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9012)
static void C_ccall f_9012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9020)
static void C_ccall f_9020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9027)
static void C_ccall f_9027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9024)
static void C_ccall f_9024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9007)
static void C_ccall f_9007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9005)
static void C_ccall f_9005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9083)
static void C_ccall f_9083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8880)
static void C_ccall f_8880(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8880)
static void C_ccall f_8880r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8892)
static void C_fcall f_8892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8887)
static void C_fcall f_8887(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8882)
static void C_fcall f_8882(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8820)
static void C_ccall f_8820(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8820)
static void C_ccall f_8820r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8832)
static void C_fcall f_8832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8827)
static void C_fcall f_8827(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8822)
static void C_fcall f_8822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8759)
static void C_fcall f_8759(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8814)
static void C_ccall f_8814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8818)
static void C_ccall f_8818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8780)
static void C_ccall f_8780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8783)
static void C_ccall f_8783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8794)
static void C_ccall f_8794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8788)
static void C_ccall f_8788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8761)
static void C_fcall f_8761(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8770)
static void C_ccall f_8770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8701)
static void C_ccall f_8701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8713)
static void C_ccall f_8713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8744)
static void C_ccall f_8744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8740)
static void C_ccall f_8740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8728)
static void C_ccall f_8728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8736)
static void C_ccall f_8736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8732)
static void C_ccall f_8732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8707)
static void C_ccall f_8707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8690)
static void C_fcall f_8690(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8694)
static void C_ccall f_8694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_fcall f_8679(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8683)
static void C_ccall f_8683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8634)
static void C_fcall f_8634(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8638)
static void C_ccall f_8638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8641)
static void C_ccall f_8641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8644)
static void C_ccall f_8644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8657)
static void C_ccall f_8657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8661)
static void C_ccall f_8661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8667)
static void C_ccall f_8667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8655)
static void C_ccall f_8655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8618)
static C_word C_fcall f_8618(C_word *a,C_word t0);
C_noret_decl(f_8601)
static void C_fcall f_8601(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8614)
static void C_ccall f_8614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8526)
static void C_ccall f_8526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8587)
static void C_fcall f_8587(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8600)
static void C_ccall f_8600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8567)
static void C_fcall f_8567(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8582)
static void C_ccall f_8582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8576)
static void C_ccall f_8576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8530)
static void C_fcall f_8530(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8532)
static void C_ccall f_8532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8553)
static void C_ccall f_8553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8547)
static void C_ccall f_8547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8474)
static void C_ccall f_8474(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8474)
static void C_ccall f_8474r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8481)
static void C_ccall f_8481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8500)
static void C_ccall f_8500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8504)
static void C_ccall f_8504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8468)
static void C_ccall f_8468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8459)
static void C_ccall f_8459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8463)
static void C_ccall f_8463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8432)
static void C_ccall f_8432(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8432)
static void C_ccall f_8432r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8425)
static void C_ccall f_8425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8422)
static void C_ccall f_8422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8419)
static void C_ccall f_8419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8341)
static void C_ccall f_8341(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8341)
static void C_ccall f_8341r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8377)
static void C_ccall f_8377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8371)
static void C_ccall f_8371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8324)
static void C_ccall f_8324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8276)
static void C_fcall f_8276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8271)
static void C_fcall f_8271(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8144)
static void C_fcall f_8144(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8162)
static void C_fcall f_8162(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8208)
static C_word C_fcall f_8208(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8175)
static void C_fcall f_8175(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8200)
static void C_ccall f_8200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8178)
static void C_ccall f_8178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8123)
static C_word C_fcall f_8123(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8104)
static C_word C_fcall f_8104(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8062)
static void C_ccall f_8062(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8062)
static void C_ccall f_8062r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8088)
static void C_ccall f_8088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7956)
static void C_fcall f_7956(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7977)
static void C_ccall f_7977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8054)
static void C_ccall f_8054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7981)
static void C_ccall f_7981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7987)
static void C_ccall f_7987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7994)
static void C_ccall f_7994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7996)
static void C_fcall f_7996(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8023)
static void C_ccall f_8023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8027)
static void C_ccall f_8027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7971)
static void C_ccall f_7971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7942)
static void C_ccall f_7942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7945)
static void C_ccall f_7945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7927)
static void C_ccall f_7927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7931)
static void C_ccall f_7931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7884)
static void C_ccall f_7884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7848)
static void C_fcall f_7848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7852)
static void C_ccall f_7852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7829)
static void C_ccall f_7829(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7833)
static void C_ccall f_7833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7836)
static void C_ccall f_7836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7770)
static void C_ccall f_7770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7770)
static void C_ccall f_7770r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7774)
static void C_ccall f_7774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7763)
static void C_ccall f_7763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7747)
static void C_ccall f_7747(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7747)
static void C_ccall f_7747r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7707)
static void C_ccall f_7707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7714)
static void C_ccall f_7714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7686)
static void C_ccall f_7686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7633)
static void C_ccall f_7633(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7633)
static void C_ccall f_7633r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7637)
static void C_ccall f_7637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7654)
static void C_ccall f_7654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7551)
static void C_ccall f_7551(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7551)
static void C_ccall f_7551r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7555)
static void C_ccall f_7555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7561)
static void C_ccall f_7561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7583)
static void C_ccall f_7583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7580)
static void C_ccall f_7580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7570)
static void C_ccall f_7570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7518)
static void C_ccall f_7518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7522)
static void C_ccall f_7522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7499)
static void C_ccall f_7499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7490)
static void C_ccall f_7490(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7484)
static void C_ccall f_7484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_7382)
static void C_ccall f_7382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7388)
static void C_ccall f_7388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7407)
static void C_ccall f_7407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7394)
static void C_ccall f_7394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7275)
static void C_ccall f_7275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7281)
static void C_fcall f_7281(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7285)
static void C_ccall f_7285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7293)
static void C_fcall f_7293(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7319)
static void C_ccall f_7319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7323)
static void C_ccall f_7323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7311)
static void C_ccall f_7311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7255)
static void C_ccall f_7255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7263)
static void C_ccall f_7263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_ccall f_7238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7212)
static void C_ccall f_7212(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7219)
static void C_ccall f_7219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7169)
static void C_ccall f_7169(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7169)
static void C_ccall f_7169r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7176)
static void C_fcall f_7176(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7197)
static void C_ccall f_7197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7193)
static void C_ccall f_7193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7141)
static void C_ccall f_7141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7119)
static void C_ccall f_7119(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7119)
static void C_ccall f_7119r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7123)
static void C_ccall f_7123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7104)
static void C_ccall f_7104(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7104)
static void C_ccall f_7104r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7108)
static void C_ccall f_7108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7093)
static void C_ccall f_7093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7071)
static void C_fcall f_7071(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6997)
static void C_fcall f_6997(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7025)
static void C_fcall f_7025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6958)
static void C_ccall f_6958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6986)
static void C_ccall f_6986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6982)
static void C_ccall f_6982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6975)
static void C_ccall f_6975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6699)
static void C_ccall f_6699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6699)
static void C_ccall f_6699r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6895)
static void C_fcall f_6895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6890)
static void C_fcall f_6890(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6885)
static void C_fcall f_6885(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6701)
static void C_fcall f_6701(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6705)
static void C_ccall f_6705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6811)
static void C_ccall f_6811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6812)
static void C_ccall f_6812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6829)
static void C_fcall f_6829(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6839)
static void C_ccall f_6839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6753)
static void C_fcall f_6753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6768)
static void C_ccall f_6768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6778)
static void C_ccall f_6778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6757)
static void C_ccall f_6757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6760)
static void C_ccall f_6760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6707)
static void C_fcall f_6707(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6742)
static void C_ccall f_6742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6723)
static void C_ccall f_6723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6621)
static void C_fcall f_6621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6616)
static void C_fcall f_6616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6611)
static void C_fcall f_6611(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6606)
static void C_fcall f_6606(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6227)
static void C_fcall f_6227(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6237)
static void C_ccall f_6237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6485)
static void C_fcall f_6485(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6504)
static void C_ccall f_6504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6411)
static void C_fcall f_6411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6413)
static void C_fcall f_6413(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6461)
static void C_ccall f_6461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6394)
static void C_ccall f_6394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6383)
static void C_ccall f_6383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6352)
static void C_ccall f_6352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6261)
static void C_fcall f_6261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6273)
static void C_fcall f_6273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6319)
static void C_ccall f_6319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6289)
static void C_ccall f_6289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static C_word C_fcall f_6253(C_word t0);
C_noret_decl(f_6238)
static void C_fcall f_6238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6205)
static void C_fcall f_6205(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6175)
static void C_ccall f_6175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6151)
static void C_ccall f_6151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6110)
static void C_fcall f_6110(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6073)
static void C_fcall f_6073(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6048)
static void C_ccall f_6048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6029)
static void C_ccall f_6029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6033)
static void C_ccall f_6033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5998)
static void C_ccall f_5998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5993)
static void C_ccall f_5993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5981)
static void C_ccall f_5981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5989)
static void C_ccall f_5989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5985)
static void C_ccall f_5985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5923)
static void C_ccall f_5923(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5899)
static void C_fcall f_5899(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5909)
static void C_ccall f_5909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5893)
static void C_ccall f_5893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5842)
static void C_ccall f_5842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5766)
static void C_ccall f_5766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5713)
static void C_fcall f_5713(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5699)
static void C_ccall f_5699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_ccall f_5648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5680)
static void C_ccall f_5680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5651)
static void C_ccall f_5651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5656)
static void C_fcall f_5656(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static C_word C_fcall f_5634(C_word t0);
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5606)
static void C_ccall f_5606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5555)
static void C_fcall f_5555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5569)
static void C_ccall f_5569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5578)
static void C_fcall f_5578(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5531)
static void C_ccall f_5531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5449)
static void C_fcall f_5449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5317)
static void C_ccall f_5317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5323)
static void C_fcall f_5323(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5142)
static void C_ccall f_5142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5142)
static void C_ccall f_5142r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5146)
static void C_ccall f_5146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_fcall f_5015(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_fcall f_5009(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static C_word C_fcall f_4997(C_word t0);
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_fcall f_4807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_fcall f_4826(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4870)
static void C_fcall f_4870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4696)
static void C_fcall f_4696(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_fcall f_4764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_fcall f_4624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static C_word C_fcall f_4613(C_word t0);
C_noret_decl(f_4608)
static void C_fcall f_4608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4544)
static void C_ccall f_4544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4485)
static void C_fcall f_4485(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_fcall f_4480(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4382)
static void C_fcall f_4382(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4413)
static void C_fcall f_4413(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4423)
static void C_ccall f_4423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4429)
static void C_ccall f_4429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4435)
static void C_fcall f_4435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4378)
static void C_ccall f_4378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4374)
static void C_ccall f_4374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4119)
static void C_ccall f_4119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_fcall f_4007(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_fcall f_3840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_fcall f_3879(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_fcall f_3883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static C_word C_fcall f_3805(C_word t0,C_word t1);
C_noret_decl(f_3795)
static C_word C_fcall f_3795(C_word t0,C_word t1);
C_noret_decl(f_3789)
static C_word C_fcall f_3789(C_word t0);
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3513)
static void C_ccall f_3513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3510)
static void C_ccall f_3510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9117)
static void C_fcall trf_9117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9117(t0,t1);}

C_noret_decl(trf_9112)
static void C_fcall trf_9112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9112(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9112(t0,t1,t2);}

C_noret_decl(trf_9107)
static void C_fcall trf_9107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9107(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9107(t0,t1,t2,t3);}

C_noret_decl(trf_8942)
static void C_fcall trf_8942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8942(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8942(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8949)
static void C_fcall trf_8949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8949(t0,t1);}

C_noret_decl(trf_8961)
static void C_fcall trf_8961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8961(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8961(t0,t1,t2,t3);}

C_noret_decl(trf_8892)
static void C_fcall trf_8892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8892(t0,t1);}

C_noret_decl(trf_8887)
static void C_fcall trf_8887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8887(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8887(t0,t1,t2);}

C_noret_decl(trf_8882)
static void C_fcall trf_8882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8882(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8882(t0,t1,t2,t3);}

C_noret_decl(trf_8832)
static void C_fcall trf_8832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8832(t0,t1);}

C_noret_decl(trf_8827)
static void C_fcall trf_8827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8827(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8827(t0,t1,t2);}

C_noret_decl(trf_8822)
static void C_fcall trf_8822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8822(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8822(t0,t1,t2,t3);}

C_noret_decl(trf_8759)
static void C_fcall trf_8759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8759(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8759(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8761)
static void C_fcall trf_8761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8761(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8761(t0,t1,t2);}

C_noret_decl(trf_8690)
static void C_fcall trf_8690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8690(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8690(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8679)
static void C_fcall trf_8679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8679(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8679(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8634)
static void C_fcall trf_8634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8634(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8634(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8601)
static void C_fcall trf_8601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8601(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8601(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8587)
static void C_fcall trf_8587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8587(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8587(t0,t1,t2,t3);}

C_noret_decl(trf_8567)
static void C_fcall trf_8567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8567(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8567(t0,t1,t2);}

C_noret_decl(trf_8530)
static void C_fcall trf_8530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8530(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8530(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8276)
static void C_fcall trf_8276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8276(t0,t1);}

C_noret_decl(trf_8271)
static void C_fcall trf_8271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8271(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8271(t0,t1,t2);}

C_noret_decl(trf_8144)
static void C_fcall trf_8144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8144(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8144(t0,t1,t2,t3);}

C_noret_decl(trf_8162)
static void C_fcall trf_8162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8162(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8162(t0,t1,t2,t3);}

C_noret_decl(trf_8175)
static void C_fcall trf_8175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8175(t0,t1);}

C_noret_decl(trf_7956)
static void C_fcall trf_7956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7956(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7956(t0,t1,t2);}

C_noret_decl(trf_7996)
static void C_fcall trf_7996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7996(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7996(t0,t1,t2);}

C_noret_decl(trf_7848)
static void C_fcall trf_7848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7848(t0,t1,t2);}

C_noret_decl(trf_7281)
static void C_fcall trf_7281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7281(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7281(t0,t1,t2);}

C_noret_decl(trf_7293)
static void C_fcall trf_7293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7293(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7293(t0,t1,t2);}

C_noret_decl(trf_7176)
static void C_fcall trf_7176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7176(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7176(t0,t1);}

C_noret_decl(trf_7071)
static void C_fcall trf_7071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7071(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7071(t0,t1,t2,t3);}

C_noret_decl(trf_6997)
static void C_fcall trf_6997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6997(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6997(t0,t1,t2,t3);}

C_noret_decl(trf_7025)
static void C_fcall trf_7025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7025(t0,t1);}

C_noret_decl(trf_6895)
static void C_fcall trf_6895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6895(t0,t1);}

C_noret_decl(trf_6890)
static void C_fcall trf_6890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6890(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6890(t0,t1,t2);}

C_noret_decl(trf_6885)
static void C_fcall trf_6885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6885(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6885(t0,t1,t2,t3);}

C_noret_decl(trf_6701)
static void C_fcall trf_6701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6701(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6701(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6829)
static void C_fcall trf_6829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6829(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6829(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6753)
static void C_fcall trf_6753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6753(t0,t1);}

C_noret_decl(trf_6707)
static void C_fcall trf_6707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6707(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6707(t0,t1,t2,t3);}

C_noret_decl(trf_6621)
static void C_fcall trf_6621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6621(t0,t1);}

C_noret_decl(trf_6616)
static void C_fcall trf_6616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6616(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6616(t0,t1,t2);}

C_noret_decl(trf_6611)
static void C_fcall trf_6611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6611(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6611(t0,t1,t2,t3);}

C_noret_decl(trf_6606)
static void C_fcall trf_6606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6606(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6606(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6227)
static void C_fcall trf_6227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6227(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6227(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6485)
static void C_fcall trf_6485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6485(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6485(t0,t1,t2);}

C_noret_decl(trf_6411)
static void C_fcall trf_6411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6411(t0,t1);}

C_noret_decl(trf_6413)
static void C_fcall trf_6413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6413(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6413(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6261)
static void C_fcall trf_6261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6261(t0,t1);}

C_noret_decl(trf_6273)
static void C_fcall trf_6273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6273(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6273(t0,t1);}

C_noret_decl(trf_6238)
static void C_fcall trf_6238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6238(t0,t1);}

C_noret_decl(trf_6205)
static void C_fcall trf_6205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6205(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6205(t0,t1);}

C_noret_decl(trf_6110)
static void C_fcall trf_6110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6110(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6110(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6073)
static void C_fcall trf_6073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6073(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6073(t0,t1,t2);}

C_noret_decl(trf_5899)
static void C_fcall trf_5899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5899(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5899(t0,t1,t2,t3);}

C_noret_decl(trf_5713)
static void C_fcall trf_5713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5713(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5713(t0,t1,t2,t3);}

C_noret_decl(trf_5656)
static void C_fcall trf_5656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5656(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5656(t0,t1,t2);}

C_noret_decl(trf_5555)
static void C_fcall trf_5555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5555(t0,t1);}

C_noret_decl(trf_5578)
static void C_fcall trf_5578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5578(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5578(t0,t1,t2);}

C_noret_decl(trf_5449)
static void C_fcall trf_5449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5449(t0,t1);}

C_noret_decl(trf_5323)
static void C_fcall trf_5323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5323(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5323(t0,t1,t2,t3);}

C_noret_decl(trf_5015)
static void C_fcall trf_5015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5015(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5015(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5009)
static void C_fcall trf_5009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5009(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5009(t0,t1);}

C_noret_decl(trf_4807)
static void C_fcall trf_4807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4807(t0,t1);}

C_noret_decl(trf_4826)
static void C_fcall trf_4826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4826(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4826(t0,t1);}

C_noret_decl(trf_4870)
static void C_fcall trf_4870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4870(t0,t1);}

C_noret_decl(trf_4696)
static void C_fcall trf_4696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4696(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4696(t0,t1,t2,t3);}

C_noret_decl(trf_4764)
static void C_fcall trf_4764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4764(t0,t1);}

C_noret_decl(trf_4624)
static void C_fcall trf_4624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4624(t0,t1);}

C_noret_decl(trf_4608)
static void C_fcall trf_4608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4608(t0,t1);}

C_noret_decl(trf_4485)
static void C_fcall trf_4485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4485(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4485(t0,t1);}

C_noret_decl(trf_4480)
static void C_fcall trf_4480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4480(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4480(t0,t1,t2);}

C_noret_decl(trf_4382)
static void C_fcall trf_4382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4382(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4382(t0,t1,t2,t3);}

C_noret_decl(trf_4413)
static void C_fcall trf_4413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4413(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4413(t0,t1);}

C_noret_decl(trf_4435)
static void C_fcall trf_4435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4435(t0,t1);}

C_noret_decl(trf_4007)
static void C_fcall trf_4007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4007(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4007(t0,t1,t2,t3);}

C_noret_decl(trf_3840)
static void C_fcall trf_3840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3840(t0,t1);}

C_noret_decl(trf_3879)
static void C_fcall trf_3879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3879(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3879(t0,t1);}

C_noret_decl(trf_3883)
static void C_fcall trf_3883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3883(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3330)){
C_save(t1);
C_rereclaim2(3330*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,465);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_h_intern(&lf[51],9,"file-open");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[53]=C_h_intern(&lf[53],17,"\003sysmake-c-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysexpand-home-path");
lf[55]=C_h_intern(&lf[55],10,"file-close");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],10,"file-write");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[65]=C_h_intern(&lf[65],12,"file-mkstemp");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[68]=C_h_intern(&lf[68],11,"file-select");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[70]=C_h_intern(&lf[70],12,"\003sysfor-each");
lf[71]=C_h_intern(&lf[71],8,"seek/set");
lf[72]=C_h_intern(&lf[72],8,"seek/end");
lf[73]=C_h_intern(&lf[73],8,"seek/cur");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[77]=C_h_intern(&lf[77],9,"file-stat");
lf[78]=C_h_intern(&lf[78],9,"file-size");
lf[79]=C_h_intern(&lf[79],22,"file-modification-time");
lf[80]=C_h_intern(&lf[80],16,"file-access-time");
lf[81]=C_h_intern(&lf[81],16,"file-change-time");
lf[82]=C_h_intern(&lf[82],10,"file-owner");
lf[83]=C_h_intern(&lf[83],16,"file-permissions");
lf[84]=C_h_intern(&lf[84],13,"regular-file\077");
lf[85]=C_h_intern(&lf[85],14,"symbolic-link\077");
lf[86]=C_h_intern(&lf[86],13,"stat-regular\077");
lf[87]=C_h_intern(&lf[87],15,"stat-directory\077");
lf[88]=C_h_intern(&lf[88],17,"stat-char-device\077");
lf[89]=C_h_intern(&lf[89],18,"stat-block-device\077");
lf[90]=C_h_intern(&lf[90],10,"stat-fifo\077");
lf[91]=C_h_intern(&lf[91],13,"stat-symlink\077");
lf[92]=C_h_intern(&lf[92],12,"stat-socket\077");
lf[93]=C_h_intern(&lf[93],13,"file-position");
lf[94]=C_h_intern(&lf[94],16,"create-directory");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot stat file");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\026path segment is a file");
lf[99]=C_h_intern(&lf[99],12,"file-exists\077");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[101]=C_h_intern(&lf[101],12,"string-split");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[103]=C_h_intern(&lf[103],14,"canonical-path");
lf[104]=C_h_intern(&lf[104],16,"change-directory");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[106]=C_h_intern(&lf[106],16,"delete-directory");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[108]=C_h_intern(&lf[108],10,"string-ref");
lf[109]=C_h_intern(&lf[109],6,"string");
lf[110]=C_h_intern(&lf[110],9,"directory");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[112]=C_h_intern(&lf[112],16,"\003sysmake-pointer");
lf[113]=C_h_intern(&lf[113],17,"current-directory");
lf[114]=C_h_intern(&lf[114],10,"directory\077");
lf[115]=C_h_intern(&lf[115],13,"\003sysfile-info");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[117]=C_h_intern(&lf[117],5,"null\077");
lf[118]=C_h_intern(&lf[118],6,"char=\077");
lf[119]=C_h_intern(&lf[119],8,"string=\077");
lf[120]=C_h_intern(&lf[120],16,"char-alphabetic\077");
lf[121]=C_h_intern(&lf[121],18,"string-intersperse");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[123]=C_h_intern(&lf[123],6,"getenv");
lf[124]=C_h_intern(&lf[124],17,"current-user-name");
lf[125]=C_h_intern(&lf[125],9,"condition");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[127]=C_h_intern(&lf[127],22,"with-exception-handler");
lf[128]=C_h_intern(&lf[128],30,"call-with-current-continuation");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[132]=C_h_intern(&lf[132],7,"reverse");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[143]=C_h_intern(&lf[143],5,"\000text");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[146]=C_h_intern(&lf[146],13,"\003sysmake-port");
lf[147]=C_h_intern(&lf[147],21,"\003sysstream-port-class");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[149]=C_h_intern(&lf[149],6,"stream");
lf[150]=C_h_intern(&lf[150],15,"open-input-pipe");
lf[151]=C_h_intern(&lf[151],7,"\000binary");
lf[152]=C_h_intern(&lf[152],16,"open-output-pipe");
lf[153]=C_h_intern(&lf[153],16,"close-input-pipe");
lf[154]=C_h_intern(&lf[154],23,"close-input/output-pipe");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[156]=C_h_intern(&lf[156],14,"\003syscheck-port");
lf[157]=C_h_intern(&lf[157],17,"close-output-pipe");
lf[158]=C_h_intern(&lf[158],20,"call-with-input-pipe");
lf[159]=C_h_intern(&lf[159],21,"call-with-output-pipe");
lf[160]=C_h_intern(&lf[160],20,"with-input-from-pipe");
lf[161]=C_h_intern(&lf[161],18,"\003sysstandard-input");
lf[162]=C_h_intern(&lf[162],19,"with-output-to-pipe");
lf[163]=C_h_intern(&lf[163],19,"\003sysstandard-output");
lf[164]=C_h_intern(&lf[164],11,"create-pipe");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[166]=C_h_intern(&lf[166],11,"signal/term");
lf[167]=C_h_intern(&lf[167],11,"signal/kill");
lf[168]=C_h_intern(&lf[168],10,"signal/int");
lf[169]=C_h_intern(&lf[169],10,"signal/hup");
lf[170]=C_h_intern(&lf[170],10,"signal/fpe");
lf[171]=C_h_intern(&lf[171],10,"signal/ill");
lf[172]=C_h_intern(&lf[172],11,"signal/segv");
lf[173]=C_h_intern(&lf[173],11,"signal/abrt");
lf[174]=C_h_intern(&lf[174],11,"signal/trap");
lf[175]=C_h_intern(&lf[175],11,"signal/quit");
lf[176]=C_h_intern(&lf[176],11,"signal/alrm");
lf[177]=C_h_intern(&lf[177],13,"signal/vtalrm");
lf[178]=C_h_intern(&lf[178],11,"signal/prof");
lf[179]=C_h_intern(&lf[179],9,"signal/io");
lf[180]=C_h_intern(&lf[180],10,"signal/urg");
lf[181]=C_h_intern(&lf[181],11,"signal/chld");
lf[182]=C_h_intern(&lf[182],11,"signal/cont");
lf[183]=C_h_intern(&lf[183],11,"signal/stop");
lf[184]=C_h_intern(&lf[184],11,"signal/tstp");
lf[185]=C_h_intern(&lf[185],11,"signal/pipe");
lf[186]=C_h_intern(&lf[186],11,"signal/xcpu");
lf[187]=C_h_intern(&lf[187],11,"signal/xfsz");
lf[188]=C_h_intern(&lf[188],11,"signal/usr1");
lf[189]=C_h_intern(&lf[189],11,"signal/usr2");
lf[190]=C_h_intern(&lf[190],12,"signal/winch");
lf[191]=C_h_intern(&lf[191],12,"signals-list");
lf[192]=C_h_intern(&lf[192],18,"\003sysinterrupt-hook");
lf[193]=C_h_intern(&lf[193],14,"signal-handler");
lf[194]=C_h_intern(&lf[194],19,"set-signal-handler!");
lf[195]=C_h_intern(&lf[195],16,"set-signal-mask!");
lf[196]=C_h_intern(&lf[196],14,"\000process-error");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[198]=C_h_intern(&lf[198],11,"signal-mask");
lf[199]=C_h_intern(&lf[199],14,"signal-masked\077");
lf[200]=C_h_intern(&lf[200],12,"signal-mask!");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[202]=C_h_intern(&lf[202],14,"signal-unmask!");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[204]=C_h_intern(&lf[204],18,"system-information");
lf[205]=C_h_intern(&lf[205],25,"\003syspeek-nonnull-c-string");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[207]=C_h_intern(&lf[207],15,"current-user-id");
lf[208]=C_h_intern(&lf[208],25,"current-effective-user-id");
lf[209]=C_h_intern(&lf[209],16,"current-group-id");
lf[210]=C_h_intern(&lf[210],26,"current-effective-group-id");
lf[211]=C_h_intern(&lf[211],16,"user-information");
lf[212]=C_h_intern(&lf[212],6,"vector");
lf[213]=C_h_intern(&lf[213],4,"list");
lf[214]=C_h_intern(&lf[214],27,"current-effective-user-name");
lf[215]=C_h_intern(&lf[215],17,"group-information");
lf[217]=C_h_intern(&lf[217],10,"get-groups");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[221]=C_h_intern(&lf[221],11,"set-groups!");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[224]=C_h_intern(&lf[224],17,"initialize-groups");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[226]=C_h_intern(&lf[226],10,"errno/perm");
lf[227]=C_h_intern(&lf[227],11,"errno/noent");
lf[228]=C_h_intern(&lf[228],10,"errno/srch");
lf[229]=C_h_intern(&lf[229],10,"errno/intr");
lf[230]=C_h_intern(&lf[230],8,"errno/io");
lf[231]=C_h_intern(&lf[231],12,"errno/noexec");
lf[232]=C_h_intern(&lf[232],10,"errno/badf");
lf[233]=C_h_intern(&lf[233],11,"errno/child");
lf[234]=C_h_intern(&lf[234],11,"errno/nomem");
lf[235]=C_h_intern(&lf[235],11,"errno/acces");
lf[236]=C_h_intern(&lf[236],11,"errno/fault");
lf[237]=C_h_intern(&lf[237],10,"errno/busy");
lf[238]=C_h_intern(&lf[238],12,"errno/notdir");
lf[239]=C_h_intern(&lf[239],11,"errno/isdir");
lf[240]=C_h_intern(&lf[240],11,"errno/inval");
lf[241]=C_h_intern(&lf[241],11,"errno/mfile");
lf[242]=C_h_intern(&lf[242],11,"errno/nospc");
lf[243]=C_h_intern(&lf[243],11,"errno/spipe");
lf[244]=C_h_intern(&lf[244],10,"errno/pipe");
lf[245]=C_h_intern(&lf[245],11,"errno/again");
lf[246]=C_h_intern(&lf[246],10,"errno/rofs");
lf[247]=C_h_intern(&lf[247],11,"errno/exist");
lf[248]=C_h_intern(&lf[248],16,"errno/wouldblock");
lf[249]=C_h_intern(&lf[249],10,"errno/2big");
lf[250]=C_h_intern(&lf[250],12,"errno/deadlk");
lf[251]=C_h_intern(&lf[251],9,"errno/dom");
lf[252]=C_h_intern(&lf[252],10,"errno/fbig");
lf[253]=C_h_intern(&lf[253],11,"errno/ilseq");
lf[254]=C_h_intern(&lf[254],11,"errno/mlink");
lf[255]=C_h_intern(&lf[255],17,"errno/nametoolong");
lf[256]=C_h_intern(&lf[256],11,"errno/nfile");
lf[257]=C_h_intern(&lf[257],11,"errno/nodev");
lf[258]=C_h_intern(&lf[258],11,"errno/nolck");
lf[259]=C_h_intern(&lf[259],11,"errno/nosys");
lf[260]=C_h_intern(&lf[260],14,"errno/notempty");
lf[261]=C_h_intern(&lf[261],11,"errno/notty");
lf[262]=C_h_intern(&lf[262],10,"errno/nxio");
lf[263]=C_h_intern(&lf[263],11,"errno/range");
lf[264]=C_h_intern(&lf[264],10,"errno/xdev");
lf[265]=C_h_intern(&lf[265],16,"change-file-mode");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[267]=C_h_intern(&lf[267],17,"change-file-owner");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[269]=C_h_intern(&lf[269],17,"file-read-access\077");
lf[270]=C_h_intern(&lf[270],18,"file-write-access\077");
lf[271]=C_h_intern(&lf[271],20,"file-execute-access\077");
lf[272]=C_h_intern(&lf[272],14,"create-session");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[274]=C_h_intern(&lf[274],16,"process-group-id");
lf[275]=C_h_intern(&lf[275],20,"create-symbolic-link");
lf[276]=C_h_intern(&lf[276],18,"create-symbol-link");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[278]=C_h_intern(&lf[278],9,"substring");
lf[279]=C_h_intern(&lf[279],18,"read-symbolic-link");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[281]=C_h_intern(&lf[281],9,"file-link");
lf[282]=C_h_intern(&lf[282],9,"hard-link");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[284]=C_h_intern(&lf[284],12,"fileno/stdin");
lf[285]=C_h_intern(&lf[285],13,"fileno/stdout");
lf[286]=C_h_intern(&lf[286],13,"fileno/stderr");
lf[287]=C_h_intern(&lf[287],7,"\000append");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[295]=C_h_intern(&lf[295],16,"open-input-file*");
lf[296]=C_h_intern(&lf[296],17,"open-output-file*");
lf[297]=C_h_intern(&lf[297],12,"port->fileno");
lf[298]=C_h_intern(&lf[298],6,"socket");
lf[299]=C_h_intern(&lf[299],20,"\003systcp-port->fileno");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[302]=C_h_intern(&lf[302],25,"\003syspeek-unsigned-integer");
lf[303]=C_h_intern(&lf[303],16,"duplicate-fileno");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[305]=C_h_intern(&lf[305],15,"make-input-port");
lf[306]=C_h_intern(&lf[306],14,"set-port-name!");
lf[307]=C_h_intern(&lf[307],21,"\003syscustom-input-port");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[309]=C_h_intern(&lf[309],17,"\003systhread-yield!");
lf[310]=C_h_intern(&lf[310],25,"\003systhread-block-for-i/o!");
lf[311]=C_h_intern(&lf[311],18,"\003syscurrent-thread");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[316]=C_h_intern(&lf[316],17,"\003sysstring-append");
lf[317]=C_h_intern(&lf[317],15,"\003sysmake-string");
lf[318]=C_h_intern(&lf[318],20,"\003sysscan-buffer-line");
lf[319]=C_h_intern(&lf[319],4,"noop");
lf[320]=C_h_intern(&lf[320],16,"make-output-port");
lf[321]=C_h_intern(&lf[321],22,"\003syscustom-output-port");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[324]=C_h_intern(&lf[324],13,"file-truncate");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[327]=C_h_intern(&lf[327],4,"lock");
lf[328]=C_h_intern(&lf[328],9,"file-lock");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[330]=C_h_intern(&lf[330],18,"file-lock/blocking");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[332]=C_h_intern(&lf[332],14,"file-test-lock");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[334]=C_h_intern(&lf[334],11,"file-unlock");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[336]=C_h_intern(&lf[336],11,"create-fifo");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[338]=C_h_intern(&lf[338],5,"fifo\077");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[340]=C_h_intern(&lf[340],6,"setenv");
lf[341]=C_h_intern(&lf[341],8,"unsetenv");
lf[342]=C_h_intern(&lf[342],19,"current-environment");
lf[343]=C_h_intern(&lf[343],9,"prot/read");
lf[344]=C_h_intern(&lf[344],10,"prot/write");
lf[345]=C_h_intern(&lf[345],9,"prot/exec");
lf[346]=C_h_intern(&lf[346],9,"prot/none");
lf[347]=C_h_intern(&lf[347],9,"map/fixed");
lf[348]=C_h_intern(&lf[348],10,"map/shared");
lf[349]=C_h_intern(&lf[349],11,"map/private");
lf[350]=C_h_intern(&lf[350],13,"map/anonymous");
lf[351]=C_h_intern(&lf[351],8,"map/file");
lf[352]=C_h_intern(&lf[352],18,"map-file-to-memory");
lf[353]=C_h_intern(&lf[353],4,"mmap");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[355]=C_h_intern(&lf[355],20,"\003syspointer->address");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[357]=C_h_intern(&lf[357],16,"\003sysnull-pointer");
lf[358]=C_h_intern(&lf[358],22,"unmap-file-from-memory");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[360]=C_h_intern(&lf[360],26,"memory-mapped-file-pointer");
lf[361]=C_h_intern(&lf[361],19,"memory-mapped-file\077");
lf[362]=C_h_intern(&lf[362],19,"seconds->local-time");
lf[363]=C_h_intern(&lf[363],18,"\003sysdecode-seconds");
lf[364]=C_h_intern(&lf[364],17,"seconds->utc-time");
lf[365]=C_h_intern(&lf[365],15,"seconds->string");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[367]=C_h_intern(&lf[367],12,"time->string");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[371]=C_h_intern(&lf[371],12,"string->time");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[373]=C_h_intern(&lf[373],19,"local-time->seconds");
lf[374]=C_h_intern(&lf[374],15,"\003syscons-flonum");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[377]=C_h_intern(&lf[377],17,"utc-time->seconds");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[380]=C_h_intern(&lf[380],27,"local-timezone-abbreviation");
lf[381]=C_h_intern(&lf[381],5,"_exit");
lf[382]=C_h_intern(&lf[382],10,"set-alarm!");
lf[383]=C_h_intern(&lf[383],19,"set-buffering-mode!");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[385]=C_h_intern(&lf[385],5,"\000full");
lf[386]=C_h_intern(&lf[386],5,"\000line");
lf[387]=C_h_intern(&lf[387],5,"\000none");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[389]=C_h_intern(&lf[389],14,"terminal-port\077");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[392]=C_h_intern(&lf[392],13,"terminal-name");
lf[393]=C_h_intern(&lf[393],13,"terminal-size");
lf[394]=C_h_intern(&lf[394],6,"\000error");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[396]=C_h_intern(&lf[396],17,"\003sysmake-locative");
lf[397]=C_h_intern(&lf[397],8,"location");
lf[398]=C_h_intern(&lf[398],13,"get-host-name");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[400]=C_h_intern(&lf[400],6,"regexp");
lf[401]=C_h_intern(&lf[401],21,"make-anchored-pattern");
lf[402]=C_h_intern(&lf[402],12,"string-match");
lf[403]=C_h_intern(&lf[403],12,"glob->regexp");
lf[404]=C_h_intern(&lf[404],13,"make-pathname");
lf[405]=C_h_intern(&lf[405],18,"decompose-pathname");
lf[406]=C_h_intern(&lf[406],4,"glob");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[409]=C_h_intern(&lf[409],12,"process-fork");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[411]=C_h_intern(&lf[411],24,"pathname-strip-directory");
lf[412]=C_h_intern(&lf[412],15,"process-execute");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[414]=C_h_intern(&lf[414],16,"\003sysprocess-wait");
lf[415]=C_h_intern(&lf[415],12,"process-wait");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[417]=C_h_intern(&lf[417],18,"current-process-id");
lf[418]=C_h_intern(&lf[418],17,"parent-process-id");
lf[419]=C_h_intern(&lf[419],5,"sleep");
lf[420]=C_h_intern(&lf[420],14,"process-signal");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[422]=C_h_intern(&lf[422],17,"\003sysshell-command");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[425]=C_h_intern(&lf[425],27,"\003sysshell-command-arguments");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[427]=C_h_intern(&lf[427],11,"process-run");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[429]=C_h_intern(&lf[429],11,"\003sysprocess");
lf[430]=C_h_intern(&lf[430],7,"process");
lf[431]=C_h_intern(&lf[431],8,"process*");
lf[432]=C_h_intern(&lf[432],10,"find-files");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[436]=C_h_intern(&lf[436],16,"\003sysdynamic-wind");
lf[437]=C_h_intern(&lf[437],13,"pathname-file");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[439]=C_h_intern(&lf[439],7,"regexp\077");
lf[440]=C_h_intern(&lf[440],19,"set-root-directory!");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[443]=C_h_intern(&lf[443],21,"set-process-group-id!");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[445]=C_h_intern(&lf[445],18,"getter-with-setter");
lf[446]=C_h_intern(&lf[446],26,"effective-group-id!-setter");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[448]=C_h_intern(&lf[448],12,"set-user-id!");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[450]=C_h_intern(&lf[450],25,"effective-user-id!-setter");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[453]=C_h_intern(&lf[453],23,"\003sysuser-interrupt-hook");
lf[454]=C_h_intern(&lf[454],11,"make-vector");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[457]=C_h_intern(&lf[457],5,"port\077");
lf[458]=C_h_intern(&lf[458],18,"set-file-position!");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[461]=C_h_intern(&lf[461],13,"\000bounds-error");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[463]=C_h_intern(&lf[463],17,"register-feature!");
lf[464]=C_h_intern(&lf[464],5,"posix");
C_register_lf2(lf,465,create_ptable());
t2=C_mutate(&lf[0] /* c150 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3468,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3466 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3471,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3469 in k3466 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3472 in k3469 in k3466 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3480,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3483,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 493  register-feature!");
t3=*((C_word*)lf[463]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[464]);}

/* k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word ab[113],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3483,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3495,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3513,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* file-select-one ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3520,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1 /* fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1 /* fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1 /* fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1 /* fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1 /* fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1 /* open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1 /* open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1 /* open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1 /* open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1 /* open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1 /* open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1 /* open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1 /* open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1 /* open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1 /* open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1 /* open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1 /* open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1 /* open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1 /* open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1 /* open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1 /* perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1 /* perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1 /* perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1 /* perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1 /* perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1 /* perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1 /* perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1 /* perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1 /* perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1 /* perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1 /* perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1 /* perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1 /* perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1 /* perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1 /* perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1 /* file-control ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3577,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[51]+1 /* file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3623,a[2]=t45,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[55]+1 /* file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3661,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[57]+1);
t49=C_mutate((C_word*)lf[58]+1 /* file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3676,a[2]=t48,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[62]+1 /* file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3718,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[65]+1 /* file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3789,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3795,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3805,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t55=C_mutate((C_word*)lf[68]+1 /* file-select ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3815,a[2]=t53,a[3]=t54,a[4]=t52,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t56=C_mutate((C_word*)lf[71]+1 /* seek/set ...) */,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[72]+1 /* seek/end ...) */,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[73]+1 /* seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[74] /* stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4007,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[77]+1 /* file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4044,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[78]+1 /* file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4076,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[79]+1 /* file-modification-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4082,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[80]+1 /* file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4088,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[81]+1 /* file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4094,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[82]+1 /* file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4100,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[83]+1 /* file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4106,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[84]+1 /* regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4112,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[85]+1 /* symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4121,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[86]+1 /* stat-regular? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4130,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[87]+1 /* stat-directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4139,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[88]+1 /* stat-char-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4148,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[89]+1 /* stat-block-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4157,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[90]+1 /* stat-fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4166,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[91]+1 /* stat-symlink? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4175,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[92]+1 /* stat-socket? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4184,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t76=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4195,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t77=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9339,a[2]=((C_word)li264),tmp=(C_word)a,a+=3,tmp);
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9376,a[2]=((C_word)li265),tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 820  getter-with-setter");
t79=*((C_word*)lf[445]+1);
((C_proc4)C_retrieve_proc(t79))(4,t79,t76,t77,t78);}

/* a9375 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_9376r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_9376r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9376r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[458]);
t8=(C_word)C_i_check_exact_2(t6,lf[458]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9389,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
C_trace("posixunix.scm: 835  ##sys#signal-hook");
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[461],lf[458],lf[462],t3,t2);}
else{
t10=t9;
f_9389(2,t10,C_SCHEME_UNDEFINED);}}

/* k9387 in a9375 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 836  port?");
t4=*((C_word*)lf[457]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k9399 in k9387 in a9375 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[149]);
t4=((C_word*)t0)[4];
f_9395(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_9395(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
C_trace("posixunix.scm: 840  ##sys#signal-hook");
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[60],lf[458],lf[460],((C_word*)t0)[5]);}}}

/* k9393 in k9387 in a9375 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 841  posix-error");
t2=lf[3];
f_3495(7,t2,((C_word*)t0)[4],lf[48],lf[458],lf[459],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a9338 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9339,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9343,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9355,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 822  port?");
t5=*((C_word*)lf[457]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k9353 in a9338 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[149]);
t4=((C_word*)t0)[2];
f_9343(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_9343(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
C_trace("posixunix.scm: 827  ##sys#signal-hook");
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[93],lf[456],((C_word*)t0)[3]);}}}

/* k9341 in a9338 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9346,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
C_trace("posixunix.scm: 829  posix-error");
t3=lf[3];
f_3495(6,t3,t2,lf[48],lf[93],lf[455],((C_word*)t0)[2]);}
else{
t3=t2;
f_9346(2,t3,C_SCHEME_UNDEFINED);}}

/* k9344 in k9341 in a9338 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[171],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4195,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1 /* file-position ...) */,t1);
t3=C_mutate((C_word*)lf[94]+1 /* create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4197,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[104]+1 /* change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4332,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[106]+1 /* delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4356,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[108]+1);
t7=*((C_word*)lf[57]+1);
t8=*((C_word*)lf[109]+1);
t9=C_mutate((C_word*)lf[110]+1 /* directory ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4380,a[2]=t7,a[3]=t6,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[114]+1 /* directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4537,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[113]+1 /* current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4560,a[2]=t11,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[117]+1);
t14=*((C_word*)lf[118]+1);
t15=*((C_word*)lf[119]+1);
t16=*((C_word*)lf[120]+1);
t17=*((C_word*)lf[108]+1);
t18=*((C_word*)lf[2]+1);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4608,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4613,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
t21=*((C_word*)lf[123]+1);
t22=*((C_word*)lf[124]+1);
t23=*((C_word*)lf[113]+1);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4624,a[2]=t23,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t25=C_mutate((C_word*)lf[103]+1 /* canonical-path ...) */,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4680,a[2]=t16,a[3]=t14,a[4]=t21,a[5]=t22,a[6]=t24,a[7]=t15,a[8]=t13,a[9]=t17,a[10]=t19,a[11]=t18,a[12]=t20,a[13]=((C_word)li61),tmp=(C_word)a,a+=14,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4997,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5009,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5015,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
t29=C_mutate((C_word*)lf[150]+1 /* open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5030,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li65),tmp=(C_word)a,a+=6,tmp));
t30=C_mutate((C_word*)lf[152]+1 /* open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5066,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[153]+1 /* close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5102,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[157]+1 /* close-output-pipe ...) */,*((C_word*)lf[153]+1));
t33=*((C_word*)lf[150]+1);
t34=*((C_word*)lf[152]+1);
t35=*((C_word*)lf[153]+1);
t36=*((C_word*)lf[157]+1);
t37=C_mutate((C_word*)lf[158]+1 /* call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5118,a[2]=t33,a[3]=t35,a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp));
t38=C_mutate((C_word*)lf[159]+1 /* call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5142,a[2]=t34,a[3]=t36,a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[160]+1 /* with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5166,a[2]=t33,a[3]=t35,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[162]+1 /* with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5186,a[2]=t34,a[3]=t36,a[4]=((C_word)li77),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[164]+1 /* create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5206,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[166]+1 /* signal/term ...) */,C_fix((C_word)SIGTERM));
t43=C_mutate((C_word*)lf[167]+1 /* signal/kill ...) */,C_fix((C_word)SIGKILL));
t44=C_mutate((C_word*)lf[168]+1 /* signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[169]+1 /* signal/hup ...) */,C_fix((C_word)SIGHUP));
t46=C_mutate((C_word*)lf[170]+1 /* signal/fpe ...) */,C_fix((C_word)SIGFPE));
t47=C_mutate((C_word*)lf[171]+1 /* signal/ill ...) */,C_fix((C_word)SIGILL));
t48=C_mutate((C_word*)lf[172]+1 /* signal/segv ...) */,C_fix((C_word)SIGSEGV));
t49=C_mutate((C_word*)lf[173]+1 /* signal/abrt ...) */,C_fix((C_word)SIGABRT));
t50=C_mutate((C_word*)lf[174]+1 /* signal/trap ...) */,C_fix((C_word)SIGTRAP));
t51=C_mutate((C_word*)lf[175]+1 /* signal/quit ...) */,C_fix((C_word)SIGQUIT));
t52=C_mutate((C_word*)lf[176]+1 /* signal/alrm ...) */,C_fix((C_word)SIGALRM));
t53=C_mutate((C_word*)lf[177]+1 /* signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t54=C_mutate((C_word*)lf[178]+1 /* signal/prof ...) */,C_fix((C_word)SIGPROF));
t55=C_mutate((C_word*)lf[179]+1 /* signal/io ...) */,C_fix((C_word)SIGIO));
t56=C_mutate((C_word*)lf[180]+1 /* signal/urg ...) */,C_fix((C_word)SIGURG));
t57=C_mutate((C_word*)lf[181]+1 /* signal/chld ...) */,C_fix((C_word)SIGCHLD));
t58=C_mutate((C_word*)lf[182]+1 /* signal/cont ...) */,C_fix((C_word)SIGCONT));
t59=C_mutate((C_word*)lf[183]+1 /* signal/stop ...) */,C_fix((C_word)SIGSTOP));
t60=C_mutate((C_word*)lf[184]+1 /* signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t61=C_mutate((C_word*)lf[185]+1 /* signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t62=C_mutate((C_word*)lf[186]+1 /* signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t63=C_mutate((C_word*)lf[187]+1 /* signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t64=C_mutate((C_word*)lf[188]+1 /* signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t65=C_mutate((C_word*)lf[189]+1 /* signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t66=C_mutate((C_word*)lf[190]+1 /* signal/winch ...) */,C_fix((C_word)SIGWINCH));
t67=(C_word)C_a_i_list(&a,25,*((C_word*)lf[166]+1),*((C_word*)lf[167]+1),*((C_word*)lf[168]+1),*((C_word*)lf[169]+1),*((C_word*)lf[170]+1),*((C_word*)lf[171]+1),*((C_word*)lf[172]+1),*((C_word*)lf[173]+1),*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1),*((C_word*)lf[189]+1),*((C_word*)lf[190]+1));
t68=C_mutate((C_word*)lf[191]+1 /* signals-list ...) */,t67);
t69=*((C_word*)lf[192]+1);
t70=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5251,a[2]=((C_word*)t0)[2],a[3]=t69,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1163 make-vector");
t71=*((C_word*)lf[454]+1);
((C_proc4)(void*)(*((C_word*)t71+1)))(4,t71,t70,C_fix(256),C_SCHEME_FALSE);}

/* k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5251,2,t0,t1);}
t2=C_mutate((C_word*)lf[193]+1 /* signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5253,a[2]=t1,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[194]+1 /* set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5262,a[2]=t1,a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[192]+1 /* interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5275,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[195]+1 /* set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5293,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[198]+1 /* signal-mask ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5317,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[199]+1 /* signal-masked? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5349,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[200]+1 /* signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5355,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[202]+1 /* signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5370,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9333,a[2]=((C_word)li263),tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1219 set-signal-handler!");
t12=*((C_word*)lf[194]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,*((C_word*)lf[168]+1),t11);}

/* a9332 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9333,3,t0,t1,t2);}
C_trace("posixunix.scm: 1221 ##sys#user-interrupt-hook");
t3=*((C_word*)lf[453]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5386,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1 /* system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5388,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5428,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9315,a[2]=((C_word)li261),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9318,a[2]=((C_word)li262),tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1245 getter-with-setter");
t6=*((C_word*)lf[445]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a9317 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9318,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9328,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1249 ##sys#update-errno");
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9326 in a9317 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1250 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[448],lf[452],((C_word*)t0)[2]);}

/* a9314 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9315,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1113(C_SCHEME_UNDEFINED));}

/* k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5428,2,t0,t1);}
t2=C_mutate((C_word*)lf[207]+1 /* current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5432,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9297,a[2]=((C_word)li259),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9300,a[2]=((C_word)li260),tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1253 getter-with-setter");
t6=*((C_word*)lf[445]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a9299 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9300,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9310,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1257 ##sys#update-errno");
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9308 in a9299 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1258 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[450],lf[451],((C_word*)t0)[2]);}

/* a9296 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9297,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1122(C_SCHEME_UNDEFINED));}

/* k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5432,2,t0,t1);}
t2=C_mutate((C_word*)lf[208]+1 /* current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9279,a[2]=((C_word)li257),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9282,a[2]=((C_word)li258),tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1262 getter-with-setter");
t6=*((C_word*)lf[445]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a9281 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9282,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9292,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1266 ##sys#update-errno");
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9290 in a9281 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1267 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[448],lf[449],((C_word*)t0)[2]);}

/* a9278 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9279,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1131(C_SCHEME_UNDEFINED));}

/* k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5436,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1 /* current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9261,a[2]=((C_word)li255),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9264,a[2]=((C_word)li256),tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1270 getter-with-setter");
t6=*((C_word*)lf[445]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a9263 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9264(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9264,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9274,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1274 ##sys#update-errno");
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9272 in a9263 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1275 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[446],lf[447],((C_word*)t0)[2]);}

/* a9260 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9261,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1140(C_SCHEME_UNDEFINED));}

/* k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5440,2,t0,t1);}
t2=C_mutate((C_word*)lf[210]+1 /* current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[211]+1 /* user-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5442,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[124]+1 /* current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5509,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[214]+1 /* current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5523,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[215]+1 /* group-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5548,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[216] /* _ensure-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5634,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[217]+1 /* get-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5641,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[221]+1 /* set-groups! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5704,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[224]+1 /* initialize-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5778,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[226]+1 /* errno/perm ...) */,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[227]+1 /* errno/noent ...) */,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[228]+1 /* errno/srch ...) */,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[229]+1 /* errno/intr ...) */,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[230]+1 /* errno/io ...) */,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[231]+1 /* errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[232]+1 /* errno/badf ...) */,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[233]+1 /* errno/child ...) */,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[234]+1 /* errno/nomem ...) */,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[235]+1 /* errno/acces ...) */,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[236]+1 /* errno/fault ...) */,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[237]+1 /* errno/busy ...) */,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[238]+1 /* errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[239]+1 /* errno/isdir ...) */,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[240]+1 /* errno/inval ...) */,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[241]+1 /* errno/mfile ...) */,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[242]+1 /* errno/nospc ...) */,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[243]+1 /* errno/spipe ...) */,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[244]+1 /* errno/pipe ...) */,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[245]+1 /* errno/again ...) */,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[246]+1 /* errno/rofs ...) */,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[247]+1 /* errno/exist ...) */,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[248]+1 /* errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[249] /* errno/2big */,0,C_fix(0));
t35=C_set_block_item(lf[250] /* errno/deadlk */,0,C_fix(0));
t36=C_set_block_item(lf[251] /* errno/dom */,0,C_fix(0));
t37=C_set_block_item(lf[252] /* errno/fbig */,0,C_fix(0));
t38=C_set_block_item(lf[253] /* errno/ilseq */,0,C_fix(0));
t39=C_set_block_item(lf[254] /* errno/mlink */,0,C_fix(0));
t40=C_set_block_item(lf[255] /* errno/nametoolong */,0,C_fix(0));
t41=C_set_block_item(lf[256] /* errno/nfile */,0,C_fix(0));
t42=C_set_block_item(lf[257] /* errno/nodev */,0,C_fix(0));
t43=C_set_block_item(lf[258] /* errno/nolck */,0,C_fix(0));
t44=C_set_block_item(lf[259] /* errno/nosys */,0,C_fix(0));
t45=C_set_block_item(lf[260] /* errno/notempty */,0,C_fix(0));
t46=C_set_block_item(lf[261] /* errno/notty */,0,C_fix(0));
t47=C_set_block_item(lf[262] /* errno/nxio */,0,C_fix(0));
t48=C_set_block_item(lf[263] /* errno/range */,0,C_fix(0));
t49=C_set_block_item(lf[264] /* errno/xdev */,0,C_fix(0));
t50=C_mutate((C_word*)lf[265]+1 /* change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5842,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[267]+1 /* change-file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5869,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5899,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[269]+1 /* file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5923,a[2]=t52,a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[270]+1 /* file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5929,a[2]=t52,a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[271]+1 /* file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5935,a[2]=t52,a[3]=((C_word)li106),tmp=(C_word)a,a+=4,tmp));
t56=C_mutate((C_word*)lf[272]+1 /* create-session ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5941,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9222,a[2]=((C_word)li253),tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9240,a[2]=((C_word)li254),tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1490 getter-with-setter");
t60=*((C_word*)lf[445]+1);
((C_proc4)C_retrieve_proc(t60))(4,t60,t57,t58,t59);}

/* a9239 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9240,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[443]);
t5=(C_word)C_i_check_exact_2(t3,lf[443]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9256,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1502 ##sys#update-errno");
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k9254 in a9239 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1503 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[443],lf[444],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9221 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9222(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9222,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[274]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9229,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9235,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1495 ##sys#update-errno");
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_9229(2,t6,C_SCHEME_UNDEFINED);}}

/* k9233 in a9221 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1496 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[274],lf[442],((C_word*)t0)[2]);}

/* k9227 in a9221 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5958,2,t0,t1);}
t2=C_mutate((C_word*)lf[274]+1 /* process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[275]+1 /* create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5960,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[278]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5997,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
C_trace("posixunix.scm: 1523 make-string");
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[259],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5997,2,t0,t1);}
t2=C_mutate((C_word*)lf[279]+1 /* read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5998,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[281]+1 /* file-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6048,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[284]+1 /* fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[285]+1 /* fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[286]+1 /* fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6073,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6110,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp);
t9=C_mutate((C_word*)lf[295]+1 /* open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6125,a[2]=t7,a[3]=t8,a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[296]+1 /* open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6139,a[2]=t7,a[3]=t8,a[4]=((C_word)li114),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[297]+1 /* port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6153,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[303]+1 /* duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6198,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[305]+1);
t14=*((C_word*)lf[306]+1);
t15=C_mutate((C_word*)lf[307]+1 /* custom-input-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6225,a[2]=t13,a[3]=t14,a[4]=((C_word)li136),tmp=(C_word)a,a+=5,tmp));
t16=*((C_word*)lf[320]+1);
t17=*((C_word*)lf[306]+1);
t18=C_mutate((C_word*)lf[321]+1 /* custom-output-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6699,a[2]=t16,a[3]=t17,a[4]=((C_word)li148),tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[324]+1 /* file-truncate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6958,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6997,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7071,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[328]+1 /* file-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7089,a[2]=t20,a[3]=t21,a[4]=((C_word)li152),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[330]+1 /* file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7104,a[2]=t20,a[3]=t21,a[4]=((C_word)li153),tmp=(C_word)a,a+=5,tmp));
t24=C_mutate((C_word*)lf[332]+1 /* file-test-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7119,a[2]=t20,a[3]=t21,a[4]=((C_word)li154),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[334]+1 /* file-unlock ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7141,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[336]+1 /* create-fifo ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7169,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[338]+1 /* fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7212,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[340]+1 /* setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7238,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[341]+1 /* unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7255,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[342]+1 /* current-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7275,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[343]+1 /* prot/read ...) */,C_fix((C_word)PROT_READ));
t32=C_mutate((C_word*)lf[344]+1 /* prot/write ...) */,C_fix((C_word)PROT_WRITE));
t33=C_mutate((C_word*)lf[345]+1 /* prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t34=C_mutate((C_word*)lf[346]+1 /* prot/none ...) */,C_fix((C_word)PROT_NONE));
t35=C_mutate((C_word*)lf[347]+1 /* map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t36=C_mutate((C_word*)lf[348]+1 /* map/shared ...) */,C_fix((C_word)MAP_SHARED));
t37=C_mutate((C_word*)lf[349]+1 /* map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t38=C_mutate((C_word*)lf[350]+1 /* map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t39=C_mutate((C_word*)lf[351]+1 /* map/file ...) */,C_fix((C_word)MAP_FILE));
t40=C_mutate((C_word*)lf[352]+1 /* map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7378,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[358]+1 /* unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7440,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[360]+1 /* memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7475,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[361]+1 /* memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7484,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[362]+1 /* seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7490,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[364]+1 /* seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7499,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[365]+1 /* seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7518,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[367]+1 /* time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7551,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[371]+1 /* string->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7633,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[373]+1 /* local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7679,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[377]+1 /* utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7707,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[380]+1 /* local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7735,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[381]+1 /* _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7747,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[382]+1 /* set-alarm! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7763,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[383]+1 /* set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7770,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[389]+1 /* terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7829,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate(&lf[390] /* terminal-check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7848,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[392]+1 /* terminal-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7880,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[393]+1 /* terminal-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7903,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[398]+1 /* get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7938,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp));
t60=*((C_word*)lf[400]+1);
t61=*((C_word*)lf[401]+1);
t62=*((C_word*)lf[402]+1);
t63=*((C_word*)lf[403]+1);
t64=*((C_word*)lf[110]+1);
t65=*((C_word*)lf[404]+1);
t66=*((C_word*)lf[405]+1);
t67=C_mutate((C_word*)lf[406]+1 /* glob ...) */,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7950,a[2]=t63,a[3]=t61,a[4]=t60,a[5]=t64,a[6]=t62,a[7]=t65,a[8]=t66,a[9]=((C_word)li187),tmp=(C_word)a,a+=10,tmp));
t68=C_mutate((C_word*)lf[409]+1 /* process-fork ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8062,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp));
t69=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8104,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8123,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
t71=*((C_word*)lf[411]+1);
t72=C_mutate((C_word*)lf[412]+1 /* process-execute ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8142,a[2]=t71,a[3]=t70,a[4]=t69,a[5]=((C_word)li197),tmp=(C_word)a,a+=6,tmp));
t73=C_mutate((C_word*)lf[414]+1 /* process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8324,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[415]+1 /* process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8341,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[417]+1 /* current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8419,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[418]+1 /* parent-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8422,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[419]+1 /* sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8425,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[420]+1 /* process-signal ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8432,a[2]=((C_word)li205),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[422]+1 /* shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8459,a[2]=((C_word)li206),tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[425]+1 /* shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8468,a[2]=((C_word)li207),tmp=(C_word)a,a+=3,tmp));
t81=*((C_word*)lf[409]+1);
t82=*((C_word*)lf[412]+1);
t83=*((C_word*)lf[123]+1);
t84=C_mutate((C_word*)lf[427]+1 /* process-run ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8474,a[2]=t81,a[3]=t82,a[4]=((C_word)li208),tmp=(C_word)a,a+=5,tmp));
t85=*((C_word*)lf[164]+1);
t86=*((C_word*)lf[415]+1);
t87=*((C_word*)lf[409]+1);
t88=*((C_word*)lf[412]+1);
t89=*((C_word*)lf[303]+1);
t90=*((C_word*)lf[55]+1);
t91=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8530,a[2]=t86,a[3]=((C_word)li212),tmp=(C_word)a,a+=4,tmp);
t92=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8567,a[2]=t85,a[3]=((C_word)li215),tmp=(C_word)a,a+=4,tmp);
t93=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8587,a[2]=t90,a[3]=((C_word)li216),tmp=(C_word)a,a+=4,tmp);
t94=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8601,a[2]=t90,a[3]=((C_word)li217),tmp=(C_word)a,a+=4,tmp);
t95=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8618,a[2]=((C_word)li218),tmp=(C_word)a,a+=3,tmp);
t96=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8634,a[2]=t92,a[3]=t87,a[4]=t94,a[5]=t88,a[6]=t95,a[7]=((C_word)li220),tmp=(C_word)a,a+=8,tmp);
t97=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8679,a[2]=t93,a[3]=((C_word)li221),tmp=(C_word)a,a+=4,tmp);
t98=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8690,a[2]=t93,a[3]=((C_word)li222),tmp=(C_word)a,a+=4,tmp);
t99=C_mutate((C_word*)lf[429]+1 /* process ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8701,a[2]=t98,a[3]=t91,a[4]=t97,a[5]=t96,a[6]=((C_word)li225),tmp=(C_word)a,a+=7,tmp));
t100=C_set_block_item(lf[430] /* process */,0,C_SCHEME_UNDEFINED);
t101=C_set_block_item(lf[431] /* process* */,0,C_SCHEME_UNDEFINED);
t102=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8759,a[2]=((C_word)li230),tmp=(C_word)a,a+=3,tmp);
t103=C_mutate((C_word*)lf[430]+1 /* process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8820,a[2]=t102,a[3]=((C_word)li234),tmp=(C_word)a,a+=4,tmp));
t104=C_mutate((C_word*)lf[431]+1 /* process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8880,a[2]=t102,a[3]=((C_word)li238),tmp=(C_word)a,a+=4,tmp));
t105=*((C_word*)lf[406]+1);
t106=*((C_word*)lf[402]+1);
t107=*((C_word*)lf[404]+1);
t108=*((C_word*)lf[114]+1);
t109=C_mutate((C_word*)lf[432]+1 /* find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8940,a[2]=t108,a[3]=t107,a[4]=t105,a[5]=t106,a[6]=((C_word)li251),tmp=(C_word)a,a+=7,tmp));
t110=C_mutate((C_word*)lf[440]+1 /* set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9199,a[2]=((C_word)li252),tmp=(C_word)a,a+=3,tmp));
t111=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t111+1)))(2,t111,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9199,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[440]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9191,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_foreign_string_argumentp(t4);
C_trace("##sys#make-c-string");
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t6=t5;
f_9191(2,t6,C_SCHEME_FALSE);}}

/* k9189 in set-root-directory! in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub3206(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
C_trace("posixunix.scm: 2376 posix-error");
t3=lf[3];
f_3495(6,t3,((C_word*)t0)[3],lf[48],lf[440],lf[441],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_8940r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8940r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8940r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li246),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9107,a[2]=t5,a[3]=((C_word)li247),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9112,a[2]=t6,a[3]=((C_word)li248),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9117,a[2]=t7,a[3]=((C_word)li250),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-action30943187");
t9=t8;
f_9117(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("def-id30953183");
t11=t7;
f_9112(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
C_trace("def-limit30963178");
t13=t6;
f_9107(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
C_trace("body30923102");
t15=t5;
f_8942(t15,t1,t9,t11,t13);}
else{
C_trace("##sys#error");
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action3094 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_9117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9117,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9123,a[2]=((C_word)li249),tmp=(C_word)a,a+=3,tmp);
C_trace("def-id30953183");
t3=((C_word*)t0)[2];
f_9112(t3,t1,t2);}

/* a9122 in def-action3094 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9123,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id3095 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_9112(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9112,NULL,3,t0,t1,t2);}
C_trace("def-limit30963178");
t3=((C_word*)t0)[2];
f_9107(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit3096 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_9107(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9107,NULL,4,t0,t1,t2,t3);}
C_trace("body30923102");
t4=((C_word*)t0)[2];
f_8942(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8942(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8942,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[432]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8949,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_8949(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9102,a[2]=t4,a[3]=t7,a[4]=((C_word)li244),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_8949(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9094,a[2]=((C_word)li245),tmp=(C_word)a,a+=3,tmp));}}

/* f_9094 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9094(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9094,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_9102 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9102(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9102,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8949,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_9082(2,t4,t2);}
else{
C_trace("posixunix.scm: 2348 regexp?");
t4=*((C_word*)lf[439]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[11]);}}

/* k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9082,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9083,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word)li239),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9076,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 2351 make-pathname");
t5=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[438]);}

/* k9074 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2351 glob");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8959,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8961,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li243),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_8961(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8961(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8961,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
C_trace("posixunix.scm: 2357 directory?");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8980,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
C_trace("posixunix.scm: 2358 pathname-file");
t3=*((C_word*)lf[437]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9062,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
C_trace("posixunix.scm: 2365 pproc");
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k9060 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9062,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9069,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 2365 action");
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("posixunix.scm: 2366 loop");
t2=((C_word*)((C_word*)t0)[7])[1];
f_8961(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k9067 in k9060 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2365 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_8961(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9056,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[433]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[434]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
C_trace("posixunix.scm: 2358 loop");
t2=((C_word*)((C_word*)t0)[12])[1];
f_8961(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
C_trace("posixunix.scm: 2359 lproc");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8993 in k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8995,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9005,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9007,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,a[5]=((C_word)li240),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word)li241),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9036,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,a[5]=((C_word)li242),tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#dynamic-wind");
t11=*((C_word*)lf[436]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9046,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9049,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 2364 pproc");
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k9047 in k8993 in k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("posixunix.scm: 2364 action");
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_9046(2,t2,((C_word*)t0)[2]);}}

/* k9044 in k8993 in k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2364 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_8961(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9035 in k8993 in k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9036,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a9011 in k8993 in k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9020,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9034,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 2362 make-pathname");
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],lf[435]);}

/* k9032 in a9011 in k8993 in k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2362 glob");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9018 in a9011 in k8993 in k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9024,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 2363 pproc");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k9025 in k9018 in a9011 in k8993 in k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("posixunix.scm: 2363 action");
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_9024(2,t2,((C_word*)t0)[2]);}}

/* k9022 in k9018 in a9011 in k8993 in k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2362 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_8961(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9006 in k8993 in k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9007,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k9003 in k8993 in k9054 in k8978 in loop in k8957 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2360 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_8961(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_9083 in k9080 in k8947 in body3092 in find-files in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_9083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9083,3,t0,t1,t2);}
C_trace("posixunix.scm: 2349 string-match");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8880(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8880r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8880r(t0,t1,t2,t3);}}

static void C_ccall f_8880r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8882,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li235),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8887,a[2]=t4,a[3]=((C_word)li236),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8892,a[2]=t5,a[3]=((C_word)li237),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("def-args30473063");
t7=t6;
f_8892(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
C_trace("def-env30483059");
t9=t5;
f_8887(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("body30453054");
t11=t4;
f_8882(t11,t1,t7,t9);}
else{
C_trace("##sys#error");
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args3047 in process* in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8892,NULL,2,t0,t1);}
C_trace("def-env30483059");
t2=((C_word*)t0)[2];
f_8887(t2,t1,C_SCHEME_FALSE);}

/* def-env3048 in process* in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8887(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8887,NULL,3,t0,t1,t2);}
C_trace("body30453054");
t3=((C_word*)t0)[2];
f_8882(t3,t1,t2,C_SCHEME_FALSE);}

/* body3045 in process* in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8882(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8882,NULL,4,t0,t1,t2,t3);}
C_trace("posixunix.scm: 2326 %process");
f_8759(t1,lf[431],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8820(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8820r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8820r(t0,t1,t2,t3);}}

static void C_ccall f_8820r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8822,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li231),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8827,a[2]=t4,a[3]=((C_word)li232),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8832,a[2]=t5,a[3]=((C_word)li233),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("def-args30033019");
t7=t6;
f_8832(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
C_trace("def-env30043015");
t9=t5;
f_8827(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("body30013010");
t11=t4;
f_8822(t11,t1,t7,t9);}
else{
C_trace("##sys#error");
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args3003 in process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8832,NULL,2,t0,t1);}
C_trace("def-env30043015");
t2=((C_word*)t0)[2];
f_8827(t2,t1,C_SCHEME_FALSE);}

/* def-env3004 in process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8827(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8827,NULL,3,t0,t1,t2);}
C_trace("body30013010");
t3=((C_word*)t0)[2];
f_8822(t3,t1,t2,C_SCHEME_FALSE);}

/* body3001 in process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8822(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8822,NULL,4,t0,t1,t2,t3);}
C_trace("posixunix.scm: 2323 %process");
f_8759(t1,lf[430],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8759(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8759,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8761,a[2]=t2,a[3]=((C_word)li227),tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8780,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
C_trace("posixunix.scm: 2312 chkstrlst");
t12=t9;
f_8761(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8814,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 2314 ##sys#shell-command-arguments");
t13=*((C_word*)lf[425]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)t7)[1]);}}

/* k8812 in %process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8814,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 2315 ##sys#shell-command");
t4=*((C_word*)lf[422]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8816 in k8812 in %process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_8780(2,t3,t2);}

/* k8778 in %process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
C_trace("posixunix.scm: 2316 chkstrlst");
t3=((C_word*)t0)[2];
f_8761(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_8783(2,t3,C_SCHEME_UNDEFINED);}}

/* k8781 in k8778 in %process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li228),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8794,a[2]=((C_word*)t0)[3],a[3]=((C_word)li229),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8793 in k8781 in k8778 in %process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8794,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
C_trace("posixunix.scm: 2319 values");
C_values(6,0,t1,t2,t3,t4,t5);}
else{
C_trace("posixunix.scm: 2320 values");
C_values(5,0,t1,t2,t3,t4);}}

/* a8787 in k8781 in k8778 in %process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8788,2,t0,t1);}
C_trace("posixunix.scm: 2317 ##sys#process");
t2=*((C_word*)lf[429]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8761(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8761,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8770,a[2]=((C_word*)t0)[2],a[3]=((C_word)li226),tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a8769 in chkstrlst in %process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8770,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8701,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8707,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word)li223),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,a[10]=((C_word)li224),tmp=(C_word)a,a+=11,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t9,t10);}

/* a8712 in ##sys#process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8713,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8724,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8744,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("posixunix.scm: 2293 make-on-close");
t12=((C_word*)t0)[3];
f_8530(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k8742 in a8712 in ##sys#process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2292 input-port");
t2=((C_word*)t0)[7];
f_8679(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8722 in a8712 in ##sys#process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8728,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
C_trace("posixunix.scm: 2295 make-on-close");
t4=((C_word*)t0)[6];
f_8530(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k8738 in k8722 in a8712 in ##sys#process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2294 output-port");
t2=((C_word*)t0)[7];
f_8690(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8726 in k8722 in a8712 in ##sys#process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8732,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8736,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("posixunix.scm: 2298 make-on-close");
t4=((C_word*)t0)[3];
f_8530(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k8734 in k8726 in k8722 in a8712 in ##sys#process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2297 input-port");
t2=((C_word*)t0)[7];
f_8679(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8730 in k8726 in k8722 in a8712 in ##sys#process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2291 values");
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8706 in ##sys#process in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8707,2,t0,t1);}
C_trace("posixunix.scm: 2286 spawn");
t2=((C_word*)t0)[8];
f_8634(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8690(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8690,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8694,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 2282 connect-parent");
t8=((C_word*)t0)[2];
f_8587(t8,t7,t4,t5);}

/* k8692 in output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("posixunix.scm: 2283 ##sys#custom-output-port");
t2=*((C_word*)lf[321]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8679(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8679,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8683,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 2278 connect-parent");
t8=((C_word*)t0)[2];
f_8587(t8,t7,t4,t5);}

/* k8681 in input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("posixunix.scm: 2279 ##sys#custom-input-port");
t2=*((C_word*)lf[307]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8634(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8634,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
C_trace("posixunix.scm: 2265 needed-pipe");
t9=((C_word*)t0)[2];
f_8567(t9,t8,t6);}

/* k8636 in spawn in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
C_trace("posixunix.scm: 2266 needed-pipe");
t3=((C_word*)t0)[2];
f_8567(t3,t2,((C_word*)t0)[5]);}

/* k8639 in k8636 in spawn in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8644,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
C_trace("posixunix.scm: 2267 needed-pipe");
t3=((C_word*)t0)[2];
f_8567(t3,t2,((C_word*)t0)[6]);}

/* k8642 in k8639 in k8636 in spawn in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8644,2,t0,t1);}
t2=f_8618(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8655,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word)li219),tmp=(C_word)a,a+=15,tmp);
C_trace("posixunix.scm: 2270 process-fork");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8656 in k8642 in k8639 in k8636 in spawn in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8661,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
C_trace("posixunix.scm: 2272 connect-child");
t3=((C_word*)t0)[7];
f_8601(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[284]+1));}

/* k8659 in a8656 in k8642 in k8639 in k8636 in spawn in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8664,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_8618(C_a_i(&a,3),((C_word*)t0)[3]);
C_trace("posixunix.scm: 2273 connect-child");
t4=((C_word*)t0)[5];
f_8601(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[285]+1));}

/* k8662 in k8659 in a8656 in k8642 in k8639 in k8636 in spawn in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8667,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_8618(C_a_i(&a,3),((C_word*)t0)[4]);
C_trace("posixunix.scm: 2274 connect-child");
t4=((C_word*)t0)[3];
f_8601(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[286]+1));}

/* k8665 in k8662 in k8659 in a8656 in k8642 in k8639 in k8636 in spawn in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2275 process-execute");
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8653 in k8642 in k8639 in k8636 in spawn in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2268 values");
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall f_8618(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8601(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8601,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8614,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 2256 file-close");
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k8612 in connect-child in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8614,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8526,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 2230 duplicate-fileno");
t6=*((C_word*)lf[303]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k8524 in k8612 in connect-child in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2231 file-close");
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8587(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8587,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8600,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 2250 file-close");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k8598 in connect-parent in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8567(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8567,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8576,a[2]=((C_word*)t0)[2],a[3]=((C_word)li213),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8582,a[2]=((C_word)li214),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a8581 in needed-pipe in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8582(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8582,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a8575 in needed-pipe in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8576,2,t0,t1);}
C_trace("posixunix.scm: 2245 create-pipe");
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* make-on-close in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8530(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8530,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8532,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,a[9]=((C_word)li211),tmp=(C_word)a,a+=10,tmp));}

/* f_8532 in make-on-close in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8532,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li209),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8553,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li210),tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a8552 */
static void C_ccall f_8553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8553,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 2240 ##sys#signal-hook");
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[196],((C_word*)t0)[3],lf[428],((C_word*)t0)[2],t4);}}

/* a8546 */
static void C_ccall f_8547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8547,2,t0,t1);}
C_trace("posixunix.scm: 2238 process-wait");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8474(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8474r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8474r(t0,t1,t2,t3);}}

static void C_ccall f_8474r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8481,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 2194 process-fork");
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k8479 in process-run in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8481,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
C_trace("posixunix.scm: 2196 process-execute");
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 2198 ##sys#shell-command");
t4=*((C_word*)lf[422]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k8498 in k8479 in process-run in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8504,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 2198 ##sys#shell-command-arguments");
t3=*((C_word*)lf[425]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8502 in k8498 in k8479 in process-run in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2198 process-execute");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8468,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[426],t2));}

/* ##sys#shell-command in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8463,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 2183 getenv");
t3=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[424]);}

/* k8461 in ##sys#shell-command in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[423]));}

/* process-signal in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8432(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8432r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8432r(t0,t1,t2,t3);}}

static void C_ccall f_8432r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[420]);
t7=(C_word)C_i_check_exact_2(t5,lf[420]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
C_trace("posixunix.scm: 2180 posix-error");
t10=lf[3];
f_3495(7,t10,t1,lf[196],lf[420],lf[421],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8425,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2751(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8422,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2746(C_SCHEME_UNDEFINED));}

/* current-process-id in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8419,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2742(C_SCHEME_UNDEFINED));}

/* process-wait in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8341(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_8341r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8341r(t0,t1,t2);}}

static void C_ccall f_8341r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[415]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8371,a[2]=t8,a[3]=t11,a[4]=((C_word)li199),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8377,a[2]=t11,a[3]=((C_word)li200),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t13,t14);}
else{
C_trace("##sys#error");
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* a8376 in process-wait in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8377,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
C_trace("posixunix.scm: 2166 posix-error");
t6=lf[3];
f_3495(6,t6,t1,lf[196],lf[415],lf[416],((C_word*)t0)[2]);}
else{
C_trace("posixunix.scm: 2167 values");
C_values(5,0,t1,t2,t3,t4);}}

/* a8370 in process-wait in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8371,2,t0,t1);}
C_trace("posixunix.scm: 2164 ##sys#process-wait");
t2=*((C_word*)lf[414]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8324,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
C_trace("posixunix.scm: 2151 values");
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8142(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_8142r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8142r(t0,t1,t2,t3);}}

static void C_ccall f_8142r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li194),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8271,a[2]=t4,a[3]=((C_word)li195),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8276,a[2]=t5,a[3]=((C_word)li196),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("def-arglist26042676");
t7=t6;
f_8276(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
C_trace("def-envlist26052672");
t9=t5;
f_8271(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("body26022611");
t11=t4;
f_8144(t11,t1,t7,t9);}
else{
C_trace("##sys#error");
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist2604 in process-execute in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8276,NULL,2,t0,t1);}
C_trace("def-envlist26052672");
t2=((C_word*)t0)[2];
f_8271(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist2605 in process-execute in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8271(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8271,NULL,3,t0,t1,t2);}
C_trace("body26022611");
t3=((C_word*)t0)[2];
f_8144(t3,t1,t2,C_SCHEME_FALSE);}

/* body2602 in process-execute in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8144(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8144,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[412]);
t5=(C_word)C_i_check_list_2(t2,lf[412]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8154,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
C_trace("posixunix.scm: 2119 pathname-strip-directory");
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k8152 in body2602 in process-execute in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8154,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_8104(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8162,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li193),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_8162(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* doloop2617 in k8152 in body2602 in process-execute in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8162(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8162,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_8104(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8175,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[412]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8208,a[2]=((C_word*)t0)[3],a[3]=((C_word)li192),tmp=(C_word)a,a+=4,tmp);
t8=t5;
f_8175(t8,f_8208(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_8175(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[412]);
t6=(C_word)C_block_size(t4);
t7=f_8104(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* doloop2630 in doloop2617 in k8152 in body2602 in process-execute in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall f_8208(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_8123(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[412]);
t5=(C_word)C_block_size(t3);
t6=f_8123(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k8173 in doloop2617 in k8152 in body2602 in process-execute in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_8175(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8175,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8200,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 2133 ##sys#expand-home-path");
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8198 in k8173 in doloop2617 in k8152 in body2602 in process-execute in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2133 ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8176 in k8173 in doloop2617 in k8152 in body2602 in process-execute in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub2567(C_SCHEME_UNDEFINED);
t5=(C_word)stub2582(C_SCHEME_UNDEFINED);
C_trace("posixunix.scm: 2140 posix-error");
t6=lf[3];
f_3495(6,t6,((C_word*)t0)[3],lf[196],lf[412],lf[413],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall f_8123(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub2573(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall f_8104(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub2558(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8062(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_8062r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_8062r(t0,t1,t2);}}

static void C_ccall f_8062r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub2526(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
C_trace("posixunix.scm: 2104 posix-error");
t5=lf[3];
f_3495(5,t5,t1,lf[196],lf[409],lf[410]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8084,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_vector_ref(t2,C_fix(0));
t9=t8;
((C_proc2)C_retrieve_proc(t9))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k8082 in process-fork in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8088,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_8088 in k8082 in process-fork in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8088,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2544(C_SCHEME_UNDEFINED,t3));}

/* glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_7950r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7950r(t0,t1,t2);}}

static void C_ccall f_7950r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li186),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_7956(t6,t1,t2);}

/* conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_7956(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7956,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7971,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li183),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li185),tmp=(C_word)a,a+=11,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t4,t5);}}

/* a7976 in conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7977,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8054,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[408]);
C_trace("posixunix.scm: 2088 make-pathname");
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k8052 in a7976 in conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 2088 glob->regexp");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7979 in a7976 in conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("posixunix.scm: 2089 make-anchored-pattern");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k7982 in k7979 in a7976 in conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("posixunix.scm: 2090 regexp");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k7985 in k7982 in k7979 in a7976 in conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7994,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[407]);
C_trace("posixunix.scm: 2091 directory");
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k7992 in k7985 in k7982 in k7979 in a7976 in conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7994,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li184),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_7996(t5,((C_word*)t0)[2],t1);}

/* loop in k7992 in k7985 in k7982 in k7979 in a7976 in conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_7996(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7996,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
C_trace("posixunix.scm: 2092 conc-loop");
t4=((C_word*)((C_word*)t0)[7])[1];
f_7956(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8013,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
C_trace("posixunix.scm: 2093 string-match");
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k8011 in loop in k7992 in k7985 in k7982 in k7979 in a7976 in conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8013,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8023,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
C_trace("posixunix.scm: 2094 make-pathname");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("posixunix.scm: 2095 loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_7996(t3,((C_word*)t0)[6],t2);}}

/* k8021 in k8011 in loop in k7992 in k7985 in k7982 in k7979 in a7976 in conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8027,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("posixunix.scm: 2094 loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_7996(t4,t2,t3);}

/* k8025 in k8021 in k8011 in loop in k7992 in k7985 in k7982 in k7979 in a7976 in conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_8027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8027,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a7970 in conc-loop in glob in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7971,2,t0,t1);}
C_trace("posixunix.scm: 2087 decompose-pathname");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7942,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub2433(t3),C_fix(0));}

/* k7940 in get-host-name in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7945,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7945(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 2068 posix-error");
t3=lf[3];
f_3495(5,t3,t2,lf[394],lf[398],lf[399]);}}

/* k7943 in k7940 in get-host-name in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7903,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7907,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 2049 ##sys#terminal-check");
f_7848(t3,lf[393],t2);}

/* k7905 in terminal-size in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7907,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7927,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#make-locative");
t5=*((C_word*)lf[396]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[397]);}

/* k7925 in k7905 in terminal-size in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#make-locative");
t3=*((C_word*)lf[396]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[397]);}

/* k7929 in k7925 in k7905 in terminal-size in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_pointer_argumentp(t3);
t6=(C_word)C_i_foreign_pointer_argumentp(t1);
t7=(C_word)stub2404(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(C_word)C_eqp(C_fix(0),t7);
if(C_truep(t8)){
C_trace("posixunix.scm: 2056 values");
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
C_trace("posixunix.scm: 2057 posix-error");
t9=lf[3];
f_3495(6,t9,((C_word*)t0)[4],lf[394],lf[393],lf[395],((C_word*)t0)[6]);}}

/* terminal-name in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7880,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7884,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 2041 ##sys#terminal-check");
f_7848(t3,lf[392],t2);}

/* k7882 in terminal-name in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7884,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub2389(t4,t5);
C_trace("##sys#peek-nonnull-c-string");
t7=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* ##sys#terminal-check in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_7848(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7848,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7852,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 2033 ##sys#check-port");
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k7850 in ##sys#terminal-check in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[149],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 2036 ##sys#error");
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[391],((C_word*)t0)[4]);}}

/* terminal-port? in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7829(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7829,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7833,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 2028 ##sys#check-port");
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[389]);}

/* k7831 in terminal-port? in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 2029 ##sys#peek-unsigned-integer");
t3=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k7834 in k7831 in terminal-port? in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_7770r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_7770r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7770r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7774,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 2013 ##sys#check-port");
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[383]);}

/* k7772 in set-buffering-mode! in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7774,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[385]);
if(C_truep(t6)){
t7=t5;
f_7780(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[386]);
if(C_truep(t7)){
t8=t5;
f_7780(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[387]);
if(C_truep(t8)){
t9=t5;
f_7780(2,t9,C_fix((C_word)_IONBF));}
else{
C_trace("posixunix.scm: 2019 ##sys#error");
t9=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[383],lf[388],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k7778 in k7772 in set-buffering-mode! in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[383]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[149],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
C_trace("posixunix.scm: 2025 ##sys#error");
t6=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[383],lf[384],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7763,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2339(C_SCHEME_UNDEFINED,t3));}

/* _exit in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7747(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7747r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7747r(t0,t1,t2);}}

static void C_ccall f_7747r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub2330(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7735,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub2322(t2),C_fix(0));}

/* utc-time->seconds in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7707,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[377]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7714,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
C_trace("posixunix.scm: 1981 ##sys#error");
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[377],lf[379],t2);}
else{
t6=t4;
f_7714(2,t6,C_SCHEME_UNDEFINED);}}

/* k7712 in utc-time->seconds in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
C_trace("posixunix.scm: 1983 ##sys#cons-flonum");
t2=*((C_word*)lf[374]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
C_trace("posixunix.scm: 1984 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[377],lf[378],((C_word*)t0)[3]);}}

/* local-time->seconds in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7679,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[373]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7686,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
C_trace("posixunix.scm: 1974 ##sys#error");
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[373],lf[376],t2);}
else{
t6=t4;
f_7686(2,t6,C_SCHEME_UNDEFINED);}}

/* k7684 in local-time->seconds in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
C_trace("posixunix.scm: 1976 ##sys#cons-flonum");
t2=*((C_word*)lf[374]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
C_trace("posixunix.scm: 1977 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[373],lf[375],((C_word*)t0)[3]);}}

/* string->time in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7633(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7633r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7633r(t0,t1,t2,t3);}}

static void C_ccall f_7633r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7637,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7637(2,t5,lf[372]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7637(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7635 in string->time in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7637,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[371]);
t3=(C_word)C_i_check_string_2(t1,lf[371]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7650,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1970 ##sys#make-c-string");
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* k7648 in k7635 in string->time in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7654,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1970 ##sys#make-c-string");
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7652 in k7648 in k7635 in string->time in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7654,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub2277(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7551(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7551r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7551r(t0,t1,t2,t3);}}

static void C_ccall f_7551r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7555,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7555(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7555(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7553 in time->string in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7555,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[3],lf[367]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(10)))){
C_trace("posixunix.scm: 1954 ##sys#error");
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[367],lf[370],((C_word*)t0)[3]);}
else{
t5=t3;
f_7561(2,t5,C_SCHEME_UNDEFINED);}}

/* k7559 in k7553 in time->string in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7561,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[367]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7580,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1958 ##sys#make-c-string");
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub2224(t4,t3),C_fix(0));}}

/* k7581 in k7559 in k7553 in time->string in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
C_trace("posixunix.scm: 1962 ##sys#substring");
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
C_trace("posixunix.scm: 1963 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[367],lf[369],((C_word*)t0)[2]);}}

/* k7578 in k7559 in k7553 in time->string in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7580,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub2232(t3,t2,t1),C_fix(0));}

/* k7568 in k7559 in k7553 in time->string in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
C_trace("posixunix.scm: 1959 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[367],lf[368],((C_word*)t0)[2]);}}

/* seconds->string in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7518,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7522,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub2209(t5,t6);
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k7520 in seconds->string in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
C_trace("posixunix.scm: 1946 ##sys#substring");
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
C_trace("posixunix.scm: 1947 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[365],lf[366],((C_word*)t0)[2]);}}

/* seconds->utc-time in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7499,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[364]);
C_trace("posixunix.scm: 1939 ##sys#decode-seconds");
t4=*((C_word*)lf[363]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7490(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7490,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[362]);
C_trace("posixunix.scm: 1935 ##sys#decode-seconds");
t4=*((C_word*)lf[363]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* memory-mapped-file? in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7484,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[353]));}

/* memory-mapped-file-pointer in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7475,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[353],lf[360]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7440(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7440r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7440r(t0,t1,t2,t3);}}

static void C_ccall f_7440r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_i_check_structure_2(t2,lf[353],lf[358]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub2170(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 1922 posix-error");
t12=lf[3];
f_3495(7,t12,t1,lf[48],lf[358],lf[359],t2,t6);}}

/* map-file-to-memory in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_7378r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_7378r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_7378r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7382,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_7382(2,t10,t2);}
else{
C_trace("posixunix.scm: 1907 ##sys#null-pointer");
t10=*((C_word*)lf[357]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k7380 in map-file-to-memory in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7382,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7388,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_7388(2,t6,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 1910 ##sys#signal-hook");
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[60],lf[352],lf[356],t1);}}

/* k7386 in k7380 in map-file-to-memory in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7388,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub2131(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7394,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
C_trace("posixunix.scm: 1912 ##sys#pointer->address");
t17=*((C_word*)lf[355]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,t14);}

/* k7405 in k7386 in k7380 in map-file-to-memory in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
C_trace("posixunix.scm: 1913 posix-error");
t3=lf[3];
f_3495(11,t3,((C_word*)t0)[8],lf[48],lf[352],lf[354],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_7394(2,t3,C_SCHEME_UNDEFINED);}}

/* k7392 in k7386 in k7380 in map-file-to-memory in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7394,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[353],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* current-environment in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7275,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7281,a[2]=t3,a[3]=((C_word)li161),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7281(t5,t1,C_fix(0));}

/* loop in current-environment in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_7281(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7281,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7285,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub2079(t5,t6);
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k7283 in loop in current-environment in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7285,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7293,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li160),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_7293(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k7283 in loop in current-environment in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_7293(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7293,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7319,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("posixunix.scm: 1874 ##sys#substring");
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
C_trace("posixunix.scm: 1877 scan");
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k7317 in scan in k7283 in loop in current-environment in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7323,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
C_trace("posixunix.scm: 1875 ##sys#substring");
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k7321 in k7317 in scan in k7283 in loop in current-environment in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7323,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7311,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
C_trace("posixunix.scm: 1876 loop");
t5=((C_word*)((C_word*)t0)[2])[1];
f_7281(t5,t3,t4);}

/* k7309 in k7321 in k7317 in scan in k7283 in loop in current-environment in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7311,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7255,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[341]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7263,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1863 ##sys#make-c-string");
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7261 in unsetenv in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7238,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[340]);
t5=(C_word)C_i_check_string_2(t3,lf[340]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7249,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1858 ##sys#make-c-string");
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k7247 in setenv in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7253,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1858 ##sys#make-c-string");
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7251 in k7247 in setenv in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7212(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7212,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[338]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7219,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7236,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1847 ##sys#expand-home-path");
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k7234 in fifo? in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1847 ##sys#file-info");
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7217 in fifo? in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
C_trace("posixunix.scm: 1850 posix-error");
t2=lf[3];
f_3495(6,t2,((C_word*)t0)[3],lf[48],lf[338],lf[339],((C_word*)t0)[2]);}}

/* create-fifo in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7169(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7169r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7169r(t0,t1,t2,t3);}}

static void C_ccall f_7169r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[336]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7176,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_7176(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_7176(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k7174 in create-fifo in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_7176(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7176,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[336]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7197,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1841 ##sys#expand-home-path");
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k7195 in k7174 in create-fifo in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1841 ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7191 in k7174 in create-fifo in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
C_trace("posixunix.scm: 1842 posix-error");
t3=lf[3];
f_3495(7,t3,((C_word*)t0)[3],lf[48],lf[336],lf[337],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7141,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[327],lf[334]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
C_trace("posixunix.scm: 1831 posix-error");
t9=lf[3];
f_3495(6,t9,t1,lf[48],lf[334],lf[335],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7119(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7119r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7119r(t0,t1,t2,t3);}}

static void C_ccall f_7119r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7123,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1822 setup");
f_6997(t4,t2,t3,lf[332]);}

/* k7121 in file-test-lock in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
C_trace("posixunix.scm: 1824 err");
f_7071(((C_word*)t0)[3],lf[333],t1,lf[332]);}}

/* file-lock/blocking in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7104(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7104r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7104r(t0,t1,t2,t3);}}

static void C_ccall f_7104r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7108,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1816 setup");
f_6997(t4,t2,t3,lf[330]);}

/* k7106 in file-lock/blocking in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
C_trace("posixunix.scm: 1818 err");
f_7071(((C_word*)t0)[2],lf[331],t1,lf[330]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7089r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7089r(t0,t1,t2,t3);}}

static void C_ccall f_7089r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7093,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1810 setup");
f_6997(t4,t2,t3,lf[328]);}

/* k7091 in file-lock in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
C_trace("posixunix.scm: 1812 err");
f_7071(((C_word*)t0)[2],lf[329],t1,lf[328]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_7071(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7071,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
C_trace("posixunix.scm: 1807 posix-error");
t8=lf[3];
f_3495(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6997(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6997,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7019,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
C_trace("posixunix.scm: 1799 ##sys#check-port");
t16=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
C_trace("##sys#error");
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k7017 in setup in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7019,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_7025(t6,t5);}
else{
t5=t3;
f_7025(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k7023 in k7017 in setup in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_7025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7025,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[327],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6958,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[324]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6975,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6982,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6986,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1782 ##sys#expand-home-path");
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_6975(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
C_trace("posixunix.scm: 1784 ##sys#error");
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[324],lf[326],t2);}}}

/* k6984 in file-truncate in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1782 ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6980 in file-truncate in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6975(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k6973 in file-truncate in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
C_trace("posixunix.scm: 1786 posix-error");
t2=lf[3];
f_3495(7,t2,((C_word*)t0)[4],lf[48],lf[324],lf[325],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_6699r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6699r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6699r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li144),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6885,a[2]=t6,a[3]=((C_word)li145),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6890,a[2]=t7,a[3]=((C_word)li146),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6895,a[2]=t8,a[3]=((C_word)li147),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
C_trace("def-nonblocking?18491944");
t10=t9;
f_6895(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("def-bufi18501940");
t12=t8;
f_6890(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
C_trace("def-on-close18511935");
t14=t7;
f_6885(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
C_trace("body18471857");
t16=t6;
f_6701(t16,t1,t10,t12,t14);}
else{
C_trace("##sys#error");
t16=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-nonblocking?1849 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6895,NULL,2,t0,t1);}
C_trace("def-bufi18501940");
t2=((C_word*)t0)[2];
f_6890(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1850 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6890(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6890,NULL,3,t0,t1,t2);}
C_trace("def-on-close18511935");
t3=((C_word*)t0)[2];
f_6885(t3,t1,t2,C_fix(0));}

/* def-on-close1851 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6885(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6885,NULL,4,t0,t1,t2,t3);}
C_trace("body18471857");
t4=((C_word*)t0)[2];
f_6701(t4,t1,t2,t3,*((C_word*)lf[319]+1));}

/* body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6701(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6701,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6705,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
C_trace("posixunix.scm: 1724 ##sys#file-nonblocking!");
t6=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_6705(2,t6,C_SCHEME_UNDEFINED);}}

/* k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6705,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6707,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word)li137),tmp=(C_word)a,a+=7,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_6753(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6797,a[2]=t3,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6811,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
C_trace("posixunix.scm: 1743 ##sys#make-string");
t12=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_6811(2,t12,((C_word*)t0)[6]);}}}

/* k6809 in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6811,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_6753(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6812,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li143),tmp=(C_word)a,a+=7,tmp));}

/* f_6812 in k6809 in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6812,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6829,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word)li142),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6829(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
C_trace("posixunix.scm: 1759 poke");
t3=((C_word*)((C_word*)t0)[3])[1];
f_6707(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_6829(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6829,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6839,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("posixunix.scm: 1749 poke");
t7=((C_word*)((C_word*)t0)[4])[1];
f_6707(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_difference(t4,t2);
C_trace("posixunix.scm: 1754 loop");
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k6837 in loop */
static void C_ccall f_6839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
C_trace("posixunix.scm: 1751 loop");
t3=((C_word*)((C_word*)t0)[5])[1];
f_6829(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_6797 in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6797,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
C_trace("posixunix.scm: 1742 poke");
t4=((C_word*)((C_word*)t0)[2])[1];
f_6707(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6751 in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6753,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6757,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6762,a[2]=((C_word*)t0)[9],a[3]=((C_word)li138),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6768,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li139),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6789,a[2]=((C_word*)t0)[9],a[3]=((C_word)li140),tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1762 make-output-port");
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t5,t6,t7,t8);}

/* a6788 in k6751 in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6789,2,t0,t1);}
C_trace("posixunix.scm: 1772 store");
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* a6767 in k6751 in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6768,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6778,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
C_trace("posixunix.scm: 1769 posix-error");
t3=lf[3];
f_3495(7,t3,t2,lf[48],((C_word*)t0)[3],lf[323],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6778(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6776 in a6767 in k6751 in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1770 on-close");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6761 in k6751 in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6762,3,t0,t1,t2);}
C_trace("posixunix.scm: 1764 store");
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* k6755 in k6751 in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6757,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6760,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1773 set-port-name!");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6758 in k6755 in k6751 in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6707(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6707,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6723,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 1732 ##sys#thread-yield!");
t8=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
C_trace("posixunix.scm: 1734 posix-error");
t7=lf[3];
f_3495(7,t7,t1,((C_word*)t0)[3],lf[48],lf[322],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6742,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 1736 ##sys#substring");
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6740 in poke in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
C_trace("posixunix.scm: 1736 poke");
t3=((C_word*)((C_word*)t0)[3])[1];
f_6707(t3,((C_word*)t0)[2],t1,t2);}

/* k6721 in poke in k6703 in body1847 in ##sys#custom-output-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1733 poke");
t2=((C_word*)((C_word*)t0)[5])[1];
f_6707(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_6225r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6225r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6225r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,a[7]=((C_word)li131),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6606,a[2]=t6,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6611,a[2]=t7,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6616,a[2]=t8,a[3]=((C_word)li134),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6621,a[2]=t9,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
C_trace("def-nonblocking?16031808");
t11=t10;
f_6621(t11,t1);}
else{
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t12))){
C_trace("def-bufi16041804");
t13=t9;
f_6616(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
C_trace("def-on-close16051799");
t15=t8;
f_6611(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
C_trace("def-more?16061793");
t17=t7;
f_6606(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
C_trace("body16011612");
t19=t6;
f_6227(t19,t1,t11,t13,t15,t17);}
else{
C_trace("##sys#error");
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[0],t18);}}}}}}

/* def-nonblocking?1603 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6621,NULL,2,t0,t1);}
C_trace("def-bufi16041804");
t2=((C_word*)t0)[2];
f_6616(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1604 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6616,NULL,3,t0,t1,t2);}
C_trace("def-on-close16051799");
t3=((C_word*)t0)[2];
f_6611(t3,t1,t2,C_fix(1));}

/* def-on-close1605 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6611(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6611,NULL,4,t0,t1,t2,t3);}
C_trace("def-more?16061793");
t4=((C_word*)t0)[2];
f_6606(t4,t1,t2,t3,*((C_word*)lf[319]+1));}

/* def-more?1606 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6606(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6606,NULL,5,t0,t1,t2,t3,t4);}
C_trace("body16011612");
t5=((C_word*)t0)[2];
f_6227(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6227(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6227,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6231,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
C_trace("posixunix.scm: 1602 ##sys#file-nonblocking!");
t7=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_6231(2,t7,C_SCHEME_UNDEFINED);}}

/* k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6231,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
C_trace("posixunix.scm: 1604 ##sys#make-string");
t5=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_6237(2,t5,((C_word*)t0)[10]);}}

/* k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6237,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6238,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li117),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6253,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6261,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,a[10]=((C_word)li119),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6343,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6348,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word)li120),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6361,a[2]=t6,a[3]=t3,a[4]=t5,a[5]=((C_word)li121),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6373,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=((C_word)li122),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6394,a[2]=t8,a[3]=t7,a[4]=((C_word)li123),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6403,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li125),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6479,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,a[6]=((C_word)li130),tmp=(C_word)a,a+=7,tmp);
C_trace("posixunix.scm: 1648 make-input-port");
t18=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t18))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a6478 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6479,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6485,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li129),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_6485(t7,t1,C_SCHEME_FALSE);}

/* loop in a6478 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6485(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6485,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li126),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6565,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word)li127),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6571,a[2]=((C_word*)t0)[2],a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6581,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("posixunix.scm: 1713 fetch");
t5=((C_word*)t0)[5];
f_6261(t5,t4);}}

/* k6579 in loop in a6478 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
C_trace("posixunix.scm: 1715 loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_6485(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a6570 in loop in a6478 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6571,4,t0,t1,t2,t3);}
if(C_truep(t3)){
C_trace("posixunix.scm: 1710 loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_6485(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a6564 in loop in a6478 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6565,2,t0,t1);}
C_trace("posixunix.scm: 1708 ##sys#scan-buffer-line");
t2=*((C_word*)lf[318]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a6478 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6487,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6494,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_6494(2,t8,(C_truep(t7)?t7:lf[315]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6537,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
C_trace("posixunix.scm: 1690 ##sys#make-string");
t8=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k6535 in bumper in loop in a6478 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
C_trace("posixunix.scm: 1696 ##sys#string-append");
t6=*((C_word*)lf[316]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_6494(2,t6,t1);}}

/* k6492 in bumper in loop in a6478 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6494,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6504,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 1700 fetch");
t5=((C_word*)t0)[3];
f_6261(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
C_trace("posixunix.scm: 1705 values");
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k6502 in k6492 in bumper in loop in a6478 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
C_trace("posixunix.scm: 1701 values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a6402 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6403,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6411,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_6411(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_6411(t8,(C_word)C_fixnum_difference(t7,t5));}}

/* k6409 in a6402 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6411,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6413,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li124),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6413(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k6409 in a6402 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6413(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6413,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
C_trace("posixunix.scm: 1676 loop");
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6461,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("posixunix.scm: 1678 fetch");
t7=((C_word*)t0)[2];
f_6261(t7,t6);}}}

/* k6459 in loop in k6409 in a6402 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
C_trace("posixunix.scm: 1681 loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_6413(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a6393 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6398,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1666 fetch");
t3=((C_word*)t0)[2];
f_6261(t3,t2);}

/* k6396 in a6393 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1667 peek");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_6253(((C_word*)t0)[2]));}

/* a6372 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6373,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6383,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
C_trace("posixunix.scm: 1663 posix-error");
t3=lf[3];
f_3495(7,t3,t2,lf[48],((C_word*)t0)[3],lf[314],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6383(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6381 in a6372 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1664 on-close");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6360 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6361,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
C_trace("posixunix.scm: 1658 ready?");
t3=((C_word*)t0)[2];
f_6238(t3,t1);}}

/* a6347 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6352,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1650 fetch");
t3=((C_word*)t0)[2];
f_6261(t3,t2);}

/* k6350 in a6347 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_6253(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k6341 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6343,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6346,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1717 set-port-name!");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6344 in k6341 in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6261,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6273,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li118),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_6273(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6273,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6289,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1625 ##sys#thread-block-for-i/o!");
t6=*((C_word*)lf[310]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[311]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
C_trace("posixunix.scm: 1628 posix-error");
t5=lf[3];
f_3495(7,t5,t1,lf[48],((C_word*)t0)[6],lf[312],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6310,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
C_trace("posixunix.scm: 1632 more?");
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k6308 in loop in fetch in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6310,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6313,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1634 ##sys#thread-yield!");
t3=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6319,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_6319(2,t8,t7);}
else{
C_trace("posixunix.scm: 1640 posix-error");
t7=lf[3];
f_3495(7,t7,t4,lf[48],((C_word*)t0)[3],lf[313],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_6319(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6317 in k6308 in loop in fetch in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6311 in k6308 in loop in fetch in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1635 loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_6273(t2,((C_word*)t0)[2]);}

/* k6287 in loop in fetch in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1626 ##sys#thread-yield!");
t3=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6290 in k6287 in loop in fetch in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1627 loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_6273(t2,((C_word*)t0)[2]);}

/* peek in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall f_6253(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6238,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 1610 ##sys#file-select-one");
t3=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k6250 in ready? in k6235 in k6229 in body1601 in ##sys#custom-input-port in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
C_trace("posixunix.scm: 1611 posix-error");
t3=lf[3];
f_3495(7,t3,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[308],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* duplicate-fileno in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6198r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6198r(t0,t1,t2,t3);}}

static void C_ccall f_6198r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[303]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6205,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_6205(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[303]);
t8=t5;
f_6205(t8,(C_word)C_dup2(t2,t6));}}

/* k6203 in duplicate-fileno in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6205(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6205,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6208,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
C_trace("posixunix.scm: 1595 posix-error");
t3=lf[3];
f_3495(6,t3,t2,lf[48],lf[303],lf[304],((C_word*)t0)[2]);}
else{
t3=t2;
f_6208(2,t3,C_SCHEME_UNDEFINED);}}

/* k6206 in k6203 in duplicate-fileno in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6153(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6153,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6157,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1577 ##sys#check-port");
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[297]);}

/* k6155 in port->fileno in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6157,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[298],t2);
if(C_truep(t3)){
C_trace("posixunix.scm: 1578 ##sys#tcp-port->fileno");
t4=*((C_word*)lf[299]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6192,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1579 ##sys#peek-unsigned-integer");
t5=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k6190 in k6155 in port->fileno in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6192,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
C_trace("posixunix.scm: 1584 posix-error");
t2=lf[3];
f_3495(6,t2,((C_word*)t0)[3],lf[60],lf[297],lf[300],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6175,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
C_trace("posixunix.scm: 1582 posix-error");
t4=lf[3];
f_3495(6,t4,t3,lf[48],lf[297],lf[301],((C_word*)t0)[2]);}
else{
t4=t3;
f_6175(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6173 in k6190 in k6155 in port->fileno in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6139(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6139r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6139r(t0,t1,t2,t3);}}

static void C_ccall f_6139r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[296]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6151,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1573 mode");
f_6073(t5,C_SCHEME_FALSE,t3);}

/* k6149 in open-output-file* in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6151,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
C_trace("posixunix.scm: 1573 check");
f_6110(((C_word*)t0)[2],lf[296],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6125r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6125r(t0,t1,t2,t3);}}

static void C_ccall f_6125r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[295]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6137,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1569 mode");
f_6073(t5,C_SCHEME_TRUE,t3);}

/* k6135 in open-input-file* in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6137,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
C_trace("posixunix.scm: 1569 check");
f_6110(((C_word*)t0)[2],lf[295],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6110(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6110,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
C_trace("posixunix.scm: 1562 posix-error");
t6=lf[3];
f_3495(6,t6,t1,lf[48],t2,lf[293],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6123,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1563 ##sys#make-port");
t7=*((C_word*)lf[146]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[147]+1),lf[294],lf[149]);}}

/* k6121 in check in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_6073(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6073,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6081,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[287]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
C_trace("posixunix.scm: 1556 ##sys#error");
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[288],t5);}
else{
t8=t4;
f_6081(2,t8,lf[289]);}}
else{
C_trace("posixunix.scm: 1557 ##sys#error");
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[290],t5);}}
else{
t5=t4;
f_6081(2,t5,(C_truep(t2)?lf[291]:lf[292]));}}

/* k6079 in mode in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1552 ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6048,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[281]);
t5=(C_word)C_i_check_string_2(t3,lf[281]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6029,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
C_trace("##sys#make-c-string");
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_6029(2,t9,C_SCHEME_FALSE);}}

/* k6027 in file-link in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6033,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
C_trace("##sys#make-c-string");
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_6033(2,t3,C_SCHEME_FALSE);}}

/* k6031 in k6027 in file-link in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1480(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
C_trace("posixunix.scm: 1537 posix-error");
t3=lf[3];
f_3495(7,t3,((C_word*)t0)[4],lf[48],lf[282],lf[283],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5998,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[279]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6006,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6022,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1526 ##sys#expand-home-path");
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k6020 in read-symbolic-link in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1526 ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6004 in read-symbolic-link in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6006,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6009,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
C_trace("posixunix.scm: 1528 posix-error");
t4=lf[3];
f_3495(6,t4,t3,lf[48],lf[279],lf[280],((C_word*)t0)[2]);}
else{
t4=t3;
f_6009(2,t4,C_SCHEME_UNDEFINED);}}

/* k6007 in k6004 in read-symbolic-link in k5995 in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1529 substring");
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5960,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[275]);
t5=(C_word)C_i_check_string_2(t3,lf[275]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5981,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5993,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1514 ##sys#expand-home-path");
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5991 in create-symbolic-link in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1514 ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5979 in create-symbolic-link in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5989,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1515 ##sys#expand-home-path");
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5987 in k5979 in create-symbolic-link in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1515 ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5983 in k5979 in create-symbolic-link in k5956 in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
C_trace("posixunix.scm: 1517 posix-error");
t3=lf[3];
f_3495(7,t3,((C_word*)t0)[4],lf[48],lf[276],lf[277],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* create-session in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5941,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5945,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5951,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1485 ##sys#update-errno");
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5945(2,t4,C_SCHEME_UNDEFINED);}}

/* k5949 in create-session in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1486 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[272],lf[273]);}

/* k5943 in create-session in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5935,3,t0,t1,t2);}
C_trace("posixunix.scm: 1480 check");
f_5899(t1,t2,C_fix((C_word)X_OK),lf[271]);}

/* file-write-access? in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5929,3,t0,t1,t2);}
C_trace("posixunix.scm: 1479 check");
f_5899(t1,t2,C_fix((C_word)W_OK),lf[270]);}

/* file-read-access? in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5923(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5923,3,t0,t1,t2);}
C_trace("posixunix.scm: 1478 check");
f_5899(t1,t2,C_fix((C_word)R_OK),lf[269]);}

/* check in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_5899(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5899,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5917,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5921,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1475 ##sys#expand-home-path");
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5919 in check in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1475 ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5915 in check in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5917,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5909,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5909(2,t5,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 1476 ##sys#update-errno");
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5907 in k5915 in check in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5869,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[267]);
t6=(C_word)C_i_check_exact_2(t3,lf[267]);
t7=(C_word)C_i_check_exact_2(t4,lf[267]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5893,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5897,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1465 ##sys#expand-home-path");
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k5895 in change-file-owner in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1465 ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5891 in change-file-owner in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
C_trace("posixunix.scm: 1466 posix-error");
t3=lf[3];
f_3495(8,t3,((C_word*)t0)[3],lf[48],lf[267],lf[268],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5842,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[265]);
t5=(C_word)C_i_check_exact_2(t3,lf[265]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5863,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5867,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1457 ##sys#expand-home-path");
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5865 in change-file-mode in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1457 ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5861 in change-file-mode in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
C_trace("posixunix.scm: 1458 posix-error");
t3=lf[3];
f_3495(7,t3,((C_word*)t0)[3],lf[48],lf[265],lf[266],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5778,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[224]);
t5=(C_word)C_i_check_exact_2(t3,lf[224]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5766,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
C_trace("##sys#make-c-string");
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5766(2,t9,C_SCHEME_FALSE);}}

/* k5764 in initialize-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5766,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub1305(C_SCHEME_UNDEFINED,t1,t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1378 ##sys#update-errno");
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5792 in k5764 in initialize-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1379 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[224],lf[225],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5704,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5708,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_5634(t4);
if(C_truep(t5)){
t6=t3;
f_5708(2,t6,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 1361 ##sys#error");
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[221],lf[223]);}}

/* k5706 in set-groups! in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5708,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5713,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li98),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5713(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop1279 in k5706 in set-groups! in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_5713(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5713,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5729,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1366 ##sys#update-errno");
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[221]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k5727 in doloop1279 in k5706 in set-groups! in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1367 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[221],lf[222],((C_word*)t0)[2]);}

/* get-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5641,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5645,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5699,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1347 ##sys#update-errno");
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5645(2,t4,C_SCHEME_UNDEFINED);}}

/* k5697 in get-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1348 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[217],lf[220]);}

/* k5643 in get-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_5634(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_5648(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 1350 ##sys#error");
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[217],lf[219]);}}

/* k5646 in k5643 in get-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub1236(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5680,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1352 ##sys#update-errno");
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_5651(2,t5,C_SCHEME_UNDEFINED);}}

/* k5678 in k5646 in k5643 in get-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1353 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[217],lf[218]);}

/* k5649 in k5646 in k5643 in get-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5651,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5656,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li96),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5656(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5649 in k5646 in k5643 in get-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_5656(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5656,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5670,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
C_trace("posixunix.scm: 1357 loop");
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k5668 in loop in k5649 in k5646 in k5643 in get-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5670,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall f_5634(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub1242(C_SCHEME_UNDEFINED,t2));}

/* group-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5548r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5548r(t0,t1,t2,t3);}}

static void C_ccall f_5548r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5552,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5552(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5552(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5550 in group-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5555,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_5555(t3,(C_word)C_getgrgid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[215]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5606,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1321 ##sys#make-c-string");
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5604 in k5550 in group-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5555(t2,(C_word)C_getgrnam(t1));}

/* k5553 in k5550 in group-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_5555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5555,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-nonnull-c-string");
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5563 in k5553 in k5550 in group-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5569,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#peek-nonnull-c-string");
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k5567 in k5563 in k5553 in k5550 in group-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5573,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5578,a[2]=t4,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5578(t6,t2,C_fix(0));}

/* loop in k5567 in k5563 in k5553 in k5550 in group-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_5578(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5578,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5582,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1192(t5,t6);
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k5580 in loop in k5567 in k5563 in k5553 in k5550 in group-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5582,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5592,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
C_trace("posixunix.scm: 1330 loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_5578(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k5590 in k5580 in loop in k5567 in k5563 in k5553 in k5550 in group-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5592,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5571 in k5567 in k5563 in k5553 in k5550 in group-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[212]+1):*((C_word*)lf[213]+1));
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5531,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5535,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1306 current-effective-user-id");
t4=*((C_word*)lf[208]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5533 in current-effective-user-name in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1306 user-information");
t2=*((C_word*)lf[211]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5529 in current-effective-user-name in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5517,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5521,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1303 current-user-id");
t4=*((C_word*)lf[207]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5519 in current-user-name in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1303 user-information");
t2=*((C_word*)lf[211]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5515 in current-user-name in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* user-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5442r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5442r(t0,t1,t2,t3);}}

static void C_ccall f_5442r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5446,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5446(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5446(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5444 in user-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5449,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_5449(t3,(C_word)C_getpwuid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[211]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5488,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1291 ##sys#make-c-string");
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5486 in k5444 in user-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5449(t2,(C_word)C_getpwnam(t1));}

/* k5447 in k5444 in user-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_5449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5449,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-nonnull-c-string");
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5457 in k5447 in k5444 in user-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5463,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#peek-nonnull-c-string");
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k5461 in k5457 in k5447 in k5444 in user-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5467,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#peek-nonnull-c-string");
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k5465 in k5461 in k5457 in k5447 in k5444 in user-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5471,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k5469 in k5465 in k5461 in k5457 in k5447 in k5444 in user-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5475,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k5473 in k5469 in k5465 in k5461 in k5457 in k5447 in k5444 in user-information in k5438 in k5434 in k5430 in k5426 in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[212]+1):*((C_word*)lf[213]+1));
t3=t2;
((C_proc9)C_retrieve_proc(t3))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* system-information in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5392,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5421,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1236 ##sys#update-errno");
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_5392(2,t3,C_SCHEME_UNDEFINED);}}

/* k5419 in system-information in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1237 ##sys#error");
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[204],lf[206]);}

/* k5390 in system-information in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-nonnull-c-string");
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k5397 in k5390 in system-information in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5403,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-nonnull-c-string");
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k5401 in k5397 in k5390 in system-information in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5407,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#peek-nonnull-c-string");
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k5405 in k5401 in k5397 in k5390 in system-information in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5411,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#peek-nonnull-c-string");
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k5409 in k5405 in k5401 in k5397 in k5390 in system-information in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5415,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("##sys#peek-nonnull-c-string");
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k5413 in k5409 in k5405 in k5401 in k5397 in k5390 in system-information in k5384 in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5415,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5370,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[202]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
C_trace("posixunix.scm: 1215 posix-error");
t5=lf[3];
f_3495(5,t5,t1,lf[196],lf[202],lf[203]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5355,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[200]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
C_trace("posixunix.scm: 1209 posix-error");
t5=lf[3];
f_3495(5,t5,t1,lf[196],lf[200],lf[201]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5349,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[199]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5317,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5323,a[2]=t3,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5323(t5,t1,*((C_word*)lf[191]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_5323(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5323,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
C_trace("posixunix.scm: 1199 loop");
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5293,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[195]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5300,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5311,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5310 in set-signal-mask! in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5311,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[195]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k5298 in set-signal-mask! in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
C_trace("posixunix.scm: 1192 posix-error");
t2=lf[3];
f_3495(5,t2,((C_word*)t0)[2],lf[196],lf[195],lf[197]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5275,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5285,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1178 h");
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
C_trace("posixunix.scm: 1180 oldhook");
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k5283 in ##sys#interrupt-hook in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1179 ##sys#context-switch");
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5262,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[194]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k5249 in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5253,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[193]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5210,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
C_trace("posixunix.scm: 1095 posix-error");
t3=lf[3];
f_3495(5,t3,t2,lf[48],lf[164],lf[165]);}
else{
t3=t2;
f_5210(2,t3,C_SCHEME_UNDEFINED);}}

/* k5208 in create-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1096 values");
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5186r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5186r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[163]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5190,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5188 in with-output-to-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5190,2,t0,t1);}
t2=C_mutate((C_word*)lf[163]+1 /* standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5196,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li76),tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 1083 ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5195 in k5188 in with-output-to-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5196r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5196r(t0,t1,t2);}}

static void C_ccall f_5196r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5200,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1085 close-output-pipe");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5198 in a5195 in k5188 in with-output-to-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[163]+1 /* standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5166r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5166r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5166r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[161]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5170,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5168 in with-input-from-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5170,2,t0,t1);}
t2=C_mutate((C_word*)lf[161]+1 /* standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5176,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 1073 ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5175 in k5168 in with-input-from-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5176r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5176r(t0,t1,t2);}}

static void C_ccall f_5176r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5180,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1075 close-input-pipe");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5178 in a5175 in k5168 in with-input-from-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[161]+1 /* standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5142r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5142r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5142r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5146,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5144 in call-with-output-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5151,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5157,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1063 ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5156 in k5144 in call-with-output-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5157(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5157r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5157r(t0,t1,t2);}}

static void C_ccall f_5157r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5161,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1066 close-output-pipe");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5159 in a5156 in k5144 in call-with-output-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5150 in k5144 in call-with-output-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5151,2,t0,t1);}
C_trace("posixunix.scm: 1064 proc");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5118r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5118r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5118r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5122,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5120 in call-with-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5127,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5133,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 1055 ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5132 in k5120 in call-with-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5133(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5133r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5133r(t0,t1,t2);}}

static void C_ccall f_5133r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5137,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1058 close-input-pipe");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5135 in a5132 in k5120 in call-with-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5126 in k5120 in call-with-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5127,2,t0,t1);}
C_trace("posixunix.scm: 1056 proc");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5102,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5106,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1042 ##sys#check-port");
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[153]);}

/* k5104 in close-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5109,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
C_trace("posixunix.scm: 1044 posix-error");
t5=lf[3];
f_3495(6,t5,t3,lf[48],lf[154],lf[155],((C_word*)t0)[3]);}
else{
t5=t3;
f_5109(2,t5,C_SCHEME_UNDEFINED);}}

/* k5107 in k5104 in close-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_5066r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5066r(t0,t1,t2,t3);}}

static void C_ccall f_5066r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[152]);
t5=f_4997(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5080,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5087,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1037 ##sys#make-c-string");
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5097,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1038 ##sys#make-c-string");
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
C_trace("posixunix.scm: 1039 badmode");
f_5009(t6,t5);}}}

/* k5095 in open-output-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5097,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5080(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k5085 in open-output-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5087,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5080(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k5078 in open-output-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1033 check");
f_5015(((C_word*)t0)[3],lf[152],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_5030r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5030r(t0,t1,t2,t3);}}

static void C_ccall f_5030r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[150]);
t5=f_4997(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5044,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5051,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1026 ##sys#make-c-string");
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5061,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 1027 ##sys#make-c-string");
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
C_trace("posixunix.scm: 1028 badmode");
f_5009(t6,t5);}}}

/* k5059 in open-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5061,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5044(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k5049 in open-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5051,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5044(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k5042 in open-input-pipe in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 1022 check");
f_5015(((C_word*)t0)[3],lf[150],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_5015(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5015,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
C_trace("posixunix.scm: 1014 posix-error");
t6=lf[3];
f_3495(6,t6,t1,lf[48],t2,lf[145],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5028,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 1015 ##sys#make-port");
t7=*((C_word*)lf[146]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[147]+1),lf[148],lf[149]);}}

/* k5026 in check in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_5009(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5009,NULL,2,t1,t2);}
C_trace("posixunix.scm: 1011 ##sys#error");
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[144],t2);}

/* mode in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall f_4997(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[143]));}

/* canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4680,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4687,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4801,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 959  cwd");
t8=((C_word*)t0)[6];
f_4624(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4987,a[2]=((C_word*)t0)[12],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 961  sref");
t10=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_4807(t9,C_SCHEME_FALSE);}}}

/* k4985 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 961  sep?");
t2=((C_word*)t0)[3];
f_4807(t2,f_4613(t1));}

/* k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4807,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
f_4687(2,t2,((C_word*)t0)[10]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4820,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 964  cwd");
t5=((C_word*)t0)[8];
f_4624(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4962,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4973,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 965  sref");
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k4971 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 965  char=?");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k4960 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4969,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 966  sref");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4826(t2,C_SCHEME_FALSE);}}

/* k4967 in k4960 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 966  sep?");
t2=((C_word*)t0)[3];
f_4826(t2,f_4613(t1));}

/* k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4826(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4826,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4833,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 968  getenv");
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[140]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 973  cwd");
t5=((C_word*)t0)[6];
f_4624(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4955,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 974  sref");
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(0));}}}

/* k4953 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 974  alpha?");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4932 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4934,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4940,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4951,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 975  sref");
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_4870(t2,C_SCHEME_FALSE);}}

/* k4949 in k4932 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 975  char=?");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4938 in k4932 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4940,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4947,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 976  sref");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_4870(t2,C_SCHEME_FALSE);}}

/* k4945 in k4938 in k4932 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 976  sep?");
t2=((C_word*)t0)[3];
f_4870(t2,f_4613(t1));}

/* k4868 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4870,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
C_trace("posixunix.scm: 977  ##sys#substring");
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)t0)[9],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4931,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 978  sref");
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[9],C_fix(0));}}

/* k4929 in k4868 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 978  char=?");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k4908 in k4868 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4927,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 979  sref");
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4883(2,t2,C_SCHEME_FALSE);}}

/* k4925 in k4908 in k4868 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 979  alpha?");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4914 in k4908 in k4868 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4916,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4923,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 980  sref");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_4883(2,t2,C_SCHEME_FALSE);}}

/* k4921 in k4914 in k4908 in k4868 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 980  char=?");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4881 in k4868 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4883,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
C_trace("posixunix.scm: 981  ##sys#substring");
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("posixunix.scm: 982  sref");
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],C_fix(0));}}

/* k4905 in k4881 in k4868 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4907,2,t0,t1);}
t2=f_4613(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_4687(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4903,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("posixunix.scm: 985  cwd");
t4=((C_word*)t0)[2];
f_4624(t4,t3);}}

/* k4901 in k4905 in k4881 in k4868 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 985  sappend");
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[142],((C_word*)t0)[2]);}

/* k4862 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 973  sappend");
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[141],((C_word*)t0)[2]);}

/* k4831 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4836(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4851,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 969  user");
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k4849 in k4831 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 969  sappend");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[139],t1);}

/* k4834 in k4831 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4840,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
C_trace("posixunix.scm: 970  ##sys#substring");
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k4838 in k4834 in k4831 in k4824 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 967  sappend");
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4818 in k4805 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 964  sappend");
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[138],((C_word*)t0)[2]);}

/* k4799 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 959  sappend");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[137]);}

/* k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=t1;
C_trace("string-split");
t4=*((C_word*)lf[101]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,lf[136]);}

/* k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4694,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4696,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li60),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_4696(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4696(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4696,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
C_trace("posixunix.scm: 988  null?");
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4701 in loop in k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4703,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
C_trace("posixunix.scm: 989  null?");
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4764,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("posixunix.scm: 1000 string=?");
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[135],t5);}}

/* k4765 in k4701 in loop in k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4767,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4764(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("posixunix.scm: 1002 string=?");
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[134],t3);}}

/* k4774 in k4765 in k4701 in loop in k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4776,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4764(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_4764(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k4762 in k4701 in loop in k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 998  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_4696(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4707 in k4701 in loop in k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4709,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[129]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
C_trace("posixunix.scm: 991  sref");
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k4743 in k4707 in k4701 in loop in k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4745,2,t0,t1);}
t2=f_4613(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4722,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4726,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[131],((C_word*)t0)[2]);
C_trace("posixunix.scm: 994  reverse");
t6=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4737,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4741,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 997  reverse");
t5=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4739 in k4743 in k4707 in k4701 in loop in k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 997  isperse");
f_4608(((C_word*)t0)[2],t1);}

/* k4735 in k4743 in k4707 in k4701 in loop in k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 995  sappend");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[133],t1);}

/* k4724 in k4743 in k4707 in k4701 in loop in k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 994  isperse");
f_4608(((C_word*)t0)[2],t1);}

/* k4720 in k4743 in k4707 in k4701 in loop in k4692 in k4685 in canonical-path in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 992  sappend");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[130],t1);}

/* cwd in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4624,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4631,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[2],a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
C_trace("call-with-current-continuation");
t4=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a4632 in cwd in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4633,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4639,a[2]=t2,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4657,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4656 in a4632 in cwd in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4663,a[2]=((C_word*)t0)[3],a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[2],a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a4668 in a4656 in a4632 in cwd in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4669r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4669r(t0,t1,t2);}}

static void C_ccall f_4669r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4675,a[2]=t2,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
C_trace("k789795");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4674 in a4668 in a4656 in a4632 in cwd in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4662 in a4656 in a4632 in cwd in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
C_trace("posixunix.scm: 954  cw");
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a4638 in a4632 in cwd in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4639,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4645,a[2]=t2,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
C_trace("k789795");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4644 in a4638 in a4632 in cwd in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[125]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[126]);}

/* k4629 in cwd in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* sep? in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall f_4613(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4608(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4608,NULL,2,t1,t2);}
C_trace("string-intersperse");
t3=*((C_word*)lf[121]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[122]);}

/* current-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4560r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4560r(t0,t1,t2);}}

static void C_ccall f_4560r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4564,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4564(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4564(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4562 in current-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4564,2,t0,t1);}
if(C_truep(t1)){
C_trace("posixunix.scm: 932  change-directory");
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 933  make-string");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k4571 in k4562 in current-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
C_trace("posixunix.scm: 936  ##sys#substring");
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
C_trace("posixunix.scm: 937  posix-error");
t3=lf[3];
f_3495(5,t3,((C_word*)t0)[2],lf[48],lf[113],lf[116]);}}

/* directory? in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4537,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[114]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4544,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4558,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 925  ##sys#expand-home-path");
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4556 in directory? in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 925  ##sys#file-info");
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4542 in directory? in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_4380r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4380r(t0,t1,t2);}}

static void C_ccall f_4380r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4480,a[2]=t3,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4485,a[2]=t4,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("def-spec635694");
t6=t5;
f_4485(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
C_trace("def-show-dotfiles?636690");
t8=t4;
f_4480(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("body633642");
t10=t3;
f_4382(t10,t1,t6,t8);}
else{
C_trace("##sys#error");
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec635 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4485(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4485,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4493,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 898  current-directory");
t3=*((C_word*)lf[113]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4491 in def-spec635 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("def-show-dotfiles?636690");
t2=((C_word*)t0)[3];
f_4480(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?636 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4480(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4480,NULL,3,t0,t1,t2);}
C_trace("body633642");
t3=((C_word*)t0)[2];
f_4382(t3,t1,t2,C_SCHEME_FALSE);}

/* body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4382(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4382,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[110]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4389,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("posixunix.scm: 900  make-string");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k4387 in body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("posixunix.scm: 901  ##sys#make-pointer");
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4390 in k4387 in body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("posixunix.scm: 902  ##sys#make-pointer");
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4393 in k4390 in k4387 in body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4479,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 903  ##sys#expand-home-path");
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k4477 in k4393 in k4390 in k4387 in body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 903  ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4397 in k4393 in k4390 in k4387 in body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
C_trace("posixunix.scm: 905  posix-error");
t3=lf[3];
f_3495(6,t3,((C_word*)t0)[7],lf[48],lf[110],lf[111],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word)li43),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_4413(t6,((C_word*)t0)[7]);}}

/* loop in k4397 in k4393 in k4390 in k4387 in body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4413(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4413,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("posixunix.scm: 913  ##sys#substring");
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k4421 in loop in k4397 in k4393 in k4390 in k4387 in body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("posixunix.scm: 914  string-ref");
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_fix(0));}

/* k4424 in k4421 in loop in k4397 in k4393 in k4390 in k4387 in body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4429,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
C_trace("posixunix.scm: 915  string-ref");
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_4429(2,t3,C_SCHEME_FALSE);}}

/* k4427 in k4424 in k4421 in loop in k4397 in k4393 in k4390 in k4387 in body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4435,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_4435(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_4435(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_4435(t4,C_SCHEME_FALSE);}}

/* k4433 in k4427 in k4424 in k4421 in loop in k4397 in k4393 in k4390 in k4387 in body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4435,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("posixunix.scm: 920  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_4413(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 921  loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_4413(t3,t2);}}

/* k4443 in k4433 in k4427 in k4424 in k4421 in loop in k4397 in k4393 in k4390 in k4387 in body633 in directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4356,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[106]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4374,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4378,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 891  ##sys#expand-home-path");
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4376 in delete-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 891  ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4372 in delete-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 892  posix-error");
t3=lf[3];
f_3495(6,t3,((C_word*)t0)[3],lf[48],lf[106],lf[107],((C_word*)t0)[2]);}}

/* change-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4332,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[104]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4350,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4354,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 885  ##sys#expand-home-path");
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4352 in change-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 885  ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4348 in change-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 886  posix-error");
t3=lf[3];
f_3495(6,t3,((C_word*)t0)[3],lf[48],lf[104],lf[105],((C_word*)t0)[2]);}}

/* create-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4197r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4197r(t0,t1,t2,t3);}}

static void C_ccall f_4197r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4201,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4201(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4201(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4199 in create-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[94]);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4214,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 877  canonical-path");
t4=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4295,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 878  canonical-path");
t4=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}

/* k4293 in k4199 in create-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4296,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4296 in k4293 in k4199 in create-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4296,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4311,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 847  ##sys#make-c-string");
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4309 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 848  posix-error");
t3=lf[3];
f_3495(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[96],((C_word*)t0)[2]);}}

/* k4212 in k4199 in create-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4215,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4215 in k4212 in k4199 in create-directory in k4193 in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4215,3,t0,t1,t2);}
t3=lf[95];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4221,a[2]=t4,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4288,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 871  string-split");
t7=*((C_word*)lf[101]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,lf[102]);}

/* k4286 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4220 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4221,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4226,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 869  string-append");
t4=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[100],t2);}

/* k4224 in a4220 */
static void C_ccall f_4226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4226,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4230,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}

/* f_4230 in k4224 in a4220 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4230,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4237,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4257,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_4257 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4264,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 852  file-exists?");
t4=*((C_word*)lf[99]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4262 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4264,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 853  ##sys#make-c-string");
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4282 in k4262 */
static void C_ccall f_4284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_stat(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
C_trace("posixunix.scm: 854  posix-error");
t3=lf[3];
f_3495(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[97],((C_word*)t0)[2]);}
else{
t3=C_mk_bool(C_isdir);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
C_trace("posixunix.scm: 857  posix-error");
t4=lf[3];
f_3495(6,t4,((C_word*)t0)[3],lf[48],lf[94],lf[98],((C_word*)t0)[2]);}}}

/* k4235 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4237,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4241,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_4241 in k4235 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4241,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4256,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 847  ##sys#make-c-string");
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4254 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 848  posix-error");
t3=lf[3];
f_3495(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[96],((C_word*)t0)[2]);}}

/* stat-socket? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4184,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[92]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4191,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 816  ##sys#stat");
f_4007(t4,t2,C_SCHEME_FALSE,lf[92]);}

/* k4189 in stat-socket? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* stat-symlink? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4175,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[91]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4182,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 811  ##sys#stat");
f_4007(t4,t2,C_SCHEME_TRUE,lf[91]);}

/* k4180 in stat-symlink? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* stat-fifo? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4166,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4173,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 806  ##sys#stat");
f_4007(t4,t2,C_SCHEME_FALSE,lf[90]);}

/* k4171 in stat-fifo? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* stat-block-device? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4157,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4164,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 801  ##sys#stat");
f_4007(t4,t2,C_SCHEME_FALSE,lf[89]);}

/* k4162 in stat-block-device? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* stat-char-device? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4148,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4155,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 796  ##sys#stat");
f_4007(t4,t2,C_SCHEME_FALSE,lf[88]);}

/* k4153 in stat-char-device? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4139,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4146,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 791  ##sys#stat");
f_4007(t4,t2,C_SCHEME_FALSE,lf[87]);}

/* k4144 in stat-directory? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4130,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4137,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 786  ##sys#stat");
f_4007(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k4135 in stat-regular? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4121,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4128,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 781  ##sys#stat");
f_4007(t4,t2,C_SCHEME_TRUE,lf[85]);}

/* k4126 in symbolic-link? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4112,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4119,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 776  ##sys#stat");
f_4007(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k4117 in regular-file? in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4106,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4110,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 772  ##sys#stat");
f_4007(t3,t2,C_SCHEME_FALSE,lf[83]);}

/* k4108 in file-permissions in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4100,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4104,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 771  ##sys#stat");
f_4007(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k4102 in file-owner in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4094,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4098,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 770  ##sys#stat");
f_4007(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k4096 in file-change-time in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4098,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4088,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4092,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 769  ##sys#stat");
f_4007(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k4090 in file-access-time in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4092,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4082,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4086,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 768  ##sys#stat");
f_4007(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k4084 in file-modification-time in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4076,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4080,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 767  ##sys#stat");
f_4007(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k4078 in file-size in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4044r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4044r(t0,t1,t2,t3);}}

static void C_ccall f_4044r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4048,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4055,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_4055(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4055(2,t7,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k4053 in file-stat in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 760  ##sys#stat");
f_4007(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[77]);}

/* k4046 in file-stat in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_4007(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4007,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4011,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_4011(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4032,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4039,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 751  ##sys#expand-home-path");
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
C_trace("posixunix.scm: 755  ##sys#signal-hook");
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[76],t2);}}}

/* k4037 in ##sys#stat in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 751  ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4030 in ##sys#stat in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4011(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k4009 in ##sys#stat in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
C_trace("posixunix.scm: 757  posix-error");
t2=lf[3];
f_3495(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[75],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3815r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3815r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3815r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_3789(C_fix(0));
t10=f_3789(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3831,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_3831(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
C_trace("posixunix.scm: 680  fd_set");
t14=t12;
f_3831(2,t14,f_3795(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[68]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3988,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t15=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a3987 in file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3988,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
C_trace("posixunix.scm: 687  fd_set");
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_3795(C_fix(0),t2));}

/* k3829 in file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3831,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3837,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_3837(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
C_trace("posixunix.scm: 692  fd_set");
t5=t3;
f_3837(2,t5,f_3795(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[68]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a3961 in k3829 in file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3962,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
C_trace("posixunix.scm: 699  fd_set");
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_3795(C_fix(1),t2));}

/* k3835 in k3829 in file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[68]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_3840(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_3840(t4,(C_word)C_C_select(t3));}}

/* k3838 in k3835 in k3829 in file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_3840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3840,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
C_trace("posixunix.scm: 706  posix-error");
t2=lf[3];
f_3495(7,t2,((C_word*)t0)[5],lf[48],lf[68],lf[69],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
C_trace("posixunix.scm: 707  values");
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
C_trace("posixunix.scm: 712  fd_test");
t4=t3;
f_3879(t4,f_3805(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3920,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3922,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_3879(t4,C_SCHEME_FALSE);}}}}

/* a3921 in k3838 in k3835 in k3829 in file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3922,3,t0,t1,t2);}
t3=f_3805(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3918 in k3838 in k3835 in k3829 in file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3879(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3877 in k3838 in k3835 in k3829 in file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_3879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3879,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3883,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
C_trace("posixunix.scm: 718  fd_test");
t3=t2;
f_3883(t3,f_3805(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3895,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3897,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_3883(t3,C_SCHEME_FALSE);}}

/* a3896 in k3877 in k3838 in k3835 in k3829 in file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3897,3,t0,t1,t2);}
t3=f_3805(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3893 in k3877 in k3838 in k3835 in k3829 in file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3883(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3881 in k3877 in k3838 in k3835 in k3829 in file-select in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_fcall f_3883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 709  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall f_3805(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub252(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_set in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall f_3795(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub245(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_zero in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static C_word C_fcall f_3789(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub239(C_SCHEME_UNDEFINED,t2));}

/* file-mkstemp in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3757,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[65]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3764,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("posixunix.scm: 658  ##sys#make-c-string");
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3762 in file-mkstemp in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3764,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3770,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
C_trace("posixunix.scm: 662  posix-error");
t6=lf[3];
f_3495(6,t6,t4,lf[48],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t6=t4;
f_3770(2,t6,C_SCHEME_UNDEFINED);}}

/* k3768 in k3762 in file-mkstemp in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3777,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
C_trace("posixunix.scm: 663  ##sys#substring");
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k3775 in k3768 in k3762 in file-mkstemp in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 663  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3718r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3718r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3718r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[62]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3725,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_3725(2,t8,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 647  ##sys#signal-hook");
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[60],lf[62],lf[64],t3);}}

/* k3723 in file-write in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3725,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[62]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3734,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
C_trace("posixunix.scm: 652  posix-error");
t8=lf[3];
f_3495(7,t8,t6,lf[48],lf[62],lf[63],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_3734(2,t8,C_SCHEME_UNDEFINED);}}

/* k3732 in k3723 in file-write in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3676r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3676r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3676r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3686,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_3686(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
C_trace("posixunix.scm: 635  make-string");
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k3684 in file-read in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_3689(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("posixunix.scm: 637  ##sys#signal-hook");
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[60],lf[58],lf[61],t1);}}

/* k3687 in k3684 in file-read in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3689,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3692,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
C_trace("posixunix.scm: 640  posix-error");
t5=lf[3];
f_3495(7,t5,t3,lf[48],lf[58],lf[59],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_3692(2,t5,C_SCHEME_UNDEFINED);}}

/* k3690 in k3687 in k3684 in file-read in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3692,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3661,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[55]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
C_trace("posixunix.scm: 628  posix-error");
t4=lf[3];
f_3495(6,t4,t1,lf[48],lf[55],lf[56],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3623r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3623r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3623r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[51]);
t8=(C_word)C_i_check_exact_2(t3,lf[51]);
t9=(C_word)C_i_check_exact_2(t6,lf[51]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3640,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3653,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
C_trace("posixunix.scm: 619  ##sys#expand-home-path");
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k3651 in file-open in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 619  ##sys#make-c-string");
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3638 in file-open in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3643,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
C_trace("posixunix.scm: 621  posix-error");
t5=lf[3];
f_3495(8,t5,t3,lf[48],lf[51],lf[52],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_3643(2,t5,C_SCHEME_UNDEFINED);}}

/* k3641 in k3638 in file-open in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3577r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3577r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3577r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3581,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3581(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3581(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3579 in file-control in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[47]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[47]);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_integer_argumentp(t1);
t9=(C_word)stub124(C_SCHEME_UNDEFINED,t6,t7,t8);
t10=(C_word)C_eqp(t9,C_fix(-1));
if(C_truep(t10)){
C_trace("posixunix.scm: 609  posix-error");
t11=lf[3];
f_3495(7,t11,((C_word*)t0)[2],lf[48],lf[47],lf[49],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t9);}}

/* ##sys#file-select-one in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3520,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub46(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-nonblocking! in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3513,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub40(C_SCHEME_UNDEFINED,t3));}

/* posix-error in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_3495r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3495r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3495r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3499,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("posixunix.scm: 499  ##sys#update-errno");
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3497 in posix-error in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3506,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3510,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub23(t4,t5);
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k3508 in k3497 in posix-error in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("posixunix.scm: 500  string-append");
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k3504 in k3497 in posix-error in k3481 in k3478 in k3475 in k3472 in k3469 in k3466 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[622] = {
{"toplevelposixunix.scm",(void*)C_posix_toplevel},
{"f_3468posixunix.scm",(void*)f_3468},
{"f_3471posixunix.scm",(void*)f_3471},
{"f_3474posixunix.scm",(void*)f_3474},
{"f_3477posixunix.scm",(void*)f_3477},
{"f_3480posixunix.scm",(void*)f_3480},
{"f_3483posixunix.scm",(void*)f_3483},
{"f_9376posixunix.scm",(void*)f_9376},
{"f_9389posixunix.scm",(void*)f_9389},
{"f_9401posixunix.scm",(void*)f_9401},
{"f_9395posixunix.scm",(void*)f_9395},
{"f_9339posixunix.scm",(void*)f_9339},
{"f_9355posixunix.scm",(void*)f_9355},
{"f_9343posixunix.scm",(void*)f_9343},
{"f_9346posixunix.scm",(void*)f_9346},
{"f_4195posixunix.scm",(void*)f_4195},
{"f_5251posixunix.scm",(void*)f_5251},
{"f_9333posixunix.scm",(void*)f_9333},
{"f_5386posixunix.scm",(void*)f_5386},
{"f_9318posixunix.scm",(void*)f_9318},
{"f_9328posixunix.scm",(void*)f_9328},
{"f_9315posixunix.scm",(void*)f_9315},
{"f_5428posixunix.scm",(void*)f_5428},
{"f_9300posixunix.scm",(void*)f_9300},
{"f_9310posixunix.scm",(void*)f_9310},
{"f_9297posixunix.scm",(void*)f_9297},
{"f_5432posixunix.scm",(void*)f_5432},
{"f_9282posixunix.scm",(void*)f_9282},
{"f_9292posixunix.scm",(void*)f_9292},
{"f_9279posixunix.scm",(void*)f_9279},
{"f_5436posixunix.scm",(void*)f_5436},
{"f_9264posixunix.scm",(void*)f_9264},
{"f_9274posixunix.scm",(void*)f_9274},
{"f_9261posixunix.scm",(void*)f_9261},
{"f_5440posixunix.scm",(void*)f_5440},
{"f_9240posixunix.scm",(void*)f_9240},
{"f_9256posixunix.scm",(void*)f_9256},
{"f_9222posixunix.scm",(void*)f_9222},
{"f_9235posixunix.scm",(void*)f_9235},
{"f_9229posixunix.scm",(void*)f_9229},
{"f_5958posixunix.scm",(void*)f_5958},
{"f_5997posixunix.scm",(void*)f_5997},
{"f_9199posixunix.scm",(void*)f_9199},
{"f_9191posixunix.scm",(void*)f_9191},
{"f_8940posixunix.scm",(void*)f_8940},
{"f_9117posixunix.scm",(void*)f_9117},
{"f_9123posixunix.scm",(void*)f_9123},
{"f_9112posixunix.scm",(void*)f_9112},
{"f_9107posixunix.scm",(void*)f_9107},
{"f_8942posixunix.scm",(void*)f_8942},
{"f_9094posixunix.scm",(void*)f_9094},
{"f_9102posixunix.scm",(void*)f_9102},
{"f_8949posixunix.scm",(void*)f_8949},
{"f_9082posixunix.scm",(void*)f_9082},
{"f_9076posixunix.scm",(void*)f_9076},
{"f_8959posixunix.scm",(void*)f_8959},
{"f_8961posixunix.scm",(void*)f_8961},
{"f_8980posixunix.scm",(void*)f_8980},
{"f_9062posixunix.scm",(void*)f_9062},
{"f_9069posixunix.scm",(void*)f_9069},
{"f_9056posixunix.scm",(void*)f_9056},
{"f_8995posixunix.scm",(void*)f_8995},
{"f_9049posixunix.scm",(void*)f_9049},
{"f_9046posixunix.scm",(void*)f_9046},
{"f_9036posixunix.scm",(void*)f_9036},
{"f_9012posixunix.scm",(void*)f_9012},
{"f_9034posixunix.scm",(void*)f_9034},
{"f_9020posixunix.scm",(void*)f_9020},
{"f_9027posixunix.scm",(void*)f_9027},
{"f_9024posixunix.scm",(void*)f_9024},
{"f_9007posixunix.scm",(void*)f_9007},
{"f_9005posixunix.scm",(void*)f_9005},
{"f_9083posixunix.scm",(void*)f_9083},
{"f_8880posixunix.scm",(void*)f_8880},
{"f_8892posixunix.scm",(void*)f_8892},
{"f_8887posixunix.scm",(void*)f_8887},
{"f_8882posixunix.scm",(void*)f_8882},
{"f_8820posixunix.scm",(void*)f_8820},
{"f_8832posixunix.scm",(void*)f_8832},
{"f_8827posixunix.scm",(void*)f_8827},
{"f_8822posixunix.scm",(void*)f_8822},
{"f_8759posixunix.scm",(void*)f_8759},
{"f_8814posixunix.scm",(void*)f_8814},
{"f_8818posixunix.scm",(void*)f_8818},
{"f_8780posixunix.scm",(void*)f_8780},
{"f_8783posixunix.scm",(void*)f_8783},
{"f_8794posixunix.scm",(void*)f_8794},
{"f_8788posixunix.scm",(void*)f_8788},
{"f_8761posixunix.scm",(void*)f_8761},
{"f_8770posixunix.scm",(void*)f_8770},
{"f_8701posixunix.scm",(void*)f_8701},
{"f_8713posixunix.scm",(void*)f_8713},
{"f_8744posixunix.scm",(void*)f_8744},
{"f_8724posixunix.scm",(void*)f_8724},
{"f_8740posixunix.scm",(void*)f_8740},
{"f_8728posixunix.scm",(void*)f_8728},
{"f_8736posixunix.scm",(void*)f_8736},
{"f_8732posixunix.scm",(void*)f_8732},
{"f_8707posixunix.scm",(void*)f_8707},
{"f_8690posixunix.scm",(void*)f_8690},
{"f_8694posixunix.scm",(void*)f_8694},
{"f_8679posixunix.scm",(void*)f_8679},
{"f_8683posixunix.scm",(void*)f_8683},
{"f_8634posixunix.scm",(void*)f_8634},
{"f_8638posixunix.scm",(void*)f_8638},
{"f_8641posixunix.scm",(void*)f_8641},
{"f_8644posixunix.scm",(void*)f_8644},
{"f_8657posixunix.scm",(void*)f_8657},
{"f_8661posixunix.scm",(void*)f_8661},
{"f_8664posixunix.scm",(void*)f_8664},
{"f_8667posixunix.scm",(void*)f_8667},
{"f_8655posixunix.scm",(void*)f_8655},
{"f_8618posixunix.scm",(void*)f_8618},
{"f_8601posixunix.scm",(void*)f_8601},
{"f_8614posixunix.scm",(void*)f_8614},
{"f_8526posixunix.scm",(void*)f_8526},
{"f_8587posixunix.scm",(void*)f_8587},
{"f_8600posixunix.scm",(void*)f_8600},
{"f_8567posixunix.scm",(void*)f_8567},
{"f_8582posixunix.scm",(void*)f_8582},
{"f_8576posixunix.scm",(void*)f_8576},
{"f_8530posixunix.scm",(void*)f_8530},
{"f_8532posixunix.scm",(void*)f_8532},
{"f_8553posixunix.scm",(void*)f_8553},
{"f_8547posixunix.scm",(void*)f_8547},
{"f_8474posixunix.scm",(void*)f_8474},
{"f_8481posixunix.scm",(void*)f_8481},
{"f_8500posixunix.scm",(void*)f_8500},
{"f_8504posixunix.scm",(void*)f_8504},
{"f_8468posixunix.scm",(void*)f_8468},
{"f_8459posixunix.scm",(void*)f_8459},
{"f_8463posixunix.scm",(void*)f_8463},
{"f_8432posixunix.scm",(void*)f_8432},
{"f_8425posixunix.scm",(void*)f_8425},
{"f_8422posixunix.scm",(void*)f_8422},
{"f_8419posixunix.scm",(void*)f_8419},
{"f_8341posixunix.scm",(void*)f_8341},
{"f_8377posixunix.scm",(void*)f_8377},
{"f_8371posixunix.scm",(void*)f_8371},
{"f_8324posixunix.scm",(void*)f_8324},
{"f_8142posixunix.scm",(void*)f_8142},
{"f_8276posixunix.scm",(void*)f_8276},
{"f_8271posixunix.scm",(void*)f_8271},
{"f_8144posixunix.scm",(void*)f_8144},
{"f_8154posixunix.scm",(void*)f_8154},
{"f_8162posixunix.scm",(void*)f_8162},
{"f_8208posixunix.scm",(void*)f_8208},
{"f_8175posixunix.scm",(void*)f_8175},
{"f_8200posixunix.scm",(void*)f_8200},
{"f_8178posixunix.scm",(void*)f_8178},
{"f_8123posixunix.scm",(void*)f_8123},
{"f_8104posixunix.scm",(void*)f_8104},
{"f_8062posixunix.scm",(void*)f_8062},
{"f_8084posixunix.scm",(void*)f_8084},
{"f_8088posixunix.scm",(void*)f_8088},
{"f_7950posixunix.scm",(void*)f_7950},
{"f_7956posixunix.scm",(void*)f_7956},
{"f_7977posixunix.scm",(void*)f_7977},
{"f_8054posixunix.scm",(void*)f_8054},
{"f_7981posixunix.scm",(void*)f_7981},
{"f_7984posixunix.scm",(void*)f_7984},
{"f_7987posixunix.scm",(void*)f_7987},
{"f_7994posixunix.scm",(void*)f_7994},
{"f_7996posixunix.scm",(void*)f_7996},
{"f_8013posixunix.scm",(void*)f_8013},
{"f_8023posixunix.scm",(void*)f_8023},
{"f_8027posixunix.scm",(void*)f_8027},
{"f_7971posixunix.scm",(void*)f_7971},
{"f_7938posixunix.scm",(void*)f_7938},
{"f_7942posixunix.scm",(void*)f_7942},
{"f_7945posixunix.scm",(void*)f_7945},
{"f_7903posixunix.scm",(void*)f_7903},
{"f_7907posixunix.scm",(void*)f_7907},
{"f_7927posixunix.scm",(void*)f_7927},
{"f_7931posixunix.scm",(void*)f_7931},
{"f_7880posixunix.scm",(void*)f_7880},
{"f_7884posixunix.scm",(void*)f_7884},
{"f_7848posixunix.scm",(void*)f_7848},
{"f_7852posixunix.scm",(void*)f_7852},
{"f_7829posixunix.scm",(void*)f_7829},
{"f_7833posixunix.scm",(void*)f_7833},
{"f_7836posixunix.scm",(void*)f_7836},
{"f_7770posixunix.scm",(void*)f_7770},
{"f_7774posixunix.scm",(void*)f_7774},
{"f_7780posixunix.scm",(void*)f_7780},
{"f_7763posixunix.scm",(void*)f_7763},
{"f_7747posixunix.scm",(void*)f_7747},
{"f_7735posixunix.scm",(void*)f_7735},
{"f_7707posixunix.scm",(void*)f_7707},
{"f_7714posixunix.scm",(void*)f_7714},
{"f_7679posixunix.scm",(void*)f_7679},
{"f_7686posixunix.scm",(void*)f_7686},
{"f_7633posixunix.scm",(void*)f_7633},
{"f_7637posixunix.scm",(void*)f_7637},
{"f_7650posixunix.scm",(void*)f_7650},
{"f_7654posixunix.scm",(void*)f_7654},
{"f_7551posixunix.scm",(void*)f_7551},
{"f_7555posixunix.scm",(void*)f_7555},
{"f_7561posixunix.scm",(void*)f_7561},
{"f_7583posixunix.scm",(void*)f_7583},
{"f_7580posixunix.scm",(void*)f_7580},
{"f_7570posixunix.scm",(void*)f_7570},
{"f_7518posixunix.scm",(void*)f_7518},
{"f_7522posixunix.scm",(void*)f_7522},
{"f_7499posixunix.scm",(void*)f_7499},
{"f_7490posixunix.scm",(void*)f_7490},
{"f_7484posixunix.scm",(void*)f_7484},
{"f_7475posixunix.scm",(void*)f_7475},
{"f_7440posixunix.scm",(void*)f_7440},
{"f_7378posixunix.scm",(void*)f_7378},
{"f_7382posixunix.scm",(void*)f_7382},
{"f_7388posixunix.scm",(void*)f_7388},
{"f_7407posixunix.scm",(void*)f_7407},
{"f_7394posixunix.scm",(void*)f_7394},
{"f_7275posixunix.scm",(void*)f_7275},
{"f_7281posixunix.scm",(void*)f_7281},
{"f_7285posixunix.scm",(void*)f_7285},
{"f_7293posixunix.scm",(void*)f_7293},
{"f_7319posixunix.scm",(void*)f_7319},
{"f_7323posixunix.scm",(void*)f_7323},
{"f_7311posixunix.scm",(void*)f_7311},
{"f_7255posixunix.scm",(void*)f_7255},
{"f_7263posixunix.scm",(void*)f_7263},
{"f_7238posixunix.scm",(void*)f_7238},
{"f_7249posixunix.scm",(void*)f_7249},
{"f_7253posixunix.scm",(void*)f_7253},
{"f_7212posixunix.scm",(void*)f_7212},
{"f_7236posixunix.scm",(void*)f_7236},
{"f_7219posixunix.scm",(void*)f_7219},
{"f_7169posixunix.scm",(void*)f_7169},
{"f_7176posixunix.scm",(void*)f_7176},
{"f_7197posixunix.scm",(void*)f_7197},
{"f_7193posixunix.scm",(void*)f_7193},
{"f_7141posixunix.scm",(void*)f_7141},
{"f_7119posixunix.scm",(void*)f_7119},
{"f_7123posixunix.scm",(void*)f_7123},
{"f_7104posixunix.scm",(void*)f_7104},
{"f_7108posixunix.scm",(void*)f_7108},
{"f_7089posixunix.scm",(void*)f_7089},
{"f_7093posixunix.scm",(void*)f_7093},
{"f_7071posixunix.scm",(void*)f_7071},
{"f_6997posixunix.scm",(void*)f_6997},
{"f_7019posixunix.scm",(void*)f_7019},
{"f_7025posixunix.scm",(void*)f_7025},
{"f_6958posixunix.scm",(void*)f_6958},
{"f_6986posixunix.scm",(void*)f_6986},
{"f_6982posixunix.scm",(void*)f_6982},
{"f_6975posixunix.scm",(void*)f_6975},
{"f_6699posixunix.scm",(void*)f_6699},
{"f_6895posixunix.scm",(void*)f_6895},
{"f_6890posixunix.scm",(void*)f_6890},
{"f_6885posixunix.scm",(void*)f_6885},
{"f_6701posixunix.scm",(void*)f_6701},
{"f_6705posixunix.scm",(void*)f_6705},
{"f_6811posixunix.scm",(void*)f_6811},
{"f_6812posixunix.scm",(void*)f_6812},
{"f_6829posixunix.scm",(void*)f_6829},
{"f_6839posixunix.scm",(void*)f_6839},
{"f_6797posixunix.scm",(void*)f_6797},
{"f_6753posixunix.scm",(void*)f_6753},
{"f_6789posixunix.scm",(void*)f_6789},
{"f_6768posixunix.scm",(void*)f_6768},
{"f_6778posixunix.scm",(void*)f_6778},
{"f_6762posixunix.scm",(void*)f_6762},
{"f_6757posixunix.scm",(void*)f_6757},
{"f_6760posixunix.scm",(void*)f_6760},
{"f_6707posixunix.scm",(void*)f_6707},
{"f_6742posixunix.scm",(void*)f_6742},
{"f_6723posixunix.scm",(void*)f_6723},
{"f_6225posixunix.scm",(void*)f_6225},
{"f_6621posixunix.scm",(void*)f_6621},
{"f_6616posixunix.scm",(void*)f_6616},
{"f_6611posixunix.scm",(void*)f_6611},
{"f_6606posixunix.scm",(void*)f_6606},
{"f_6227posixunix.scm",(void*)f_6227},
{"f_6231posixunix.scm",(void*)f_6231},
{"f_6237posixunix.scm",(void*)f_6237},
{"f_6479posixunix.scm",(void*)f_6479},
{"f_6485posixunix.scm",(void*)f_6485},
{"f_6581posixunix.scm",(void*)f_6581},
{"f_6571posixunix.scm",(void*)f_6571},
{"f_6565posixunix.scm",(void*)f_6565},
{"f_6487posixunix.scm",(void*)f_6487},
{"f_6537posixunix.scm",(void*)f_6537},
{"f_6494posixunix.scm",(void*)f_6494},
{"f_6504posixunix.scm",(void*)f_6504},
{"f_6403posixunix.scm",(void*)f_6403},
{"f_6411posixunix.scm",(void*)f_6411},
{"f_6413posixunix.scm",(void*)f_6413},
{"f_6461posixunix.scm",(void*)f_6461},
{"f_6394posixunix.scm",(void*)f_6394},
{"f_6398posixunix.scm",(void*)f_6398},
{"f_6373posixunix.scm",(void*)f_6373},
{"f_6383posixunix.scm",(void*)f_6383},
{"f_6361posixunix.scm",(void*)f_6361},
{"f_6348posixunix.scm",(void*)f_6348},
{"f_6352posixunix.scm",(void*)f_6352},
{"f_6343posixunix.scm",(void*)f_6343},
{"f_6346posixunix.scm",(void*)f_6346},
{"f_6261posixunix.scm",(void*)f_6261},
{"f_6273posixunix.scm",(void*)f_6273},
{"f_6310posixunix.scm",(void*)f_6310},
{"f_6319posixunix.scm",(void*)f_6319},
{"f_6313posixunix.scm",(void*)f_6313},
{"f_6289posixunix.scm",(void*)f_6289},
{"f_6292posixunix.scm",(void*)f_6292},
{"f_6253posixunix.scm",(void*)f_6253},
{"f_6238posixunix.scm",(void*)f_6238},
{"f_6252posixunix.scm",(void*)f_6252},
{"f_6198posixunix.scm",(void*)f_6198},
{"f_6205posixunix.scm",(void*)f_6205},
{"f_6208posixunix.scm",(void*)f_6208},
{"f_6153posixunix.scm",(void*)f_6153},
{"f_6157posixunix.scm",(void*)f_6157},
{"f_6192posixunix.scm",(void*)f_6192},
{"f_6175posixunix.scm",(void*)f_6175},
{"f_6139posixunix.scm",(void*)f_6139},
{"f_6151posixunix.scm",(void*)f_6151},
{"f_6125posixunix.scm",(void*)f_6125},
{"f_6137posixunix.scm",(void*)f_6137},
{"f_6110posixunix.scm",(void*)f_6110},
{"f_6123posixunix.scm",(void*)f_6123},
{"f_6073posixunix.scm",(void*)f_6073},
{"f_6081posixunix.scm",(void*)f_6081},
{"f_6048posixunix.scm",(void*)f_6048},
{"f_6029posixunix.scm",(void*)f_6029},
{"f_6033posixunix.scm",(void*)f_6033},
{"f_5998posixunix.scm",(void*)f_5998},
{"f_6022posixunix.scm",(void*)f_6022},
{"f_6006posixunix.scm",(void*)f_6006},
{"f_6009posixunix.scm",(void*)f_6009},
{"f_5960posixunix.scm",(void*)f_5960},
{"f_5993posixunix.scm",(void*)f_5993},
{"f_5981posixunix.scm",(void*)f_5981},
{"f_5989posixunix.scm",(void*)f_5989},
{"f_5985posixunix.scm",(void*)f_5985},
{"f_5941posixunix.scm",(void*)f_5941},
{"f_5951posixunix.scm",(void*)f_5951},
{"f_5945posixunix.scm",(void*)f_5945},
{"f_5935posixunix.scm",(void*)f_5935},
{"f_5929posixunix.scm",(void*)f_5929},
{"f_5923posixunix.scm",(void*)f_5923},
{"f_5899posixunix.scm",(void*)f_5899},
{"f_5921posixunix.scm",(void*)f_5921},
{"f_5917posixunix.scm",(void*)f_5917},
{"f_5909posixunix.scm",(void*)f_5909},
{"f_5869posixunix.scm",(void*)f_5869},
{"f_5897posixunix.scm",(void*)f_5897},
{"f_5893posixunix.scm",(void*)f_5893},
{"f_5842posixunix.scm",(void*)f_5842},
{"f_5867posixunix.scm",(void*)f_5867},
{"f_5863posixunix.scm",(void*)f_5863},
{"f_5778posixunix.scm",(void*)f_5778},
{"f_5766posixunix.scm",(void*)f_5766},
{"f_5794posixunix.scm",(void*)f_5794},
{"f_5704posixunix.scm",(void*)f_5704},
{"f_5708posixunix.scm",(void*)f_5708},
{"f_5713posixunix.scm",(void*)f_5713},
{"f_5729posixunix.scm",(void*)f_5729},
{"f_5641posixunix.scm",(void*)f_5641},
{"f_5699posixunix.scm",(void*)f_5699},
{"f_5645posixunix.scm",(void*)f_5645},
{"f_5648posixunix.scm",(void*)f_5648},
{"f_5680posixunix.scm",(void*)f_5680},
{"f_5651posixunix.scm",(void*)f_5651},
{"f_5656posixunix.scm",(void*)f_5656},
{"f_5670posixunix.scm",(void*)f_5670},
{"f_5634posixunix.scm",(void*)f_5634},
{"f_5548posixunix.scm",(void*)f_5548},
{"f_5552posixunix.scm",(void*)f_5552},
{"f_5606posixunix.scm",(void*)f_5606},
{"f_5555posixunix.scm",(void*)f_5555},
{"f_5565posixunix.scm",(void*)f_5565},
{"f_5569posixunix.scm",(void*)f_5569},
{"f_5578posixunix.scm",(void*)f_5578},
{"f_5582posixunix.scm",(void*)f_5582},
{"f_5592posixunix.scm",(void*)f_5592},
{"f_5573posixunix.scm",(void*)f_5573},
{"f_5523posixunix.scm",(void*)f_5523},
{"f_5535posixunix.scm",(void*)f_5535},
{"f_5531posixunix.scm",(void*)f_5531},
{"f_5509posixunix.scm",(void*)f_5509},
{"f_5521posixunix.scm",(void*)f_5521},
{"f_5517posixunix.scm",(void*)f_5517},
{"f_5442posixunix.scm",(void*)f_5442},
{"f_5446posixunix.scm",(void*)f_5446},
{"f_5488posixunix.scm",(void*)f_5488},
{"f_5449posixunix.scm",(void*)f_5449},
{"f_5459posixunix.scm",(void*)f_5459},
{"f_5463posixunix.scm",(void*)f_5463},
{"f_5467posixunix.scm",(void*)f_5467},
{"f_5471posixunix.scm",(void*)f_5471},
{"f_5475posixunix.scm",(void*)f_5475},
{"f_5388posixunix.scm",(void*)f_5388},
{"f_5421posixunix.scm",(void*)f_5421},
{"f_5392posixunix.scm",(void*)f_5392},
{"f_5399posixunix.scm",(void*)f_5399},
{"f_5403posixunix.scm",(void*)f_5403},
{"f_5407posixunix.scm",(void*)f_5407},
{"f_5411posixunix.scm",(void*)f_5411},
{"f_5415posixunix.scm",(void*)f_5415},
{"f_5370posixunix.scm",(void*)f_5370},
{"f_5355posixunix.scm",(void*)f_5355},
{"f_5349posixunix.scm",(void*)f_5349},
{"f_5317posixunix.scm",(void*)f_5317},
{"f_5323posixunix.scm",(void*)f_5323},
{"f_5293posixunix.scm",(void*)f_5293},
{"f_5311posixunix.scm",(void*)f_5311},
{"f_5300posixunix.scm",(void*)f_5300},
{"f_5275posixunix.scm",(void*)f_5275},
{"f_5285posixunix.scm",(void*)f_5285},
{"f_5262posixunix.scm",(void*)f_5262},
{"f_5253posixunix.scm",(void*)f_5253},
{"f_5206posixunix.scm",(void*)f_5206},
{"f_5210posixunix.scm",(void*)f_5210},
{"f_5186posixunix.scm",(void*)f_5186},
{"f_5190posixunix.scm",(void*)f_5190},
{"f_5196posixunix.scm",(void*)f_5196},
{"f_5200posixunix.scm",(void*)f_5200},
{"f_5166posixunix.scm",(void*)f_5166},
{"f_5170posixunix.scm",(void*)f_5170},
{"f_5176posixunix.scm",(void*)f_5176},
{"f_5180posixunix.scm",(void*)f_5180},
{"f_5142posixunix.scm",(void*)f_5142},
{"f_5146posixunix.scm",(void*)f_5146},
{"f_5157posixunix.scm",(void*)f_5157},
{"f_5161posixunix.scm",(void*)f_5161},
{"f_5151posixunix.scm",(void*)f_5151},
{"f_5118posixunix.scm",(void*)f_5118},
{"f_5122posixunix.scm",(void*)f_5122},
{"f_5133posixunix.scm",(void*)f_5133},
{"f_5137posixunix.scm",(void*)f_5137},
{"f_5127posixunix.scm",(void*)f_5127},
{"f_5102posixunix.scm",(void*)f_5102},
{"f_5106posixunix.scm",(void*)f_5106},
{"f_5109posixunix.scm",(void*)f_5109},
{"f_5066posixunix.scm",(void*)f_5066},
{"f_5097posixunix.scm",(void*)f_5097},
{"f_5087posixunix.scm",(void*)f_5087},
{"f_5080posixunix.scm",(void*)f_5080},
{"f_5030posixunix.scm",(void*)f_5030},
{"f_5061posixunix.scm",(void*)f_5061},
{"f_5051posixunix.scm",(void*)f_5051},
{"f_5044posixunix.scm",(void*)f_5044},
{"f_5015posixunix.scm",(void*)f_5015},
{"f_5028posixunix.scm",(void*)f_5028},
{"f_5009posixunix.scm",(void*)f_5009},
{"f_4997posixunix.scm",(void*)f_4997},
{"f_4680posixunix.scm",(void*)f_4680},
{"f_4987posixunix.scm",(void*)f_4987},
{"f_4807posixunix.scm",(void*)f_4807},
{"f_4973posixunix.scm",(void*)f_4973},
{"f_4962posixunix.scm",(void*)f_4962},
{"f_4969posixunix.scm",(void*)f_4969},
{"f_4826posixunix.scm",(void*)f_4826},
{"f_4955posixunix.scm",(void*)f_4955},
{"f_4934posixunix.scm",(void*)f_4934},
{"f_4951posixunix.scm",(void*)f_4951},
{"f_4940posixunix.scm",(void*)f_4940},
{"f_4947posixunix.scm",(void*)f_4947},
{"f_4870posixunix.scm",(void*)f_4870},
{"f_4931posixunix.scm",(void*)f_4931},
{"f_4910posixunix.scm",(void*)f_4910},
{"f_4927posixunix.scm",(void*)f_4927},
{"f_4916posixunix.scm",(void*)f_4916},
{"f_4923posixunix.scm",(void*)f_4923},
{"f_4883posixunix.scm",(void*)f_4883},
{"f_4907posixunix.scm",(void*)f_4907},
{"f_4903posixunix.scm",(void*)f_4903},
{"f_4864posixunix.scm",(void*)f_4864},
{"f_4833posixunix.scm",(void*)f_4833},
{"f_4851posixunix.scm",(void*)f_4851},
{"f_4836posixunix.scm",(void*)f_4836},
{"f_4840posixunix.scm",(void*)f_4840},
{"f_4820posixunix.scm",(void*)f_4820},
{"f_4801posixunix.scm",(void*)f_4801},
{"f_4687posixunix.scm",(void*)f_4687},
{"f_4694posixunix.scm",(void*)f_4694},
{"f_4696posixunix.scm",(void*)f_4696},
{"f_4703posixunix.scm",(void*)f_4703},
{"f_4767posixunix.scm",(void*)f_4767},
{"f_4776posixunix.scm",(void*)f_4776},
{"f_4764posixunix.scm",(void*)f_4764},
{"f_4709posixunix.scm",(void*)f_4709},
{"f_4745posixunix.scm",(void*)f_4745},
{"f_4741posixunix.scm",(void*)f_4741},
{"f_4737posixunix.scm",(void*)f_4737},
{"f_4726posixunix.scm",(void*)f_4726},
{"f_4722posixunix.scm",(void*)f_4722},
{"f_4624posixunix.scm",(void*)f_4624},
{"f_4633posixunix.scm",(void*)f_4633},
{"f_4657posixunix.scm",(void*)f_4657},
{"f_4669posixunix.scm",(void*)f_4669},
{"f_4675posixunix.scm",(void*)f_4675},
{"f_4663posixunix.scm",(void*)f_4663},
{"f_4639posixunix.scm",(void*)f_4639},
{"f_4645posixunix.scm",(void*)f_4645},
{"f_4631posixunix.scm",(void*)f_4631},
{"f_4613posixunix.scm",(void*)f_4613},
{"f_4608posixunix.scm",(void*)f_4608},
{"f_4560posixunix.scm",(void*)f_4560},
{"f_4564posixunix.scm",(void*)f_4564},
{"f_4573posixunix.scm",(void*)f_4573},
{"f_4537posixunix.scm",(void*)f_4537},
{"f_4558posixunix.scm",(void*)f_4558},
{"f_4544posixunix.scm",(void*)f_4544},
{"f_4380posixunix.scm",(void*)f_4380},
{"f_4485posixunix.scm",(void*)f_4485},
{"f_4493posixunix.scm",(void*)f_4493},
{"f_4480posixunix.scm",(void*)f_4480},
{"f_4382posixunix.scm",(void*)f_4382},
{"f_4389posixunix.scm",(void*)f_4389},
{"f_4392posixunix.scm",(void*)f_4392},
{"f_4395posixunix.scm",(void*)f_4395},
{"f_4479posixunix.scm",(void*)f_4479},
{"f_4399posixunix.scm",(void*)f_4399},
{"f_4413posixunix.scm",(void*)f_4413},
{"f_4423posixunix.scm",(void*)f_4423},
{"f_4426posixunix.scm",(void*)f_4426},
{"f_4429posixunix.scm",(void*)f_4429},
{"f_4435posixunix.scm",(void*)f_4435},
{"f_4445posixunix.scm",(void*)f_4445},
{"f_4356posixunix.scm",(void*)f_4356},
{"f_4378posixunix.scm",(void*)f_4378},
{"f_4374posixunix.scm",(void*)f_4374},
{"f_4332posixunix.scm",(void*)f_4332},
{"f_4354posixunix.scm",(void*)f_4354},
{"f_4350posixunix.scm",(void*)f_4350},
{"f_4197posixunix.scm",(void*)f_4197},
{"f_4201posixunix.scm",(void*)f_4201},
{"f_4295posixunix.scm",(void*)f_4295},
{"f_4296posixunix.scm",(void*)f_4296},
{"f_4311posixunix.scm",(void*)f_4311},
{"f_4214posixunix.scm",(void*)f_4214},
{"f_4215posixunix.scm",(void*)f_4215},
{"f_4288posixunix.scm",(void*)f_4288},
{"f_4221posixunix.scm",(void*)f_4221},
{"f_4226posixunix.scm",(void*)f_4226},
{"f_4230posixunix.scm",(void*)f_4230},
{"f_4257posixunix.scm",(void*)f_4257},
{"f_4264posixunix.scm",(void*)f_4264},
{"f_4284posixunix.scm",(void*)f_4284},
{"f_4237posixunix.scm",(void*)f_4237},
{"f_4241posixunix.scm",(void*)f_4241},
{"f_4256posixunix.scm",(void*)f_4256},
{"f_4184posixunix.scm",(void*)f_4184},
{"f_4191posixunix.scm",(void*)f_4191},
{"f_4175posixunix.scm",(void*)f_4175},
{"f_4182posixunix.scm",(void*)f_4182},
{"f_4166posixunix.scm",(void*)f_4166},
{"f_4173posixunix.scm",(void*)f_4173},
{"f_4157posixunix.scm",(void*)f_4157},
{"f_4164posixunix.scm",(void*)f_4164},
{"f_4148posixunix.scm",(void*)f_4148},
{"f_4155posixunix.scm",(void*)f_4155},
{"f_4139posixunix.scm",(void*)f_4139},
{"f_4146posixunix.scm",(void*)f_4146},
{"f_4130posixunix.scm",(void*)f_4130},
{"f_4137posixunix.scm",(void*)f_4137},
{"f_4121posixunix.scm",(void*)f_4121},
{"f_4128posixunix.scm",(void*)f_4128},
{"f_4112posixunix.scm",(void*)f_4112},
{"f_4119posixunix.scm",(void*)f_4119},
{"f_4106posixunix.scm",(void*)f_4106},
{"f_4110posixunix.scm",(void*)f_4110},
{"f_4100posixunix.scm",(void*)f_4100},
{"f_4104posixunix.scm",(void*)f_4104},
{"f_4094posixunix.scm",(void*)f_4094},
{"f_4098posixunix.scm",(void*)f_4098},
{"f_4088posixunix.scm",(void*)f_4088},
{"f_4092posixunix.scm",(void*)f_4092},
{"f_4082posixunix.scm",(void*)f_4082},
{"f_4086posixunix.scm",(void*)f_4086},
{"f_4076posixunix.scm",(void*)f_4076},
{"f_4080posixunix.scm",(void*)f_4080},
{"f_4044posixunix.scm",(void*)f_4044},
{"f_4055posixunix.scm",(void*)f_4055},
{"f_4048posixunix.scm",(void*)f_4048},
{"f_4007posixunix.scm",(void*)f_4007},
{"f_4039posixunix.scm",(void*)f_4039},
{"f_4032posixunix.scm",(void*)f_4032},
{"f_4011posixunix.scm",(void*)f_4011},
{"f_3815posixunix.scm",(void*)f_3815},
{"f_3988posixunix.scm",(void*)f_3988},
{"f_3831posixunix.scm",(void*)f_3831},
{"f_3962posixunix.scm",(void*)f_3962},
{"f_3837posixunix.scm",(void*)f_3837},
{"f_3840posixunix.scm",(void*)f_3840},
{"f_3922posixunix.scm",(void*)f_3922},
{"f_3920posixunix.scm",(void*)f_3920},
{"f_3879posixunix.scm",(void*)f_3879},
{"f_3897posixunix.scm",(void*)f_3897},
{"f_3895posixunix.scm",(void*)f_3895},
{"f_3883posixunix.scm",(void*)f_3883},
{"f_3805posixunix.scm",(void*)f_3805},
{"f_3795posixunix.scm",(void*)f_3795},
{"f_3789posixunix.scm",(void*)f_3789},
{"f_3757posixunix.scm",(void*)f_3757},
{"f_3764posixunix.scm",(void*)f_3764},
{"f_3770posixunix.scm",(void*)f_3770},
{"f_3777posixunix.scm",(void*)f_3777},
{"f_3718posixunix.scm",(void*)f_3718},
{"f_3725posixunix.scm",(void*)f_3725},
{"f_3734posixunix.scm",(void*)f_3734},
{"f_3676posixunix.scm",(void*)f_3676},
{"f_3686posixunix.scm",(void*)f_3686},
{"f_3689posixunix.scm",(void*)f_3689},
{"f_3692posixunix.scm",(void*)f_3692},
{"f_3661posixunix.scm",(void*)f_3661},
{"f_3623posixunix.scm",(void*)f_3623},
{"f_3653posixunix.scm",(void*)f_3653},
{"f_3640posixunix.scm",(void*)f_3640},
{"f_3643posixunix.scm",(void*)f_3643},
{"f_3577posixunix.scm",(void*)f_3577},
{"f_3581posixunix.scm",(void*)f_3581},
{"f_3520posixunix.scm",(void*)f_3520},
{"f_3513posixunix.scm",(void*)f_3513},
{"f_3495posixunix.scm",(void*)f_3495},
{"f_3499posixunix.scm",(void*)f_3499},
{"f_3510posixunix.scm",(void*)f_3510},
{"f_3506posixunix.scm",(void*)f_3506},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
