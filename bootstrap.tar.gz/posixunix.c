/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-11-03 03:24
   Version 4.0.0x - linux-unix-gnu-x86	[ ptables applyhook ]
   SVN rev. 12299	compiled 2008-10-29 on dill (Linux)
   command line: posixunix.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -debug i -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set_9(v) \
        (C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)))

#define C_tm_get_08(v) \
        (C_set_block_item(v, 0, C_fix(C_tm.tm_sec)), \
        C_set_block_item(v, 1, C_fix(C_tm.tm_min)), \
        C_set_block_item(v, 2, C_fix(C_tm.tm_hour)), \
        C_set_block_item(v, 3, C_fix(C_tm.tm_mday)), \
        C_set_block_item(v, 4, C_fix(C_tm.tm_mon)), \
        C_set_block_item(v, 5, C_fix(C_tm.tm_year)), \
        C_set_block_item(v, 6, C_fix(C_tm.tm_wday)), \
        C_set_block_item(v, 7, C_fix(C_tm.tm_yday)), \
        C_set_block_item(v, 8, (C_tm.tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define C_tm_get_9(v) \
        (C_set_block_item(v, 9, C_fix(C_tm.tm_gmtoff)))

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  return &C_tm;
}

static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  return v;
}

#else

static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  C_tm_set_9 (v);
  return &C_tm;
}

static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  C_tm_get_9 (v);
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[466];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,51,48,32,108,111,99,51,49,32,109,115,103,51,50,32,46,32,97,114,103,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,51,57,52,50,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,52,53,52,56,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,49,51,55,32,99,109,100,49,51,56,32,46,32,116,109,112,49,51,54,49,51,57,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,49,53,57,32,102,108,97,103,115,49,54,48,32,46,32,109,111,100,101,49,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,99,108,111,115,101,32,102,100,49,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,37),40,102,105,108,101,45,114,101,97,100,32,102,100,49,56,50,32,115,105,122,101,49,56,51,32,46,32,98,117,102,102,101,114,49,56,52,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,119,114,105,116,101,32,102,100,50,48,49,32,98,117,102,102,101,114,50,48,50,32,46,32,115,105,122,101,50,48,51,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,50,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,9),40,102,100,95,122,101,114,111,41,0,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,16),40,102,100,95,115,101,116,32,97,50,52,51,50,52,56,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,17),40,102,100,95,116,101,115,116,32,97,50,53,48,50,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,51,56,53,55,32,102,100,51,51,51,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,97,51,56,56,50,32,102,100,51,50,52,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,13),40,97,51,57,50,50,32,102,100,50,57,56,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,51,57,52,56,32,102,100,50,55,57,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,50,53,56,32,102,100,115,119,50,53,57,32,46,32,116,105,109,101,111,117,116,50,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,51,54,51,32,108,105,110,107,51,54,52,32,108,111,99,51,54,53,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,51,56,50,32,46,32,108,105,110,107,51,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,51,57,54,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,52,48,49,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,52,48,54,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,52,49,49,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,52,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,52,50,49,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,52,50,54,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,52,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,114,101,103,117,108,97,114,63,32,102,110,97,109,101,52,52,52,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,115,116,97,116,45,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,52,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,28),40,115,116,97,116,45,99,104,97,114,45,100,101,118,105,99,101,63,32,102,110,97,109,101,52,54,50,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,29),40,115,116,97,116,45,98,108,111,99,107,45,100,101,118,105,99,101,63,32,102,110,97,109,101,52,55,49,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,21),40,115,116,97,116,45,102,105,102,111,63,32,102,110,97,109,101,52,56,48,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,115,121,109,108,105,110,107,63,32,102,110,97,109,101,52,56,57,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,115,116,97,116,45,115,111,99,107,101,116,63,32,102,110,97,109,101,52,57,56,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,16),40,102,95,52,50,48,50,32,110,97,109,101,53,57,49,41};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,16),40,102,95,52,50,49,56,32,110,97,109,101,53,56,48,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,16),40,102,95,52,49,57,49,32,110,97,109,101,53,55,54,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,97,52,49,56,49,32,120,53,55,52,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,16),40,102,95,52,49,55,54,32,110,97,109,101,53,55,48,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,16),40,102,95,52,50,53,55,32,110,97,109,101,53,57,54,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,53,53,55,32,46,32,116,109,112,53,53,54,53,53,56,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,54,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,54,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,54,51,51,32,115,112,101,99,54,52,51,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,54,52,52,41,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,54,51,54,32,37,115,112,101,99,54,51,49,54,56,57,41,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,54,51,53,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,54,50,51,54,50,52,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,55,48,52,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,55,49,57,55,50,48,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,20),40,105,115,112,101,114,115,101,32,103,55,54,53,55,54,54,55,54,55,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,52,54,48,53,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,19),40,97,52,53,57,57,32,101,120,118,97,114,55,55,57,55,57,53,41,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,52,54,50,51,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,7),40,97,52,54,51,53,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,20),40,97,52,54,50,57,32,46,32,97,114,103,115,55,56,56,56,49,51,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,52,54,49,55,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,15),40,97,52,53,57,51,32,107,55,56,55,55,57,51,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,56,52,56,32,114,56,52,57,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,56,49,55,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,56,54,49,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,56,54,51,32,99,109,100,56,54,52,32,105,110,112,56,54,53,32,114,56,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,56,55,49,32,46,32,109,56,55,50,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,56,56,52,32,46,32,109,56,56,53,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,56,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,7),40,97,53,48,56,55,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,20),40,97,53,48,57,51,32,46,32,114,101,115,117,108,116,115,57,50,52,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,57,49,55,32,112,114,111,99,57,49,56,32,46,32,109,111,100,101,57,49,57,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,7),40,97,53,49,49,49,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,20),40,97,53,49,49,55,32,46,32,114,101,115,117,108,116,115,57,51,52,41,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,57,50,55,32,112,114,111,99,57,50,56,32,46,32,109,111,100,101,57,50,57,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,20),40,97,53,49,51,54,32,46,32,114,101,115,117,108,116,115,57,52,52,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,57,51,55,32,116,104,117,110,107,57,51,56,32,46,32,109,111,100,101,57,51,57,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,20),40,97,53,49,53,54,32,46,32,114,101,115,117,108,116,115,57,53,54,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,57,52,57,32,116,104,117,110,107,57,53,48,32,46,32,109,111,100,101,57,53,49,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,49,48,50,55,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,38),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,49,48,51,48,32,112,114,111,99,49,48,51,49,41,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,49,48,51,55,32,115,116,97,116,101,49,48,51,56,41,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,13),40,97,53,50,55,49,32,115,49,48,52,56,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,27),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,49,48,52,54,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,115,105,103,115,49,48,54,49,32,109,97,115,107,49,48,54,50,41};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,49,48,55,48,41};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,22),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,49,48,55,53,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,49,48,56,51,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,41),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,49,49,53,53,32,46,32,116,109,112,49,49,53,52,49,49,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,49,56,41,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,43),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,49,49,57,56,32,46,32,116,109,112,49,49,57,55,49,49,57,57,41,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,16),40,95,101,110,115,117,114,101,45,103,114,111,117,112,115,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,53,52,41,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,49,50,54,55,32,108,115,116,49,50,55,51,32,105,49,50,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,49,50,54,51,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,35),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,49,51,48,48,32,105,100,49,51,48,49,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,34),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,49,51,55,50,32,109,49,51,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,42),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,49,51,56,48,32,117,105,100,49,51,56,49,32,103,105,100,49,51,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,49,51,57,53,32,97,99,99,49,51,57,54,32,108,111,99,49,51,57,55,41,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,48,53,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,48,57,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,49,52,52,50,32,110,101,119,49,52,52,51,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,49,52,53,52,41,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,27),40,102,105,108,101,45,108,105,110,107,32,111,108,100,49,52,55,56,32,110,101,119,49,52,55,57,41,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,20),40,109,111,100,101,32,105,110,112,49,52,57,53,32,109,49,52,57,54,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,108,111,99,49,53,49,52,32,102,100,49,53,49,53,32,105,110,112,49,53,49,54,32,114,49,53,49,55,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,33),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,49,53,50,50,32,46,32,109,49,53,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,34),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,49,53,50,54,32,46,32,109,49,53,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,23),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,49,53,51,52,41,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,36),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,49,53,53,48,32,46,32,110,101,119,49,53,53,49,41,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,8),40,114,101,97,100,121,63,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,7),40,102,101,116,99,104,41,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,7),40,97,54,51,48,56,41,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,7),40,97,54,51,50,49,41,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,7),40,97,54,51,51,51,41,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,7),40,97,54,51,53,52,41,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,110,49,54,55,54,32,109,49,54,55,55,32,115,116,97,114,116,49,54,55,56,41,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,41),40,97,54,51,54,51,32,112,111,114,116,49,54,54,57,32,110,49,54,55,48,32,100,101,115,116,49,54,55,49,32,115,116,97,114,116,49,54,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,24),40,98,117,109,112,101,114,32,99,117,114,49,55,49,50,32,112,116,114,49,55,49,51,41};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,7),40,97,54,53,50,53,41,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,42),40,97,54,53,51,49,32,100,101,115,116,49,55,53,50,49,55,53,51,49,55,53,55,32,99,111,110,116,63,49,55,53,52,49,55,53,53,49,55,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,49,55,48,57,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,26),40,97,54,52,51,57,32,112,111,114,116,49,55,48,52,32,108,105,109,105,116,49,55,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,49,53,56,54,32,110,111,110,98,108,111,99,107,105,110,103,63,49,53,57,56,32,98,117,102,105,49,53,57,57,32,111,110,45,99,108,111,115,101,49,54,48,48,32,109,111,114,101,63,49,54,48,49,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,69),40,100,101,102,45,109,111,114,101,63,49,53,57,49,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,50,49,55,55,50,32,37,98,117,102,105,49,53,56,51,49,55,55,51,32,37,111,110,45,99,108,111,115,101,49,53,56,52,49,55,55,52,41,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,53,57,48,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,50,49,55,55,56,32,37,98,117,102,105,49,53,56,51,49,55,55,57,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,53,56,57,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,50,49,55,56,51,41,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,56,41,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,62),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,53,55,50,32,110,97,109,49,53,55,51,32,102,100,49,53,55,52,32,46,32,116,109,112,49,53,55,49,49,53,55,53,41,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,22),40,112,111,107,101,32,115,116,114,49,56,52,53,32,108,101,110,49,56,52,54,41,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,15),40,97,54,55,50,50,32,115,116,114,49,56,57,51,41,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,7),40,97,54,55,50,56,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,7),40,97,54,55,52,57,41,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,16),40,102,95,54,55,53,56,32,115,116,114,49,56,54,48,41};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,32,114,101,109,49,56,55,49,32,115,116,97,114,116,49,56,55,50,32,108,101,110,49,56,55,51,41};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,16),40,102,95,54,55,55,51,32,115,116,114,49,56,54,55,41};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,49),40,98,111,100,121,49,56,50,53,32,110,111,110,98,108,111,99,107,105,110,103,63,49,56,51,54,32,98,117,102,105,49,56,51,55,32,111,110,45,99,108,111,115,101,49,56,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,56,50,57,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,56,50,50,49,57,49,48,32,37,98,117,102,105,49,56,50,51,49,57,49,49,41,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,56,50,56,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,56,50,50,49,57,49,53,41,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,56,50,55,41,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,63),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,56,49,50,32,110,97,109,49,56,49,51,32,102,100,49,56,49,52,32,46,32,116,109,112,49,56,49,49,49,56,49,53,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,49,57,51,50,32,111,102,102,49,57,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,32,112,111,114,116,49,57,53,50,32,97,114,103,115,49,57,53,51,32,108,111,99,49,57,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,30),40,101,114,114,32,109,115,103,49,57,55,54,32,108,111,99,107,49,57,55,55,32,108,111,99,49,57,55,56,41,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,49,57,56,48,32,46,32,97,114,103,115,49,57,56,49,41,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,40),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,49,57,56,53,32,46,32,97,114,103,115,49,57,56,54,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,36),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,49,57,57,48,32,46,32,97,114,103,115,49,57,57,49,41,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,50,48,49,53,41,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,34),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,50,48,50,50,32,46,32,109,111,100,101,50,48,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,20),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,50,48,51,50,41,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,50,48,51,56,32,118,97,108,50,48,51,57,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,50,48,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,50,48,54,57,41,0,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,50,48,54,51,41,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,27),40,103,101,116,45,101,110,118,105,114,111,110,109,101,110,116,45,118,97,114,105,97,98,108,101,115,41,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,72),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,50,49,49,55,32,108,101,110,50,49,49,56,32,112,114,111,116,50,49,49,57,32,102,108,97,103,50,49,50,48,32,102,100,50,49,50,49,32,46,32,111,102,102,50,49,50,50,41};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,43),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,50,49,53,48,32,46,32,108,101,110,50,49,53,49,41,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,37),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,50,49,54,48,41,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,50,49,54,53,41,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,30),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,50,49,54,57,41,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,28),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,50,49,55,52,41,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,26),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,50,49,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,50,50,49,55,32,46,32,116,109,112,50,50,49,54,50,50,49,56,41,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,36),40,115,116,114,105,110,103,45,62,116,105,109,101,32,116,105,109,50,50,54,49,32,46,32,116,109,112,50,50,54,48,50,50,54,50,41,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,50,50,55,56,41,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,26),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,50,50,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,50,51,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,97,108,97,114,109,33,32,97,50,51,48,57,50,51,49,50,41,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,50,51,49,57,32,109,111,100,101,50,51,50,48,32,46,32,115,105,122,101,50,51,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,50,51,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,50,51,52,56,32,112,111,114,116,50,51,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,50,51,54,54,41};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,50,51,56,49,41};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,7),40,97,55,57,51,50,41,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,50,52,54,53,41,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,55),40,97,55,57,51,56,32,100,105,114,50,52,51,51,50,52,51,52,50,52,52,49,32,102,105,108,50,52,51,53,50,52,51,54,50,52,52,50,32,101,120,116,50,52,51,55,50,52,51,56,50,52,52,51,41,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,50,52,50,56,41,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,50,52,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,18),40,102,95,56,48,53,48,32,97,50,53,48,57,50,53,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,50,52,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,28),40,115,101,116,97,114,103,32,97,50,53,50,50,50,53,50,56,32,97,50,53,50,49,50,53,50,57,41,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,28),40,115,101,116,101,110,118,32,97,50,53,51,55,50,53,52,51,32,97,50,53,51,54,50,53,52,52,41,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,50,53,57,52,32,105,50,54,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,25),40,100,111,108,111,111,112,50,53,56,51,32,97,108,50,53,56,57,32,105,50,53,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,50,53,54,56,32,97,114,103,108,105,115,116,50,53,55,56,32,101,110,118,108,105,115,116,50,53,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,34),40,100,101,102,45,101,110,118,108,105,115,116,50,53,55,49,32,37,97,114,103,108,105,115,116,50,53,54,54,50,54,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,97,114,103,108,105,115,116,50,53,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,50,53,53,56,32,46,32,116,109,112,50,53,53,55,50,53,53,57,41,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,50,54,53,50,32,110,111,104,97,110,103,50,54,53,51,41,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,7),40,97,56,51,51,50,41,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,36),40,97,56,51,51,56,32,101,112,105,100,50,54,57,56,32,101,110,111,114,109,50,54,57,57,32,101,99,111,100,101,50,55,48,48,41,0,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,50,54,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,50,55,49,50,50,55,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,50,55,49,56,32,46,32,115,105,103,50,55,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,50,55,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,50,55,52,55,32,46,32,97,114,103,115,50,55,52,56,41,0,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,7),40,97,56,53,48,56,41,0};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,29),40,97,56,53,49,52,32,95,50,55,57,55,32,102,108,103,50,55,57,56,32,99,111,100,50,55,57,57,41,0,0,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,8),40,102,95,56,52,57,52,41};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,111,110,45,99,108,111,115,101,32,108,111,99,50,55,56,50,32,112,105,100,50,55,56,51,32,99,108,115,118,101,99,50,55,56,52,32,105,100,120,50,55,56,53,32,105,100,120,97,50,55,56,54,32,105,100,120,98,50,55,56,55,41,0,0,0,0};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,7),40,97,56,53,51,55,41,0};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,19),40,97,56,53,52,51,32,105,50,56,49,50,32,111,50,56,49,51,41,0,0,0,0,0};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,101,100,45,112,105,112,101,32,112,111,114,116,50,56,48,53,41,0,0};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,34),40,99,111,110,110,101,99,116,45,112,97,114,101,110,116,32,112,105,112,101,50,56,49,54,32,112,111,114,116,50,56,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,43),40,99,111,110,110,101,99,116,45,99,104,105,108,100,32,112,105,112,101,50,56,50,55,32,112,111,114,116,50,56,50,56,32,115,116,100,102,100,50,56,50,57,41,0,0,0,0,0};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,14),40,115,119,97,112,112,101,100,45,101,110,100,115,41,0,0};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,7),40,97,56,54,49,56,41,0};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,67),40,115,112,97,119,110,32,99,109,100,50,56,52,56,32,97,114,103,115,50,56,52,57,32,101,110,118,50,56,53,48,32,115,116,100,111,117,116,102,50,56,53,49,32,115,116,100,105,110,102,50,56,53,50,32,115,116,100,101,114,114,102,50,56,53,51,41,0,0,0,0,0};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,59),40,105,110,112,117,116,45,112,111,114,116,32,108,111,99,50,56,54,51,32,99,109,100,50,56,54,53,32,112,105,112,101,50,56,54,54,32,115,116,100,102,50,56,54,55,32,111,110,45,99,108,111,115,101,50,56,54,57,41,0,0,0,0,0};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,60),40,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,50,56,55,54,32,99,109,100,50,56,55,56,32,112,105,112,101,50,56,55,57,32,115,116,100,102,50,56,56,48,32,111,110,45,99,108,111,115,101,50,56,56,50,41,0,0,0,0};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,7),40,97,56,54,54,56,41,0};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,50),40,97,56,54,55,52,32,105,110,112,105,112,101,50,57,48,49,32,111,117,116,112,105,112,101,50,57,48,50,32,101,114,114,112,105,112,101,50,57,48,51,32,112,105,100,50,57,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,50,56,57,48,32,99,109,100,50,56,57,49,32,97,114,103,115,50,56,57,50,32,101,110,118,50,56,57,51,32,115,116,100,111,117,116,102,50,56,57,52,32,115,116,100,105,110,102,50,56,57,53,32,115,116,100,101,114,114,102,50,56,57,54,41,0,0,0,0,0};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,21),40,97,56,55,51,49,32,103,50,57,50,54,50,57,50,55,50,57,50,56,41,0,0,0};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,50,57,49,57,41,0,0,0,0,0};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,7),40,97,56,55,52,57,41,0};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,38),40,97,56,55,53,53,32,105,110,50,57,51,56,32,111,117,116,50,57,51,57,32,112,105,100,50,57,52,48,32,101,114,114,50,57,52,49,41,0,0};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,52),40,37,112,114,111,99,101,115,115,32,108,111,99,50,57,49,50,32,101,114,114,63,50,57,49,51,32,99,109,100,50,57,49,52,32,97,114,103,115,50,57,49,53,32,101,110,118,50,57,49,54,41,0,0,0,0};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,50,57,54,51,32,97,114,103,115,50,57,55,51,32,101,110,118,50,57,55,52,41,0,0,0,0,0};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,50,57,54,54,32,37,97,114,103,115,50,57,54,49,50,57,55,56,41,0,0,0,0,0};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,50,57,54,53,41,0,0};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,50,57,53,51,32,46,32,116,109,112,50,57,53,50,50,57,53,52,41,0};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,51,48,48,55,32,97,114,103,115,51,48,49,55,32,101,110,118,51,48,49,56,41,0,0,0,0,0};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,51,48,49,48,32,37,97,114,103,115,51,48,48,53,51,48,50,50,41,0,0,0,0,0};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,51,48,48,57,41,0,0};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,50,57,57,55,32,46,32,116,109,112,50,57,57,54,50,57,57,56,41};
static C_char C_TLS li239[] C_aligned={C_lihdr(0,0,14),40,102,95,57,48,52,53,32,120,51,48,57,50,41,0,0};
static C_char C_TLS li240[] C_aligned={C_lihdr(0,0,7),40,97,56,57,54,56,41,0};
static C_char C_TLS li241[] C_aligned={C_lihdr(0,0,7),40,97,56,57,55,51,41,0};
static C_char C_TLS li242[] C_aligned={C_lihdr(0,0,7),40,97,56,57,57,55,41,0};
static C_char C_TLS li243[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,51,48,57,56,32,114,51,48,57,57,41,0,0,0,0,0};
static C_char C_TLS li244[] C_aligned={C_lihdr(0,0,16),40,102,95,57,48,54,52,32,46,32,95,51,48,56,50,41};
static C_char C_TLS li245[] C_aligned={C_lihdr(0,0,16),40,102,95,57,48,53,54,32,46,32,95,51,48,56,48,41};
static C_char C_TLS li246[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,51,48,53,52,32,97,99,116,105,111,110,51,48,54,53,32,105,100,51,48,54,54,32,108,105,109,105,116,51,48,54,55,41,0,0};
static C_char C_TLS li247[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,51,48,53,56,32,37,97,99,116,105,111,110,51,48,53,49,51,49,51,57,32,37,105,100,51,48,53,50,51,49,52,48,41,0,0,0,0,0};
static C_char C_TLS li248[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,51,48,53,55,32,37,97,99,116,105,111,110,51,48,53,49,51,49,52,52,41,0,0,0,0};
static C_char C_TLS li249[] C_aligned={C_lihdr(0,0,19),40,97,57,48,56,52,32,120,51,49,52,57,32,121,51,49,53,48,41,0,0,0,0,0};
static C_char C_TLS li250[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,51,48,53,54,41};
static C_char C_TLS li251[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,51,48,52,50,32,112,114,101,100,51,48,52,51,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,51,48,52,52,41,0,0,0,0,0};
static C_char C_TLS li252[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,51,49,55,52,41,0,0,0};
static C_char C_TLS li253[] C_aligned={C_lihdr(0,0,15),40,97,57,49,56,51,32,112,105,100,49,52,50,52,41,0};
static C_char C_TLS li254[] C_aligned={C_lihdr(0,0,24),40,97,57,50,48,49,32,112,105,100,49,52,51,51,32,112,103,105,100,49,52,51,52,41};
static C_char C_TLS li255[] C_aligned={C_lihdr(0,0,7),40,97,57,50,50,50,41,0};
static C_char C_TLS li256[] C_aligned={C_lihdr(0,0,14),40,97,57,50,50,53,32,105,100,49,49,51,53,41,0,0};
static C_char C_TLS li257[] C_aligned={C_lihdr(0,0,7),40,97,57,50,52,48,41,0};
static C_char C_TLS li258[] C_aligned={C_lihdr(0,0,14),40,97,57,50,52,51,32,105,100,49,49,50,54,41,0,0};
static C_char C_TLS li259[] C_aligned={C_lihdr(0,0,7),40,97,57,50,53,56,41,0};
static C_char C_TLS li260[] C_aligned={C_lihdr(0,0,14),40,97,57,50,54,49,32,105,100,49,49,49,55,41,0,0};
static C_char C_TLS li261[] C_aligned={C_lihdr(0,0,7),40,97,57,50,55,54,41,0};
static C_char C_TLS li262[] C_aligned={C_lihdr(0,0,14),40,97,57,50,55,57,32,105,100,49,49,48,56,41,0,0};
static C_char C_TLS li263[] C_aligned={C_lihdr(0,0,13),40,97,57,50,57,52,32,110,49,48,57,48,41,0,0,0};
static C_char C_TLS li264[] C_aligned={C_lihdr(0,0,15),40,97,57,51,48,48,32,112,111,114,116,53,48,54,41,0};
static C_char C_TLS li265[] C_aligned={C_lihdr(0,0,34),40,97,57,51,51,55,32,112,111,114,116,53,50,48,32,112,111,115,53,50,49,32,46,32,119,104,101,110,99,101,53,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li266[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k9151 in set-root-directory! in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall stub3166(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3166(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k8390 */
static C_word C_fcall stub2713(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2713(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall stub2708(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2708(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall stub2704(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2704(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub2548(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2548(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k8096 */
static C_word C_fcall stub2539(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2539(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub2533(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2533(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k8077 */
static C_word C_fcall stub2524(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2524(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k8053 */
static C_word C_fcall stub2510(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2510(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub2492(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2492(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2403(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2403(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k7862 */
static C_word C_fcall stub2374(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2374(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k7839 */
static C_word C_fcall stub2359(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2359(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k7728 */
static C_word C_fcall stub2310(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2310(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k7706 */
static C_word C_fcall stub2301(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2301(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2293(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2293(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub2248(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2248(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub2203(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2203(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub2195(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2195(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k7477 */
static C_word C_fcall stub2180(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2180(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k7396 */
static C_word C_fcall stub2141(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2141(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k7334 */
static C_word C_fcall stub2102(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub2102(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k7233 */
static C_word C_fcall stub2053(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2053(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k5992 in k5988 in file-link in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall stub1466(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1466(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k5729 */
static C_word C_fcall stub1291(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1291(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k5598 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub1232(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1232(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from k5591 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1226(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1226(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from k5505 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1184(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1184(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a9222 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall stub1132(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1132(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a9240 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall stub1123(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1123(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a9258 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall stub1114(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1114(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a9276 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall stub1105(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1105(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k3773 */
static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k3763 */
static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k3753 */
static C_word C_fcall stub239(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub239(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k3535 */
static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from k3484 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub46(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub46(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from k3477 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub40(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub40(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k3453 */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9338)
static void C_ccall f_9338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9338)
static void C_ccall f_9338r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9351)
static void C_ccall f_9351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9363)
static void C_ccall f_9363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9357)
static void C_ccall f_9357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9301)
static void C_ccall f_9301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9317)
static void C_ccall f_9317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9305)
static void C_ccall f_9305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9308)
static void C_ccall f_9308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9295)
static void C_ccall f_9295(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9280)
static void C_ccall f_9280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9290)
static void C_ccall f_9290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9277)
static void C_ccall f_9277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9262)
static void C_ccall f_9262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9272)
static void C_ccall f_9272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9259)
static void C_ccall f_9259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5393)
static void C_ccall f_5393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9244)
static void C_ccall f_9244(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9254)
static void C_ccall f_9254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9241)
static void C_ccall f_9241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9226)
static void C_ccall f_9226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9236)
static void C_ccall f_9236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9223)
static void C_ccall f_9223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9202)
static void C_ccall f_9202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9218)
static void C_ccall f_9218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9184)
static void C_ccall f_9184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9197)
static void C_ccall f_9197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9191)
static void C_ccall f_9191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5958)
static void C_ccall f_5958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9161)
static void C_ccall f_9161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9153)
static void C_ccall f_9153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8902)
static void C_ccall f_8902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8902)
static void C_ccall f_8902r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9079)
static void C_fcall f_9079(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9085)
static void C_ccall f_9085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9074)
static void C_fcall f_9074(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9069)
static void C_fcall f_9069(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8904)
static void C_fcall f_8904(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9056)
static void C_ccall f_9056(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9064)
static void C_ccall f_9064(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8911)
static void C_fcall f_8911(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9044)
static void C_ccall f_9044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8921)
static void C_ccall f_8921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8923)
static void C_fcall f_8923(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9024)
static void C_ccall f_9024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9031)
static void C_ccall f_9031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9018)
static void C_ccall f_9018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8957)
static void C_ccall f_8957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9011)
static void C_ccall f_9011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9008)
static void C_ccall f_9008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8998)
static void C_ccall f_8998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8974)
static void C_ccall f_8974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8996)
static void C_ccall f_8996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8982)
static void C_ccall f_8982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8989)
static void C_ccall f_8989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8986)
static void C_ccall f_8986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8969)
static void C_ccall f_8969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8967)
static void C_ccall f_8967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9045)
static void C_ccall f_9045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8842)
static void C_ccall f_8842(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8842)
static void C_ccall f_8842r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8854)
static void C_fcall f_8854(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8849)
static void C_fcall f_8849(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8844)
static void C_fcall f_8844(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8782)
static void C_ccall f_8782(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8782)
static void C_ccall f_8782r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8794)
static void C_fcall f_8794(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8789)
static void C_fcall f_8789(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8784)
static void C_fcall f_8784(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8721)
static void C_fcall f_8721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8776)
static void C_ccall f_8776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8780)
static void C_ccall f_8780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8742)
static void C_ccall f_8742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8745)
static void C_ccall f_8745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8756)
static void C_ccall f_8756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8723)
static void C_fcall f_8723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8732)
static void C_ccall f_8732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8663)
static void C_ccall f_8663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8675)
static void C_ccall f_8675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8706)
static void C_ccall f_8706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8686)
static void C_ccall f_8686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8702)
static void C_ccall f_8702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8690)
static void C_ccall f_8690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8698)
static void C_ccall f_8698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8694)
static void C_ccall f_8694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8669)
static void C_ccall f_8669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8652)
static void C_fcall f_8652(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8656)
static void C_ccall f_8656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8641)
static void C_fcall f_8641(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8645)
static void C_ccall f_8645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8596)
static void C_fcall f_8596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8600)
static void C_ccall f_8600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8603)
static void C_ccall f_8603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8606)
static void C_ccall f_8606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8619)
static void C_ccall f_8619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8623)
static void C_ccall f_8623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8626)
static void C_ccall f_8626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8629)
static void C_ccall f_8629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8617)
static void C_ccall f_8617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8580)
static C_word C_fcall f_8580(C_word *a,C_word t0);
C_noret_decl(f_8563)
static void C_fcall f_8563(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8576)
static void C_ccall f_8576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8488)
static void C_ccall f_8488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8549)
static void C_fcall f_8549(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8529)
static void C_fcall f_8529(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8538)
static void C_ccall f_8538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8492)
static void C_fcall f_8492(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8494)
static void C_ccall f_8494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8515)
static void C_ccall f_8515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8509)
static void C_ccall f_8509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8436)
static void C_ccall f_8436(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8436)
static void C_ccall f_8436r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8443)
static void C_ccall f_8443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8462)
static void C_ccall f_8462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8466)
static void C_ccall f_8466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8421)
static void C_ccall f_8421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8425)
static void C_ccall f_8425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8394)
static void C_ccall f_8394(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8394)
static void C_ccall f_8394r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8387)
static void C_ccall f_8387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8384)
static void C_ccall f_8384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8381)
static void C_ccall f_8381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8339)
static void C_ccall f_8339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8333)
static void C_ccall f_8333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8286)
static void C_ccall f_8286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8104)
static void C_ccall f_8104(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8104)
static void C_ccall f_8104r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8238)
static void C_fcall f_8238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8233)
static void C_fcall f_8233(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8106)
static void C_fcall f_8106(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8116)
static void C_ccall f_8116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8124)
static void C_fcall f_8124(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8170)
static C_word C_fcall f_8170(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8137)
static void C_fcall f_8137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8162)
static void C_ccall f_8162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8140)
static void C_ccall f_8140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8085)
static C_word C_fcall f_8085(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8066)
static C_word C_fcall f_8066(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8024)
static void C_ccall f_8024(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8024)
static void C_ccall f_8024r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8046)
static void C_ccall f_8046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8050)
static void C_ccall f_8050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7918)
static void C_fcall f_7918(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8016)
static void C_ccall f_8016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7943)
static void C_ccall f_7943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7946)
static void C_ccall f_7946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7949)
static void C_ccall f_7949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7958)
static void C_fcall f_7958(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7985)
static void C_ccall f_7985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7989)
static void C_ccall f_7989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7933)
static void C_ccall f_7933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7900)
static void C_ccall f_7900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7865)
static void C_ccall f_7865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7842)
static void C_ccall f_7842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7810)
static void C_fcall f_7810(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7814)
static void C_ccall f_7814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7795)
static void C_ccall f_7795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7798)
static void C_ccall f_7798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7736)
static void C_ccall f_7736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7742)
static void C_ccall f_7742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7725)
static void C_ccall f_7725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7709)
static void C_ccall f_7709(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7709)
static void C_ccall f_7709r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7697)
static void C_ccall f_7697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7669)
static void C_ccall f_7669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7676)
static void C_ccall f_7676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7648)
static void C_ccall f_7648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7595)
static void C_ccall f_7595(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7595)
static void C_ccall f_7595r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7599)
static void C_ccall f_7599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7612)
static void C_ccall f_7612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7616)
static void C_ccall f_7616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7517)
static void C_ccall f_7517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7545)
static void C_ccall f_7545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7542)
static void C_ccall f_7542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7532)
static void C_ccall f_7532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7480)
static void C_ccall f_7480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7484)
static void C_ccall f_7484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7461)
static void C_ccall f_7461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7452)
static void C_ccall f_7452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7446)
static void C_ccall f_7446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7402)
static void C_ccall f_7402(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7402)
static void C_ccall f_7402r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7350)
static void C_ccall f_7350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7369)
static void C_ccall f_7369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7356)
static void C_ccall f_7356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7242)
static void C_fcall f_7242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7246)
static void C_ccall f_7246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7254)
static void C_fcall f_7254(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7280)
static void C_ccall f_7280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7272)
static void C_ccall f_7272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7216)
static void C_ccall f_7216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7224)
static void C_ccall f_7224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7199)
static void C_ccall f_7199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7210)
static void C_ccall f_7210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7214)
static void C_ccall f_7214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7173)
static void C_ccall f_7173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7197)
static void C_ccall f_7197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7180)
static void C_ccall f_7180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7130)
static void C_ccall f_7130(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7130)
static void C_ccall f_7130r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7137)
static void C_fcall f_7137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7154)
static void C_ccall f_7154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7102)
static void C_ccall f_7102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7054)
static void C_ccall f_7054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7032)
static void C_fcall f_7032(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6958)
static void C_fcall f_6958(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6980)
static void C_ccall f_6980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6986)
static void C_fcall f_6986(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6919)
static void C_ccall f_6919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6947)
static void C_ccall f_6947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6943)
static void C_ccall f_6943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6936)
static void C_ccall f_6936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6856)
static void C_fcall f_6856(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6851)
static void C_fcall f_6851(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6846)
static void C_fcall f_6846(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6662)
static void C_fcall f_6662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6666)
static void C_ccall f_6666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6772)
static void C_ccall f_6772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6773)
static void C_ccall f_6773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6790)
static void C_fcall f_6790(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6714)
static void C_fcall f_6714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6750)
static void C_ccall f_6750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6739)
static void C_ccall f_6739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6723)
static void C_ccall f_6723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6718)
static void C_ccall f_6718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6721)
static void C_ccall f_6721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6668)
static void C_fcall f_6668(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_ccall f_6684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6582)
static void C_fcall f_6582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_fcall f_6577(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6572)
static void C_fcall f_6572(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6567)
static void C_fcall f_6567(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6188)
static void C_fcall f_6188(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6440)
static void C_ccall f_6440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6446)
static void C_fcall f_6446(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6532)
static void C_ccall f_6532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6372)
static void C_fcall f_6372(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6374)
static void C_fcall f_6374(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6359)
static void C_ccall f_6359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6344)
static void C_ccall f_6344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6307)
static void C_ccall f_6307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6222)
static void C_fcall f_6222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6234)
static void C_fcall f_6234(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6271)
static void C_ccall f_6271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6274)
static void C_ccall f_6274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6250)
static void C_ccall f_6250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6214)
static C_word C_fcall f_6214(C_word t0);
C_noret_decl(f_6199)
static void C_fcall f_6199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6159)
static void C_ccall f_6159(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6159)
static void C_ccall f_6159r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6166)
static void C_fcall f_6166(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6169)
static void C_ccall f_6169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6114)
static void C_ccall f_6114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6118)
static void C_ccall f_6118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6136)
static void C_ccall f_6136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6112)
static void C_ccall f_6112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6071)
static void C_fcall f_6071(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6084)
static void C_ccall f_6084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6034)
static void C_fcall f_6034(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6042)
static void C_ccall f_6042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5990)
static void C_ccall f_5990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5959)
static void C_ccall f_5959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5983)
static void C_ccall f_5983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5967)
static void C_ccall f_5967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5954)
static void C_ccall f_5954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5942)
static void C_ccall f_5942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5950)
static void C_ccall f_5950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5946)
static void C_ccall f_5946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5912)
static void C_ccall f_5912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5906)
static void C_ccall f_5906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5896)
static void C_ccall f_5896(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5860)
static void C_fcall f_5860(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5830)
static void C_ccall f_5830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5727)
static void C_ccall f_5727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5674)
static void C_fcall f_5674(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5660)
static void C_ccall f_5660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5606)
static void C_ccall f_5606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_ccall f_5612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_fcall f_5617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5595)
static C_word C_fcall f_5595(C_word t0);
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_fcall f_5516(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_fcall f_5539(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5496)
static void C_ccall f_5496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5482)
static void C_ccall f_5482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_fcall f_5410(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5353)
static void C_ccall f_5353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5364)
static void C_ccall f_5364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5376)
static void C_ccall f_5376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5316)
static void C_ccall f_5316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5284)
static void C_fcall f_5284(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5131)
static void C_ccall f_5131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_fcall f_4976(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_fcall f_4970(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static C_word C_fcall f_4958(C_word t0);
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4768)
static void C_fcall f_4768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_fcall f_4787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_fcall f_4831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_fcall f_4657(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4725)
static void C_fcall f_4725(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4585)
static void C_fcall f_4585(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4600)
static void C_ccall f_4600(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static C_word C_fcall f_4574(C_word t0);
C_noret_decl(f_4569)
static void C_fcall f_4569(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4498)
static void C_ccall f_4498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4446)
static void C_fcall f_4446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_fcall f_4441(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4343)
static void C_fcall f_4343(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4374)
static void C_fcall f_4374(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4396)
static void C_fcall f_4396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4100)
static void C_ccall f_4100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4107)
static void C_ccall f_4107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_fcall f_3968(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3801)
static void C_fcall f_3801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_fcall f_3840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3844)
static void C_fcall f_3844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3766)
static C_word C_fcall f_3766(C_word t0,C_word t1);
C_noret_decl(f_3756)
static C_word C_fcall f_3756(C_word t0,C_word t1);
C_noret_decl(f_3750)
static C_word C_fcall f_3750(C_word t0);
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3650)
static void C_ccall f_3650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9079)
static void C_fcall trf_9079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9079(t0,t1);}

C_noret_decl(trf_9074)
static void C_fcall trf_9074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9074(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9074(t0,t1,t2);}

C_noret_decl(trf_9069)
static void C_fcall trf_9069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9069(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9069(t0,t1,t2,t3);}

C_noret_decl(trf_8904)
static void C_fcall trf_8904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8904(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8904(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8911)
static void C_fcall trf_8911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8911(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8911(t0,t1);}

C_noret_decl(trf_8923)
static void C_fcall trf_8923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8923(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8923(t0,t1,t2,t3);}

C_noret_decl(trf_8854)
static void C_fcall trf_8854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8854(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8854(t0,t1);}

C_noret_decl(trf_8849)
static void C_fcall trf_8849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8849(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8849(t0,t1,t2);}

C_noret_decl(trf_8844)
static void C_fcall trf_8844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8844(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8844(t0,t1,t2,t3);}

C_noret_decl(trf_8794)
static void C_fcall trf_8794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8794(t0,t1);}

C_noret_decl(trf_8789)
static void C_fcall trf_8789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8789(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8789(t0,t1,t2);}

C_noret_decl(trf_8784)
static void C_fcall trf_8784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8784(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8784(t0,t1,t2,t3);}

C_noret_decl(trf_8721)
static void C_fcall trf_8721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8721(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8721(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8723)
static void C_fcall trf_8723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8723(t0,t1,t2);}

C_noret_decl(trf_8652)
static void C_fcall trf_8652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8652(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8652(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8641)
static void C_fcall trf_8641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8641(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8641(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8596)
static void C_fcall trf_8596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8596(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8596(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8563)
static void C_fcall trf_8563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8563(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8563(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8549)
static void C_fcall trf_8549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8549(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8549(t0,t1,t2,t3);}

C_noret_decl(trf_8529)
static void C_fcall trf_8529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8529(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8529(t0,t1,t2);}

C_noret_decl(trf_8492)
static void C_fcall trf_8492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8492(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8492(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8238)
static void C_fcall trf_8238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8238(t0,t1);}

C_noret_decl(trf_8233)
static void C_fcall trf_8233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8233(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8233(t0,t1,t2);}

C_noret_decl(trf_8106)
static void C_fcall trf_8106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8106(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8106(t0,t1,t2,t3);}

C_noret_decl(trf_8124)
static void C_fcall trf_8124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8124(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8124(t0,t1,t2,t3);}

C_noret_decl(trf_8137)
static void C_fcall trf_8137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8137(t0,t1);}

C_noret_decl(trf_7918)
static void C_fcall trf_7918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7918(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7918(t0,t1,t2);}

C_noret_decl(trf_7958)
static void C_fcall trf_7958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7958(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7958(t0,t1,t2);}

C_noret_decl(trf_7810)
static void C_fcall trf_7810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7810(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7810(t0,t1,t2);}

C_noret_decl(trf_7242)
static void C_fcall trf_7242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7242(t0,t1,t2);}

C_noret_decl(trf_7254)
static void C_fcall trf_7254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7254(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7254(t0,t1,t2);}

C_noret_decl(trf_7137)
static void C_fcall trf_7137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7137(t0,t1);}

C_noret_decl(trf_7032)
static void C_fcall trf_7032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7032(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7032(t0,t1,t2,t3);}

C_noret_decl(trf_6958)
static void C_fcall trf_6958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6958(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6958(t0,t1,t2,t3);}

C_noret_decl(trf_6986)
static void C_fcall trf_6986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6986(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6986(t0,t1);}

C_noret_decl(trf_6856)
static void C_fcall trf_6856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6856(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6856(t0,t1);}

C_noret_decl(trf_6851)
static void C_fcall trf_6851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6851(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6851(t0,t1,t2);}

C_noret_decl(trf_6846)
static void C_fcall trf_6846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6846(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6846(t0,t1,t2,t3);}

C_noret_decl(trf_6662)
static void C_fcall trf_6662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6662(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6662(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6790)
static void C_fcall trf_6790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6790(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6790(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6714)
static void C_fcall trf_6714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6714(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6714(t0,t1);}

C_noret_decl(trf_6668)
static void C_fcall trf_6668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6668(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6668(t0,t1,t2,t3);}

C_noret_decl(trf_6582)
static void C_fcall trf_6582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6582(t0,t1);}

C_noret_decl(trf_6577)
static void C_fcall trf_6577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6577(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6577(t0,t1,t2);}

C_noret_decl(trf_6572)
static void C_fcall trf_6572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6572(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6572(t0,t1,t2,t3);}

C_noret_decl(trf_6567)
static void C_fcall trf_6567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6567(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6567(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6188)
static void C_fcall trf_6188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6188(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6188(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6446)
static void C_fcall trf_6446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6446(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6446(t0,t1,t2);}

C_noret_decl(trf_6372)
static void C_fcall trf_6372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6372(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6372(t0,t1);}

C_noret_decl(trf_6374)
static void C_fcall trf_6374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6374(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6374(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6222)
static void C_fcall trf_6222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6222(t0,t1);}

C_noret_decl(trf_6234)
static void C_fcall trf_6234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6234(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6234(t0,t1);}

C_noret_decl(trf_6199)
static void C_fcall trf_6199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6199(t0,t1);}

C_noret_decl(trf_6166)
static void C_fcall trf_6166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6166(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6166(t0,t1);}

C_noret_decl(trf_6071)
static void C_fcall trf_6071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6071(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6071(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6034)
static void C_fcall trf_6034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6034(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6034(t0,t1,t2);}

C_noret_decl(trf_5860)
static void C_fcall trf_5860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5860(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5860(t0,t1,t2,t3);}

C_noret_decl(trf_5674)
static void C_fcall trf_5674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5674(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5674(t0,t1,t2,t3);}

C_noret_decl(trf_5617)
static void C_fcall trf_5617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5617(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5617(t0,t1,t2);}

C_noret_decl(trf_5516)
static void C_fcall trf_5516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5516(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5516(t0,t1);}

C_noret_decl(trf_5539)
static void C_fcall trf_5539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5539(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5539(t0,t1,t2);}

C_noret_decl(trf_5410)
static void C_fcall trf_5410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5410(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5410(t0,t1);}

C_noret_decl(trf_5284)
static void C_fcall trf_5284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5284(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5284(t0,t1,t2,t3);}

C_noret_decl(trf_4976)
static void C_fcall trf_4976(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4976(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4976(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4970)
static void C_fcall trf_4970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4970(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4970(t0,t1);}

C_noret_decl(trf_4768)
static void C_fcall trf_4768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4768(t0,t1);}

C_noret_decl(trf_4787)
static void C_fcall trf_4787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4787(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4787(t0,t1);}

C_noret_decl(trf_4831)
static void C_fcall trf_4831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4831(t0,t1);}

C_noret_decl(trf_4657)
static void C_fcall trf_4657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4657(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4657(t0,t1,t2,t3);}

C_noret_decl(trf_4725)
static void C_fcall trf_4725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4725(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4725(t0,t1);}

C_noret_decl(trf_4585)
static void C_fcall trf_4585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4585(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4585(t0,t1);}

C_noret_decl(trf_4569)
static void C_fcall trf_4569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4569(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4569(t0,t1);}

C_noret_decl(trf_4446)
static void C_fcall trf_4446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4446(t0,t1);}

C_noret_decl(trf_4441)
static void C_fcall trf_4441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4441(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4441(t0,t1,t2);}

C_noret_decl(trf_4343)
static void C_fcall trf_4343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4343(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4343(t0,t1,t2,t3);}

C_noret_decl(trf_4374)
static void C_fcall trf_4374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4374(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4374(t0,t1);}

C_noret_decl(trf_4396)
static void C_fcall trf_4396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4396(t0,t1);}

C_noret_decl(trf_3968)
static void C_fcall trf_3968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3968(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3968(t0,t1,t2,t3);}

C_noret_decl(trf_3801)
static void C_fcall trf_3801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3801(t0,t1);}

C_noret_decl(trf_3840)
static void C_fcall trf_3840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3840(t0,t1);}

C_noret_decl(trf_3844)
static void C_fcall trf_3844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3844(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3340)){
C_save(t1);
C_rereclaim2(3340*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,466);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_h_intern(&lf[51],9,"file-open");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[53]=C_h_intern(&lf[53],17,"\003sysmake-c-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysexpand-home-path");
lf[55]=C_h_intern(&lf[55],10,"file-close");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],10,"file-write");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[65]=C_h_intern(&lf[65],12,"file-mkstemp");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[68]=C_h_intern(&lf[68],11,"file-select");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[70]=C_h_intern(&lf[70],12,"\003sysfor-each");
lf[71]=C_h_intern(&lf[71],8,"seek/set");
lf[72]=C_h_intern(&lf[72],8,"seek/end");
lf[73]=C_h_intern(&lf[73],8,"seek/cur");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[77]=C_h_intern(&lf[77],9,"file-stat");
lf[78]=C_h_intern(&lf[78],9,"file-size");
lf[79]=C_h_intern(&lf[79],22,"file-modification-time");
lf[80]=C_h_intern(&lf[80],16,"file-access-time");
lf[81]=C_h_intern(&lf[81],16,"file-change-time");
lf[82]=C_h_intern(&lf[82],10,"file-owner");
lf[83]=C_h_intern(&lf[83],16,"file-permissions");
lf[84]=C_h_intern(&lf[84],13,"regular-file\077");
lf[85]=C_h_intern(&lf[85],14,"symbolic-link\077");
lf[86]=C_h_intern(&lf[86],13,"stat-regular\077");
lf[87]=C_h_intern(&lf[87],15,"stat-directory\077");
lf[88]=C_h_intern(&lf[88],17,"stat-char-device\077");
lf[89]=C_h_intern(&lf[89],18,"stat-block-device\077");
lf[90]=C_h_intern(&lf[90],10,"stat-fifo\077");
lf[91]=C_h_intern(&lf[91],13,"stat-symlink\077");
lf[92]=C_h_intern(&lf[92],12,"stat-socket\077");
lf[93]=C_h_intern(&lf[93],13,"file-position");
lf[94]=C_h_intern(&lf[94],16,"create-directory");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot stat file");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\026path segment is a file");
lf[99]=C_h_intern(&lf[99],12,"file-exists\077");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[101]=C_h_intern(&lf[101],12,"string-split");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[103]=C_h_intern(&lf[103],14,"canonical-path");
lf[104]=C_h_intern(&lf[104],16,"change-directory");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[106]=C_h_intern(&lf[106],16,"delete-directory");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[108]=C_h_intern(&lf[108],10,"string-ref");
lf[109]=C_h_intern(&lf[109],6,"string");
lf[110]=C_h_intern(&lf[110],9,"directory");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[112]=C_h_intern(&lf[112],16,"\003sysmake-pointer");
lf[113]=C_h_intern(&lf[113],17,"current-directory");
lf[114]=C_h_intern(&lf[114],10,"directory\077");
lf[115]=C_h_intern(&lf[115],13,"\003sysfile-info");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[117]=C_h_intern(&lf[117],5,"null\077");
lf[118]=C_h_intern(&lf[118],6,"char=\077");
lf[119]=C_h_intern(&lf[119],8,"string=\077");
lf[120]=C_h_intern(&lf[120],16,"char-alphabetic\077");
lf[121]=C_h_intern(&lf[121],18,"string-intersperse");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[123]=C_h_intern(&lf[123],6,"getenv");
lf[124]=C_h_intern(&lf[124],17,"current-user-name");
lf[125]=C_h_intern(&lf[125],9,"condition");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[127]=C_h_intern(&lf[127],22,"with-exception-handler");
lf[128]=C_h_intern(&lf[128],30,"call-with-current-continuation");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[132]=C_h_intern(&lf[132],7,"reverse");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[143]=C_h_intern(&lf[143],5,"\000text");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[146]=C_h_intern(&lf[146],13,"\003sysmake-port");
lf[147]=C_h_intern(&lf[147],21,"\003sysstream-port-class");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[149]=C_h_intern(&lf[149],6,"stream");
lf[150]=C_h_intern(&lf[150],15,"open-input-pipe");
lf[151]=C_h_intern(&lf[151],7,"\000binary");
lf[152]=C_h_intern(&lf[152],16,"open-output-pipe");
lf[153]=C_h_intern(&lf[153],16,"close-input-pipe");
lf[154]=C_h_intern(&lf[154],23,"close-input/output-pipe");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[156]=C_h_intern(&lf[156],14,"\003syscheck-port");
lf[157]=C_h_intern(&lf[157],17,"close-output-pipe");
lf[158]=C_h_intern(&lf[158],20,"call-with-input-pipe");
lf[159]=C_h_intern(&lf[159],21,"call-with-output-pipe");
lf[160]=C_h_intern(&lf[160],20,"with-input-from-pipe");
lf[161]=C_h_intern(&lf[161],18,"\003sysstandard-input");
lf[162]=C_h_intern(&lf[162],19,"with-output-to-pipe");
lf[163]=C_h_intern(&lf[163],19,"\003sysstandard-output");
lf[164]=C_h_intern(&lf[164],11,"create-pipe");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[166]=C_h_intern(&lf[166],11,"signal/term");
lf[167]=C_h_intern(&lf[167],11,"signal/kill");
lf[168]=C_h_intern(&lf[168],10,"signal/int");
lf[169]=C_h_intern(&lf[169],10,"signal/hup");
lf[170]=C_h_intern(&lf[170],10,"signal/fpe");
lf[171]=C_h_intern(&lf[171],10,"signal/ill");
lf[172]=C_h_intern(&lf[172],11,"signal/segv");
lf[173]=C_h_intern(&lf[173],11,"signal/abrt");
lf[174]=C_h_intern(&lf[174],11,"signal/trap");
lf[175]=C_h_intern(&lf[175],11,"signal/quit");
lf[176]=C_h_intern(&lf[176],11,"signal/alrm");
lf[177]=C_h_intern(&lf[177],13,"signal/vtalrm");
lf[178]=C_h_intern(&lf[178],11,"signal/prof");
lf[179]=C_h_intern(&lf[179],9,"signal/io");
lf[180]=C_h_intern(&lf[180],10,"signal/urg");
lf[181]=C_h_intern(&lf[181],11,"signal/chld");
lf[182]=C_h_intern(&lf[182],11,"signal/cont");
lf[183]=C_h_intern(&lf[183],11,"signal/stop");
lf[184]=C_h_intern(&lf[184],11,"signal/tstp");
lf[185]=C_h_intern(&lf[185],11,"signal/pipe");
lf[186]=C_h_intern(&lf[186],11,"signal/xcpu");
lf[187]=C_h_intern(&lf[187],11,"signal/xfsz");
lf[188]=C_h_intern(&lf[188],11,"signal/usr1");
lf[189]=C_h_intern(&lf[189],11,"signal/usr2");
lf[190]=C_h_intern(&lf[190],12,"signal/winch");
lf[191]=C_h_intern(&lf[191],12,"signals-list");
lf[192]=C_h_intern(&lf[192],18,"\003sysinterrupt-hook");
lf[193]=C_h_intern(&lf[193],14,"signal-handler");
lf[194]=C_h_intern(&lf[194],19,"set-signal-handler!");
lf[195]=C_h_intern(&lf[195],16,"set-signal-mask!");
lf[196]=C_h_intern(&lf[196],14,"\000process-error");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[198]=C_h_intern(&lf[198],11,"signal-mask");
lf[199]=C_h_intern(&lf[199],14,"signal-masked\077");
lf[200]=C_h_intern(&lf[200],12,"signal-mask!");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[202]=C_h_intern(&lf[202],14,"signal-unmask!");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[204]=C_h_intern(&lf[204],18,"system-information");
lf[205]=C_h_intern(&lf[205],25,"\003syspeek-nonnull-c-string");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[207]=C_h_intern(&lf[207],15,"current-user-id");
lf[208]=C_h_intern(&lf[208],25,"current-effective-user-id");
lf[209]=C_h_intern(&lf[209],16,"current-group-id");
lf[210]=C_h_intern(&lf[210],26,"current-effective-group-id");
lf[211]=C_h_intern(&lf[211],16,"user-information");
lf[212]=C_h_intern(&lf[212],6,"vector");
lf[213]=C_h_intern(&lf[213],4,"list");
lf[214]=C_h_intern(&lf[214],27,"current-effective-user-name");
lf[215]=C_h_intern(&lf[215],17,"group-information");
lf[217]=C_h_intern(&lf[217],10,"get-groups");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[221]=C_h_intern(&lf[221],11,"set-groups!");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[224]=C_h_intern(&lf[224],17,"initialize-groups");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[226]=C_h_intern(&lf[226],10,"errno/perm");
lf[227]=C_h_intern(&lf[227],11,"errno/noent");
lf[228]=C_h_intern(&lf[228],10,"errno/srch");
lf[229]=C_h_intern(&lf[229],10,"errno/intr");
lf[230]=C_h_intern(&lf[230],8,"errno/io");
lf[231]=C_h_intern(&lf[231],12,"errno/noexec");
lf[232]=C_h_intern(&lf[232],10,"errno/badf");
lf[233]=C_h_intern(&lf[233],11,"errno/child");
lf[234]=C_h_intern(&lf[234],11,"errno/nomem");
lf[235]=C_h_intern(&lf[235],11,"errno/acces");
lf[236]=C_h_intern(&lf[236],11,"errno/fault");
lf[237]=C_h_intern(&lf[237],10,"errno/busy");
lf[238]=C_h_intern(&lf[238],12,"errno/notdir");
lf[239]=C_h_intern(&lf[239],11,"errno/isdir");
lf[240]=C_h_intern(&lf[240],11,"errno/inval");
lf[241]=C_h_intern(&lf[241],11,"errno/mfile");
lf[242]=C_h_intern(&lf[242],11,"errno/nospc");
lf[243]=C_h_intern(&lf[243],11,"errno/spipe");
lf[244]=C_h_intern(&lf[244],10,"errno/pipe");
lf[245]=C_h_intern(&lf[245],11,"errno/again");
lf[246]=C_h_intern(&lf[246],10,"errno/rofs");
lf[247]=C_h_intern(&lf[247],11,"errno/exist");
lf[248]=C_h_intern(&lf[248],16,"errno/wouldblock");
lf[249]=C_h_intern(&lf[249],10,"errno/2big");
lf[250]=C_h_intern(&lf[250],12,"errno/deadlk");
lf[251]=C_h_intern(&lf[251],9,"errno/dom");
lf[252]=C_h_intern(&lf[252],10,"errno/fbig");
lf[253]=C_h_intern(&lf[253],11,"errno/ilseq");
lf[254]=C_h_intern(&lf[254],11,"errno/mlink");
lf[255]=C_h_intern(&lf[255],17,"errno/nametoolong");
lf[256]=C_h_intern(&lf[256],11,"errno/nfile");
lf[257]=C_h_intern(&lf[257],11,"errno/nodev");
lf[258]=C_h_intern(&lf[258],11,"errno/nolck");
lf[259]=C_h_intern(&lf[259],11,"errno/nosys");
lf[260]=C_h_intern(&lf[260],14,"errno/notempty");
lf[261]=C_h_intern(&lf[261],11,"errno/notty");
lf[262]=C_h_intern(&lf[262],10,"errno/nxio");
lf[263]=C_h_intern(&lf[263],11,"errno/range");
lf[264]=C_h_intern(&lf[264],10,"errno/xdev");
lf[265]=C_h_intern(&lf[265],16,"change-file-mode");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[267]=C_h_intern(&lf[267],17,"change-file-owner");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[269]=C_h_intern(&lf[269],17,"file-read-access\077");
lf[270]=C_h_intern(&lf[270],18,"file-write-access\077");
lf[271]=C_h_intern(&lf[271],20,"file-execute-access\077");
lf[272]=C_h_intern(&lf[272],14,"create-session");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[274]=C_h_intern(&lf[274],16,"process-group-id");
lf[275]=C_h_intern(&lf[275],20,"create-symbolic-link");
lf[276]=C_h_intern(&lf[276],18,"create-symbol-link");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[278]=C_h_intern(&lf[278],9,"substring");
lf[279]=C_h_intern(&lf[279],18,"read-symbolic-link");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[281]=C_h_intern(&lf[281],9,"file-link");
lf[282]=C_h_intern(&lf[282],9,"hard-link");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[284]=C_h_intern(&lf[284],12,"fileno/stdin");
lf[285]=C_h_intern(&lf[285],13,"fileno/stdout");
lf[286]=C_h_intern(&lf[286],13,"fileno/stderr");
lf[287]=C_h_intern(&lf[287],7,"\000append");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[295]=C_h_intern(&lf[295],16,"open-input-file*");
lf[296]=C_h_intern(&lf[296],17,"open-output-file*");
lf[297]=C_h_intern(&lf[297],12,"port->fileno");
lf[298]=C_h_intern(&lf[298],6,"socket");
lf[299]=C_h_intern(&lf[299],20,"\003systcp-port->fileno");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[302]=C_h_intern(&lf[302],25,"\003syspeek-unsigned-integer");
lf[303]=C_h_intern(&lf[303],16,"duplicate-fileno");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[305]=C_h_intern(&lf[305],15,"make-input-port");
lf[306]=C_h_intern(&lf[306],14,"set-port-name!");
lf[307]=C_h_intern(&lf[307],21,"\003syscustom-input-port");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[309]=C_h_intern(&lf[309],17,"\003systhread-yield!");
lf[310]=C_h_intern(&lf[310],25,"\003systhread-block-for-i/o!");
lf[311]=C_h_intern(&lf[311],18,"\003syscurrent-thread");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[316]=C_h_intern(&lf[316],17,"\003sysstring-append");
lf[317]=C_h_intern(&lf[317],15,"\003sysmake-string");
lf[318]=C_h_intern(&lf[318],20,"\003sysscan-buffer-line");
lf[319]=C_h_intern(&lf[319],4,"noop");
lf[320]=C_h_intern(&lf[320],16,"make-output-port");
lf[321]=C_h_intern(&lf[321],22,"\003syscustom-output-port");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[324]=C_h_intern(&lf[324],13,"file-truncate");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[327]=C_h_intern(&lf[327],4,"lock");
lf[328]=C_h_intern(&lf[328],9,"file-lock");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[330]=C_h_intern(&lf[330],18,"file-lock/blocking");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[332]=C_h_intern(&lf[332],14,"file-test-lock");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[334]=C_h_intern(&lf[334],11,"file-unlock");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[336]=C_h_intern(&lf[336],11,"create-fifo");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[338]=C_h_intern(&lf[338],5,"fifo\077");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[340]=C_h_intern(&lf[340],6,"setenv");
lf[341]=C_h_intern(&lf[341],8,"unsetenv");
lf[342]=C_h_intern(&lf[342],25,"get-environment-variables");
lf[343]=C_h_intern(&lf[343],19,"current-environment");
lf[344]=C_h_intern(&lf[344],9,"prot/read");
lf[345]=C_h_intern(&lf[345],10,"prot/write");
lf[346]=C_h_intern(&lf[346],9,"prot/exec");
lf[347]=C_h_intern(&lf[347],9,"prot/none");
lf[348]=C_h_intern(&lf[348],9,"map/fixed");
lf[349]=C_h_intern(&lf[349],10,"map/shared");
lf[350]=C_h_intern(&lf[350],11,"map/private");
lf[351]=C_h_intern(&lf[351],13,"map/anonymous");
lf[352]=C_h_intern(&lf[352],8,"map/file");
lf[353]=C_h_intern(&lf[353],18,"map-file-to-memory");
lf[354]=C_h_intern(&lf[354],4,"mmap");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[356]=C_h_intern(&lf[356],20,"\003syspointer->address");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[358]=C_h_intern(&lf[358],16,"\003sysnull-pointer");
lf[359]=C_h_intern(&lf[359],22,"unmap-file-from-memory");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[361]=C_h_intern(&lf[361],26,"memory-mapped-file-pointer");
lf[362]=C_h_intern(&lf[362],19,"memory-mapped-file\077");
lf[363]=C_h_intern(&lf[363],19,"seconds->local-time");
lf[364]=C_h_intern(&lf[364],18,"\003sysdecode-seconds");
lf[365]=C_h_intern(&lf[365],17,"seconds->utc-time");
lf[366]=C_h_intern(&lf[366],15,"seconds->string");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[368]=C_h_intern(&lf[368],12,"time->string");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[372]=C_h_intern(&lf[372],12,"string->time");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[374]=C_h_intern(&lf[374],19,"local-time->seconds");
lf[375]=C_h_intern(&lf[375],15,"\003syscons-flonum");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[378]=C_h_intern(&lf[378],17,"utc-time->seconds");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[381]=C_h_intern(&lf[381],27,"local-timezone-abbreviation");
lf[382]=C_h_intern(&lf[382],5,"_exit");
lf[383]=C_h_intern(&lf[383],10,"set-alarm!");
lf[384]=C_h_intern(&lf[384],19,"set-buffering-mode!");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[386]=C_h_intern(&lf[386],5,"\000full");
lf[387]=C_h_intern(&lf[387],5,"\000line");
lf[388]=C_h_intern(&lf[388],5,"\000none");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[390]=C_h_intern(&lf[390],14,"terminal-port\077");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[393]=C_h_intern(&lf[393],13,"terminal-name");
lf[394]=C_h_intern(&lf[394],13,"terminal-size");
lf[395]=C_h_intern(&lf[395],6,"\000error");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[397]=C_h_intern(&lf[397],17,"\003sysmake-locative");
lf[398]=C_h_intern(&lf[398],8,"location");
lf[399]=C_h_intern(&lf[399],13,"get-host-name");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[401]=C_h_intern(&lf[401],6,"regexp");
lf[402]=C_h_intern(&lf[402],21,"make-anchored-pattern");
lf[403]=C_h_intern(&lf[403],12,"string-match");
lf[404]=C_h_intern(&lf[404],12,"glob->regexp");
lf[405]=C_h_intern(&lf[405],13,"make-pathname");
lf[406]=C_h_intern(&lf[406],18,"decompose-pathname");
lf[407]=C_h_intern(&lf[407],4,"glob");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[410]=C_h_intern(&lf[410],12,"process-fork");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[412]=C_h_intern(&lf[412],24,"pathname-strip-directory");
lf[413]=C_h_intern(&lf[413],15,"process-execute");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[415]=C_h_intern(&lf[415],16,"\003sysprocess-wait");
lf[416]=C_h_intern(&lf[416],12,"process-wait");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[418]=C_h_intern(&lf[418],18,"current-process-id");
lf[419]=C_h_intern(&lf[419],17,"parent-process-id");
lf[420]=C_h_intern(&lf[420],5,"sleep");
lf[421]=C_h_intern(&lf[421],14,"process-signal");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[423]=C_h_intern(&lf[423],17,"\003sysshell-command");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[426]=C_h_intern(&lf[426],27,"\003sysshell-command-arguments");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[428]=C_h_intern(&lf[428],11,"process-run");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[430]=C_h_intern(&lf[430],11,"\003sysprocess");
lf[431]=C_h_intern(&lf[431],7,"process");
lf[432]=C_h_intern(&lf[432],8,"process*");
lf[433]=C_h_intern(&lf[433],10,"find-files");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[437]=C_h_intern(&lf[437],16,"\003sysdynamic-wind");
lf[438]=C_h_intern(&lf[438],13,"pathname-file");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[440]=C_h_intern(&lf[440],7,"regexp\077");
lf[441]=C_h_intern(&lf[441],19,"set-root-directory!");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[444]=C_h_intern(&lf[444],21,"set-process-group-id!");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[446]=C_h_intern(&lf[446],18,"getter-with-setter");
lf[447]=C_h_intern(&lf[447],26,"effective-group-id!-setter");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[449]=C_h_intern(&lf[449],12,"set-user-id!");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[451]=C_h_intern(&lf[451],25,"effective-user-id!-setter");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[454]=C_h_intern(&lf[454],23,"\003sysuser-interrupt-hook");
lf[455]=C_h_intern(&lf[455],11,"make-vector");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[458]=C_h_intern(&lf[458],5,"port\077");
lf[459]=C_h_intern(&lf[459],18,"set-file-position!");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[462]=C_h_intern(&lf[462],13,"\000bounds-error");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[464]=C_h_intern(&lf[464],17,"register-feature!");
lf[465]=C_h_intern(&lf[465],5,"posix");
C_register_lf2(lf,466,create_ptable());
t2=C_mutate(&lf[0] /* (set! c150 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3429,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3427 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3432,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3430 in k3427 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3435,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3433 in k3430 in k3427 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3438,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 493  register-feature! */
t3=*((C_word*)lf[464]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[465]);}

/* k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word ab[113],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3444,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3456,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* (set! file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3474,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! file-select-one ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3481,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1 /* (set! fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1 /* (set! fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1 /* (set! fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1 /* (set! fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1 /* (set! fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1 /* (set! open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1 /* (set! open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1 /* (set! open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1 /* (set! open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1 /* (set! perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1 /* (set! perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1 /* (set! perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1 /* (set! file-control ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3538,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[51]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3584,a[2]=t45,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[55]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3622,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[57]+1);
t49=C_mutate((C_word*)lf[58]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3637,a[2]=t48,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[62]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[65]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3718,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3750,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3756,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3766,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t55=C_mutate((C_word*)lf[68]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3776,a[2]=t53,a[3]=t54,a[4]=t52,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t56=C_mutate((C_word*)lf[71]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[72]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[73]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[74] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3968,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[77]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4005,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[78]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4037,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[79]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4043,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[80]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4049,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[81]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4055,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[82]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4061,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[83]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4067,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[84]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4073,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[85]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4082,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[86]+1 /* (set! stat-regular? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4091,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[87]+1 /* (set! stat-directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4100,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[88]+1 /* (set! stat-char-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4109,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[89]+1 /* (set! stat-block-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4118,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[90]+1 /* (set! stat-fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4127,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[91]+1 /* (set! stat-symlink? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4136,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[92]+1 /* (set! stat-socket? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4145,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t76=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t77=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9301,a[2]=((C_word)li264),tmp=(C_word)a,a+=3,tmp);
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9338,a[2]=((C_word)li265),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 820  getter-with-setter */
t79=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t79))(4,t79,t76,t77,t78);}

/* a9337 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_9338r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_9338r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9338r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[459]);
t8=(C_word)C_i_check_exact_2(t6,lf[459]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9351,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 835  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[462],lf[459],lf[463],t3,t2);}
else{
t10=t9;
f_9351(2,t10,C_SCHEME_UNDEFINED);}}

/* k9349 in a9337 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 836  port? */
t4=*((C_word*)lf[458]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k9361 in k9349 in a9337 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[149]);
t4=((C_word*)t0)[4];
f_9357(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_9357(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 840  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[60],lf[459],lf[461],((C_word*)t0)[5]);}}}

/* k9355 in k9349 in a9337 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 841  posix-error */
t2=lf[3];
f_3456(7,t2,((C_word*)t0)[4],lf[48],lf[459],lf[460],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a9300 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9301,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9305,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9317,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 822  port? */
t5=*((C_word*)lf[458]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k9315 in a9300 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[149]);
t4=((C_word*)t0)[2];
f_9305(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_9305(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 827  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[93],lf[457],((C_word*)t0)[3]);}}}

/* k9303 in a9300 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9308,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 829  posix-error */
t3=lf[3];
f_3456(6,t3,t2,lf[48],lf[93],lf[456],((C_word*)t0)[2]);}
else{
t3=t2;
f_9308(2,t3,C_SCHEME_UNDEFINED);}}

/* k9306 in k9303 in a9300 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[171],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1 /* (set! file-position ...) */,t1);
t3=C_mutate((C_word*)lf[94]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4158,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[104]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4293,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[106]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4317,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[108]+1);
t7=*((C_word*)lf[57]+1);
t8=*((C_word*)lf[109]+1);
t9=C_mutate((C_word*)lf[110]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4341,a[2]=t7,a[3]=t6,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[114]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4498,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[113]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4521,a[2]=t11,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[117]+1);
t14=*((C_word*)lf[118]+1);
t15=*((C_word*)lf[119]+1);
t16=*((C_word*)lf[120]+1);
t17=*((C_word*)lf[108]+1);
t18=*((C_word*)lf[2]+1);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4569,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4574,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
t21=*((C_word*)lf[123]+1);
t22=*((C_word*)lf[124]+1);
t23=*((C_word*)lf[113]+1);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4585,a[2]=t23,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t25=C_mutate((C_word*)lf[103]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4641,a[2]=t16,a[3]=t14,a[4]=t21,a[5]=t22,a[6]=t24,a[7]=t15,a[8]=t13,a[9]=t17,a[10]=t19,a[11]=t18,a[12]=t20,a[13]=((C_word)li61),tmp=(C_word)a,a+=14,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4958,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4970,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4976,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
t29=C_mutate((C_word*)lf[150]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4991,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li65),tmp=(C_word)a,a+=6,tmp));
t30=C_mutate((C_word*)lf[152]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5027,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[153]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5063,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[157]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[153]+1));
t33=*((C_word*)lf[150]+1);
t34=*((C_word*)lf[152]+1);
t35=*((C_word*)lf[153]+1);
t36=*((C_word*)lf[157]+1);
t37=C_mutate((C_word*)lf[158]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5079,a[2]=t33,a[3]=t35,a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp));
t38=C_mutate((C_word*)lf[159]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5103,a[2]=t34,a[3]=t36,a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[160]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5127,a[2]=t33,a[3]=t35,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[162]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5147,a[2]=t34,a[3]=t36,a[4]=((C_word)li77),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[164]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5167,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[166]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t43=C_mutate((C_word*)lf[167]+1 /* (set! signal/kill ...) */,C_fix((C_word)SIGKILL));
t44=C_mutate((C_word*)lf[168]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[169]+1 /* (set! signal/hup ...) */,C_fix((C_word)SIGHUP));
t46=C_mutate((C_word*)lf[170]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t47=C_mutate((C_word*)lf[171]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t48=C_mutate((C_word*)lf[172]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t49=C_mutate((C_word*)lf[173]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t50=C_mutate((C_word*)lf[174]+1 /* (set! signal/trap ...) */,C_fix((C_word)SIGTRAP));
t51=C_mutate((C_word*)lf[175]+1 /* (set! signal/quit ...) */,C_fix((C_word)SIGQUIT));
t52=C_mutate((C_word*)lf[176]+1 /* (set! signal/alrm ...) */,C_fix((C_word)SIGALRM));
t53=C_mutate((C_word*)lf[177]+1 /* (set! signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t54=C_mutate((C_word*)lf[178]+1 /* (set! signal/prof ...) */,C_fix((C_word)SIGPROF));
t55=C_mutate((C_word*)lf[179]+1 /* (set! signal/io ...) */,C_fix((C_word)SIGIO));
t56=C_mutate((C_word*)lf[180]+1 /* (set! signal/urg ...) */,C_fix((C_word)SIGURG));
t57=C_mutate((C_word*)lf[181]+1 /* (set! signal/chld ...) */,C_fix((C_word)SIGCHLD));
t58=C_mutate((C_word*)lf[182]+1 /* (set! signal/cont ...) */,C_fix((C_word)SIGCONT));
t59=C_mutate((C_word*)lf[183]+1 /* (set! signal/stop ...) */,C_fix((C_word)SIGSTOP));
t60=C_mutate((C_word*)lf[184]+1 /* (set! signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t61=C_mutate((C_word*)lf[185]+1 /* (set! signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t62=C_mutate((C_word*)lf[186]+1 /* (set! signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t63=C_mutate((C_word*)lf[187]+1 /* (set! signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t64=C_mutate((C_word*)lf[188]+1 /* (set! signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t65=C_mutate((C_word*)lf[189]+1 /* (set! signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t66=C_mutate((C_word*)lf[190]+1 /* (set! signal/winch ...) */,C_fix((C_word)SIGWINCH));
t67=(C_word)C_a_i_list(&a,25,*((C_word*)lf[166]+1),*((C_word*)lf[167]+1),*((C_word*)lf[168]+1),*((C_word*)lf[169]+1),*((C_word*)lf[170]+1),*((C_word*)lf[171]+1),*((C_word*)lf[172]+1),*((C_word*)lf[173]+1),*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1),*((C_word*)lf[189]+1),*((C_word*)lf[190]+1));
t68=C_mutate((C_word*)lf[191]+1 /* (set! signals-list ...) */,t67);
t69=*((C_word*)lf[192]+1);
t70=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5212,a[2]=((C_word*)t0)[2],a[3]=t69,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1163 make-vector */
t71=*((C_word*)lf[455]+1);
((C_proc4)(void*)(*((C_word*)t71+1)))(4,t71,t70,C_fix(256),C_SCHEME_FALSE);}

/* k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5212,2,t0,t1);}
t2=C_mutate((C_word*)lf[193]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5214,a[2]=t1,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[194]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5223,a[2]=t1,a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[192]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5236,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[195]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5254,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[198]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5278,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[199]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5310,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[200]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5316,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[202]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5331,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9295,a[2]=((C_word)li263),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1219 set-signal-handler! */
t12=*((C_word*)lf[194]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,*((C_word*)lf[168]+1),t11);}

/* a9294 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9295(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9295,3,t0,t1,t2);}
/* posixunix.scm: 1221 ##sys#user-interrupt-hook */
t3=*((C_word*)lf[454]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5347,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5349,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9277,a[2]=((C_word)li261),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9280,a[2]=((C_word)li262),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1245 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a9279 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9280,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9290,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1249 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9288 in a9279 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1250 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[449],lf[453],((C_word*)t0)[2]);}

/* a9276 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9277,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1105(C_SCHEME_UNDEFINED));}

/* k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5389,2,t0,t1);}
t2=C_mutate((C_word*)lf[207]+1 /* (set! current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5393,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9259,a[2]=((C_word)li259),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9262,a[2]=((C_word)li260),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1253 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a9261 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9262,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9272,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1257 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9270 in a9261 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1258 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[451],lf[452],((C_word*)t0)[2]);}

/* a9258 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9259,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1114(C_SCHEME_UNDEFINED));}

/* k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5393,2,t0,t1);}
t2=C_mutate((C_word*)lf[208]+1 /* (set! current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9241,a[2]=((C_word)li257),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9244,a[2]=((C_word)li258),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1262 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a9243 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9244(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9244,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9254,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1266 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9252 in a9243 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1267 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[449],lf[450],((C_word*)t0)[2]);}

/* a9240 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9241,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1123(C_SCHEME_UNDEFINED));}

/* k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5397,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1 /* (set! current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9223,a[2]=((C_word)li255),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9226,a[2]=((C_word)li256),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1270 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a9225 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9226,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9236,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1274 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9234 in a9225 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1275 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[447],lf[448],((C_word*)t0)[2]);}

/* a9222 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9223,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1132(C_SCHEME_UNDEFINED));}

/* k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5401,2,t0,t1);}
t2=C_mutate((C_word*)lf[210]+1 /* (set! current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[211]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5403,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[124]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5470,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[214]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[215]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5509,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[216] /* (set! _ensure-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5595,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[217]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5602,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[221]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5665,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[224]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5739,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[226]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[227]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[228]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[229]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[230]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[231]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[232]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[233]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[234]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[235]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[236]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[237]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[238]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[239]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[240]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[241]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[242]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[243]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[244]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[245]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[246]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[247]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[248]+1 /* (set! errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[249] /* errno/2big */,0,C_fix(0));
t35=C_set_block_item(lf[250] /* errno/deadlk */,0,C_fix(0));
t36=C_set_block_item(lf[251] /* errno/dom */,0,C_fix(0));
t37=C_set_block_item(lf[252] /* errno/fbig */,0,C_fix(0));
t38=C_set_block_item(lf[253] /* errno/ilseq */,0,C_fix(0));
t39=C_set_block_item(lf[254] /* errno/mlink */,0,C_fix(0));
t40=C_set_block_item(lf[255] /* errno/nametoolong */,0,C_fix(0));
t41=C_set_block_item(lf[256] /* errno/nfile */,0,C_fix(0));
t42=C_set_block_item(lf[257] /* errno/nodev */,0,C_fix(0));
t43=C_set_block_item(lf[258] /* errno/nolck */,0,C_fix(0));
t44=C_set_block_item(lf[259] /* errno/nosys */,0,C_fix(0));
t45=C_set_block_item(lf[260] /* errno/notempty */,0,C_fix(0));
t46=C_set_block_item(lf[261] /* errno/notty */,0,C_fix(0));
t47=C_set_block_item(lf[262] /* errno/nxio */,0,C_fix(0));
t48=C_set_block_item(lf[263] /* errno/range */,0,C_fix(0));
t49=C_set_block_item(lf[264] /* errno/xdev */,0,C_fix(0));
t50=C_mutate((C_word*)lf[265]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5803,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[267]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5830,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5860,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[269]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5884,a[2]=t52,a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[270]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5890,a[2]=t52,a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[271]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5896,a[2]=t52,a[3]=((C_word)li106),tmp=(C_word)a,a+=4,tmp));
t56=C_mutate((C_word*)lf[272]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5902,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5919,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9184,a[2]=((C_word)li253),tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9202,a[2]=((C_word)li254),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1490 getter-with-setter */
t60=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t60))(4,t60,t57,t58,t59);}

/* a9201 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9202,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[444]);
t5=(C_word)C_i_check_exact_2(t3,lf[444]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9218,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1502 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k9216 in a9201 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1503 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[444],lf[445],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9183 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9184,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[274]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9191,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9197,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1495 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_9191(2,t6,C_SCHEME_UNDEFINED);}}

/* k9195 in a9183 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1496 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[274],lf[443],((C_word*)t0)[2]);}

/* k9189 in a9183 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5919,2,t0,t1);}
t2=C_mutate((C_word*)lf[274]+1 /* (set! process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[275]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5921,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[278]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5958,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1523 make-string */
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word ab[259],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5958,2,t0,t1);}
t2=C_mutate((C_word*)lf[279]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5959,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[281]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6009,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[284]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[285]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[286]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6034,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6071,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp);
t9=C_mutate((C_word*)lf[295]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6086,a[2]=t7,a[3]=t8,a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[296]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6100,a[2]=t7,a[3]=t8,a[4]=((C_word)li114),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[297]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6114,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[303]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6159,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[305]+1);
t14=*((C_word*)lf[306]+1);
t15=C_mutate((C_word*)lf[307]+1 /* (set! custom-input-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6186,a[2]=t13,a[3]=t14,a[4]=((C_word)li136),tmp=(C_word)a,a+=5,tmp));
t16=*((C_word*)lf[320]+1);
t17=*((C_word*)lf[306]+1);
t18=C_mutate((C_word*)lf[321]+1 /* (set! custom-output-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6660,a[2]=t16,a[3]=t17,a[4]=((C_word)li148),tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[324]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6919,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6958,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7032,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[328]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7050,a[2]=t20,a[3]=t21,a[4]=((C_word)li152),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[330]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7065,a[2]=t20,a[3]=t21,a[4]=((C_word)li153),tmp=(C_word)a,a+=5,tmp));
t24=C_mutate((C_word*)lf[332]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7080,a[2]=t20,a[3]=t21,a[4]=((C_word)li154),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[334]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7102,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[336]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7130,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[338]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7173,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[340]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7199,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[341]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7216,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[342]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7236,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[343]+1 /* (set! current-environment ...) */,*((C_word*)lf[342]+1));
t32=C_mutate((C_word*)lf[344]+1 /* (set! prot/read ...) */,C_fix((C_word)PROT_READ));
t33=C_mutate((C_word*)lf[345]+1 /* (set! prot/write ...) */,C_fix((C_word)PROT_WRITE));
t34=C_mutate((C_word*)lf[346]+1 /* (set! prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t35=C_mutate((C_word*)lf[347]+1 /* (set! prot/none ...) */,C_fix((C_word)PROT_NONE));
t36=C_mutate((C_word*)lf[348]+1 /* (set! map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t37=C_mutate((C_word*)lf[349]+1 /* (set! map/shared ...) */,C_fix((C_word)MAP_SHARED));
t38=C_mutate((C_word*)lf[350]+1 /* (set! map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t39=C_mutate((C_word*)lf[351]+1 /* (set! map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t40=C_mutate((C_word*)lf[352]+1 /* (set! map/file ...) */,C_fix((C_word)MAP_FILE));
t41=C_mutate((C_word*)lf[353]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7340,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[359]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7402,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[361]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7437,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[362]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7446,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[363]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7452,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[365]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7461,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[366]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7480,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[368]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7513,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[372]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7595,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[374]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7641,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[378]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7669,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[381]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7697,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[382]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7709,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[383]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7725,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[384]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7732,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[390]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7791,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate(&lf[391] /* (set! terminal-check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7810,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[393]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7842,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[394]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7865,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[399]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7900,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp));
t61=*((C_word*)lf[401]+1);
t62=*((C_word*)lf[402]+1);
t63=*((C_word*)lf[403]+1);
t64=*((C_word*)lf[404]+1);
t65=*((C_word*)lf[110]+1);
t66=*((C_word*)lf[405]+1);
t67=*((C_word*)lf[406]+1);
t68=C_mutate((C_word*)lf[407]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7912,a[2]=t64,a[3]=t62,a[4]=t61,a[5]=t65,a[6]=t63,a[7]=t66,a[8]=t67,a[9]=((C_word)li187),tmp=(C_word)a,a+=10,tmp));
t69=C_mutate((C_word*)lf[410]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8024,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp));
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8066,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
t71=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8085,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
t72=*((C_word*)lf[412]+1);
t73=C_mutate((C_word*)lf[413]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8104,a[2]=t72,a[3]=t71,a[4]=t70,a[5]=((C_word)li197),tmp=(C_word)a,a+=6,tmp));
t74=C_mutate((C_word*)lf[415]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8286,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[416]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8303,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[418]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8381,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[419]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8384,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[420]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8387,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[421]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8394,a[2]=((C_word)li205),tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[423]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8421,a[2]=((C_word)li206),tmp=(C_word)a,a+=3,tmp));
t81=C_mutate((C_word*)lf[426]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8430,a[2]=((C_word)li207),tmp=(C_word)a,a+=3,tmp));
t82=*((C_word*)lf[410]+1);
t83=*((C_word*)lf[413]+1);
t84=*((C_word*)lf[123]+1);
t85=C_mutate((C_word*)lf[428]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8436,a[2]=t82,a[3]=t83,a[4]=((C_word)li208),tmp=(C_word)a,a+=5,tmp));
t86=*((C_word*)lf[164]+1);
t87=*((C_word*)lf[416]+1);
t88=*((C_word*)lf[410]+1);
t89=*((C_word*)lf[413]+1);
t90=*((C_word*)lf[303]+1);
t91=*((C_word*)lf[55]+1);
t92=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8492,a[2]=t87,a[3]=((C_word)li212),tmp=(C_word)a,a+=4,tmp);
t93=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8529,a[2]=t86,a[3]=((C_word)li215),tmp=(C_word)a,a+=4,tmp);
t94=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8549,a[2]=t91,a[3]=((C_word)li216),tmp=(C_word)a,a+=4,tmp);
t95=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8563,a[2]=t91,a[3]=((C_word)li217),tmp=(C_word)a,a+=4,tmp);
t96=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8580,a[2]=((C_word)li218),tmp=(C_word)a,a+=3,tmp);
t97=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8596,a[2]=t93,a[3]=t88,a[4]=t95,a[5]=t89,a[6]=t96,a[7]=((C_word)li220),tmp=(C_word)a,a+=8,tmp);
t98=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8641,a[2]=t94,a[3]=((C_word)li221),tmp=(C_word)a,a+=4,tmp);
t99=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8652,a[2]=t94,a[3]=((C_word)li222),tmp=(C_word)a,a+=4,tmp);
t100=C_mutate((C_word*)lf[430]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8663,a[2]=t99,a[3]=t92,a[4]=t98,a[5]=t97,a[6]=((C_word)li225),tmp=(C_word)a,a+=7,tmp));
t101=C_set_block_item(lf[431] /* process */,0,C_SCHEME_UNDEFINED);
t102=C_set_block_item(lf[432] /* process* */,0,C_SCHEME_UNDEFINED);
t103=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8721,a[2]=((C_word)li230),tmp=(C_word)a,a+=3,tmp);
t104=C_mutate((C_word*)lf[431]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8782,a[2]=t103,a[3]=((C_word)li234),tmp=(C_word)a,a+=4,tmp));
t105=C_mutate((C_word*)lf[432]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8842,a[2]=t103,a[3]=((C_word)li238),tmp=(C_word)a,a+=4,tmp));
t106=*((C_word*)lf[407]+1);
t107=*((C_word*)lf[403]+1);
t108=*((C_word*)lf[405]+1);
t109=*((C_word*)lf[114]+1);
t110=C_mutate((C_word*)lf[433]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8902,a[2]=t109,a[3]=t108,a[4]=t106,a[5]=t107,a[6]=((C_word)li251),tmp=(C_word)a,a+=7,tmp));
t111=C_mutate((C_word*)lf[441]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9161,a[2]=((C_word)li252),tmp=(C_word)a,a+=3,tmp));
t112=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t112+1)))(2,t112,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9161,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[441]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9153,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_foreign_string_argumentp(t4);
/* ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t6=t5;
f_9153(2,t6,C_SCHEME_FALSE);}}

/* k9151 in set-root-directory! in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub3166(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2380 posix-error */
t3=lf[3];
f_3456(6,t3,((C_word*)t0)[3],lf[48],lf[441],lf[442],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_8902r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8902r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8902r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li246),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9069,a[2]=t5,a[3]=((C_word)li247),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9074,a[2]=t6,a[3]=((C_word)li248),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9079,a[2]=t7,a[3]=((C_word)li250),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action30563147 */
t9=t8;
f_9079(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id30573143 */
t11=t7;
f_9074(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit30583138 */
t13=t6;
f_9069(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body30543064 */
t15=t5;
f_8904(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action3056 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_9079(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9079,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9085,a[2]=((C_word)li249),tmp=(C_word)a,a+=3,tmp);
/* def-id30573143 */
t3=((C_word*)t0)[2];
f_9074(t3,t1,t2);}

/* a9084 in def-action3056 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9085,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id3057 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_9074(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9074,NULL,3,t0,t1,t2);}
/* def-limit30583138 */
t3=((C_word*)t0)[2];
f_9069(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit3058 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_9069(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9069,NULL,4,t0,t1,t2,t3);}
/* body30543064 */
t4=((C_word*)t0)[2];
f_8904(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8904(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8904,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[433]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8911,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_8911(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9064,a[2]=t4,a[3]=t7,a[4]=((C_word)li244),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_8911(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9056,a[2]=((C_word)li245),tmp=(C_word)a,a+=3,tmp));}}

/* f_9056 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9056(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9056,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_9064 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9064(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9064,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8911,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_9044(2,t4,t2);}
else{
/* posixunix.scm: 2352 regexp? */
t4=*((C_word*)lf[440]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[11]);}}

/* k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9044,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9045,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word)li239),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8921,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9038,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2355 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[439]);}

/* k9036 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2355 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8921,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8923,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li243),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_8923(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8923(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8923,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2361 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8942,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2362 pathname-file */
t3=*((C_word*)lf[438]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9024,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2369 pproc */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k9022 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9024,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9031,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2369 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2370 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_8923(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k9029 in k9022 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2369 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8923(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9018,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[434]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[435]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2362 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_8923(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2363 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8955 in k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8957,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8967,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8969,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,a[5]=((C_word)li240),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word)li241),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8998,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,a[5]=((C_word)li242),tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[437]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9008,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9011,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2368 pproc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k9009 in k8955 in k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2368 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_9008(2,t2,((C_word*)t0)[2]);}}

/* k9006 in k8955 in k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2368 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8923(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8997 in k8955 in k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8998,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8973 in k8955 in k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8982,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8996,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2366 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],lf[436]);}

/* k8994 in a8973 in k8955 in k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2366 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8980 in a8973 in k8955 in k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8986,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2367 pproc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k8987 in k8980 in a8973 in k8955 in k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2367 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8986(2,t2,((C_word*)t0)[2]);}}

/* k8984 in k8980 in a8973 in k8955 in k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2366 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8923(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8968 in k8955 in k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8969,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8965 in k8955 in k9016 in k8940 in loop in k8919 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2364 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8923(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_9045 in k9042 in k8909 in body3054 in find-files in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_9045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9045,3,t0,t1,t2);}
/* posixunix.scm: 2353 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8842(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8842r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8842r(t0,t1,t2,t3);}}

static void C_ccall f_8842r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8844,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li235),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8849,a[2]=t4,a[3]=((C_word)li236),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8854,a[2]=t5,a[3]=((C_word)li237),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args30093025 */
t7=t6;
f_8854(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env30103021 */
t9=t5;
f_8849(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body30073016 */
t11=t4;
f_8844(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args3009 in process* in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8854(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8854,NULL,2,t0,t1);}
/* def-env30103021 */
t2=((C_word*)t0)[2];
f_8849(t2,t1,C_SCHEME_FALSE);}

/* def-env3010 in process* in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8849(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8849,NULL,3,t0,t1,t2);}
/* body30073016 */
t3=((C_word*)t0)[2];
f_8844(t3,t1,t2,C_SCHEME_FALSE);}

/* body3007 in process* in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8844(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8844,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2330 %process */
f_8721(t1,lf[432],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8782(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8782r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8782r(t0,t1,t2,t3);}}

static void C_ccall f_8782r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8784,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li231),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8789,a[2]=t4,a[3]=((C_word)li232),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8794,a[2]=t5,a[3]=((C_word)li233),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args29652981 */
t7=t6;
f_8794(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env29662977 */
t9=t5;
f_8789(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body29632972 */
t11=t4;
f_8784(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args2965 in process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8794,NULL,2,t0,t1);}
/* def-env29662977 */
t2=((C_word*)t0)[2];
f_8789(t2,t1,C_SCHEME_FALSE);}

/* def-env2966 in process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8789(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8789,NULL,3,t0,t1,t2);}
/* body29632972 */
t3=((C_word*)t0)[2];
f_8784(t3,t1,t2,C_SCHEME_FALSE);}

/* body2963 in process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8784(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8784,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2327 %process */
f_8721(t1,lf[431],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8721(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8721,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8723,a[2]=t2,a[3]=((C_word)li227),tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8742,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2316 chkstrlst */
t12=t9;
f_8723(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8776,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2318 ##sys#shell-command-arguments */
t13=*((C_word*)lf[426]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)t7)[1]);}}

/* k8774 in %process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8776,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2319 ##sys#shell-command */
t4=*((C_word*)lf[423]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8778 in k8774 in %process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_8742(2,t3,t2);}

/* k8740 in %process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2320 chkstrlst */
t3=((C_word*)t0)[2];
f_8723(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_8745(2,t3,C_SCHEME_UNDEFINED);}}

/* k8743 in k8740 in %process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8750,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li228),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8756,a[2]=((C_word*)t0)[3],a[3]=((C_word)li229),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8755 in k8743 in k8740 in %process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8756,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2323 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2324 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8749 in k8743 in k8740 in %process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8750,2,t0,t1);}
/* posixunix.scm: 2321 ##sys#process */
t2=*((C_word*)lf[430]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8723,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8732,a[2]=((C_word*)t0)[2],a[3]=((C_word)li226),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a8731 in chkstrlst in %process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8732,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8663,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8669,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word)li223),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,a[10]=((C_word)li224),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a8674 in ##sys#process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8675,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8686,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8706,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2297 make-on-close */
t12=((C_word*)t0)[3];
f_8492(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k8704 in a8674 in ##sys#process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2296 input-port */
t2=((C_word*)t0)[7];
f_8641(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8684 in a8674 in ##sys#process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8690,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2299 make-on-close */
t4=((C_word*)t0)[6];
f_8492(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k8700 in k8684 in a8674 in ##sys#process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2298 output-port */
t2=((C_word*)t0)[7];
f_8652(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8688 in k8684 in a8674 in ##sys#process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8694,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8698,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2302 make-on-close */
t4=((C_word*)t0)[3];
f_8492(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k8696 in k8688 in k8684 in a8674 in ##sys#process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2301 input-port */
t2=((C_word*)t0)[7];
f_8641(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8692 in k8688 in k8684 in a8674 in ##sys#process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2295 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8668 in ##sys#process in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8669,2,t0,t1);}
/* posixunix.scm: 2290 spawn */
t2=((C_word*)t0)[8];
f_8596(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8652(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8652,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8656,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2286 connect-parent */
t8=((C_word*)t0)[2];
f_8549(t8,t7,t4,t5);}

/* k8654 in output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2287 ##sys#custom-output-port */
t2=*((C_word*)lf[321]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8641(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8641,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8645,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2282 connect-parent */
t8=((C_word*)t0)[2];
f_8549(t8,t7,t4,t5);}

/* k8643 in input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2283 ##sys#custom-input-port */
t2=*((C_word*)lf[307]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8596,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2269 needed-pipe */
t9=((C_word*)t0)[2];
f_8529(t9,t8,t6);}

/* k8598 in spawn in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2270 needed-pipe */
t3=((C_word*)t0)[2];
f_8529(t3,t2,((C_word*)t0)[5]);}

/* k8601 in k8598 in spawn in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2271 needed-pipe */
t3=((C_word*)t0)[2];
f_8529(t3,t2,((C_word*)t0)[6]);}

/* k8604 in k8601 in k8598 in spawn in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8606,2,t0,t1);}
t2=f_8580(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8617,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8619,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word)li219),tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2274 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8618 in k8604 in k8601 in k8598 in spawn in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8623,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2276 connect-child */
t3=((C_word*)t0)[7];
f_8563(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[284]+1));}

/* k8621 in a8618 in k8604 in k8601 in k8598 in spawn in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8626,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_8580(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2277 connect-child */
t4=((C_word*)t0)[5];
f_8563(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[285]+1));}

/* k8624 in k8621 in a8618 in k8604 in k8601 in k8598 in spawn in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8629,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_8580(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2278 connect-child */
t4=((C_word*)t0)[3];
f_8563(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[286]+1));}

/* k8627 in k8624 in k8621 in a8618 in k8604 in k8601 in k8598 in spawn in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2279 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8615 in k8604 in k8601 in k8598 in spawn in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2272 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall f_8580(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8563(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8563,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8576,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2260 file-close */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k8574 in connect-child in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8576,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8488,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2234 duplicate-fileno */
t6=*((C_word*)lf[303]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k8486 in k8574 in connect-child in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2235 file-close */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8549(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8549,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8562,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2254 file-close */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k8560 in connect-parent in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8529,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8538,a[2]=((C_word*)t0)[2],a[3]=((C_word)li213),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8544,a[2]=((C_word)li214),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a8543 in needed-pipe in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8544,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a8537 in needed-pipe in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8538,2,t0,t1);}
/* posixunix.scm: 2249 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* make-on-close in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8492(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8492,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8494,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,a[9]=((C_word)li211),tmp=(C_word)a,a+=10,tmp));}

/* f_8494 in make-on-close in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8494,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li209),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li210),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a8514 */
static void C_ccall f_8515(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8515,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2244 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[196],((C_word*)t0)[3],lf[429],((C_word*)t0)[2],t4);}}

/* a8508 */
static void C_ccall f_8509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8509,2,t0,t1);}
/* posixunix.scm: 2242 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8436(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8436r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8436r(t0,t1,t2,t3);}}

static void C_ccall f_8436r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8443,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2198 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k8441 in process-run in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8443,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2200 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2202 ##sys#shell-command */
t4=*((C_word*)lf[423]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k8460 in k8441 in process-run in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8466,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2202 ##sys#shell-command-arguments */
t3=*((C_word*)lf[426]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8464 in k8460 in k8441 in process-run in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2202 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8430,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[427],t2));}

/* ##sys#shell-command in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8425,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2187 getenv */
t3=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[425]);}

/* k8423 in ##sys#shell-command in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[424]));}

/* process-signal in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8394(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8394r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8394r(t0,t1,t2,t3);}}

static void C_ccall f_8394r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[421]);
t7=(C_word)C_i_check_exact_2(t5,lf[421]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2184 posix-error */
t10=lf[3];
f_3456(7,t10,t1,lf[196],lf[421],lf[422],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8387,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2713(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8384,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2708(C_SCHEME_UNDEFINED));}

/* current-process-id in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8381,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2704(C_SCHEME_UNDEFINED));}

/* process-wait in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_8303r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8303r(t0,t1,t2);}}

static void C_ccall f_8303r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[416]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8333,a[2]=t8,a[3]=t11,a[4]=((C_word)li199),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8339,a[2]=t11,a[3]=((C_word)li200),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t13,t14);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* a8338 in process-wait in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8339,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2170 posix-error */
t6=lf[3];
f_3456(6,t6,t1,lf[196],lf[416],lf[417],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2171 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8332 in process-wait in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8333,2,t0,t1);}
/* posixunix.scm: 2168 ##sys#process-wait */
t2=*((C_word*)lf[415]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8286,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 2155 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8104(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_8104r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8104r(t0,t1,t2,t3);}}

static void C_ccall f_8104r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li194),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8233,a[2]=t4,a[3]=((C_word)li195),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8238,a[2]=t5,a[3]=((C_word)li196),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist25702638 */
t7=t6;
f_8238(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist25712634 */
t9=t5;
f_8233(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body25682577 */
t11=t4;
f_8106(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist2570 in process-execute in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8238,NULL,2,t0,t1);}
/* def-envlist25712634 */
t2=((C_word*)t0)[2];
f_8233(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist2571 in process-execute in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8233(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8233,NULL,3,t0,t1,t2);}
/* body25682577 */
t3=((C_word*)t0)[2];
f_8106(t3,t1,t2,C_SCHEME_FALSE);}

/* body2568 in process-execute in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8106(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8106,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[413]);
t5=(C_word)C_i_check_list_2(t2,lf[413]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8116,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2123 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k8114 in body2568 in process-execute in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8116,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_8066(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8124,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li193),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_8124(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* doloop2583 in k8114 in body2568 in process-execute in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8124(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8124,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_8066(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8137,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[413]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8170,a[2]=((C_word*)t0)[3],a[3]=((C_word)li192),tmp=(C_word)a,a+=4,tmp);
t8=t5;
f_8137(t8,f_8170(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_8137(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[413]);
t6=(C_word)C_block_size(t4);
t7=f_8066(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* doloop2594 in doloop2583 in k8114 in body2568 in process-execute in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall f_8170(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_8085(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[413]);
t5=(C_word)C_block_size(t3);
t6=f_8085(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k8135 in doloop2583 in k8114 in body2568 in process-execute in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_8137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8137,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8162,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2137 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8160 in k8135 in doloop2583 in k8114 in body2568 in process-execute in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2137 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8138 in k8135 in doloop2583 in k8114 in body2568 in process-execute in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub2533(C_SCHEME_UNDEFINED);
t5=(C_word)stub2548(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2144 posix-error */
t6=lf[3];
f_3456(6,t6,((C_word*)t0)[3],lf[196],lf[413],lf[414],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall f_8085(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub2539(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall f_8066(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub2524(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8024(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_8024r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_8024r(t0,t1,t2);}}

static void C_ccall f_8024r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub2492(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2108 posix-error */
t5=lf[3];
f_3456(5,t5,t1,lf[196],lf[410],lf[411]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8046,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_vector_ref(t2,C_fix(0));
t9=t8;
((C_proc2)C_retrieve_proc(t9))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k8044 in process-fork in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8050,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_8050 in k8044 in process-fork in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8050,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2510(C_SCHEME_UNDEFINED,t3));}

/* glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7912(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_7912r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7912r(t0,t1,t2);}}

static void C_ccall f_7912r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li186),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_7918(t6,t1,t2);}

/* conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_7918(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7918,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7933,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li183),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li185),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a7938 in conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7939,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8016,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[409]);
/* posixunix.scm: 2092 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k8014 in a7938 in conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_8016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2092 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7941 in a7938 in conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixunix.scm: 2093 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k7944 in k7941 in a7938 in conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7949,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2094 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k7947 in k7944 in k7941 in a7938 in conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7956,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[408]);
/* posixunix.scm: 2095 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k7954 in k7947 in k7944 in k7941 in a7938 in conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7956,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li184),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_7958(t5,((C_word*)t0)[2],t1);}

/* loop in k7954 in k7947 in k7944 in k7941 in a7938 in conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_7958(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7958,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixunix.scm: 2096 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_7918(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7975,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixunix.scm: 2097 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k7973 in loop in k7954 in k7947 in k7944 in k7941 in a7938 in conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7975,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7985,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixunix.scm: 2098 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixunix.scm: 2099 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7958(t3,((C_word*)t0)[6],t2);}}

/* k7983 in k7973 in loop in k7954 in k7947 in k7944 in k7941 in a7938 in conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7989,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixunix.scm: 2098 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7958(t4,t2,t3);}

/* k7987 in k7983 in k7973 in loop in k7954 in k7947 in k7944 in k7941 in a7938 in conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7989,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a7932 in conc-loop in glob in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7933,2,t0,t1);}
/* posixunix.scm: 2091 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7904,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub2403(t3),C_fix(0));}

/* k7902 in get-host-name in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7907,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7907(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2072 posix-error */
t3=lf[3];
f_3456(5,t3,t2,lf[395],lf[399],lf[400]);}}

/* k7905 in k7902 in get-host-name in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7865,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7869,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2053 ##sys#terminal-check */
f_7810(t3,lf[394],t2);}

/* k7867 in terminal-size in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7869,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7889,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
t5=*((C_word*)lf[397]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[398]);}

/* k7887 in k7867 in terminal-size in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[397]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[398]);}

/* k7891 in k7887 in k7867 in terminal-size in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_pointer_argumentp(t3);
t6=(C_word)C_i_foreign_pointer_argumentp(t1);
t7=(C_word)stub2374(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(C_word)C_eqp(C_fix(0),t7);
if(C_truep(t8)){
/* posixunix.scm: 2060 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2061 posix-error */
t9=lf[3];
f_3456(6,t9,((C_word*)t0)[4],lf[395],lf[394],lf[396],((C_word*)t0)[6]);}}

/* terminal-name in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7842,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7846,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2045 ##sys#terminal-check */
f_7810(t3,lf[393],t2);}

/* k7844 in terminal-name in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7846,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub2359(t4,t5);
/* ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* ##sys#terminal-check in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_7810(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7810,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7814,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2037 ##sys#check-port */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k7812 in ##sys#terminal-check in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[149],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2040 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[392],((C_word*)t0)[4]);}}

/* terminal-port? in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7791,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7795,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2032 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[390]);}

/* k7793 in terminal-port? in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2033 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k7796 in k7793 in terminal-port? in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_7732r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_7732r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7732r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7736,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2017 ##sys#check-port */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[384]);}

/* k7734 in set-buffering-mode! in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7736,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[386]);
if(C_truep(t6)){
t7=t5;
f_7742(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[387]);
if(C_truep(t7)){
t8=t5;
f_7742(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[388]);
if(C_truep(t8)){
t9=t5;
f_7742(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2023 ##sys#error */
t9=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[384],lf[389],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k7740 in k7734 in set-buffering-mode! in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[384]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[149],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 2029 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[384],lf[385],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7725,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2310(C_SCHEME_UNDEFINED,t3));}

/* _exit in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7709(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7709r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7709r(t0,t1,t2);}}

static void C_ccall f_7709r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub2301(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7697,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub2293(t2),C_fix(0));}

/* utc-time->seconds in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7669,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[378]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7676,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1985 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[378],lf[380],t2);}
else{
t6=t4;
f_7676(2,t6,C_SCHEME_UNDEFINED);}}

/* k7674 in utc-time->seconds in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 1987 ##sys#cons-flonum */
t2=*((C_word*)lf[375]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1988 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[378],lf[379],((C_word*)t0)[3]);}}

/* local-time->seconds in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7641,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[374]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7648,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1978 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[374],lf[377],t2);}
else{
t6=t4;
f_7648(2,t6,C_SCHEME_UNDEFINED);}}

/* k7646 in local-time->seconds in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 1980 ##sys#cons-flonum */
t2=*((C_word*)lf[375]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1981 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[374],lf[376],((C_word*)t0)[3]);}}

/* string->time in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7595(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7595r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7595r(t0,t1,t2,t3);}}

static void C_ccall f_7595r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7599,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7599(2,t5,lf[373]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7599(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7597 in string->time in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7599,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[372]);
t3=(C_word)C_i_check_string_2(t1,lf[372]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7612,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1974 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* k7610 in k7597 in string->time in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7616,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1974 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7614 in k7610 in k7597 in string->time in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7616,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub2248(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7513(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7513r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7513r(t0,t1,t2,t3);}}

static void C_ccall f_7513r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7517,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7517(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7517(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7515 in time->string in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7517,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[3],lf[368]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7523,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(10)))){
/* posixunix.scm: 1958 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[368],lf[371],((C_word*)t0)[3]);}
else{
t5=t3;
f_7523(2,t5,C_SCHEME_UNDEFINED);}}

/* k7521 in k7515 in time->string in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7523,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[368]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7542,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1962 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub2195(t4,t3),C_fix(0));}}

/* k7543 in k7521 in k7515 in time->string in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1966 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1967 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[368],lf[370],((C_word*)t0)[2]);}}

/* k7540 in k7521 in k7515 in time->string in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7542,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub2203(t3,t2,t1),C_fix(0));}

/* k7530 in k7521 in k7515 in time->string in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1963 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[368],lf[369],((C_word*)t0)[2]);}}

/* seconds->string in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7480,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7484,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub2180(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k7482 in seconds->string in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1950 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1951 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[366],lf[367],((C_word*)t0)[2]);}}

/* seconds->utc-time in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7461,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[365]);
/* posixunix.scm: 1943 ##sys#decode-seconds */
t4=*((C_word*)lf[364]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7452,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[363]);
/* posixunix.scm: 1939 ##sys#decode-seconds */
t4=*((C_word*)lf[364]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* memory-mapped-file? in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7446,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[354]));}

/* memory-mapped-file-pointer in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7437,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[354],lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7402(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7402r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7402r(t0,t1,t2,t3);}}

static void C_ccall f_7402r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_i_check_structure_2(t2,lf[354],lf[359]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub2141(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1926 posix-error */
t12=lf[3];
f_3456(7,t12,t1,lf[48],lf[359],lf[360],t2,t6);}}

/* map-file-to-memory in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_7340r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_7340r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_7340r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7344,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_7344(2,t10,t2);}
else{
/* posixunix.scm: 1911 ##sys#null-pointer */
t10=*((C_word*)lf[358]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k7342 in map-file-to-memory in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7344,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7350,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_7350(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1914 ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[60],lf[353],lf[357],t1);}}

/* k7348 in k7342 in map-file-to-memory in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7350,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub2102(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7356,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1916 ##sys#pointer->address */
t17=*((C_word*)lf[356]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,t14);}

/* k7367 in k7348 in k7342 in map-file-to-memory in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1917 posix-error */
t3=lf[3];
f_3456(11,t3,((C_word*)t0)[8],lf[48],lf[353],lf[355],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_7356(2,t3,C_SCHEME_UNDEFINED);}}

/* k7354 in k7348 in k7342 in map-file-to-memory in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7356,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[354],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* get-environment-variables in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7236,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7242,a[2]=t3,a[3]=((C_word)li161),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7242(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_7242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7242,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7246,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub2053(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k7244 in loop in get-environment-variables in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7246,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7254,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li160),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_7254(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k7244 in loop in get-environment-variables in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_7254(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7254,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7280,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1875 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1878 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k7278 in scan in k7244 in loop in get-environment-variables in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7284,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1876 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k7282 in k7278 in scan in k7244 in loop in get-environment-variables in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7284,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7272,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1877 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7242(t5,t3,t4);}

/* k7270 in k7282 in k7278 in scan in k7244 in loop in get-environment-variables in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7272,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7216,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[341]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7224,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1864 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7222 in unsetenv in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7199,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[340]);
t5=(C_word)C_i_check_string_2(t3,lf[340]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7210,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1859 ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k7208 in setenv in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7214,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1859 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7212 in k7208 in setenv in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7173,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[338]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7180,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7197,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1847 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k7195 in fifo? in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1847 ##sys#file-info */
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7178 in fifo? in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1850 posix-error */
t2=lf[3];
f_3456(6,t2,((C_word*)t0)[3],lf[48],lf[338],lf[339],((C_word*)t0)[2]);}}

/* create-fifo in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7130(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7130r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7130r(t0,t1,t2,t3);}}

static void C_ccall f_7130r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[336]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7137,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_7137(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_7137(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k7135 in create-fifo in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_7137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7137,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[336]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7158,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1841 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k7156 in k7135 in create-fifo in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1841 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7152 in k7135 in create-fifo in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1842 posix-error */
t3=lf[3];
f_3456(7,t3,((C_word*)t0)[3],lf[48],lf[336],lf[337],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7102,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[327],lf[334]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1831 posix-error */
t9=lf[3];
f_3456(6,t9,t1,lf[48],lf[334],lf[335],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7080r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7080r(t0,t1,t2,t3);}}

static void C_ccall f_7080r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7084,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1822 setup */
f_6958(t4,t2,t3,lf[332]);}

/* k7082 in file-test-lock in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1824 err */
f_7032(((C_word*)t0)[3],lf[333],t1,lf[332]);}}

/* file-lock/blocking in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7065(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7065r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7065r(t0,t1,t2,t3);}}

static void C_ccall f_7065r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7069,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1816 setup */
f_6958(t4,t2,t3,lf[330]);}

/* k7067 in file-lock/blocking in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1818 err */
f_7032(((C_word*)t0)[2],lf[331],t1,lf[330]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7050(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7050r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7050r(t0,t1,t2,t3);}}

static void C_ccall f_7050r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7054,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1810 setup */
f_6958(t4,t2,t3,lf[328]);}

/* k7052 in file-lock in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_7054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1812 err */
f_7032(((C_word*)t0)[2],lf[329],t1,lf[328]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_7032(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7032,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1807 posix-error */
t8=lf[3];
f_3456(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6958(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6958,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6980,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1799 ##sys#check-port */
t16=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k6978 in setup in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6980,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_6986(t6,t5);}
else{
t5=t3;
f_6986(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k6984 in k6978 in setup in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6986(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6986,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[327],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6919,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[324]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6936,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6943,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6947,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1782 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_6936(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1784 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[324],lf[326],t2);}}}

/* k6945 in file-truncate in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1782 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6941 in file-truncate in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6936(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k6934 in file-truncate in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1786 posix-error */
t2=lf[3];
f_3456(7,t2,((C_word*)t0)[4],lf[48],lf[324],lf[325],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_6660r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6660r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6660r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li144),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6846,a[2]=t6,a[3]=((C_word)li145),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6851,a[2]=t7,a[3]=((C_word)li146),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6856,a[2]=t8,a[3]=((C_word)li147),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?18271918 */
t10=t9;
f_6856(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi18281914 */
t12=t8;
f_6851(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close18291909 */
t14=t7;
f_6846(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* body18251835 */
t16=t6;
f_6662(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-nonblocking?1827 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6856(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6856,NULL,2,t0,t1);}
/* def-bufi18281914 */
t2=((C_word*)t0)[2];
f_6851(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1828 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6851(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6851,NULL,3,t0,t1,t2);}
/* def-on-close18291909 */
t3=((C_word*)t0)[2];
f_6846(t3,t1,t2,C_fix(0));}

/* def-on-close1829 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6846(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6846,NULL,4,t0,t1,t2,t3);}
/* body18251835 */
t4=((C_word*)t0)[2];
f_6662(t4,t1,t2,t3,*((C_word*)lf[319]+1));}

/* body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6662,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6666,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1724 ##sys#file-nonblocking! */
t6=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_6666(2,t6,C_SCHEME_UNDEFINED);}}

/* k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6666,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6668,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word)li137),tmp=(C_word)a,a+=7,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_6714(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6758,a[2]=t3,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6772,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1743 ##sys#make-string */
t12=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_6772(2,t12,((C_word*)t0)[6]);}}}

/* k6770 in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6772,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_6714(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6773,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li143),tmp=(C_word)a,a+=7,tmp));}

/* f_6773 in k6770 in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6773,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6790,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word)li142),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6790(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1759 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6668(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_6790(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6790,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6800,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1749 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6668(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_difference(t4,t2);
/* posixunix.scm: 1754 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k6798 in loop */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1751 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6790(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_6758 in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6758,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1742 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6668(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6712 in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6714,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6718,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6723,a[2]=((C_word*)t0)[9],a[3]=((C_word)li138),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6729,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li139),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6750,a[2]=((C_word*)t0)[9],a[3]=((C_word)li140),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1762 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t5,t6,t7,t8);}

/* a6749 in k6712 in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6750,2,t0,t1);}
/* posixunix.scm: 1772 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* a6728 in k6712 in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6729,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6739,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1769 posix-error */
t3=lf[3];
f_3456(7,t3,t2,lf[48],((C_word*)t0)[3],lf[323],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6739(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6737 in a6728 in k6712 in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1770 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6722 in k6712 in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6723,3,t0,t1,t2);}
/* posixunix.scm: 1764 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* k6716 in k6712 in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6718,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6721,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1773 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6719 in k6716 in k6712 in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6668(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6668,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6684,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1732 ##sys#thread-yield! */
t8=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1734 posix-error */
t7=lf[3];
f_3456(7,t7,t1,((C_word*)t0)[3],lf[48],lf[322],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6703,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1736 ##sys#substring */
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6701 in poke in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1736 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6668(t3,((C_word*)t0)[2],t1,t2);}

/* k6682 in poke in k6664 in body1825 in ##sys#custom-output-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1733 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6668(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_6186r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6186r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,a[7]=((C_word)li131),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6567,a[2]=t6,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6572,a[2]=t7,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6577,a[2]=t8,a[3]=((C_word)li134),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6582,a[2]=t9,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?15881786 */
t11=t10;
f_6582(t11,t1);}
else{
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi15891782 */
t13=t9;
f_6577(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close15901777 */
t15=t8;
f_6572(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?15911771 */
t17=t7;
f_6567(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
/* body15861597 */
t19=t6;
f_6188(t19,t1,t11,t13,t15,t17);}
else{
/* ##sys#error */
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[0],t18);}}}}}}

/* def-nonblocking?1588 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6582,NULL,2,t0,t1);}
/* def-bufi15891782 */
t2=((C_word*)t0)[2];
f_6577(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1589 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6577(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6577,NULL,3,t0,t1,t2);}
/* def-on-close15901777 */
t3=((C_word*)t0)[2];
f_6572(t3,t1,t2,C_fix(1));}

/* def-on-close1590 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6572(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6572,NULL,4,t0,t1,t2,t3);}
/* def-more?15911771 */
t4=((C_word*)t0)[2];
f_6567(t4,t1,t2,t3,*((C_word*)lf[319]+1));}

/* def-more?1591 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6567(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6567,NULL,5,t0,t1,t2,t3,t4);}
/* body15861597 */
t5=((C_word*)t0)[2];
f_6188(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6188(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6188,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6192,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1602 ##sys#file-nonblocking! */
t7=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_6192(2,t7,C_SCHEME_UNDEFINED);}}

/* k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6192,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1604 ##sys#make-string */
t5=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_6198(2,t5,((C_word*)t0)[10]);}}

/* k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6198,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li117),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6214,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6222,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,a[10]=((C_word)li119),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6304,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6309,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word)li120),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6322,a[2]=t6,a[3]=t3,a[4]=t5,a[5]=((C_word)li121),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6334,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=((C_word)li122),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6355,a[2]=t8,a[3]=t7,a[4]=((C_word)li123),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6364,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li125),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6440,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,a[6]=((C_word)li130),tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1648 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t18))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a6439 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6440,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6446,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li129),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_6446(t7,t1,C_SCHEME_FALSE);}

/* loop in a6439 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6446(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6446,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6448,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li126),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6526,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word)li127),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6532,a[2]=((C_word*)t0)[2],a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6542,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1713 fetch */
t5=((C_word*)t0)[5];
f_6222(t5,t4);}}

/* k6540 in loop in a6439 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1715 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6446(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a6531 in loop in a6439 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6532,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1710 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6446(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a6525 in loop in a6439 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6526,2,t0,t1);}
/* posixunix.scm: 1708 ##sys#scan-buffer-line */
t2=*((C_word*)lf[318]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a6439 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6448,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6455,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_6455(2,t8,(C_truep(t7)?t7:lf[315]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6498,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1690 ##sys#make-string */
t8=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k6496 in bumper in loop in a6439 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1696 ##sys#string-append */
t6=*((C_word*)lf[316]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_6455(2,t6,t1);}}

/* k6453 in bumper in loop in a6439 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6455,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6465,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1700 fetch */
t5=((C_word*)t0)[3];
f_6222(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1705 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k6463 in k6453 in bumper in loop in a6439 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1701 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a6363 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6364,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6372,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_6372(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_6372(t8,(C_word)C_fixnum_difference(t7,t5));}}

/* k6370 in a6363 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6372(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6372,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6374,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li124),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6374(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k6370 in a6363 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6374(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6374,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* posixunix.scm: 1676 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6422,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1678 fetch */
t7=((C_word*)t0)[2];
f_6222(t7,t6);}}}

/* k6420 in loop in k6370 in a6363 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1681 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6374(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a6354 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1666 fetch */
t3=((C_word*)t0)[2];
f_6222(t3,t2);}

/* k6357 in a6354 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1667 peek */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_6214(((C_word*)t0)[2]));}

/* a6333 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6334,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6344,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1663 posix-error */
t3=lf[3];
f_3456(7,t3,t2,lf[48],((C_word*)t0)[3],lf[314],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6344(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6342 in a6333 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1664 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6321 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6322,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1658 ready? */
t3=((C_word*)t0)[2];
f_6199(t3,t1);}}

/* a6308 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6313,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1650 fetch */
t3=((C_word*)t0)[2];
f_6222(t3,t2);}

/* k6311 in a6308 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_6214(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k6302 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6304,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6307,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1717 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6305 in k6302 in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6222,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6234,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li118),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_6234(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6234(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6234,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6250,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1625 ##sys#thread-block-for-i/o! */
t6=*((C_word*)lf[310]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[311]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1628 posix-error */
t5=lf[3];
f_3456(7,t5,t1,lf[48],((C_word*)t0)[6],lf[312],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6271,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1632 more? */
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k6269 in loop in fetch in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6271,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6274,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1634 ##sys#thread-yield! */
t3=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6280,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_6280(2,t8,t7);}
else{
/* posixunix.scm: 1640 posix-error */
t7=lf[3];
f_3456(7,t7,t4,lf[48],((C_word*)t0)[3],lf[313],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_6280(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6278 in k6269 in loop in fetch in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6272 in k6269 in loop in fetch in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1635 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6234(t2,((C_word*)t0)[2]);}

/* k6248 in loop in fetch in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1626 ##sys#thread-yield! */
t3=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6251 in k6248 in loop in fetch in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1627 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6234(t2,((C_word*)t0)[2]);}

/* peek in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall f_6214(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6199,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1610 ##sys#file-select-one */
t3=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k6211 in ready? in k6196 in k6190 in body1586 in ##sys#custom-input-port in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1611 posix-error */
t3=lf[3];
f_3456(7,t3,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[308],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* duplicate-fileno in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6159(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6159r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6159r(t0,t1,t2,t3);}}

static void C_ccall f_6159r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[303]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6166,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_6166(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[303]);
t8=t5;
f_6166(t8,(C_word)C_dup2(t2,t6));}}

/* k6164 in duplicate-fileno in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6166(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6166,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6169,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1595 posix-error */
t3=lf[3];
f_3456(6,t3,t2,lf[48],lf[303],lf[304],((C_word*)t0)[2]);}
else{
t3=t2;
f_6169(2,t3,C_SCHEME_UNDEFINED);}}

/* k6167 in k6164 in duplicate-fileno in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6114,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6118,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1577 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[297]);}

/* k6116 in port->fileno in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6118,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[298],t2);
if(C_truep(t3)){
/* posixunix.scm: 1578 ##sys#tcp-port->fileno */
t4=*((C_word*)lf[299]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1579 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k6151 in k6116 in port->fileno in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6153,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1584 posix-error */
t2=lf[3];
f_3456(6,t2,((C_word*)t0)[3],lf[60],lf[297],lf[300],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6136,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1582 posix-error */
t4=lf[3];
f_3456(6,t4,t3,lf[48],lf[297],lf[301],((C_word*)t0)[2]);}
else{
t4=t3;
f_6136(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6134 in k6151 in k6116 in port->fileno in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6100(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6100r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6100r(t0,t1,t2,t3);}}

static void C_ccall f_6100r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[296]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6112,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1573 mode */
f_6034(t5,C_SCHEME_FALSE,t3);}

/* k6110 in open-output-file* in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6112,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1573 check */
f_6071(((C_word*)t0)[2],lf[296],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6086r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6086r(t0,t1,t2,t3);}}

static void C_ccall f_6086r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[295]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6098,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1569 mode */
f_6034(t5,C_SCHEME_TRUE,t3);}

/* k6096 in open-input-file* in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6098,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1569 check */
f_6071(((C_word*)t0)[2],lf[295],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6071(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6071,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1562 posix-error */
t6=lf[3];
f_3456(6,t6,t1,lf[48],t2,lf[293],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6084,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1563 ##sys#make-port */
t7=*((C_word*)lf[146]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[147]+1),lf[294],lf[149]);}}

/* k6082 in check in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_6034(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6034,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6042,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[287]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1556 ##sys#error */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[288],t5);}
else{
t8=t4;
f_6042(2,t8,lf[289]);}}
else{
/* posixunix.scm: 1557 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[290],t5);}}
else{
t5=t4;
f_6042(2,t5,(C_truep(t2)?lf[291]:lf[292]));}}

/* k6040 in mode in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1552 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6009,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[281]);
t5=(C_word)C_i_check_string_2(t3,lf[281]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5990,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5990(2,t9,C_SCHEME_FALSE);}}

/* k5988 in file-link in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_5994(2,t3,C_SCHEME_FALSE);}}

/* k5992 in k5988 in file-link in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1466(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1537 posix-error */
t3=lf[3];
f_3456(7,t3,((C_word*)t0)[4],lf[48],lf[282],lf[283],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5959,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[279]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5967,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5983,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1526 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k5981 in read-symbolic-link in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1526 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5965 in read-symbolic-link in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5967,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5970,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1528 posix-error */
t4=lf[3];
f_3456(6,t4,t3,lf[48],lf[279],lf[280],((C_word*)t0)[2]);}
else{
t4=t3;
f_5970(2,t4,C_SCHEME_UNDEFINED);}}

/* k5968 in k5965 in read-symbolic-link in k5956 in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1529 substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5921,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[275]);
t5=(C_word)C_i_check_string_2(t3,lf[275]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5942,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5954,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1514 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5952 in create-symbolic-link in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1514 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5940 in create-symbolic-link in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5950,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1515 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5948 in k5940 in create-symbolic-link in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1515 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5944 in k5940 in create-symbolic-link in k5917 in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1517 posix-error */
t3=lf[3];
f_3456(7,t3,((C_word*)t0)[4],lf[48],lf[276],lf[277],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* create-session in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5902,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5906,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5912,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1485 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5906(2,t4,C_SCHEME_UNDEFINED);}}

/* k5910 in create-session in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1486 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[272],lf[273]);}

/* k5904 in create-session in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5896(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5896,3,t0,t1,t2);}
/* posixunix.scm: 1480 check */
f_5860(t1,t2,C_fix((C_word)X_OK),lf[271]);}

/* file-write-access? in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5890,3,t0,t1,t2);}
/* posixunix.scm: 1479 check */
f_5860(t1,t2,C_fix((C_word)W_OK),lf[270]);}

/* file-read-access? in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5884,3,t0,t1,t2);}
/* posixunix.scm: 1478 check */
f_5860(t1,t2,C_fix((C_word)R_OK),lf[269]);}

/* check in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_5860(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5860,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5878,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5882,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1475 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5880 in check in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1475 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5876 in check in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5878,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5870,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5870(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1476 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5868 in k5876 in check in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5830,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[267]);
t6=(C_word)C_i_check_exact_2(t3,lf[267]);
t7=(C_word)C_i_check_exact_2(t4,lf[267]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5854,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5858,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1465 ##sys#expand-home-path */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k5856 in change-file-owner in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1465 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5852 in change-file-owner in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1466 posix-error */
t3=lf[3];
f_3456(8,t3,((C_word*)t0)[3],lf[48],lf[267],lf[268],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5803,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[265]);
t5=(C_word)C_i_check_exact_2(t3,lf[265]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5824,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5828,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1457 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5826 in change-file-mode in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1457 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5822 in change-file-mode in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1458 posix-error */
t3=lf[3];
f_3456(7,t3,((C_word*)t0)[3],lf[48],lf[265],lf[266],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5739,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[224]);
t5=(C_word)C_i_check_exact_2(t3,lf[224]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5727,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5727(2,t9,C_SCHEME_FALSE);}}

/* k5725 in initialize-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5727,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub1291(C_SCHEME_UNDEFINED,t1,t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1378 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5753 in k5725 in initialize-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1379 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[224],lf[225],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5665,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5669,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_5595(t4);
if(C_truep(t5)){
t6=t3;
f_5669(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1361 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[221],lf[223]);}}

/* k5667 in set-groups! in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5669,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5674,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li98),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5674(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop1267 in k5667 in set-groups! in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_5674(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5674,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5690,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1366 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[221]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k5688 in doloop1267 in k5667 in set-groups! in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1367 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[221],lf[222],((C_word*)t0)[2]);}

/* get-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5602,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5606,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5660,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1347 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5606(2,t4,C_SCHEME_UNDEFINED);}}

/* k5658 in get-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1348 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[217],lf[220]);}

/* k5604 in get-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_5595(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_5609(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1350 ##sys#error */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[217],lf[219]);}}

/* k5607 in k5604 in get-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub1226(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5641,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1352 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_5612(2,t5,C_SCHEME_UNDEFINED);}}

/* k5639 in k5607 in k5604 in get-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1353 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[217],lf[218]);}

/* k5610 in k5607 in k5604 in get-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5612,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5617,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li96),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5617(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5610 in k5607 in k5604 in get-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_5617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5617,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5631,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1357 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k5629 in loop in k5610 in k5607 in k5604 in get-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5631,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall f_5595(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub1232(C_SCHEME_UNDEFINED,t2));}

/* group-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5509(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5509r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5509r(t0,t1,t2,t3);}}

static void C_ccall f_5509r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5513,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5513(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5513(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5511 in group-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5516,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_5516(t3,(C_word)C_getgrgid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[215]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5567,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1321 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5565 in k5511 in group-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5516(t2,(C_word)C_getgrnam(t1));}

/* k5514 in k5511 in group-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_5516(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5516,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5524 in k5514 in k5511 in group-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5530,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k5528 in k5524 in k5514 in k5511 in group-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5534,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5539,a[2]=t4,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5539(t6,t2,C_fix(0));}

/* loop in k5528 in k5524 in k5514 in k5511 in group-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_5539(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5539,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1184(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k5541 in loop in k5528 in k5524 in k5514 in k5511 in group-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5543,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5553,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1330 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5539(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k5551 in k5541 in loop in k5528 in k5524 in k5514 in k5511 in group-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5553,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5532 in k5528 in k5524 in k5514 in k5511 in group-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[212]+1):*((C_word*)lf[213]+1));
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5492,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5496,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1306 current-effective-user-id */
t4=*((C_word*)lf[208]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5494 in current-effective-user-name in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1306 user-information */
t2=*((C_word*)lf[211]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5490 in current-effective-user-name in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5478,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5482,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1303 current-user-id */
t4=*((C_word*)lf[207]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5480 in current-user-name in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1303 user-information */
t2=*((C_word*)lf[211]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5476 in current-user-name in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* user-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5403r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5403r(t0,t1,t2,t3);}}

static void C_ccall f_5403r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5407,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5407(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5407(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5405 in user-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5410,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_5410(t3,(C_word)C_getpwuid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[211]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5449,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1291 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5447 in k5405 in user-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5410(t2,(C_word)C_getpwnam(t1));}

/* k5408 in k5405 in user-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_5410(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5410,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5418 in k5408 in k5405 in user-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5424,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k5422 in k5418 in k5408 in k5405 in user-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5428,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k5426 in k5422 in k5418 in k5408 in k5405 in user-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5432,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k5430 in k5426 in k5422 in k5418 in k5408 in k5405 in user-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5436,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k5434 in k5430 in k5426 in k5422 in k5418 in k5408 in k5405 in user-information in k5399 in k5395 in k5391 in k5387 in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[212]+1):*((C_word*)lf[213]+1));
t3=t2;
((C_proc9)C_retrieve_proc(t3))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* system-information in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5353,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5382,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1236 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_5353(2,t3,C_SCHEME_UNDEFINED);}}

/* k5380 in system-information in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1237 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[204],lf[206]);}

/* k5351 in system-information in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k5358 in k5351 in system-information in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5364,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k5362 in k5358 in k5351 in system-information in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5368,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k5366 in k5362 in k5358 in k5351 in system-information in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5372,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k5370 in k5366 in k5362 in k5358 in k5351 in system-information in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5376,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k5374 in k5370 in k5366 in k5362 in k5358 in k5351 in system-information in k5345 in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5376,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5331,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[202]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1215 posix-error */
t5=lf[3];
f_3456(5,t5,t1,lf[196],lf[202],lf[203]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5316,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[200]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1209 posix-error */
t5=lf[3];
f_3456(5,t5,t1,lf[196],lf[200],lf[201]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5310,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[199]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5278,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5284,a[2]=t3,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5284(t5,t1,*((C_word*)lf[191]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_5284(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5284,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1199 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5254,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[195]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5261,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5272,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5271 in set-signal-mask! in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5272,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[195]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k5259 in set-signal-mask! in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1192 posix-error */
t2=lf[3];
f_3456(5,t2,((C_word*)t0)[2],lf[196],lf[195],lf[197]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5236,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5246,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1178 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1180 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k5244 in ##sys#interrupt-hook in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1179 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5223,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[194]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k5210 in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5214,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[193]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5171,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1095 posix-error */
t3=lf[3];
f_3456(5,t3,t2,lf[48],lf[164],lf[165]);}
else{
t3=t2;
f_5171(2,t3,C_SCHEME_UNDEFINED);}}

/* k5169 in create-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1096 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5147r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5147r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5147r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[163]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5151,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5149 in with-output-to-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5151,2,t0,t1);}
t2=C_mutate((C_word*)lf[163]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5157,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li76),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1083 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5156 in k5149 in with-output-to-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5157(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5157r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5157r(t0,t1,t2);}}

static void C_ccall f_5157r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5161,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1085 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5159 in a5156 in k5149 in with-output-to-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[163]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5127r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5127r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5127r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[161]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5131,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5129 in with-input-from-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5131,2,t0,t1);}
t2=C_mutate((C_word*)lf[161]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5137,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1073 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5136 in k5129 in with-input-from-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5137r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5137r(t0,t1,t2);}}

static void C_ccall f_5137r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5141,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1075 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5139 in a5136 in k5129 in with-input-from-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[161]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5103r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5103r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5103r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5107,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5105 in call-with-output-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5112,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5118,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1063 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5117 in k5105 in call-with-output-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5118r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5118r(t0,t1,t2);}}

static void C_ccall f_5118r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5122,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1066 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5120 in a5117 in k5105 in call-with-output-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5111 in k5105 in call-with-output-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5112,2,t0,t1);}
/* posixunix.scm: 1064 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5079r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5079r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5079r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5083,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5081 in call-with-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5088,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5094,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1055 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5093 in k5081 in call-with-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5094(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5094r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5094r(t0,t1,t2);}}

static void C_ccall f_5094r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5098,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1058 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5096 in a5093 in k5081 in call-with-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5087 in k5081 in call-with-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5088,2,t0,t1);}
/* posixunix.scm: 1056 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5063,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5067,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1042 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[153]);}

/* k5065 in close-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5067,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5070,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1044 posix-error */
t5=lf[3];
f_3456(6,t5,t3,lf[48],lf[154],lf[155],((C_word*)t0)[3]);}
else{
t5=t3;
f_5070(2,t5,C_SCHEME_UNDEFINED);}}

/* k5068 in k5065 in close-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_5027r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5027r(t0,t1,t2,t3);}}

static void C_ccall f_5027r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[152]);
t5=f_4958(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5041,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5048,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1037 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5058,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1038 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1039 badmode */
f_4970(t6,t5);}}}

/* k5056 in open-output-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5058,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5041(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k5046 in open-output-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5048,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5041(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k5039 in open-output-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1033 check */
f_4976(((C_word*)t0)[3],lf[152],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_4991r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4991r(t0,t1,t2,t3);}}

static void C_ccall f_4991r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[150]);
t5=f_4958(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5005,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5012,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1026 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5022,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1027 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1028 badmode */
f_4970(t6,t5);}}}

/* k5020 in open-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5022,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5005(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k5010 in open-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5012,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5005(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k5003 in open-input-pipe in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_5005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1022 check */
f_4976(((C_word*)t0)[3],lf[150],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4976(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4976,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1014 posix-error */
t6=lf[3];
f_3456(6,t6,t1,lf[48],t2,lf[145],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4989,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1015 ##sys#make-port */
t7=*((C_word*)lf[146]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[147]+1),lf[148],lf[149]);}}

/* k4987 in check in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4970(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4970,NULL,2,t1,t2);}
/* posixunix.scm: 1011 ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[144],t2);}

/* mode in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall f_4958(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[143]));}

/* canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4641,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4648,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4762,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 959  cwd */
t8=((C_word*)t0)[6];
f_4585(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4948,a[2]=((C_word*)t0)[12],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 961  sref */
t10=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_4768(t9,C_SCHEME_FALSE);}}}

/* k4946 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 961  sep? */
t2=((C_word*)t0)[3];
f_4768(t2,f_4574(t1));}

/* k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4768(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4768,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
f_4648(2,t2,((C_word*)t0)[10]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 964  cwd */
t5=((C_word*)t0)[8];
f_4585(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4923,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4934,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 965  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k4932 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 965  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k4921 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4923,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4930,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 966  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4787(t2,C_SCHEME_FALSE);}}

/* k4928 in k4921 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 966  sep? */
t2=((C_word*)t0)[3];
f_4787(t2,f_4574(t1));}

/* k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4787(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4787,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4794,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 968  getenv */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[140]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 973  cwd */
t5=((C_word*)t0)[6];
f_4585(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4895,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4916,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 974  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(0));}}}

/* k4914 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 974  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4893 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4895,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4912,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 975  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_4831(t2,C_SCHEME_FALSE);}}

/* k4910 in k4893 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 975  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4899 in k4893 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4901,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 976  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_4831(t2,C_SCHEME_FALSE);}}

/* k4906 in k4899 in k4893 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 976  sep? */
t2=((C_word*)t0)[3];
f_4831(t2,f_4574(t1));}

/* k4829 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4831,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
/* posixunix.scm: 977  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)t0)[9],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4892,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 978  sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[9],C_fix(0));}}

/* k4890 in k4829 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 978  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k4869 in k4829 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4888,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 979  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4844(2,t2,C_SCHEME_FALSE);}}

/* k4886 in k4869 in k4829 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 979  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4875 in k4869 in k4829 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4884,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 980  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_4844(2,t2,C_SCHEME_FALSE);}}

/* k4882 in k4875 in k4869 in k4829 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 980  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4842 in k4829 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4844,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
/* posixunix.scm: 981  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 982  sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],C_fix(0));}}

/* k4866 in k4842 in k4829 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=f_4574(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_4648(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 985  cwd */
t4=((C_word*)t0)[2];
f_4585(t4,t3);}}

/* k4862 in k4866 in k4842 in k4829 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 985  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[142],((C_word*)t0)[2]);}

/* k4823 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 973  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[141],((C_word*)t0)[2]);}

/* k4792 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4797(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4812,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 969  user */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k4810 in k4792 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 969  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[139],t1);}

/* k4795 in k4792 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4801,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 970  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k4799 in k4795 in k4792 in k4785 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 967  sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4779 in k4766 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 964  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[138],((C_word*)t0)[2]);}

/* k4760 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 959  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[137]);}

/* k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=t1;
/* string-split */
t4=*((C_word*)lf[101]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,lf[136]);}

/* k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4655,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li60),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_4657(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4657(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4657,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 988  null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4662 in loop in k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4664,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 989  null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4725,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 1000 string=? */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[135],t5);}}

/* k4726 in k4662 in loop in k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4725(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4737,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 1002 string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[134],t3);}}

/* k4735 in k4726 in k4662 in loop in k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4737,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4725(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_4725(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k4723 in k4662 in loop in k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4725(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 998  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4657(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4668 in k4662 in loop in k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4670,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[129]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 991  sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k4704 in k4668 in k4662 in loop in k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4706,2,t0,t1);}
t2=f_4574(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4683,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4687,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[131],((C_word*)t0)[2]);
/* posixunix.scm: 994  reverse */
t6=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4698,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4702,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 997  reverse */
t5=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4700 in k4704 in k4668 in k4662 in loop in k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 997  isperse */
f_4569(((C_word*)t0)[2],t1);}

/* k4696 in k4704 in k4668 in k4662 in loop in k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 995  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[133],t1);}

/* k4685 in k4704 in k4668 in k4662 in loop in k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 994  isperse */
f_4569(((C_word*)t0)[2],t1);}

/* k4681 in k4704 in k4668 in k4662 in loop in k4653 in k4646 in canonical-path in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 992  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[130],t1);}

/* cwd in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4585(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4585,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4592,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4594,a[2]=((C_word*)t0)[2],a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a4593 in cwd in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4594,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4600,a[2]=t2,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4618,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4617 in a4593 in cwd in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[3],a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4630,a[2]=((C_word*)t0)[2],a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4629 in a4617 in a4593 in cwd in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4630r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4630r(t0,t1,t2);}}

static void C_ccall f_4630r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4636,a[2]=t2,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
/* k787793 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4635 in a4629 in a4617 in a4593 in cwd in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4636,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4623 in a4617 in a4593 in cwd in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
/* posixunix.scm: 954  cw */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a4599 in a4593 in cwd in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4600(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4600,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4606,a[2]=t2,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
/* k787793 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4605 in a4599 in a4593 in cwd in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4606,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[125]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[126]);}

/* k4590 in cwd in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* sep? in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall f_4574(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4569(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4569,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[121]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[122]);}

/* current-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4521r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4521r(t0,t1,t2);}}

static void C_ccall f_4521r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4525(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4525(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4523 in current-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4525,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 932  change-directory */
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4534,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 933  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k4532 in k4523 in current-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 936  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 937  posix-error */
t3=lf[3];
f_3456(5,t3,((C_word*)t0)[2],lf[48],lf[113],lf[116]);}}

/* directory? in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4498,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[114]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4505,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4519,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 925  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4517 in directory? in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 925  ##sys#file-info */
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4503 in directory? in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_4341r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4341r(t0,t1,t2);}}

static void C_ccall f_4341r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4441,a[2]=t3,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4446,a[2]=t4,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec635692 */
t6=t5;
f_4446(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?636688 */
t8=t4;
f_4441(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body633642 */
t10=t3;
f_4343(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec635 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4446,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4454,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 898  current-directory */
t3=*((C_word*)lf[113]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4452 in def-spec635 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?636688 */
t2=((C_word*)t0)[3];
f_4441(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?636 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4441(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4441,NULL,3,t0,t1,t2);}
/* body633642 */
t3=((C_word*)t0)[2];
f_4343(t3,t1,t2,C_SCHEME_FALSE);}

/* body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4343(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4343,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[110]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 900  make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k4348 in body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 901  ##sys#make-pointer */
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4351 in k4348 in body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 902  ##sys#make-pointer */
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4354 in k4351 in k4348 in body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4440,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 903  ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k4438 in k4354 in k4351 in k4348 in body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 903  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4358 in k4354 in k4351 in k4348 in body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4360,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 905  posix-error */
t3=lf[3];
f_3456(6,t3,((C_word*)t0)[7],lf[48],lf[110],lf[111],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word)li43),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_4374(t6,((C_word*)t0)[7]);}}

/* loop in k4358 in k4354 in k4351 in k4348 in body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4374(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4374,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 913  ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k4382 in loop in k4358 in k4354 in k4351 in k4348 in body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 914  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_fix(0));}

/* k4385 in k4382 in loop in k4358 in k4354 in k4351 in k4348 in body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 915  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_4390(2,t3,C_SCHEME_FALSE);}}

/* k4388 in k4385 in k4382 in loop in k4358 in k4354 in k4351 in k4348 in body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4396,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_4396(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_4396(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_4396(t4,C_SCHEME_FALSE);}}

/* k4394 in k4388 in k4385 in k4382 in loop in k4358 in k4354 in k4351 in k4348 in body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_4396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4396,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 920  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4374(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 921  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4374(t3,t2);}}

/* k4404 in k4394 in k4388 in k4385 in k4382 in loop in k4358 in k4354 in k4351 in k4348 in body633 in directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4317,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[106]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4335,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4339,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 891  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4337 in delete-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 891  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4333 in delete-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 892  posix-error */
t3=lf[3];
f_3456(6,t3,((C_word*)t0)[3],lf[48],lf[106],lf[107],((C_word*)t0)[2]);}}

/* change-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4293,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[104]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4311,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4315,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 885  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4313 in change-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 885  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4309 in change-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 886  posix-error */
t3=lf[3];
f_3456(6,t3,((C_word*)t0)[3],lf[48],lf[104],lf[105],((C_word*)t0)[2]);}}

/* create-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4158r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4158r(t0,t1,t2,t3);}}

static void C_ccall f_4158r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4162,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4162(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4162(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4160 in create-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4162,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[94]);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4175,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 877  canonical-path */
t4=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 878  canonical-path */
t4=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}

/* k4254 in k4160 in create-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4257,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4257 in k4254 in k4160 in create-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4272,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 847  ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4270 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 848  posix-error */
t3=lf[3];
f_3456(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[96],((C_word*)t0)[2]);}}

/* k4173 in k4160 in create-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4176,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4176 in k4173 in k4160 in create-directory in k4154 in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4176,3,t0,t1,t2);}
t3=lf[95];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4182,a[2]=t4,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4249,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 871  string-split */
t7=*((C_word*)lf[101]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,lf[102]);}

/* k4247 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4181 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4182,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4187,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 869  string-append */
t4=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[100],t2);}

/* k4185 in a4181 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4187,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4191,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}

/* f_4191 in k4185 in a4181 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4191,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4198,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4218,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_4218 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4218,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4225,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 852  file-exists? */
t4=*((C_word*)lf[99]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4223 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4225,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 853  ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4243 in k4223 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_stat(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 854  posix-error */
t3=lf[3];
f_3456(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[97],((C_word*)t0)[2]);}
else{
t3=C_mk_bool(C_isdir);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* posixunix.scm: 857  posix-error */
t4=lf[3];
f_3456(6,t4,((C_word*)t0)[3],lf[48],lf[94],lf[98],((C_word*)t0)[2]);}}}

/* k4196 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4202,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_4202 in k4196 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4202,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4217,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 847  ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4215 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 848  posix-error */
t3=lf[3];
f_3456(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[96],((C_word*)t0)[2]);}}

/* stat-socket? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4145,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[92]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4152,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 816  ##sys#stat */
f_3968(t4,t2,C_SCHEME_FALSE,lf[92]);}

/* k4150 in stat-socket? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* stat-symlink? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4136,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[91]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4143,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 811  ##sys#stat */
f_3968(t4,t2,C_SCHEME_TRUE,lf[91]);}

/* k4141 in stat-symlink? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* stat-fifo? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4127,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4134,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 806  ##sys#stat */
f_3968(t4,t2,C_SCHEME_FALSE,lf[90]);}

/* k4132 in stat-fifo? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* stat-block-device? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4118,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4125,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 801  ##sys#stat */
f_3968(t4,t2,C_SCHEME_FALSE,lf[89]);}

/* k4123 in stat-block-device? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* stat-char-device? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4109,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4116,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 796  ##sys#stat */
f_3968(t4,t2,C_SCHEME_FALSE,lf[88]);}

/* k4114 in stat-char-device? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4100,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4107,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 791  ##sys#stat */
f_3968(t4,t2,C_SCHEME_FALSE,lf[87]);}

/* k4105 in stat-directory? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4091,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4098,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 786  ##sys#stat */
f_3968(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k4096 in stat-regular? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4082,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4089,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 781  ##sys#stat */
f_3968(t4,t2,C_SCHEME_TRUE,lf[85]);}

/* k4087 in symbolic-link? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4073,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4080,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 776  ##sys#stat */
f_3968(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k4078 in regular-file? in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4067,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4071,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 772  ##sys#stat */
f_3968(t3,t2,C_SCHEME_FALSE,lf[83]);}

/* k4069 in file-permissions in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4061,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4065,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 771  ##sys#stat */
f_3968(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k4063 in file-owner in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4055,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4059,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 770  ##sys#stat */
f_3968(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k4057 in file-change-time in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4049,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4053,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 769  ##sys#stat */
f_3968(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k4051 in file-access-time in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4043,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4047,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 768  ##sys#stat */
f_3968(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k4045 in file-modification-time in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4037,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4041,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 767  ##sys#stat */
f_3968(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k4039 in file-size in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4041,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4005r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4005r(t0,t1,t2,t3);}}

static void C_ccall f_4005r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4016,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_4016(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4016(2,t7,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k4014 in file-stat in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 760  ##sys#stat */
f_3968(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[77]);}

/* k4007 in file-stat in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_3968(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3968,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3972,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_3972(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3993,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4000,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 751  ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 755  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[76],t2);}}}

/* k3998 in ##sys#stat in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 751  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3991 in ##sys#stat in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3972(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k3970 in ##sys#stat in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 757  posix-error */
t2=lf[3];
f_3456(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[75],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3776r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3776r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3776r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_3750(C_fix(0));
t10=f_3750(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_3792(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 680  fd_set */
t14=t12;
f_3792(2,t14,f_3756(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[68]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3949,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t15=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a3948 in file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3949,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 687  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_3756(C_fix(0),t2));}

/* k3790 in file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3792,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_3798(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 692  fd_set */
t5=t3;
f_3798(2,t5,f_3756(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[68]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a3922 in k3790 in file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3923,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 699  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_3756(C_fix(1),t2));}

/* k3796 in k3790 in file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3801,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[68]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_3801(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_3801(t4,(C_word)C_C_select(t3));}}

/* k3799 in k3796 in k3790 in file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_3801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3801,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 706  posix-error */
t2=lf[3];
f_3456(7,t2,((C_word*)t0)[5],lf[48],lf[68],lf[69],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 707  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 712  fd_test */
t4=t3;
f_3840(t4,f_3766(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3881,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3883,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_3840(t4,C_SCHEME_FALSE);}}}}

/* a3882 in k3799 in k3796 in k3790 in file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3883,3,t0,t1,t2);}
t3=f_3766(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3879 in k3799 in k3796 in k3790 in file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3840(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3838 in k3799 in k3796 in k3790 in file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_3840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3840,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3844,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 718  fd_test */
t3=t2;
f_3844(t3,f_3766(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3856,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3858,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_3844(t3,C_SCHEME_FALSE);}}

/* a3857 in k3838 in k3799 in k3796 in k3790 in file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3858,3,t0,t1,t2);}
t3=f_3766(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3854 in k3838 in k3799 in k3796 in k3790 in file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3844(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3842 in k3838 in k3799 in k3796 in k3790 in file-select in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_fcall f_3844(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 709  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall f_3766(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub252(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_set in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall f_3756(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub245(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_zero in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static C_word C_fcall f_3750(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub239(C_SCHEME_UNDEFINED,t2));}

/* file-mkstemp in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3718,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[65]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3725,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 658  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3723 in file-mkstemp in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3725,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3731,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 662  posix-error */
t6=lf[3];
f_3456(6,t6,t4,lf[48],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t6=t4;
f_3731(2,t6,C_SCHEME_UNDEFINED);}}

/* k3729 in k3723 in file-mkstemp in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3738,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 663  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k3736 in k3729 in k3723 in file-mkstemp in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 663  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3679r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3679r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3679r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[62]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3686,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_3686(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 647  ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[60],lf[62],lf[64],t3);}}

/* k3684 in file-write in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[62]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3695,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 652  posix-error */
t8=lf[3];
f_3456(7,t8,t6,lf[48],lf[62],lf[63],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_3695(2,t8,C_SCHEME_UNDEFINED);}}

/* k3693 in k3684 in file-write in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3637r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3637r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3637r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3647,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_3647(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixunix.scm: 635  make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k3645 in file-read in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_3650(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 637  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[60],lf[58],lf[61],t1);}}

/* k3648 in k3645 in file-read in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3650,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3653,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 640  posix-error */
t5=lf[3];
f_3456(7,t5,t3,lf[48],lf[58],lf[59],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_3653(2,t5,C_SCHEME_UNDEFINED);}}

/* k3651 in k3648 in k3645 in file-read in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3622,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[55]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 628  posix-error */
t4=lf[3];
f_3456(6,t4,t1,lf[48],lf[55],lf[56],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3584r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3584r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3584r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[51]);
t8=(C_word)C_i_check_exact_2(t3,lf[51]);
t9=(C_word)C_i_check_exact_2(t6,lf[51]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3601,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3614,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 619  ##sys#expand-home-path */
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k3612 in file-open in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 619  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3599 in file-open in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3601,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3604,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 621  posix-error */
t5=lf[3];
f_3456(8,t5,t3,lf[48],lf[51],lf[52],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_3604(2,t5,C_SCHEME_UNDEFINED);}}

/* k3602 in k3599 in file-open in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3538r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3538r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3538r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3542,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3542(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3542(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3540 in file-control in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[47]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[47]);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_integer_argumentp(t1);
t9=(C_word)stub124(C_SCHEME_UNDEFINED,t6,t7,t8);
t10=(C_word)C_eqp(t9,C_fix(-1));
if(C_truep(t10)){
/* posixunix.scm: 609  posix-error */
t11=lf[3];
f_3456(7,t11,((C_word*)t0)[2],lf[48],lf[47],lf[49],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t9);}}

/* ##sys#file-select-one in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3481,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub46(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-nonblocking! in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3474,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub40(C_SCHEME_UNDEFINED,t3));}

/* posix-error in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_3456r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3456r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3456r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3460,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 499  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3458 in posix-error in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3467,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3471,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub23(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k3469 in k3458 in posix-error in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 500  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k3465 in k3458 in posix-error in k3442 in k3439 in k3436 in k3433 in k3430 in k3427 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[622] = {
{"toplevelposixunix.scm",(void*)C_posix_toplevel},
{"f_3429posixunix.scm",(void*)f_3429},
{"f_3432posixunix.scm",(void*)f_3432},
{"f_3435posixunix.scm",(void*)f_3435},
{"f_3438posixunix.scm",(void*)f_3438},
{"f_3441posixunix.scm",(void*)f_3441},
{"f_3444posixunix.scm",(void*)f_3444},
{"f_9338posixunix.scm",(void*)f_9338},
{"f_9351posixunix.scm",(void*)f_9351},
{"f_9363posixunix.scm",(void*)f_9363},
{"f_9357posixunix.scm",(void*)f_9357},
{"f_9301posixunix.scm",(void*)f_9301},
{"f_9317posixunix.scm",(void*)f_9317},
{"f_9305posixunix.scm",(void*)f_9305},
{"f_9308posixunix.scm",(void*)f_9308},
{"f_4156posixunix.scm",(void*)f_4156},
{"f_5212posixunix.scm",(void*)f_5212},
{"f_9295posixunix.scm",(void*)f_9295},
{"f_5347posixunix.scm",(void*)f_5347},
{"f_9280posixunix.scm",(void*)f_9280},
{"f_9290posixunix.scm",(void*)f_9290},
{"f_9277posixunix.scm",(void*)f_9277},
{"f_5389posixunix.scm",(void*)f_5389},
{"f_9262posixunix.scm",(void*)f_9262},
{"f_9272posixunix.scm",(void*)f_9272},
{"f_9259posixunix.scm",(void*)f_9259},
{"f_5393posixunix.scm",(void*)f_5393},
{"f_9244posixunix.scm",(void*)f_9244},
{"f_9254posixunix.scm",(void*)f_9254},
{"f_9241posixunix.scm",(void*)f_9241},
{"f_5397posixunix.scm",(void*)f_5397},
{"f_9226posixunix.scm",(void*)f_9226},
{"f_9236posixunix.scm",(void*)f_9236},
{"f_9223posixunix.scm",(void*)f_9223},
{"f_5401posixunix.scm",(void*)f_5401},
{"f_9202posixunix.scm",(void*)f_9202},
{"f_9218posixunix.scm",(void*)f_9218},
{"f_9184posixunix.scm",(void*)f_9184},
{"f_9197posixunix.scm",(void*)f_9197},
{"f_9191posixunix.scm",(void*)f_9191},
{"f_5919posixunix.scm",(void*)f_5919},
{"f_5958posixunix.scm",(void*)f_5958},
{"f_9161posixunix.scm",(void*)f_9161},
{"f_9153posixunix.scm",(void*)f_9153},
{"f_8902posixunix.scm",(void*)f_8902},
{"f_9079posixunix.scm",(void*)f_9079},
{"f_9085posixunix.scm",(void*)f_9085},
{"f_9074posixunix.scm",(void*)f_9074},
{"f_9069posixunix.scm",(void*)f_9069},
{"f_8904posixunix.scm",(void*)f_8904},
{"f_9056posixunix.scm",(void*)f_9056},
{"f_9064posixunix.scm",(void*)f_9064},
{"f_8911posixunix.scm",(void*)f_8911},
{"f_9044posixunix.scm",(void*)f_9044},
{"f_9038posixunix.scm",(void*)f_9038},
{"f_8921posixunix.scm",(void*)f_8921},
{"f_8923posixunix.scm",(void*)f_8923},
{"f_8942posixunix.scm",(void*)f_8942},
{"f_9024posixunix.scm",(void*)f_9024},
{"f_9031posixunix.scm",(void*)f_9031},
{"f_9018posixunix.scm",(void*)f_9018},
{"f_8957posixunix.scm",(void*)f_8957},
{"f_9011posixunix.scm",(void*)f_9011},
{"f_9008posixunix.scm",(void*)f_9008},
{"f_8998posixunix.scm",(void*)f_8998},
{"f_8974posixunix.scm",(void*)f_8974},
{"f_8996posixunix.scm",(void*)f_8996},
{"f_8982posixunix.scm",(void*)f_8982},
{"f_8989posixunix.scm",(void*)f_8989},
{"f_8986posixunix.scm",(void*)f_8986},
{"f_8969posixunix.scm",(void*)f_8969},
{"f_8967posixunix.scm",(void*)f_8967},
{"f_9045posixunix.scm",(void*)f_9045},
{"f_8842posixunix.scm",(void*)f_8842},
{"f_8854posixunix.scm",(void*)f_8854},
{"f_8849posixunix.scm",(void*)f_8849},
{"f_8844posixunix.scm",(void*)f_8844},
{"f_8782posixunix.scm",(void*)f_8782},
{"f_8794posixunix.scm",(void*)f_8794},
{"f_8789posixunix.scm",(void*)f_8789},
{"f_8784posixunix.scm",(void*)f_8784},
{"f_8721posixunix.scm",(void*)f_8721},
{"f_8776posixunix.scm",(void*)f_8776},
{"f_8780posixunix.scm",(void*)f_8780},
{"f_8742posixunix.scm",(void*)f_8742},
{"f_8745posixunix.scm",(void*)f_8745},
{"f_8756posixunix.scm",(void*)f_8756},
{"f_8750posixunix.scm",(void*)f_8750},
{"f_8723posixunix.scm",(void*)f_8723},
{"f_8732posixunix.scm",(void*)f_8732},
{"f_8663posixunix.scm",(void*)f_8663},
{"f_8675posixunix.scm",(void*)f_8675},
{"f_8706posixunix.scm",(void*)f_8706},
{"f_8686posixunix.scm",(void*)f_8686},
{"f_8702posixunix.scm",(void*)f_8702},
{"f_8690posixunix.scm",(void*)f_8690},
{"f_8698posixunix.scm",(void*)f_8698},
{"f_8694posixunix.scm",(void*)f_8694},
{"f_8669posixunix.scm",(void*)f_8669},
{"f_8652posixunix.scm",(void*)f_8652},
{"f_8656posixunix.scm",(void*)f_8656},
{"f_8641posixunix.scm",(void*)f_8641},
{"f_8645posixunix.scm",(void*)f_8645},
{"f_8596posixunix.scm",(void*)f_8596},
{"f_8600posixunix.scm",(void*)f_8600},
{"f_8603posixunix.scm",(void*)f_8603},
{"f_8606posixunix.scm",(void*)f_8606},
{"f_8619posixunix.scm",(void*)f_8619},
{"f_8623posixunix.scm",(void*)f_8623},
{"f_8626posixunix.scm",(void*)f_8626},
{"f_8629posixunix.scm",(void*)f_8629},
{"f_8617posixunix.scm",(void*)f_8617},
{"f_8580posixunix.scm",(void*)f_8580},
{"f_8563posixunix.scm",(void*)f_8563},
{"f_8576posixunix.scm",(void*)f_8576},
{"f_8488posixunix.scm",(void*)f_8488},
{"f_8549posixunix.scm",(void*)f_8549},
{"f_8562posixunix.scm",(void*)f_8562},
{"f_8529posixunix.scm",(void*)f_8529},
{"f_8544posixunix.scm",(void*)f_8544},
{"f_8538posixunix.scm",(void*)f_8538},
{"f_8492posixunix.scm",(void*)f_8492},
{"f_8494posixunix.scm",(void*)f_8494},
{"f_8515posixunix.scm",(void*)f_8515},
{"f_8509posixunix.scm",(void*)f_8509},
{"f_8436posixunix.scm",(void*)f_8436},
{"f_8443posixunix.scm",(void*)f_8443},
{"f_8462posixunix.scm",(void*)f_8462},
{"f_8466posixunix.scm",(void*)f_8466},
{"f_8430posixunix.scm",(void*)f_8430},
{"f_8421posixunix.scm",(void*)f_8421},
{"f_8425posixunix.scm",(void*)f_8425},
{"f_8394posixunix.scm",(void*)f_8394},
{"f_8387posixunix.scm",(void*)f_8387},
{"f_8384posixunix.scm",(void*)f_8384},
{"f_8381posixunix.scm",(void*)f_8381},
{"f_8303posixunix.scm",(void*)f_8303},
{"f_8339posixunix.scm",(void*)f_8339},
{"f_8333posixunix.scm",(void*)f_8333},
{"f_8286posixunix.scm",(void*)f_8286},
{"f_8104posixunix.scm",(void*)f_8104},
{"f_8238posixunix.scm",(void*)f_8238},
{"f_8233posixunix.scm",(void*)f_8233},
{"f_8106posixunix.scm",(void*)f_8106},
{"f_8116posixunix.scm",(void*)f_8116},
{"f_8124posixunix.scm",(void*)f_8124},
{"f_8170posixunix.scm",(void*)f_8170},
{"f_8137posixunix.scm",(void*)f_8137},
{"f_8162posixunix.scm",(void*)f_8162},
{"f_8140posixunix.scm",(void*)f_8140},
{"f_8085posixunix.scm",(void*)f_8085},
{"f_8066posixunix.scm",(void*)f_8066},
{"f_8024posixunix.scm",(void*)f_8024},
{"f_8046posixunix.scm",(void*)f_8046},
{"f_8050posixunix.scm",(void*)f_8050},
{"f_7912posixunix.scm",(void*)f_7912},
{"f_7918posixunix.scm",(void*)f_7918},
{"f_7939posixunix.scm",(void*)f_7939},
{"f_8016posixunix.scm",(void*)f_8016},
{"f_7943posixunix.scm",(void*)f_7943},
{"f_7946posixunix.scm",(void*)f_7946},
{"f_7949posixunix.scm",(void*)f_7949},
{"f_7956posixunix.scm",(void*)f_7956},
{"f_7958posixunix.scm",(void*)f_7958},
{"f_7975posixunix.scm",(void*)f_7975},
{"f_7985posixunix.scm",(void*)f_7985},
{"f_7989posixunix.scm",(void*)f_7989},
{"f_7933posixunix.scm",(void*)f_7933},
{"f_7900posixunix.scm",(void*)f_7900},
{"f_7904posixunix.scm",(void*)f_7904},
{"f_7907posixunix.scm",(void*)f_7907},
{"f_7865posixunix.scm",(void*)f_7865},
{"f_7869posixunix.scm",(void*)f_7869},
{"f_7889posixunix.scm",(void*)f_7889},
{"f_7893posixunix.scm",(void*)f_7893},
{"f_7842posixunix.scm",(void*)f_7842},
{"f_7846posixunix.scm",(void*)f_7846},
{"f_7810posixunix.scm",(void*)f_7810},
{"f_7814posixunix.scm",(void*)f_7814},
{"f_7791posixunix.scm",(void*)f_7791},
{"f_7795posixunix.scm",(void*)f_7795},
{"f_7798posixunix.scm",(void*)f_7798},
{"f_7732posixunix.scm",(void*)f_7732},
{"f_7736posixunix.scm",(void*)f_7736},
{"f_7742posixunix.scm",(void*)f_7742},
{"f_7725posixunix.scm",(void*)f_7725},
{"f_7709posixunix.scm",(void*)f_7709},
{"f_7697posixunix.scm",(void*)f_7697},
{"f_7669posixunix.scm",(void*)f_7669},
{"f_7676posixunix.scm",(void*)f_7676},
{"f_7641posixunix.scm",(void*)f_7641},
{"f_7648posixunix.scm",(void*)f_7648},
{"f_7595posixunix.scm",(void*)f_7595},
{"f_7599posixunix.scm",(void*)f_7599},
{"f_7612posixunix.scm",(void*)f_7612},
{"f_7616posixunix.scm",(void*)f_7616},
{"f_7513posixunix.scm",(void*)f_7513},
{"f_7517posixunix.scm",(void*)f_7517},
{"f_7523posixunix.scm",(void*)f_7523},
{"f_7545posixunix.scm",(void*)f_7545},
{"f_7542posixunix.scm",(void*)f_7542},
{"f_7532posixunix.scm",(void*)f_7532},
{"f_7480posixunix.scm",(void*)f_7480},
{"f_7484posixunix.scm",(void*)f_7484},
{"f_7461posixunix.scm",(void*)f_7461},
{"f_7452posixunix.scm",(void*)f_7452},
{"f_7446posixunix.scm",(void*)f_7446},
{"f_7437posixunix.scm",(void*)f_7437},
{"f_7402posixunix.scm",(void*)f_7402},
{"f_7340posixunix.scm",(void*)f_7340},
{"f_7344posixunix.scm",(void*)f_7344},
{"f_7350posixunix.scm",(void*)f_7350},
{"f_7369posixunix.scm",(void*)f_7369},
{"f_7356posixunix.scm",(void*)f_7356},
{"f_7236posixunix.scm",(void*)f_7236},
{"f_7242posixunix.scm",(void*)f_7242},
{"f_7246posixunix.scm",(void*)f_7246},
{"f_7254posixunix.scm",(void*)f_7254},
{"f_7280posixunix.scm",(void*)f_7280},
{"f_7284posixunix.scm",(void*)f_7284},
{"f_7272posixunix.scm",(void*)f_7272},
{"f_7216posixunix.scm",(void*)f_7216},
{"f_7224posixunix.scm",(void*)f_7224},
{"f_7199posixunix.scm",(void*)f_7199},
{"f_7210posixunix.scm",(void*)f_7210},
{"f_7214posixunix.scm",(void*)f_7214},
{"f_7173posixunix.scm",(void*)f_7173},
{"f_7197posixunix.scm",(void*)f_7197},
{"f_7180posixunix.scm",(void*)f_7180},
{"f_7130posixunix.scm",(void*)f_7130},
{"f_7137posixunix.scm",(void*)f_7137},
{"f_7158posixunix.scm",(void*)f_7158},
{"f_7154posixunix.scm",(void*)f_7154},
{"f_7102posixunix.scm",(void*)f_7102},
{"f_7080posixunix.scm",(void*)f_7080},
{"f_7084posixunix.scm",(void*)f_7084},
{"f_7065posixunix.scm",(void*)f_7065},
{"f_7069posixunix.scm",(void*)f_7069},
{"f_7050posixunix.scm",(void*)f_7050},
{"f_7054posixunix.scm",(void*)f_7054},
{"f_7032posixunix.scm",(void*)f_7032},
{"f_6958posixunix.scm",(void*)f_6958},
{"f_6980posixunix.scm",(void*)f_6980},
{"f_6986posixunix.scm",(void*)f_6986},
{"f_6919posixunix.scm",(void*)f_6919},
{"f_6947posixunix.scm",(void*)f_6947},
{"f_6943posixunix.scm",(void*)f_6943},
{"f_6936posixunix.scm",(void*)f_6936},
{"f_6660posixunix.scm",(void*)f_6660},
{"f_6856posixunix.scm",(void*)f_6856},
{"f_6851posixunix.scm",(void*)f_6851},
{"f_6846posixunix.scm",(void*)f_6846},
{"f_6662posixunix.scm",(void*)f_6662},
{"f_6666posixunix.scm",(void*)f_6666},
{"f_6772posixunix.scm",(void*)f_6772},
{"f_6773posixunix.scm",(void*)f_6773},
{"f_6790posixunix.scm",(void*)f_6790},
{"f_6800posixunix.scm",(void*)f_6800},
{"f_6758posixunix.scm",(void*)f_6758},
{"f_6714posixunix.scm",(void*)f_6714},
{"f_6750posixunix.scm",(void*)f_6750},
{"f_6729posixunix.scm",(void*)f_6729},
{"f_6739posixunix.scm",(void*)f_6739},
{"f_6723posixunix.scm",(void*)f_6723},
{"f_6718posixunix.scm",(void*)f_6718},
{"f_6721posixunix.scm",(void*)f_6721},
{"f_6668posixunix.scm",(void*)f_6668},
{"f_6703posixunix.scm",(void*)f_6703},
{"f_6684posixunix.scm",(void*)f_6684},
{"f_6186posixunix.scm",(void*)f_6186},
{"f_6582posixunix.scm",(void*)f_6582},
{"f_6577posixunix.scm",(void*)f_6577},
{"f_6572posixunix.scm",(void*)f_6572},
{"f_6567posixunix.scm",(void*)f_6567},
{"f_6188posixunix.scm",(void*)f_6188},
{"f_6192posixunix.scm",(void*)f_6192},
{"f_6198posixunix.scm",(void*)f_6198},
{"f_6440posixunix.scm",(void*)f_6440},
{"f_6446posixunix.scm",(void*)f_6446},
{"f_6542posixunix.scm",(void*)f_6542},
{"f_6532posixunix.scm",(void*)f_6532},
{"f_6526posixunix.scm",(void*)f_6526},
{"f_6448posixunix.scm",(void*)f_6448},
{"f_6498posixunix.scm",(void*)f_6498},
{"f_6455posixunix.scm",(void*)f_6455},
{"f_6465posixunix.scm",(void*)f_6465},
{"f_6364posixunix.scm",(void*)f_6364},
{"f_6372posixunix.scm",(void*)f_6372},
{"f_6374posixunix.scm",(void*)f_6374},
{"f_6422posixunix.scm",(void*)f_6422},
{"f_6355posixunix.scm",(void*)f_6355},
{"f_6359posixunix.scm",(void*)f_6359},
{"f_6334posixunix.scm",(void*)f_6334},
{"f_6344posixunix.scm",(void*)f_6344},
{"f_6322posixunix.scm",(void*)f_6322},
{"f_6309posixunix.scm",(void*)f_6309},
{"f_6313posixunix.scm",(void*)f_6313},
{"f_6304posixunix.scm",(void*)f_6304},
{"f_6307posixunix.scm",(void*)f_6307},
{"f_6222posixunix.scm",(void*)f_6222},
{"f_6234posixunix.scm",(void*)f_6234},
{"f_6271posixunix.scm",(void*)f_6271},
{"f_6280posixunix.scm",(void*)f_6280},
{"f_6274posixunix.scm",(void*)f_6274},
{"f_6250posixunix.scm",(void*)f_6250},
{"f_6253posixunix.scm",(void*)f_6253},
{"f_6214posixunix.scm",(void*)f_6214},
{"f_6199posixunix.scm",(void*)f_6199},
{"f_6213posixunix.scm",(void*)f_6213},
{"f_6159posixunix.scm",(void*)f_6159},
{"f_6166posixunix.scm",(void*)f_6166},
{"f_6169posixunix.scm",(void*)f_6169},
{"f_6114posixunix.scm",(void*)f_6114},
{"f_6118posixunix.scm",(void*)f_6118},
{"f_6153posixunix.scm",(void*)f_6153},
{"f_6136posixunix.scm",(void*)f_6136},
{"f_6100posixunix.scm",(void*)f_6100},
{"f_6112posixunix.scm",(void*)f_6112},
{"f_6086posixunix.scm",(void*)f_6086},
{"f_6098posixunix.scm",(void*)f_6098},
{"f_6071posixunix.scm",(void*)f_6071},
{"f_6084posixunix.scm",(void*)f_6084},
{"f_6034posixunix.scm",(void*)f_6034},
{"f_6042posixunix.scm",(void*)f_6042},
{"f_6009posixunix.scm",(void*)f_6009},
{"f_5990posixunix.scm",(void*)f_5990},
{"f_5994posixunix.scm",(void*)f_5994},
{"f_5959posixunix.scm",(void*)f_5959},
{"f_5983posixunix.scm",(void*)f_5983},
{"f_5967posixunix.scm",(void*)f_5967},
{"f_5970posixunix.scm",(void*)f_5970},
{"f_5921posixunix.scm",(void*)f_5921},
{"f_5954posixunix.scm",(void*)f_5954},
{"f_5942posixunix.scm",(void*)f_5942},
{"f_5950posixunix.scm",(void*)f_5950},
{"f_5946posixunix.scm",(void*)f_5946},
{"f_5902posixunix.scm",(void*)f_5902},
{"f_5912posixunix.scm",(void*)f_5912},
{"f_5906posixunix.scm",(void*)f_5906},
{"f_5896posixunix.scm",(void*)f_5896},
{"f_5890posixunix.scm",(void*)f_5890},
{"f_5884posixunix.scm",(void*)f_5884},
{"f_5860posixunix.scm",(void*)f_5860},
{"f_5882posixunix.scm",(void*)f_5882},
{"f_5878posixunix.scm",(void*)f_5878},
{"f_5870posixunix.scm",(void*)f_5870},
{"f_5830posixunix.scm",(void*)f_5830},
{"f_5858posixunix.scm",(void*)f_5858},
{"f_5854posixunix.scm",(void*)f_5854},
{"f_5803posixunix.scm",(void*)f_5803},
{"f_5828posixunix.scm",(void*)f_5828},
{"f_5824posixunix.scm",(void*)f_5824},
{"f_5739posixunix.scm",(void*)f_5739},
{"f_5727posixunix.scm",(void*)f_5727},
{"f_5755posixunix.scm",(void*)f_5755},
{"f_5665posixunix.scm",(void*)f_5665},
{"f_5669posixunix.scm",(void*)f_5669},
{"f_5674posixunix.scm",(void*)f_5674},
{"f_5690posixunix.scm",(void*)f_5690},
{"f_5602posixunix.scm",(void*)f_5602},
{"f_5660posixunix.scm",(void*)f_5660},
{"f_5606posixunix.scm",(void*)f_5606},
{"f_5609posixunix.scm",(void*)f_5609},
{"f_5641posixunix.scm",(void*)f_5641},
{"f_5612posixunix.scm",(void*)f_5612},
{"f_5617posixunix.scm",(void*)f_5617},
{"f_5631posixunix.scm",(void*)f_5631},
{"f_5595posixunix.scm",(void*)f_5595},
{"f_5509posixunix.scm",(void*)f_5509},
{"f_5513posixunix.scm",(void*)f_5513},
{"f_5567posixunix.scm",(void*)f_5567},
{"f_5516posixunix.scm",(void*)f_5516},
{"f_5526posixunix.scm",(void*)f_5526},
{"f_5530posixunix.scm",(void*)f_5530},
{"f_5539posixunix.scm",(void*)f_5539},
{"f_5543posixunix.scm",(void*)f_5543},
{"f_5553posixunix.scm",(void*)f_5553},
{"f_5534posixunix.scm",(void*)f_5534},
{"f_5484posixunix.scm",(void*)f_5484},
{"f_5496posixunix.scm",(void*)f_5496},
{"f_5492posixunix.scm",(void*)f_5492},
{"f_5470posixunix.scm",(void*)f_5470},
{"f_5482posixunix.scm",(void*)f_5482},
{"f_5478posixunix.scm",(void*)f_5478},
{"f_5403posixunix.scm",(void*)f_5403},
{"f_5407posixunix.scm",(void*)f_5407},
{"f_5449posixunix.scm",(void*)f_5449},
{"f_5410posixunix.scm",(void*)f_5410},
{"f_5420posixunix.scm",(void*)f_5420},
{"f_5424posixunix.scm",(void*)f_5424},
{"f_5428posixunix.scm",(void*)f_5428},
{"f_5432posixunix.scm",(void*)f_5432},
{"f_5436posixunix.scm",(void*)f_5436},
{"f_5349posixunix.scm",(void*)f_5349},
{"f_5382posixunix.scm",(void*)f_5382},
{"f_5353posixunix.scm",(void*)f_5353},
{"f_5360posixunix.scm",(void*)f_5360},
{"f_5364posixunix.scm",(void*)f_5364},
{"f_5368posixunix.scm",(void*)f_5368},
{"f_5372posixunix.scm",(void*)f_5372},
{"f_5376posixunix.scm",(void*)f_5376},
{"f_5331posixunix.scm",(void*)f_5331},
{"f_5316posixunix.scm",(void*)f_5316},
{"f_5310posixunix.scm",(void*)f_5310},
{"f_5278posixunix.scm",(void*)f_5278},
{"f_5284posixunix.scm",(void*)f_5284},
{"f_5254posixunix.scm",(void*)f_5254},
{"f_5272posixunix.scm",(void*)f_5272},
{"f_5261posixunix.scm",(void*)f_5261},
{"f_5236posixunix.scm",(void*)f_5236},
{"f_5246posixunix.scm",(void*)f_5246},
{"f_5223posixunix.scm",(void*)f_5223},
{"f_5214posixunix.scm",(void*)f_5214},
{"f_5167posixunix.scm",(void*)f_5167},
{"f_5171posixunix.scm",(void*)f_5171},
{"f_5147posixunix.scm",(void*)f_5147},
{"f_5151posixunix.scm",(void*)f_5151},
{"f_5157posixunix.scm",(void*)f_5157},
{"f_5161posixunix.scm",(void*)f_5161},
{"f_5127posixunix.scm",(void*)f_5127},
{"f_5131posixunix.scm",(void*)f_5131},
{"f_5137posixunix.scm",(void*)f_5137},
{"f_5141posixunix.scm",(void*)f_5141},
{"f_5103posixunix.scm",(void*)f_5103},
{"f_5107posixunix.scm",(void*)f_5107},
{"f_5118posixunix.scm",(void*)f_5118},
{"f_5122posixunix.scm",(void*)f_5122},
{"f_5112posixunix.scm",(void*)f_5112},
{"f_5079posixunix.scm",(void*)f_5079},
{"f_5083posixunix.scm",(void*)f_5083},
{"f_5094posixunix.scm",(void*)f_5094},
{"f_5098posixunix.scm",(void*)f_5098},
{"f_5088posixunix.scm",(void*)f_5088},
{"f_5063posixunix.scm",(void*)f_5063},
{"f_5067posixunix.scm",(void*)f_5067},
{"f_5070posixunix.scm",(void*)f_5070},
{"f_5027posixunix.scm",(void*)f_5027},
{"f_5058posixunix.scm",(void*)f_5058},
{"f_5048posixunix.scm",(void*)f_5048},
{"f_5041posixunix.scm",(void*)f_5041},
{"f_4991posixunix.scm",(void*)f_4991},
{"f_5022posixunix.scm",(void*)f_5022},
{"f_5012posixunix.scm",(void*)f_5012},
{"f_5005posixunix.scm",(void*)f_5005},
{"f_4976posixunix.scm",(void*)f_4976},
{"f_4989posixunix.scm",(void*)f_4989},
{"f_4970posixunix.scm",(void*)f_4970},
{"f_4958posixunix.scm",(void*)f_4958},
{"f_4641posixunix.scm",(void*)f_4641},
{"f_4948posixunix.scm",(void*)f_4948},
{"f_4768posixunix.scm",(void*)f_4768},
{"f_4934posixunix.scm",(void*)f_4934},
{"f_4923posixunix.scm",(void*)f_4923},
{"f_4930posixunix.scm",(void*)f_4930},
{"f_4787posixunix.scm",(void*)f_4787},
{"f_4916posixunix.scm",(void*)f_4916},
{"f_4895posixunix.scm",(void*)f_4895},
{"f_4912posixunix.scm",(void*)f_4912},
{"f_4901posixunix.scm",(void*)f_4901},
{"f_4908posixunix.scm",(void*)f_4908},
{"f_4831posixunix.scm",(void*)f_4831},
{"f_4892posixunix.scm",(void*)f_4892},
{"f_4871posixunix.scm",(void*)f_4871},
{"f_4888posixunix.scm",(void*)f_4888},
{"f_4877posixunix.scm",(void*)f_4877},
{"f_4884posixunix.scm",(void*)f_4884},
{"f_4844posixunix.scm",(void*)f_4844},
{"f_4868posixunix.scm",(void*)f_4868},
{"f_4864posixunix.scm",(void*)f_4864},
{"f_4825posixunix.scm",(void*)f_4825},
{"f_4794posixunix.scm",(void*)f_4794},
{"f_4812posixunix.scm",(void*)f_4812},
{"f_4797posixunix.scm",(void*)f_4797},
{"f_4801posixunix.scm",(void*)f_4801},
{"f_4781posixunix.scm",(void*)f_4781},
{"f_4762posixunix.scm",(void*)f_4762},
{"f_4648posixunix.scm",(void*)f_4648},
{"f_4655posixunix.scm",(void*)f_4655},
{"f_4657posixunix.scm",(void*)f_4657},
{"f_4664posixunix.scm",(void*)f_4664},
{"f_4728posixunix.scm",(void*)f_4728},
{"f_4737posixunix.scm",(void*)f_4737},
{"f_4725posixunix.scm",(void*)f_4725},
{"f_4670posixunix.scm",(void*)f_4670},
{"f_4706posixunix.scm",(void*)f_4706},
{"f_4702posixunix.scm",(void*)f_4702},
{"f_4698posixunix.scm",(void*)f_4698},
{"f_4687posixunix.scm",(void*)f_4687},
{"f_4683posixunix.scm",(void*)f_4683},
{"f_4585posixunix.scm",(void*)f_4585},
{"f_4594posixunix.scm",(void*)f_4594},
{"f_4618posixunix.scm",(void*)f_4618},
{"f_4630posixunix.scm",(void*)f_4630},
{"f_4636posixunix.scm",(void*)f_4636},
{"f_4624posixunix.scm",(void*)f_4624},
{"f_4600posixunix.scm",(void*)f_4600},
{"f_4606posixunix.scm",(void*)f_4606},
{"f_4592posixunix.scm",(void*)f_4592},
{"f_4574posixunix.scm",(void*)f_4574},
{"f_4569posixunix.scm",(void*)f_4569},
{"f_4521posixunix.scm",(void*)f_4521},
{"f_4525posixunix.scm",(void*)f_4525},
{"f_4534posixunix.scm",(void*)f_4534},
{"f_4498posixunix.scm",(void*)f_4498},
{"f_4519posixunix.scm",(void*)f_4519},
{"f_4505posixunix.scm",(void*)f_4505},
{"f_4341posixunix.scm",(void*)f_4341},
{"f_4446posixunix.scm",(void*)f_4446},
{"f_4454posixunix.scm",(void*)f_4454},
{"f_4441posixunix.scm",(void*)f_4441},
{"f_4343posixunix.scm",(void*)f_4343},
{"f_4350posixunix.scm",(void*)f_4350},
{"f_4353posixunix.scm",(void*)f_4353},
{"f_4356posixunix.scm",(void*)f_4356},
{"f_4440posixunix.scm",(void*)f_4440},
{"f_4360posixunix.scm",(void*)f_4360},
{"f_4374posixunix.scm",(void*)f_4374},
{"f_4384posixunix.scm",(void*)f_4384},
{"f_4387posixunix.scm",(void*)f_4387},
{"f_4390posixunix.scm",(void*)f_4390},
{"f_4396posixunix.scm",(void*)f_4396},
{"f_4406posixunix.scm",(void*)f_4406},
{"f_4317posixunix.scm",(void*)f_4317},
{"f_4339posixunix.scm",(void*)f_4339},
{"f_4335posixunix.scm",(void*)f_4335},
{"f_4293posixunix.scm",(void*)f_4293},
{"f_4315posixunix.scm",(void*)f_4315},
{"f_4311posixunix.scm",(void*)f_4311},
{"f_4158posixunix.scm",(void*)f_4158},
{"f_4162posixunix.scm",(void*)f_4162},
{"f_4256posixunix.scm",(void*)f_4256},
{"f_4257posixunix.scm",(void*)f_4257},
{"f_4272posixunix.scm",(void*)f_4272},
{"f_4175posixunix.scm",(void*)f_4175},
{"f_4176posixunix.scm",(void*)f_4176},
{"f_4249posixunix.scm",(void*)f_4249},
{"f_4182posixunix.scm",(void*)f_4182},
{"f_4187posixunix.scm",(void*)f_4187},
{"f_4191posixunix.scm",(void*)f_4191},
{"f_4218posixunix.scm",(void*)f_4218},
{"f_4225posixunix.scm",(void*)f_4225},
{"f_4245posixunix.scm",(void*)f_4245},
{"f_4198posixunix.scm",(void*)f_4198},
{"f_4202posixunix.scm",(void*)f_4202},
{"f_4217posixunix.scm",(void*)f_4217},
{"f_4145posixunix.scm",(void*)f_4145},
{"f_4152posixunix.scm",(void*)f_4152},
{"f_4136posixunix.scm",(void*)f_4136},
{"f_4143posixunix.scm",(void*)f_4143},
{"f_4127posixunix.scm",(void*)f_4127},
{"f_4134posixunix.scm",(void*)f_4134},
{"f_4118posixunix.scm",(void*)f_4118},
{"f_4125posixunix.scm",(void*)f_4125},
{"f_4109posixunix.scm",(void*)f_4109},
{"f_4116posixunix.scm",(void*)f_4116},
{"f_4100posixunix.scm",(void*)f_4100},
{"f_4107posixunix.scm",(void*)f_4107},
{"f_4091posixunix.scm",(void*)f_4091},
{"f_4098posixunix.scm",(void*)f_4098},
{"f_4082posixunix.scm",(void*)f_4082},
{"f_4089posixunix.scm",(void*)f_4089},
{"f_4073posixunix.scm",(void*)f_4073},
{"f_4080posixunix.scm",(void*)f_4080},
{"f_4067posixunix.scm",(void*)f_4067},
{"f_4071posixunix.scm",(void*)f_4071},
{"f_4061posixunix.scm",(void*)f_4061},
{"f_4065posixunix.scm",(void*)f_4065},
{"f_4055posixunix.scm",(void*)f_4055},
{"f_4059posixunix.scm",(void*)f_4059},
{"f_4049posixunix.scm",(void*)f_4049},
{"f_4053posixunix.scm",(void*)f_4053},
{"f_4043posixunix.scm",(void*)f_4043},
{"f_4047posixunix.scm",(void*)f_4047},
{"f_4037posixunix.scm",(void*)f_4037},
{"f_4041posixunix.scm",(void*)f_4041},
{"f_4005posixunix.scm",(void*)f_4005},
{"f_4016posixunix.scm",(void*)f_4016},
{"f_4009posixunix.scm",(void*)f_4009},
{"f_3968posixunix.scm",(void*)f_3968},
{"f_4000posixunix.scm",(void*)f_4000},
{"f_3993posixunix.scm",(void*)f_3993},
{"f_3972posixunix.scm",(void*)f_3972},
{"f_3776posixunix.scm",(void*)f_3776},
{"f_3949posixunix.scm",(void*)f_3949},
{"f_3792posixunix.scm",(void*)f_3792},
{"f_3923posixunix.scm",(void*)f_3923},
{"f_3798posixunix.scm",(void*)f_3798},
{"f_3801posixunix.scm",(void*)f_3801},
{"f_3883posixunix.scm",(void*)f_3883},
{"f_3881posixunix.scm",(void*)f_3881},
{"f_3840posixunix.scm",(void*)f_3840},
{"f_3858posixunix.scm",(void*)f_3858},
{"f_3856posixunix.scm",(void*)f_3856},
{"f_3844posixunix.scm",(void*)f_3844},
{"f_3766posixunix.scm",(void*)f_3766},
{"f_3756posixunix.scm",(void*)f_3756},
{"f_3750posixunix.scm",(void*)f_3750},
{"f_3718posixunix.scm",(void*)f_3718},
{"f_3725posixunix.scm",(void*)f_3725},
{"f_3731posixunix.scm",(void*)f_3731},
{"f_3738posixunix.scm",(void*)f_3738},
{"f_3679posixunix.scm",(void*)f_3679},
{"f_3686posixunix.scm",(void*)f_3686},
{"f_3695posixunix.scm",(void*)f_3695},
{"f_3637posixunix.scm",(void*)f_3637},
{"f_3647posixunix.scm",(void*)f_3647},
{"f_3650posixunix.scm",(void*)f_3650},
{"f_3653posixunix.scm",(void*)f_3653},
{"f_3622posixunix.scm",(void*)f_3622},
{"f_3584posixunix.scm",(void*)f_3584},
{"f_3614posixunix.scm",(void*)f_3614},
{"f_3601posixunix.scm",(void*)f_3601},
{"f_3604posixunix.scm",(void*)f_3604},
{"f_3538posixunix.scm",(void*)f_3538},
{"f_3542posixunix.scm",(void*)f_3542},
{"f_3481posixunix.scm",(void*)f_3481},
{"f_3474posixunix.scm",(void*)f_3474},
{"f_3456posixunix.scm",(void*)f_3456},
{"f_3460posixunix.scm",(void*)f_3460},
{"f_3471posixunix.scm",(void*)f_3471},
{"f_3467posixunix.scm",(void*)f_3467},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
