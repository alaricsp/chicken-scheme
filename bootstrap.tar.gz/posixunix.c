/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-12 23:07
   Version 3.0.2 - macosx-unix-gnu-ppc	[ manyargs dload ptables applyhook lockts ]
   SVN rev. 8608	compiled 2008-02-23 on apfel (Darwin)
   command line: posixunix.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
#endif
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set_9(v) \
        (C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)))

#define C_tm_get_08(v) \
        (C_set_block_item(v, 0, C_fix(C_tm.tm_sec)), \
        C_set_block_item(v, 1, C_fix(C_tm.tm_min)), \
        C_set_block_item(v, 2, C_fix(C_tm.tm_hour)), \
        C_set_block_item(v, 3, C_fix(C_tm.tm_mday)), \
        C_set_block_item(v, 4, C_fix(C_tm.tm_mon)), \
        C_set_block_item(v, 5, C_fix(C_tm.tm_year)), \
        C_set_block_item(v, 6, C_fix(C_tm.tm_wday)), \
        C_set_block_item(v, 7, C_fix(C_tm.tm_yday)), \
        C_set_block_item(v, 8, (C_tm.tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define C_tm_get_9(v) \
        (C_set_block_item(v, 9, C_fix(C_tm.tm_gmtoff)))

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  return &C_tm;
}

static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  return v;
}

#else

static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  C_tm_set_9 (v);
  return &C_tm;
}

static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  C_tm_get_9 (v);
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[457];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,38),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,55,32,108,111,99,56,32,109,115,103,57,32,46,32,97,114,103,115,49,48,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,49,50,49,53,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,49,54,49,57,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,51,48,32,99,109,100,51,49,32,46,32,103,50,57,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,52,49,32,102,108,97,103,115,52,50,32,46,32,109,111,100,101,52,51,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,99,108,111,115,101,32,102,100,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,114,101,97,100,32,102,100,53,51,32,115,105,122,101,53,52,32,46,32,98,117,102,102,101,114,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,119,114,105,116,101,32,102,100,54,50,32,98,117,102,102,101,114,54,51,32,46,32,115,105,122,101,54,52,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,9),40,102,100,95,122,101,114,111,41,0,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,14),40,102,100,95,115,101,116,32,97,56,52,56,57,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,15),40,102,100,95,116,101,115,116,32,97,57,48,57,53,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,50,48,50,55,32,102,100,49,50,49,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,97,50,48,53,50,32,102,100,49,49,56,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,13),40,97,50,48,57,50,32,102,100,49,49,49,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,50,49,49,56,32,102,100,49,48,52,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,57,54,32,102,100,115,119,57,55,32,46,32,116,105,109,101,111,117,116,57,56,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,49,50,55,32,108,105,110,107,49,50,56,32,108,111,99,49,50,57,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,49,51,50,32,46,32,108,105,110,107,49,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,49,51,55,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,49,51,57,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,49,52,49,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,49,52,51,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,49,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,49,52,55,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,49,52,57,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,49,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,114,101,103,117,108,97,114,63,32,102,110,97,109,101,49,53,55,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,115,116,97,116,45,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,49,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,28),40,115,116,97,116,45,99,104,97,114,45,100,101,118,105,99,101,63,32,102,110,97,109,101,49,54,53,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,29),40,115,116,97,116,45,98,108,111,99,107,45,100,101,118,105,99,101,63,32,102,110,97,109,101,49,54,57,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,21),40,115,116,97,116,45,102,105,102,111,63,32,102,110,97,109,101,49,55,51,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,115,121,109,108,105,110,107,63,32,102,110,97,109,101,49,55,55,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,115,116,97,116,45,115,111,99,107,101,116,63,32,102,110,97,109,101,49,56,49,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,49,56,53,32,112,111,115,49,56,54,32,46,32,119,104,101,110,99,101,49,56,55,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,26),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,57,53,41,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,57,57,41,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,50,48,56,32,115,112,101,99,50,49,52,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,50,49,53,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,50,49,49,32,37,115,112,101,99,50,48,54,50,51,52,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,50,49,48,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,32,46,32,103,50,48,52,50,48,53,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,50,52,48,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,103,50,52,52,50,52,53,41,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,17),40,105,115,112,101,114,115,101,32,103,50,54,53,50,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,50,55,53,32,114,50,55,54,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,50,55,48,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,50,56,51,41,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,50,56,52,32,99,109,100,50,56,53,32,105,110,112,50,56,54,32,114,50,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,50,57,48,32,46,32,109,50,57,49,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,50,57,54,32,46,32,109,50,57,55,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,51,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,7),40,97,51,49,52,56,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,20),40,97,51,49,53,52,32,46,32,114,101,115,117,108,116,115,51,50,48,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,51,49,54,32,112,114,111,99,51,49,55,32,46,32,109,111,100,101,51,49,56,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,7),40,97,51,49,55,50,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,20),40,97,51,49,55,56,32,46,32,114,101,115,117,108,116,115,51,50,54,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,51,50,50,32,112,114,111,99,51,50,51,32,46,32,109,111,100,101,51,50,52,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,20),40,97,51,49,57,55,32,46,32,114,101,115,117,108,116,115,51,51,51,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,51,50,56,32,116,104,117,110,107,51,50,57,32,46,32,109,111,100,101,51,51,48,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,20),40,97,51,50,49,55,32,46,32,114,101,115,117,108,116,115,51,52,50,41,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,51,51,55,32,116,104,117,110,107,51,51,56,32,46,32,109,111,100,101,51,51,57,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,51,53,50,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,51,53,52,32,112,114,111,99,51,53,53,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,51,53,56,32,115,116,97,116,101,51,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,12),40,97,51,51,51,50,32,115,51,54,53,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,26),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,51,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,105,103,115,51,55,49,32,109,97,115,107,51,55,50,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,51,55,53,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,21),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,51,55,55,41,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,51,56,48,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,20),40,115,101,116,45,117,115,101,114,45,105,100,33,32,105,100,51,56,54,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,103,114,111,117,112,45,105,100,33,32,105,100,51,57,52,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,36),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,52,48,51,32,46,32,103,52,48,50,52,48,52,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,52,50,52,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,38),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,52,49,54,32,46,32,103,52,49,53,52,49,55,41,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,16),40,95,101,110,115,117,114,101,45,103,114,111,117,112,115,41};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,52,52,48,41,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,19),40,100,111,52,52,54,32,108,115,116,52,52,56,32,105,52,52,57,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,52,52,53,41,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,33),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,52,54,53,32,105,100,52,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,52,55,48,32,109,52,55,49,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,39),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,52,55,52,32,117,105,100,52,55,53,32,103,105,100,52,55,54,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,52,56,49,32,97,99,99,52,56,50,32,108,111,99,52,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,56,55,41,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,56,56,41};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,38),40,115,101,116,45,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,33,32,112,105,100,52,57,54,32,112,103,105,100,52,57,55,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,36),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,53,48,54,32,110,101,119,53,48,55,41,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,29),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,53,49,50,41,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,108,105,110,107,32,111,108,100,53,50,55,32,110,101,119,53,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,53,51,51,32,109,53,51,52,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,32),40,99,104,101,99,107,32,108,111,99,53,51,56,32,102,100,53,51,57,32,105,110,112,53,52,48,32,114,53,52,49,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,53,52,52,32,46,32,109,53,52,53,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,53,52,55,32,46,32,109,53,52,56,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,53,53,51,41,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,34),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,53,53,55,32,46,32,110,101,119,53,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,8),40,114,101,97,100,121,63,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,7),40,102,101,116,99,104,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,7),40,97,52,52,50,48,41,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,7),40,97,52,52,51,51,41,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,7),40,97,52,52,52,53,41,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,7),40,97,52,52,54,54,41,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,110,54,49,55,32,109,54,49,56,32,115,116,97,114,116,54,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,37),40,97,52,52,55,53,32,112,111,114,116,54,49,50,32,110,54,49,51,32,100,101,115,116,54,49,52,32,115,116,97,114,116,54,49,53,41,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,22),40,98,117,109,112,101,114,32,99,117,114,54,51,51,32,112,116,114,54,51,52,41,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,7),40,97,52,54,51,55,41,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,30),40,97,52,54,52,51,32,100,101,115,116,54,52,54,54,52,56,32,99,111,110,116,63,54,52,55,54,52,57,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,116,114,54,51,49,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,24),40,97,52,53,53,49,32,112,111,114,116,54,50,56,32,108,105,109,105,116,54,50,57,41};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,54),40,98,111,100,121,53,55,53,32,110,111,110,98,108,111,99,107,105,110,103,63,53,56,51,32,98,117,102,105,53,56,52,32,111,110,45,99,108,111,115,101,53,56,53,32,109,111,114,101,63,53,56,54,41,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,62),40,100,101,102,45,109,111,114,101,63,53,56,48,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,55,49,54,53,56,32,37,98,117,102,105,53,55,50,54,53,57,32,37,111,110,45,99,108,111,115,101,53,55,51,54,54,48,41,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,49),40,100,101,102,45,111,110,45,99,108,111,115,101,53,55,57,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,55,49,54,54,50,32,37,98,117,102,105,53,55,50,54,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,117,102,105,53,55,56,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,55,49,54,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,21),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,53,55,55,41,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,55),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,53,54,55,32,110,97,109,53,54,56,32,102,100,53,54,57,32,46,32,103,53,54,54,53,55,48,41,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,20),40,112,111,107,101,32,115,116,114,54,57,55,32,108,101,110,54,57,56,41,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,14),40,97,52,56,51,52,32,115,116,114,55,49,54,41,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,7),40,97,52,56,52,48,41,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,7),40,97,52,56,54,49,41,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,15),40,102,95,52,56,55,48,32,115,116,114,55,48,50,41,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,29),40,108,111,111,112,32,114,101,109,55,48,55,32,115,116,97,114,116,55,48,56,32,108,101,110,55,48,57,41,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,15),40,102,95,52,56,56,53,32,115,116,114,55,48,53,41,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,45),40,98,111,100,121,54,56,53,32,110,111,110,98,108,111,99,107,105,110,103,63,54,57,50,32,98,117,102,105,54,57,51,32,111,110,45,99,108,111,115,101,54,57,52,41,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,49),40,100,101,102,45,111,110,45,99,108,111,115,101,54,56,57,32,37,110,111,110,98,108,111,99,107,105,110,103,63,54,56,50,55,50,52,32,37,98,117,102,105,54,56,51,55,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,117,102,105,54,56,56,32,37,110,111,110,98,108,111,99,107,105,110,103,63,54,56,50,55,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,21),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,54,56,55,41,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,56),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,54,55,56,32,110,97,109,54,55,57,32,102,100,54,56,48,32,46,32,103,54,55,55,54,56,49,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,55,51,53,32,111,102,102,55,51,54,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,32,112,111,114,116,55,52,48,32,97,114,103,115,55,52,49,32,108,111,99,55,52,50,41,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,27),40,101,114,114,32,109,115,103,55,53,53,32,108,111,99,107,55,53,54,32,108,111,99,55,53,55,41,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,55,53,56,32,46,32,97,114,103,115,55,53,57,41,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,55,54,49,32,46,32,97,114,103,115,55,54,50,41,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,55,54,52,32,46,32,97,114,103,115,55,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,21),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,55,55,52,41,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,32),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,55,55,55,32,46,32,109,111,100,101,55,55,56,41};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,19),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,55,56,50,41,0,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,22),40,115,101,116,101,110,118,32,118,97,114,55,56,53,32,118,97,108,55,56,54,41,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,17),40,117,110,115,101,116,101,110,118,32,118,97,114,55,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,56,48,51,41,0,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,48,48,41,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,21),40,99,117,114,114,101,110,116,45,101,110,118,105,114,111,110,109,101,110,116,41,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,66),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,56,50,52,32,108,101,110,56,50,53,32,112,114,111,116,56,50,54,32,102,108,97,103,56,50,55,32,102,100,56,50,56,32,46,32,111,102,102,56,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,41),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,56,52,52,32,46,32,108,101,110,56,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,36),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,56,52,56,41,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,26),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,56,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,29),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,56,53,49,41,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,27),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,56,53,51,41,0,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,25),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,56,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,30),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,56,55,56,32,46,32,103,56,55,55,56,55,57,41,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,31),40,115,116,114,105,110,103,45,62,116,105,109,101,32,116,105,109,56,57,57,32,46,32,103,56,57,56,57,48,48,41,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,27),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,57,48,54,41,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,25),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,57,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,17),40,95,101,120,105,116,32,46,32,99,111,100,101,57,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,20),40,115,101,116,45,97,108,97,114,109,33,32,97,57,50,49,57,50,52,41,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,57,50,53,32,109,111,100,101,57,50,54,32,46,32,115,105,122,101,57,50,55,41,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,57,51,52,41};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,57,51,55,32,112,111,114,116,57,51,56,41};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,23),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,57,52,54,41,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,23),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,57,53,55,41,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,7),40,97,54,48,52,51,41,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,110,115,57,57,55,41,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,37),40,97,54,48,52,57,32,100,105,114,57,56,50,57,56,53,32,102,105,108,57,56,51,57,56,54,32,101,120,116,57,56,52,57,56,55,41,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,20),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,57,56,48,41,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,17),40,103,108,111,98,32,46,32,112,97,116,104,115,57,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,18),40,102,95,54,49,54,49,32,97,49,48,49,48,49,48,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,49,48,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,28),40,115,101,116,97,114,103,32,97,49,48,50,49,49,48,50,55,32,97,49,48,50,48,49,48,50,56,41,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,28),40,115,101,116,101,110,118,32,97,49,48,51,51,49,48,51,57,32,97,49,48,51,50,49,48,52,48,41,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,14),40,100,111,49,48,54,50,32,105,49,48,54,53,41,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,21),40,100,111,49,48,53,56,32,97,108,49,48,54,48,32,105,49,48,54,49,41,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,49,48,52,57,32,97,114,103,108,105,115,116,49,48,53,53,32,101,110,118,108,105,115,116,49,48,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,34),40,100,101,102,45,101,110,118,108,105,115,116,49,48,53,50,32,37,97,114,103,108,105,115,116,49,48,52,55,49,48,56,53,41,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,97,114,103,108,105,115,116,49,48,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,42),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,49,48,52,53,32,46,32,103,49,48,52,52,49,48,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,48,57,49,32,110,111,104,97,110,103,49,48,57,50,41,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,7),40,97,54,52,52,51,41,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,36),40,97,54,52,52,57,32,101,112,105,100,49,49,48,55,32,101,110,111,114,109,49,49,48,56,32,101,99,111,100,101,49,49,48,57,41,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,49,48,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,49,49,49,53,49,49,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,49,49,49,57,32,46,32,115,105,103,49,49,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,49,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,49,51,49,32,46,32,97,114,103,115,49,49,51,50,41,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,7),40,97,54,54,49,57,41,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,29),40,97,54,54,50,53,32,95,49,49,53,54,32,102,108,103,49,49,53,55,32,99,111,100,49,49,53,56,41,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,8),40,102,95,54,54,48,53,41};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,111,110,45,99,108,111,115,101,32,108,111,99,49,49,53,48,32,112,105,100,49,49,53,49,32,99,108,115,118,101,99,49,49,53,50,32,105,100,120,49,49,53,51,32,105,100,120,97,49,49,53,52,32,105,100,120,98,49,49,53,53,41,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,7),40,97,54,54,52,56,41,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,19),40,97,54,54,53,52,32,105,49,49,54,50,32,111,49,49,54,51,41,0,0,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,101,100,45,112,105,112,101,32,112,111,114,116,49,49,54,49,41,0,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,34),40,99,111,110,110,101,99,116,45,112,97,114,101,110,116,32,112,105,112,101,49,49,54,53,32,112,111,114,116,49,49,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,43),40,99,111,110,110,101,99,116,45,99,104,105,108,100,32,112,105,112,101,49,49,55,50,32,112,111,114,116,49,49,55,51,32,115,116,100,102,100,49,49,55,52,41,0,0,0,0,0};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,14),40,115,119,97,112,112,101,100,45,101,110,100,115,41,0,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,7),40,97,54,55,50,57,41,0};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,67),40,115,112,97,119,110,32,99,109,100,49,49,56,52,32,97,114,103,115,49,49,56,53,32,101,110,118,49,49,56,54,32,115,116,100,111,117,116,102,49,49,56,55,32,115,116,100,105,110,102,49,49,56,56,32,115,116,100,101,114,114,102,49,49,56,57,41,0,0,0,0,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,59),40,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,49,57,54,32,99,109,100,49,49,57,56,32,112,105,112,101,49,49,57,57,32,115,116,100,102,49,50,48,48,32,111,110,45,99,108,111,115,101,49,50,48,50,41,0,0,0,0,0};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,60),40,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,50,48,52,32,99,109,100,49,50,48,54,32,112,105,112,101,49,50,48,55,32,115,116,100,102,49,50,48,56,32,111,110,45,99,108,111,115,101,49,50,49,48,41,0,0,0,0};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,7),40,97,54,55,55,57,41,0};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,50),40,97,54,55,56,53,32,105,110,112,105,112,101,49,50,49,57,32,111,117,116,112,105,112,101,49,50,50,48,32,101,114,114,112,105,112,101,49,50,50,49,32,112,105,100,49,50,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,49,50,49,50,32,99,109,100,49,50,49,51,32,97,114,103,115,49,50,49,52,32,101,110,118,49,50,49,53,32,115,116,100,111,117,116,102,49,50,49,54,32,115,116,100,105,110,102,49,50,49,55,32,115,116,100,101,114,114,102,49,50,49,56,41,0,0,0,0,0};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,17),40,97,54,56,52,56,32,103,49,50,51,50,49,50,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,49,50,51,49,41,0,0,0,0,0};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,7),40,97,54,56,54,54,41,0};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,38),40,97,54,56,55,50,32,105,110,49,50,51,54,32,111,117,116,49,50,51,55,32,112,105,100,49,50,51,56,32,101,114,114,49,50,51,57,41,0,0};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,52),40,37,112,114,111,99,101,115,115,32,108,111,99,49,50,50,53,32,101,114,114,63,49,50,50,54,32,99,109,100,49,50,50,55,32,97,114,103,115,49,50,50,56,32,101,110,118,49,50,50,57,41,0,0,0,0};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,49,50,52,56,32,97,114,103,115,49,50,53,52,32,101,110,118,49,50,53,53,41,0,0,0,0,0};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,50,53,49,32,37,97,114,103,115,49,50,52,54,49,50,53,55,41,0,0,0,0,0};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,50,53,48,41,0,0};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,29),40,112,114,111,99,101,115,115,32,99,109,100,49,50,52,52,32,46,32,103,49,50,52,51,49,50,52,53,41,0,0,0};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,49,50,54,56,32,97,114,103,115,49,50,55,52,32,101,110,118,49,50,55,53,41,0,0,0,0,0};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,50,55,49,32,37,97,114,103,115,49,50,54,54,49,50,55,55,41,0,0,0,0,0};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,50,55,48,41,0,0};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,42,32,99,109,100,49,50,54,52,32,46,32,103,49,50,54,51,49,50,54,53,41,0,0};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,14),40,102,95,55,49,54,56,32,120,49,51,49,49,41,0,0};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,7),40,97,55,48,56,53,41,0};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,7),40,97,55,48,57,51,41,0};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,7),40,97,55,49,49,55,41,0};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,49,51,49,51,32,114,49,51,49,52,41,0,0,0,0,0};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,16),40,102,95,55,49,56,55,32,46,32,95,49,51,48,55,41};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,16),40,102,95,55,49,55,57,32,46,32,95,49,51,48,54,41};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,50,57,52,32,97,99,116,105,111,110,49,51,48,49,32,105,100,49,51,48,50,32,108,105,109,105,116,49,51,48,51,41,0,0};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,49,50,57,56,32,37,97,99,116,105,111,110,49,50,57,49,49,51,50,56,32,37,105,100,49,50,57,50,49,51,50,57,41,0,0,0,0,0};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,49,50,57,55,32,37,97,99,116,105,111,110,49,50,57,49,49,51,51,49,41,0,0,0,0};
static C_char C_TLS li239[] C_aligned={C_lihdr(0,0,19),40,97,55,50,48,55,32,120,49,51,51,51,32,121,49,51,51,52,41,0,0,0,0,0};
static C_char C_TLS li240[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,49,50,57,54,41};
static C_char C_TLS li241[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,49,50,56,56,32,112,114,101,100,49,50,56,57,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,49,50,57,48,41,0,0,0,0,0};
static C_char C_TLS li242[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,49,51,52,56,41,0,0,0};
static C_char C_TLS li243[] C_aligned={C_lihdr(0,0,14),40,97,55,51,48,54,32,112,105,100,53,48,49,41,0,0};
static C_char C_TLS li244[] C_aligned={C_lihdr(0,0,7),40,97,55,51,50,52,41,0};
static C_char C_TLS li245[] C_aligned={C_lihdr(0,0,13),40,97,55,51,50,55,32,105,100,52,48,48,41,0,0,0};
static C_char C_TLS li246[] C_aligned={C_lihdr(0,0,7),40,97,55,51,52,50,41,0};
static C_char C_TLS li247[] C_aligned={C_lihdr(0,0,7),40,97,55,51,52,53,41,0};
static C_char C_TLS li248[] C_aligned={C_lihdr(0,0,13),40,97,55,51,52,56,32,105,100,51,57,50,41,0,0,0};
static C_char C_TLS li249[] C_aligned={C_lihdr(0,0,7),40,97,55,51,54,51,41,0};
static C_char C_TLS li250[] C_aligned={C_lihdr(0,0,12),40,97,55,51,54,54,32,110,51,56,51,41,0,0,0,0};
static C_char C_TLS li251[] C_aligned={C_lihdr(0,0,15),40,97,55,51,55,50,32,112,111,114,116,49,57,50,41,0};
static C_char C_TLS li252[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k7274 in set-root-directory! in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall stub1343(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1343(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k6501 */
static C_word C_fcall stub1116(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1116(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall stub1113(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1113(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall stub1111(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1111(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub1042(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1042(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k6207 */
static C_word C_fcall stub1035(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1035(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub1030(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1030(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k6188 */
static C_word C_fcall stub1023(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1023(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k6164 */
static C_word C_fcall stub1011(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1011(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub1006(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1006(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub966(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub966(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k5973 */
static C_word C_fcall stub952(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub952(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k5950 */
static C_word C_fcall stub942(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub942(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k5839 */
static C_word C_fcall stub922(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub922(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k5817 */
static C_word C_fcall stub917(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub917(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub912(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub912(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub893(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub893(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub872(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub872(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub866(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub866(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k5588 */
static C_word C_fcall stub857(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub857(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k5507 */
static C_word C_fcall stub838(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub838(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k5445 */
static C_word C_fcall stub813(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub813(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k5345 */
static C_word C_fcall stub795(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub795(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k4104 in k4100 in file-link in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall stub519(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub519(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k3820 */
static C_word C_fcall stub459(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub459(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k3689 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub432(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub432(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from k3682 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub428(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub428(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from k3596 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub411(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub411(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a7324 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall stub398(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub398(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a7342 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall stub396(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub396(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a7345 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall stub390(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub390(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a7363 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall stub388(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub388(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k1943 */
static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k1933 */
static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k1923 */
static C_word C_fcall stub81(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub81(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k1705 */
static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from k1654 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub17(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub17(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from k1647 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub13(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub13(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k1623 */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7380)
static void C_ccall f_7380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7367)
static void C_ccall f_7367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7346)
static void C_ccall f_7346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7343)
static void C_ccall f_7343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7328)
static void C_ccall f_7328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7338)
static void C_ccall f_7338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7325)
static void C_ccall f_7325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7314)
static void C_ccall f_7314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7276)
static void C_ccall f_7276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7202)
static void C_fcall f_7202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7197)
static void C_fcall f_7197(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7192)
static void C_fcall f_7192(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7021)
static void C_fcall f_7021(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7179)
static void C_ccall f_7179(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7187)
static void C_ccall f_7187(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7028)
static void C_fcall f_7028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7167)
static void C_ccall f_7167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7161)
static void C_ccall f_7161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7040)
static void C_fcall f_7040(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7154)
static void C_ccall f_7154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7141)
static void C_ccall f_7141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7134)
static void C_ccall f_7134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7131)
static void C_ccall f_7131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7102)
static void C_ccall f_7102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7086)
static void C_ccall f_7086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7168)
static void C_ccall f_7168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6971)
static void C_fcall f_6971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6966)
static void C_fcall f_6966(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6961)
static void C_fcall f_6961(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6911)
static void C_fcall f_6911(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_fcall f_6906(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6901)
static void C_fcall f_6901(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6838)
static void C_fcall f_6838(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6893)
static void C_ccall f_6893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6862)
static void C_ccall f_6862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6873)
static void C_ccall f_6873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6840)
static void C_fcall f_6840(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6774)
static void C_ccall f_6774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6813)
static void C_ccall f_6813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_ccall f_6801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6763)
static void C_fcall f_6763(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6752)
static void C_fcall f_6752(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6707)
static void C_fcall f_6707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6734)
static void C_ccall f_6734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6728)
static void C_ccall f_6728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static C_word C_fcall f_6691(C_word *a,C_word t0);
C_noret_decl(f_6674)
static void C_fcall f_6674(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6599)
static void C_ccall f_6599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_fcall f_6660(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6673)
static void C_ccall f_6673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6640)
static void C_fcall f_6640(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6603)
static void C_fcall f_6603(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_6605)
static void C_ccall f_6605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6620)
static void C_ccall f_6620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6532)
static void C_ccall f_6532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6536)
static void C_ccall f_6536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6492)
static void C_ccall f_6492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6397)
static void C_ccall f_6397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6349)
static void C_fcall f_6349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6344)
static void C_fcall f_6344(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6217)
static void C_fcall f_6217(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6235)
static void C_fcall f_6235(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6281)
static C_word C_fcall f_6281(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6248)
static void C_fcall f_6248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6273)
static void C_ccall f_6273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6251)
static void C_ccall f_6251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6196)
static C_word C_fcall f_6196(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6177)
static C_word C_fcall f_6177(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6161)
static void C_ccall f_6161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6029)
static void C_fcall f_6029(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6127)
static void C_ccall f_6127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6054)
static void C_ccall f_6054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6057)
static void C_ccall f_6057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6067)
static void C_ccall f_6067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6069)
static void C_fcall f_6069(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6004)
static void C_ccall f_6004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5953)
static void C_ccall f_5953(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5921)
static void C_fcall f_5921(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5906)
static void C_ccall f_5906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5909)
static void C_ccall f_5909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5847)
static void C_ccall f_5847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5820)
static void C_ccall f_5820(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5820)
static void C_ccall f_5820r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5706)
static void C_ccall f_5706(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5706)
static void C_ccall f_5706r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5723)
static void C_ccall f_5723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5727)
static void C_ccall f_5727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5591)
static void C_ccall f_5591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5451)
static void C_ccall f_5451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_5451)
static void C_ccall f_5451r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5348)
static void C_ccall f_5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_fcall f_5354(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_fcall f_5366(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5396)
static void C_ccall f_5396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5249)
static void C_fcall f_5249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_fcall f_5144(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5070)
static void C_fcall f_5070(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5098)
static void C_fcall f_5098(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4968)
static void C_fcall f_4968(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_fcall f_4963(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4958)
static void C_fcall f_4958(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4774)
static void C_fcall f_4774(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4902)
static void C_fcall f_4902(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4826)
static void C_fcall f_4826(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4780)
static void C_fcall f_4780(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4694)
static void C_fcall f_4694(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_fcall f_4689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4684)
static void C_fcall f_4684(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4679)
static void C_fcall f_4679(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4300)
static void C_fcall f_4300(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4558)
static void C_fcall f_4558(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4484)
static void C_fcall f_4484(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_fcall f_4486(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_fcall f_4334(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_fcall f_4346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4362)
static void C_ccall f_4362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static C_word C_fcall f_4326(C_word t0);
C_noret_decl(f_4311)
static void C_fcall f_4311(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4278)
static void C_fcall f_4278(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4265)
static void C_ccall f_4265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4210)
static void C_ccall f_4210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_fcall f_4183(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_fcall f_4146(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3951)
static void C_fcall f_3951(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_fcall f_3765(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3708)
static void C_fcall f_3708(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static C_word C_fcall f_3686(C_word t0);
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_fcall f_3607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_fcall f_3630(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_fcall f_3501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_ccall f_3511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3519)
static void C_ccall f_3519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_fcall f_3345(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3208)
static void C_ccall f_3208r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3088)
static void C_ccall f_3088r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_fcall f_3037(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_fcall f_3031(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static C_word C_fcall f_3019(C_word t0);
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_fcall f_2829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_fcall f_2848(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_fcall f_2892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_fcall f_2718(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_fcall f_2786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static C_word C_fcall f_2691(C_word t0);
C_noret_decl(f_2686)
static void C_fcall f_2686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2563)
static void C_fcall f_2563(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_fcall f_2558(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2460)
static void C_fcall f_2460(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_fcall f_2491(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_fcall f_2513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_fcall f_2138(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_fcall f_1971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_fcall f_2010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_fcall f_2014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static C_word C_fcall f_1936(C_word t0,C_word t1);
C_noret_decl(f_1926)
static C_word C_fcall f_1926(C_word t0,C_word t1);
C_noret_decl(f_1920)
static C_word C_fcall f_1920(C_word t0);
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_7202)
static void C_fcall trf_7202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7202(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7202(t0,t1);}

C_noret_decl(trf_7197)
static void C_fcall trf_7197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7197(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7197(t0,t1,t2);}

C_noret_decl(trf_7192)
static void C_fcall trf_7192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7192(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7192(t0,t1,t2,t3);}

C_noret_decl(trf_7021)
static void C_fcall trf_7021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7021(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7021(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7028)
static void C_fcall trf_7028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7028(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7028(t0,t1);}

C_noret_decl(trf_7040)
static void C_fcall trf_7040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7040(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7040(t0,t1,t2,t3);}

C_noret_decl(trf_6971)
static void C_fcall trf_6971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6971(t0,t1);}

C_noret_decl(trf_6966)
static void C_fcall trf_6966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6966(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6966(t0,t1,t2);}

C_noret_decl(trf_6961)
static void C_fcall trf_6961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6961(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6961(t0,t1,t2,t3);}

C_noret_decl(trf_6911)
static void C_fcall trf_6911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6911(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6911(t0,t1);}

C_noret_decl(trf_6906)
static void C_fcall trf_6906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6906(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6906(t0,t1,t2);}

C_noret_decl(trf_6901)
static void C_fcall trf_6901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6901(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6901(t0,t1,t2,t3);}

C_noret_decl(trf_6838)
static void C_fcall trf_6838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6838(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6838(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6840)
static void C_fcall trf_6840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6840(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6840(t0,t1,t2);}

C_noret_decl(trf_6763)
static void C_fcall trf_6763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6763(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6763(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6752)
static void C_fcall trf_6752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6752(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6752(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6707)
static void C_fcall trf_6707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6707(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6707(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6674)
static void C_fcall trf_6674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6674(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6674(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6660)
static void C_fcall trf_6660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6660(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6660(t0,t1,t2,t3);}

C_noret_decl(trf_6640)
static void C_fcall trf_6640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6640(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6640(t0,t1,t2);}

C_noret_decl(trf_6603)
static void C_fcall trf_6603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6603(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6603(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6349)
static void C_fcall trf_6349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6349(t0,t1);}

C_noret_decl(trf_6344)
static void C_fcall trf_6344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6344(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6344(t0,t1,t2);}

C_noret_decl(trf_6217)
static void C_fcall trf_6217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6217(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6217(t0,t1,t2,t3);}

C_noret_decl(trf_6235)
static void C_fcall trf_6235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6235(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6235(t0,t1,t2,t3);}

C_noret_decl(trf_6248)
static void C_fcall trf_6248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6248(t0,t1);}

C_noret_decl(trf_6029)
static void C_fcall trf_6029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6029(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6029(t0,t1,t2);}

C_noret_decl(trf_6069)
static void C_fcall trf_6069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6069(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6069(t0,t1,t2);}

C_noret_decl(trf_5921)
static void C_fcall trf_5921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5921(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5921(t0,t1,t2);}

C_noret_decl(trf_5354)
static void C_fcall trf_5354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5354(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5354(t0,t1,t2);}

C_noret_decl(trf_5366)
static void C_fcall trf_5366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5366(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5366(t0,t1,t2);}

C_noret_decl(trf_5249)
static void C_fcall trf_5249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5249(t0,t1);}

C_noret_decl(trf_5144)
static void C_fcall trf_5144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5144(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5144(t0,t1,t2,t3);}

C_noret_decl(trf_5070)
static void C_fcall trf_5070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5070(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5070(t0,t1,t2,t3);}

C_noret_decl(trf_5098)
static void C_fcall trf_5098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5098(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5098(t0,t1);}

C_noret_decl(trf_4968)
static void C_fcall trf_4968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4968(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4968(t0,t1);}

C_noret_decl(trf_4963)
static void C_fcall trf_4963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4963(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4963(t0,t1,t2);}

C_noret_decl(trf_4958)
static void C_fcall trf_4958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4958(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4958(t0,t1,t2,t3);}

C_noret_decl(trf_4774)
static void C_fcall trf_4774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4774(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4774(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4902)
static void C_fcall trf_4902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4902(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4902(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4826)
static void C_fcall trf_4826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4826(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4826(t0,t1);}

C_noret_decl(trf_4780)
static void C_fcall trf_4780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4780(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4780(t0,t1,t2,t3);}

C_noret_decl(trf_4694)
static void C_fcall trf_4694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4694(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4694(t0,t1);}

C_noret_decl(trf_4689)
static void C_fcall trf_4689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4689(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4689(t0,t1,t2);}

C_noret_decl(trf_4684)
static void C_fcall trf_4684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4684(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4684(t0,t1,t2,t3);}

C_noret_decl(trf_4679)
static void C_fcall trf_4679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4679(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4679(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4300)
static void C_fcall trf_4300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4300(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4300(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4558)
static void C_fcall trf_4558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4558(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4558(t0,t1,t2);}

C_noret_decl(trf_4484)
static void C_fcall trf_4484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4484(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4484(t0,t1);}

C_noret_decl(trf_4486)
static void C_fcall trf_4486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4486(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4486(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4334)
static void C_fcall trf_4334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4334(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4334(t0,t1);}

C_noret_decl(trf_4346)
static void C_fcall trf_4346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4346(t0,t1);}

C_noret_decl(trf_4311)
static void C_fcall trf_4311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4311(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4311(t0,t1);}

C_noret_decl(trf_4278)
static void C_fcall trf_4278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4278(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4278(t0,t1);}

C_noret_decl(trf_4183)
static void C_fcall trf_4183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4183(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4183(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4146)
static void C_fcall trf_4146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4146(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4146(t0,t1,t2);}

C_noret_decl(trf_3951)
static void C_fcall trf_3951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3951(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3951(t0,t1,t2,t3);}

C_noret_decl(trf_3765)
static void C_fcall trf_3765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3765(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3765(t0,t1,t2,t3);}

C_noret_decl(trf_3708)
static void C_fcall trf_3708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3708(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3708(t0,t1,t2);}

C_noret_decl(trf_3607)
static void C_fcall trf_3607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3607(t0,t1);}

C_noret_decl(trf_3630)
static void C_fcall trf_3630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3630(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3630(t0,t1,t2);}

C_noret_decl(trf_3501)
static void C_fcall trf_3501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3501(t0,t1);}

C_noret_decl(trf_3345)
static void C_fcall trf_3345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3345(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3345(t0,t1,t2,t3);}

C_noret_decl(trf_3037)
static void C_fcall trf_3037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3037(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3037(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3031)
static void C_fcall trf_3031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3031(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3031(t0,t1);}

C_noret_decl(trf_2829)
static void C_fcall trf_2829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2829(t0,t1);}

C_noret_decl(trf_2848)
static void C_fcall trf_2848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2848(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2848(t0,t1);}

C_noret_decl(trf_2892)
static void C_fcall trf_2892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2892(t0,t1);}

C_noret_decl(trf_2718)
static void C_fcall trf_2718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2718(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2718(t0,t1,t2,t3);}

C_noret_decl(trf_2786)
static void C_fcall trf_2786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2786(t0,t1);}

C_noret_decl(trf_2686)
static void C_fcall trf_2686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2686(t0,t1);}

C_noret_decl(trf_2563)
static void C_fcall trf_2563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2563(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2563(t0,t1);}

C_noret_decl(trf_2558)
static void C_fcall trf_2558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2558(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2558(t0,t1,t2);}

C_noret_decl(trf_2460)
static void C_fcall trf_2460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2460(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2460(t0,t1,t2,t3);}

C_noret_decl(trf_2491)
static void C_fcall trf_2491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2491(t0,t1);}

C_noret_decl(trf_2513)
static void C_fcall trf_2513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2513(t0,t1);}

C_noret_decl(trf_2138)
static void C_fcall trf_2138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2138(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2138(t0,t1,t2,t3);}

C_noret_decl(trf_1971)
static void C_fcall trf_1971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1971(t0,t1);}

C_noret_decl(trf_2010)
static void C_fcall trf_2010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2010(t0,t1);}

C_noret_decl(trf_2014)
static void C_fcall trf_2014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2014(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3310)){
C_save(t1);
C_rereclaim2(3310*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,457);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_h_intern(&lf[51],9,"file-open");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[53]=C_h_intern(&lf[53],17,"\003sysmake-c-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysexpand-home-path");
lf[55]=C_h_intern(&lf[55],10,"file-close");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],10,"file-write");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[65]=C_h_intern(&lf[65],12,"file-mkstemp");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[68]=C_h_intern(&lf[68],11,"file-select");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[70]=C_h_intern(&lf[70],12,"\003sysfor-each");
lf[71]=C_h_intern(&lf[71],8,"seek/set");
lf[72]=C_h_intern(&lf[72],8,"seek/end");
lf[73]=C_h_intern(&lf[73],8,"seek/cur");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[77]=C_h_intern(&lf[77],9,"file-stat");
lf[78]=C_h_intern(&lf[78],9,"file-size");
lf[79]=C_h_intern(&lf[79],22,"file-modification-time");
lf[80]=C_h_intern(&lf[80],16,"file-access-time");
lf[81]=C_h_intern(&lf[81],16,"file-change-time");
lf[82]=C_h_intern(&lf[82],10,"file-owner");
lf[83]=C_h_intern(&lf[83],16,"file-permissions");
lf[84]=C_h_intern(&lf[84],13,"regular-file\077");
lf[85]=C_h_intern(&lf[85],14,"symbolic-link\077");
lf[86]=C_h_intern(&lf[86],13,"stat-regular\077");
lf[87]=C_h_intern(&lf[87],15,"stat-directory\077");
lf[88]=C_h_intern(&lf[88],17,"stat-char-device\077");
lf[89]=C_h_intern(&lf[89],18,"stat-block-device\077");
lf[90]=C_h_intern(&lf[90],10,"stat-fifo\077");
lf[91]=C_h_intern(&lf[91],13,"stat-symlink\077");
lf[92]=C_h_intern(&lf[92],12,"stat-socket\077");
lf[93]=C_h_intern(&lf[93],18,"set-file-position!");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[95]=C_h_intern(&lf[95],6,"stream");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[97]=C_h_intern(&lf[97],5,"port\077");
lf[98]=C_h_intern(&lf[98],13,"\000bounds-error");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[100]=C_h_intern(&lf[100],13,"file-position");
lf[101]=C_h_intern(&lf[101],16,"create-directory");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[103]=C_h_intern(&lf[103],16,"change-directory");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[105]=C_h_intern(&lf[105],16,"delete-directory");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[107]=C_h_intern(&lf[107],10,"string-ref");
lf[108]=C_h_intern(&lf[108],6,"string");
lf[109]=C_h_intern(&lf[109],9,"directory");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[111]=C_h_intern(&lf[111],16,"\003sysmake-pointer");
lf[112]=C_h_intern(&lf[112],17,"current-directory");
lf[113]=C_h_intern(&lf[113],10,"directory\077");
lf[114]=C_h_intern(&lf[114],13,"\003sysfile-info");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[116]=C_h_intern(&lf[116],5,"null\077");
lf[117]=C_h_intern(&lf[117],6,"char=\077");
lf[118]=C_h_intern(&lf[118],8,"string=\077");
lf[119]=C_h_intern(&lf[119],16,"char-alphabetic\077");
lf[120]=C_h_intern(&lf[120],18,"string-intersperse");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[122]=C_h_intern(&lf[122],6,"getenv");
lf[123]=C_h_intern(&lf[123],17,"current-user-name");
lf[124]=C_h_intern(&lf[124],14,"canonical-path");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[128]=C_h_intern(&lf[128],7,"reverse");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[132]=C_h_intern(&lf[132],12,"string-split");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[140]=C_h_intern(&lf[140],5,"\000text");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[143]=C_h_intern(&lf[143],13,"\003sysmake-port");
lf[144]=C_h_intern(&lf[144],21,"\003sysstream-port-class");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[146]=C_h_intern(&lf[146],15,"open-input-pipe");
lf[147]=C_h_intern(&lf[147],7,"\000binary");
lf[148]=C_h_intern(&lf[148],16,"open-output-pipe");
lf[149]=C_h_intern(&lf[149],16,"close-input-pipe");
lf[150]=C_h_intern(&lf[150],23,"close-input/output-pipe");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[152]=C_h_intern(&lf[152],14,"\003syscheck-port");
lf[153]=C_h_intern(&lf[153],17,"close-output-pipe");
lf[154]=C_h_intern(&lf[154],20,"call-with-input-pipe");
lf[155]=C_h_intern(&lf[155],21,"call-with-output-pipe");
lf[156]=C_h_intern(&lf[156],20,"with-input-from-pipe");
lf[157]=C_h_intern(&lf[157],18,"\003sysstandard-input");
lf[158]=C_h_intern(&lf[158],19,"with-output-to-pipe");
lf[159]=C_h_intern(&lf[159],19,"\003sysstandard-output");
lf[160]=C_h_intern(&lf[160],11,"create-pipe");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[162]=C_h_intern(&lf[162],11,"signal/term");
lf[163]=C_h_intern(&lf[163],11,"signal/kill");
lf[164]=C_h_intern(&lf[164],10,"signal/int");
lf[165]=C_h_intern(&lf[165],10,"signal/hup");
lf[166]=C_h_intern(&lf[166],10,"signal/fpe");
lf[167]=C_h_intern(&lf[167],10,"signal/ill");
lf[168]=C_h_intern(&lf[168],11,"signal/segv");
lf[169]=C_h_intern(&lf[169],11,"signal/abrt");
lf[170]=C_h_intern(&lf[170],11,"signal/trap");
lf[171]=C_h_intern(&lf[171],11,"signal/quit");
lf[172]=C_h_intern(&lf[172],11,"signal/alrm");
lf[173]=C_h_intern(&lf[173],13,"signal/vtalrm");
lf[174]=C_h_intern(&lf[174],11,"signal/prof");
lf[175]=C_h_intern(&lf[175],9,"signal/io");
lf[176]=C_h_intern(&lf[176],10,"signal/urg");
lf[177]=C_h_intern(&lf[177],11,"signal/chld");
lf[178]=C_h_intern(&lf[178],11,"signal/cont");
lf[179]=C_h_intern(&lf[179],11,"signal/stop");
lf[180]=C_h_intern(&lf[180],11,"signal/tstp");
lf[181]=C_h_intern(&lf[181],11,"signal/pipe");
lf[182]=C_h_intern(&lf[182],11,"signal/xcpu");
lf[183]=C_h_intern(&lf[183],11,"signal/xfsz");
lf[184]=C_h_intern(&lf[184],11,"signal/usr1");
lf[185]=C_h_intern(&lf[185],11,"signal/usr2");
lf[186]=C_h_intern(&lf[186],12,"signal/winch");
lf[187]=C_h_intern(&lf[187],12,"signals-list");
lf[188]=C_h_intern(&lf[188],18,"\003sysinterrupt-hook");
lf[189]=C_h_intern(&lf[189],14,"signal-handler");
lf[190]=C_h_intern(&lf[190],19,"set-signal-handler!");
lf[191]=C_h_intern(&lf[191],16,"set-signal-mask!");
lf[192]=C_h_intern(&lf[192],14,"\000process-error");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[194]=C_h_intern(&lf[194],11,"signal-mask");
lf[195]=C_h_intern(&lf[195],14,"signal-masked\077");
lf[196]=C_h_intern(&lf[196],12,"signal-mask!");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[198]=C_h_intern(&lf[198],14,"signal-unmask!");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[200]=C_h_intern(&lf[200],18,"system-information");
lf[201]=C_h_intern(&lf[201],25,"\003syspeek-nonnull-c-string");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[203]=C_h_intern(&lf[203],12,"set-user-id!");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[205]=C_h_intern(&lf[205],15,"current-user-id");
lf[206]=C_h_intern(&lf[206],25,"current-effective-user-id");
lf[207]=C_h_intern(&lf[207],13,"set-group-id!");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[209]=C_h_intern(&lf[209],16,"current-group-id");
lf[210]=C_h_intern(&lf[210],26,"current-effective-group-id");
lf[211]=C_h_intern(&lf[211],16,"user-information");
lf[212]=C_h_intern(&lf[212],6,"vector");
lf[213]=C_h_intern(&lf[213],4,"list");
lf[214]=C_h_intern(&lf[214],27,"current-effective-user-name");
lf[215]=C_h_intern(&lf[215],17,"group-information");
lf[217]=C_h_intern(&lf[217],10,"get-groups");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[221]=C_h_intern(&lf[221],11,"set-groups!");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[224]=C_h_intern(&lf[224],17,"initialize-groups");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[226]=C_h_intern(&lf[226],10,"errno/perm");
lf[227]=C_h_intern(&lf[227],11,"errno/noent");
lf[228]=C_h_intern(&lf[228],10,"errno/srch");
lf[229]=C_h_intern(&lf[229],10,"errno/intr");
lf[230]=C_h_intern(&lf[230],8,"errno/io");
lf[231]=C_h_intern(&lf[231],12,"errno/noexec");
lf[232]=C_h_intern(&lf[232],10,"errno/badf");
lf[233]=C_h_intern(&lf[233],11,"errno/child");
lf[234]=C_h_intern(&lf[234],11,"errno/nomem");
lf[235]=C_h_intern(&lf[235],11,"errno/acces");
lf[236]=C_h_intern(&lf[236],11,"errno/fault");
lf[237]=C_h_intern(&lf[237],10,"errno/busy");
lf[238]=C_h_intern(&lf[238],12,"errno/notdir");
lf[239]=C_h_intern(&lf[239],11,"errno/isdir");
lf[240]=C_h_intern(&lf[240],11,"errno/inval");
lf[241]=C_h_intern(&lf[241],11,"errno/mfile");
lf[242]=C_h_intern(&lf[242],11,"errno/nospc");
lf[243]=C_h_intern(&lf[243],11,"errno/spipe");
lf[244]=C_h_intern(&lf[244],10,"errno/pipe");
lf[245]=C_h_intern(&lf[245],11,"errno/again");
lf[246]=C_h_intern(&lf[246],10,"errno/rofs");
lf[247]=C_h_intern(&lf[247],11,"errno/exist");
lf[248]=C_h_intern(&lf[248],16,"errno/wouldblock");
lf[249]=C_h_intern(&lf[249],10,"errno/2big");
lf[250]=C_h_intern(&lf[250],12,"errno/deadlk");
lf[251]=C_h_intern(&lf[251],9,"errno/dom");
lf[252]=C_h_intern(&lf[252],10,"errno/fbig");
lf[253]=C_h_intern(&lf[253],11,"errno/ilseq");
lf[254]=C_h_intern(&lf[254],11,"errno/mlink");
lf[255]=C_h_intern(&lf[255],17,"errno/nametoolong");
lf[256]=C_h_intern(&lf[256],11,"errno/nfile");
lf[257]=C_h_intern(&lf[257],11,"errno/nodev");
lf[258]=C_h_intern(&lf[258],11,"errno/nolck");
lf[259]=C_h_intern(&lf[259],11,"errno/nosys");
lf[260]=C_h_intern(&lf[260],14,"errno/notempty");
lf[261]=C_h_intern(&lf[261],11,"errno/notty");
lf[262]=C_h_intern(&lf[262],10,"errno/nxio");
lf[263]=C_h_intern(&lf[263],11,"errno/range");
lf[264]=C_h_intern(&lf[264],10,"errno/xdev");
lf[265]=C_h_intern(&lf[265],16,"change-file-mode");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[267]=C_h_intern(&lf[267],17,"change-file-owner");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[269]=C_h_intern(&lf[269],17,"file-read-access\077");
lf[270]=C_h_intern(&lf[270],18,"file-write-access\077");
lf[271]=C_h_intern(&lf[271],20,"file-execute-access\077");
lf[272]=C_h_intern(&lf[272],14,"create-session");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[274]=C_h_intern(&lf[274],21,"set-process-group-id!");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[276]=C_h_intern(&lf[276],16,"process-group-id");
lf[277]=C_h_intern(&lf[277],20,"create-symbolic-link");
lf[278]=C_h_intern(&lf[278],18,"create-symbol-link");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[280]=C_h_intern(&lf[280],9,"substring");
lf[281]=C_h_intern(&lf[281],18,"read-symbolic-link");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[283]=C_h_intern(&lf[283],9,"file-link");
lf[284]=C_h_intern(&lf[284],9,"hard-link");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[286]=C_h_intern(&lf[286],12,"fileno/stdin");
lf[287]=C_h_intern(&lf[287],13,"fileno/stdout");
lf[288]=C_h_intern(&lf[288],13,"fileno/stderr");
lf[289]=C_h_intern(&lf[289],7,"\000append");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[297]=C_h_intern(&lf[297],16,"open-input-file*");
lf[298]=C_h_intern(&lf[298],17,"open-output-file*");
lf[299]=C_h_intern(&lf[299],12,"port->fileno");
lf[300]=C_h_intern(&lf[300],6,"socket");
lf[301]=C_h_intern(&lf[301],20,"\003systcp-port->fileno");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[304]=C_h_intern(&lf[304],25,"\003syspeek-unsigned-integer");
lf[305]=C_h_intern(&lf[305],16,"duplicate-fileno");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[307]=C_h_intern(&lf[307],15,"make-input-port");
lf[308]=C_h_intern(&lf[308],14,"set-port-name!");
lf[309]=C_h_intern(&lf[309],21,"\003syscustom-input-port");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[311]=C_h_intern(&lf[311],17,"\003systhread-yield!");
lf[312]=C_h_intern(&lf[312],25,"\003systhread-block-for-i/o!");
lf[313]=C_h_intern(&lf[313],18,"\003syscurrent-thread");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[318]=C_h_intern(&lf[318],17,"\003sysstring-append");
lf[319]=C_h_intern(&lf[319],15,"\003sysmake-string");
lf[320]=C_h_intern(&lf[320],20,"\003sysscan-buffer-line");
lf[321]=C_h_intern(&lf[321],4,"noop");
lf[322]=C_h_intern(&lf[322],16,"make-output-port");
lf[323]=C_h_intern(&lf[323],22,"\003syscustom-output-port");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[326]=C_h_intern(&lf[326],13,"file-truncate");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[329]=C_h_intern(&lf[329],4,"lock");
lf[330]=C_h_intern(&lf[330],9,"file-lock");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[332]=C_h_intern(&lf[332],18,"file-lock/blocking");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[334]=C_h_intern(&lf[334],14,"file-test-lock");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[336]=C_h_intern(&lf[336],11,"file-unlock");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[338]=C_h_intern(&lf[338],11,"create-fifo");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[340]=C_h_intern(&lf[340],5,"fifo\077");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[342]=C_h_intern(&lf[342],6,"setenv");
lf[343]=C_h_intern(&lf[343],8,"unsetenv");
lf[344]=C_h_intern(&lf[344],19,"current-environment");
lf[345]=C_h_intern(&lf[345],9,"prot/read");
lf[346]=C_h_intern(&lf[346],10,"prot/write");
lf[347]=C_h_intern(&lf[347],9,"prot/exec");
lf[348]=C_h_intern(&lf[348],9,"prot/none");
lf[349]=C_h_intern(&lf[349],9,"map/fixed");
lf[350]=C_h_intern(&lf[350],10,"map/shared");
lf[351]=C_h_intern(&lf[351],11,"map/private");
lf[352]=C_h_intern(&lf[352],13,"map/anonymous");
lf[353]=C_h_intern(&lf[353],8,"map/file");
lf[354]=C_h_intern(&lf[354],18,"map-file-to-memory");
lf[355]=C_h_intern(&lf[355],4,"mmap");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[357]=C_h_intern(&lf[357],20,"\003syspointer->address");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[359]=C_h_intern(&lf[359],16,"\003sysnull-pointer");
lf[360]=C_h_intern(&lf[360],22,"unmap-file-from-memory");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[362]=C_h_intern(&lf[362],26,"memory-mapped-file-pointer");
lf[363]=C_h_intern(&lf[363],19,"memory-mapped-file\077");
lf[364]=C_h_intern(&lf[364],19,"seconds->local-time");
lf[365]=C_h_intern(&lf[365],18,"\003sysdecode-seconds");
lf[366]=C_h_intern(&lf[366],17,"seconds->utc-time");
lf[367]=C_h_intern(&lf[367],15,"seconds->string");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[369]=C_h_intern(&lf[369],12,"time->string");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[373]=C_h_intern(&lf[373],12,"string->time");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[375]=C_h_intern(&lf[375],19,"local-time->seconds");
lf[376]=C_h_intern(&lf[376],15,"\003syscons-flonum");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[379]=C_h_intern(&lf[379],17,"utc-time->seconds");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[382]=C_h_intern(&lf[382],27,"local-timezone-abbreviation");
lf[383]=C_h_intern(&lf[383],5,"_exit");
lf[384]=C_h_intern(&lf[384],10,"set-alarm!");
lf[385]=C_h_intern(&lf[385],19,"set-buffering-mode!");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[387]=C_h_intern(&lf[387],5,"\000full");
lf[388]=C_h_intern(&lf[388],5,"\000line");
lf[389]=C_h_intern(&lf[389],5,"\000none");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[391]=C_h_intern(&lf[391],14,"terminal-port\077");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[394]=C_h_intern(&lf[394],13,"terminal-name");
lf[395]=C_h_intern(&lf[395],13,"terminal-size");
lf[396]=C_h_intern(&lf[396],6,"\000error");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[398]=C_h_intern(&lf[398],17,"\003sysmake-locative");
lf[399]=C_h_intern(&lf[399],8,"location");
lf[400]=C_h_intern(&lf[400],13,"get-host-name");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[402]=C_h_intern(&lf[402],6,"regexp");
lf[403]=C_h_intern(&lf[403],21,"make-anchored-pattern");
lf[404]=C_h_intern(&lf[404],12,"string-match");
lf[405]=C_h_intern(&lf[405],12,"glob->regexp");
lf[406]=C_h_intern(&lf[406],13,"make-pathname");
lf[407]=C_h_intern(&lf[407],18,"decompose-pathname");
lf[408]=C_h_intern(&lf[408],4,"glob");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[411]=C_h_intern(&lf[411],12,"process-fork");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[413]=C_h_intern(&lf[413],24,"pathname-strip-directory");
lf[414]=C_h_intern(&lf[414],15,"process-execute");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[416]=C_h_intern(&lf[416],16,"\003sysprocess-wait");
lf[417]=C_h_intern(&lf[417],12,"process-wait");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[419]=C_h_intern(&lf[419],18,"current-process-id");
lf[420]=C_h_intern(&lf[420],17,"parent-process-id");
lf[421]=C_h_intern(&lf[421],5,"sleep");
lf[422]=C_h_intern(&lf[422],14,"process-signal");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[424]=C_h_intern(&lf[424],17,"\003sysshell-command");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[427]=C_h_intern(&lf[427],27,"\003sysshell-command-arguments");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[429]=C_h_intern(&lf[429],11,"process-run");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[431]=C_h_intern(&lf[431],11,"\003sysprocess");
lf[432]=C_h_intern(&lf[432],19,"\003sysundefined-value");
lf[433]=C_h_intern(&lf[433],7,"process");
lf[434]=C_h_intern(&lf[434],8,"process*");
lf[435]=C_h_intern(&lf[435],10,"find-files");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[439]=C_h_intern(&lf[439],16,"\003sysdynamic-wind");
lf[440]=C_h_intern(&lf[440],13,"pathname-file");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[442]=C_h_intern(&lf[442],7,"regexp\077");
lf[443]=C_h_intern(&lf[443],19,"set-root-directory!");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[446]=C_h_intern(&lf[446],18,"getter-with-setter");
lf[447]=C_h_intern(&lf[447],26,"effective-group-id!-setter");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[449]=C_h_intern(&lf[449],25,"effective-user-id!-setter");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[451]=C_h_intern(&lf[451],23,"\003sysuser-interrupt-hook");
lf[452]=C_h_intern(&lf[452],11,"make-vector");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[455]=C_h_intern(&lf[455],17,"register-feature!");
lf[456]=C_h_intern(&lf[456],5,"posix");
C_register_lf2(lf,457,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1602,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1600 */
static void C_ccall f_1602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1603 in k1600 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1606 in k1603 in k1600 */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 502  register-feature! */
t3=*((C_word*)lf[455]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[456]);}

/* k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word ab[113],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1614,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1626,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1,lf[3]);
t5=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1644,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1651,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1708,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1754,a[2]=t45,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1792,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[57]+1);
t49=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1807,a[2]=t48,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1849,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1888,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1920,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1926,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t55=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1946,a[2]=t53,a[3]=t54,a[4]=t52,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t56=C_mutate((C_word*)lf[71]+1,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[72]+1,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[73]+1,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[74],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2138,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2175,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2207,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2213,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2219,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2225,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2231,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2237,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2243,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2252,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2288,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2297,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2306,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2324,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t77=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2384,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7373,a[2]=((C_word)li251),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 842  getter-with-setter */
t79=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t79))(4,t79,t77,t78,*((C_word*)lf[93]+1));}

/* a7372 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7373,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7377,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7389,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 844  port? */
t5=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7387 in a7372 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[95]);
t4=((C_word*)t0)[2];
f_7377(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_7377(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 849  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[100],lf[454],((C_word*)t0)[3]);}}}

/* k7375 in a7372 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7380,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 851  posix-error */
t3=lf[3];
f_1626(6,t3,t2,lf[48],lf[100],lf[453],((C_word*)t0)[2]);}
else{
t3=t2;
f_7380(2,t3,C_SCHEME_UNDEFINED);}}

/* k7378 in k7375 in a7372 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word ab[167],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2384,2,t0,t1);}
t2=C_mutate((C_word*)lf[100]+1,t1);
t3=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2386,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2410,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2434,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[107]+1);
t7=*((C_word*)lf[57]+1);
t8=*((C_word*)lf[108]+1);
t9=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2458,a[2]=t7,a[3]=t6,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[113]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2615,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2638,a[2]=t11,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[116]+1);
t14=*((C_word*)lf[117]+1);
t15=*((C_word*)lf[118]+1);
t16=*((C_word*)lf[119]+1);
t17=*((C_word*)lf[107]+1);
t18=*((C_word*)lf[2]+1);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2686,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2691,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
t21=*((C_word*)lf[122]+1);
t22=*((C_word*)lf[123]+1);
t23=*((C_word*)lf[112]+1);
t24=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2702,a[2]=t16,a[3]=t14,a[4]=t21,a[5]=t22,a[6]=t23,a[7]=t15,a[8]=t13,a[9]=t17,a[10]=t19,a[11]=t18,a[12]=t20,a[13]=((C_word)li48),tmp=(C_word)a,a+=14,tmp));
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3019,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3031,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3037,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
t28=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3052,a[2]=t26,a[3]=t27,a[4]=t25,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t29=C_mutate((C_word*)lf[148]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3088,a[2]=t26,a[3]=t27,a[4]=t25,a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t30=C_mutate((C_word*)lf[149]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3124,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[153]+1,*((C_word*)lf[149]+1));
t32=*((C_word*)lf[146]+1);
t33=*((C_word*)lf[148]+1);
t34=*((C_word*)lf[149]+1);
t35=*((C_word*)lf[153]+1);
t36=C_mutate((C_word*)lf[154]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3140,a[2]=t32,a[3]=t34,a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp));
t37=C_mutate((C_word*)lf[155]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3164,a[2]=t33,a[3]=t35,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp));
t38=C_mutate((C_word*)lf[156]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3188,a[2]=t32,a[3]=t34,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3208,a[2]=t33,a[3]=t35,a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3228,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[162]+1,C_fix((C_word)SIGTERM));
t42=C_mutate((C_word*)lf[163]+1,C_fix((C_word)SIGKILL));
t43=C_mutate((C_word*)lf[164]+1,C_fix((C_word)SIGINT));
t44=C_mutate((C_word*)lf[165]+1,C_fix((C_word)SIGHUP));
t45=C_mutate((C_word*)lf[166]+1,C_fix((C_word)SIGFPE));
t46=C_mutate((C_word*)lf[167]+1,C_fix((C_word)SIGILL));
t47=C_mutate((C_word*)lf[168]+1,C_fix((C_word)SIGSEGV));
t48=C_mutate((C_word*)lf[169]+1,C_fix((C_word)SIGABRT));
t49=C_mutate((C_word*)lf[170]+1,C_fix((C_word)SIGTRAP));
t50=C_mutate((C_word*)lf[171]+1,C_fix((C_word)SIGQUIT));
t51=C_mutate((C_word*)lf[172]+1,C_fix((C_word)SIGALRM));
t52=C_mutate((C_word*)lf[173]+1,C_fix((C_word)SIGVTALRM));
t53=C_mutate((C_word*)lf[174]+1,C_fix((C_word)SIGPROF));
t54=C_mutate((C_word*)lf[175]+1,C_fix((C_word)SIGIO));
t55=C_mutate((C_word*)lf[176]+1,C_fix((C_word)SIGURG));
t56=C_mutate((C_word*)lf[177]+1,C_fix((C_word)SIGCHLD));
t57=C_mutate((C_word*)lf[178]+1,C_fix((C_word)SIGCONT));
t58=C_mutate((C_word*)lf[179]+1,C_fix((C_word)SIGSTOP));
t59=C_mutate((C_word*)lf[180]+1,C_fix((C_word)SIGTSTP));
t60=C_mutate((C_word*)lf[181]+1,C_fix((C_word)SIGPIPE));
t61=C_mutate((C_word*)lf[182]+1,C_fix((C_word)SIGXCPU));
t62=C_mutate((C_word*)lf[183]+1,C_fix((C_word)SIGXFSZ));
t63=C_mutate((C_word*)lf[184]+1,C_fix((C_word)SIGUSR1));
t64=C_mutate((C_word*)lf[185]+1,C_fix((C_word)SIGUSR2));
t65=C_mutate((C_word*)lf[186]+1,C_fix((C_word)SIGWINCH));
t66=(C_word)C_a_i_list(&a,25,*((C_word*)lf[162]+1),*((C_word*)lf[163]+1),*((C_word*)lf[164]+1),*((C_word*)lf[165]+1),*((C_word*)lf[166]+1),*((C_word*)lf[167]+1),*((C_word*)lf[168]+1),*((C_word*)lf[169]+1),*((C_word*)lf[170]+1),*((C_word*)lf[171]+1),*((C_word*)lf[172]+1),*((C_word*)lf[173]+1),*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1));
t67=C_mutate((C_word*)lf[187]+1,t66);
t68=*((C_word*)lf[188]+1);
t69=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3273,a[2]=((C_word*)t0)[2],a[3]=t68,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1142 make-vector */
t70=*((C_word*)lf[452]+1);
((C_proc4)(void*)(*((C_word*)t70+1)))(4,t70,t69,C_fix(256),C_SCHEME_FALSE);}

/* k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3273,2,t0,t1);}
t2=C_mutate((C_word*)lf[189]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3275,a[2]=t1,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[190]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3284,a[2]=t1,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[188]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[191]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3315,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[194]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3339,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[195]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3371,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[196]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3377,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[198]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3392,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3408,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7367,a[2]=((C_word)li250),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1198 set-signal-handler! */
t12=*((C_word*)lf[190]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,*((C_word*)lf[164]+1),t11);}

/* a7366 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7367,3,t0,t1,t2);}
/* posixunix.scm: 1200 ##sys#user-interrupt-hook */
t3=*((C_word*)lf[451]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3408,2,t0,t1);}
t2=C_mutate((C_word*)lf[200]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3410,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[203]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7364,a[2]=((C_word)li249),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1230 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,*((C_word*)lf[203]+1));}

/* a7363 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7364,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub388(C_SCHEME_UNDEFINED));}

/* k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3465,2,t0,t1);}
t2=C_mutate((C_word*)lf[205]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7346,a[2]=((C_word)li247),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7349,a[2]=((C_word)li248),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1235 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a7348 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7349,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7359,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1239 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7357 in a7348 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1240 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[449],lf[450],((C_word*)t0)[2]);}

/* a7345 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7346,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub390(C_SCHEME_UNDEFINED));}

/* k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=C_mutate((C_word*)lf[206]+1,t1);
t3=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3471,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3488,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7343,a[2]=((C_word)li246),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1250 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,*((C_word*)lf[207]+1));}

/* a7342 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7343,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub396(C_SCHEME_UNDEFINED));}

/* k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3492,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7325,a[2]=((C_word)li244),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7328,a[2]=((C_word)li245),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1255 getter-with-setter */
t6=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a7327 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7328,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7338,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1259 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7336 in a7327 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1260 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[447],lf[448],((C_word*)t0)[2]);}

/* a7324 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7325,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub398(C_SCHEME_UNDEFINED));}

/* k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3492,2,t0,t1);}
t2=C_mutate((C_word*)lf[210]+1,t1);
t3=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3494,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3561,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[214]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3600,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[216],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3686,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[217]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3693,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3756,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[224]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3830,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[226]+1,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[227]+1,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[228]+1,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[229]+1,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[230]+1,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[231]+1,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[232]+1,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[233]+1,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[234]+1,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[235]+1,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[236]+1,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[237]+1,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[238]+1,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[239]+1,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[240]+1,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[241]+1,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[242]+1,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[243]+1,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[244]+1,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[245]+1,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[246]+1,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[247]+1,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[248]+1,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[249],0,C_fix(0));
t35=C_set_block_item(lf[250],0,C_fix(0));
t36=C_set_block_item(lf[251],0,C_fix(0));
t37=C_set_block_item(lf[252],0,C_fix(0));
t38=C_set_block_item(lf[253],0,C_fix(0));
t39=C_set_block_item(lf[254],0,C_fix(0));
t40=C_set_block_item(lf[255],0,C_fix(0));
t41=C_set_block_item(lf[256],0,C_fix(0));
t42=C_set_block_item(lf[257],0,C_fix(0));
t43=C_set_block_item(lf[258],0,C_fix(0));
t44=C_set_block_item(lf[259],0,C_fix(0));
t45=C_set_block_item(lf[260],0,C_fix(0));
t46=C_set_block_item(lf[261],0,C_fix(0));
t47=C_set_block_item(lf[262],0,C_fix(0));
t48=C_set_block_item(lf[263],0,C_fix(0));
t49=C_set_block_item(lf[264],0,C_fix(0));
t50=C_mutate((C_word*)lf[265]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3894,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3921,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3951,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3975,a[2]=t52,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[270]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3981,a[2]=t52,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[271]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3987,a[2]=t52,a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp));
t56=C_mutate((C_word*)lf[272]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3993,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[274]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4008,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7307,a[2]=((C_word)li243),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1482 getter-with-setter */
t60=*((C_word*)lf[446]+1);
((C_proc4)C_retrieve_proc(t60))(4,t60,t58,t59,*((C_word*)lf[274]+1));}

/* a7306 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7307,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[276]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7314,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7320,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1487 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_7314(2,t6,C_SCHEME_UNDEFINED);}}

/* k7318 in a7306 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1488 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[276],lf[445],((C_word*)t0)[2]);}

/* k7312 in a7306 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4031,2,t0,t1);}
t2=C_mutate((C_word*)lf[276]+1,t1);
t3=C_mutate((C_word*)lf[277]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4033,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[280]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1509 make-string */
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word ab[259],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=C_mutate((C_word*)lf[281]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[283]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4121,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[286]+1,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[287]+1,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[288]+1,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4146,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4183,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
t9=C_mutate((C_word*)lf[297]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4198,a[2]=t7,a[3]=t8,a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[298]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4212,a[2]=t7,a[3]=t8,a[4]=((C_word)li104),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[299]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4226,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[305]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4271,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[307]+1);
t14=*((C_word*)lf[308]+1);
t15=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4298,a[2]=t13,a[3]=t14,a[4]=((C_word)li126),tmp=(C_word)a,a+=5,tmp));
t16=*((C_word*)lf[322]+1);
t17=*((C_word*)lf[308]+1);
t18=C_mutate((C_word*)lf[323]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4772,a[2]=t16,a[3]=t17,a[4]=((C_word)li138),tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5031,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5070,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5144,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5162,a[2]=t20,a[3]=t21,a[4]=((C_word)li142),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5177,a[2]=t20,a[3]=t21,a[4]=((C_word)li143),tmp=(C_word)a,a+=5,tmp));
t24=C_mutate((C_word*)lf[334]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5192,a[2]=t20,a[3]=t21,a[4]=((C_word)li144),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5214,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[338]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5242,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[340]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5285,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5311,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[343]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5328,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[344]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5348,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[345]+1,C_fix((C_word)PROT_READ));
t32=C_mutate((C_word*)lf[346]+1,C_fix((C_word)PROT_WRITE));
t33=C_mutate((C_word*)lf[347]+1,C_fix((C_word)PROT_EXEC));
t34=C_mutate((C_word*)lf[348]+1,C_fix((C_word)PROT_NONE));
t35=C_mutate((C_word*)lf[349]+1,C_fix((C_word)MAP_FIXED));
t36=C_mutate((C_word*)lf[350]+1,C_fix((C_word)MAP_SHARED));
t37=C_mutate((C_word*)lf[351]+1,C_fix((C_word)MAP_PRIVATE));
t38=C_mutate((C_word*)lf[352]+1,C_fix((C_word)MAP_ANON));
t39=C_mutate((C_word*)lf[353]+1,C_fix((C_word)MAP_FILE));
t40=C_mutate((C_word*)lf[354]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5451,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[360]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5513,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[362]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5548,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[363]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5557,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5563,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5572,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5591,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5624,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5706,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5752,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5780,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[382]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5808,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[383]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5820,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[384]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5836,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[385]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5843,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[391]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5902,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate(&lf[392],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5921,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[394]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5953,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[395]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5976,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[400]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6011,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t60=*((C_word*)lf[402]+1);
t61=*((C_word*)lf[403]+1);
t62=*((C_word*)lf[404]+1);
t63=*((C_word*)lf[405]+1);
t64=*((C_word*)lf[109]+1);
t65=*((C_word*)lf[406]+1);
t66=*((C_word*)lf[407]+1);
t67=C_mutate((C_word*)lf[408]+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6023,a[2]=t63,a[3]=t61,a[4]=t60,a[5]=t64,a[6]=t62,a[7]=t65,a[8]=t66,a[9]=((C_word)li177),tmp=(C_word)a,a+=10,tmp));
t68=C_mutate((C_word*)lf[411]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6135,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp));
t69=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6177,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6196,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
t71=*((C_word*)lf[413]+1);
t72=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6215,a[2]=t71,a[3]=t70,a[4]=t69,a[5]=((C_word)li187),tmp=(C_word)a,a+=6,tmp));
t73=C_mutate((C_word*)lf[416]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6397,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[417]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6414,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[419]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6492,a[2]=((C_word)li192),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6495,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6498,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[422]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6505,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[424]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6532,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[427]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6541,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp));
t81=*((C_word*)lf[411]+1);
t82=*((C_word*)lf[414]+1);
t83=*((C_word*)lf[122]+1);
t84=C_mutate((C_word*)lf[429]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6547,a[2]=t81,a[3]=t82,a[4]=((C_word)li198),tmp=(C_word)a,a+=5,tmp));
t85=*((C_word*)lf[160]+1);
t86=*((C_word*)lf[417]+1);
t87=*((C_word*)lf[411]+1);
t88=*((C_word*)lf[414]+1);
t89=*((C_word*)lf[305]+1);
t90=*((C_word*)lf[55]+1);
t91=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6603,a[2]=t86,a[3]=((C_word)li202),tmp=(C_word)a,a+=4,tmp);
t92=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6640,a[2]=t85,a[3]=((C_word)li205),tmp=(C_word)a,a+=4,tmp);
t93=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6660,a[2]=t90,a[3]=((C_word)li206),tmp=(C_word)a,a+=4,tmp);
t94=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6674,a[2]=t90,a[3]=((C_word)li207),tmp=(C_word)a,a+=4,tmp);
t95=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6691,a[2]=((C_word)li208),tmp=(C_word)a,a+=3,tmp);
t96=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6707,a[2]=t92,a[3]=t87,a[4]=t94,a[5]=t88,a[6]=t95,a[7]=((C_word)li210),tmp=(C_word)a,a+=8,tmp);
t97=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6752,a[2]=t93,a[3]=((C_word)li211),tmp=(C_word)a,a+=4,tmp);
t98=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6763,a[2]=t93,a[3]=((C_word)li212),tmp=(C_word)a,a+=4,tmp);
t99=C_mutate((C_word*)lf[431]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6774,a[2]=t98,a[3]=t91,a[4]=t97,a[5]=t96,a[6]=((C_word)li215),tmp=(C_word)a,a+=7,tmp));
t100=*((C_word*)lf[432]+1);
t101=C_mutate((C_word*)lf[433]+1,t100);
t102=*((C_word*)lf[432]+1);
t103=C_mutate((C_word*)lf[434]+1,t102);
t104=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6838,a[2]=((C_word)li220),tmp=(C_word)a,a+=3,tmp);
t105=C_mutate((C_word*)lf[433]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6899,a[2]=t104,a[3]=((C_word)li224),tmp=(C_word)a,a+=4,tmp));
t106=C_mutate((C_word*)lf[434]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6959,a[2]=t104,a[3]=((C_word)li228),tmp=(C_word)a,a+=4,tmp));
t107=*((C_word*)lf[408]+1);
t108=*((C_word*)lf[404]+1);
t109=*((C_word*)lf[406]+1);
t110=*((C_word*)lf[113]+1);
t111=C_mutate((C_word*)lf[435]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7019,a[2]=t110,a[3]=t109,a[4]=t107,a[5]=t108,a[6]=((C_word)li241),tmp=(C_word)a,a+=7,tmp));
t112=C_mutate((C_word*)lf[443]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7284,a[2]=((C_word)li242),tmp=(C_word)a,a+=3,tmp));
t113=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t113+1)))(2,t113,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7284,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[443]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7276,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_foreign_string_argumentp(t4);
/* ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t6=t5;
f_7276(2,t6,C_SCHEME_FALSE);}}

/* k7274 in set-root-directory! in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1343(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2362 posix-error */
t3=lf[3];
f_1626(6,t3,((C_word*)t0)[3],lf[48],lf[443],lf[444],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_7019r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7019r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7019r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li236),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7192,a[2]=t5,a[3]=((C_word)li237),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7197,a[2]=t6,a[3]=((C_word)li238),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7202,a[2]=t7,a[3]=((C_word)li240),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action12961332 */
t9=t8;
f_7202(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id12971330 */
t11=t7;
f_7197(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit12981327 */
t13=t6;
f_7192(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body12941300 */
t15=t5;
f_7021(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action1296 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_7202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7202,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7208,a[2]=((C_word)li239),tmp=(C_word)a,a+=3,tmp);
/* def-id12971330 */
t3=((C_word*)t0)[2];
f_7197(t3,t1,t2);}

/* a7207 in def-action1296 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7208,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1297 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_7197(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7197,NULL,3,t0,t1,t2);}
/* def-limit12981327 */
t3=((C_word*)t0)[2];
f_7192(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1298 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_7192(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7192,NULL,4,t0,t1,t2,t3);}
/* body12941300 */
t4=((C_word*)t0)[2];
f_7021(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_7021(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7021,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[435]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7028,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_7028(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7187,a[2]=t4,a[3]=t7,a[4]=((C_word)li234),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_7028(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7179,a[2]=((C_word)li235),tmp=(C_word)a,a+=3,tmp));}}

/* f_7179 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7179(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7179,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_7187 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7187(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7187,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_7028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7028,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_7167(2,t4,t2);}
else{
/* posixunix.scm: 2334 regexp? */
t4=*((C_word*)lf[442]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[11]);}}

/* k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7167,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7168,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word)li229),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7038,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7161,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2337 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[441]);}

/* k7159 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2337 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7038,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7040,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li233),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7040(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_7040(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7040,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2343 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7059,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2344 pathname-file */
t3=*((C_word*)lf[440]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7147,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2351 pproc */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k7145 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7147,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7154,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2351 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2352 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7040(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k7152 in k7145 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2351 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7040(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7141,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[436]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[437]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2344 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_7040(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2345 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k7072 in k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7074,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7084,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7086,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,a[5]=((C_word)li230),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word)li231),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7118,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,a[5]=((C_word)li232),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2347 ##sys#dynamic-wind */
t11=*((C_word*)lf[439]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7131,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7134,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2350 pproc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k7132 in k7072 in k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2350 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7131(2,t2,((C_word*)t0)[2]);}}

/* k7129 in k7072 in k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2350 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7040(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7117 in k7072 in k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7118,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[432]+1));}

/* a7093 in k7072 in k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7102,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7116,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2348 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],lf[438]);}

/* k7114 in a7093 in k7072 in k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2348 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7100 in a7093 in k7072 in k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7106,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7109,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2349 pproc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k7107 in k7100 in a7093 in k7072 in k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2349 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7106(2,t2,((C_word*)t0)[2]);}}

/* k7104 in k7100 in a7093 in k7072 in k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2348 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7040(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7085 in k7072 in k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7086,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[432]+1));}

/* k7082 in k7072 in k7139 in k7057 in loop in k7036 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2346 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7040(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7168 in k7165 in k7026 in body1294 in find-files in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_7168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7168,3,t0,t1,t2);}
/* posixunix.scm: 2335 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6959(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_6959r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6959r(t0,t1,t2,t3);}}

static void C_ccall f_6959r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6961,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li225),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6966,a[2]=t4,a[3]=((C_word)li226),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6971,a[2]=t5,a[3]=((C_word)li227),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args12701278 */
t7=t6;
f_6971(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env12711276 */
t9=t5;
f_6966(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body12681273 */
t11=t4;
f_6961(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args1270 in process* in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6971,NULL,2,t0,t1);}
/* def-env12711276 */
t2=((C_word*)t0)[2];
f_6966(t2,t1,C_SCHEME_FALSE);}

/* def-env1271 in process* in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6966(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6966,NULL,3,t0,t1,t2);}
/* body12681273 */
t3=((C_word*)t0)[2];
f_6961(t3,t1,t2,C_SCHEME_FALSE);}

/* body1268 in process* in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6961(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6961,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2312 %process */
f_6838(t1,lf[434],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6899(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_6899r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6899r(t0,t1,t2,t3);}}

static void C_ccall f_6899r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6901,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li221),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6906,a[2]=t4,a[3]=((C_word)li222),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6911,a[2]=t5,a[3]=((C_word)li223),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args12501258 */
t7=t6;
f_6911(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env12511256 */
t9=t5;
f_6906(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body12481253 */
t11=t4;
f_6901(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args1250 in process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6911,NULL,2,t0,t1);}
/* def-env12511256 */
t2=((C_word*)t0)[2];
f_6906(t2,t1,C_SCHEME_FALSE);}

/* def-env1251 in process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6906(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6906,NULL,3,t0,t1,t2);}
/* body12481253 */
t3=((C_word*)t0)[2];
f_6901(t3,t1,t2,C_SCHEME_FALSE);}

/* body1248 in process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6901(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6901,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2309 %process */
f_6838(t1,lf[433],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6838(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6838,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6840,a[2]=t2,a[3]=((C_word)li217),tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6859,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2298 chkstrlst */
t12=t9;
f_6840(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6893,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2300 ##sys#shell-command-arguments */
t13=*((C_word*)lf[427]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)t7)[1]);}}

/* k6891 in %process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6893,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2301 ##sys#shell-command */
t4=*((C_word*)lf[424]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6895 in k6891 in %process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6859(2,t3,t2);}

/* k6857 in %process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6862,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2302 chkstrlst */
t3=((C_word*)t0)[2];
f_6840(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6862(2,t3,C_SCHEME_UNDEFINED);}}

/* k6860 in k6857 in %process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li218),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6873,a[2]=((C_word*)t0)[3],a[3]=((C_word)li219),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2303 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6872 in k6860 in k6857 in %process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6873,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2305 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2306 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a6866 in k6860 in k6857 in %process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6867,2,t0,t1);}
/* posixunix.scm: 2303 ##sys#process */
t2=*((C_word*)lf[431]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6840(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6840,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[2],a[3]=((C_word)li216),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6848 in chkstrlst in %process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6849,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6774,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6780,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word)li213),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,a[10]=((C_word)li214),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a6785 in ##sys#process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6786,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6797,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6817,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2279 make-on-close */
t12=((C_word*)t0)[3];
f_6603(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k6815 in a6785 in ##sys#process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2278 input-port */
t2=((C_word*)t0)[7];
f_6752(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6795 in a6785 in ##sys#process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6801,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2281 make-on-close */
t4=((C_word*)t0)[6];
f_6603(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k6811 in k6795 in a6785 in ##sys#process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2280 output-port */
t2=((C_word*)t0)[7];
f_6763(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6799 in k6795 in a6785 in ##sys#process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6805,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6809,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2284 make-on-close */
t4=((C_word*)t0)[3];
f_6603(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k6807 in k6799 in k6795 in a6785 in ##sys#process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2283 input-port */
t2=((C_word*)t0)[7];
f_6752(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6803 in k6799 in k6795 in a6785 in ##sys#process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2277 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6779 in ##sys#process in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6780,2,t0,t1);}
/* posixunix.scm: 2272 spawn */
t2=((C_word*)t0)[8];
f_6707(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6763(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6763,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6767,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2268 connect-parent */
t8=((C_word*)t0)[2];
f_6660(t8,t7,t4,t5);}

/* k6765 in output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2269 ##sys#custom-output-port */
t2=*((C_word*)lf[323]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6752(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6752,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6756,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2264 connect-parent */
t8=((C_word*)t0)[2];
f_6660(t8,t7,t4,t5);}

/* k6754 in input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2265 ##sys#custom-input-port */
t2=*((C_word*)lf[309]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6707,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2251 needed-pipe */
t9=((C_word*)t0)[2];
f_6640(t9,t8,t6);}

/* k6709 in spawn in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2252 needed-pipe */
t3=((C_word*)t0)[2];
f_6640(t3,t2,((C_word*)t0)[5]);}

/* k6712 in k6709 in spawn in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2253 needed-pipe */
t3=((C_word*)t0)[2];
f_6640(t3,t2,((C_word*)t0)[6]);}

/* k6715 in k6712 in k6709 in spawn in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6717,2,t0,t1);}
t2=f_6691(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6728,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word)li209),tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2256 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6729 in k6715 in k6712 in k6709 in spawn in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6734,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2258 connect-child */
t3=((C_word*)t0)[7];
f_6674(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[286]+1));}

/* k6732 in a6729 in k6715 in k6712 in k6709 in spawn in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6737,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_6691(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2259 connect-child */
t4=((C_word*)t0)[5];
f_6674(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[287]+1));}

/* k6735 in k6732 in a6729 in k6715 in k6712 in k6709 in spawn in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6740,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_6691(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2260 connect-child */
t4=((C_word*)t0)[3];
f_6674(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[288]+1));}

/* k6738 in k6735 in k6732 in a6729 in k6715 in k6712 in k6709 in spawn in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2261 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6726 in k6715 in k6712 in k6709 in spawn in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2254 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall f_6691(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6674(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6674,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6687,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2242 file-close */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k6685 in connect-child in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6687,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6599,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2216 duplicate-fileno */
t6=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k6597 in k6685 in connect-child in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2217 file-close */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6660(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6660,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6673,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2236 file-close */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6671 in connect-parent in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6640(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6640,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6649,a[2]=((C_word*)t0)[2],a[3]=((C_word)li203),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6655,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2231 ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a6654 in needed-pipe in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6655,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a6648 in needed-pipe in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6649,2,t0,t1);}
/* posixunix.scm: 2231 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* make-on-close in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6603(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6603,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6605,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,a[9]=((C_word)li201),tmp=(C_word)a,a+=10,tmp));}

/* f_6605 in make-on-close in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6605,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li199),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li200),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2224 ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a6625 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6626,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2226 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[192],((C_word*)t0)[3],lf[430],((C_word*)t0)[2],t4);}}

/* a6619 */
static void C_ccall f_6620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6620,2,t0,t1);}
/* posixunix.scm: 2224 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6547r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6547r(t0,t1,t2,t3);}}

static void C_ccall f_6547r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6554,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2180 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k6552 in process-run in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6554,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2182 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2184 ##sys#shell-command */
t4=*((C_word*)lf[424]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k6571 in k6552 in process-run in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6577,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2184 ##sys#shell-command-arguments */
t3=*((C_word*)lf[427]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6575 in k6571 in k6552 in process-run in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2184 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6541,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[428],t2));}

/* ##sys#shell-command in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6536,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2169 getenv */
t3=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[426]);}

/* k6534 in ##sys#shell-command in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[425]));}

/* process-signal in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6505(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6505r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6505r(t0,t1,t2,t3);}}

static void C_ccall f_6505r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[422]);
t7=(C_word)C_i_check_exact_2(t5,lf[422]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2166 posix-error */
t10=lf[3];
f_1626(7,t10,t1,lf[192],lf[422],lf[423],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6498,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1116(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6495,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1113(C_SCHEME_UNDEFINED));}

/* current-process-id in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6492,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1111(C_SCHEME_UNDEFINED));}

/* process-wait in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_6414r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6414r(t0,t1,t2);}}

static void C_ccall f_6414r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[417]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6444,a[2]=t8,a[3]=t11,a[4]=((C_word)li189),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6450,a[2]=t11,a[3]=((C_word)li190),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2150 ##sys#call-with-values */
C_call_with_values(4,0,t1,t13,t14);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* a6449 in process-wait in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6450,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2152 posix-error */
t6=lf[3];
f_1626(6,t6,t1,lf[192],lf[417],lf[418],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2153 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a6443 in process-wait in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6444,2,t0,t1);}
/* posixunix.scm: 2150 ##sys#process-wait */
t2=*((C_word*)lf[416]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6397,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 2137 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6215(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_6215r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6215r(t0,t1,t2,t3);}}

static void C_ccall f_6215r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li184),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6344,a[2]=t4,a[3]=((C_word)li185),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6349,a[2]=t5,a[3]=((C_word)li186),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist10511086 */
t7=t6;
f_6349(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist10521084 */
t9=t5;
f_6344(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body10491054 */
t11=t4;
f_6217(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist1051 in process-execute in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6349,NULL,2,t0,t1);}
/* def-envlist10521084 */
t2=((C_word*)t0)[2];
f_6344(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist1052 in process-execute in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6344(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6344,NULL,3,t0,t1,t2);}
/* body10491054 */
t3=((C_word*)t0)[2];
f_6217(t3,t1,t2,C_SCHEME_FALSE);}

/* body1049 in process-execute in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6217(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6217,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[414]);
t5=(C_word)C_i_check_list_2(t2,lf[414]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6227,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2105 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k6225 in body1049 in process-execute in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6227,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_6177(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6235,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li183),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_6235(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do1058 in k6225 in body1049 in process-execute in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6235(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6235,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_6177(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6248,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[414]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6281,a[2]=((C_word*)t0)[3],a[3]=((C_word)li182),tmp=(C_word)a,a+=4,tmp);
t8=t5;
f_6248(t8,f_6281(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_6248(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[414]);
t6=(C_word)C_block_size(t4);
t7=f_6177(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* do1062 in do1058 in k6225 in body1049 in process-execute in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall f_6281(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_6196(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[414]);
t5=(C_word)C_block_size(t3);
t6=f_6196(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k6246 in do1058 in k6225 in body1049 in process-execute in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6248,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6273,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2119 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k6271 in k6246 in do1058 in k6225 in body1049 in process-execute in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2119 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6249 in k6246 in do1058 in k6225 in body1049 in process-execute in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub1030(C_SCHEME_UNDEFINED);
t5=(C_word)stub1042(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2126 posix-error */
t6=lf[3];
f_1626(6,t6,((C_word*)t0)[3],lf[192],lf[414],lf[415],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall f_6196(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub1035(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall f_6177(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub1023(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6135r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6135r(t0,t1,t2);}}

static void C_ccall f_6135r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub1006(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2090 posix-error */
t5=lf[3];
f_1626(5,t5,t1,lf[192],lf[411],lf[412]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6157,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_vector_ref(t2,C_fix(0));
t9=t8;
((C_proc2)C_retrieve_proc(t9))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k6155 in process-fork in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6161,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_6161 in k6155 in process-fork in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6161,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1011(C_SCHEME_UNDEFINED,t3));}

/* glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_6023r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6023r(t0,t1,t2);}}

static void C_ccall f_6023r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li176),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_6029(t6,t1,t2);}

/* conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6029(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6029,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6044,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li173),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li175),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a6049 in conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6050,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6054,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6127,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[410]);
/* posixunix.scm: 2074 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k6125 in a6049 in conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2074 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6052 in a6049 in conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixunix.scm: 2075 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k6055 in k6052 in a6049 in conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2076 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k6058 in k6055 in k6052 in a6049 in conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6067,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[409]);
/* posixunix.scm: 2077 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k6065 in k6058 in k6055 in k6052 in a6049 in conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6067,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li174),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_6069(t5,((C_word*)t0)[2],t1);}

/* loop in k6065 in k6058 in k6055 in k6052 in a6049 in conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_6069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6069,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixunix.scm: 2078 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_6029(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6086,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixunix.scm: 2079 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k6084 in loop in k6065 in k6058 in k6055 in k6052 in a6049 in conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6086,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6096,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixunix.scm: 2080 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixunix.scm: 2081 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6069(t3,((C_word*)t0)[6],t2);}}

/* k6094 in k6084 in loop in k6065 in k6058 in k6055 in k6052 in a6049 in conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6100,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixunix.scm: 2080 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6069(t4,t2,t3);}

/* k6098 in k6094 in k6084 in loop in k6065 in k6058 in k6055 in k6052 in a6049 in conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6100,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a6043 in conc-loop in glob in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6044,2,t0,t1);}
/* posixunix.scm: 2073 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6015,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub966(t3),C_fix(0));}

/* k6013 in get-host-name in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6018,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6018(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2054 posix-error */
t3=lf[3];
f_1626(5,t3,t2,lf[396],lf[400],lf[401]);}}

/* k6016 in k6013 in get-host-name in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5976,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5980,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2035 ##sys#terminal-check */
f_5921(t3,lf[395],t2);}

/* k5978 in terminal-size in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5980,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6000,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
t5=*((C_word*)lf[398]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[399]);}

/* k5998 in k5978 in terminal-size in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[398]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[399]);}

/* k6002 in k5998 in k5978 in terminal-size in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_6004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_pointer_argumentp(t3);
t6=(C_word)C_i_foreign_pointer_argumentp(t1);
t7=(C_word)stub952(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(C_word)C_eqp(C_fix(0),t7);
if(C_truep(t8)){
/* posixunix.scm: 2042 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2043 posix-error */
t9=lf[3];
f_1626(6,t9,((C_word*)t0)[4],lf[396],lf[395],lf[397],((C_word*)t0)[6]);}}

/* terminal-name in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5953(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5953,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5957,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2027 ##sys#terminal-check */
f_5921(t3,lf[394],t2);}

/* k5955 in terminal-name in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5957,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub942(t4,t5);
/* ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* ##sys#terminal-check in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_5921(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5921,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5925,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2019 ##sys#check-port */
t5=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k5923 in ##sys#terminal-check in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[95],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2022 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[393],((C_word*)t0)[4]);}}

/* terminal-port? in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5902,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5906,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2014 ##sys#check-port */
t4=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[391]);}

/* k5904 in terminal-port? in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2015 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[304]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k5907 in k5904 in terminal-port? in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5843r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5843r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5843r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5847,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1999 ##sys#check-port */
t6=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[385]);}

/* k5845 in set-buffering-mode! in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5847,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[387]);
if(C_truep(t6)){
t7=t5;
f_5853(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[388]);
if(C_truep(t7)){
t8=t5;
f_5853(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[389]);
if(C_truep(t8)){
t9=t5;
f_5853(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2005 ##sys#error */
t9=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[385],lf[390],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k5851 in k5845 in set-buffering-mode! in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[385]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[95],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 2011 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[385],lf[386],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5836,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub922(C_SCHEME_UNDEFINED,t3));}

/* _exit in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5820(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5820r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5820r(t0,t1,t2);}}

static void C_ccall f_5820r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub917(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5808,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub912(t2),C_fix(0));}

/* utc-time->seconds in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5780,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[379]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5787,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1967 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[379],lf[381],t2);}
else{
t6=t4;
f_5787(2,t6,C_SCHEME_UNDEFINED);}}

/* k5785 in utc-time->seconds in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 1969 ##sys#cons-flonum */
t2=*((C_word*)lf[376]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1970 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[379],lf[380],((C_word*)t0)[3]);}}

/* local-time->seconds in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5752,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[375]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5759,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1960 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[375],lf[378],t2);}
else{
t6=t4;
f_5759(2,t6,C_SCHEME_UNDEFINED);}}

/* k5757 in local-time->seconds in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 1962 ##sys#cons-flonum */
t2=*((C_word*)lf[376]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1963 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[375],lf[377],((C_word*)t0)[3]);}}

/* string->time in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5706(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5706r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5706r(t0,t1,t2,t3);}}

static void C_ccall f_5706r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5710,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5710(2,t5,lf[374]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5710(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5708 in string->time in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5710,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[373]);
t3=(C_word)C_i_check_string_2(t1,lf[373]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5723,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1956 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* k5721 in k5708 in string->time in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5727,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1956 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5725 in k5721 in k5708 in string->time in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5727,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub893(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5624r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5624r(t0,t1,t2,t3);}}

static void C_ccall f_5624r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5628,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5628(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5628(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5626 in time->string in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5628,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[3],lf[369]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(10)))){
/* posixunix.scm: 1940 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[369],lf[372],((C_word*)t0)[3]);}
else{
t5=t3;
f_5634(2,t5,C_SCHEME_UNDEFINED);}}

/* k5632 in k5626 in time->string in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5634,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[369]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5653,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1944 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub866(t4,t3),C_fix(0));}}

/* k5654 in k5632 in k5626 in time->string in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1948 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1949 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[369],lf[371],((C_word*)t0)[2]);}}

/* k5651 in k5632 in k5626 in time->string in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5653,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub872(t3,t2,t1),C_fix(0));}

/* k5641 in k5632 in k5626 in time->string in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1945 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[369],lf[370],((C_word*)t0)[2]);}}

/* seconds->string in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5591,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5595,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub857(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k5593 in seconds->string in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1932 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1933 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[367],lf[368],((C_word*)t0)[2]);}}

/* seconds->utc-time in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5572,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[366]);
/* posixunix.scm: 1925 ##sys#decode-seconds */
t4=*((C_word*)lf[365]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5563,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[364]);
/* posixunix.scm: 1921 ##sys#decode-seconds */
t4=*((C_word*)lf[365]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* memory-mapped-file? in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5557,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[355]));}

/* memory-mapped-file-pointer in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5548,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[355],lf[362]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5513r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5513r(t0,t1,t2,t3);}}

static void C_ccall f_5513r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_i_check_structure_2(t2,lf[355],lf[360]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub838(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1908 posix-error */
t12=lf[3];
f_1626(7,t12,t1,lf[48],lf[360],lf[361],t2,t6);}}

/* map-file-to-memory in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_5451r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_5451r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_5451r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5455,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_5455(2,t10,t2);}
else{
/* posixunix.scm: 1893 ##sys#null-pointer */
t10=*((C_word*)lf[359]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k5453 in map-file-to-memory in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5455,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_5461(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1896 ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[60],lf[354],lf[358],t1);}}

/* k5459 in k5453 in map-file-to-memory in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5461,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub813(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5467,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5480,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1898 ##sys#pointer->address */
t17=*((C_word*)lf[357]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,t14);}

/* k5478 in k5459 in k5453 in map-file-to-memory in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1899 posix-error */
t3=lf[3];
f_1626(11,t3,((C_word*)t0)[8],lf[48],lf[354],lf[356],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_5467(2,t3,C_SCHEME_UNDEFINED);}}

/* k5465 in k5459 in k5453 in map-file-to-memory in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[355],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* current-environment in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5348,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5354,a[2]=t3,a[3]=((C_word)li151),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5354(t5,t1,C_fix(0));}

/* loop in current-environment in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_5354(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5354,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5358,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub795(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k5356 in loop in current-environment in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5358,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5366,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li150),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5366(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k5356 in loop in current-environment in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_5366(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5366,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5392,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1860 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1863 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k5390 in scan in k5356 in loop in current-environment in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5396,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1861 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k5394 in k5390 in scan in k5356 in loop in current-environment in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5396,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5384,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1862 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5354(t5,t3,t4);}

/* k5382 in k5394 in k5390 in scan in k5356 in loop in current-environment in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5384,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5328,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[343]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5336,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1849 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5334 in unsetenv in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5311,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[342]);
t5=(C_word)C_i_check_string_2(t3,lf[342]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5322,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1844 ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k5320 in setenv in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5326,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1844 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5324 in k5320 in setenv in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5285,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[340]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5292,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5309,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1833 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k5307 in fifo? in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1833 ##sys#file-info */
t2=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5290 in fifo? in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1836 posix-error */
t2=lf[3];
f_1626(6,t2,((C_word*)t0)[3],lf[48],lf[340],lf[341],((C_word*)t0)[2]);}}

/* create-fifo in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5242r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5242r(t0,t1,t2,t3);}}

static void C_ccall f_5242r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[338]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5249,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_5249(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_5249(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k5247 in create-fifo in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_5249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5249,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[338]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5270,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1827 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k5268 in k5247 in create-fifo in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1827 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5264 in k5247 in create-fifo in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1828 posix-error */
t3=lf[3];
f_1626(7,t3,((C_word*)t0)[3],lf[48],lf[338],lf[339],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5214,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[329],lf[336]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1817 posix-error */
t9=lf[3];
f_1626(6,t9,t1,lf[48],lf[336],lf[337],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5192r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5192r(t0,t1,t2,t3);}}

static void C_ccall f_5192r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5196,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1808 setup */
f_5070(t4,t2,t3,lf[334]);}

/* k5194 in file-test-lock in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1810 err */
f_5144(((C_word*)t0)[3],lf[335],t1,lf[334]);}}

/* file-lock/blocking in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5177r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5177r(t0,t1,t2,t3);}}

static void C_ccall f_5177r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5181,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1802 setup */
f_5070(t4,t2,t3,lf[332]);}

/* k5179 in file-lock/blocking in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1804 err */
f_5144(((C_word*)t0)[2],lf[333],t1,lf[332]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5162r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5162r(t0,t1,t2,t3);}}

static void C_ccall f_5162r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5166,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1796 setup */
f_5070(t4,t2,t3,lf[330]);}

/* k5164 in file-lock in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1798 err */
f_5144(((C_word*)t0)[2],lf[331],t1,lf[330]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_5144(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5144,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1793 posix-error */
t8=lf[3];
f_1626(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_5070(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5070,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5092,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1785 ##sys#check-port */
t16=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k5090 in setup in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5092,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_5098(t6,t5);}
else{
t5=t3;
f_5098(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k5096 in k5090 in setup in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_5098(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5098,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[329],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5031,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[326]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5048,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5055,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5059,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1768 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_5048(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1770 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[326],lf[328],t2);}}}

/* k5057 in file-truncate in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1768 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5053 in file-truncate in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5048(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k5046 in file-truncate in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1772 posix-error */
t2=lf[3];
f_1626(7,t2,((C_word*)t0)[4],lf[48],lf[326],lf[327],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_4772r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4772r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4772r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li134),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4958,a[2]=t6,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4963,a[2]=t7,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4968,a[2]=t8,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?687728 */
t10=t9;
f_4968(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi688726 */
t12=t8;
f_4963(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close689723 */
t14=t7;
f_4958(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* body685691 */
t16=t6;
f_4774(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-nonblocking?687 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4968(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4968,NULL,2,t0,t1);}
/* def-bufi688726 */
t2=((C_word*)t0)[2];
f_4963(t2,t1,C_SCHEME_FALSE);}

/* def-bufi688 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4963(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4963,NULL,3,t0,t1,t2);}
/* def-on-close689723 */
t3=((C_word*)t0)[2];
f_4958(t3,t1,t2,C_fix(0));}

/* def-on-close689 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4958(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4958,NULL,4,t0,t1,t2,t3);}
/* body685691 */
t4=((C_word*)t0)[2];
f_4774(t4,t1,t2,t3,*((C_word*)lf[321]+1));}

/* body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4774(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4774,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1710 ##sys#file-nonblocking! */
t6=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_4778(2,t6,C_SCHEME_UNDEFINED);}}

/* k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4780,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word)li127),tmp=(C_word)a,a+=7,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_4826(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4870,a[2]=t3,a[3]=((C_word)li131),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4884,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1729 ##sys#make-string */
t12=*((C_word*)lf[319]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_4884(2,t12,((C_word*)t0)[6]);}}}

/* k4882 in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4884,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_4826(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4885,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li133),tmp=(C_word)a,a+=7,tmp));}

/* f_4885 in k4882 in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4885,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4902,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word)li132),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_4902(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1745 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4780(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_4902(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4902,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4912,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1735 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_4780(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_difference(t4,t2);
/* posixunix.scm: 1740 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k4910 in loop */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1737 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4902(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_4870 in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4870,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1728 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4780(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4824 in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4826(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4826,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4835,a[2]=((C_word*)t0)[9],a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li129),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4862,a[2]=((C_word*)t0)[9],a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1748 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t5,t6,t7,t8);}

/* a4861 in k4824 in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4862,2,t0,t1);}
/* posixunix.scm: 1758 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* a4840 in k4824 in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4841,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4851,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1755 posix-error */
t3=lf[3];
f_1626(7,t3,t2,lf[48],((C_word*)t0)[3],lf[325],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_4851(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4849 in a4840 in k4824 in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1756 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a4834 in k4824 in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4835,3,t0,t1,t2);}
/* posixunix.scm: 1750 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* k4828 in k4824 in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4833,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1759 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k4831 in k4828 in k4824 in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4780(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4780,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4796,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1718 ##sys#thread-yield! */
t8=*((C_word*)lf[311]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1720 posix-error */
t7=lf[3];
f_1626(7,t7,t1,((C_word*)t0)[3],lf[48],lf[324],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4815,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1722 ##sys#substring */
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4813 in poke in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1722 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4780(t3,((C_word*)t0)[2],t1,t2);}

/* k4794 in poke in k4776 in body685 in ##sys#custom-output-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1719 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4780(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_4298r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4298r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4298r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,a[7]=((C_word)li121),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4679,a[2]=t6,a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4684,a[2]=t7,a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4689,a[2]=t8,a[3]=((C_word)li124),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4694,a[2]=t9,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?577666 */
t11=t10;
f_4694(t11,t1);}
else{
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi578664 */
t13=t9;
f_4689(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close579661 */
t15=t8;
f_4684(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?580657 */
t17=t7;
f_4679(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
/* body575582 */
t19=t6;
f_4300(t19,t1,t11,t13,t15,t17);}
else{
/* ##sys#error */
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[0],t18);}}}}}}

/* def-nonblocking?577 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4694(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4694,NULL,2,t0,t1);}
/* def-bufi578664 */
t2=((C_word*)t0)[2];
f_4689(t2,t1,C_SCHEME_FALSE);}

/* def-bufi578 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4689(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4689,NULL,3,t0,t1,t2);}
/* def-on-close579661 */
t3=((C_word*)t0)[2];
f_4684(t3,t1,t2,C_fix(1));}

/* def-on-close579 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4684(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4684,NULL,4,t0,t1,t2,t3);}
/* def-more?580657 */
t4=((C_word*)t0)[2];
f_4679(t4,t1,t2,t3,*((C_word*)lf[321]+1));}

/* def-more?580 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4679(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4679,NULL,5,t0,t1,t2,t3,t4);}
/* body575582 */
t5=((C_word*)t0)[2];
f_4300(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4300(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4300,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1588 ##sys#file-nonblocking! */
t7=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_4304(2,t7,C_SCHEME_UNDEFINED);}}

/* k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4304,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1590 ##sys#make-string */
t5=*((C_word*)lf[319]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_4310(2,t5,((C_word*)t0)[10]);}}

/* k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li107),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4326,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,a[10]=((C_word)li109),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4421,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word)li110),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4434,a[2]=t6,a[3]=t3,a[4]=t5,a[5]=((C_word)li111),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=((C_word)li112),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4467,a[2]=t8,a[3]=t7,a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4476,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li115),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4552,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,a[6]=((C_word)li120),tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1634 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t18))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a4551 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4552,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4558,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li119),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_4558(t7,t1,C_SCHEME_FALSE);}

/* loop in a4551 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4558(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4558,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li116),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4638,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word)li117),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[2],a[3]=((C_word)li118),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1693 ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4654,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1699 fetch */
t5=((C_word*)t0)[5];
f_4334(t5,t4);}}

/* k4652 in loop in a4551 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1701 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4558(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a4643 in loop in a4551 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4644,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1696 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4558(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a4637 in loop in a4551 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
/* posixunix.scm: 1694 ##sys#scan-buffer-line */
t2=*((C_word*)lf[320]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a4551 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4560,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_4567(2,t8,(C_truep(t7)?t7:lf[317]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4610,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1676 ##sys#make-string */
t8=*((C_word*)lf[319]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k4608 in bumper in loop in a4551 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1682 ##sys#string-append */
t6=*((C_word*)lf[318]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_4567(2,t6,t1);}}

/* k4565 in bumper in loop in a4551 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4567,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4577,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1686 fetch */
t5=((C_word*)t0)[3];
f_4334(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1691 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k4575 in k4565 in bumper in loop in a4551 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1687 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4475 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4476,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4484,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_4484(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_4484(t8,(C_word)C_fixnum_difference(t7,t5));}}

/* k4482 in a4475 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4484(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4484,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li114),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_4486(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k4482 in a4475 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4486(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4486,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* posixunix.scm: 1662 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4534,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1664 fetch */
t7=((C_word*)t0)[2];
f_4334(t7,t6);}}}

/* k4532 in loop in k4482 in a4475 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1667 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4486(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a4466 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1652 fetch */
t3=((C_word*)t0)[2];
f_4334(t3,t2);}

/* k4469 in a4466 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1653 peek */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_4326(((C_word*)t0)[2]));}

/* a4445 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4456,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1649 posix-error */
t3=lf[3];
f_1626(7,t3,t2,lf[48],((C_word*)t0)[3],lf[316],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_4456(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4454 in a4445 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1650 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a4433 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4434,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1644 ready? */
t3=((C_word*)t0)[2];
f_4311(t3,t1);}}

/* a4420 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4425,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1636 fetch */
t3=((C_word*)t0)[2];
f_4334(t3,t2);}

/* k4423 in a4420 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_4326(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k4414 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4416,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1703 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k4417 in k4414 in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4334(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4334,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li108),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_4346(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4346,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4362,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1611 ##sys#thread-block-for-i/o! */
t6=*((C_word*)lf[312]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[313]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1614 posix-error */
t5=lf[3];
f_1626(7,t5,t1,lf[48],((C_word*)t0)[6],lf[314],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4383,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1618 more? */
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k4381 in loop in fetch in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4383,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4386,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1620 ##sys#thread-yield! */
t3=*((C_word*)lf[311]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_4392(2,t8,t7);}
else{
/* posixunix.scm: 1626 posix-error */
t7=lf[3];
f_1626(7,t7,t4,lf[48],((C_word*)t0)[3],lf[315],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_4392(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4390 in k4381 in loop in fetch in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4384 in k4381 in loop in fetch in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1621 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4346(t2,((C_word*)t0)[2]);}

/* k4360 in loop in fetch in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1612 ##sys#thread-yield! */
t3=*((C_word*)lf[311]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4363 in k4360 in loop in fetch in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1613 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4346(t2,((C_word*)t0)[2]);}

/* peek in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall f_4326(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4311(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4311,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1596 ##sys#file-select-one */
t3=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k4323 in ready? in k4308 in k4302 in body575 in ##sys#custom-input-port in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1597 posix-error */
t3=lf[3];
f_1626(7,t3,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[310],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* duplicate-fileno in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4271r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4271r(t0,t1,t2,t3);}}

static void C_ccall f_4271r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[305]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4278,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_4278(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[305]);
t8=t5;
f_4278(t8,(C_word)C_dup2(t2,t6));}}

/* k4276 in duplicate-fileno in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4278(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4278,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4281,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1581 posix-error */
t3=lf[3];
f_1626(6,t3,t2,lf[48],lf[305],lf[306],((C_word*)t0)[2]);}
else{
t3=t2;
f_4281(2,t3,C_SCHEME_UNDEFINED);}}

/* k4279 in k4276 in duplicate-fileno in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4226,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4230,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1563 ##sys#check-port */
t4=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[299]);}

/* k4228 in port->fileno in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4230,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[300],t2);
if(C_truep(t3)){
/* posixunix.scm: 1564 ##sys#tcp-port->fileno */
t4=*((C_word*)lf[301]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1565 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[304]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k4263 in k4228 in port->fileno in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4265,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1570 posix-error */
t2=lf[3];
f_1626(6,t2,((C_word*)t0)[3],lf[60],lf[299],lf[302],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4248,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1568 posix-error */
t4=lf[3];
f_1626(6,t4,t3,lf[48],lf[299],lf[303],((C_word*)t0)[2]);}
else{
t4=t3;
f_4248(2,t4,C_SCHEME_UNDEFINED);}}}

/* k4246 in k4263 in k4228 in port->fileno in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4212r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4212r(t0,t1,t2,t3);}}

static void C_ccall f_4212r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[298]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4224,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1559 mode */
f_4146(t5,C_SCHEME_FALSE,t3);}

/* k4222 in open-output-file* in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4224,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1559 check */
f_4183(((C_word*)t0)[2],lf[298],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4198r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4198r(t0,t1,t2,t3);}}

static void C_ccall f_4198r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[297]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4210,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1555 mode */
f_4146(t5,C_SCHEME_TRUE,t3);}

/* k4208 in open-input-file* in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4210,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1555 check */
f_4183(((C_word*)t0)[2],lf[297],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4183(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4183,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1548 posix-error */
t6=lf[3];
f_1626(6,t6,t1,lf[48],t2,lf[295],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4196,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1549 ##sys#make-port */
t7=*((C_word*)lf[143]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[144]+1),lf[296],lf[95]);}}

/* k4194 in check in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_4146(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4146,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4154,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[289]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1542 ##sys#error */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[290],t5);}
else{
t8=t4;
f_4154(2,t8,lf[291]);}}
else{
/* posixunix.scm: 1543 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[292],t5);}}
else{
t5=t4;
f_4154(2,t5,(C_truep(t2)?lf[293]:lf[294]));}}

/* k4152 in mode in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1538 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4121,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[283]);
t5=(C_word)C_i_check_string_2(t3,lf[283]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4102,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_4102(2,t9,C_SCHEME_FALSE);}}

/* k4100 in file-link in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_4106(2,t3,C_SCHEME_FALSE);}}

/* k4104 in k4100 in file-link in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub519(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1523 posix-error */
t3=lf[3];
f_1626(7,t3,((C_word*)t0)[4],lf[48],lf[284],lf[285],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4071,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[281]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4079,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4095,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1512 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4093 in read-symbolic-link in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1512 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4077 in read-symbolic-link in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4079,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4082,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1514 posix-error */
t4=lf[3];
f_1626(6,t4,t3,lf[48],lf[281],lf[282],((C_word*)t0)[2]);}
else{
t4=t3;
f_4082(2,t4,C_SCHEME_UNDEFINED);}}

/* k4080 in k4077 in read-symbolic-link in k4068 in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1515 substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4033,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[277]);
t5=(C_word)C_i_check_string_2(t3,lf[277]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4054,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4066,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1500 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4064 in create-symbolic-link in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1500 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4052 in create-symbolic-link in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4062,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1501 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4060 in k4052 in create-symbolic-link in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1501 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4056 in k4052 in create-symbolic-link in k4029 in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1503 posix-error */
t3=lf[3];
f_1626(7,t3,((C_word*)t0)[4],lf[48],lf[278],lf[279],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* set-process-group-id! in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4008,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[274]);
t5=(C_word)C_i_check_exact_2(t3,lf[274]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4024,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1478 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k4022 in set-process-group-id! in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1479 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[274],lf[275],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* create-session in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3997,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4003,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1470 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3997(2,t4,C_SCHEME_UNDEFINED);}}

/* k4001 in create-session in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1471 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[272],lf[273]);}

/* k3995 in create-session in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3987,3,t0,t1,t2);}
/* posixunix.scm: 1465 check */
f_3951(t1,t2,C_fix((C_word)X_OK),lf[271]);}

/* file-write-access? in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3981,3,t0,t1,t2);}
/* posixunix.scm: 1464 check */
f_3951(t1,t2,C_fix((C_word)W_OK),lf[270]);}

/* file-read-access? in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3975,3,t0,t1,t2);}
/* posixunix.scm: 1463 check */
f_3951(t1,t2,C_fix((C_word)R_OK),lf[269]);}

/* check in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_3951(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3951,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3969,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3973,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1460 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3971 in check in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1460 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3967 in check in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3961,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3961(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1461 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3959 in k3967 in check in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3921,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[267]);
t6=(C_word)C_i_check_exact_2(t3,lf[267]);
t7=(C_word)C_i_check_exact_2(t4,lf[267]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3945,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3949,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1450 ##sys#expand-home-path */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k3947 in change-file-owner in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1450 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3943 in change-file-owner in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1451 posix-error */
t3=lf[3];
f_1626(8,t3,((C_word*)t0)[3],lf[48],lf[267],lf[268],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3894,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[265]);
t5=(C_word)C_i_check_exact_2(t3,lf[265]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3915,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3919,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1442 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3917 in change-file-mode in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1442 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3913 in change-file-mode in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1443 posix-error */
t3=lf[3];
f_1626(7,t3,((C_word*)t0)[3],lf[48],lf[265],lf[266],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3830,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[224]);
t5=(C_word)C_i_check_exact_2(t3,lf[224]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3818,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_3818(2,t9,C_SCHEME_FALSE);}}

/* k3816 in initialize-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub459(C_SCHEME_UNDEFINED,t1,t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1363 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3844 in k3816 in initialize-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1364 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[224],lf[225],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3756,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3760,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_3686(t4);
if(C_truep(t5)){
t6=t3;
f_3760(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1346 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[221],lf[223]);}}

/* k3758 in set-groups! in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3760,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3765,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li87),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3765(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do446 in k3758 in set-groups! in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_3765(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3765,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3781,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1351 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[221]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k3779 in do446 in k3758 in set-groups! in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1352 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[221],lf[222],((C_word*)t0)[2]);}

/* get-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3693,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3697,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3751,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1332 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3697(2,t4,C_SCHEME_UNDEFINED);}}

/* k3749 in get-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1333 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[217],lf[220]);}

/* k3695 in get-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_3686(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_3700(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1335 ##sys#error */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[217],lf[219]);}}

/* k3698 in k3695 in get-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub428(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3732,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1337 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_3703(2,t5,C_SCHEME_UNDEFINED);}}

/* k3730 in k3698 in k3695 in get-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1338 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[217],lf[218]);}

/* k3701 in k3698 in k3695 in get-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3708,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li85),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3708(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k3701 in k3698 in k3695 in get-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_3708(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3708,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3722,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1342 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3720 in loop in k3701 in k3698 in k3695 in get-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3722,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall f_3686(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub432(C_SCHEME_UNDEFINED,t2));}

/* group-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3600r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3600r(t0,t1,t2,t3);}}

static void C_ccall f_3600r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3604,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3604(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3604(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3602 in group-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3607,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_3607(t3,(C_word)C_getgrgid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[215]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3658,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1306 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3656 in k3602 in group-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3607(t2,(C_word)C_getgrnam(t1));}

/* k3605 in k3602 in group-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_3607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3607,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3615 in k3605 in k3602 in group-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3621,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k3619 in k3615 in k3605 in k3602 in group-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3625,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3630,a[2]=t4,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3630(t6,t2,C_fix(0));}

/* loop in k3619 in k3615 in k3605 in k3602 in group-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_3630(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3630,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3634,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub411(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k3632 in loop in k3619 in k3615 in k3605 in k3602 in group-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3634,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3644,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1315 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3630(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k3642 in k3632 in loop in k3619 in k3615 in k3605 in k3602 in group-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3644,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3623 in k3619 in k3615 in k3605 in k3602 in group-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[212]+1):*((C_word*)lf[213]+1));
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3583,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3587,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1291 current-effective-user-id */
t4=*((C_word*)lf[206]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3585 in current-effective-user-name in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1291 user-information */
t2=*((C_word*)lf[211]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3581 in current-effective-user-name in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3569,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3573,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1288 current-user-id */
t4=*((C_word*)lf[205]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3571 in current-user-name in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1288 user-information */
t2=*((C_word*)lf[211]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3567 in current-user-name in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* user-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3494r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3494r(t0,t1,t2,t3);}}

static void C_ccall f_3494r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3498,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3498(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3498(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3496 in user-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_3501(t3,(C_word)C_getpwuid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[211]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3540,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1276 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3538 in k3496 in user-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3501(t2,(C_word)C_getpwnam(t1));}

/* k3499 in k3496 in user-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_3501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3501,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3509 in k3499 in k3496 in user-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3515,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k3513 in k3509 in k3499 in k3496 in user-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3519,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k3517 in k3513 in k3509 in k3499 in k3496 in user-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3523,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k3521 in k3517 in k3513 in k3509 in k3499 in k3496 in user-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3527,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k3525 in k3521 in k3517 in k3513 in k3509 in k3499 in k3496 in user-information in k3490 in k3486 in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[212]+1):*((C_word*)lf[213]+1));
t3=t2;
((C_proc9)C_retrieve_proc(t3))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* set-group-id! in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3471,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3481,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1246 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3479 in set-group-id! in k3467 in k3463 in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1247 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[203],lf[208],((C_word*)t0)[2]);}

/* set-user-id! in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3448,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3458,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1226 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3456 in set-user-id! in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1227 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[203],lf[204],((C_word*)t0)[2]);}

/* system-information in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3414,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3443,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1215 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_3414(2,t3,C_SCHEME_UNDEFINED);}}

/* k3441 in system-information in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1216 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[200],lf[202]);}

/* k3412 in system-information in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k3419 in k3412 in system-information in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3425,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k3423 in k3419 in k3412 in system-information in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3429,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k3427 in k3423 in k3419 in k3412 in system-information in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3433,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k3431 in k3427 in k3423 in k3419 in k3412 in system-information in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3437,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[201]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k3435 in k3431 in k3427 in k3423 in k3419 in k3412 in system-information in k3406 in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3392,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[198]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1194 posix-error */
t5=lf[3];
f_1626(5,t5,t1,lf[192],lf[198],lf[199]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3377,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[196]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1188 posix-error */
t5=lf[3];
f_1626(5,t5,t1,lf[192],lf[196],lf[197]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3371,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[195]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3345,a[2]=t3,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3345(t5,t1,*((C_word*)lf[187]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_3345(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3345,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1178 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3315,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[191]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3322,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3333,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a3332 in set-signal-mask! in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3333,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[191]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k3320 in set-signal-mask! in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1171 posix-error */
t2=lf[3];
f_1626(5,t2,((C_word*)t0)[2],lf[192],lf[191],lf[193]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3297,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3307,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1157 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1159 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k3305 in ##sys#interrupt-hook in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1158 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3284,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[190]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k3271 in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3275,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[189]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3232,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1074 posix-error */
t3=lf[3];
f_1626(5,t3,t2,lf[48],lf[160],lf[161]);}
else{
t3=t2;
f_3232(2,t3,C_SCHEME_UNDEFINED);}}

/* k3230 in create-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1075 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3208r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3208r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3208r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[159]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3212,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k3210 in with-output-to-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
t2=C_mutate((C_word*)lf[159]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3218,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1062 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a3217 in k3210 in with-output-to-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3218r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3218r(t0,t1,t2);}}

static void C_ccall f_3218r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3222,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1064 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3220 in a3217 in k3210 in with-output-to-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[159]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3188r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3188r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3188r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[157]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3192,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k3190 in with-input-from-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3192,2,t0,t1);}
t2=C_mutate((C_word*)lf[157]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3198,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1052 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a3197 in k3190 in with-input-from-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3198r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3198r(t0,t1,t2);}}

static void C_ccall f_3198r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3202,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1054 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3200 in a3197 in k3190 in with-input-from-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[157]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3164r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3164r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3164r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3168,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k3166 in call-with-output-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3173,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3179,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1042 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3178 in k3166 in call-with-output-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3179r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3179r(t0,t1,t2);}}

static void C_ccall f_3179r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3183,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1045 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3181 in a3178 in k3166 in call-with-output-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3172 in k3166 in call-with-output-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3173,2,t0,t1);}
/* posixunix.scm: 1043 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3140r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3140r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3140r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3144,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k3142 in call-with-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3149,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3155,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1034 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3154 in k3142 in call-with-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3155r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3155r(t0,t1,t2);}}

static void C_ccall f_3155r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3159,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1037 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3157 in a3154 in k3142 in call-with-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3148 in k3142 in call-with-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3149,2,t0,t1);}
/* posixunix.scm: 1035 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3124,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3128,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1021 ##sys#check-port */
t4=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[149]);}

/* k3126 in close-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3128,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3131,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1023 posix-error */
t5=lf[3];
f_1626(6,t5,t3,lf[48],lf[150],lf[151],((C_word*)t0)[3]);}
else{
t5=t3;
f_3131(2,t5,C_SCHEME_UNDEFINED);}}

/* k3129 in k3126 in close-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3088(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3088r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3088r(t0,t1,t2,t3);}}

static void C_ccall f_3088r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[148]);
t5=f_3019(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3102,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[140]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3109,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1016 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[147]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3119,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1017 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1018 badmode */
f_3031(t6,t5);}}}

/* k3117 in open-output-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3119,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3102(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k3107 in open-output-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3102(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k3100 in open-output-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1012 check */
f_3037(((C_word*)t0)[3],lf[148],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3052r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3052r(t0,t1,t2,t3);}}

static void C_ccall f_3052r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[146]);
t5=f_3019(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3066,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[140]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3073,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1005 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[147]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3083,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1006 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1007 badmode */
f_3031(t6,t5);}}}

/* k3081 in open-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3083,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3066(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k3071 in open-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3066(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k3064 in open-input-pipe in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1001 check */
f_3037(((C_word*)t0)[3],lf[146],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_3037(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3037,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 993  posix-error */
t6=lf[3];
f_1626(6,t6,t1,lf[48],t2,lf[142],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3050,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 994  ##sys#make-port */
t7=*((C_word*)lf[143]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[144]+1),lf[145],lf[95]);}}

/* k3048 in check in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_3031(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3031,NULL,2,t1,t2);}
/* posixunix.scm: 990  ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[141],t2);}

/* mode in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall f_3019(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[140]));}

/* canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2702,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[124]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2709,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2823,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 938  cwd */
t8=((C_word*)t0)[6];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[12],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 940  sref */
t10=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_2829(t9,C_SCHEME_FALSE);}}}

/* k3007 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 940  sep? */
t2=((C_word*)t0)[3];
f_2829(t2,f_2691(t1));}

/* k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2829,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
f_2709(2,t2,((C_word*)t0)[10]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 943  cwd */
t5=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2984,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2995,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 944  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k2993 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 944  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k2982 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2984,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 945  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_2848(t2,C_SCHEME_FALSE);}}

/* k2989 in k2982 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 945  sep? */
t2=((C_word*)t0)[3];
f_2848(t2,f_2691(t1));}

/* k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2848(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2848,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 947  getenv */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[137]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 952  cwd */
t5=((C_word*)t0)[6];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2977,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 953  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(0));}}}

/* k2975 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 953  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2954 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2973,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 954  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_2892(t2,C_SCHEME_FALSE);}}

/* k2971 in k2954 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 954  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k2960 in k2954 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2969,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 955  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_2892(t2,C_SCHEME_FALSE);}}

/* k2967 in k2960 in k2954 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 955  sep? */
t2=((C_word*)t0)[3];
f_2892(t2,f_2691(t1));}

/* k2890 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2892,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
/* posixunix.scm: 956  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)t0)[9],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2905,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2953,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 957  sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[9],C_fix(0));}}

/* k2951 in k2890 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 957  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k2930 in k2890 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2932,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2949,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 958  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_2905(2,t2,C_SCHEME_FALSE);}}

/* k2947 in k2930 in k2890 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 958  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2936 in k2930 in k2890 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2938,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 959  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_2905(2,t2,C_SCHEME_FALSE);}}

/* k2943 in k2936 in k2930 in k2890 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 959  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k2903 in k2890 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2905,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
/* posixunix.scm: 960  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 961  sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],C_fix(0));}}

/* k2927 in k2903 in k2890 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2929,2,t0,t1);}
t2=f_2691(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_2709(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2925,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 964  cwd */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2923 in k2927 in k2903 in k2890 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 964  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[139],((C_word*)t0)[2]);}

/* k2884 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 952  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[138],((C_word*)t0)[2]);}

/* k2853 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2858(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2873,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 948  user */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2871 in k2853 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 948  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[136],t1);}

/* k2856 in k2853 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2862,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 949  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k2860 in k2856 in k2853 in k2846 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 946  sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2840 in k2827 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 943  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[135],((C_word*)t0)[2]);}

/* k2821 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 938  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[134]);}

/* k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=t1;
/* string-split */
t4=*((C_word*)lf[132]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,lf[133]);}

/* k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2716,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li47),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_2718(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2718(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2718,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 967  null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2723 in loop in k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 968  null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2786,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 979  string=? */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[131],t5);}}

/* k2787 in k2723 in loop in k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2789,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2786(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 981  string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[130],t3);}}

/* k2796 in k2787 in k2723 in loop in k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2798,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2786(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_2786(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k2784 in k2723 in loop in k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 977  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2718(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2729 in k2723 in loop in k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2731,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[125]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 970  sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k2765 in k2729 in k2723 in loop in k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2767,2,t0,t1);}
t2=f_2691(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2748,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[127],((C_word*)t0)[2]);
/* posixunix.scm: 973  reverse */
t6=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2759,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2763,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 976  reverse */
t5=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2761 in k2765 in k2729 in k2723 in loop in k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 976  isperse */
f_2686(((C_word*)t0)[2],t1);}

/* k2757 in k2765 in k2729 in k2723 in loop in k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 974  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[129],t1);}

/* k2746 in k2765 in k2729 in k2723 in loop in k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 973  isperse */
f_2686(((C_word*)t0)[2],t1);}

/* k2742 in k2765 in k2729 in k2723 in loop in k2714 in k2707 in canonical-path in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 971  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[126],t1);}

/* sep? in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall f_2691(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2686(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2686,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[120]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[121]);}

/* current-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2638r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2638r(t0,t1,t2);}}

static void C_ccall f_2638r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2642(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2642(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2640 in current-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 914  change-directory */
t2=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 915  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k2649 in k2640 in current-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 918  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 919  posix-error */
t3=lf[3];
f_1626(5,t3,((C_word*)t0)[2],lf[48],lf[112],lf[115]);}}

/* directory? in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2615,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[113]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2622,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2636,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 907  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2634 in directory? in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 907  ##sys#file-info */
t2=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2620 in directory? in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_2458r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2458r(t0,t1,t2);}}

static void C_ccall f_2458r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2558,a[2]=t3,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2563,a[2]=t4,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec210235 */
t6=t5;
f_2563(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?211233 */
t8=t4;
f_2558(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body208213 */
t10=t3;
f_2460(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec210 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2563(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2563,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2571,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 880  current-directory */
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2569 in def-spec210 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?211233 */
t2=((C_word*)t0)[3];
f_2558(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?211 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2558(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2558,NULL,3,t0,t1,t2);}
/* body208213 */
t3=((C_word*)t0)[2];
f_2460(t3,t1,t2,C_SCHEME_FALSE);}

/* body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2460(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2460,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[109]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 882  make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k2465 in body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 883  ##sys#make-pointer */
t3=*((C_word*)lf[111]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2468 in k2465 in body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 884  ##sys#make-pointer */
t3=*((C_word*)lf[111]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2471 in k2468 in k2465 in body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2557,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 885  ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k2555 in k2471 in k2468 in k2465 in body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 885  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2475 in k2471 in k2468 in k2465 in body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 887  posix-error */
t3=lf[3];
f_1626(6,t3,((C_word*)t0)[7],lf[48],lf[109],lf[110],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word)li38),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_2491(t6,((C_word*)t0)[7]);}}

/* loop in k2475 in k2471 in k2468 in k2465 in body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2491,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 895  ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k2499 in loop in k2475 in k2471 in k2468 in k2465 in body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 896  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_fix(0));}

/* k2502 in k2499 in loop in k2475 in k2471 in k2468 in k2465 in body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 897  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_2507(2,t3,C_SCHEME_FALSE);}}

/* k2505 in k2502 in k2499 in loop in k2475 in k2471 in k2468 in k2465 in body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_2513(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_2513(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_2513(t4,C_SCHEME_FALSE);}}

/* k2511 in k2505 in k2502 in k2499 in loop in k2475 in k2471 in k2468 in k2465 in body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2513,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 902  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2491(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 903  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2491(t3,t2);}}

/* k2521 in k2511 in k2505 in k2502 in k2499 in loop in k2475 in k2471 in k2468 in k2465 in body208 in directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2523,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2434,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[105]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2452,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2456,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 873  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2454 in delete-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 873  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2450 in delete-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 874  posix-error */
t3=lf[3];
f_1626(6,t3,((C_word*)t0)[3],lf[48],lf[105],lf[106],((C_word*)t0)[2]);}}

/* change-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2410,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2428,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2432,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 867  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2430 in change-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 867  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2426 in change-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 868  posix-error */
t3=lf[3];
f_1626(6,t3,((C_word*)t0)[3],lf[48],lf[103],lf[104],((C_word*)t0)[2]);}}

/* create-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2386,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[101]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2404,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2408,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 861  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2406 in create-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 861  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2402 in create-directory in k2382 in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 862  posix-error */
t3=lf[3];
f_1626(6,t3,((C_word*)t0)[3],lf[48],lf[101],lf[102],((C_word*)t0)[2]);}}

/* set-file-position! in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2324r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2324r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2324r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[93]);
t8=(C_word)C_i_check_exact_2(t6,lf[93]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2337,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 833  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[98],lf[93],lf[99],t3,t2);}
else{
t10=t9;
f_2337(2,t10,C_SCHEME_UNDEFINED);}}

/* k2335 in set-file-position! in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 834  port? */
t4=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k2347 in k2335 in set-file-position! in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[95]);
t4=((C_word*)t0)[4];
f_2343(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_2343(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 838  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[60],lf[93],lf[96],((C_word*)t0)[5]);}}}

/* k2341 in k2335 in set-file-position! in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 839  posix-error */
t2=lf[3];
f_1626(7,t2,((C_word*)t0)[4],lf[48],lf[93],lf[94],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* stat-socket? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2315,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[92]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2322,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 825  ##sys#stat */
f_2138(t4,t2,C_SCHEME_FALSE,lf[92]);}

/* k2320 in stat-socket? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* stat-symlink? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2306,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[91]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2313,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 820  ##sys#stat */
f_2138(t4,t2,C_SCHEME_TRUE,lf[91]);}

/* k2311 in stat-symlink? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* stat-fifo? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2297,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2304,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 815  ##sys#stat */
f_2138(t4,t2,C_SCHEME_FALSE,lf[90]);}

/* k2302 in stat-fifo? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* stat-block-device? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2288,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2295,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 810  ##sys#stat */
f_2138(t4,t2,C_SCHEME_FALSE,lf[89]);}

/* k2293 in stat-block-device? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* stat-char-device? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2279,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2286,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 805  ##sys#stat */
f_2138(t4,t2,C_SCHEME_FALSE,lf[88]);}

/* k2284 in stat-char-device? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2270,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2277,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 800  ##sys#stat */
f_2138(t4,t2,C_SCHEME_FALSE,lf[87]);}

/* k2275 in stat-directory? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2261,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 795  ##sys#stat */
f_2138(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k2266 in stat-regular? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2252,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2259,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 790  ##sys#stat */
f_2138(t4,t2,C_SCHEME_TRUE,lf[85]);}

/* k2257 in symbolic-link? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2243,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2250,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 785  ##sys#stat */
f_2138(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k2248 in regular-file? in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2237,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2241,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 781  ##sys#stat */
f_2138(t3,t2,C_SCHEME_FALSE,lf[83]);}

/* k2239 in file-permissions in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2231,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2235,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 780  ##sys#stat */
f_2138(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k2233 in file-owner in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2225,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2229,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#stat */
f_2138(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k2227 in file-change-time in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2219,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2223,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 778  ##sys#stat */
f_2138(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k2221 in file-access-time in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2223,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2213,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2217,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 777  ##sys#stat */
f_2138(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k2215 in file-modification-time in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2217,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2207,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2211,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 776  ##sys#stat */
f_2138(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k2209 in file-size in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2211,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2175r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2175r(t0,t1,t2,t3);}}

static void C_ccall f_2175r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2179,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2186,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_2186(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2186(2,t7,(C_word)C_i_car(t3));}
else{
/* posixunix.scm: 769  ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k2184 in file-stat in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 769  ##sys#stat */
f_2138(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[77]);}

/* k2177 in file-stat in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2179,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2138(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2138,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2142,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_2142(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2163,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2170,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 760  ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 764  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[76],t2);}}}

/* k2168 in ##sys#stat in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 760  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2161 in ##sys#stat in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2142(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k2140 in ##sys#stat in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 766  posix-error */
t2=lf[3];
f_1626(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[75],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1946r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1946r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1946r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_1920(C_fix(0));
t10=f_1920(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_1962(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 689  fd_set */
t14=t12;
f_1962(2,t14,f_1926(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[68]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t15=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a2118 in file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2119,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 696  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1926(C_fix(0),t2));}

/* k1960 in file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_1968(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 701  fd_set */
t5=t3;
f_1968(2,t5,f_1926(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[68]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a2092 in k1960 in file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2093,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 708  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1926(C_fix(1),t2));}

/* k1966 in k1960 in file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[68]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_1971(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_1971(t4,(C_word)C_C_select(t3));}}

/* k1969 in k1966 in k1960 in file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_1971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1971,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 715  posix-error */
t2=lf[3];
f_1626(7,t2,((C_word*)t0)[5],lf[48],lf[68],lf[69],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 716  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 721  fd_test */
t4=t3;
f_2010(t4,f_1936(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2051,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2053,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_2010(t4,C_SCHEME_FALSE);}}}}

/* a2052 in k1969 in k1966 in k1960 in file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2053,3,t0,t1,t2);}
t3=f_1936(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2049 in k1969 in k1966 in k1960 in file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2010(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2008 in k1969 in k1966 in k1960 in file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2010,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 727  fd_test */
t3=t2;
f_2014(t3,f_1936(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2026,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2028,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_2014(t3,C_SCHEME_FALSE);}}

/* a2027 in k2008 in k1969 in k1966 in k1960 in file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2028,3,t0,t1,t2);}
t3=f_1936(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2024 in k2008 in k1969 in k1966 in k1960 in file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2014(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2012 in k2008 in k1969 in k1966 in k1960 in file-select in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_fcall f_2014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 718  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall f_1936(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub92(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_set in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall f_1926(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub86(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_zero in k1612 in k1609 in k1606 in k1603 in k1600 */
static C_word C_fcall f_1920(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub81(C_SCHEME_UNDEFINED,t2));}

/* file-mkstemp in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1888,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[65]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1895,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 667  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1893 in file-mkstemp in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1901,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 671  posix-error */
t6=lf[3];
f_1626(6,t6,t4,lf[48],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t6=t4;
f_1901(2,t6,C_SCHEME_UNDEFINED);}}

/* k1899 in k1893 in file-mkstemp in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 672  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1906 in k1899 in k1893 in file-mkstemp in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 672  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1849r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1849r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1849r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[62]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1856,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1856(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 656  ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[60],lf[62],lf[64],t3);}}

/* k1854 in file-write in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[62]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1865,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 661  posix-error */
t8=lf[3];
f_1626(7,t8,t6,lf[48],lf[62],lf[63],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_1865(2,t8,C_SCHEME_UNDEFINED);}}

/* k1863 in k1854 in file-write in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1807r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1807r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1807r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1817,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1817(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixunix.scm: 644  make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k1815 in file-read in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1820(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 646  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[60],lf[58],lf[61],t1);}}

/* k1818 in k1815 in file-read in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1823,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 649  posix-error */
t5=lf[3];
f_1626(7,t5,t3,lf[48],lf[58],lf[59],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_1823(2,t5,C_SCHEME_UNDEFINED);}}

/* k1821 in k1818 in k1815 in file-read in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1823,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1792,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[55]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 637  posix-error */
t4=lf[3];
f_1626(6,t4,t1,lf[48],lf[55],lf[56],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1754r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1754r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1754r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[51]);
t8=(C_word)C_i_check_exact_2(t3,lf[51]);
t9=(C_word)C_i_check_exact_2(t6,lf[51]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1771,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 628  ##sys#expand-home-path */
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k1782 in file-open in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 628  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1769 in file-open in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1771,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1774,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 630  posix-error */
t5=lf[3];
f_1626(8,t5,t3,lf[48],lf[51],lf[52],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_1774(2,t5,C_SCHEME_UNDEFINED);}}

/* k1772 in k1769 in file-open in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1708r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1708r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1708r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1712,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1712(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1712(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1710 in file-control in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[47]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[47]);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_integer_argumentp(t1);
t9=(C_word)stub24(C_SCHEME_UNDEFINED,t6,t7,t8);
t10=(C_word)C_eqp(t9,C_fix(-1));
if(C_truep(t10)){
/* posixunix.scm: 618  posix-error */
t11=lf[3];
f_1626(7,t11,((C_word*)t0)[2],lf[48],lf[47],lf[49],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t9);}}

/* ##sys#file-select-one in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1651,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub17(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-nonblocking! in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1644,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub13(C_SCHEME_UNDEFINED,t3));}

/* posix-error in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1626r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1626r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1626r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1630,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 508  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1628 in posix-error in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1641,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub3(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k1639 in k1628 in posix-error in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 509  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k1635 in k1628 in posix-error in k1612 in k1609 in k1606 in k1603 in k1600 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[598] = {
{"toplevelposixunix.scm",(void*)C_posix_toplevel},
{"f_1602posixunix.scm",(void*)f_1602},
{"f_1605posixunix.scm",(void*)f_1605},
{"f_1608posixunix.scm",(void*)f_1608},
{"f_1611posixunix.scm",(void*)f_1611},
{"f_1614posixunix.scm",(void*)f_1614},
{"f_7373posixunix.scm",(void*)f_7373},
{"f_7389posixunix.scm",(void*)f_7389},
{"f_7377posixunix.scm",(void*)f_7377},
{"f_7380posixunix.scm",(void*)f_7380},
{"f_2384posixunix.scm",(void*)f_2384},
{"f_3273posixunix.scm",(void*)f_3273},
{"f_7367posixunix.scm",(void*)f_7367},
{"f_3408posixunix.scm",(void*)f_3408},
{"f_7364posixunix.scm",(void*)f_7364},
{"f_3465posixunix.scm",(void*)f_3465},
{"f_7349posixunix.scm",(void*)f_7349},
{"f_7359posixunix.scm",(void*)f_7359},
{"f_7346posixunix.scm",(void*)f_7346},
{"f_3469posixunix.scm",(void*)f_3469},
{"f_7343posixunix.scm",(void*)f_7343},
{"f_3488posixunix.scm",(void*)f_3488},
{"f_7328posixunix.scm",(void*)f_7328},
{"f_7338posixunix.scm",(void*)f_7338},
{"f_7325posixunix.scm",(void*)f_7325},
{"f_3492posixunix.scm",(void*)f_3492},
{"f_7307posixunix.scm",(void*)f_7307},
{"f_7320posixunix.scm",(void*)f_7320},
{"f_7314posixunix.scm",(void*)f_7314},
{"f_4031posixunix.scm",(void*)f_4031},
{"f_4070posixunix.scm",(void*)f_4070},
{"f_7284posixunix.scm",(void*)f_7284},
{"f_7276posixunix.scm",(void*)f_7276},
{"f_7019posixunix.scm",(void*)f_7019},
{"f_7202posixunix.scm",(void*)f_7202},
{"f_7208posixunix.scm",(void*)f_7208},
{"f_7197posixunix.scm",(void*)f_7197},
{"f_7192posixunix.scm",(void*)f_7192},
{"f_7021posixunix.scm",(void*)f_7021},
{"f_7179posixunix.scm",(void*)f_7179},
{"f_7187posixunix.scm",(void*)f_7187},
{"f_7028posixunix.scm",(void*)f_7028},
{"f_7167posixunix.scm",(void*)f_7167},
{"f_7161posixunix.scm",(void*)f_7161},
{"f_7038posixunix.scm",(void*)f_7038},
{"f_7040posixunix.scm",(void*)f_7040},
{"f_7059posixunix.scm",(void*)f_7059},
{"f_7147posixunix.scm",(void*)f_7147},
{"f_7154posixunix.scm",(void*)f_7154},
{"f_7141posixunix.scm",(void*)f_7141},
{"f_7074posixunix.scm",(void*)f_7074},
{"f_7134posixunix.scm",(void*)f_7134},
{"f_7131posixunix.scm",(void*)f_7131},
{"f_7118posixunix.scm",(void*)f_7118},
{"f_7094posixunix.scm",(void*)f_7094},
{"f_7116posixunix.scm",(void*)f_7116},
{"f_7102posixunix.scm",(void*)f_7102},
{"f_7109posixunix.scm",(void*)f_7109},
{"f_7106posixunix.scm",(void*)f_7106},
{"f_7086posixunix.scm",(void*)f_7086},
{"f_7084posixunix.scm",(void*)f_7084},
{"f_7168posixunix.scm",(void*)f_7168},
{"f_6959posixunix.scm",(void*)f_6959},
{"f_6971posixunix.scm",(void*)f_6971},
{"f_6966posixunix.scm",(void*)f_6966},
{"f_6961posixunix.scm",(void*)f_6961},
{"f_6899posixunix.scm",(void*)f_6899},
{"f_6911posixunix.scm",(void*)f_6911},
{"f_6906posixunix.scm",(void*)f_6906},
{"f_6901posixunix.scm",(void*)f_6901},
{"f_6838posixunix.scm",(void*)f_6838},
{"f_6893posixunix.scm",(void*)f_6893},
{"f_6897posixunix.scm",(void*)f_6897},
{"f_6859posixunix.scm",(void*)f_6859},
{"f_6862posixunix.scm",(void*)f_6862},
{"f_6873posixunix.scm",(void*)f_6873},
{"f_6867posixunix.scm",(void*)f_6867},
{"f_6840posixunix.scm",(void*)f_6840},
{"f_6849posixunix.scm",(void*)f_6849},
{"f_6774posixunix.scm",(void*)f_6774},
{"f_6786posixunix.scm",(void*)f_6786},
{"f_6817posixunix.scm",(void*)f_6817},
{"f_6797posixunix.scm",(void*)f_6797},
{"f_6813posixunix.scm",(void*)f_6813},
{"f_6801posixunix.scm",(void*)f_6801},
{"f_6809posixunix.scm",(void*)f_6809},
{"f_6805posixunix.scm",(void*)f_6805},
{"f_6780posixunix.scm",(void*)f_6780},
{"f_6763posixunix.scm",(void*)f_6763},
{"f_6767posixunix.scm",(void*)f_6767},
{"f_6752posixunix.scm",(void*)f_6752},
{"f_6756posixunix.scm",(void*)f_6756},
{"f_6707posixunix.scm",(void*)f_6707},
{"f_6711posixunix.scm",(void*)f_6711},
{"f_6714posixunix.scm",(void*)f_6714},
{"f_6717posixunix.scm",(void*)f_6717},
{"f_6730posixunix.scm",(void*)f_6730},
{"f_6734posixunix.scm",(void*)f_6734},
{"f_6737posixunix.scm",(void*)f_6737},
{"f_6740posixunix.scm",(void*)f_6740},
{"f_6728posixunix.scm",(void*)f_6728},
{"f_6691posixunix.scm",(void*)f_6691},
{"f_6674posixunix.scm",(void*)f_6674},
{"f_6687posixunix.scm",(void*)f_6687},
{"f_6599posixunix.scm",(void*)f_6599},
{"f_6660posixunix.scm",(void*)f_6660},
{"f_6673posixunix.scm",(void*)f_6673},
{"f_6640posixunix.scm",(void*)f_6640},
{"f_6655posixunix.scm",(void*)f_6655},
{"f_6649posixunix.scm",(void*)f_6649},
{"f_6603posixunix.scm",(void*)f_6603},
{"f_6605posixunix.scm",(void*)f_6605},
{"f_6626posixunix.scm",(void*)f_6626},
{"f_6620posixunix.scm",(void*)f_6620},
{"f_6547posixunix.scm",(void*)f_6547},
{"f_6554posixunix.scm",(void*)f_6554},
{"f_6573posixunix.scm",(void*)f_6573},
{"f_6577posixunix.scm",(void*)f_6577},
{"f_6541posixunix.scm",(void*)f_6541},
{"f_6532posixunix.scm",(void*)f_6532},
{"f_6536posixunix.scm",(void*)f_6536},
{"f_6505posixunix.scm",(void*)f_6505},
{"f_6498posixunix.scm",(void*)f_6498},
{"f_6495posixunix.scm",(void*)f_6495},
{"f_6492posixunix.scm",(void*)f_6492},
{"f_6414posixunix.scm",(void*)f_6414},
{"f_6450posixunix.scm",(void*)f_6450},
{"f_6444posixunix.scm",(void*)f_6444},
{"f_6397posixunix.scm",(void*)f_6397},
{"f_6215posixunix.scm",(void*)f_6215},
{"f_6349posixunix.scm",(void*)f_6349},
{"f_6344posixunix.scm",(void*)f_6344},
{"f_6217posixunix.scm",(void*)f_6217},
{"f_6227posixunix.scm",(void*)f_6227},
{"f_6235posixunix.scm",(void*)f_6235},
{"f_6281posixunix.scm",(void*)f_6281},
{"f_6248posixunix.scm",(void*)f_6248},
{"f_6273posixunix.scm",(void*)f_6273},
{"f_6251posixunix.scm",(void*)f_6251},
{"f_6196posixunix.scm",(void*)f_6196},
{"f_6177posixunix.scm",(void*)f_6177},
{"f_6135posixunix.scm",(void*)f_6135},
{"f_6157posixunix.scm",(void*)f_6157},
{"f_6161posixunix.scm",(void*)f_6161},
{"f_6023posixunix.scm",(void*)f_6023},
{"f_6029posixunix.scm",(void*)f_6029},
{"f_6050posixunix.scm",(void*)f_6050},
{"f_6127posixunix.scm",(void*)f_6127},
{"f_6054posixunix.scm",(void*)f_6054},
{"f_6057posixunix.scm",(void*)f_6057},
{"f_6060posixunix.scm",(void*)f_6060},
{"f_6067posixunix.scm",(void*)f_6067},
{"f_6069posixunix.scm",(void*)f_6069},
{"f_6086posixunix.scm",(void*)f_6086},
{"f_6096posixunix.scm",(void*)f_6096},
{"f_6100posixunix.scm",(void*)f_6100},
{"f_6044posixunix.scm",(void*)f_6044},
{"f_6011posixunix.scm",(void*)f_6011},
{"f_6015posixunix.scm",(void*)f_6015},
{"f_6018posixunix.scm",(void*)f_6018},
{"f_5976posixunix.scm",(void*)f_5976},
{"f_5980posixunix.scm",(void*)f_5980},
{"f_6000posixunix.scm",(void*)f_6000},
{"f_6004posixunix.scm",(void*)f_6004},
{"f_5953posixunix.scm",(void*)f_5953},
{"f_5957posixunix.scm",(void*)f_5957},
{"f_5921posixunix.scm",(void*)f_5921},
{"f_5925posixunix.scm",(void*)f_5925},
{"f_5902posixunix.scm",(void*)f_5902},
{"f_5906posixunix.scm",(void*)f_5906},
{"f_5909posixunix.scm",(void*)f_5909},
{"f_5843posixunix.scm",(void*)f_5843},
{"f_5847posixunix.scm",(void*)f_5847},
{"f_5853posixunix.scm",(void*)f_5853},
{"f_5836posixunix.scm",(void*)f_5836},
{"f_5820posixunix.scm",(void*)f_5820},
{"f_5808posixunix.scm",(void*)f_5808},
{"f_5780posixunix.scm",(void*)f_5780},
{"f_5787posixunix.scm",(void*)f_5787},
{"f_5752posixunix.scm",(void*)f_5752},
{"f_5759posixunix.scm",(void*)f_5759},
{"f_5706posixunix.scm",(void*)f_5706},
{"f_5710posixunix.scm",(void*)f_5710},
{"f_5723posixunix.scm",(void*)f_5723},
{"f_5727posixunix.scm",(void*)f_5727},
{"f_5624posixunix.scm",(void*)f_5624},
{"f_5628posixunix.scm",(void*)f_5628},
{"f_5634posixunix.scm",(void*)f_5634},
{"f_5656posixunix.scm",(void*)f_5656},
{"f_5653posixunix.scm",(void*)f_5653},
{"f_5643posixunix.scm",(void*)f_5643},
{"f_5591posixunix.scm",(void*)f_5591},
{"f_5595posixunix.scm",(void*)f_5595},
{"f_5572posixunix.scm",(void*)f_5572},
{"f_5563posixunix.scm",(void*)f_5563},
{"f_5557posixunix.scm",(void*)f_5557},
{"f_5548posixunix.scm",(void*)f_5548},
{"f_5513posixunix.scm",(void*)f_5513},
{"f_5451posixunix.scm",(void*)f_5451},
{"f_5455posixunix.scm",(void*)f_5455},
{"f_5461posixunix.scm",(void*)f_5461},
{"f_5480posixunix.scm",(void*)f_5480},
{"f_5467posixunix.scm",(void*)f_5467},
{"f_5348posixunix.scm",(void*)f_5348},
{"f_5354posixunix.scm",(void*)f_5354},
{"f_5358posixunix.scm",(void*)f_5358},
{"f_5366posixunix.scm",(void*)f_5366},
{"f_5392posixunix.scm",(void*)f_5392},
{"f_5396posixunix.scm",(void*)f_5396},
{"f_5384posixunix.scm",(void*)f_5384},
{"f_5328posixunix.scm",(void*)f_5328},
{"f_5336posixunix.scm",(void*)f_5336},
{"f_5311posixunix.scm",(void*)f_5311},
{"f_5322posixunix.scm",(void*)f_5322},
{"f_5326posixunix.scm",(void*)f_5326},
{"f_5285posixunix.scm",(void*)f_5285},
{"f_5309posixunix.scm",(void*)f_5309},
{"f_5292posixunix.scm",(void*)f_5292},
{"f_5242posixunix.scm",(void*)f_5242},
{"f_5249posixunix.scm",(void*)f_5249},
{"f_5270posixunix.scm",(void*)f_5270},
{"f_5266posixunix.scm",(void*)f_5266},
{"f_5214posixunix.scm",(void*)f_5214},
{"f_5192posixunix.scm",(void*)f_5192},
{"f_5196posixunix.scm",(void*)f_5196},
{"f_5177posixunix.scm",(void*)f_5177},
{"f_5181posixunix.scm",(void*)f_5181},
{"f_5162posixunix.scm",(void*)f_5162},
{"f_5166posixunix.scm",(void*)f_5166},
{"f_5144posixunix.scm",(void*)f_5144},
{"f_5070posixunix.scm",(void*)f_5070},
{"f_5092posixunix.scm",(void*)f_5092},
{"f_5098posixunix.scm",(void*)f_5098},
{"f_5031posixunix.scm",(void*)f_5031},
{"f_5059posixunix.scm",(void*)f_5059},
{"f_5055posixunix.scm",(void*)f_5055},
{"f_5048posixunix.scm",(void*)f_5048},
{"f_4772posixunix.scm",(void*)f_4772},
{"f_4968posixunix.scm",(void*)f_4968},
{"f_4963posixunix.scm",(void*)f_4963},
{"f_4958posixunix.scm",(void*)f_4958},
{"f_4774posixunix.scm",(void*)f_4774},
{"f_4778posixunix.scm",(void*)f_4778},
{"f_4884posixunix.scm",(void*)f_4884},
{"f_4885posixunix.scm",(void*)f_4885},
{"f_4902posixunix.scm",(void*)f_4902},
{"f_4912posixunix.scm",(void*)f_4912},
{"f_4870posixunix.scm",(void*)f_4870},
{"f_4826posixunix.scm",(void*)f_4826},
{"f_4862posixunix.scm",(void*)f_4862},
{"f_4841posixunix.scm",(void*)f_4841},
{"f_4851posixunix.scm",(void*)f_4851},
{"f_4835posixunix.scm",(void*)f_4835},
{"f_4830posixunix.scm",(void*)f_4830},
{"f_4833posixunix.scm",(void*)f_4833},
{"f_4780posixunix.scm",(void*)f_4780},
{"f_4815posixunix.scm",(void*)f_4815},
{"f_4796posixunix.scm",(void*)f_4796},
{"f_4298posixunix.scm",(void*)f_4298},
{"f_4694posixunix.scm",(void*)f_4694},
{"f_4689posixunix.scm",(void*)f_4689},
{"f_4684posixunix.scm",(void*)f_4684},
{"f_4679posixunix.scm",(void*)f_4679},
{"f_4300posixunix.scm",(void*)f_4300},
{"f_4304posixunix.scm",(void*)f_4304},
{"f_4310posixunix.scm",(void*)f_4310},
{"f_4552posixunix.scm",(void*)f_4552},
{"f_4558posixunix.scm",(void*)f_4558},
{"f_4654posixunix.scm",(void*)f_4654},
{"f_4644posixunix.scm",(void*)f_4644},
{"f_4638posixunix.scm",(void*)f_4638},
{"f_4560posixunix.scm",(void*)f_4560},
{"f_4610posixunix.scm",(void*)f_4610},
{"f_4567posixunix.scm",(void*)f_4567},
{"f_4577posixunix.scm",(void*)f_4577},
{"f_4476posixunix.scm",(void*)f_4476},
{"f_4484posixunix.scm",(void*)f_4484},
{"f_4486posixunix.scm",(void*)f_4486},
{"f_4534posixunix.scm",(void*)f_4534},
{"f_4467posixunix.scm",(void*)f_4467},
{"f_4471posixunix.scm",(void*)f_4471},
{"f_4446posixunix.scm",(void*)f_4446},
{"f_4456posixunix.scm",(void*)f_4456},
{"f_4434posixunix.scm",(void*)f_4434},
{"f_4421posixunix.scm",(void*)f_4421},
{"f_4425posixunix.scm",(void*)f_4425},
{"f_4416posixunix.scm",(void*)f_4416},
{"f_4419posixunix.scm",(void*)f_4419},
{"f_4334posixunix.scm",(void*)f_4334},
{"f_4346posixunix.scm",(void*)f_4346},
{"f_4383posixunix.scm",(void*)f_4383},
{"f_4392posixunix.scm",(void*)f_4392},
{"f_4386posixunix.scm",(void*)f_4386},
{"f_4362posixunix.scm",(void*)f_4362},
{"f_4365posixunix.scm",(void*)f_4365},
{"f_4326posixunix.scm",(void*)f_4326},
{"f_4311posixunix.scm",(void*)f_4311},
{"f_4325posixunix.scm",(void*)f_4325},
{"f_4271posixunix.scm",(void*)f_4271},
{"f_4278posixunix.scm",(void*)f_4278},
{"f_4281posixunix.scm",(void*)f_4281},
{"f_4226posixunix.scm",(void*)f_4226},
{"f_4230posixunix.scm",(void*)f_4230},
{"f_4265posixunix.scm",(void*)f_4265},
{"f_4248posixunix.scm",(void*)f_4248},
{"f_4212posixunix.scm",(void*)f_4212},
{"f_4224posixunix.scm",(void*)f_4224},
{"f_4198posixunix.scm",(void*)f_4198},
{"f_4210posixunix.scm",(void*)f_4210},
{"f_4183posixunix.scm",(void*)f_4183},
{"f_4196posixunix.scm",(void*)f_4196},
{"f_4146posixunix.scm",(void*)f_4146},
{"f_4154posixunix.scm",(void*)f_4154},
{"f_4121posixunix.scm",(void*)f_4121},
{"f_4102posixunix.scm",(void*)f_4102},
{"f_4106posixunix.scm",(void*)f_4106},
{"f_4071posixunix.scm",(void*)f_4071},
{"f_4095posixunix.scm",(void*)f_4095},
{"f_4079posixunix.scm",(void*)f_4079},
{"f_4082posixunix.scm",(void*)f_4082},
{"f_4033posixunix.scm",(void*)f_4033},
{"f_4066posixunix.scm",(void*)f_4066},
{"f_4054posixunix.scm",(void*)f_4054},
{"f_4062posixunix.scm",(void*)f_4062},
{"f_4058posixunix.scm",(void*)f_4058},
{"f_4008posixunix.scm",(void*)f_4008},
{"f_4024posixunix.scm",(void*)f_4024},
{"f_3993posixunix.scm",(void*)f_3993},
{"f_4003posixunix.scm",(void*)f_4003},
{"f_3997posixunix.scm",(void*)f_3997},
{"f_3987posixunix.scm",(void*)f_3987},
{"f_3981posixunix.scm",(void*)f_3981},
{"f_3975posixunix.scm",(void*)f_3975},
{"f_3951posixunix.scm",(void*)f_3951},
{"f_3973posixunix.scm",(void*)f_3973},
{"f_3969posixunix.scm",(void*)f_3969},
{"f_3961posixunix.scm",(void*)f_3961},
{"f_3921posixunix.scm",(void*)f_3921},
{"f_3949posixunix.scm",(void*)f_3949},
{"f_3945posixunix.scm",(void*)f_3945},
{"f_3894posixunix.scm",(void*)f_3894},
{"f_3919posixunix.scm",(void*)f_3919},
{"f_3915posixunix.scm",(void*)f_3915},
{"f_3830posixunix.scm",(void*)f_3830},
{"f_3818posixunix.scm",(void*)f_3818},
{"f_3846posixunix.scm",(void*)f_3846},
{"f_3756posixunix.scm",(void*)f_3756},
{"f_3760posixunix.scm",(void*)f_3760},
{"f_3765posixunix.scm",(void*)f_3765},
{"f_3781posixunix.scm",(void*)f_3781},
{"f_3693posixunix.scm",(void*)f_3693},
{"f_3751posixunix.scm",(void*)f_3751},
{"f_3697posixunix.scm",(void*)f_3697},
{"f_3700posixunix.scm",(void*)f_3700},
{"f_3732posixunix.scm",(void*)f_3732},
{"f_3703posixunix.scm",(void*)f_3703},
{"f_3708posixunix.scm",(void*)f_3708},
{"f_3722posixunix.scm",(void*)f_3722},
{"f_3686posixunix.scm",(void*)f_3686},
{"f_3600posixunix.scm",(void*)f_3600},
{"f_3604posixunix.scm",(void*)f_3604},
{"f_3658posixunix.scm",(void*)f_3658},
{"f_3607posixunix.scm",(void*)f_3607},
{"f_3617posixunix.scm",(void*)f_3617},
{"f_3621posixunix.scm",(void*)f_3621},
{"f_3630posixunix.scm",(void*)f_3630},
{"f_3634posixunix.scm",(void*)f_3634},
{"f_3644posixunix.scm",(void*)f_3644},
{"f_3625posixunix.scm",(void*)f_3625},
{"f_3575posixunix.scm",(void*)f_3575},
{"f_3587posixunix.scm",(void*)f_3587},
{"f_3583posixunix.scm",(void*)f_3583},
{"f_3561posixunix.scm",(void*)f_3561},
{"f_3573posixunix.scm",(void*)f_3573},
{"f_3569posixunix.scm",(void*)f_3569},
{"f_3494posixunix.scm",(void*)f_3494},
{"f_3498posixunix.scm",(void*)f_3498},
{"f_3540posixunix.scm",(void*)f_3540},
{"f_3501posixunix.scm",(void*)f_3501},
{"f_3511posixunix.scm",(void*)f_3511},
{"f_3515posixunix.scm",(void*)f_3515},
{"f_3519posixunix.scm",(void*)f_3519},
{"f_3523posixunix.scm",(void*)f_3523},
{"f_3527posixunix.scm",(void*)f_3527},
{"f_3471posixunix.scm",(void*)f_3471},
{"f_3481posixunix.scm",(void*)f_3481},
{"f_3448posixunix.scm",(void*)f_3448},
{"f_3458posixunix.scm",(void*)f_3458},
{"f_3410posixunix.scm",(void*)f_3410},
{"f_3443posixunix.scm",(void*)f_3443},
{"f_3414posixunix.scm",(void*)f_3414},
{"f_3421posixunix.scm",(void*)f_3421},
{"f_3425posixunix.scm",(void*)f_3425},
{"f_3429posixunix.scm",(void*)f_3429},
{"f_3433posixunix.scm",(void*)f_3433},
{"f_3437posixunix.scm",(void*)f_3437},
{"f_3392posixunix.scm",(void*)f_3392},
{"f_3377posixunix.scm",(void*)f_3377},
{"f_3371posixunix.scm",(void*)f_3371},
{"f_3339posixunix.scm",(void*)f_3339},
{"f_3345posixunix.scm",(void*)f_3345},
{"f_3315posixunix.scm",(void*)f_3315},
{"f_3333posixunix.scm",(void*)f_3333},
{"f_3322posixunix.scm",(void*)f_3322},
{"f_3297posixunix.scm",(void*)f_3297},
{"f_3307posixunix.scm",(void*)f_3307},
{"f_3284posixunix.scm",(void*)f_3284},
{"f_3275posixunix.scm",(void*)f_3275},
{"f_3228posixunix.scm",(void*)f_3228},
{"f_3232posixunix.scm",(void*)f_3232},
{"f_3208posixunix.scm",(void*)f_3208},
{"f_3212posixunix.scm",(void*)f_3212},
{"f_3218posixunix.scm",(void*)f_3218},
{"f_3222posixunix.scm",(void*)f_3222},
{"f_3188posixunix.scm",(void*)f_3188},
{"f_3192posixunix.scm",(void*)f_3192},
{"f_3198posixunix.scm",(void*)f_3198},
{"f_3202posixunix.scm",(void*)f_3202},
{"f_3164posixunix.scm",(void*)f_3164},
{"f_3168posixunix.scm",(void*)f_3168},
{"f_3179posixunix.scm",(void*)f_3179},
{"f_3183posixunix.scm",(void*)f_3183},
{"f_3173posixunix.scm",(void*)f_3173},
{"f_3140posixunix.scm",(void*)f_3140},
{"f_3144posixunix.scm",(void*)f_3144},
{"f_3155posixunix.scm",(void*)f_3155},
{"f_3159posixunix.scm",(void*)f_3159},
{"f_3149posixunix.scm",(void*)f_3149},
{"f_3124posixunix.scm",(void*)f_3124},
{"f_3128posixunix.scm",(void*)f_3128},
{"f_3131posixunix.scm",(void*)f_3131},
{"f_3088posixunix.scm",(void*)f_3088},
{"f_3119posixunix.scm",(void*)f_3119},
{"f_3109posixunix.scm",(void*)f_3109},
{"f_3102posixunix.scm",(void*)f_3102},
{"f_3052posixunix.scm",(void*)f_3052},
{"f_3083posixunix.scm",(void*)f_3083},
{"f_3073posixunix.scm",(void*)f_3073},
{"f_3066posixunix.scm",(void*)f_3066},
{"f_3037posixunix.scm",(void*)f_3037},
{"f_3050posixunix.scm",(void*)f_3050},
{"f_3031posixunix.scm",(void*)f_3031},
{"f_3019posixunix.scm",(void*)f_3019},
{"f_2702posixunix.scm",(void*)f_2702},
{"f_3009posixunix.scm",(void*)f_3009},
{"f_2829posixunix.scm",(void*)f_2829},
{"f_2995posixunix.scm",(void*)f_2995},
{"f_2984posixunix.scm",(void*)f_2984},
{"f_2991posixunix.scm",(void*)f_2991},
{"f_2848posixunix.scm",(void*)f_2848},
{"f_2977posixunix.scm",(void*)f_2977},
{"f_2956posixunix.scm",(void*)f_2956},
{"f_2973posixunix.scm",(void*)f_2973},
{"f_2962posixunix.scm",(void*)f_2962},
{"f_2969posixunix.scm",(void*)f_2969},
{"f_2892posixunix.scm",(void*)f_2892},
{"f_2953posixunix.scm",(void*)f_2953},
{"f_2932posixunix.scm",(void*)f_2932},
{"f_2949posixunix.scm",(void*)f_2949},
{"f_2938posixunix.scm",(void*)f_2938},
{"f_2945posixunix.scm",(void*)f_2945},
{"f_2905posixunix.scm",(void*)f_2905},
{"f_2929posixunix.scm",(void*)f_2929},
{"f_2925posixunix.scm",(void*)f_2925},
{"f_2886posixunix.scm",(void*)f_2886},
{"f_2855posixunix.scm",(void*)f_2855},
{"f_2873posixunix.scm",(void*)f_2873},
{"f_2858posixunix.scm",(void*)f_2858},
{"f_2862posixunix.scm",(void*)f_2862},
{"f_2842posixunix.scm",(void*)f_2842},
{"f_2823posixunix.scm",(void*)f_2823},
{"f_2709posixunix.scm",(void*)f_2709},
{"f_2716posixunix.scm",(void*)f_2716},
{"f_2718posixunix.scm",(void*)f_2718},
{"f_2725posixunix.scm",(void*)f_2725},
{"f_2789posixunix.scm",(void*)f_2789},
{"f_2798posixunix.scm",(void*)f_2798},
{"f_2786posixunix.scm",(void*)f_2786},
{"f_2731posixunix.scm",(void*)f_2731},
{"f_2767posixunix.scm",(void*)f_2767},
{"f_2763posixunix.scm",(void*)f_2763},
{"f_2759posixunix.scm",(void*)f_2759},
{"f_2748posixunix.scm",(void*)f_2748},
{"f_2744posixunix.scm",(void*)f_2744},
{"f_2691posixunix.scm",(void*)f_2691},
{"f_2686posixunix.scm",(void*)f_2686},
{"f_2638posixunix.scm",(void*)f_2638},
{"f_2642posixunix.scm",(void*)f_2642},
{"f_2651posixunix.scm",(void*)f_2651},
{"f_2615posixunix.scm",(void*)f_2615},
{"f_2636posixunix.scm",(void*)f_2636},
{"f_2622posixunix.scm",(void*)f_2622},
{"f_2458posixunix.scm",(void*)f_2458},
{"f_2563posixunix.scm",(void*)f_2563},
{"f_2571posixunix.scm",(void*)f_2571},
{"f_2558posixunix.scm",(void*)f_2558},
{"f_2460posixunix.scm",(void*)f_2460},
{"f_2467posixunix.scm",(void*)f_2467},
{"f_2470posixunix.scm",(void*)f_2470},
{"f_2473posixunix.scm",(void*)f_2473},
{"f_2557posixunix.scm",(void*)f_2557},
{"f_2477posixunix.scm",(void*)f_2477},
{"f_2491posixunix.scm",(void*)f_2491},
{"f_2501posixunix.scm",(void*)f_2501},
{"f_2504posixunix.scm",(void*)f_2504},
{"f_2507posixunix.scm",(void*)f_2507},
{"f_2513posixunix.scm",(void*)f_2513},
{"f_2523posixunix.scm",(void*)f_2523},
{"f_2434posixunix.scm",(void*)f_2434},
{"f_2456posixunix.scm",(void*)f_2456},
{"f_2452posixunix.scm",(void*)f_2452},
{"f_2410posixunix.scm",(void*)f_2410},
{"f_2432posixunix.scm",(void*)f_2432},
{"f_2428posixunix.scm",(void*)f_2428},
{"f_2386posixunix.scm",(void*)f_2386},
{"f_2408posixunix.scm",(void*)f_2408},
{"f_2404posixunix.scm",(void*)f_2404},
{"f_2324posixunix.scm",(void*)f_2324},
{"f_2337posixunix.scm",(void*)f_2337},
{"f_2349posixunix.scm",(void*)f_2349},
{"f_2343posixunix.scm",(void*)f_2343},
{"f_2315posixunix.scm",(void*)f_2315},
{"f_2322posixunix.scm",(void*)f_2322},
{"f_2306posixunix.scm",(void*)f_2306},
{"f_2313posixunix.scm",(void*)f_2313},
{"f_2297posixunix.scm",(void*)f_2297},
{"f_2304posixunix.scm",(void*)f_2304},
{"f_2288posixunix.scm",(void*)f_2288},
{"f_2295posixunix.scm",(void*)f_2295},
{"f_2279posixunix.scm",(void*)f_2279},
{"f_2286posixunix.scm",(void*)f_2286},
{"f_2270posixunix.scm",(void*)f_2270},
{"f_2277posixunix.scm",(void*)f_2277},
{"f_2261posixunix.scm",(void*)f_2261},
{"f_2268posixunix.scm",(void*)f_2268},
{"f_2252posixunix.scm",(void*)f_2252},
{"f_2259posixunix.scm",(void*)f_2259},
{"f_2243posixunix.scm",(void*)f_2243},
{"f_2250posixunix.scm",(void*)f_2250},
{"f_2237posixunix.scm",(void*)f_2237},
{"f_2241posixunix.scm",(void*)f_2241},
{"f_2231posixunix.scm",(void*)f_2231},
{"f_2235posixunix.scm",(void*)f_2235},
{"f_2225posixunix.scm",(void*)f_2225},
{"f_2229posixunix.scm",(void*)f_2229},
{"f_2219posixunix.scm",(void*)f_2219},
{"f_2223posixunix.scm",(void*)f_2223},
{"f_2213posixunix.scm",(void*)f_2213},
{"f_2217posixunix.scm",(void*)f_2217},
{"f_2207posixunix.scm",(void*)f_2207},
{"f_2211posixunix.scm",(void*)f_2211},
{"f_2175posixunix.scm",(void*)f_2175},
{"f_2186posixunix.scm",(void*)f_2186},
{"f_2179posixunix.scm",(void*)f_2179},
{"f_2138posixunix.scm",(void*)f_2138},
{"f_2170posixunix.scm",(void*)f_2170},
{"f_2163posixunix.scm",(void*)f_2163},
{"f_2142posixunix.scm",(void*)f_2142},
{"f_1946posixunix.scm",(void*)f_1946},
{"f_2119posixunix.scm",(void*)f_2119},
{"f_1962posixunix.scm",(void*)f_1962},
{"f_2093posixunix.scm",(void*)f_2093},
{"f_1968posixunix.scm",(void*)f_1968},
{"f_1971posixunix.scm",(void*)f_1971},
{"f_2053posixunix.scm",(void*)f_2053},
{"f_2051posixunix.scm",(void*)f_2051},
{"f_2010posixunix.scm",(void*)f_2010},
{"f_2028posixunix.scm",(void*)f_2028},
{"f_2026posixunix.scm",(void*)f_2026},
{"f_2014posixunix.scm",(void*)f_2014},
{"f_1936posixunix.scm",(void*)f_1936},
{"f_1926posixunix.scm",(void*)f_1926},
{"f_1920posixunix.scm",(void*)f_1920},
{"f_1888posixunix.scm",(void*)f_1888},
{"f_1895posixunix.scm",(void*)f_1895},
{"f_1901posixunix.scm",(void*)f_1901},
{"f_1908posixunix.scm",(void*)f_1908},
{"f_1849posixunix.scm",(void*)f_1849},
{"f_1856posixunix.scm",(void*)f_1856},
{"f_1865posixunix.scm",(void*)f_1865},
{"f_1807posixunix.scm",(void*)f_1807},
{"f_1817posixunix.scm",(void*)f_1817},
{"f_1820posixunix.scm",(void*)f_1820},
{"f_1823posixunix.scm",(void*)f_1823},
{"f_1792posixunix.scm",(void*)f_1792},
{"f_1754posixunix.scm",(void*)f_1754},
{"f_1784posixunix.scm",(void*)f_1784},
{"f_1771posixunix.scm",(void*)f_1771},
{"f_1774posixunix.scm",(void*)f_1774},
{"f_1708posixunix.scm",(void*)f_1708},
{"f_1712posixunix.scm",(void*)f_1712},
{"f_1651posixunix.scm",(void*)f_1651},
{"f_1644posixunix.scm",(void*)f_1644},
{"f_1626posixunix.scm",(void*)f_1626},
{"f_1630posixunix.scm",(void*)f_1630},
{"f_1641posixunix.scm",(void*)f_1641},
{"f_1637posixunix.scm",(void*)f_1637},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
