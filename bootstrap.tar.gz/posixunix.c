/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-01-18 12:10
   Version 3.0.0rc1 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook lockts ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-17 on dill (Linux)
   command line: posixunix.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
#endif
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)

#ifdef C_GNU_ENV
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
static C_word C_fcall C_setenv(C_word x, C_word y);
C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__CYGWIN__) || defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)
# define C_asctime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), asctime(&C_tm) )
# define C_mktime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), (C_temporary_flonum = mktime(&C_tm)) != -1)
# define C_timegm(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), (C_temporary_flonum = timegm(&C_tm)) != -1)
#else
# define C_asctime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)), asctime(&C_tm) )
# define C_mktime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)), (C_temporary_flonum = mktime(&C_tm)) != -1)
# define C_timegm(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)), (C_temporary_flonum = timegm(&C_tm)) != -1)
#endif

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[425];
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,38),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,55,32,108,111,99,56,32,109,115,103,57,32,46,32,97,114,103,115,49,48,41};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,49,50,49,53,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,49,54,49,57,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,51,48,32,99,109,100,51,49,32,46,32,103,50,57,51,50,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,52,49,32,102,108,97,103,115,52,50,32,46,32,109,111,100,101,52,51,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,99,108,111,115,101,32,102,100,53,48,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,114,101,97,100,32,102,100,53,51,32,115,105,122,101,53,52,32,46,32,98,117,102,102,101,114,53,53,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,119,114,105,116,101,32,102,100,54,50,32,98,117,102,102,101,114,54,51,32,46,32,115,105,122,101,54,52,41};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,55,49,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,9),40,102,100,95,122,101,114,111,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,14),40,102,100,95,115,101,116,32,97,56,52,56,57,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,15),40,102,100,95,116,101,115,116,32,97,57,48,57,53,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,49,57,49,56,32,102,100,49,50,49,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,97,49,57,52,51,32,102,100,49,49,56,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,13),40,97,49,57,56,51,32,102,100,49,49,49,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,50,48,48,57,32,102,100,49,48,52,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,57,54,32,102,100,115,119,57,55,32,46,32,116,105,109,101,111,117,116,57,56,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,49,50,55,32,108,105,110,107,49,50,56,32,108,111,99,49,50,57,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,49,51,50,32,46,32,108,105,110,107,49,51,51,41};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,49,51,55,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,49,51,57,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,49,52,49,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,49,52,51,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,49,52,53,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,49,52,55,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,49,52,57,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,49,53,51,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,49,53,55,32,112,111,115,49,53,56,32,46,32,119,104,101,110,99,101,49,53,57,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,54,55,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,54,57,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,55,49,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,49,56,48,32,115,112,101,99,49,56,54,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,49,56,55,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,49,56,51,32,37,115,112,101,99,49,55,56,50,48,54,41};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,49,56,50,41};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,32,46,32,103,49,55,54,49,55,55,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,50,49,50,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,103,50,49,54,50,49,55,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,50,50,55,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,50,50,56,32,99,109,100,50,50,57,32,105,110,112,50,51,48,32,114,50,51,49,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,50,51,52,32,46,32,109,50,51,53,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,50,52,48,32,46,32,109,50,52,49,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,50,52,54,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,50,54,51,56,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,20),40,97,50,54,52,52,32,46,32,114,101,115,117,108,116,115,50,54,52,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,50,54,48,32,112,114,111,99,50,54,49,32,46,32,109,111,100,101,50,54,50,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,50,54,54,50,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,20),40,97,50,54,54,56,32,46,32,114,101,115,117,108,116,115,50,55,48,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,50,54,54,32,112,114,111,99,50,54,55,32,46,32,109,111,100,101,50,54,56,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,20),40,97,50,54,56,55,32,46,32,114,101,115,117,108,116,115,50,55,55,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,50,55,50,32,116,104,117,110,107,50,55,51,32,46,32,109,111,100,101,50,55,52,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,20),40,97,50,55,48,55,32,46,32,114,101,115,117,108,116,115,50,56,54,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,50,56,49,32,116,104,117,110,107,50,56,50,32,46,32,109,111,100,101,50,56,51,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,50,57,54,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,50,57,56,32,112,114,111,99,50,57,57,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,51,48,50,32,115,116,97,116,101,51,48,51,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,12),40,97,50,56,50,50,32,115,51,48,57,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,26),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,51,48,56,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,105,103,115,51,49,53,32,109,97,115,107,51,49,54,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,51,49,57,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,21),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,51,50,49,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,51,50,52,41};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,20),40,115,101,116,45,117,115,101,114,45,105,100,33,32,105,100,51,51,48,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,103,114,111,117,112,45,105,100,33,32,105,100,51,51,56,41};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,36),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,51,52,55,32,46,32,103,51,52,54,51,52,56,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,51,54,56,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,38),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,51,54,48,32,46,32,103,51,53,57,51,54,49,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,16),40,95,101,110,115,117,114,101,45,103,114,111,117,112,115,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,51,56,52,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,19),40,100,111,51,57,48,32,108,115,116,51,57,50,32,105,51,57,51,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,51,56,57,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,33),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,52,48,57,32,105,100,52,49,48,41};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,52,49,52,32,109,52,49,53,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,39),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,52,49,56,32,117,105,100,52,49,57,32,103,105,100,52,50,48,41};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,52,50,53,32,97,99,99,52,50,54,32,108,111,99,52,50,55,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,51,49,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,51,50,41};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,51,51,41};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,38),40,115,101,116,45,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,33,32,112,105,100,52,52,48,32,112,103,105,100,52,52,49,41};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,36),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,52,53,48,32,110,101,119,52,53,49,41};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,29),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,52,53,54,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,108,105,110,107,32,111,108,100,52,55,49,32,110,101,119,52,55,50,41};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,52,55,55,32,109,52,55,56,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,32),40,99,104,101,99,107,32,108,111,99,52,56,50,32,102,100,52,56,51,32,105,110,112,52,56,52,32,114,52,56,53,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,52,56,56,32,46,32,109,52,56,57,41};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,52,57,49,32,46,32,109,52,57,50,41};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,52,57,55,41};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,34),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,53,48,49,32,46,32,110,101,119,53,48,50,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,8),40,114,101,97,100,121,63,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,7),40,102,101,116,99,104,41};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,7),40,97,51,57,49,48,41};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,7),40,97,51,57,50,51,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,7),40,97,51,57,51,53,41};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,7),40,97,51,57,53,54,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,110,53,54,49,32,109,53,54,50,32,115,116,97,114,116,53,54,51,41};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,37),40,97,51,57,54,53,32,112,111,114,116,53,53,54,32,110,53,53,55,32,100,101,115,116,53,53,56,32,115,116,97,114,116,53,53,57,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,21),40,97,52,48,52,56,32,99,117,114,53,55,52,32,112,116,114,53,55,53,41};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,116,114,53,55,51,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,24),40,97,52,48,51,48,32,112,111,114,116,53,55,48,32,108,105,109,105,116,53,55,49,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,54),40,98,111,100,121,53,49,57,32,110,111,110,98,108,111,99,107,105,110,103,63,53,50,55,32,98,117,102,105,53,50,56,32,111,110,45,99,108,111,115,101,53,50,57,32,109,111,114,101,63,53,51,48,41};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,62),40,100,101,102,45,109,111,114,101,63,53,50,52,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,49,53,53,56,57,32,37,98,117,102,105,53,49,54,53,57,48,32,37,111,110,45,99,108,111,115,101,53,49,55,53,57,49,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,49),40,100,101,102,45,111,110,45,99,108,111,115,101,53,50,51,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,49,53,53,57,51,32,37,98,117,102,105,53,49,54,53,57,52,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,117,102,105,53,50,50,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,49,53,53,57,54,41};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,21),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,53,50,49,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,55),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,53,49,49,32,110,97,109,53,49,50,32,102,100,53,49,51,32,46,32,103,53,49,48,53,49,52,41};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,20),40,112,111,107,101,32,115,116,114,54,50,56,32,108,101,110,54,50,57,41};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,14),40,97,52,50,56,54,32,115,116,114,54,52,55,41};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,7),40,97,52,50,57,50,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,7),40,97,52,51,49,51,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,15),40,102,95,52,51,50,50,32,115,116,114,54,51,51,41};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,29),40,108,111,111,112,32,114,101,109,54,51,56,32,115,116,97,114,116,54,51,57,32,108,101,110,54,52,48,41};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,15),40,102,95,52,51,51,55,32,115,116,114,54,51,54,41};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,45),40,98,111,100,121,54,49,54,32,110,111,110,98,108,111,99,107,105,110,103,63,54,50,51,32,98,117,102,105,54,50,52,32,111,110,45,99,108,111,115,101,54,50,53,41};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,49),40,100,101,102,45,111,110,45,99,108,111,115,101,54,50,48,32,37,110,111,110,98,108,111,99,107,105,110,103,63,54,49,51,54,53,53,32,37,98,117,102,105,54,49,52,54,53,54,41};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,117,102,105,54,49,57,32,37,110,111,110,98,108,111,99,107,105,110,103,63,54,49,51,54,53,56,41};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,21),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,54,49,56,41};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,56),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,54,48,57,32,110,97,109,54,49,48,32,102,100,54,49,49,32,46,32,103,54,48,56,54,49,50,41};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,54,54,54,32,111,102,102,54,54,55,41};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,32,112,111,114,116,54,55,49,32,97,114,103,115,54,55,50,32,108,111,99,54,55,51,41};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,27),40,101,114,114,32,109,115,103,54,56,54,32,108,111,99,107,54,56,55,32,108,111,99,54,56,56,41};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,54,56,57,32,46,32,97,114,103,115,54,57,48,41};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,54,57,50,32,46,32,97,114,103,115,54,57,51,41};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,54,57,53,32,46,32,97,114,103,115,54,57,54,41};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,21),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,55,48,53,41};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,32),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,55,48,56,32,46,32,109,111,100,101,55,48,57,41};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,19),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,55,49,51,41};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,22),40,115,101,116,101,110,118,32,118,97,114,55,49,54,32,118,97,108,55,49,55,41};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,17),40,117,110,115,101,116,101,110,118,32,118,97,114,55,50,49,41};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,55,51,52,41};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,51,49,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,21),40,99,117,114,114,101,110,116,45,101,110,118,105,114,111,110,109,101,110,116,41};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,66),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,55,53,53,32,108,101,110,55,53,54,32,112,114,111,116,55,53,55,32,102,108,97,103,55,53,56,32,102,100,55,53,57,32,46,32,111,102,102,55,54,48,41};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,41),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,55,55,53,32,46,32,108,101,110,55,55,54,41};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,36),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,55,55,57,41};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,26),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,55,56,49,41};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,29),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,55,56,50,41};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,27),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,55,56,52,41};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,25),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,55,57,50,41};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,20),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,56,48,49,41};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,27),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,56,48,54,41};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,25),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,56,48,57,41};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,17),40,95,101,120,105,116,32,46,32,99,111,100,101,56,50,48,41};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,20),40,115,101,116,45,97,108,97,114,109,33,32,97,56,50,49,56,50,52,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,56,50,53,32,109,111,100,101,56,50,54,32,46,32,115,105,122,101,56,50,55,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,56,51,52,41};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,56,51,55,32,112,111,114,116,56,51,56,41};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,23),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,56,52,54,41};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,23),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,56,53,55,41};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,7),40,97,53,51,55,57,41};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,110,115,56,57,55,41};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,37),40,97,53,51,56,53,32,100,105,114,56,56,50,56,56,53,32,102,105,108,56,56,51,56,56,54,32,101,120,116,56,56,52,56,56,55,41};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,20),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,56,56,48,41};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,17),40,103,108,111,98,32,46,32,112,97,116,104,115,56,55,56,41};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,16),40,102,95,53,52,57,55,32,97,57,49,48,57,49,51,41};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,57,48,56,41};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,24),40,115,101,116,97,114,103,32,97,57,50,49,57,50,55,32,97,57,50,48,57,50,56,41};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,97,57,51,51,57,51,57,32,97,57,51,50,57,52,48,41};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,12),40,100,111,57,54,50,32,105,57,54,53,41};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,18),40,100,111,57,53,56,32,97,108,57,54,48,32,105,57,54,49,41};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,31),40,98,111,100,121,57,52,57,32,97,114,103,108,105,115,116,57,53,53,32,101,110,118,108,105,115,116,57,53,54,41};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,31),40,100,101,102,45,101,110,118,108,105,115,116,57,53,50,32,37,97,114,103,108,105,115,116,57,52,55,57,56,53,41};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,105,115,116,57,53,49,41};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,39),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,57,52,53,32,46,32,103,57,52,52,57,52,54,41};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,57,57,49,32,110,111,104,97,110,103,57,57,50,41};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,7),40,97,53,55,55,57,41};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,36),40,97,53,55,56,53,32,101,112,105,100,49,48,48,55,32,101,110,111,114,109,49,48,48,56,32,101,99,111,100,101,49,48,48,57,41};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,24),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,57,57,53,41};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,49,48,49,53,49,48,49,56,41};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,49,48,49,57,32,46,32,115,105,103,49,48,50,48,41};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,48,50,55,41};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,48,51,49,32,46,32,97,114,103,115,49,48,51,50,41};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,7),40,97,53,57,53,53,41};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,29),40,97,53,57,54,49,32,95,49,48,53,54,32,102,108,103,49,48,53,55,32,99,111,100,49,48,53,56,41};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,8),40,102,95,53,57,52,49,41};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,111,110,45,99,108,111,115,101,32,108,111,99,49,48,53,48,32,112,105,100,49,48,53,49,32,99,108,115,118,101,99,49,48,53,50,32,105,100,120,49,48,53,51,32,105,100,120,97,49,48,53,52,32,105,100,120,98,49,48,53,53,41};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,7),40,97,53,57,56,52,41};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,19),40,97,53,57,57,48,32,105,49,48,54,50,32,111,49,48,54,51,41};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,101,100,45,112,105,112,101,32,112,111,114,116,49,48,54,49,41};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,34),40,99,111,110,110,101,99,116,45,112,97,114,101,110,116,32,112,105,112,101,49,48,54,53,32,112,111,114,116,49,48,54,54,41};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,43),40,99,111,110,110,101,99,116,45,99,104,105,108,100,32,112,105,112,101,49,48,55,50,32,112,111,114,116,49,48,55,51,32,115,116,100,102,100,49,48,55,52,41};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,14),40,115,119,97,112,112,101,100,45,101,110,100,115,41};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,7),40,97,54,48,54,53,41};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,67),40,115,112,97,119,110,32,99,109,100,49,48,56,52,32,97,114,103,115,49,48,56,53,32,101,110,118,49,48,56,54,32,115,116,100,111,117,116,102,49,48,56,55,32,115,116,100,105,110,102,49,48,56,56,32,115,116,100,101,114,114,102,49,48,56,57,41};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,59),40,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,48,57,54,32,99,109,100,49,48,57,56,32,112,105,112,101,49,48,57,57,32,115,116,100,102,49,49,48,48,32,111,110,45,99,108,111,115,101,49,49,48,50,41};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,60),40,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,49,48,52,32,99,109,100,49,49,48,54,32,112,105,112,101,49,49,48,55,32,115,116,100,102,49,49,48,56,32,111,110,45,99,108,111,115,101,49,49,49,48,41};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,7),40,97,54,49,49,53,41};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,50),40,97,54,49,50,49,32,105,110,112,105,112,101,49,49,49,57,32,111,117,116,112,105,112,101,49,49,50,48,32,101,114,114,112,105,112,101,49,49,50,49,32,112,105,100,49,49,50,50,41};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,49,49,49,50,32,99,109,100,49,49,49,51,32,97,114,103,115,49,49,49,52,32,101,110,118,49,49,49,53,32,115,116,100,111,117,116,102,49,49,49,54,32,115,116,100,105,110,102,49,49,49,55,32,115,116,100,101,114,114,102,49,49,49,56,41};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,17),40,97,54,49,56,52,32,103,49,49,51,50,49,49,51,51,41};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,49,49,51,49,41};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,7),40,97,54,50,48,50,41};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,38),40,97,54,50,48,56,32,105,110,49,49,51,54,32,111,117,116,49,49,51,55,32,112,105,100,49,49,51,56,32,101,114,114,49,49,51,57,41};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,52),40,37,112,114,111,99,101,115,115,32,108,111,99,49,49,50,53,32,101,114,114,63,49,49,50,54,32,99,109,100,49,49,50,55,32,97,114,103,115,49,49,50,56,32,101,110,118,49,49,50,57,41};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,49,49,52,56,32,97,114,103,115,49,49,53,52,32,101,110,118,49,49,53,53,41};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,49,53,49,32,37,97,114,103,115,49,49,52,54,49,49,53,55,41};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,49,53,48,41};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,29),40,112,114,111,99,101,115,115,32,99,109,100,49,49,52,52,32,46,32,103,49,49,52,51,49,49,52,53,41};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,49,49,54,56,32,97,114,103,115,49,49,55,52,32,101,110,118,49,49,55,53,41};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,49,55,49,32,37,97,114,103,115,49,49,54,54,49,49,55,55,41};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,49,55,48,41};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,42,32,99,109,100,49,49,54,52,32,46,32,103,49,49,54,51,49,49,54,53,41};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,14),40,102,95,54,53,48,52,32,120,49,50,49,49,41};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,7),40,97,54,52,50,49,41};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,7),40,97,54,52,50,57,41};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,7),40,97,54,52,53,51,41};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,49,50,49,51,32,114,49,50,49,52,41};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,16),40,102,95,54,53,50,51,32,46,32,95,49,50,48,55,41};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,16),40,102,95,54,53,49,53,32,46,32,95,49,50,48,54,41};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,49,57,52,32,97,99,116,105,111,110,49,50,48,49,32,105,100,49,50,48,50,32,108,105,109,105,116,49,50,48,51,41};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,49,49,57,56,32,37,97,99,116,105,111,110,49,49,57,49,49,50,50,56,32,37,105,100,49,49,57,50,49,50,50,57,41};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,49,49,57,55,32,37,97,99,116,105,111,110,49,49,57,49,49,50,51,49,41};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,19),40,97,54,53,52,51,32,120,49,50,51,51,32,121,49,50,51,52,41};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,49,49,57,54,41};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,49,49,56,56,32,112,114,101,100,49,49,56,57,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,49,49,57,48,41};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,49,50,52,56,41};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,14),40,97,54,54,52,50,32,112,105,100,52,52,53,41};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,7),40,97,54,54,54,48,41};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,13),40,97,54,54,54,51,32,105,100,51,52,52,41};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,7),40,97,54,54,55,56,41};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,7),40,97,54,54,56,49,41};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,13),40,97,54,54,56,52,32,105,100,51,51,54,41};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,7),40,97,54,54,57,57,41};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,12),40,97,54,55,48,50,32,110,51,50,55,41};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,15),40,97,54,55,48,56,32,112,111,114,116,49,54,52,41};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41};


/* from k6610 in set-root-directory! in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub1243(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1243(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k5837 */
static C_word C_fcall stub1016(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1016(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub1013(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1013(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub1011(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1011(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub942(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub942(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k5543 */
static C_word C_fcall stub935(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub935(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub930(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub930(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k5524 */
static C_word C_fcall stub923(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub923(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k5500 */
static C_word C_fcall stub911(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub911(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub906(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub906(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub866(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub866(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k5309 */
static C_word C_fcall stub852(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub852(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k5286 */
static C_word C_fcall stub842(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub842(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k5175 */
static C_word C_fcall stub822(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub822(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k5153 */
static C_word C_fcall stub817(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub817(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub812(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub812(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from asctime */
static C_word C_fcall stub797(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub797(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k5040 */
static C_word C_fcall stub788(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub788(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k4959 */
static C_word C_fcall stub769(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub769(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k4897 */
static C_word C_fcall stub744(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub744(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k4797 */
static C_word C_fcall stub726(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub726(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k3594 in k3590 in file-link in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub463(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub463(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k3310 */
static C_word C_fcall stub403(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub403(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k3179 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub376(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub376(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from k3172 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub372(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub372(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from k3086 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub355(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub355(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a6660 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub342(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub342(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a6678 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub340(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub340(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a6681 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub334(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub334(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a6699 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub332(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub332(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k1834 */
static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k1824 */
static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k1814 */
static C_word C_fcall stub81(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub81(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k1596 */
static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from k1545 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub17(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub17(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from k1538 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub13(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub13(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k1514 */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6709)
static void C_ccall f_6709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6725)
static void C_ccall f_6725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6713)
static void C_ccall f_6713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6716)
static void C_ccall f_6716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6685)
static void C_ccall f_6685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6682)
static void C_ccall f_6682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6679)
static void C_ccall f_6679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6664)
static void C_ccall f_6664(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6674)
static void C_ccall f_6674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6656)
static void C_ccall f_6656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6650)
static void C_ccall f_6650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6620)
static void C_ccall f_6620(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6538)
static void C_fcall f_6538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6533)
static void C_fcall f_6533(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6528)
static void C_fcall f_6528(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6357)
static void C_fcall f_6357(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6364)
static void C_fcall f_6364(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6376)
static void C_fcall f_6376(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6470)
static void C_ccall f_6470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6467)
static void C_ccall f_6467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6445)
static void C_ccall f_6445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6442)
static void C_ccall f_6442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6504)
static void C_ccall f_6504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6295)
static void C_ccall f_6295(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6295)
static void C_ccall f_6295r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6307)
static void C_fcall f_6307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6302)
static void C_fcall f_6302(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6297)
static void C_fcall f_6297(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6235)
static void C_ccall f_6235(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6235)
static void C_ccall f_6235r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6247)
static void C_fcall f_6247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6242)
static void C_fcall f_6242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6237)
static void C_fcall f_6237(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6174)
static void C_fcall f_6174(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6209)
static void C_ccall f_6209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6176)
static void C_fcall f_6176(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6145)
static void C_ccall f_6145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6099)
static void C_fcall f_6099(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6088)
static void C_fcall f_6088(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6043)
static void C_fcall f_6043(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6066)
static void C_ccall f_6066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6073)
static void C_ccall f_6073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6064)
static void C_ccall f_6064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6027)
static C_word C_fcall f_6027(C_word *a,C_word t0);
C_noret_decl(f_6010)
static void C_fcall f_6010(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_fcall f_5996(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5976)
static void C_fcall f_5976(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5985)
static void C_ccall f_5985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5939)
static void C_fcall f_5939(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5962)
static void C_ccall f_5962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5956)
static void C_ccall f_5956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5909)
static void C_ccall f_5909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5685)
static void C_fcall f_5685(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5680)
static void C_fcall f_5680(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5553)
static void C_fcall f_5553(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5571)
static void C_fcall f_5571(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5617)
static C_word C_fcall f_5617(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5584)
static void C_fcall f_5584(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static C_word C_fcall f_5532(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5513)
static C_word C_fcall f_5513(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5365)
static void C_fcall f_5365(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5393)
static void C_ccall f_5393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5396)
static void C_ccall f_5396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5405)
static void C_fcall f_5405(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5316)
static void C_ccall f_5316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_fcall f_5257(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5245)
static void C_ccall f_5245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_fcall f_4806(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_fcall f_4818(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4780)
static void C_ccall f_4780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4701)
static void C_fcall f_4701(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4614)
static void C_ccall f_4614(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4614)
static void C_ccall f_4614r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4596)
static void C_fcall f_4596(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4522)
static void C_fcall f_4522(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4544)
static void C_ccall f_4544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4550)
static void C_fcall f_4550(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4420)
static void C_fcall f_4420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_fcall f_4415(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4410)
static void C_fcall f_4410(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4226)
static void C_fcall f_4226(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4354)
static void C_fcall f_4354(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4278)
static void C_fcall f_4278(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_fcall f_4232(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4146)
static void C_fcall f_4146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4141)
static void C_fcall f_4141(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4136)
static void C_fcall f_4136(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4131)
static void C_fcall f_4131(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3790)
static void C_fcall f_3790(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4037)
static void C_fcall f_4037(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3972)
static void C_fcall f_3972(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_fcall f_3824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_fcall f_3836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static C_word C_fcall f_3816(C_word t0);
C_noret_decl(f_3801)
static void C_fcall f_3801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3768)
static void C_fcall f_3768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3716)
static void C_ccall f_3716(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_fcall f_3673(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3636)
static void C_fcall f_3636(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3441)
static void C_fcall f_3441(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3255)
static void C_fcall f_3255(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_fcall f_3198(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static C_word C_fcall f_3176(C_word t0);
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_fcall f_3097(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_fcall f_3120(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_fcall f_2991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2835)
static void C_fcall f_2835(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_fcall f_2527(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_fcall f_2521(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static C_word C_fcall f_2509(C_word t0);
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2391)
static void C_fcall f_2391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_fcall f_2386(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2288)
static void C_fcall f_2288(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_fcall f_2319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_fcall f_2341(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_fcall f_2029(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_fcall f_1862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_fcall f_1901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_fcall f_1905(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static C_word C_fcall f_1827(C_word t0,C_word t1);
C_noret_decl(f_1817)
static C_word C_fcall f_1817(C_word t0,C_word t1);
C_noret_decl(f_1811)
static C_word C_fcall f_1811(C_word t0);
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1698)
static void C_ccall f_1698r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6538)
static void C_fcall trf_6538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6538(t0,t1);}

C_noret_decl(trf_6533)
static void C_fcall trf_6533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6533(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6533(t0,t1,t2);}

C_noret_decl(trf_6528)
static void C_fcall trf_6528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6528(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6528(t0,t1,t2,t3);}

C_noret_decl(trf_6357)
static void C_fcall trf_6357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6357(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6357(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6364)
static void C_fcall trf_6364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6364(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6364(t0,t1);}

C_noret_decl(trf_6376)
static void C_fcall trf_6376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6376(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6376(t0,t1,t2,t3);}

C_noret_decl(trf_6307)
static void C_fcall trf_6307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6307(t0,t1);}

C_noret_decl(trf_6302)
static void C_fcall trf_6302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6302(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6302(t0,t1,t2);}

C_noret_decl(trf_6297)
static void C_fcall trf_6297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6297(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6297(t0,t1,t2,t3);}

C_noret_decl(trf_6247)
static void C_fcall trf_6247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6247(t0,t1);}

C_noret_decl(trf_6242)
static void C_fcall trf_6242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6242(t0,t1,t2);}

C_noret_decl(trf_6237)
static void C_fcall trf_6237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6237(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6237(t0,t1,t2,t3);}

C_noret_decl(trf_6174)
static void C_fcall trf_6174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6174(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6174(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6176)
static void C_fcall trf_6176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6176(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6176(t0,t1,t2);}

C_noret_decl(trf_6099)
static void C_fcall trf_6099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6099(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6099(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6088)
static void C_fcall trf_6088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6088(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6088(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6043)
static void C_fcall trf_6043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6043(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6043(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6010)
static void C_fcall trf_6010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6010(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6010(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5996)
static void C_fcall trf_5996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5996(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5996(t0,t1,t2,t3);}

C_noret_decl(trf_5976)
static void C_fcall trf_5976(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5976(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5976(t0,t1,t2);}

C_noret_decl(trf_5939)
static void C_fcall trf_5939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5939(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_5939(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_5685)
static void C_fcall trf_5685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5685(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5685(t0,t1);}

C_noret_decl(trf_5680)
static void C_fcall trf_5680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5680(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5680(t0,t1,t2);}

C_noret_decl(trf_5553)
static void C_fcall trf_5553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5553(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5553(t0,t1,t2,t3);}

C_noret_decl(trf_5571)
static void C_fcall trf_5571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5571(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5571(t0,t1,t2,t3);}

C_noret_decl(trf_5584)
static void C_fcall trf_5584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5584(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5584(t0,t1);}

C_noret_decl(trf_5365)
static void C_fcall trf_5365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5365(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5365(t0,t1,t2);}

C_noret_decl(trf_5405)
static void C_fcall trf_5405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5405(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5405(t0,t1,t2);}

C_noret_decl(trf_5257)
static void C_fcall trf_5257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5257(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5257(t0,t1,t2);}

C_noret_decl(trf_4806)
static void C_fcall trf_4806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4806(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4806(t0,t1,t2);}

C_noret_decl(trf_4818)
static void C_fcall trf_4818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4818(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4818(t0,t1,t2);}

C_noret_decl(trf_4701)
static void C_fcall trf_4701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4701(t0,t1);}

C_noret_decl(trf_4596)
static void C_fcall trf_4596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4596(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4596(t0,t1,t2,t3);}

C_noret_decl(trf_4522)
static void C_fcall trf_4522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4522(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4522(t0,t1,t2,t3);}

C_noret_decl(trf_4550)
static void C_fcall trf_4550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4550(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4550(t0,t1);}

C_noret_decl(trf_4420)
static void C_fcall trf_4420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4420(t0,t1);}

C_noret_decl(trf_4415)
static void C_fcall trf_4415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4415(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4415(t0,t1,t2);}

C_noret_decl(trf_4410)
static void C_fcall trf_4410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4410(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4410(t0,t1,t2,t3);}

C_noret_decl(trf_4226)
static void C_fcall trf_4226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4226(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4226(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4354)
static void C_fcall trf_4354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4354(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4354(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4278)
static void C_fcall trf_4278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4278(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4278(t0,t1);}

C_noret_decl(trf_4232)
static void C_fcall trf_4232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4232(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4232(t0,t1,t2,t3);}

C_noret_decl(trf_4146)
static void C_fcall trf_4146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4146(t0,t1);}

C_noret_decl(trf_4141)
static void C_fcall trf_4141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4141(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4141(t0,t1,t2);}

C_noret_decl(trf_4136)
static void C_fcall trf_4136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4136(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4136(t0,t1,t2,t3);}

C_noret_decl(trf_4131)
static void C_fcall trf_4131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4131(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4131(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3790)
static void C_fcall trf_3790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3790(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3790(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4037)
static void C_fcall trf_4037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4037(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4037(t0,t1,t2);}

C_noret_decl(trf_3972)
static void C_fcall trf_3972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3972(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3972(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3824)
static void C_fcall trf_3824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3824(t0,t1);}

C_noret_decl(trf_3836)
static void C_fcall trf_3836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3836(t0,t1);}

C_noret_decl(trf_3801)
static void C_fcall trf_3801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3801(t0,t1);}

C_noret_decl(trf_3768)
static void C_fcall trf_3768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3768(t0,t1);}

C_noret_decl(trf_3673)
static void C_fcall trf_3673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3673(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3673(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3636)
static void C_fcall trf_3636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3636(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3636(t0,t1,t2);}

C_noret_decl(trf_3441)
static void C_fcall trf_3441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3441(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3441(t0,t1,t2,t3);}

C_noret_decl(trf_3255)
static void C_fcall trf_3255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3255(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3255(t0,t1,t2,t3);}

C_noret_decl(trf_3198)
static void C_fcall trf_3198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3198(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3198(t0,t1,t2);}

C_noret_decl(trf_3097)
static void C_fcall trf_3097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3097(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3097(t0,t1);}

C_noret_decl(trf_3120)
static void C_fcall trf_3120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3120(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3120(t0,t1,t2);}

C_noret_decl(trf_2991)
static void C_fcall trf_2991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2991(t0,t1);}

C_noret_decl(trf_2835)
static void C_fcall trf_2835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2835(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2835(t0,t1,t2,t3);}

C_noret_decl(trf_2527)
static void C_fcall trf_2527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2527(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2527(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2521)
static void C_fcall trf_2521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2521(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2521(t0,t1);}

C_noret_decl(trf_2391)
static void C_fcall trf_2391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2391(t0,t1);}

C_noret_decl(trf_2386)
static void C_fcall trf_2386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2386(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2386(t0,t1,t2);}

C_noret_decl(trf_2288)
static void C_fcall trf_2288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2288(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2288(t0,t1,t2,t3);}

C_noret_decl(trf_2319)
static void C_fcall trf_2319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2319(t0,t1);}

C_noret_decl(trf_2341)
static void C_fcall trf_2341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2341(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2341(t0,t1);}

C_noret_decl(trf_2029)
static void C_fcall trf_2029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2029(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2029(t0,t1,t2,t3);}

C_noret_decl(trf_1862)
static void C_fcall trf_1862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1862(t0,t1);}

C_noret_decl(trf_1901)
static void C_fcall trf_1901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1901(t0,t1);}

C_noret_decl(trf_1905)
static void C_fcall trf_1905(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1905(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1905(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3150)){
C_save(t1);
C_rereclaim2(3150*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,425);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_h_intern(&lf[51],9,"file-open");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[53]=C_h_intern(&lf[53],17,"\003sysmake-c-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysexpand-home-path");
lf[55]=C_h_intern(&lf[55],10,"file-close");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],10,"file-write");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[65]=C_h_intern(&lf[65],12,"file-mkstemp");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[68]=C_h_intern(&lf[68],11,"file-select");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[70]=C_h_intern(&lf[70],12,"\003sysfor-each");
lf[71]=C_h_intern(&lf[71],8,"seek/set");
lf[72]=C_h_intern(&lf[72],8,"seek/end");
lf[73]=C_h_intern(&lf[73],8,"seek/cur");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[77]=C_h_intern(&lf[77],9,"file-stat");
lf[78]=C_h_intern(&lf[78],9,"file-size");
lf[79]=C_h_intern(&lf[79],22,"file-modification-time");
lf[80]=C_h_intern(&lf[80],16,"file-access-time");
lf[81]=C_h_intern(&lf[81],16,"file-change-time");
lf[82]=C_h_intern(&lf[82],10,"file-owner");
lf[83]=C_h_intern(&lf[83],16,"file-permissions");
lf[84]=C_h_intern(&lf[84],13,"regular-file\077");
lf[85]=C_h_intern(&lf[85],14,"symbolic-link\077");
lf[86]=C_h_intern(&lf[86],18,"set-file-position!");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[88]=C_h_intern(&lf[88],6,"stream");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[90]=C_h_intern(&lf[90],5,"port\077");
lf[91]=C_h_intern(&lf[91],13,"\000bounds-error");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[93]=C_h_intern(&lf[93],13,"file-position");
lf[94]=C_h_intern(&lf[94],16,"create-directory");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[96]=C_h_intern(&lf[96],16,"change-directory");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[98]=C_h_intern(&lf[98],16,"delete-directory");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[100]=C_h_intern(&lf[100],10,"string-ref");
lf[101]=C_h_intern(&lf[101],6,"string");
lf[102]=C_h_intern(&lf[102],9,"directory");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[104]=C_h_intern(&lf[104],16,"\003sysmake-pointer");
lf[105]=C_h_intern(&lf[105],17,"current-directory");
lf[106]=C_h_intern(&lf[106],10,"directory\077");
lf[107]=C_h_intern(&lf[107],13,"\003sysfile-info");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[109]=C_h_intern(&lf[109],5,"\000text");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[112]=C_h_intern(&lf[112],13,"\003sysmake-port");
lf[113]=C_h_intern(&lf[113],21,"\003sysstream-port-class");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[115]=C_h_intern(&lf[115],15,"open-input-pipe");
lf[116]=C_h_intern(&lf[116],7,"\000binary");
lf[117]=C_h_intern(&lf[117],16,"open-output-pipe");
lf[118]=C_h_intern(&lf[118],16,"close-input-pipe");
lf[119]=C_h_intern(&lf[119],23,"close-input/output-pipe");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[121]=C_h_intern(&lf[121],14,"\003syscheck-port");
lf[122]=C_h_intern(&lf[122],17,"close-output-pipe");
lf[123]=C_h_intern(&lf[123],20,"call-with-input-pipe");
lf[124]=C_h_intern(&lf[124],21,"call-with-output-pipe");
lf[125]=C_h_intern(&lf[125],20,"with-input-from-pipe");
lf[126]=C_h_intern(&lf[126],18,"\003sysstandard-input");
lf[127]=C_h_intern(&lf[127],19,"with-output-to-pipe");
lf[128]=C_h_intern(&lf[128],19,"\003sysstandard-output");
lf[129]=C_h_intern(&lf[129],11,"create-pipe");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[131]=C_h_intern(&lf[131],11,"signal/term");
lf[132]=C_h_intern(&lf[132],11,"signal/kill");
lf[133]=C_h_intern(&lf[133],10,"signal/int");
lf[134]=C_h_intern(&lf[134],10,"signal/hup");
lf[135]=C_h_intern(&lf[135],10,"signal/fpe");
lf[136]=C_h_intern(&lf[136],10,"signal/ill");
lf[137]=C_h_intern(&lf[137],11,"signal/segv");
lf[138]=C_h_intern(&lf[138],11,"signal/abrt");
lf[139]=C_h_intern(&lf[139],11,"signal/trap");
lf[140]=C_h_intern(&lf[140],11,"signal/quit");
lf[141]=C_h_intern(&lf[141],11,"signal/alrm");
lf[142]=C_h_intern(&lf[142],13,"signal/vtalrm");
lf[143]=C_h_intern(&lf[143],11,"signal/prof");
lf[144]=C_h_intern(&lf[144],9,"signal/io");
lf[145]=C_h_intern(&lf[145],10,"signal/urg");
lf[146]=C_h_intern(&lf[146],11,"signal/chld");
lf[147]=C_h_intern(&lf[147],11,"signal/cont");
lf[148]=C_h_intern(&lf[148],11,"signal/stop");
lf[149]=C_h_intern(&lf[149],11,"signal/tstp");
lf[150]=C_h_intern(&lf[150],11,"signal/pipe");
lf[151]=C_h_intern(&lf[151],11,"signal/xcpu");
lf[152]=C_h_intern(&lf[152],11,"signal/xfsz");
lf[153]=C_h_intern(&lf[153],11,"signal/usr1");
lf[154]=C_h_intern(&lf[154],11,"signal/usr2");
lf[155]=C_h_intern(&lf[155],12,"signal/winch");
lf[156]=C_h_intern(&lf[156],12,"signals-list");
lf[157]=C_h_intern(&lf[157],18,"\003sysinterrupt-hook");
lf[158]=C_h_intern(&lf[158],14,"signal-handler");
lf[159]=C_h_intern(&lf[159],19,"set-signal-handler!");
lf[160]=C_h_intern(&lf[160],16,"set-signal-mask!");
lf[161]=C_h_intern(&lf[161],14,"\000process-error");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[163]=C_h_intern(&lf[163],11,"signal-mask");
lf[164]=C_h_intern(&lf[164],14,"signal-masked\077");
lf[165]=C_h_intern(&lf[165],12,"signal-mask!");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[167]=C_h_intern(&lf[167],14,"signal-unmask!");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[169]=C_h_intern(&lf[169],18,"system-information");
lf[170]=C_h_intern(&lf[170],25,"\003syspeek-nonnull-c-string");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[172]=C_h_intern(&lf[172],12,"set-user-id!");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[174]=C_h_intern(&lf[174],15,"current-user-id");
lf[175]=C_h_intern(&lf[175],25,"current-effective-user-id");
lf[176]=C_h_intern(&lf[176],13,"set-group-id!");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[178]=C_h_intern(&lf[178],16,"current-group-id");
lf[179]=C_h_intern(&lf[179],26,"current-effective-group-id");
lf[180]=C_h_intern(&lf[180],16,"user-information");
lf[181]=C_h_intern(&lf[181],6,"vector");
lf[182]=C_h_intern(&lf[182],4,"list");
lf[183]=C_h_intern(&lf[183],17,"current-user-name");
lf[184]=C_h_intern(&lf[184],27,"current-effective-user-name");
lf[185]=C_h_intern(&lf[185],17,"group-information");
lf[187]=C_h_intern(&lf[187],10,"get-groups");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[191]=C_h_intern(&lf[191],11,"set-groups!");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[194]=C_h_intern(&lf[194],17,"initialize-groups");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[196]=C_h_intern(&lf[196],10,"errno/perm");
lf[197]=C_h_intern(&lf[197],11,"errno/noent");
lf[198]=C_h_intern(&lf[198],10,"errno/srch");
lf[199]=C_h_intern(&lf[199],10,"errno/intr");
lf[200]=C_h_intern(&lf[200],8,"errno/io");
lf[201]=C_h_intern(&lf[201],12,"errno/noexec");
lf[202]=C_h_intern(&lf[202],10,"errno/badf");
lf[203]=C_h_intern(&lf[203],11,"errno/child");
lf[204]=C_h_intern(&lf[204],11,"errno/nomem");
lf[205]=C_h_intern(&lf[205],11,"errno/acces");
lf[206]=C_h_intern(&lf[206],11,"errno/fault");
lf[207]=C_h_intern(&lf[207],10,"errno/busy");
lf[208]=C_h_intern(&lf[208],12,"errno/notdir");
lf[209]=C_h_intern(&lf[209],11,"errno/isdir");
lf[210]=C_h_intern(&lf[210],11,"errno/inval");
lf[211]=C_h_intern(&lf[211],11,"errno/mfile");
lf[212]=C_h_intern(&lf[212],11,"errno/nospc");
lf[213]=C_h_intern(&lf[213],11,"errno/spipe");
lf[214]=C_h_intern(&lf[214],10,"errno/pipe");
lf[215]=C_h_intern(&lf[215],11,"errno/again");
lf[216]=C_h_intern(&lf[216],10,"errno/rofs");
lf[217]=C_h_intern(&lf[217],11,"errno/exist");
lf[218]=C_h_intern(&lf[218],16,"errno/wouldblock");
lf[219]=C_h_intern(&lf[219],10,"errno/2big");
lf[220]=C_h_intern(&lf[220],12,"errno/deadlk");
lf[221]=C_h_intern(&lf[221],9,"errno/dom");
lf[222]=C_h_intern(&lf[222],10,"errno/fbig");
lf[223]=C_h_intern(&lf[223],11,"errno/ilseq");
lf[224]=C_h_intern(&lf[224],11,"errno/mlink");
lf[225]=C_h_intern(&lf[225],17,"errno/nametoolong");
lf[226]=C_h_intern(&lf[226],11,"errno/nfile");
lf[227]=C_h_intern(&lf[227],11,"errno/nodev");
lf[228]=C_h_intern(&lf[228],11,"errno/nolck");
lf[229]=C_h_intern(&lf[229],11,"errno/nosys");
lf[230]=C_h_intern(&lf[230],14,"errno/notempty");
lf[231]=C_h_intern(&lf[231],11,"errno/notty");
lf[232]=C_h_intern(&lf[232],10,"errno/nxio");
lf[233]=C_h_intern(&lf[233],11,"errno/range");
lf[234]=C_h_intern(&lf[234],10,"errno/xdev");
lf[235]=C_h_intern(&lf[235],16,"change-file-mode");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[237]=C_h_intern(&lf[237],17,"change-file-owner");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[239]=C_h_intern(&lf[239],17,"file-read-access\077");
lf[240]=C_h_intern(&lf[240],18,"file-write-access\077");
lf[241]=C_h_intern(&lf[241],20,"file-execute-access\077");
lf[242]=C_h_intern(&lf[242],14,"create-session");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[244]=C_h_intern(&lf[244],21,"set-process-group-id!");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[246]=C_h_intern(&lf[246],16,"process-group-id");
lf[247]=C_h_intern(&lf[247],20,"create-symbolic-link");
lf[248]=C_h_intern(&lf[248],18,"create-symbol-link");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[250]=C_h_intern(&lf[250],9,"substring");
lf[251]=C_h_intern(&lf[251],18,"read-symbolic-link");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[253]=C_h_intern(&lf[253],9,"file-link");
lf[254]=C_h_intern(&lf[254],9,"hard-link");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[256]=C_h_intern(&lf[256],12,"fileno/stdin");
lf[257]=C_h_intern(&lf[257],13,"fileno/stdout");
lf[258]=C_h_intern(&lf[258],13,"fileno/stderr");
lf[259]=C_h_intern(&lf[259],7,"\000append");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[267]=C_h_intern(&lf[267],16,"open-input-file*");
lf[268]=C_h_intern(&lf[268],17,"open-output-file*");
lf[269]=C_h_intern(&lf[269],12,"port->fileno");
lf[270]=C_h_intern(&lf[270],6,"socket");
lf[271]=C_h_intern(&lf[271],20,"\003systcp-port->fileno");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[274]=C_h_intern(&lf[274],25,"\003syspeek-unsigned-integer");
lf[275]=C_h_intern(&lf[275],16,"duplicate-fileno");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[277]=C_h_intern(&lf[277],15,"make-input-port");
lf[278]=C_h_intern(&lf[278],14,"set-port-name!");
lf[279]=C_h_intern(&lf[279],21,"\003syscustom-input-port");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[281]=C_h_intern(&lf[281],17,"\003systhread-yield!");
lf[282]=C_h_intern(&lf[282],25,"\003systhread-block-for-i/o!");
lf[283]=C_h_intern(&lf[283],18,"\003syscurrent-thread");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[288]=C_h_intern(&lf[288],17,"\003sysstring-append");
lf[289]=C_h_intern(&lf[289],15,"\003sysmake-string");
lf[290]=C_h_intern(&lf[290],20,"\003sysscan-buffer-line");
lf[291]=C_h_intern(&lf[291],4,"noop");
lf[292]=C_h_intern(&lf[292],16,"make-output-port");
lf[293]=C_h_intern(&lf[293],22,"\003syscustom-output-port");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[296]=C_h_intern(&lf[296],13,"file-truncate");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[299]=C_h_intern(&lf[299],4,"lock");
lf[300]=C_h_intern(&lf[300],9,"file-lock");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[302]=C_h_intern(&lf[302],18,"file-lock/blocking");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[304]=C_h_intern(&lf[304],14,"file-test-lock");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[306]=C_h_intern(&lf[306],11,"file-unlock");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[308]=C_h_intern(&lf[308],11,"create-fifo");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[310]=C_h_intern(&lf[310],5,"fifo\077");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[312]=C_h_intern(&lf[312],6,"setenv");
lf[313]=C_h_intern(&lf[313],8,"unsetenv");
lf[314]=C_h_intern(&lf[314],19,"current-environment");
lf[315]=C_h_intern(&lf[315],9,"prot/read");
lf[316]=C_h_intern(&lf[316],10,"prot/write");
lf[317]=C_h_intern(&lf[317],9,"prot/exec");
lf[318]=C_h_intern(&lf[318],9,"prot/none");
lf[319]=C_h_intern(&lf[319],9,"map/fixed");
lf[320]=C_h_intern(&lf[320],10,"map/shared");
lf[321]=C_h_intern(&lf[321],11,"map/private");
lf[322]=C_h_intern(&lf[322],13,"map/anonymous");
lf[323]=C_h_intern(&lf[323],8,"map/file");
lf[324]=C_h_intern(&lf[324],18,"map-file-to-memory");
lf[325]=C_h_intern(&lf[325],4,"mmap");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[327]=C_h_intern(&lf[327],20,"\003syspointer->address");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[329]=C_h_intern(&lf[329],16,"\003sysnull-pointer");
lf[330]=C_h_intern(&lf[330],22,"unmap-file-from-memory");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[332]=C_h_intern(&lf[332],26,"memory-mapped-file-pointer");
lf[333]=C_h_intern(&lf[333],19,"memory-mapped-file\077");
lf[334]=C_h_intern(&lf[334],19,"seconds->local-time");
lf[335]=C_h_intern(&lf[335],18,"\003sysdecode-seconds");
lf[336]=C_h_intern(&lf[336],17,"seconds->utc-time");
lf[337]=C_h_intern(&lf[337],15,"seconds->string");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[339]=C_h_intern(&lf[339],12,"time->string");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[342]=C_h_intern(&lf[342],19,"local-time->seconds");
lf[343]=C_h_intern(&lf[343],15,"\003syscons-flonum");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[346]=C_h_intern(&lf[346],17,"utc-time->seconds");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[349]=C_h_intern(&lf[349],27,"local-timezone-abbreviation");
lf[350]=C_h_intern(&lf[350],5,"_exit");
lf[351]=C_h_intern(&lf[351],10,"set-alarm!");
lf[352]=C_h_intern(&lf[352],19,"set-buffering-mode!");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[354]=C_h_intern(&lf[354],5,"\000full");
lf[355]=C_h_intern(&lf[355],5,"\000line");
lf[356]=C_h_intern(&lf[356],5,"\000none");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[358]=C_h_intern(&lf[358],14,"terminal-port\077");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[361]=C_h_intern(&lf[361],13,"terminal-name");
lf[362]=C_h_intern(&lf[362],13,"terminal-size");
lf[363]=C_h_intern(&lf[363],6,"\000error");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[365]=C_h_intern(&lf[365],17,"\003sysmake-locative");
lf[366]=C_h_intern(&lf[366],8,"location");
lf[367]=C_h_intern(&lf[367],13,"get-host-name");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[369]=C_h_intern(&lf[369],6,"regexp");
lf[370]=C_h_intern(&lf[370],21,"make-anchored-pattern");
lf[371]=C_h_intern(&lf[371],12,"string-match");
lf[372]=C_h_intern(&lf[372],12,"glob->regexp");
lf[373]=C_h_intern(&lf[373],13,"make-pathname");
lf[374]=C_h_intern(&lf[374],18,"decompose-pathname");
lf[375]=C_h_intern(&lf[375],4,"glob");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[378]=C_h_intern(&lf[378],12,"process-fork");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[380]=C_h_intern(&lf[380],24,"pathname-strip-directory");
lf[381]=C_h_intern(&lf[381],15,"process-execute");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[383]=C_h_intern(&lf[383],16,"\003sysprocess-wait");
lf[384]=C_h_intern(&lf[384],12,"process-wait");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[386]=C_h_intern(&lf[386],18,"current-process-id");
lf[387]=C_h_intern(&lf[387],17,"parent-process-id");
lf[388]=C_h_intern(&lf[388],5,"sleep");
lf[389]=C_h_intern(&lf[389],14,"process-signal");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[391]=C_h_intern(&lf[391],17,"\003sysshell-command");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[393]=C_h_intern(&lf[393],6,"getenv");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[395]=C_h_intern(&lf[395],27,"\003sysshell-command-arguments");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[397]=C_h_intern(&lf[397],11,"process-run");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[399]=C_h_intern(&lf[399],11,"\003sysprocess");
lf[400]=C_h_intern(&lf[400],19,"\003sysundefined-value");
lf[401]=C_h_intern(&lf[401],7,"process");
lf[402]=C_h_intern(&lf[402],8,"process*");
lf[403]=C_h_intern(&lf[403],10,"find-files");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[407]=C_h_intern(&lf[407],16,"\003sysdynamic-wind");
lf[408]=C_h_intern(&lf[408],13,"pathname-file");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[410]=C_h_intern(&lf[410],7,"regexp\077");
lf[411]=C_h_intern(&lf[411],19,"set-root-directory!");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[414]=C_h_intern(&lf[414],18,"getter-with-setter");
lf[415]=C_h_intern(&lf[415],26,"effective-group-id!-setter");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[417]=C_h_intern(&lf[417],25,"effective-user-id!-setter");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[419]=C_h_intern(&lf[419],23,"\003sysuser-interrupt-hook");
lf[420]=C_h_intern(&lf[420],11,"make-vector");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[423]=C_h_intern(&lf[423],17,"register-feature!");
lf[424]=C_h_intern(&lf[424],5,"posix");
C_register_lf2(lf,425,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1493,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1491 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1496,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1494 in k1491 */
static void C_ccall f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1499,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1497 in k1494 in k1491 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 419  register-feature! */
t3=*((C_word*)lf[423]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[424]);}

/* k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word ab[92],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1517,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1,lf[3]);
t5=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1535,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1542,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1599,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1645,a[2]=t45,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1683,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[57]+1);
t49=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1698,a[2]=t48,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1811,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1817,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1827,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t55=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1837,a[2]=t53,a[3]=t54,a[4]=t52,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t56=C_mutate((C_word*)lf[71]+1,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[72]+1,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[73]+1,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[74],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2029,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2066,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2098,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2104,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2110,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2116,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2122,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2128,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2134,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2143,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2152,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t71=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6709,a[2]=((C_word)li237),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 724  getter-with-setter */
t72=*((C_word*)lf[414]+1);
((C_proc4)C_retrieve_proc(t72))(4,t72,t70,t71,*((C_word*)lf[86]+1));}

/* a6708 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6709,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6713,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6725,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 726  port? */
t5=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6723 in a6708 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[88]);
t4=((C_word*)t0)[2];
f_6713(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_6713(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 731  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[93],lf[422],((C_word*)t0)[3]);}}}

/* k6711 in a6708 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6716,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 733  posix-error */
t3=lf[3];
f_1517(6,t3,t2,lf[48],lf[93],lf[421],((C_word*)t0)[2]);}
else{
t3=t2;
f_6716(2,t3,C_SCHEME_UNDEFINED);}}

/* k6714 in k6711 in a6708 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word ab[147],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1,t1);
t3=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2214,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2238,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2262,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[100]+1);
t7=*((C_word*)lf[57]+1);
t8=*((C_word*)lf[101]+1);
t9=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2286,a[2]=t7,a[3]=t6,a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2443,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2466,a[2]=t11,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2509,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2521,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2527,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp);
t16=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2542,a[2]=t14,a[3]=t15,a[4]=t13,a[5]=((C_word)li41),tmp=(C_word)a,a+=6,tmp));
t17=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2578,a[2]=t14,a[3]=t15,a[4]=t13,a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp));
t18=C_mutate((C_word*)lf[118]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2614,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[122]+1,*((C_word*)lf[118]+1));
t20=*((C_word*)lf[115]+1);
t21=*((C_word*)lf[117]+1);
t22=*((C_word*)lf[118]+1);
t23=*((C_word*)lf[122]+1);
t24=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2630,a[2]=t20,a[3]=t22,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2654,a[2]=t21,a[3]=t23,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
t26=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2678,a[2]=t20,a[3]=t22,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp));
t27=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2698,a[2]=t21,a[3]=t23,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp));
t28=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2718,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[131]+1,C_fix((C_word)SIGTERM));
t30=C_mutate((C_word*)lf[132]+1,C_fix((C_word)SIGKILL));
t31=C_mutate((C_word*)lf[133]+1,C_fix((C_word)SIGINT));
t32=C_mutate((C_word*)lf[134]+1,C_fix((C_word)SIGHUP));
t33=C_mutate((C_word*)lf[135]+1,C_fix((C_word)SIGFPE));
t34=C_mutate((C_word*)lf[136]+1,C_fix((C_word)SIGILL));
t35=C_mutate((C_word*)lf[137]+1,C_fix((C_word)SIGSEGV));
t36=C_mutate((C_word*)lf[138]+1,C_fix((C_word)SIGABRT));
t37=C_mutate((C_word*)lf[139]+1,C_fix((C_word)SIGTRAP));
t38=C_mutate((C_word*)lf[140]+1,C_fix((C_word)SIGQUIT));
t39=C_mutate((C_word*)lf[141]+1,C_fix((C_word)SIGALRM));
t40=C_mutate((C_word*)lf[142]+1,C_fix((C_word)SIGVTALRM));
t41=C_mutate((C_word*)lf[143]+1,C_fix((C_word)SIGPROF));
t42=C_mutate((C_word*)lf[144]+1,C_fix((C_word)SIGIO));
t43=C_mutate((C_word*)lf[145]+1,C_fix((C_word)SIGURG));
t44=C_mutate((C_word*)lf[146]+1,C_fix((C_word)SIGCHLD));
t45=C_mutate((C_word*)lf[147]+1,C_fix((C_word)SIGCONT));
t46=C_mutate((C_word*)lf[148]+1,C_fix((C_word)SIGSTOP));
t47=C_mutate((C_word*)lf[149]+1,C_fix((C_word)SIGTSTP));
t48=C_mutate((C_word*)lf[150]+1,C_fix((C_word)SIGPIPE));
t49=C_mutate((C_word*)lf[151]+1,C_fix((C_word)SIGXCPU));
t50=C_mutate((C_word*)lf[152]+1,C_fix((C_word)SIGXFSZ));
t51=C_mutate((C_word*)lf[153]+1,C_fix((C_word)SIGUSR1));
t52=C_mutate((C_word*)lf[154]+1,C_fix((C_word)SIGUSR2));
t53=C_mutate((C_word*)lf[155]+1,C_fix((C_word)SIGWINCH));
t54=(C_word)C_a_i_list(&a,25,*((C_word*)lf[131]+1),*((C_word*)lf[132]+1),*((C_word*)lf[133]+1),*((C_word*)lf[134]+1),*((C_word*)lf[135]+1),*((C_word*)lf[136]+1),*((C_word*)lf[137]+1),*((C_word*)lf[138]+1),*((C_word*)lf[139]+1),*((C_word*)lf[140]+1),*((C_word*)lf[141]+1),*((C_word*)lf[142]+1),*((C_word*)lf[143]+1),*((C_word*)lf[144]+1),*((C_word*)lf[145]+1),*((C_word*)lf[146]+1),*((C_word*)lf[147]+1),*((C_word*)lf[148]+1),*((C_word*)lf[149]+1),*((C_word*)lf[150]+1),*((C_word*)lf[151]+1),*((C_word*)lf[152]+1),*((C_word*)lf[153]+1),*((C_word*)lf[154]+1),*((C_word*)lf[155]+1));
t55=C_mutate((C_word*)lf[156]+1,t54);
t56=*((C_word*)lf[157]+1);
t57=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[2],a[3]=t56,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 960  make-vector */
t58=*((C_word*)lf[420]+1);
((C_proc4)(void*)(*((C_word*)t58+1)))(4,t58,t57,C_fix(256),C_SCHEME_FALSE);}

/* k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2765,a[2]=t1,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[159]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2774,a[2]=t1,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[157]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2787,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2805,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[163]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2829,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[164]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2861,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2867,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2882,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2898,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6703,a[2]=((C_word)li236),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1016 set-signal-handler! */
t12=*((C_word*)lf[159]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,*((C_word*)lf[133]+1),t11);}

/* a6702 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6703,3,t0,t1,t2);}
/* posixunix.scm: 1018 ##sys#user-interrupt-hook */
t3=*((C_word*)lf[419]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2900,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2955,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6700,a[2]=((C_word)li235),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1048 getter-with-setter */
t6=*((C_word*)lf[414]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,*((C_word*)lf[172]+1));}

/* a6699 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6700,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub332(C_SCHEME_UNDEFINED));}

/* k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2955,2,t0,t1);}
t2=C_mutate((C_word*)lf[174]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6682,a[2]=((C_word)li233),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6685,a[2]=((C_word)li234),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1053 getter-with-setter */
t6=*((C_word*)lf[414]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a6684 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6685,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6695,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1057 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6693 in a6684 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1058 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[417],lf[418],((C_word*)t0)[2]);}

/* a6681 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6682,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub334(C_SCHEME_UNDEFINED));}

/* k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2959,2,t0,t1);}
t2=C_mutate((C_word*)lf[175]+1,t1);
t3=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2961,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6679,a[2]=((C_word)li232),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1068 getter-with-setter */
t6=*((C_word*)lf[414]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,*((C_word*)lf[176]+1));}

/* a6678 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6679,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub340(C_SCHEME_UNDEFINED));}

/* k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=C_mutate((C_word*)lf[178]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6661,a[2]=((C_word)li230),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6664,a[2]=((C_word)li231),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1073 getter-with-setter */
t6=*((C_word*)lf[414]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a6663 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6664(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6664,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6674,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1077 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6672 in a6663 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1078 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[415],lf[416],((C_word*)t0)[2]);}

/* a6660 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6661,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub342(C_SCHEME_UNDEFINED));}

/* k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2982,2,t0,t1);}
t2=C_mutate((C_word*)lf[179]+1,t1);
t3=C_mutate((C_word*)lf[180]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[183]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3051,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[184]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3065,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[185]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3090,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[186],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3176,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[187]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[191]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3246,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[194]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3320,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[196]+1,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[197]+1,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[198]+1,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[199]+1,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[200]+1,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[201]+1,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[202]+1,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[203]+1,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[204]+1,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[205]+1,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[206]+1,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[207]+1,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[208]+1,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[209]+1,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[210]+1,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[211]+1,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[212]+1,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[213]+1,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[214]+1,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[215]+1,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[216]+1,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[217]+1,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[218]+1,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[219],0,C_fix(0));
t35=C_set_block_item(lf[220],0,C_fix(0));
t36=C_set_block_item(lf[221],0,C_fix(0));
t37=C_set_block_item(lf[222],0,C_fix(0));
t38=C_set_block_item(lf[223],0,C_fix(0));
t39=C_set_block_item(lf[224],0,C_fix(0));
t40=C_set_block_item(lf[225],0,C_fix(0));
t41=C_set_block_item(lf[226],0,C_fix(0));
t42=C_set_block_item(lf[227],0,C_fix(0));
t43=C_set_block_item(lf[228],0,C_fix(0));
t44=C_set_block_item(lf[229],0,C_fix(0));
t45=C_set_block_item(lf[230],0,C_fix(0));
t46=C_set_block_item(lf[231],0,C_fix(0));
t47=C_set_block_item(lf[232],0,C_fix(0));
t48=C_set_block_item(lf[233],0,C_fix(0));
t49=C_set_block_item(lf[234],0,C_fix(0));
t50=C_mutate((C_word*)lf[235]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3384,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[237]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3411,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3441,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[239]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3465,a[2]=t52,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[240]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3471,a[2]=t52,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[241]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3477,a[2]=t52,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t56=C_mutate((C_word*)lf[242]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3483,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[244]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3498,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3521,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6643,a[2]=((C_word)li229),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1300 getter-with-setter */
t60=*((C_word*)lf[414]+1);
((C_proc4)C_retrieve_proc(t60))(4,t60,t58,t59,*((C_word*)lf[244]+1));}

/* a6642 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6643,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[246]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6650,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6656,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1305 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_6650(2,t6,C_SCHEME_UNDEFINED);}}

/* k6654 in a6642 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1306 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[246],lf[413],((C_word*)t0)[2]);}

/* k6648 in a6642 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3521,2,t0,t1);}
t2=C_mutate((C_word*)lf[246]+1,t1);
t3=C_mutate((C_word*)lf[247]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3523,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[250]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3560,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1327 make-string */
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word ab[256],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3560,2,t0,t1);}
t2=C_mutate((C_word*)lf[251]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3561,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li88),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[253]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3611,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[256]+1,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[257]+1,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[258]+1,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3636,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3673,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
t9=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3688,a[2]=t7,a[3]=t8,a[4]=((C_word)li92),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[268]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3702,a[2]=t7,a[3]=t8,a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3716,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[275]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3761,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[277]+1);
t14=*((C_word*)lf[278]+1);
t15=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3788,a[2]=t13,a[3]=t14,a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp));
t16=*((C_word*)lf[292]+1);
t17=*((C_word*)lf[278]+1);
t18=C_mutate((C_word*)lf[293]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4224,a[2]=t16,a[3]=t17,a[4]=((C_word)li125),tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[296]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4483,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4522,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4596,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[300]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4614,a[2]=t20,a[3]=t21,a[4]=((C_word)li129),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4629,a[2]=t20,a[3]=t21,a[4]=((C_word)li130),tmp=(C_word)a,a+=5,tmp));
t24=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4644,a[2]=t20,a[3]=t21,a[4]=((C_word)li131),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[306]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4666,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4694,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4737,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[312]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4763,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4780,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[314]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4800,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[315]+1,C_fix((C_word)PROT_READ));
t32=C_mutate((C_word*)lf[316]+1,C_fix((C_word)PROT_WRITE));
t33=C_mutate((C_word*)lf[317]+1,C_fix((C_word)PROT_EXEC));
t34=C_mutate((C_word*)lf[318]+1,C_fix((C_word)PROT_NONE));
t35=C_mutate((C_word*)lf[319]+1,C_fix((C_word)MAP_FIXED));
t36=C_mutate((C_word*)lf[320]+1,C_fix((C_word)MAP_SHARED));
t37=C_mutate((C_word*)lf[321]+1,C_fix((C_word)MAP_PRIVATE));
t38=C_mutate((C_word*)lf[322]+1,C_fix((C_word)MAP_ANON));
t39=C_mutate((C_word*)lf[323]+1,C_fix((C_word)MAP_FILE));
t40=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4903,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4965,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5000,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5009,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[334]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5015,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5024,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[337]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5043,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5060,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5088,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[346]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5116,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[349]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5144,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[350]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5156,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[351]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5172,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[352]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5179,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[358]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5238,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate(&lf[359],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5257,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5289,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[362]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5312,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5347,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[369]+1);
t60=*((C_word*)lf[370]+1);
t61=*((C_word*)lf[371]+1);
t62=*((C_word*)lf[372]+1);
t63=*((C_word*)lf[102]+1);
t64=*((C_word*)lf[373]+1);
t65=*((C_word*)lf[374]+1);
t66=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5359,a[2]=t62,a[3]=t60,a[4]=t59,a[5]=t63,a[6]=t61,a[7]=t64,a[8]=t65,a[9]=((C_word)li163),tmp=(C_word)a,a+=10,tmp));
t67=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5471,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t68=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5513,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp);
t69=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5532,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
t70=*((C_word*)lf[380]+1);
t71=C_mutate((C_word*)lf[381]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5551,a[2]=t70,a[3]=t69,a[4]=t68,a[5]=((C_word)li173),tmp=(C_word)a,a+=6,tmp));
t72=C_mutate((C_word*)lf[383]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5733,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[384]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5750,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[386]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5828,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[387]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5831,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[388]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5834,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[389]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5841,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[391]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5868,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[395]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5877,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp));
t80=*((C_word*)lf[378]+1);
t81=*((C_word*)lf[381]+1);
t82=*((C_word*)lf[393]+1);
t83=C_mutate((C_word*)lf[397]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5883,a[2]=t80,a[3]=t81,a[4]=((C_word)li184),tmp=(C_word)a,a+=5,tmp));
t84=*((C_word*)lf[129]+1);
t85=*((C_word*)lf[384]+1);
t86=*((C_word*)lf[378]+1);
t87=*((C_word*)lf[381]+1);
t88=*((C_word*)lf[275]+1);
t89=*((C_word*)lf[55]+1);
t90=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5939,a[2]=t85,a[3]=((C_word)li188),tmp=(C_word)a,a+=4,tmp);
t91=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5976,a[2]=t84,a[3]=((C_word)li191),tmp=(C_word)a,a+=4,tmp);
t92=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5996,a[2]=t89,a[3]=((C_word)li192),tmp=(C_word)a,a+=4,tmp);
t93=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6010,a[2]=t89,a[3]=((C_word)li193),tmp=(C_word)a,a+=4,tmp);
t94=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6027,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp);
t95=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6043,a[2]=t91,a[3]=t86,a[4]=t93,a[5]=t87,a[6]=t94,a[7]=((C_word)li196),tmp=(C_word)a,a+=8,tmp);
t96=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6088,a[2]=t92,a[3]=((C_word)li197),tmp=(C_word)a,a+=4,tmp);
t97=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6099,a[2]=t92,a[3]=((C_word)li198),tmp=(C_word)a,a+=4,tmp);
t98=C_mutate((C_word*)lf[399]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6110,a[2]=t97,a[3]=t90,a[4]=t96,a[5]=t95,a[6]=((C_word)li201),tmp=(C_word)a,a+=7,tmp));
t99=*((C_word*)lf[400]+1);
t100=C_mutate((C_word*)lf[401]+1,t99);
t101=*((C_word*)lf[400]+1);
t102=C_mutate((C_word*)lf[402]+1,t101);
t103=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6174,a[2]=((C_word)li206),tmp=(C_word)a,a+=3,tmp);
t104=C_mutate((C_word*)lf[401]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6235,a[2]=t103,a[3]=((C_word)li210),tmp=(C_word)a,a+=4,tmp));
t105=C_mutate((C_word*)lf[402]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6295,a[2]=t103,a[3]=((C_word)li214),tmp=(C_word)a,a+=4,tmp));
t106=*((C_word*)lf[375]+1);
t107=*((C_word*)lf[371]+1);
t108=*((C_word*)lf[373]+1);
t109=*((C_word*)lf[106]+1);
t110=C_mutate((C_word*)lf[403]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6355,a[2]=t109,a[3]=t108,a[4]=t106,a[5]=t107,a[6]=((C_word)li227),tmp=(C_word)a,a+=7,tmp));
t111=C_mutate((C_word*)lf[411]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6620,a[2]=((C_word)li228),tmp=(C_word)a,a+=3,tmp));
t112=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t112+1)))(2,t112,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6620(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6620,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[411]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6612,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_foreign_string_argumentp(t4);
/* ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t6=t5;
f_6612(2,t6,C_SCHEME_FALSE);}}

/* k6610 in set-root-directory! in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1243(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2157 posix-error */
t3=lf[3];
f_1517(6,t3,((C_word*)t0)[3],lf[48],lf[411],lf[412],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_6355r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6355r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6355r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li222),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6528,a[2]=t5,a[3]=((C_word)li223),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6533,a[2]=t6,a[3]=((C_word)li224),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6538,a[2]=t7,a[3]=((C_word)li226),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action11961232 */
t9=t8;
f_6538(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id11971230 */
t11=t7;
f_6533(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit11981227 */
t13=t6;
f_6528(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body11941200 */
t15=t5;
f_6357(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action1196 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6538,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6544,a[2]=((C_word)li225),tmp=(C_word)a,a+=3,tmp);
/* def-id11971230 */
t3=((C_word*)t0)[2];
f_6533(t3,t1,t2);}

/* a6543 in def-action1196 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6544,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1197 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6533(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6533,NULL,3,t0,t1,t2);}
/* def-limit11981227 */
t3=((C_word*)t0)[2];
f_6528(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1198 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6528(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6528,NULL,4,t0,t1,t2,t3);}
/* body11941200 */
t4=((C_word*)t0)[2];
f_6357(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6357(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6357,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[403]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6364,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_6364(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6523,a[2]=t4,a[3]=t7,a[4]=((C_word)li220),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_6364(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6515,a[2]=((C_word)li221),tmp=(C_word)a,a+=3,tmp));}}

/* f_6515 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6515(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6515,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_6523 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6523,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6364(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6364,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_6503(2,t4,t2);}
else{
/* posixunix.scm: 2129 regexp? */
t4=*((C_word*)lf[410]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[11]);}}

/* k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6503,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6504,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word)li215),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6374,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6497,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2132 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[409]);}

/* k6495 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2132 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6374,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6376,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li219),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6376(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6376(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6376,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2138 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6395,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2139 pathname-file */
t3=*((C_word*)lf[408]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6483,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2146 pproc */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k6481 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6483,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6490,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2146 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2147 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6376(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k6488 in k6481 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2146 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6376(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6477,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[404]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[405]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2139 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_6376(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2140 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k6408 in k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6410,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6422,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,a[5]=((C_word)li216),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word)li217),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6454,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,a[5]=((C_word)li218),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2142 ##sys#dynamic-wind */
t11=*((C_word*)lf[407]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6467,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6470,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2145 pproc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k6468 in k6408 in k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2145 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_6467(2,t2,((C_word*)t0)[2]);}}

/* k6465 in k6408 in k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2145 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6376(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6453 in k6408 in k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[400]+1));}

/* a6429 in k6408 in k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6438,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6452,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2143 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],lf[406]);}

/* k6450 in a6429 in k6408 in k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2143 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6436 in a6429 in k6408 in k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6442,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2144 pproc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k6443 in k6436 in a6429 in k6408 in k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2144 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_6442(2,t2,((C_word*)t0)[2]);}}

/* k6440 in k6436 in a6429 in k6408 in k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2143 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6376(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6421 in k6408 in k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6422,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[400]+1));}

/* k6418 in k6408 in k6475 in k6393 in loop in k6372 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2141 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6376(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6504 in k6501 in k6362 in body1194 in find-files in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6504,3,t0,t1,t2);}
/* posixunix.scm: 2130 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6295(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_6295r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6295r(t0,t1,t2,t3);}}

static void C_ccall f_6295r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6297,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li211),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6302,a[2]=t4,a[3]=((C_word)li212),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6307,a[2]=t5,a[3]=((C_word)li213),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args11701178 */
t7=t6;
f_6307(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env11711176 */
t9=t5;
f_6302(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body11681173 */
t11=t4;
f_6297(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args1170 in process* in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6307,NULL,2,t0,t1);}
/* def-env11711176 */
t2=((C_word*)t0)[2];
f_6302(t2,t1,C_SCHEME_FALSE);}

/* def-env1171 in process* in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6302(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6302,NULL,3,t0,t1,t2);}
/* body11681173 */
t3=((C_word*)t0)[2];
f_6297(t3,t1,t2,C_SCHEME_FALSE);}

/* body1168 in process* in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6297(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6297,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2107 %process */
f_6174(t1,lf[402],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6235(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_6235r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6235r(t0,t1,t2,t3);}}

static void C_ccall f_6235r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6237,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li207),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6242,a[2]=t4,a[3]=((C_word)li208),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6247,a[2]=t5,a[3]=((C_word)li209),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args11501158 */
t7=t6;
f_6247(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env11511156 */
t9=t5;
f_6242(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body11481153 */
t11=t4;
f_6237(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args1150 in process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6247(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6247,NULL,2,t0,t1);}
/* def-env11511156 */
t2=((C_word*)t0)[2];
f_6242(t2,t1,C_SCHEME_FALSE);}

/* def-env1151 in process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6242,NULL,3,t0,t1,t2);}
/* body11481153 */
t3=((C_word*)t0)[2];
f_6237(t3,t1,t2,C_SCHEME_FALSE);}

/* body1148 in process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6237(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6237,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2104 %process */
f_6174(t1,lf[401],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6174(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6174,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6176,a[2]=t2,a[3]=((C_word)li203),tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6195,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2093 chkstrlst */
t12=t9;
f_6176(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6229,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2095 ##sys#shell-command-arguments */
t13=*((C_word*)lf[395]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)t7)[1]);}}

/* k6227 in %process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6229,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2096 ##sys#shell-command */
t4=*((C_word*)lf[391]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6231 in k6227 in %process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6195(2,t3,t2);}

/* k6193 in %process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2097 chkstrlst */
t3=((C_word*)t0)[2];
f_6176(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6198(2,t3,C_SCHEME_UNDEFINED);}}

/* k6196 in k6193 in %process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li204),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6209,a[2]=((C_word*)t0)[3],a[3]=((C_word)li205),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2098 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6208 in k6196 in k6193 in %process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6209,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2100 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2101 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a6202 in k6196 in k6193 in %process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6203,2,t0,t1);}
/* posixunix.scm: 2098 ##sys#process */
t2=*((C_word*)lf[399]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6176(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6176,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6185,a[2]=((C_word*)t0)[2],a[3]=((C_word)li202),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6184 in chkstrlst in %process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6185,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6110,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6116,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word)li199),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,a[10]=((C_word)li200),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a6121 in ##sys#process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6122,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6133,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6153,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2074 make-on-close */
t12=((C_word*)t0)[3];
f_5939(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k6151 in a6121 in ##sys#process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2073 input-port */
t2=((C_word*)t0)[7];
f_6088(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6131 in a6121 in ##sys#process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6137,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2076 make-on-close */
t4=((C_word*)t0)[6];
f_5939(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k6147 in k6131 in a6121 in ##sys#process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2075 output-port */
t2=((C_word*)t0)[7];
f_6099(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6135 in k6131 in a6121 in ##sys#process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6141,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6145,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2079 make-on-close */
t4=((C_word*)t0)[3];
f_5939(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k6143 in k6135 in k6131 in a6121 in ##sys#process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2078 input-port */
t2=((C_word*)t0)[7];
f_6088(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6139 in k6135 in k6131 in a6121 in ##sys#process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2072 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6115 in ##sys#process in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6116,2,t0,t1);}
/* posixunix.scm: 2067 spawn */
t2=((C_word*)t0)[8];
f_6043(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6099(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6099,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6103,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2063 connect-parent */
t8=((C_word*)t0)[2];
f_5996(t8,t7,t4,t5);}

/* k6101 in output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2064 ##sys#custom-output-port */
t2=*((C_word*)lf[293]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6088(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6088,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6092,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2059 connect-parent */
t8=((C_word*)t0)[2];
f_5996(t8,t7,t4,t5);}

/* k6090 in input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2060 ##sys#custom-input-port */
t2=*((C_word*)lf[279]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6043(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6043,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2046 needed-pipe */
t9=((C_word*)t0)[2];
f_5976(t9,t8,t6);}

/* k6045 in spawn in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2047 needed-pipe */
t3=((C_word*)t0)[2];
f_5976(t3,t2,((C_word*)t0)[5]);}

/* k6048 in k6045 in spawn in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6053,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2048 needed-pipe */
t3=((C_word*)t0)[2];
f_5976(t3,t2,((C_word*)t0)[6]);}

/* k6051 in k6048 in k6045 in spawn in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6053,2,t0,t1);}
t2=f_6027(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6064,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word)li195),tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2051 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6065 in k6051 in k6048 in k6045 in spawn in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6070,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2053 connect-child */
t3=((C_word*)t0)[7];
f_6010(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[256]+1));}

/* k6068 in a6065 in k6051 in k6048 in k6045 in spawn in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6073,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_6027(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2054 connect-child */
t4=((C_word*)t0)[5];
f_6010(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[257]+1));}

/* k6071 in k6068 in a6065 in k6051 in k6048 in k6045 in spawn in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6076,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_6027(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2055 connect-child */
t4=((C_word*)t0)[3];
f_6010(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[258]+1));}

/* k6074 in k6071 in k6068 in a6065 in k6051 in k6048 in k6045 in spawn in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2056 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6062 in k6051 in k6048 in k6045 in spawn in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2049 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_6027(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6010(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6010,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6023,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2037 file-close */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k6021 in connect-child in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6023,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5935,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2011 duplicate-fileno */
t6=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k5933 in k6021 in connect-child in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2012 file-close */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5996(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5996,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6009,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2031 file-close */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6007 in connect-parent in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5976(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5976,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5985,a[2]=((C_word*)t0)[2],a[3]=((C_word)li189),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5991,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2026 ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a5990 in needed-pipe in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5991,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a5984 in needed-pipe in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5985,2,t0,t1);}
/* posixunix.scm: 2026 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* make-on-close in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5939(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5939,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5941,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,a[9]=((C_word)li187),tmp=(C_word)a,a+=10,tmp));}

/* f_5941 in make-on-close in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5941,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li185),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li186),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2019 ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a5961 */
static void C_ccall f_5962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5962,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2021 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[161],((C_word*)t0)[3],lf[398],((C_word*)t0)[2],t4);}}

/* a5955 */
static void C_ccall f_5956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5956,2,t0,t1);}
/* posixunix.scm: 2019 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5883(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5883r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5883r(t0,t1,t2,t3);}}

static void C_ccall f_5883r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5890,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1975 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k5888 in process-run in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5890,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 1977 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1979 ##sys#shell-command */
t4=*((C_word*)lf[391]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k5907 in k5888 in process-run in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5913,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1979 ##sys#shell-command-arguments */
t3=*((C_word*)lf[395]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5911 in k5907 in k5888 in process-run in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1979 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5877,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[396],t2));}

/* ##sys#shell-command in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5872,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1964 getenv */
t3=*((C_word*)lf[393]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[394]);}

/* k5870 in ##sys#shell-command in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[392]));}

/* process-signal in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5841r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5841r(t0,t1,t2,t3);}}

static void C_ccall f_5841r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[389]);
t7=(C_word)C_i_check_exact_2(t5,lf[389]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 1961 posix-error */
t10=lf[3];
f_1517(7,t10,t1,lf[161],lf[389],lf[390],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5834,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1016(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5831,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1013(C_SCHEME_UNDEFINED));}

/* current-process-id in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5828,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1011(C_SCHEME_UNDEFINED));}

/* process-wait in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_5750r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5750r(t0,t1,t2);}}

static void C_ccall f_5750r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[384]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5780,a[2]=t8,a[3]=t11,a[4]=((C_word)li175),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5786,a[2]=t11,a[3]=((C_word)li176),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1945 ##sys#call-with-values */
C_call_with_values(4,0,t1,t13,t14);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* a5785 in process-wait in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5786,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 1947 posix-error */
t6=lf[3];
f_1517(6,t6,t1,lf[161],lf[384],lf[385],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1948 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a5779 in process-wait in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5780,2,t0,t1);}
/* posixunix.scm: 1945 ##sys#process-wait */
t2=*((C_word*)lf[383]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5733,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 1932 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_5551r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5551r(t0,t1,t2,t3);}}

static void C_ccall f_5551r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li170),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5680,a[2]=t4,a[3]=((C_word)li171),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5685,a[2]=t5,a[3]=((C_word)li172),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist951986 */
t7=t6;
f_5685(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist952984 */
t9=t5;
f_5680(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body949954 */
t11=t4;
f_5553(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist951 in process-execute in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5685(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5685,NULL,2,t0,t1);}
/* def-envlist952984 */
t2=((C_word*)t0)[2];
f_5680(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist952 in process-execute in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5680(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5680,NULL,3,t0,t1,t2);}
/* body949954 */
t3=((C_word*)t0)[2];
f_5553(t3,t1,t2,C_SCHEME_FALSE);}

/* body949 in process-execute in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5553(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5553,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[381]);
t5=(C_word)C_i_check_list_2(t2,lf[381]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5563,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1900 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k5561 in body949 in process-execute in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5563,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_5513(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5571,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li169),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_5571(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do958 in k5561 in body949 in process-execute in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5571(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5571,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_5513(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5584,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[381]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[3],a[3]=((C_word)li168),tmp=(C_word)a,a+=4,tmp);
t8=t5;
f_5584(t8,f_5617(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_5584(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[381]);
t6=(C_word)C_block_size(t4);
t7=f_5513(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* do962 in do958 in k5561 in body949 in process-execute in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_5617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_5532(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[381]);
t5=(C_word)C_block_size(t3);
t6=f_5532(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k5582 in do958 in k5561 in body949 in process-execute in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5584(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5584,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5609,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1914 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5607 in k5582 in do958 in k5561 in body949 in process-execute in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1914 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5585 in k5582 in do958 in k5561 in body949 in process-execute in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub930(C_SCHEME_UNDEFINED);
t5=(C_word)stub942(C_SCHEME_UNDEFINED);
/* posixunix.scm: 1921 posix-error */
t6=lf[3];
f_1517(6,t6,((C_word*)t0)[3],lf[161],lf[381],lf[382],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_5532(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub935(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_5513(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub923(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5471r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5471r(t0,t1,t2);}}

static void C_ccall f_5471r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub906(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 1885 posix-error */
t5=lf[3];
f_1517(5,t5,t1,lf[161],lf[378],lf[379]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5493,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_vector_ref(t2,C_fix(0));
t9=t8;
((C_proc2)C_retrieve_proc(t9))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k5491 in process-fork in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5497,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_5497 in k5491 in process-fork in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5497,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub911(C_SCHEME_UNDEFINED,t3));}

/* glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5359(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_5359r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5359r(t0,t1,t2);}}

static void C_ccall f_5359r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li162),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_5365(t6,t1,t2);}

/* conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5365(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5365,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5380,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li159),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li161),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a5385 in conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5386,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5463,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[377]);
/* posixunix.scm: 1869 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k5461 in a5385 in conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1869 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5388 in a5385 in conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5393,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixunix.scm: 1870 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5391 in k5388 in a5385 in conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5396,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1871 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5394 in k5391 in k5388 in a5385 in conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5403,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[376]);
/* posixunix.scm: 1872 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k5401 in k5394 in k5391 in k5388 in a5385 in conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5403,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li160),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_5405(t5,((C_word*)t0)[2],t1);}

/* loop in k5401 in k5394 in k5391 in k5388 in a5385 in conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5405(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5405,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixunix.scm: 1873 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5365(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5422,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixunix.scm: 1874 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k5420 in loop in k5401 in k5394 in k5391 in k5388 in a5385 in conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5422,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5432,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixunix.scm: 1875 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixunix.scm: 1876 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5405(t3,((C_word*)t0)[6],t2);}}

/* k5430 in k5420 in loop in k5401 in k5394 in k5391 in k5388 in a5385 in conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5436,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixunix.scm: 1875 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5405(t4,t2,t3);}

/* k5434 in k5430 in k5420 in loop in k5401 in k5394 in k5391 in k5388 in a5385 in conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5436,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a5379 in conc-loop in glob in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5380,2,t0,t1);}
/* posixunix.scm: 1868 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5351,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub866(t3),C_fix(0));}

/* k5349 in get-host-name in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5354,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_5354(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1849 posix-error */
t3=lf[3];
f_1517(5,t3,t2,lf[363],lf[367],lf[368]);}}

/* k5352 in k5349 in get-host-name in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5312,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5316,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1830 ##sys#terminal-check */
f_5257(t3,lf[362],t2);}

/* k5314 in terminal-size in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5316,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5336,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
t5=*((C_word*)lf[365]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[366]);}

/* k5334 in k5314 in terminal-size in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[365]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[366]);}

/* k5338 in k5334 in k5314 in terminal-size in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_pointer_argumentp(t3);
t6=(C_word)C_i_foreign_pointer_argumentp(t1);
t7=(C_word)stub852(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(C_word)C_eqp(C_fix(0),t7);
if(C_truep(t8)){
/* posixunix.scm: 1837 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 1838 posix-error */
t9=lf[3];
f_1517(6,t9,((C_word*)t0)[4],lf[363],lf[362],lf[364],((C_word*)t0)[6]);}}

/* terminal-name in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5289,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5293,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1822 ##sys#terminal-check */
f_5257(t3,lf[361],t2);}

/* k5291 in terminal-name in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5293,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub842(t4,t5);
/* ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* ##sys#terminal-check in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5257(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5257,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5261,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1814 ##sys#check-port */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k5259 in ##sys#terminal-check in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[88],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1817 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[360],((C_word*)t0)[4]);}}

/* terminal-port? in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5238,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5242,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1809 ##sys#check-port */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[358]);}

/* k5240 in terminal-port? in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1810 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[274]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k5243 in k5240 in terminal-port? in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5179r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5179r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5179r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5183,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1794 ##sys#check-port */
t6=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[352]);}

/* k5181 in set-buffering-mode! in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5183,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[354]);
if(C_truep(t6)){
t7=t5;
f_5189(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t7)){
t8=t5;
f_5189(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t8)){
t9=t5;
f_5189(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 1800 ##sys#error */
t9=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[352],lf[357],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k5187 in k5181 in set-buffering-mode! in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[352]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[88],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 1806 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[352],lf[353],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5172,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub822(C_SCHEME_UNDEFINED,t3));}

/* _exit in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5156r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5156r(t0,t1,t2);}}

static void C_ccall f_5156r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub817(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5144,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub812(t2),C_fix(0));}

/* utc-time->seconds in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5116,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[346]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5123,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1761 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[346],lf[348],t2);}
else{
t6=t4;
f_5123(2,t6,C_SCHEME_UNDEFINED);}}

/* k5121 in utc-time->seconds in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 1763 ##sys#cons-flonum */
t2=*((C_word*)lf[343]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1764 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[346],lf[347],((C_word*)t0)[3]);}}

/* local-time->seconds in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5088,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[342]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5095,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1754 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[342],lf[345],t2);}
else{
t6=t4;
f_5095(2,t6,C_SCHEME_UNDEFINED);}}

/* k5093 in local-time->seconds in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 1756 ##sys#cons-flonum */
t2=*((C_word*)lf[343]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1757 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[342],lf[344],((C_word*)t0)[3]);}}

/* time->string in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5060,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[339]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5067,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1747 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[339],lf[341],t2);}
else{
t6=t4;
f_5067(2,t6,C_SCHEME_UNDEFINED);}}

/* k5065 in time->string in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub797(t4,t3),C_fix(0));}

/* k5068 in k5065 in time->string in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5073,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_5073(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1749 ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[339],lf[340],((C_word*)t0)[2]);}}

/* k5071 in k5068 in k5065 in time->string in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* seconds->string in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5043,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5047,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub788(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k5045 in seconds->string in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5050,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_5050(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1740 ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[337],lf[338],((C_word*)t0)[2]);}}

/* k5048 in k5045 in seconds->string in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* seconds->utc-time in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5024,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[336]);
/* posixunix.scm: 1734 ##sys#decode-seconds */
t4=*((C_word*)lf[335]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5015,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[334]);
/* posixunix.scm: 1730 ##sys#decode-seconds */
t4=*((C_word*)lf[335]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* memory-mapped-file? in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5009,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[325]));}

/* memory-mapped-file-pointer in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5000,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[325],lf[332]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4965r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4965r(t0,t1,t2,t3);}}

static void C_ccall f_4965r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_i_check_structure_2(t2,lf[325],lf[330]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub769(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1717 posix-error */
t12=lf[3];
f_1517(7,t12,t1,lf[48],lf[330],lf[331],t2,t6);}}

/* map-file-to-memory in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_4903r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_4903r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_4903r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4907,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_4907(2,t10,t2);}
else{
/* posixunix.scm: 1702 ##sys#null-pointer */
t10=*((C_word*)lf[329]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k4905 in map-file-to-memory in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4907,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_4913(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1705 ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[60],lf[324],lf[328],t1);}}

/* k4911 in k4905 in map-file-to-memory in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub744(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4919,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4932,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1707 ##sys#pointer->address */
t17=*((C_word*)lf[327]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,t14);}

/* k4930 in k4911 in k4905 in map-file-to-memory in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1708 posix-error */
t3=lf[3];
f_1517(11,t3,((C_word*)t0)[8],lf[48],lf[324],lf[326],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_4919(2,t3,C_SCHEME_UNDEFINED);}}

/* k4917 in k4911 in k4905 in map-file-to-memory in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4919,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[325],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* current-environment in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4800,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4806,a[2]=t3,a[3]=((C_word)li138),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4806(t5,t1,C_fix(0));}

/* loop in current-environment in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4806(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4806,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4810,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub726(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4808 in loop in current-environment in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4818,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li137),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_4818(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k4808 in loop in current-environment in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4818(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4818,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1669 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1672 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k4842 in scan in k4808 in loop in current-environment in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1670 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k4846 in k4842 in scan in k4808 in loop in current-environment in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4836,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1671 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4806(t5,t3,t4);}

/* k4834 in k4846 in k4842 in scan in k4808 in loop in current-environment in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4780,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[313]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4788,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1658 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4786 in unsetenv in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4763,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[312]);
t5=(C_word)C_i_check_string_2(t3,lf[312]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4774,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1653 ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4772 in setenv in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1653 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4776 in k4772 in setenv in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4737,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[310]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4744,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4761,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1642 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4759 in fifo? in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1642 ##sys#file-info */
t2=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4742 in fifo? in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1645 posix-error */
t2=lf[3];
f_1517(6,t2,((C_word*)t0)[3],lf[48],lf[310],lf[311],((C_word*)t0)[2]);}}

/* create-fifo in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4694r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4694r(t0,t1,t2,t3);}}

static void C_ccall f_4694r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[308]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4701,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_4701(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_4701(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k4699 in create-fifo in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4701,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[308]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4722,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1636 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k4720 in k4699 in create-fifo in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1636 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4716 in k4699 in create-fifo in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1637 posix-error */
t3=lf[3];
f_1517(7,t3,((C_word*)t0)[3],lf[48],lf[308],lf[309],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4666,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[299],lf[306]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1626 posix-error */
t9=lf[3];
f_1517(6,t9,t1,lf[48],lf[306],lf[307],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4644r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4644r(t0,t1,t2,t3);}}

static void C_ccall f_4644r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1617 setup */
f_4522(t4,t2,t3,lf[304]);}

/* k4646 in file-test-lock in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1619 err */
f_4596(((C_word*)t0)[3],lf[305],t1,lf[304]);}}

/* file-lock/blocking in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4629r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4629r(t0,t1,t2,t3);}}

static void C_ccall f_4629r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4633,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1611 setup */
f_4522(t4,t2,t3,lf[302]);}

/* k4631 in file-lock/blocking in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1613 err */
f_4596(((C_word*)t0)[2],lf[303],t1,lf[302]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4614(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4614r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4614r(t0,t1,t2,t3);}}

static void C_ccall f_4614r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4618,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1605 setup */
f_4522(t4,t2,t3,lf[300]);}

/* k4616 in file-lock in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1607 err */
f_4596(((C_word*)t0)[2],lf[301],t1,lf[300]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4596(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4596,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1602 posix-error */
t8=lf[3];
f_1517(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4522(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4522,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4544,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1594 ##sys#check-port */
t16=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k4542 in setup in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4544,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_4550(t6,t5);}
else{
t5=t3;
f_4550(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k4548 in k4542 in setup in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4550(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4550,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[299],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4483,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[296]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4500,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4507,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4511,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1577 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_4500(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1579 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[296],lf[298],t2);}}}

/* k4509 in file-truncate in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1577 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4505 in file-truncate in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4500(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k4498 in file-truncate in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1581 posix-error */
t2=lf[3];
f_1517(7,t2,((C_word*)t0)[4],lf[48],lf[296],lf[297],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_4224r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4224r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4224r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li121),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4410,a[2]=t6,a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4415,a[2]=t7,a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4420,a[2]=t8,a[3]=((C_word)li124),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?618659 */
t10=t9;
f_4420(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi619657 */
t12=t8;
f_4415(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close620654 */
t14=t7;
f_4410(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* body616622 */
t16=t6;
f_4226(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-nonblocking?618 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4420,NULL,2,t0,t1);}
/* def-bufi619657 */
t2=((C_word*)t0)[2];
f_4415(t2,t1,C_SCHEME_FALSE);}

/* def-bufi619 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4415(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4415,NULL,3,t0,t1,t2);}
/* def-on-close620654 */
t3=((C_word*)t0)[2];
f_4410(t3,t1,t2,C_fix(0));}

/* def-on-close620 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4410(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4410,NULL,4,t0,t1,t2,t3);}
/* body616622 */
t4=((C_word*)t0)[2];
f_4226(t4,t1,t2,t3,*((C_word*)lf[291]+1));}

/* body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4226(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4226,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4230,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1519 ##sys#file-nonblocking! */
t6=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_4230(2,t6,C_SCHEME_UNDEFINED);}}

/* k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4230,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4232,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word)li114),tmp=(C_word)a,a+=7,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_4278(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4322,a[2]=t3,a[3]=((C_word)li118),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4336,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1538 ##sys#make-string */
t12=*((C_word*)lf[289]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_4336(2,t12,((C_word*)t0)[6]);}}}

/* k4334 in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4336,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_4278(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4337,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li120),tmp=(C_word)a,a+=7,tmp));}

/* f_4337 in k4334 in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4337,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4354,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word)li119),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_4354(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1554 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4232(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_4354(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4354,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4364,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1544 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_4232(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_difference(t4,t2);
/* posixunix.scm: 1549 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k4362 in loop */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1546 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4354(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_4322 in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4322,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1537 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4232(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4276 in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4278(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4278,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4282,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4287,a[2]=((C_word*)t0)[9],a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li116),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4314,a[2]=((C_word*)t0)[9],a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1557 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t5,t6,t7,t8);}

/* a4313 in k4276 in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4314,2,t0,t1);}
/* posixunix.scm: 1567 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* a4292 in k4276 in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4293,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4303,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1564 posix-error */
t3=lf[3];
f_1517(7,t3,t2,lf[48],((C_word*)t0)[3],lf[295],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_4303(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4301 in a4292 in k4276 in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1565 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a4286 in k4276 in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4287,3,t0,t1,t2);}
/* posixunix.scm: 1559 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* k4280 in k4276 in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4282,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4285,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1568 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k4283 in k4280 in k4276 in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4232(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4232,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4248,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1527 ##sys#thread-yield! */
t8=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1529 posix-error */
t7=lf[3];
f_1517(7,t7,t1,((C_word*)t0)[3],lf[48],lf[294],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4267,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1531 ##sys#substring */
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4265 in poke in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1531 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4232(t3,((C_word*)t0)[2],t1,t2);}

/* k4246 in poke in k4228 in body616 in ##sys#custom-output-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1528 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4232(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_3788r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3788r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3788r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,a[7]=((C_word)li108),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4131,a[2]=t6,a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4136,a[2]=t7,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4141,a[2]=t8,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4146,a[2]=t9,a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?521597 */
t11=t10;
f_4146(t11,t1);}
else{
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi522595 */
t13=t9;
f_4141(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close523592 */
t15=t8;
f_4136(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?524588 */
t17=t7;
f_4131(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
/* body519526 */
t19=t6;
f_3790(t19,t1,t11,t13,t15,t17);}
else{
/* ##sys#error */
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[0],t18);}}}}}}

/* def-nonblocking?521 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4146,NULL,2,t0,t1);}
/* def-bufi522595 */
t2=((C_word*)t0)[2];
f_4141(t2,t1,C_SCHEME_FALSE);}

/* def-bufi522 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4141(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4141,NULL,3,t0,t1,t2);}
/* def-on-close523592 */
t3=((C_word*)t0)[2];
f_4136(t3,t1,t2,C_fix(1));}

/* def-on-close523 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4136(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4136,NULL,4,t0,t1,t2,t3);}
/* def-more?524588 */
t4=((C_word*)t0)[2];
f_4131(t4,t1,t2,t3,*((C_word*)lf[291]+1));}

/* def-more?524 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4131(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4131,NULL,5,t0,t1,t2,t3,t4);}
/* body519526 */
t5=((C_word*)t0)[2];
f_3790(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3790(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3790,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3794,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1408 ##sys#file-nonblocking! */
t7=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_3794(2,t7,C_SCHEME_UNDEFINED);}}

/* k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3794,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1410 ##sys#make-string */
t5=*((C_word*)lf[289]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_3800(2,t5,((C_word*)t0)[10]);}}

/* k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3801,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li96),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3816,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,a[10]=((C_word)li98),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3911,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word)li99),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3924,a[2]=t6,a[3]=t3,a[4]=t5,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=((C_word)li101),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3957,a[2]=t8,a[3]=t7,a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3966,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li104),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4031,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li107),tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1454 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t18))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a4030 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4031,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4037,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li106),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_4037(t7,t1,C_SCHEME_FALSE);}

/* loop in a4030 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4037(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4037,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],a[9]=((C_word)li105),tmp=(C_word)a,a+=10,tmp);
/* posixunix.scm: 1491 ##sys#scan-buffer-line */
t4=*((C_word*)lf[290]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4106,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1506 fetch */
t4=((C_word*)t0)[3];
f_3824(t4,t3);}}

/* k4104 in loop in a4030 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1508 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4037(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a4048 in loop in a4030 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4049,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
/* posixunix.scm: 1494 ##sys#make-string */
t6=*((C_word*)lf[289]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k4051 in a4048 in loop in a4030 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
t2=(C_word)C_substring_copy(((C_word*)t0)[11],t1,((C_word*)((C_word*)t0)[10])[1],((C_word*)t0)[9],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[8]);
t4=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4063,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1498 fetch */
t6=((C_word*)t0)[3];
f_3824(t6,t5);}
else{
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t6=(C_word)C_fixnum_plus(t5,C_fix(1));
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t6);
if(C_truep(((C_word*)t0)[6])){
/* posixunix.scm: 1504 ##sys#string-append */
t8=*((C_word*)lf[288]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[5],((C_word*)t0)[6],t1);}
else{
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}}}

/* k4061 in k4051 in a4048 in loop in a4030 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[287]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 1501 ##sys#string-append */
t3=*((C_word*)lf[288]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_4079(2,t3,((C_word*)t0)[2]);}}}

/* k4077 in k4061 in k4051 in a4048 in loop in a4030 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1501 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4037(t2,((C_word*)t0)[2],t1);}

/* a3965 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3966,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li103),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_3972(t9,t1,t3,C_fix(0),t5);}

/* loop in a3965 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3972(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3972,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* posixunix.scm: 1482 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4020,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1484 fetch */
t7=((C_word*)t0)[2];
f_3824(t7,t6);}}}

/* k4018 in loop in a3965 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1487 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3972(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a3956 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1472 fetch */
t3=((C_word*)t0)[2];
f_3824(t3,t2);}

/* k3959 in a3956 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1473 peek */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_3816(((C_word*)t0)[2]));}

/* a3935 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3936,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3946,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1469 posix-error */
t3=lf[3];
f_1517(7,t3,t2,lf[48],((C_word*)t0)[3],lf[286],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_3946(2,t3,C_SCHEME_UNDEFINED);}}}

/* k3944 in a3935 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1470 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a3923 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1464 ready? */
t3=((C_word*)t0)[2];
f_3801(t3,t1);}}

/* a3910 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3915,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1456 fetch */
t3=((C_word*)t0)[2];
f_3824(t3,t2);}

/* k3913 in a3910 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_3816(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k3904 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1510 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k3907 in k3904 in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3824,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li97),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_3836(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3836,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3852,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1431 ##sys#thread-block-for-i/o! */
t6=*((C_word*)lf[282]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[283]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1434 posix-error */
t5=lf[3];
f_1517(7,t5,t1,lf[48],((C_word*)t0)[6],lf[284],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3873,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1438 more? */
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k3871 in loop in fetch in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3873,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3876,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1440 ##sys#thread-yield! */
t3=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_3882(2,t8,t7);}
else{
/* posixunix.scm: 1446 posix-error */
t7=lf[3];
f_1517(7,t7,t4,lf[48],((C_word*)t0)[3],lf[285],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_3882(2,t6,C_SCHEME_UNDEFINED);}}}

/* k3880 in k3871 in loop in fetch in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3874 in k3871 in loop in fetch in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1441 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3836(t2,((C_word*)t0)[2]);}

/* k3850 in loop in fetch in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1432 ##sys#thread-yield! */
t3=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3853 in k3850 in loop in fetch in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1433 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3836(t2,((C_word*)t0)[2]);}

/* peek in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_3816(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3801,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1416 ##sys#file-select-one */
t3=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k3813 in ready? in k3798 in k3792 in body519 in ##sys#custom-input-port in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1417 posix-error */
t3=lf[3];
f_1517(7,t3,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[280],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* duplicate-fileno in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3761r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3761r(t0,t1,t2,t3);}}

static void C_ccall f_3761r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[275]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3768,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_3768(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[275]);
t8=t5;
f_3768(t8,(C_word)C_dup2(t2,t6));}}

/* k3766 in duplicate-fileno in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3768(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3768,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3771,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1399 posix-error */
t3=lf[3];
f_1517(6,t3,t2,lf[48],lf[275],lf[276],((C_word*)t0)[2]);}
else{
t3=t2;
f_3771(2,t3,C_SCHEME_UNDEFINED);}}

/* k3769 in k3766 in duplicate-fileno in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3716(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3716,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3720,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1381 ##sys#check-port */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[269]);}

/* k3718 in port->fileno in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3720,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[270],t2);
if(C_truep(t3)){
/* posixunix.scm: 1382 ##sys#tcp-port->fileno */
t4=*((C_word*)lf[271]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1383 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[274]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k3753 in k3718 in port->fileno in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3755,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1388 posix-error */
t2=lf[3];
f_1517(6,t2,((C_word*)t0)[3],lf[60],lf[269],lf[272],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3738,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1386 posix-error */
t4=lf[3];
f_1517(6,t4,t3,lf[48],lf[269],lf[273],((C_word*)t0)[2]);}
else{
t4=t3;
f_3738(2,t4,C_SCHEME_UNDEFINED);}}}

/* k3736 in k3753 in k3718 in port->fileno in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3702r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3702r(t0,t1,t2,t3);}}

static void C_ccall f_3702r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[268]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3714,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1377 mode */
f_3636(t5,C_SCHEME_FALSE,t3);}

/* k3712 in open-output-file* in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3714,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1377 check */
f_3673(((C_word*)t0)[2],lf[268],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3688r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3688r(t0,t1,t2,t3);}}

static void C_ccall f_3688r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[267]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3700,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1373 mode */
f_3636(t5,C_SCHEME_TRUE,t3);}

/* k3698 in open-input-file* in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1373 check */
f_3673(((C_word*)t0)[2],lf[267],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3673(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3673,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1366 posix-error */
t6=lf[3];
f_1517(6,t6,t1,lf[48],t2,lf[265],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3686,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1367 ##sys#make-port */
t7=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[113]+1),lf[266],lf[88]);}}

/* k3684 in check in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3636(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3636,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3644,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[259]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1360 ##sys#error */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[260],t5);}
else{
t8=t4;
f_3644(2,t8,lf[261]);}}
else{
/* posixunix.scm: 1361 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[262],t5);}}
else{
t5=t4;
f_3644(2,t5,(C_truep(t2)?lf[263]:lf[264]));}}

/* k3642 in mode in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1356 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3611,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[253]);
t5=(C_word)C_i_check_string_2(t3,lf[253]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3592,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_3592(2,t9,C_SCHEME_FALSE);}}

/* k3590 in file-link in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3596,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_3596(2,t3,C_SCHEME_FALSE);}}

/* k3594 in k3590 in file-link in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub463(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1341 posix-error */
t3=lf[3];
f_1517(7,t3,((C_word*)t0)[4],lf[48],lf[254],lf[255],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3561,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[251]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3569,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3585,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1330 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3583 in read-symbolic-link in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1330 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3567 in read-symbolic-link in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3569,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3572,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1332 posix-error */
t4=lf[3];
f_1517(6,t4,t3,lf[48],lf[251],lf[252],((C_word*)t0)[2]);}
else{
t4=t3;
f_3572(2,t4,C_SCHEME_UNDEFINED);}}

/* k3570 in k3567 in read-symbolic-link in k3558 in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1333 substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3523,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[247]);
t5=(C_word)C_i_check_string_2(t3,lf[247]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3544,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3556,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1318 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3554 in create-symbolic-link in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1318 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3542 in create-symbolic-link in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3552,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1319 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3550 in k3542 in create-symbolic-link in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1319 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3546 in k3542 in create-symbolic-link in k3519 in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1321 posix-error */
t3=lf[3];
f_1517(7,t3,((C_word*)t0)[4],lf[48],lf[248],lf[249],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* set-process-group-id! in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3498,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[244]);
t5=(C_word)C_i_check_exact_2(t3,lf[244]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3514,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1296 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k3512 in set-process-group-id! in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1297 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[244],lf[245],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* create-session in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3483,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3487,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3493,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1288 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3487(2,t4,C_SCHEME_UNDEFINED);}}

/* k3491 in create-session in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1289 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[242],lf[243]);}

/* k3485 in create-session in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3477,3,t0,t1,t2);}
/* posixunix.scm: 1283 check */
f_3441(t1,t2,C_fix((C_word)X_OK),lf[241]);}

/* file-write-access? in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3471,3,t0,t1,t2);}
/* posixunix.scm: 1282 check */
f_3441(t1,t2,C_fix((C_word)W_OK),lf[240]);}

/* file-read-access? in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3465,3,t0,t1,t2);}
/* posixunix.scm: 1281 check */
f_3441(t1,t2,C_fix((C_word)R_OK),lf[239]);}

/* check in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3441(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3441,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3459,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3463,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1278 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3461 in check in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1278 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3457 in check in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3451,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3451(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1279 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3449 in k3457 in check in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3411,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[237]);
t6=(C_word)C_i_check_exact_2(t3,lf[237]);
t7=(C_word)C_i_check_exact_2(t4,lf[237]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3435,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3439,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1268 ##sys#expand-home-path */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k3437 in change-file-owner in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1268 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3433 in change-file-owner in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1269 posix-error */
t3=lf[3];
f_1517(8,t3,((C_word*)t0)[3],lf[48],lf[237],lf[238],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3384,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[235]);
t5=(C_word)C_i_check_exact_2(t3,lf[235]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3405,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3409,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1260 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3407 in change-file-mode in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1260 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3403 in change-file-mode in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1261 posix-error */
t3=lf[3];
f_1517(7,t3,((C_word*)t0)[3],lf[48],lf[235],lf[236],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3320,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[194]);
t5=(C_word)C_i_check_exact_2(t3,lf[194]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3308,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_3308(2,t9,C_SCHEME_FALSE);}}

/* k3306 in initialize-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub403(C_SCHEME_UNDEFINED,t1,t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1181 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3334 in k3306 in initialize-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1182 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[194],lf[195],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3246,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3250,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_3176(t4);
if(C_truep(t5)){
t6=t3;
f_3250(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1164 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[191],lf[193]);}}

/* k3248 in set-groups! in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3250,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3255,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3255(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do390 in k3248 in set-groups! in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3255(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3255,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1169 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[191]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k3269 in do390 in k3248 in set-groups! in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1170 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[191],lf[192],((C_word*)t0)[2]);}

/* get-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3187,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3241,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1150 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3187(2,t4,C_SCHEME_UNDEFINED);}}

/* k3239 in get-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1151 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[187],lf[190]);}

/* k3185 in get-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_3176(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_3190(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1153 ##sys#error */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[187],lf[189]);}}

/* k3188 in k3185 in get-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub372(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3222,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1155 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_3193(2,t5,C_SCHEME_UNDEFINED);}}

/* k3220 in k3188 in k3185 in get-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1156 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[187],lf[188]);}

/* k3191 in k3188 in k3185 in get-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3193,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3198,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3198(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k3191 in k3188 in k3185 in get-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3198(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3198,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3212,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1160 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3210 in loop in k3191 in k3188 in k3185 in get-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_3176(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub376(C_SCHEME_UNDEFINED,t2));}

/* group-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3090r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3090r(t0,t1,t2,t3);}}

static void C_ccall f_3090r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3094,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3094(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3094(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3092 in group-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_3097(t3,(C_word)C_getgrgid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[185]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1124 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3146 in k3092 in group-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3097(t2,(C_word)C_getgrnam(t1));}

/* k3095 in k3092 in group-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3097(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3097,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3105 in k3095 in k3092 in group-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3111,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k3109 in k3105 in k3095 in k3092 in group-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3115,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3120,a[2]=t4,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3120(t6,t2,C_fix(0));}

/* loop in k3109 in k3105 in k3095 in k3092 in group-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3120(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3120,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3124,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub355(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k3122 in loop in k3109 in k3105 in k3095 in k3092 in group-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3124,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3134,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1133 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3120(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k3132 in k3122 in loop in k3109 in k3105 in k3095 in k3092 in group-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3134,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3113 in k3109 in k3105 in k3095 in k3092 in group-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[181]+1):*((C_word*)lf[182]+1));
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3073,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3077,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1109 current-effective-user-id */
t4=*((C_word*)lf[175]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3075 in current-effective-user-name in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1109 user-information */
t2=*((C_word*)lf[180]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3071 in current-effective-user-name in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3059,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3063,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1106 current-user-id */
t4=*((C_word*)lf[174]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3061 in current-user-name in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1106 user-information */
t2=*((C_word*)lf[180]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3057 in current-user-name in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* user-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2984r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2984r(t0,t1,t2,t3);}}

static void C_ccall f_2984r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2988,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2988(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2988(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2986 in user-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_2991(t3,(C_word)C_getpwuid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[180]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3030,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1094 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3028 in k2986 in user-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2991(t2,(C_word)C_getpwnam(t1));}

/* k2989 in k2986 in user-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2991,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2999 in k2989 in k2986 in user-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3005,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k3003 in k2999 in k2989 in k2986 in user-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3009,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k3007 in k3003 in k2999 in k2989 in k2986 in user-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3013,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k3011 in k3007 in k3003 in k2999 in k2989 in k2986 in user-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3017,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k3015 in k3011 in k3007 in k3003 in k2999 in k2989 in k2986 in user-information in k2980 in k2976 in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[181]+1):*((C_word*)lf[182]+1));
t3=t2;
((C_proc9)C_retrieve_proc(t3))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* set-group-id! in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2961,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2971,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1064 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2969 in set-group-id! in k2957 in k2953 in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1065 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[172],lf[177],((C_word*)t0)[2]);}

/* set-user-id! in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2938,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2948,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1044 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2946 in set-user-id! in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1045 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[172],lf[173],((C_word*)t0)[2]);}

/* system-information in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2904,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2933,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1033 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2904(2,t3,C_SCHEME_UNDEFINED);}}

/* k2931 in system-information in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1034 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[169],lf[171]);}

/* k2902 in system-information in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k2909 in k2902 in system-information in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2915,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k2913 in k2909 in k2902 in system-information in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2919,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k2917 in k2913 in k2909 in k2902 in system-information in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2923,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k2921 in k2917 in k2913 in k2909 in k2902 in system-information in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2927,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k2925 in k2921 in k2917 in k2913 in k2909 in k2902 in system-information in k2896 in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2882,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[167]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1012 posix-error */
t5=lf[3];
f_1517(5,t5,t1,lf[161],lf[167],lf[168]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2867,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[165]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1006 posix-error */
t5=lf[3];
f_1517(5,t5,t1,lf[161],lf[165],lf[166]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2861,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[164]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2829,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2835,a[2]=t3,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2835(t5,t1,*((C_word*)lf[156]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2835(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2835,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 996  loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2805,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[160]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2812,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2823,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a2822 in set-signal-mask! in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2823,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[160]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k2810 in set-signal-mask! in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 989  posix-error */
t2=lf[3];
f_1517(5,t2,((C_word*)t0)[2],lf[161],lf[160],lf[162]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2787,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2797,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 975  h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixunix.scm: 977  oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k2795 in ##sys#interrupt-hook in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 976  ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2774,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[159]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k2761 in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2765,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[158]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2722,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 892  posix-error */
t3=lf[3];
f_1517(5,t3,t2,lf[48],lf[129],lf[130]);}
else{
t3=t2;
f_2722(2,t3,C_SCHEME_UNDEFINED);}}

/* k2720 in create-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 893  values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2698r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2698r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2698r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[128]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2702,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2700 in with-output-to-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2702,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2708,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 880  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2707 in k2700 in with-output-to-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2708r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2708r(t0,t1,t2);}}

static void C_ccall f_2708r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2712,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 882  close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2710 in a2707 in k2700 in with-output-to-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[128]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2678r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2678r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2678r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[126]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2682,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2680 in with-input-from-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2688,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 870  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2687 in k2680 in with-input-from-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2688r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2688r(t0,t1,t2);}}

static void C_ccall f_2688r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2692,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 872  close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2690 in a2687 in k2680 in with-input-from-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[126]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2654r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2654r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2654r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2658,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2656 in call-with-output-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2663,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2669,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li48),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 860  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2668 in k2656 in call-with-output-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2669r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2669r(t0,t1,t2);}}

static void C_ccall f_2669r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2673,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 863  close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2671 in a2668 in k2656 in call-with-output-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2662 in k2656 in call-with-output-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2663,2,t0,t1);}
/* posixunix.scm: 861  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2630r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2630r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2630r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2634,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2632 in call-with-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2639,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2645,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li45),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 852  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2644 in k2632 in call-with-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2645r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2645r(t0,t1,t2);}}

static void C_ccall f_2645r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2649,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 855  close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2647 in a2644 in k2632 in call-with-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2638 in k2632 in call-with-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
/* posixunix.scm: 853  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2614,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2618,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 839  ##sys#check-port */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[118]);}

/* k2616 in close-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2621,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 841  posix-error */
t5=lf[3];
f_1517(6,t5,t3,lf[48],lf[119],lf[120],((C_word*)t0)[3]);}
else{
t5=t3;
f_2621(2,t5,C_SCHEME_UNDEFINED);}}

/* k2619 in k2616 in close-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2578(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2578r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2578r(t0,t1,t2,t3);}}

static void C_ccall f_2578r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[117]);
t5=f_2509(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2592,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[109]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 834  ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[116]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2609,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 835  ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 836  badmode */
f_2521(t6,t5);}}}

/* k2607 in open-output-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2609,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2592(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k2597 in open-output-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2599,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2592(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k2590 in open-output-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 830  check */
f_2527(((C_word*)t0)[3],lf[117],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2542r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2542r(t0,t1,t2,t3);}}

static void C_ccall f_2542r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[115]);
t5=f_2509(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2556,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[109]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2563,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 823  ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[116]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2573,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 824  ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 825  badmode */
f_2521(t6,t5);}}}

/* k2571 in open-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2573,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2556(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k2561 in open-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2563,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2556(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k2554 in open-input-pipe in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 819  check */
f_2527(((C_word*)t0)[3],lf[115],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2527(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2527,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 811  posix-error */
t6=lf[3];
f_1517(6,t6,t1,lf[48],t2,lf[111],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2540,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 812  ##sys#make-port */
t7=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[113]+1),lf[114],lf[88]);}}

/* k2538 in check in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2521(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2521,NULL,2,t1,t2);}
/* posixunix.scm: 808  ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[110],t2);}

/* mode in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_2509(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[109]));}

/* current-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2466r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2466r(t0,t1,t2);}}

static void C_ccall f_2466r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2470(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2470(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2468 in current-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 796  change-directory */
t2=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 797  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k2477 in k2468 in current-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 800  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 801  posix-error */
t3=lf[3];
f_1517(5,t3,((C_word*)t0)[2],lf[48],lf[105],lf[108]);}}

/* directory? in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2443,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[106]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2450,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2464,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 789  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2462 in directory? in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 789  ##sys#file-info */
t2=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2448 in directory? in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_2286r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2286r(t0,t1,t2);}}

static void C_ccall f_2286r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2386,a[2]=t3,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2391,a[2]=t4,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec182207 */
t6=t5;
f_2391(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?183205 */
t8=t4;
f_2386(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body180185 */
t10=t3;
f_2288(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec182 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2391,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2399,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 762  current-directory */
t3=*((C_word*)lf[105]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2397 in def-spec182 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?183205 */
t2=((C_word*)t0)[3];
f_2386(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?183 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2386(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2386,NULL,3,t0,t1,t2);}
/* body180185 */
t3=((C_word*)t0)[2];
f_2288(t3,t1,t2,C_SCHEME_FALSE);}

/* body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2288(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2288,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[102]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2295,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 764  make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k2293 in body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 765  ##sys#make-pointer */
t3=*((C_word*)lf[104]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2296 in k2293 in body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 766  ##sys#make-pointer */
t3=*((C_word*)lf[104]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2299 in k2296 in k2293 in body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 767  ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k2383 in k2299 in k2296 in k2293 in body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 767  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2303 in k2299 in k2296 in k2293 in body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2305,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 769  posix-error */
t3=lf[3];
f_1517(6,t3,((C_word*)t0)[7],lf[48],lf[102],lf[103],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word)li31),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_2319(t6,((C_word*)t0)[7]);}}

/* loop in k2303 in k2299 in k2296 in k2293 in body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2319,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 777  ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k2327 in loop in k2303 in k2299 in k2296 in k2293 in body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 778  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_fix(0));}

/* k2330 in k2327 in loop in k2303 in k2299 in k2296 in k2293 in body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 779  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_2335(2,t3,C_SCHEME_FALSE);}}

/* k2333 in k2330 in k2327 in loop in k2303 in k2299 in k2296 in k2293 in body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],C_make_character(46));
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_2341(t5,t4);}
else{
t5=(C_word)C_eqp(t1,C_make_character(46));
t6=(C_truep(t5)?(C_word)C_eqp(((C_word*)t0)[3],C_fix(2)):C_SCHEME_FALSE);
t7=t2;
f_2341(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_2341(t4,C_SCHEME_FALSE);}}

/* k2339 in k2333 in k2330 in k2327 in loop in k2303 in k2299 in k2296 in k2293 in body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2341(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2341,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 784  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2319(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 785  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2319(t3,t2);}}

/* k2349 in k2339 in k2333 in k2330 in k2327 in loop in k2303 in k2299 in k2296 in k2293 in body180 in directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2262,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[98]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2280,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2284,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 755  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2282 in delete-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 755  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2278 in delete-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 756  posix-error */
t3=lf[3];
f_1517(6,t3,((C_word*)t0)[3],lf[48],lf[98],lf[99],((C_word*)t0)[2]);}}

/* change-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2238,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[96]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2256,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2260,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 749  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2258 in change-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 749  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2254 in change-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 750  posix-error */
t3=lf[3];
f_1517(6,t3,((C_word*)t0)[3],lf[48],lf[96],lf[97],((C_word*)t0)[2]);}}

/* create-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2214,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[94]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2232,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2236,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 743  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2234 in create-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 743  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2230 in create-directory in k2210 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 744  posix-error */
t3=lf[3];
f_1517(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[95],((C_word*)t0)[2]);}}

/* set-file-position! in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2152r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2152r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2152r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[86]);
t8=(C_word)C_i_check_exact_2(t6,lf[86]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2165,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 715  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[91],lf[86],lf[92],t3,t2);}
else{
t10=t9;
f_2165(2,t10,C_SCHEME_UNDEFINED);}}

/* k2163 in set-file-position! in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 716  port? */
t4=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k2175 in k2163 in set-file-position! in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[88]);
t4=((C_word*)t0)[4];
f_2171(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_2171(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 720  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[60],lf[86],lf[89],((C_word*)t0)[5]);}}}

/* k2169 in k2163 in set-file-position! in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 721  posix-error */
t2=lf[3];
f_1517(7,t2,((C_word*)t0)[4],lf[48],lf[86],lf[87],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* symbolic-link? in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2143,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2150,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 707  ##sys#stat */
f_2029(t4,t2,C_SCHEME_TRUE,lf[85]);}

/* k2148 in symbolic-link? in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2134,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2141,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 702  ##sys#stat */
f_2029(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k2139 in regular-file? in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2128,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2132,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 698  ##sys#stat */
f_2029(t3,t2,C_SCHEME_FALSE,lf[83]);}

/* k2130 in file-permissions in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2122,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2126,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 697  ##sys#stat */
f_2029(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k2124 in file-owner in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2116,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2120,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 696  ##sys#stat */
f_2029(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k2118 in file-change-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2120,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2110,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2114,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 695  ##sys#stat */
f_2029(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k2112 in file-access-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2114,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2104,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2108,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 694  ##sys#stat */
f_2029(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k2106 in file-modification-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2108,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2098,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2102,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 693  ##sys#stat */
f_2029(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k2100 in file-size in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2066r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2066r(t0,t1,t2,t3);}}

static void C_ccall f_2066r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2070,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2077,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_2077(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2077(2,t7,(C_word)C_i_car(t3));}
else{
/* posixunix.scm: 686  ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k2075 in file-stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 686  ##sys#stat */
f_2029(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[77]);}

/* k2068 in file-stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2070,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2029(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2029,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2033,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_2033(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2054,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2061,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 677  ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 681  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[76],t2);}}}

/* k2059 in ##sys#stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 677  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2052 in ##sys#stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2033(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k2031 in ##sys#stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 683  posix-error */
t2=lf[3];
f_1517(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[75],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1837r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1837r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1837r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_1811(C_fix(0));
t10=f_1811(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1853,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_1853(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 606  fd_set */
t14=t12;
f_1853(2,t14,f_1817(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[68]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t15=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a2009 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2010,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 613  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1817(C_fix(0),t2));}

/* k1851 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1853,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_1859(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 618  fd_set */
t5=t3;
f_1859(2,t5,f_1817(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[68]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a1983 in k1851 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1984,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 625  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1817(C_fix(1),t2));}

/* k1857 in k1851 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[68]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_1862(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_1862(t4,(C_word)C_C_select(t3));}}

/* k1860 in k1857 in k1851 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_1862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1862,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 632  posix-error */
t2=lf[3];
f_1517(7,t2,((C_word*)t0)[5],lf[48],lf[68],lf[69],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 633  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 638  fd_test */
t4=t3;
f_1901(t4,f_1827(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1942,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1944,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_1901(t4,C_SCHEME_FALSE);}}}}

/* a1943 in k1860 in k1857 in k1851 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1944,3,t0,t1,t2);}
t3=f_1827(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1940 in k1860 in k1857 in k1851 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1901(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1899 in k1860 in k1857 in k1851 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_1901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1901,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1905,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 644  fd_test */
t3=t2;
f_1905(t3,f_1827(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1917,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1919,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_1905(t3,C_SCHEME_FALSE);}}

/* a1918 in k1899 in k1860 in k1857 in k1851 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1919,3,t0,t1,t2);}
t3=f_1827(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1915 in k1899 in k1860 in k1857 in k1851 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1905(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1903 in k1899 in k1860 in k1857 in k1851 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_1905(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 635  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_1827(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub92(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_set in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_1817(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub86(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_zero in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_1811(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub81(C_SCHEME_UNDEFINED,t2));}

/* file-mkstemp in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1779,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[65]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1786,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 584  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1784 in file-mkstemp in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1786,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1792,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 588  posix-error */
t6=lf[3];
f_1517(6,t6,t4,lf[48],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t6=t4;
f_1792(2,t6,C_SCHEME_UNDEFINED);}}

/* k1790 in k1784 in file-mkstemp in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 589  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1797 in k1790 in k1784 in file-mkstemp in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 589  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1740r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1740r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1740r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[62]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1747,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1747(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 573  ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[60],lf[62],lf[64],t3);}}

/* k1745 in file-write in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1747,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[62]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1756,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 578  posix-error */
t8=lf[3];
f_1517(7,t8,t6,lf[48],lf[62],lf[63],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_1756(2,t8,C_SCHEME_UNDEFINED);}}

/* k1754 in k1745 in file-write in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1698r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1698r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1698r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1708,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1708(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixunix.scm: 561  make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k1706 in file-read in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1711(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 563  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[60],lf[58],lf[61],t1);}}

/* k1709 in k1706 in file-read in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1714,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 566  posix-error */
t5=lf[3];
f_1517(7,t5,t3,lf[48],lf[58],lf[59],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_1714(2,t5,C_SCHEME_UNDEFINED);}}

/* k1712 in k1709 in k1706 in file-read in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1714,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1683,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[55]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 554  posix-error */
t4=lf[3];
f_1517(6,t4,t1,lf[48],lf[55],lf[56],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1645r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1645r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1645r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[51]);
t8=(C_word)C_i_check_exact_2(t3,lf[51]);
t9=(C_word)C_i_check_exact_2(t6,lf[51]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1662,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1675,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 545  ##sys#expand-home-path */
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k1673 in file-open in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 545  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1660 in file-open in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1662,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1665,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 547  posix-error */
t5=lf[3];
f_1517(8,t5,t3,lf[48],lf[51],lf[52],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_1665(2,t5,C_SCHEME_UNDEFINED);}}

/* k1663 in k1660 in file-open in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1599r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1599r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1599r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1603,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1603(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1603(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1601 in file-control in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[47]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[47]);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_integer_argumentp(t1);
t9=(C_word)stub24(C_SCHEME_UNDEFINED,t6,t7,t8);
t10=(C_word)C_eqp(t9,C_fix(-1));
if(C_truep(t10)){
/* posixunix.scm: 535  posix-error */
t11=lf[3];
f_1517(7,t11,((C_word*)t0)[2],lf[48],lf[47],lf[49],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t9);}}

/* ##sys#file-select-one in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1542,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub17(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-nonblocking! in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1535,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub13(C_SCHEME_UNDEFINED,t3));}

/* posix-error in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1517r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1517r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1517r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1521,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 425  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1519 in posix-error in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub3(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k1530 in k1519 in posix-error in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 426  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k1526 in k1519 in posix-error in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[533] = {
{"toplevelposixunix.scm",(void*)C_posix_toplevel},
{"f_1493posixunix.scm",(void*)f_1493},
{"f_1496posixunix.scm",(void*)f_1496},
{"f_1499posixunix.scm",(void*)f_1499},
{"f_1502posixunix.scm",(void*)f_1502},
{"f_1505posixunix.scm",(void*)f_1505},
{"f_6709posixunix.scm",(void*)f_6709},
{"f_6725posixunix.scm",(void*)f_6725},
{"f_6713posixunix.scm",(void*)f_6713},
{"f_6716posixunix.scm",(void*)f_6716},
{"f_2212posixunix.scm",(void*)f_2212},
{"f_2763posixunix.scm",(void*)f_2763},
{"f_6703posixunix.scm",(void*)f_6703},
{"f_2898posixunix.scm",(void*)f_2898},
{"f_6700posixunix.scm",(void*)f_6700},
{"f_2955posixunix.scm",(void*)f_2955},
{"f_6685posixunix.scm",(void*)f_6685},
{"f_6695posixunix.scm",(void*)f_6695},
{"f_6682posixunix.scm",(void*)f_6682},
{"f_2959posixunix.scm",(void*)f_2959},
{"f_6679posixunix.scm",(void*)f_6679},
{"f_2978posixunix.scm",(void*)f_2978},
{"f_6664posixunix.scm",(void*)f_6664},
{"f_6674posixunix.scm",(void*)f_6674},
{"f_6661posixunix.scm",(void*)f_6661},
{"f_2982posixunix.scm",(void*)f_2982},
{"f_6643posixunix.scm",(void*)f_6643},
{"f_6656posixunix.scm",(void*)f_6656},
{"f_6650posixunix.scm",(void*)f_6650},
{"f_3521posixunix.scm",(void*)f_3521},
{"f_3560posixunix.scm",(void*)f_3560},
{"f_6620posixunix.scm",(void*)f_6620},
{"f_6612posixunix.scm",(void*)f_6612},
{"f_6355posixunix.scm",(void*)f_6355},
{"f_6538posixunix.scm",(void*)f_6538},
{"f_6544posixunix.scm",(void*)f_6544},
{"f_6533posixunix.scm",(void*)f_6533},
{"f_6528posixunix.scm",(void*)f_6528},
{"f_6357posixunix.scm",(void*)f_6357},
{"f_6515posixunix.scm",(void*)f_6515},
{"f_6523posixunix.scm",(void*)f_6523},
{"f_6364posixunix.scm",(void*)f_6364},
{"f_6503posixunix.scm",(void*)f_6503},
{"f_6497posixunix.scm",(void*)f_6497},
{"f_6374posixunix.scm",(void*)f_6374},
{"f_6376posixunix.scm",(void*)f_6376},
{"f_6395posixunix.scm",(void*)f_6395},
{"f_6483posixunix.scm",(void*)f_6483},
{"f_6490posixunix.scm",(void*)f_6490},
{"f_6477posixunix.scm",(void*)f_6477},
{"f_6410posixunix.scm",(void*)f_6410},
{"f_6470posixunix.scm",(void*)f_6470},
{"f_6467posixunix.scm",(void*)f_6467},
{"f_6454posixunix.scm",(void*)f_6454},
{"f_6430posixunix.scm",(void*)f_6430},
{"f_6452posixunix.scm",(void*)f_6452},
{"f_6438posixunix.scm",(void*)f_6438},
{"f_6445posixunix.scm",(void*)f_6445},
{"f_6442posixunix.scm",(void*)f_6442},
{"f_6422posixunix.scm",(void*)f_6422},
{"f_6420posixunix.scm",(void*)f_6420},
{"f_6504posixunix.scm",(void*)f_6504},
{"f_6295posixunix.scm",(void*)f_6295},
{"f_6307posixunix.scm",(void*)f_6307},
{"f_6302posixunix.scm",(void*)f_6302},
{"f_6297posixunix.scm",(void*)f_6297},
{"f_6235posixunix.scm",(void*)f_6235},
{"f_6247posixunix.scm",(void*)f_6247},
{"f_6242posixunix.scm",(void*)f_6242},
{"f_6237posixunix.scm",(void*)f_6237},
{"f_6174posixunix.scm",(void*)f_6174},
{"f_6229posixunix.scm",(void*)f_6229},
{"f_6233posixunix.scm",(void*)f_6233},
{"f_6195posixunix.scm",(void*)f_6195},
{"f_6198posixunix.scm",(void*)f_6198},
{"f_6209posixunix.scm",(void*)f_6209},
{"f_6203posixunix.scm",(void*)f_6203},
{"f_6176posixunix.scm",(void*)f_6176},
{"f_6185posixunix.scm",(void*)f_6185},
{"f_6110posixunix.scm",(void*)f_6110},
{"f_6122posixunix.scm",(void*)f_6122},
{"f_6153posixunix.scm",(void*)f_6153},
{"f_6133posixunix.scm",(void*)f_6133},
{"f_6149posixunix.scm",(void*)f_6149},
{"f_6137posixunix.scm",(void*)f_6137},
{"f_6145posixunix.scm",(void*)f_6145},
{"f_6141posixunix.scm",(void*)f_6141},
{"f_6116posixunix.scm",(void*)f_6116},
{"f_6099posixunix.scm",(void*)f_6099},
{"f_6103posixunix.scm",(void*)f_6103},
{"f_6088posixunix.scm",(void*)f_6088},
{"f_6092posixunix.scm",(void*)f_6092},
{"f_6043posixunix.scm",(void*)f_6043},
{"f_6047posixunix.scm",(void*)f_6047},
{"f_6050posixunix.scm",(void*)f_6050},
{"f_6053posixunix.scm",(void*)f_6053},
{"f_6066posixunix.scm",(void*)f_6066},
{"f_6070posixunix.scm",(void*)f_6070},
{"f_6073posixunix.scm",(void*)f_6073},
{"f_6076posixunix.scm",(void*)f_6076},
{"f_6064posixunix.scm",(void*)f_6064},
{"f_6027posixunix.scm",(void*)f_6027},
{"f_6010posixunix.scm",(void*)f_6010},
{"f_6023posixunix.scm",(void*)f_6023},
{"f_5935posixunix.scm",(void*)f_5935},
{"f_5996posixunix.scm",(void*)f_5996},
{"f_6009posixunix.scm",(void*)f_6009},
{"f_5976posixunix.scm",(void*)f_5976},
{"f_5991posixunix.scm",(void*)f_5991},
{"f_5985posixunix.scm",(void*)f_5985},
{"f_5939posixunix.scm",(void*)f_5939},
{"f_5941posixunix.scm",(void*)f_5941},
{"f_5962posixunix.scm",(void*)f_5962},
{"f_5956posixunix.scm",(void*)f_5956},
{"f_5883posixunix.scm",(void*)f_5883},
{"f_5890posixunix.scm",(void*)f_5890},
{"f_5909posixunix.scm",(void*)f_5909},
{"f_5913posixunix.scm",(void*)f_5913},
{"f_5877posixunix.scm",(void*)f_5877},
{"f_5868posixunix.scm",(void*)f_5868},
{"f_5872posixunix.scm",(void*)f_5872},
{"f_5841posixunix.scm",(void*)f_5841},
{"f_5834posixunix.scm",(void*)f_5834},
{"f_5831posixunix.scm",(void*)f_5831},
{"f_5828posixunix.scm",(void*)f_5828},
{"f_5750posixunix.scm",(void*)f_5750},
{"f_5786posixunix.scm",(void*)f_5786},
{"f_5780posixunix.scm",(void*)f_5780},
{"f_5733posixunix.scm",(void*)f_5733},
{"f_5551posixunix.scm",(void*)f_5551},
{"f_5685posixunix.scm",(void*)f_5685},
{"f_5680posixunix.scm",(void*)f_5680},
{"f_5553posixunix.scm",(void*)f_5553},
{"f_5563posixunix.scm",(void*)f_5563},
{"f_5571posixunix.scm",(void*)f_5571},
{"f_5617posixunix.scm",(void*)f_5617},
{"f_5584posixunix.scm",(void*)f_5584},
{"f_5609posixunix.scm",(void*)f_5609},
{"f_5587posixunix.scm",(void*)f_5587},
{"f_5532posixunix.scm",(void*)f_5532},
{"f_5513posixunix.scm",(void*)f_5513},
{"f_5471posixunix.scm",(void*)f_5471},
{"f_5493posixunix.scm",(void*)f_5493},
{"f_5497posixunix.scm",(void*)f_5497},
{"f_5359posixunix.scm",(void*)f_5359},
{"f_5365posixunix.scm",(void*)f_5365},
{"f_5386posixunix.scm",(void*)f_5386},
{"f_5463posixunix.scm",(void*)f_5463},
{"f_5390posixunix.scm",(void*)f_5390},
{"f_5393posixunix.scm",(void*)f_5393},
{"f_5396posixunix.scm",(void*)f_5396},
{"f_5403posixunix.scm",(void*)f_5403},
{"f_5405posixunix.scm",(void*)f_5405},
{"f_5422posixunix.scm",(void*)f_5422},
{"f_5432posixunix.scm",(void*)f_5432},
{"f_5436posixunix.scm",(void*)f_5436},
{"f_5380posixunix.scm",(void*)f_5380},
{"f_5347posixunix.scm",(void*)f_5347},
{"f_5351posixunix.scm",(void*)f_5351},
{"f_5354posixunix.scm",(void*)f_5354},
{"f_5312posixunix.scm",(void*)f_5312},
{"f_5316posixunix.scm",(void*)f_5316},
{"f_5336posixunix.scm",(void*)f_5336},
{"f_5340posixunix.scm",(void*)f_5340},
{"f_5289posixunix.scm",(void*)f_5289},
{"f_5293posixunix.scm",(void*)f_5293},
{"f_5257posixunix.scm",(void*)f_5257},
{"f_5261posixunix.scm",(void*)f_5261},
{"f_5238posixunix.scm",(void*)f_5238},
{"f_5242posixunix.scm",(void*)f_5242},
{"f_5245posixunix.scm",(void*)f_5245},
{"f_5179posixunix.scm",(void*)f_5179},
{"f_5183posixunix.scm",(void*)f_5183},
{"f_5189posixunix.scm",(void*)f_5189},
{"f_5172posixunix.scm",(void*)f_5172},
{"f_5156posixunix.scm",(void*)f_5156},
{"f_5144posixunix.scm",(void*)f_5144},
{"f_5116posixunix.scm",(void*)f_5116},
{"f_5123posixunix.scm",(void*)f_5123},
{"f_5088posixunix.scm",(void*)f_5088},
{"f_5095posixunix.scm",(void*)f_5095},
{"f_5060posixunix.scm",(void*)f_5060},
{"f_5067posixunix.scm",(void*)f_5067},
{"f_5070posixunix.scm",(void*)f_5070},
{"f_5073posixunix.scm",(void*)f_5073},
{"f_5043posixunix.scm",(void*)f_5043},
{"f_5047posixunix.scm",(void*)f_5047},
{"f_5050posixunix.scm",(void*)f_5050},
{"f_5024posixunix.scm",(void*)f_5024},
{"f_5015posixunix.scm",(void*)f_5015},
{"f_5009posixunix.scm",(void*)f_5009},
{"f_5000posixunix.scm",(void*)f_5000},
{"f_4965posixunix.scm",(void*)f_4965},
{"f_4903posixunix.scm",(void*)f_4903},
{"f_4907posixunix.scm",(void*)f_4907},
{"f_4913posixunix.scm",(void*)f_4913},
{"f_4932posixunix.scm",(void*)f_4932},
{"f_4919posixunix.scm",(void*)f_4919},
{"f_4800posixunix.scm",(void*)f_4800},
{"f_4806posixunix.scm",(void*)f_4806},
{"f_4810posixunix.scm",(void*)f_4810},
{"f_4818posixunix.scm",(void*)f_4818},
{"f_4844posixunix.scm",(void*)f_4844},
{"f_4848posixunix.scm",(void*)f_4848},
{"f_4836posixunix.scm",(void*)f_4836},
{"f_4780posixunix.scm",(void*)f_4780},
{"f_4788posixunix.scm",(void*)f_4788},
{"f_4763posixunix.scm",(void*)f_4763},
{"f_4774posixunix.scm",(void*)f_4774},
{"f_4778posixunix.scm",(void*)f_4778},
{"f_4737posixunix.scm",(void*)f_4737},
{"f_4761posixunix.scm",(void*)f_4761},
{"f_4744posixunix.scm",(void*)f_4744},
{"f_4694posixunix.scm",(void*)f_4694},
{"f_4701posixunix.scm",(void*)f_4701},
{"f_4722posixunix.scm",(void*)f_4722},
{"f_4718posixunix.scm",(void*)f_4718},
{"f_4666posixunix.scm",(void*)f_4666},
{"f_4644posixunix.scm",(void*)f_4644},
{"f_4648posixunix.scm",(void*)f_4648},
{"f_4629posixunix.scm",(void*)f_4629},
{"f_4633posixunix.scm",(void*)f_4633},
{"f_4614posixunix.scm",(void*)f_4614},
{"f_4618posixunix.scm",(void*)f_4618},
{"f_4596posixunix.scm",(void*)f_4596},
{"f_4522posixunix.scm",(void*)f_4522},
{"f_4544posixunix.scm",(void*)f_4544},
{"f_4550posixunix.scm",(void*)f_4550},
{"f_4483posixunix.scm",(void*)f_4483},
{"f_4511posixunix.scm",(void*)f_4511},
{"f_4507posixunix.scm",(void*)f_4507},
{"f_4500posixunix.scm",(void*)f_4500},
{"f_4224posixunix.scm",(void*)f_4224},
{"f_4420posixunix.scm",(void*)f_4420},
{"f_4415posixunix.scm",(void*)f_4415},
{"f_4410posixunix.scm",(void*)f_4410},
{"f_4226posixunix.scm",(void*)f_4226},
{"f_4230posixunix.scm",(void*)f_4230},
{"f_4336posixunix.scm",(void*)f_4336},
{"f_4337posixunix.scm",(void*)f_4337},
{"f_4354posixunix.scm",(void*)f_4354},
{"f_4364posixunix.scm",(void*)f_4364},
{"f_4322posixunix.scm",(void*)f_4322},
{"f_4278posixunix.scm",(void*)f_4278},
{"f_4314posixunix.scm",(void*)f_4314},
{"f_4293posixunix.scm",(void*)f_4293},
{"f_4303posixunix.scm",(void*)f_4303},
{"f_4287posixunix.scm",(void*)f_4287},
{"f_4282posixunix.scm",(void*)f_4282},
{"f_4285posixunix.scm",(void*)f_4285},
{"f_4232posixunix.scm",(void*)f_4232},
{"f_4267posixunix.scm",(void*)f_4267},
{"f_4248posixunix.scm",(void*)f_4248},
{"f_3788posixunix.scm",(void*)f_3788},
{"f_4146posixunix.scm",(void*)f_4146},
{"f_4141posixunix.scm",(void*)f_4141},
{"f_4136posixunix.scm",(void*)f_4136},
{"f_4131posixunix.scm",(void*)f_4131},
{"f_3790posixunix.scm",(void*)f_3790},
{"f_3794posixunix.scm",(void*)f_3794},
{"f_3800posixunix.scm",(void*)f_3800},
{"f_4031posixunix.scm",(void*)f_4031},
{"f_4037posixunix.scm",(void*)f_4037},
{"f_4106posixunix.scm",(void*)f_4106},
{"f_4049posixunix.scm",(void*)f_4049},
{"f_4053posixunix.scm",(void*)f_4053},
{"f_4063posixunix.scm",(void*)f_4063},
{"f_4079posixunix.scm",(void*)f_4079},
{"f_3966posixunix.scm",(void*)f_3966},
{"f_3972posixunix.scm",(void*)f_3972},
{"f_4020posixunix.scm",(void*)f_4020},
{"f_3957posixunix.scm",(void*)f_3957},
{"f_3961posixunix.scm",(void*)f_3961},
{"f_3936posixunix.scm",(void*)f_3936},
{"f_3946posixunix.scm",(void*)f_3946},
{"f_3924posixunix.scm",(void*)f_3924},
{"f_3911posixunix.scm",(void*)f_3911},
{"f_3915posixunix.scm",(void*)f_3915},
{"f_3906posixunix.scm",(void*)f_3906},
{"f_3909posixunix.scm",(void*)f_3909},
{"f_3824posixunix.scm",(void*)f_3824},
{"f_3836posixunix.scm",(void*)f_3836},
{"f_3873posixunix.scm",(void*)f_3873},
{"f_3882posixunix.scm",(void*)f_3882},
{"f_3876posixunix.scm",(void*)f_3876},
{"f_3852posixunix.scm",(void*)f_3852},
{"f_3855posixunix.scm",(void*)f_3855},
{"f_3816posixunix.scm",(void*)f_3816},
{"f_3801posixunix.scm",(void*)f_3801},
{"f_3815posixunix.scm",(void*)f_3815},
{"f_3761posixunix.scm",(void*)f_3761},
{"f_3768posixunix.scm",(void*)f_3768},
{"f_3771posixunix.scm",(void*)f_3771},
{"f_3716posixunix.scm",(void*)f_3716},
{"f_3720posixunix.scm",(void*)f_3720},
{"f_3755posixunix.scm",(void*)f_3755},
{"f_3738posixunix.scm",(void*)f_3738},
{"f_3702posixunix.scm",(void*)f_3702},
{"f_3714posixunix.scm",(void*)f_3714},
{"f_3688posixunix.scm",(void*)f_3688},
{"f_3700posixunix.scm",(void*)f_3700},
{"f_3673posixunix.scm",(void*)f_3673},
{"f_3686posixunix.scm",(void*)f_3686},
{"f_3636posixunix.scm",(void*)f_3636},
{"f_3644posixunix.scm",(void*)f_3644},
{"f_3611posixunix.scm",(void*)f_3611},
{"f_3592posixunix.scm",(void*)f_3592},
{"f_3596posixunix.scm",(void*)f_3596},
{"f_3561posixunix.scm",(void*)f_3561},
{"f_3585posixunix.scm",(void*)f_3585},
{"f_3569posixunix.scm",(void*)f_3569},
{"f_3572posixunix.scm",(void*)f_3572},
{"f_3523posixunix.scm",(void*)f_3523},
{"f_3556posixunix.scm",(void*)f_3556},
{"f_3544posixunix.scm",(void*)f_3544},
{"f_3552posixunix.scm",(void*)f_3552},
{"f_3548posixunix.scm",(void*)f_3548},
{"f_3498posixunix.scm",(void*)f_3498},
{"f_3514posixunix.scm",(void*)f_3514},
{"f_3483posixunix.scm",(void*)f_3483},
{"f_3493posixunix.scm",(void*)f_3493},
{"f_3487posixunix.scm",(void*)f_3487},
{"f_3477posixunix.scm",(void*)f_3477},
{"f_3471posixunix.scm",(void*)f_3471},
{"f_3465posixunix.scm",(void*)f_3465},
{"f_3441posixunix.scm",(void*)f_3441},
{"f_3463posixunix.scm",(void*)f_3463},
{"f_3459posixunix.scm",(void*)f_3459},
{"f_3451posixunix.scm",(void*)f_3451},
{"f_3411posixunix.scm",(void*)f_3411},
{"f_3439posixunix.scm",(void*)f_3439},
{"f_3435posixunix.scm",(void*)f_3435},
{"f_3384posixunix.scm",(void*)f_3384},
{"f_3409posixunix.scm",(void*)f_3409},
{"f_3405posixunix.scm",(void*)f_3405},
{"f_3320posixunix.scm",(void*)f_3320},
{"f_3308posixunix.scm",(void*)f_3308},
{"f_3336posixunix.scm",(void*)f_3336},
{"f_3246posixunix.scm",(void*)f_3246},
{"f_3250posixunix.scm",(void*)f_3250},
{"f_3255posixunix.scm",(void*)f_3255},
{"f_3271posixunix.scm",(void*)f_3271},
{"f_3183posixunix.scm",(void*)f_3183},
{"f_3241posixunix.scm",(void*)f_3241},
{"f_3187posixunix.scm",(void*)f_3187},
{"f_3190posixunix.scm",(void*)f_3190},
{"f_3222posixunix.scm",(void*)f_3222},
{"f_3193posixunix.scm",(void*)f_3193},
{"f_3198posixunix.scm",(void*)f_3198},
{"f_3212posixunix.scm",(void*)f_3212},
{"f_3176posixunix.scm",(void*)f_3176},
{"f_3090posixunix.scm",(void*)f_3090},
{"f_3094posixunix.scm",(void*)f_3094},
{"f_3148posixunix.scm",(void*)f_3148},
{"f_3097posixunix.scm",(void*)f_3097},
{"f_3107posixunix.scm",(void*)f_3107},
{"f_3111posixunix.scm",(void*)f_3111},
{"f_3120posixunix.scm",(void*)f_3120},
{"f_3124posixunix.scm",(void*)f_3124},
{"f_3134posixunix.scm",(void*)f_3134},
{"f_3115posixunix.scm",(void*)f_3115},
{"f_3065posixunix.scm",(void*)f_3065},
{"f_3077posixunix.scm",(void*)f_3077},
{"f_3073posixunix.scm",(void*)f_3073},
{"f_3051posixunix.scm",(void*)f_3051},
{"f_3063posixunix.scm",(void*)f_3063},
{"f_3059posixunix.scm",(void*)f_3059},
{"f_2984posixunix.scm",(void*)f_2984},
{"f_2988posixunix.scm",(void*)f_2988},
{"f_3030posixunix.scm",(void*)f_3030},
{"f_2991posixunix.scm",(void*)f_2991},
{"f_3001posixunix.scm",(void*)f_3001},
{"f_3005posixunix.scm",(void*)f_3005},
{"f_3009posixunix.scm",(void*)f_3009},
{"f_3013posixunix.scm",(void*)f_3013},
{"f_3017posixunix.scm",(void*)f_3017},
{"f_2961posixunix.scm",(void*)f_2961},
{"f_2971posixunix.scm",(void*)f_2971},
{"f_2938posixunix.scm",(void*)f_2938},
{"f_2948posixunix.scm",(void*)f_2948},
{"f_2900posixunix.scm",(void*)f_2900},
{"f_2933posixunix.scm",(void*)f_2933},
{"f_2904posixunix.scm",(void*)f_2904},
{"f_2911posixunix.scm",(void*)f_2911},
{"f_2915posixunix.scm",(void*)f_2915},
{"f_2919posixunix.scm",(void*)f_2919},
{"f_2923posixunix.scm",(void*)f_2923},
{"f_2927posixunix.scm",(void*)f_2927},
{"f_2882posixunix.scm",(void*)f_2882},
{"f_2867posixunix.scm",(void*)f_2867},
{"f_2861posixunix.scm",(void*)f_2861},
{"f_2829posixunix.scm",(void*)f_2829},
{"f_2835posixunix.scm",(void*)f_2835},
{"f_2805posixunix.scm",(void*)f_2805},
{"f_2823posixunix.scm",(void*)f_2823},
{"f_2812posixunix.scm",(void*)f_2812},
{"f_2787posixunix.scm",(void*)f_2787},
{"f_2797posixunix.scm",(void*)f_2797},
{"f_2774posixunix.scm",(void*)f_2774},
{"f_2765posixunix.scm",(void*)f_2765},
{"f_2718posixunix.scm",(void*)f_2718},
{"f_2722posixunix.scm",(void*)f_2722},
{"f_2698posixunix.scm",(void*)f_2698},
{"f_2702posixunix.scm",(void*)f_2702},
{"f_2708posixunix.scm",(void*)f_2708},
{"f_2712posixunix.scm",(void*)f_2712},
{"f_2678posixunix.scm",(void*)f_2678},
{"f_2682posixunix.scm",(void*)f_2682},
{"f_2688posixunix.scm",(void*)f_2688},
{"f_2692posixunix.scm",(void*)f_2692},
{"f_2654posixunix.scm",(void*)f_2654},
{"f_2658posixunix.scm",(void*)f_2658},
{"f_2669posixunix.scm",(void*)f_2669},
{"f_2673posixunix.scm",(void*)f_2673},
{"f_2663posixunix.scm",(void*)f_2663},
{"f_2630posixunix.scm",(void*)f_2630},
{"f_2634posixunix.scm",(void*)f_2634},
{"f_2645posixunix.scm",(void*)f_2645},
{"f_2649posixunix.scm",(void*)f_2649},
{"f_2639posixunix.scm",(void*)f_2639},
{"f_2614posixunix.scm",(void*)f_2614},
{"f_2618posixunix.scm",(void*)f_2618},
{"f_2621posixunix.scm",(void*)f_2621},
{"f_2578posixunix.scm",(void*)f_2578},
{"f_2609posixunix.scm",(void*)f_2609},
{"f_2599posixunix.scm",(void*)f_2599},
{"f_2592posixunix.scm",(void*)f_2592},
{"f_2542posixunix.scm",(void*)f_2542},
{"f_2573posixunix.scm",(void*)f_2573},
{"f_2563posixunix.scm",(void*)f_2563},
{"f_2556posixunix.scm",(void*)f_2556},
{"f_2527posixunix.scm",(void*)f_2527},
{"f_2540posixunix.scm",(void*)f_2540},
{"f_2521posixunix.scm",(void*)f_2521},
{"f_2509posixunix.scm",(void*)f_2509},
{"f_2466posixunix.scm",(void*)f_2466},
{"f_2470posixunix.scm",(void*)f_2470},
{"f_2479posixunix.scm",(void*)f_2479},
{"f_2443posixunix.scm",(void*)f_2443},
{"f_2464posixunix.scm",(void*)f_2464},
{"f_2450posixunix.scm",(void*)f_2450},
{"f_2286posixunix.scm",(void*)f_2286},
{"f_2391posixunix.scm",(void*)f_2391},
{"f_2399posixunix.scm",(void*)f_2399},
{"f_2386posixunix.scm",(void*)f_2386},
{"f_2288posixunix.scm",(void*)f_2288},
{"f_2295posixunix.scm",(void*)f_2295},
{"f_2298posixunix.scm",(void*)f_2298},
{"f_2301posixunix.scm",(void*)f_2301},
{"f_2385posixunix.scm",(void*)f_2385},
{"f_2305posixunix.scm",(void*)f_2305},
{"f_2319posixunix.scm",(void*)f_2319},
{"f_2329posixunix.scm",(void*)f_2329},
{"f_2332posixunix.scm",(void*)f_2332},
{"f_2335posixunix.scm",(void*)f_2335},
{"f_2341posixunix.scm",(void*)f_2341},
{"f_2351posixunix.scm",(void*)f_2351},
{"f_2262posixunix.scm",(void*)f_2262},
{"f_2284posixunix.scm",(void*)f_2284},
{"f_2280posixunix.scm",(void*)f_2280},
{"f_2238posixunix.scm",(void*)f_2238},
{"f_2260posixunix.scm",(void*)f_2260},
{"f_2256posixunix.scm",(void*)f_2256},
{"f_2214posixunix.scm",(void*)f_2214},
{"f_2236posixunix.scm",(void*)f_2236},
{"f_2232posixunix.scm",(void*)f_2232},
{"f_2152posixunix.scm",(void*)f_2152},
{"f_2165posixunix.scm",(void*)f_2165},
{"f_2177posixunix.scm",(void*)f_2177},
{"f_2171posixunix.scm",(void*)f_2171},
{"f_2143posixunix.scm",(void*)f_2143},
{"f_2150posixunix.scm",(void*)f_2150},
{"f_2134posixunix.scm",(void*)f_2134},
{"f_2141posixunix.scm",(void*)f_2141},
{"f_2128posixunix.scm",(void*)f_2128},
{"f_2132posixunix.scm",(void*)f_2132},
{"f_2122posixunix.scm",(void*)f_2122},
{"f_2126posixunix.scm",(void*)f_2126},
{"f_2116posixunix.scm",(void*)f_2116},
{"f_2120posixunix.scm",(void*)f_2120},
{"f_2110posixunix.scm",(void*)f_2110},
{"f_2114posixunix.scm",(void*)f_2114},
{"f_2104posixunix.scm",(void*)f_2104},
{"f_2108posixunix.scm",(void*)f_2108},
{"f_2098posixunix.scm",(void*)f_2098},
{"f_2102posixunix.scm",(void*)f_2102},
{"f_2066posixunix.scm",(void*)f_2066},
{"f_2077posixunix.scm",(void*)f_2077},
{"f_2070posixunix.scm",(void*)f_2070},
{"f_2029posixunix.scm",(void*)f_2029},
{"f_2061posixunix.scm",(void*)f_2061},
{"f_2054posixunix.scm",(void*)f_2054},
{"f_2033posixunix.scm",(void*)f_2033},
{"f_1837posixunix.scm",(void*)f_1837},
{"f_2010posixunix.scm",(void*)f_2010},
{"f_1853posixunix.scm",(void*)f_1853},
{"f_1984posixunix.scm",(void*)f_1984},
{"f_1859posixunix.scm",(void*)f_1859},
{"f_1862posixunix.scm",(void*)f_1862},
{"f_1944posixunix.scm",(void*)f_1944},
{"f_1942posixunix.scm",(void*)f_1942},
{"f_1901posixunix.scm",(void*)f_1901},
{"f_1919posixunix.scm",(void*)f_1919},
{"f_1917posixunix.scm",(void*)f_1917},
{"f_1905posixunix.scm",(void*)f_1905},
{"f_1827posixunix.scm",(void*)f_1827},
{"f_1817posixunix.scm",(void*)f_1817},
{"f_1811posixunix.scm",(void*)f_1811},
{"f_1779posixunix.scm",(void*)f_1779},
{"f_1786posixunix.scm",(void*)f_1786},
{"f_1792posixunix.scm",(void*)f_1792},
{"f_1799posixunix.scm",(void*)f_1799},
{"f_1740posixunix.scm",(void*)f_1740},
{"f_1747posixunix.scm",(void*)f_1747},
{"f_1756posixunix.scm",(void*)f_1756},
{"f_1698posixunix.scm",(void*)f_1698},
{"f_1708posixunix.scm",(void*)f_1708},
{"f_1711posixunix.scm",(void*)f_1711},
{"f_1714posixunix.scm",(void*)f_1714},
{"f_1683posixunix.scm",(void*)f_1683},
{"f_1645posixunix.scm",(void*)f_1645},
{"f_1675posixunix.scm",(void*)f_1675},
{"f_1662posixunix.scm",(void*)f_1662},
{"f_1665posixunix.scm",(void*)f_1665},
{"f_1599posixunix.scm",(void*)f_1599},
{"f_1603posixunix.scm",(void*)f_1603},
{"f_1542posixunix.scm",(void*)f_1542},
{"f_1535posixunix.scm",(void*)f_1535},
{"f_1517posixunix.scm",(void*)f_1517},
{"f_1521posixunix.scm",(void*)f_1521},
{"f_1532posixunix.scm",(void*)f_1532},
{"f_1528posixunix.scm",(void*)f_1528},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
