/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-08 08:50
   Version 4.0.0x3 - SVN rev. 12690
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-12-01 on dill (Linux)
   command line: posixunix.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define cpy_tmvec_to_tmstc08(ptm, v) \
    (memset((ptm), 0, sizeof(struct tm)), \
    (ptm)->tm_sec = C_unfix(C_block_item((v), 0)), \
    (ptm)->tm_min = C_unfix(C_block_item((v), 1)), \
    (ptm)->tm_hour = C_unfix(C_block_item((v), 2)), \
    (ptm)->tm_mday = C_unfix(C_block_item((v), 3)), \
    (ptm)->tm_mon = C_unfix(C_block_item((v), 4)), \
    (ptm)->tm_year = C_unfix(C_block_item((v), 5)), \
    (ptm)->tm_wday = C_unfix(C_block_item((v), 6)), \
    (ptm)->tm_yday = C_unfix(C_block_item((v), 7)), \
    (ptm)->tm_isdst = (C_block_item((v), 8) != C_SCHEME_FALSE))

#define cpy_tmvec_to_tmstc9(ptm, v) \
    (((struct tm *)ptm)->tm_gmtoff = C_unfix(C_block_item((v), 9)))

#define cpy_tmstc08_to_tmvec(v, ptm) \
    (C_set_block_item((v), 0, C_fix(((struct tm *)ptm)->tm_sec)), \
    C_set_block_item((v), 1, C_fix((ptm)->tm_min)), \
    C_set_block_item((v), 2, C_fix((ptm)->tm_hour)), \
    C_set_block_item((v), 3, C_fix((ptm)->tm_mday)), \
    C_set_block_item((v), 4, C_fix((ptm)->tm_mon)), \
    C_set_block_item((v), 5, C_fix((ptm)->tm_year)), \
    C_set_block_item((v), 6, C_fix((ptm)->tm_wday)), \
    C_set_block_item((v), 7, C_fix((ptm)->tm_yday)), \
    C_set_block_item((v), 8, ((ptm)->tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define cpy_tmstc9_to_tmvec(v, ptm) \
    (C_set_block_item((v), 9, C_fix((ptm)->tm_gmtoff)))

#define C_tm_set_08(v)  cpy_tmvec_to_tmstc08( &C_tm, (v) )
#define C_tm_set_9(v)   cpy_tmvec_to_tmstc9( &C_tm, (v) )

#define C_tm_get_08(v)  cpy_tmstc08_to_tmvec( (v), &C_tm )
#define C_tm_get_9(v)   cpy_tmstc9_to_tmvec( (v), &C_tm )

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  return v;
}

#else

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  C_tm_set_9( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  C_tm_get_9( v );
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[465];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,51,48,32,108,111,99,51,49,32,109,115,103,51,50,32,46,32,97,114,103,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,51,57,52,50,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,52,53,52,56,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,49,51,55,32,99,109,100,49,51,56,32,46,32,116,109,112,49,51,54,49,51,57,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,49,53,57,32,102,108,97,103,115,49,54,48,32,46,32,109,111,100,101,49,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,99,108,111,115,101,32,102,100,49,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,37),40,102,105,108,101,45,114,101,97,100,32,102,100,49,56,50,32,115,105,122,101,49,56,51,32,46,32,98,117,102,102,101,114,49,56,52,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,119,114,105,116,101,32,102,100,50,48,49,32,98,117,102,102,101,114,50,48,50,32,46,32,115,105,122,101,50,48,51,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,50,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,9),40,102,100,95,122,101,114,111,41,0,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,16),40,102,100,95,115,101,116,32,97,50,52,51,50,52,56,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,17),40,102,100,95,116,101,115,116,32,97,50,53,48,50,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,51,56,53,56,32,102,100,51,51,51,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,97,51,56,56,51,32,102,100,51,50,52,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,13),40,97,51,57,50,51,32,102,100,50,57,56,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,51,57,52,57,32,102,100,50,55,57,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,50,53,56,32,102,100,115,119,50,53,57,32,46,32,116,105,109,101,111,117,116,50,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,51,54,51,32,108,105,110,107,51,54,52,32,108,111,99,51,54,53,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,51,56,50,32,46,32,108,105,110,107,51,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,51,57,54,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,52,48,49,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,52,48,54,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,52,49,49,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,52,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,52,50,49,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,52,50,54,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,52,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,114,101,103,117,108,97,114,63,32,102,110,97,109,101,52,52,52,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,115,116,97,116,45,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,52,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,28),40,115,116,97,116,45,99,104,97,114,45,100,101,118,105,99,101,63,32,102,110,97,109,101,52,54,50,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,29),40,115,116,97,116,45,98,108,111,99,107,45,100,101,118,105,99,101,63,32,102,110,97,109,101,52,55,49,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,21),40,115,116,97,116,45,102,105,102,111,63,32,102,110,97,109,101,52,56,48,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,115,121,109,108,105,110,107,63,32,102,110,97,109,101,52,56,57,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,115,116,97,116,45,115,111,99,107,101,116,63,32,102,110,97,109,101,52,57,56,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,16),40,102,95,52,50,48,51,32,110,97,109,101,53,57,49,41};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,16),40,102,95,52,50,49,57,32,110,97,109,101,53,56,48,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,16),40,102,95,52,49,57,50,32,110,97,109,101,53,55,54,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,97,52,49,56,50,32,120,53,55,52,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,16),40,102,95,52,49,55,55,32,110,97,109,101,53,55,48,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,16),40,102,95,52,50,53,56,32,110,97,109,101,53,57,54,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,53,53,55,32,46,32,116,109,112,53,53,54,53,53,56,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,54,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,54,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,54,51,51,32,115,112,101,99,54,52,51,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,54,52,52,41,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,54,51,54,32,37,115,112,101,99,54,51,49,54,56,57,41,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,54,51,53,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,54,50,51,54,50,52,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,55,48,52,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,55,49,57,55,50,48,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,20),40,105,115,112,101,114,115,101,32,103,55,54,53,55,54,54,55,54,55,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,52,54,48,54,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,19),40,97,52,54,48,48,32,101,120,118,97,114,55,55,57,55,57,53,41,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,52,54,50,52,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,7),40,97,52,54,51,54,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,20),40,97,52,54,51,48,32,46,32,97,114,103,115,55,56,56,56,49,51,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,52,54,49,56,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,15),40,97,52,53,57,52,32,107,55,56,55,55,57,51,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,56,52,56,32,114,56,52,57,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,56,49,55,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,56,54,49,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,56,54,51,32,99,109,100,56,54,52,32,105,110,112,56,54,53,32,114,56,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,56,55,49,32,46,32,109,56,55,50,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,56,56,52,32,46,32,109,56,56,53,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,56,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,7),40,97,53,48,56,56,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,20),40,97,53,48,57,52,32,46,32,114,101,115,117,108,116,115,57,50,52,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,57,49,55,32,112,114,111,99,57,49,56,32,46,32,109,111,100,101,57,49,57,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,7),40,97,53,49,49,50,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,20),40,97,53,49,49,56,32,46,32,114,101,115,117,108,116,115,57,51,52,41,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,57,50,55,32,112,114,111,99,57,50,56,32,46,32,109,111,100,101,57,50,57,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,20),40,97,53,49,51,55,32,46,32,114,101,115,117,108,116,115,57,52,52,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,57,51,55,32,116,104,117,110,107,57,51,56,32,46,32,109,111,100,101,57,51,57,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,20),40,97,53,49,53,55,32,46,32,114,101,115,117,108,116,115,57,53,54,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,57,52,57,32,116,104,117,110,107,57,53,48,32,46,32,109,111,100,101,57,53,49,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,49,48,50,55,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,38),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,49,48,51,48,32,112,114,111,99,49,48,51,49,41,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,49,48,51,55,32,115,116,97,116,101,49,48,51,56,41,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,13),40,97,53,50,55,50,32,115,49,48,52,56,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,27),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,49,48,52,54,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,115,105,103,115,49,48,54,49,32,109,97,115,107,49,48,54,50,41};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,49,48,55,48,41};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,22),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,49,48,55,53,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,49,48,56,51,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,41),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,49,49,53,53,32,46,32,116,109,112,49,49,53,52,49,49,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,49,56,41,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,43),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,49,49,57,56,32,46,32,116,109,112,49,49,57,55,49,49,57,57,41,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,16),40,95,101,110,115,117,114,101,45,103,114,111,117,112,115,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,53,52,41,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,49,50,54,55,32,108,115,116,49,50,55,51,32,105,49,50,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,49,50,54,51,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,35),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,49,51,48,48,32,105,100,49,51,48,49,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,34),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,49,51,55,50,32,109,49,51,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,42),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,49,51,56,48,32,117,105,100,49,51,56,49,32,103,105,100,49,51,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,49,51,57,53,32,97,99,99,49,51,57,54,32,108,111,99,49,51,57,55,41,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,48,53,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,48,57,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,49,52,52,50,32,110,101,119,49,52,52,51,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,49,52,53,52,41,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,27),40,102,105,108,101,45,108,105,110,107,32,111,108,100,49,52,55,56,32,110,101,119,49,52,55,57,41,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,20),40,109,111,100,101,32,105,110,112,49,52,57,53,32,109,49,52,57,54,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,108,111,99,49,53,49,52,32,102,100,49,53,49,53,32,105,110,112,49,53,49,54,32,114,49,53,49,55,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,33),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,49,53,50,50,32,46,32,109,49,53,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,34),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,49,53,50,54,32,46,32,109,49,53,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,23),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,49,53,51,52,41,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,36),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,49,53,53,48,32,46,32,110,101,119,49,53,53,49,41,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,8),40,114,101,97,100,121,63,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,7),40,102,101,116,99,104,41,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,7),40,97,54,51,49,55,41,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,7),40,97,54,51,51,48,41,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,7),40,97,54,51,52,50,41,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,7),40,97,54,51,54,51,41,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,110,49,54,55,54,32,109,49,54,55,55,32,115,116,97,114,116,49,54,55,56,41,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,41),40,97,54,51,55,50,32,112,111,114,116,49,54,54,57,32,110,49,54,55,48,32,100,101,115,116,49,54,55,49,32,115,116,97,114,116,49,54,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,24),40,98,117,109,112,101,114,32,99,117,114,49,55,49,50,32,112,116,114,49,55,49,51,41};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,7),40,97,54,53,51,52,41,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,42),40,97,54,53,52,48,32,100,101,115,116,49,55,53,50,49,55,53,51,49,55,53,55,32,99,111,110,116,63,49,55,53,52,49,55,53,53,49,55,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,49,55,48,57,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,26),40,97,54,52,52,56,32,112,111,114,116,49,55,48,52,32,108,105,109,105,116,49,55,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,49,53,56,54,32,110,111,110,98,108,111,99,107,105,110,103,63,49,53,57,56,32,98,117,102,105,49,53,57,57,32,111,110,45,99,108,111,115,101,49,54,48,48,32,109,111,114,101,63,49,54,48,49,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,69),40,100,101,102,45,109,111,114,101,63,49,53,57,49,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,50,49,55,55,50,32,37,98,117,102,105,49,53,56,51,49,55,55,51,32,37,111,110,45,99,108,111,115,101,49,53,56,52,49,55,55,52,41,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,53,57,48,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,50,49,55,55,56,32,37,98,117,102,105,49,53,56,51,49,55,55,57,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,53,56,57,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,50,49,55,56,51,41,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,56,41,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,62),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,53,55,50,32,110,97,109,49,53,55,51,32,102,100,49,53,55,52,32,46,32,116,109,112,49,53,55,49,49,53,55,53,41,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,22),40,112,111,107,101,32,115,116,114,49,56,52,53,32,108,101,110,49,56,52,54,41,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,15),40,97,54,55,51,49,32,115,116,114,49,56,57,51,41,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,7),40,97,54,55,51,55,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,7),40,97,54,55,53,56,41,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,16),40,102,95,54,55,54,55,32,115,116,114,49,56,54,48,41};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,32,114,101,109,49,56,55,49,32,115,116,97,114,116,49,56,55,50,32,108,101,110,49,56,55,51,41};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,16),40,102,95,54,55,56,50,32,115,116,114,49,56,54,55,41};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,49),40,98,111,100,121,49,56,50,53,32,110,111,110,98,108,111,99,107,105,110,103,63,49,56,51,54,32,98,117,102,105,49,56,51,55,32,111,110,45,99,108,111,115,101,49,56,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,56,50,57,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,56,50,50,49,57,49,48,32,37,98,117,102,105,49,56,50,51,49,57,49,49,41,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,56,50,56,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,56,50,50,49,57,49,53,41,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,56,50,55,41,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,63),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,56,49,50,32,110,97,109,49,56,49,51,32,102,100,49,56,49,52,32,46,32,116,109,112,49,56,49,49,49,56,49,53,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,49,57,51,50,32,111,102,102,49,57,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,32,112,111,114,116,49,57,53,50,32,97,114,103,115,49,57,53,51,32,108,111,99,49,57,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,30),40,101,114,114,32,109,115,103,49,57,55,54,32,108,111,99,107,49,57,55,55,32,108,111,99,49,57,55,56,41,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,49,57,56,48,32,46,32,97,114,103,115,49,57,56,49,41,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,40),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,49,57,56,53,32,46,32,97,114,103,115,49,57,56,54,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,36),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,49,57,57,48,32,46,32,97,114,103,115,49,57,57,49,41,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,50,48,49,53,41,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,34),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,50,48,50,50,32,46,32,109,111,100,101,50,48,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,20),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,50,48,51,50,41,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,50,48,51,56,32,118,97,108,50,48,51,57,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,50,48,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,50,48,54,57,41,0,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,50,48,54,51,41,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,27),40,103,101,116,45,101,110,118,105,114,111,110,109,101,110,116,45,118,97,114,105,97,98,108,101,115,41,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,72),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,50,49,49,55,32,108,101,110,50,49,49,56,32,112,114,111,116,50,49,49,57,32,102,108,97,103,50,49,50,48,32,102,100,50,49,50,49,32,46,32,111,102,102,50,49,50,50,41};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,43),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,50,49,53,48,32,46,32,108,101,110,50,49,53,49,41,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,37),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,50,49,54,48,41,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,50,49,54,53,41,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,34),40,99,104,101,99,107,45,116,105,109,101,45,118,101,99,116,111,114,32,108,111,99,50,49,54,57,32,116,109,50,49,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,30),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,50,49,55,55,41,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,28),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,50,49,56,50,41,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,26),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,50,49,57,53,41,0,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,50,50,50,54,32,46,32,116,109,112,50,50,50,53,50,50,50,55,41,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,36),40,115,116,114,105,110,103,45,62,116,105,109,101,32,116,105,109,50,50,54,55,32,46,32,116,109,112,50,50,54,54,50,50,54,56,41,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,50,50,56,52,41,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,26),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,50,50,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,50,51,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,97,108,97,114,109,33,32,97,50,51,48,57,50,51,49,50,41,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,50,51,49,57,32,109,111,100,101,50,51,50,48,32,46,32,115,105,122,101,50,51,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,50,51,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,50,51,52,56,32,112,111,114,116,50,51,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,50,51,54,54,41};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,50,51,56,49,41};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,7),40,97,55,57,50,52,41,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,50,52,54,53,41,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,55),40,97,55,57,51,48,32,100,105,114,50,52,51,51,50,52,51,52,50,52,52,49,32,102,105,108,50,52,51,53,50,52,51,54,50,52,52,50,32,101,120,116,50,52,51,55,50,52,51,56,50,52,52,51,41,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,50,52,50,56,41,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,50,52,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,18),40,102,95,56,48,52,50,32,97,50,53,48,57,50,53,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,50,52,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,28),40,115,101,116,97,114,103,32,97,50,53,50,50,50,53,50,56,32,97,50,53,50,49,50,53,50,57,41,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,28),40,115,101,116,101,110,118,32,97,50,53,51,55,50,53,52,51,32,97,50,53,51,54,50,53,52,52,41,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,50,53,57,52,32,105,50,54,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,25),40,100,111,108,111,111,112,50,53,56,51,32,97,108,50,53,56,57,32,105,50,53,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,50,53,54,56,32,97,114,103,108,105,115,116,50,53,55,56,32,101,110,118,108,105,115,116,50,53,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,34),40,100,101,102,45,101,110,118,108,105,115,116,50,53,55,49,32,37,97,114,103,108,105,115,116,50,53,54,54,50,54,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,97,114,103,108,105,115,116,50,53,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,50,53,53,56,32,46,32,116,109,112,50,53,53,55,50,53,53,57,41,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,50,54,53,50,32,110,111,104,97,110,103,50,54,53,51,41,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,7),40,97,56,51,50,52,41,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,36),40,97,56,51,51,48,32,101,112,105,100,50,54,57,56,32,101,110,111,114,109,50,54,57,57,32,101,99,111,100,101,50,55,48,48,41,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,50,54,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,50,55,49,50,50,55,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,50,55,49,56,32,46,32,115,105,103,50,55,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,50,55,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,50,55,52,55,32,46,32,97,114,103,115,50,55,52,56,41,0,0};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,7),40,97,56,53,48,48,41,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,29),40,97,56,53,48,54,32,95,50,55,57,55,32,102,108,103,50,55,57,56,32,99,111,100,50,55,57,57,41,0,0,0};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,8),40,102,95,56,52,56,54,41};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,111,110,45,99,108,111,115,101,32,108,111,99,50,55,56,50,32,112,105,100,50,55,56,51,32,99,108,115,118,101,99,50,55,56,52,32,105,100,120,50,55,56,53,32,105,100,120,97,50,55,56,54,32,105,100,120,98,50,55,56,55,41,0,0,0,0};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,7),40,97,56,53,50,57,41,0};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,19),40,97,56,53,51,53,32,105,50,56,49,50,32,111,50,56,49,51,41,0,0,0,0,0};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,101,100,45,112,105,112,101,32,112,111,114,116,50,56,48,53,41,0,0};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,34),40,99,111,110,110,101,99,116,45,112,97,114,101,110,116,32,112,105,112,101,50,56,49,54,32,112,111,114,116,50,56,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,43),40,99,111,110,110,101,99,116,45,99,104,105,108,100,32,112,105,112,101,50,56,50,55,32,112,111,114,116,50,56,50,56,32,115,116,100,102,100,50,56,50,57,41,0,0,0,0,0};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,14),40,115,119,97,112,112,101,100,45,101,110,100,115,41,0,0};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,7),40,97,56,54,49,48,41,0};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,67),40,115,112,97,119,110,32,99,109,100,50,56,52,56,32,97,114,103,115,50,56,52,57,32,101,110,118,50,56,53,48,32,115,116,100,111,117,116,102,50,56,53,49,32,115,116,100,105,110,102,50,56,53,50,32,115,116,100,101,114,114,102,50,56,53,51,41,0,0,0,0,0};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,59),40,105,110,112,117,116,45,112,111,114,116,32,108,111,99,50,56,54,51,32,99,109,100,50,56,54,53,32,112,105,112,101,50,56,54,54,32,115,116,100,102,50,56,54,55,32,111,110,45,99,108,111,115,101,50,56,54,57,41,0,0,0,0,0};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,60),40,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,50,56,55,54,32,99,109,100,50,56,55,56,32,112,105,112,101,50,56,55,57,32,115,116,100,102,50,56,56,48,32,111,110,45,99,108,111,115,101,50,56,56,50,41,0,0,0,0};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,7),40,97,56,54,54,48,41,0};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,50),40,97,56,54,54,54,32,105,110,112,105,112,101,50,57,48,49,32,111,117,116,112,105,112,101,50,57,48,50,32,101,114,114,112,105,112,101,50,57,48,51,32,112,105,100,50,57,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,50,56,57,48,32,99,109,100,50,56,57,49,32,97,114,103,115,50,56,57,50,32,101,110,118,50,56,57,51,32,115,116,100,111,117,116,102,50,56,57,52,32,115,116,100,105,110,102,50,56,57,53,32,115,116,100,101,114,114,102,50,56,57,54,41,0,0,0,0,0};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,21),40,97,56,55,50,51,32,103,50,57,50,54,50,57,50,55,50,57,50,56,41,0,0,0};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,50,57,49,57,41,0,0,0,0,0};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,7),40,97,56,55,52,49,41,0};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,38),40,97,56,55,52,55,32,105,110,50,57,51,56,32,111,117,116,50,57,51,57,32,112,105,100,50,57,52,48,32,101,114,114,50,57,52,49,41,0,0};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,52),40,37,112,114,111,99,101,115,115,32,108,111,99,50,57,49,50,32,101,114,114,63,50,57,49,51,32,99,109,100,50,57,49,52,32,97,114,103,115,50,57,49,53,32,101,110,118,50,57,49,54,41,0,0,0,0};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,50,57,54,51,32,97,114,103,115,50,57,55,51,32,101,110,118,50,57,55,52,41,0,0,0,0,0};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,50,57,54,54,32,37,97,114,103,115,50,57,54,49,50,57,55,56,41,0,0,0,0,0};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,50,57,54,53,41,0,0};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,50,57,53,51,32,46,32,116,109,112,50,57,53,50,50,57,53,52,41,0};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,51,48,48,55,32,97,114,103,115,51,48,49,55,32,101,110,118,51,48,49,56,41,0,0,0,0,0};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,51,48,49,48,32,37,97,114,103,115,51,48,48,53,51,48,50,50,41,0,0,0,0,0};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,51,48,48,57,41,0,0};
static C_char C_TLS li239[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,50,57,57,55,32,46,32,116,109,112,50,57,57,54,50,57,57,56,41};
static C_char C_TLS li240[] C_aligned={C_lihdr(0,0,14),40,102,95,57,48,51,55,32,120,51,48,57,50,41,0,0};
static C_char C_TLS li241[] C_aligned={C_lihdr(0,0,7),40,97,56,57,54,48,41,0};
static C_char C_TLS li242[] C_aligned={C_lihdr(0,0,7),40,97,56,57,54,53,41,0};
static C_char C_TLS li243[] C_aligned={C_lihdr(0,0,7),40,97,56,57,56,57,41,0};
static C_char C_TLS li244[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,51,48,57,56,32,114,51,48,57,57,41,0,0,0,0,0};
static C_char C_TLS li245[] C_aligned={C_lihdr(0,0,16),40,102,95,57,48,53,54,32,46,32,95,51,48,56,50,41};
static C_char C_TLS li246[] C_aligned={C_lihdr(0,0,16),40,102,95,57,48,52,56,32,46,32,95,51,48,56,48,41};
static C_char C_TLS li247[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,51,48,53,52,32,97,99,116,105,111,110,51,48,54,53,32,105,100,51,48,54,54,32,108,105,109,105,116,51,48,54,55,41,0,0};
static C_char C_TLS li248[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,51,48,53,56,32,37,97,99,116,105,111,110,51,48,53,49,51,49,51,57,32,37,105,100,51,48,53,50,51,49,52,48,41,0,0,0,0,0};
static C_char C_TLS li249[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,51,48,53,55,32,37,97,99,116,105,111,110,51,48,53,49,51,49,52,52,41,0,0,0,0};
static C_char C_TLS li250[] C_aligned={C_lihdr(0,0,19),40,97,57,48,55,54,32,120,51,49,52,57,32,121,51,49,53,48,41,0,0,0,0,0};
static C_char C_TLS li251[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,51,48,53,54,41};
static C_char C_TLS li252[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,51,48,52,50,32,112,114,101,100,51,48,52,51,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,51,48,52,52,41,0,0,0,0,0};
static C_char C_TLS li253[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,51,49,55,52,41,0,0,0};
static C_char C_TLS li254[] C_aligned={C_lihdr(0,0,15),40,97,57,49,55,53,32,112,105,100,49,52,50,52,41,0};
static C_char C_TLS li255[] C_aligned={C_lihdr(0,0,24),40,97,57,49,57,51,32,112,105,100,49,52,51,51,32,112,103,105,100,49,52,51,52,41};
static C_char C_TLS li256[] C_aligned={C_lihdr(0,0,7),40,97,57,50,49,52,41,0};
static C_char C_TLS li257[] C_aligned={C_lihdr(0,0,14),40,97,57,50,49,55,32,105,100,49,49,51,53,41,0,0};
static C_char C_TLS li258[] C_aligned={C_lihdr(0,0,7),40,97,57,50,51,50,41,0};
static C_char C_TLS li259[] C_aligned={C_lihdr(0,0,14),40,97,57,50,51,53,32,105,100,49,49,50,54,41,0,0};
static C_char C_TLS li260[] C_aligned={C_lihdr(0,0,7),40,97,57,50,53,48,41,0};
static C_char C_TLS li261[] C_aligned={C_lihdr(0,0,14),40,97,57,50,53,51,32,105,100,49,49,49,55,41,0,0};
static C_char C_TLS li262[] C_aligned={C_lihdr(0,0,7),40,97,57,50,54,56,41,0};
static C_char C_TLS li263[] C_aligned={C_lihdr(0,0,14),40,97,57,50,55,49,32,105,100,49,49,48,56,41,0,0};
static C_char C_TLS li264[] C_aligned={C_lihdr(0,0,13),40,97,57,50,56,54,32,110,49,48,57,48,41,0,0,0};
static C_char C_TLS li265[] C_aligned={C_lihdr(0,0,15),40,97,57,50,57,50,32,112,111,114,116,53,48,54,41,0};
static C_char C_TLS li266[] C_aligned={C_lihdr(0,0,34),40,97,57,51,50,57,32,112,111,114,116,53,50,48,32,112,111,115,53,50,49,32,46,32,119,104,101,110,99,101,53,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li267[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k9143 in set-root-directory! in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall stub3166(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3166(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k8382 */
static C_word C_fcall stub2713(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2713(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall stub2708(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2708(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall stub2704(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2704(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub2548(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2548(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k8088 */
static C_word C_fcall stub2539(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2539(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub2533(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2533(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k8069 */
static C_word C_fcall stub2524(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2524(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k8045 */
static C_word C_fcall stub2510(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2510(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub2492(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2492(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2403(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2403(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k7854 */
static C_word C_fcall stub2374(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2374(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k7831 */
static C_word C_fcall stub2359(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2359(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k7720 */
static C_word C_fcall stub2310(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2310(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k7698 */
static C_word C_fcall stub2301(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2301(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2293(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2293(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub2254(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2254(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub2212(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2212(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub2204(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2204(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k7505 */
static C_word C_fcall stub2188(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2188(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k7405 */
static C_word C_fcall stub2141(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2141(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k7343 */
static C_word C_fcall stub2102(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub2102(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k7242 */
static C_word C_fcall stub2053(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2053(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k5993 in k5989 in file-link in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall stub1466(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1466(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k5730 */
static C_word C_fcall stub1291(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1291(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k5599 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub1232(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1232(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from k5592 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1226(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1226(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from k5506 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1184(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1184(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a9214 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall stub1132(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1132(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a9232 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall stub1123(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1123(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a9250 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall stub1114(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1114(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a9268 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall stub1105(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1105(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k3774 */
static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k3764 */
static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k3754 */
static C_word C_fcall stub239(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub239(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k3536 */
static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from k3485 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub46(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub46(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from k3478 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub40(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub40(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k3454 */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9330)
static void C_ccall f_9330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9330)
static void C_ccall f_9330r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9343)
static void C_ccall f_9343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9355)
static void C_ccall f_9355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9349)
static void C_ccall f_9349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9293)
static void C_ccall f_9293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9309)
static void C_ccall f_9309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9297)
static void C_ccall f_9297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9300)
static void C_ccall f_9300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5213)
static void C_ccall f_5213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9287)
static void C_ccall f_9287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5348)
static void C_ccall f_5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9272)
static void C_ccall f_9272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9282)
static void C_ccall f_9282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9269)
static void C_ccall f_9269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9254)
static void C_ccall f_9254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9264)
static void C_ccall f_9264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9251)
static void C_ccall f_9251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9236)
static void C_ccall f_9236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9246)
static void C_ccall f_9246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9233)
static void C_ccall f_9233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9218)
static void C_ccall f_9218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9228)
static void C_ccall f_9228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9215)
static void C_ccall f_9215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9194)
static void C_ccall f_9194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9210)
static void C_ccall f_9210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9189)
static void C_ccall f_9189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9183)
static void C_ccall f_9183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5959)
static void C_ccall f_5959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9153)
static void C_ccall f_9153(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9145)
static void C_ccall f_9145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8894)
static void C_ccall f_8894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8894)
static void C_ccall f_8894r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9071)
static void C_fcall f_9071(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9077)
static void C_ccall f_9077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9066)
static void C_fcall f_9066(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9061)
static void C_fcall f_9061(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8896)
static void C_fcall f_8896(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9048)
static void C_ccall f_9048(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9056)
static void C_ccall f_9056(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8903)
static void C_fcall f_8903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9036)
static void C_ccall f_9036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9030)
static void C_ccall f_9030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8913)
static void C_ccall f_8913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8915)
static void C_fcall f_8915(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8934)
static void C_ccall f_8934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9016)
static void C_ccall f_9016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9023)
static void C_ccall f_9023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9010)
static void C_ccall f_9010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8949)
static void C_ccall f_8949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9003)
static void C_ccall f_9003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9000)
static void C_ccall f_9000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8990)
static void C_ccall f_8990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8966)
static void C_ccall f_8966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8988)
static void C_ccall f_8988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8974)
static void C_ccall f_8974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8981)
static void C_ccall f_8981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8978)
static void C_ccall f_8978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8961)
static void C_ccall f_8961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8959)
static void C_ccall f_8959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9037)
static void C_ccall f_9037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8834)
static void C_ccall f_8834(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8834)
static void C_ccall f_8834r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8846)
static void C_fcall f_8846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8841)
static void C_fcall f_8841(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8836)
static void C_fcall f_8836(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8774)
static void C_ccall f_8774(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8774)
static void C_ccall f_8774r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8786)
static void C_fcall f_8786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8781)
static void C_fcall f_8781(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8776)
static void C_fcall f_8776(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8713)
static void C_fcall f_8713(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8768)
static void C_ccall f_8768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8772)
static void C_ccall f_8772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8734)
static void C_ccall f_8734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8737)
static void C_ccall f_8737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8748)
static void C_ccall f_8748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8742)
static void C_ccall f_8742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8715)
static void C_fcall f_8715(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8655)
static void C_ccall f_8655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8667)
static void C_ccall f_8667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8698)
static void C_ccall f_8698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8678)
static void C_ccall f_8678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8694)
static void C_ccall f_8694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8682)
static void C_ccall f_8682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8690)
static void C_ccall f_8690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8686)
static void C_ccall f_8686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8661)
static void C_ccall f_8661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8644)
static void C_fcall f_8644(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8648)
static void C_ccall f_8648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8633)
static void C_fcall f_8633(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8637)
static void C_ccall f_8637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8588)
static void C_fcall f_8588(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8592)
static void C_ccall f_8592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8598)
static void C_ccall f_8598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8611)
static void C_ccall f_8611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8615)
static void C_ccall f_8615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8618)
static void C_ccall f_8618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8621)
static void C_ccall f_8621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8609)
static void C_ccall f_8609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8572)
static C_word C_fcall f_8572(C_word *a,C_word t0);
C_noret_decl(f_8555)
static void C_fcall f_8555(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8568)
static void C_ccall f_8568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8480)
static void C_ccall f_8480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8541)
static void C_fcall f_8541(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8554)
static void C_ccall f_8554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8521)
static void C_fcall f_8521(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8536)
static void C_ccall f_8536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8530)
static void C_ccall f_8530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8484)
static void C_fcall f_8484(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8486)
static void C_ccall f_8486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8507)
static void C_ccall f_8507(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8501)
static void C_ccall f_8501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8428)
static void C_ccall f_8428(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8428)
static void C_ccall f_8428r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8435)
static void C_ccall f_8435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8454)
static void C_ccall f_8454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8458)
static void C_ccall f_8458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8422)
static void C_ccall f_8422(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8413)
static void C_ccall f_8413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8417)
static void C_ccall f_8417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8386)
static void C_ccall f_8386(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8386)
static void C_ccall f_8386r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8379)
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8376)
static void C_ccall f_8376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8373)
static void C_ccall f_8373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8295)
static void C_ccall f_8295(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8295)
static void C_ccall f_8295r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8331)
static void C_ccall f_8331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8325)
static void C_ccall f_8325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8096)
static void C_ccall f_8096(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8096)
static void C_ccall f_8096r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8230)
static void C_fcall f_8230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8225)
static void C_fcall f_8225(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8098)
static void C_fcall f_8098(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8116)
static void C_fcall f_8116(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8162)
static C_word C_fcall f_8162(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8129)
static void C_fcall f_8129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8132)
static void C_ccall f_8132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8077)
static C_word C_fcall f_8077(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8058)
static C_word C_fcall f_8058(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8016)
static void C_ccall f_8016(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8016)
static void C_ccall f_8016r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8038)
static void C_ccall f_8038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8042)
static void C_ccall f_8042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7910)
static void C_fcall f_7910(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7931)
static void C_ccall f_7931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8008)
static void C_ccall f_8008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7935)
static void C_ccall f_7935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7941)
static void C_ccall f_7941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_fcall f_7950(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7967)
static void C_ccall f_7967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7977)
static void C_ccall f_7977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7981)
static void C_ccall f_7981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7925)
static void C_ccall f_7925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7892)
static void C_ccall f_7892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_ccall f_7899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7861)
static void C_ccall f_7861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7834)
static void C_ccall f_7834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7802)
static void C_fcall f_7802(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7806)
static void C_ccall f_7806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7790)
static void C_ccall f_7790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7724)
static void C_ccall f_7724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7724)
static void C_ccall f_7724r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7728)
static void C_ccall f_7728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7701)
static void C_ccall f_7701(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7701)
static void C_ccall f_7701r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7689)
static void C_ccall f_7689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7674)
static void C_ccall f_7674(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7678)
static void C_ccall f_7678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7659)
static void C_ccall f_7659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7663)
static void C_ccall f_7663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7613)
static void C_ccall f_7613r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7617)
static void C_ccall f_7617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7630)
static void C_ccall f_7630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7634)
static void C_ccall f_7634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7544)
static void C_ccall f_7544(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7544)
static void C_ccall f_7544r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7548)
static void C_ccall f_7548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7551)
static void C_ccall f_7551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7573)
static void C_ccall f_7573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7570)
static void C_ccall f_7570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7560)
static void C_ccall f_7560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7508)
static void C_ccall f_7508(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7480)
static void C_ccall f_7480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7461)
static void C_fcall f_7461(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7455)
static void C_ccall f_7455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7446)
static void C_ccall f_7446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_7353)
static void C_ccall f_7353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7245)
static void C_ccall f_7245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7251)
static void C_fcall f_7251(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7255)
static void C_ccall f_7255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7263)
static void C_fcall f_7263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7289)
static void C_ccall f_7289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7293)
static void C_ccall f_7293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7281)
static void C_ccall f_7281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7225)
static void C_ccall f_7225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7233)
static void C_ccall f_7233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7219)
static void C_ccall f_7219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7206)
static void C_ccall f_7206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7189)
static void C_ccall f_7189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7139)
static void C_ccall f_7139(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7139)
static void C_ccall f_7139r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7146)
static void C_fcall f_7146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7167)
static void C_ccall f_7167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7163)
static void C_ccall f_7163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7093)
static void C_ccall f_7093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7063)
static void C_ccall f_7063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7041)
static void C_fcall f_7041(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6967)
static void C_fcall f_6967(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_fcall f_6995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6928)
static void C_ccall f_6928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6945)
static void C_ccall f_6945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6669)
static void C_ccall f_6669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6669)
static void C_ccall f_6669r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6865)
static void C_fcall f_6865(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6860)
static void C_fcall f_6860(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6855)
static void C_fcall f_6855(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6671)
static void C_fcall f_6671(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6675)
static void C_ccall f_6675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6799)
static void C_fcall f_6799(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6723)
static void C_fcall f_6723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6748)
static void C_ccall f_6748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6732)
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6677)
static void C_fcall f_6677(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6693)
static void C_ccall f_6693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6591)
static void C_fcall f_6591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_fcall f_6586(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6581)
static void C_fcall f_6581(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6576)
static void C_fcall f_6576(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6189)
static void C_fcall f_6189(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6455)
static void C_fcall f_6455(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6551)
static void C_ccall f_6551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6507)
static void C_ccall f_6507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6464)
static void C_ccall f_6464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6381)
static void C_fcall f_6381(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6383)
static void C_fcall f_6383(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6331)
static void C_ccall f_6331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6316)
static void C_ccall f_6316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6231)
static void C_fcall f_6231(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6243)
static void C_fcall f_6243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6289)
static void C_ccall f_6289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6283)
static void C_ccall f_6283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6259)
static void C_ccall f_6259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6223)
static C_word C_fcall f_6223(C_word t0);
C_noret_decl(f_6200)
static void C_fcall f_6200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_ccall f_6204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6160)
static void C_ccall f_6160(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6160)
static void C_ccall f_6160r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6167)
static void C_fcall f_6167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6170)
static void C_ccall f_6170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6087)
static void C_ccall f_6087(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6087)
static void C_ccall f_6087r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6099)
static void C_ccall f_6099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6072)
static void C_fcall f_6072(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6035)
static void C_fcall f_6035(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6043)
static void C_ccall f_6043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6010)
static void C_ccall f_6010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5995)
static void C_ccall f_5995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5903)
static void C_ccall f_5903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5907)
static void C_ccall f_5907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5861)
static void C_fcall f_5861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5879)
static void C_ccall f_5879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5829)
static void C_ccall f_5829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_fcall f_5675(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_ccall f_5603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5661)
static void C_ccall f_5661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5618)
static void C_fcall f_5618(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5596)
static C_word C_fcall f_5596(C_word t0);
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_fcall f_5517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5531)
static void C_ccall f_5531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static void C_fcall f_5540(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5485)
static void C_ccall f_5485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5483)
static void C_ccall f_5483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5408)
static void C_ccall f_5408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5411)
static void C_fcall f_5411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5350)
static void C_ccall f_5350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5361)
static void C_ccall f_5361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5365)
static void C_ccall f_5365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5369)
static void C_ccall f_5369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5317)
static void C_ccall f_5317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_fcall f_5285(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5237)
static void C_ccall f_5237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5224)
static void C_ccall f_5224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5142)
static void C_ccall f_5142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5113)
static void C_ccall f_5113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5099)
static void C_ccall f_5099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5068)
static void C_ccall f_5068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_fcall f_4977(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4990)
static void C_ccall f_4990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_fcall f_4971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static C_word C_fcall f_4959(C_word t0);
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_fcall f_4769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_ccall f_4935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4788)
static void C_fcall f_4788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4909)
static void C_ccall f_4909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4832)
static void C_fcall f_4832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_fcall f_4658(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4726)
static void C_fcall f_4726(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_fcall f_4586(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static C_word C_fcall f_4575(C_word t0);
C_noret_decl(f_4570)
static void C_fcall f_4570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4447)
static void C_fcall f_4447(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_fcall f_4442(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4344)
static void C_fcall f_4344(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4375)
static void C_fcall f_4375(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_fcall f_4397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4340)
static void C_ccall f_4340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_ccall f_4119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_fcall f_3969(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_fcall f_3802(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_fcall f_3841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_fcall f_3845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static C_word C_fcall f_3767(C_word t0,C_word t1);
C_noret_decl(f_3757)
static C_word C_fcall f_3757(C_word t0,C_word t1);
C_noret_decl(f_3751)
static C_word C_fcall f_3751(C_word t0);
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3602)
static void C_ccall f_3602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9071)
static void C_fcall trf_9071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9071(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9071(t0,t1);}

C_noret_decl(trf_9066)
static void C_fcall trf_9066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9066(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9066(t0,t1,t2);}

C_noret_decl(trf_9061)
static void C_fcall trf_9061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9061(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9061(t0,t1,t2,t3);}

C_noret_decl(trf_8896)
static void C_fcall trf_8896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8896(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8896(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8903)
static void C_fcall trf_8903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8903(t0,t1);}

C_noret_decl(trf_8915)
static void C_fcall trf_8915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8915(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8915(t0,t1,t2,t3);}

C_noret_decl(trf_8846)
static void C_fcall trf_8846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8846(t0,t1);}

C_noret_decl(trf_8841)
static void C_fcall trf_8841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8841(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8841(t0,t1,t2);}

C_noret_decl(trf_8836)
static void C_fcall trf_8836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8836(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8836(t0,t1,t2,t3);}

C_noret_decl(trf_8786)
static void C_fcall trf_8786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8786(t0,t1);}

C_noret_decl(trf_8781)
static void C_fcall trf_8781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8781(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8781(t0,t1,t2);}

C_noret_decl(trf_8776)
static void C_fcall trf_8776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8776(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8776(t0,t1,t2,t3);}

C_noret_decl(trf_8713)
static void C_fcall trf_8713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8713(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8713(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8715)
static void C_fcall trf_8715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8715(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8715(t0,t1,t2);}

C_noret_decl(trf_8644)
static void C_fcall trf_8644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8644(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8644(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8633)
static void C_fcall trf_8633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8633(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8633(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8588)
static void C_fcall trf_8588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8588(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8588(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8555)
static void C_fcall trf_8555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8555(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8555(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8541)
static void C_fcall trf_8541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8541(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8541(t0,t1,t2,t3);}

C_noret_decl(trf_8521)
static void C_fcall trf_8521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8521(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8521(t0,t1,t2);}

C_noret_decl(trf_8484)
static void C_fcall trf_8484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8484(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8484(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8230)
static void C_fcall trf_8230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8230(t0,t1);}

C_noret_decl(trf_8225)
static void C_fcall trf_8225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8225(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8225(t0,t1,t2);}

C_noret_decl(trf_8098)
static void C_fcall trf_8098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8098(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8098(t0,t1,t2,t3);}

C_noret_decl(trf_8116)
static void C_fcall trf_8116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8116(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8116(t0,t1,t2,t3);}

C_noret_decl(trf_8129)
static void C_fcall trf_8129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8129(t0,t1);}

C_noret_decl(trf_7910)
static void C_fcall trf_7910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7910(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7910(t0,t1,t2);}

C_noret_decl(trf_7950)
static void C_fcall trf_7950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7950(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7950(t0,t1,t2);}

C_noret_decl(trf_7802)
static void C_fcall trf_7802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7802(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7802(t0,t1,t2);}

C_noret_decl(trf_7461)
static void C_fcall trf_7461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7461(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7461(t0,t1,t2);}

C_noret_decl(trf_7251)
static void C_fcall trf_7251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7251(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7251(t0,t1,t2);}

C_noret_decl(trf_7263)
static void C_fcall trf_7263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7263(t0,t1,t2);}

C_noret_decl(trf_7146)
static void C_fcall trf_7146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7146(t0,t1);}

C_noret_decl(trf_7041)
static void C_fcall trf_7041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7041(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7041(t0,t1,t2,t3);}

C_noret_decl(trf_6967)
static void C_fcall trf_6967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6967(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6967(t0,t1,t2,t3);}

C_noret_decl(trf_6995)
static void C_fcall trf_6995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6995(t0,t1);}

C_noret_decl(trf_6865)
static void C_fcall trf_6865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6865(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6865(t0,t1);}

C_noret_decl(trf_6860)
static void C_fcall trf_6860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6860(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6860(t0,t1,t2);}

C_noret_decl(trf_6855)
static void C_fcall trf_6855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6855(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6855(t0,t1,t2,t3);}

C_noret_decl(trf_6671)
static void C_fcall trf_6671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6671(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6671(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6799)
static void C_fcall trf_6799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6799(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6799(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6723)
static void C_fcall trf_6723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6723(t0,t1);}

C_noret_decl(trf_6677)
static void C_fcall trf_6677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6677(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6677(t0,t1,t2,t3);}

C_noret_decl(trf_6591)
static void C_fcall trf_6591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6591(t0,t1);}

C_noret_decl(trf_6586)
static void C_fcall trf_6586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6586(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6586(t0,t1,t2);}

C_noret_decl(trf_6581)
static void C_fcall trf_6581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6581(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6581(t0,t1,t2,t3);}

C_noret_decl(trf_6576)
static void C_fcall trf_6576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6576(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6576(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6189)
static void C_fcall trf_6189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6189(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6189(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6455)
static void C_fcall trf_6455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6455(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6455(t0,t1,t2);}

C_noret_decl(trf_6381)
static void C_fcall trf_6381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6381(t0,t1);}

C_noret_decl(trf_6383)
static void C_fcall trf_6383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6383(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6383(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6231)
static void C_fcall trf_6231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6231(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6231(t0,t1);}

C_noret_decl(trf_6243)
static void C_fcall trf_6243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6243(t0,t1);}

C_noret_decl(trf_6200)
static void C_fcall trf_6200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6200(t0,t1);}

C_noret_decl(trf_6167)
static void C_fcall trf_6167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6167(t0,t1);}

C_noret_decl(trf_6072)
static void C_fcall trf_6072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6072(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6072(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6035)
static void C_fcall trf_6035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6035(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6035(t0,t1,t2);}

C_noret_decl(trf_5861)
static void C_fcall trf_5861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5861(t0,t1,t2,t3);}

C_noret_decl(trf_5675)
static void C_fcall trf_5675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5675(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5675(t0,t1,t2,t3);}

C_noret_decl(trf_5618)
static void C_fcall trf_5618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5618(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5618(t0,t1,t2);}

C_noret_decl(trf_5517)
static void C_fcall trf_5517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5517(t0,t1);}

C_noret_decl(trf_5540)
static void C_fcall trf_5540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5540(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5540(t0,t1,t2);}

C_noret_decl(trf_5411)
static void C_fcall trf_5411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5411(t0,t1);}

C_noret_decl(trf_5285)
static void C_fcall trf_5285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5285(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5285(t0,t1,t2,t3);}

C_noret_decl(trf_4977)
static void C_fcall trf_4977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4977(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4977(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4971)
static void C_fcall trf_4971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4971(t0,t1);}

C_noret_decl(trf_4769)
static void C_fcall trf_4769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4769(t0,t1);}

C_noret_decl(trf_4788)
static void C_fcall trf_4788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4788(t0,t1);}

C_noret_decl(trf_4832)
static void C_fcall trf_4832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4832(t0,t1);}

C_noret_decl(trf_4658)
static void C_fcall trf_4658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4658(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4658(t0,t1,t2,t3);}

C_noret_decl(trf_4726)
static void C_fcall trf_4726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4726(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4726(t0,t1);}

C_noret_decl(trf_4586)
static void C_fcall trf_4586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4586(t0,t1);}

C_noret_decl(trf_4570)
static void C_fcall trf_4570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4570(t0,t1);}

C_noret_decl(trf_4447)
static void C_fcall trf_4447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4447(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4447(t0,t1);}

C_noret_decl(trf_4442)
static void C_fcall trf_4442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4442(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4442(t0,t1,t2);}

C_noret_decl(trf_4344)
static void C_fcall trf_4344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4344(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4344(t0,t1,t2,t3);}

C_noret_decl(trf_4375)
static void C_fcall trf_4375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4375(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4375(t0,t1);}

C_noret_decl(trf_4397)
static void C_fcall trf_4397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4397(t0,t1);}

C_noret_decl(trf_3969)
static void C_fcall trf_3969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3969(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3969(t0,t1,t2,t3);}

C_noret_decl(trf_3802)
static void C_fcall trf_3802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3802(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3802(t0,t1);}

C_noret_decl(trf_3841)
static void C_fcall trf_3841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3841(t0,t1);}

C_noret_decl(trf_3845)
static void C_fcall trf_3845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3845(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3845(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3340)){
C_save(t1);
C_rereclaim2(3340*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,465);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_h_intern(&lf[51],9,"file-open");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[53]=C_h_intern(&lf[53],17,"\003sysmake-c-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysexpand-home-path");
lf[55]=C_h_intern(&lf[55],10,"file-close");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],10,"file-write");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[65]=C_h_intern(&lf[65],12,"file-mkstemp");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[68]=C_h_intern(&lf[68],11,"file-select");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[70]=C_h_intern(&lf[70],12,"\003sysfor-each");
lf[71]=C_h_intern(&lf[71],8,"seek/set");
lf[72]=C_h_intern(&lf[72],8,"seek/end");
lf[73]=C_h_intern(&lf[73],8,"seek/cur");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[77]=C_h_intern(&lf[77],9,"file-stat");
lf[78]=C_h_intern(&lf[78],9,"file-size");
lf[79]=C_h_intern(&lf[79],22,"file-modification-time");
lf[80]=C_h_intern(&lf[80],16,"file-access-time");
lf[81]=C_h_intern(&lf[81],16,"file-change-time");
lf[82]=C_h_intern(&lf[82],10,"file-owner");
lf[83]=C_h_intern(&lf[83],16,"file-permissions");
lf[84]=C_h_intern(&lf[84],13,"regular-file\077");
lf[85]=C_h_intern(&lf[85],14,"symbolic-link\077");
lf[86]=C_h_intern(&lf[86],13,"stat-regular\077");
lf[87]=C_h_intern(&lf[87],15,"stat-directory\077");
lf[88]=C_h_intern(&lf[88],17,"stat-char-device\077");
lf[89]=C_h_intern(&lf[89],18,"stat-block-device\077");
lf[90]=C_h_intern(&lf[90],10,"stat-fifo\077");
lf[91]=C_h_intern(&lf[91],13,"stat-symlink\077");
lf[92]=C_h_intern(&lf[92],12,"stat-socket\077");
lf[93]=C_h_intern(&lf[93],13,"file-position");
lf[94]=C_h_intern(&lf[94],16,"create-directory");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot stat file");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\026path segment is a file");
lf[99]=C_h_intern(&lf[99],12,"file-exists\077");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[101]=C_h_intern(&lf[101],12,"string-split");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[103]=C_h_intern(&lf[103],14,"canonical-path");
lf[104]=C_h_intern(&lf[104],16,"change-directory");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[106]=C_h_intern(&lf[106],16,"delete-directory");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[108]=C_h_intern(&lf[108],10,"string-ref");
lf[109]=C_h_intern(&lf[109],6,"string");
lf[110]=C_h_intern(&lf[110],9,"directory");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[112]=C_h_intern(&lf[112],16,"\003sysmake-pointer");
lf[113]=C_h_intern(&lf[113],17,"current-directory");
lf[114]=C_h_intern(&lf[114],10,"directory\077");
lf[115]=C_h_intern(&lf[115],13,"\003sysfile-info");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[117]=C_h_intern(&lf[117],5,"null\077");
lf[118]=C_h_intern(&lf[118],6,"char=\077");
lf[119]=C_h_intern(&lf[119],8,"string=\077");
lf[120]=C_h_intern(&lf[120],16,"char-alphabetic\077");
lf[121]=C_h_intern(&lf[121],18,"string-intersperse");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[123]=C_h_intern(&lf[123],6,"getenv");
lf[124]=C_h_intern(&lf[124],17,"current-user-name");
lf[125]=C_h_intern(&lf[125],9,"condition");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[127]=C_h_intern(&lf[127],22,"with-exception-handler");
lf[128]=C_h_intern(&lf[128],30,"call-with-current-continuation");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[132]=C_h_intern(&lf[132],7,"reverse");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[143]=C_h_intern(&lf[143],5,"\000text");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[146]=C_h_intern(&lf[146],13,"\003sysmake-port");
lf[147]=C_h_intern(&lf[147],21,"\003sysstream-port-class");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[149]=C_h_intern(&lf[149],6,"stream");
lf[150]=C_h_intern(&lf[150],15,"open-input-pipe");
lf[151]=C_h_intern(&lf[151],7,"\000binary");
lf[152]=C_h_intern(&lf[152],16,"open-output-pipe");
lf[153]=C_h_intern(&lf[153],16,"close-input-pipe");
lf[154]=C_h_intern(&lf[154],23,"close-input/output-pipe");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[156]=C_h_intern(&lf[156],14,"\003syscheck-port");
lf[157]=C_h_intern(&lf[157],17,"close-output-pipe");
lf[158]=C_h_intern(&lf[158],20,"call-with-input-pipe");
lf[159]=C_h_intern(&lf[159],21,"call-with-output-pipe");
lf[160]=C_h_intern(&lf[160],20,"with-input-from-pipe");
lf[161]=C_h_intern(&lf[161],18,"\003sysstandard-input");
lf[162]=C_h_intern(&lf[162],19,"with-output-to-pipe");
lf[163]=C_h_intern(&lf[163],19,"\003sysstandard-output");
lf[164]=C_h_intern(&lf[164],11,"create-pipe");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[166]=C_h_intern(&lf[166],11,"signal/term");
lf[167]=C_h_intern(&lf[167],11,"signal/kill");
lf[168]=C_h_intern(&lf[168],10,"signal/int");
lf[169]=C_h_intern(&lf[169],10,"signal/hup");
lf[170]=C_h_intern(&lf[170],10,"signal/fpe");
lf[171]=C_h_intern(&lf[171],10,"signal/ill");
lf[172]=C_h_intern(&lf[172],11,"signal/segv");
lf[173]=C_h_intern(&lf[173],11,"signal/abrt");
lf[174]=C_h_intern(&lf[174],11,"signal/trap");
lf[175]=C_h_intern(&lf[175],11,"signal/quit");
lf[176]=C_h_intern(&lf[176],11,"signal/alrm");
lf[177]=C_h_intern(&lf[177],13,"signal/vtalrm");
lf[178]=C_h_intern(&lf[178],11,"signal/prof");
lf[179]=C_h_intern(&lf[179],9,"signal/io");
lf[180]=C_h_intern(&lf[180],10,"signal/urg");
lf[181]=C_h_intern(&lf[181],11,"signal/chld");
lf[182]=C_h_intern(&lf[182],11,"signal/cont");
lf[183]=C_h_intern(&lf[183],11,"signal/stop");
lf[184]=C_h_intern(&lf[184],11,"signal/tstp");
lf[185]=C_h_intern(&lf[185],11,"signal/pipe");
lf[186]=C_h_intern(&lf[186],11,"signal/xcpu");
lf[187]=C_h_intern(&lf[187],11,"signal/xfsz");
lf[188]=C_h_intern(&lf[188],11,"signal/usr1");
lf[189]=C_h_intern(&lf[189],11,"signal/usr2");
lf[190]=C_h_intern(&lf[190],12,"signal/winch");
lf[191]=C_h_intern(&lf[191],12,"signals-list");
lf[192]=C_h_intern(&lf[192],18,"\003sysinterrupt-hook");
lf[193]=C_h_intern(&lf[193],14,"signal-handler");
lf[194]=C_h_intern(&lf[194],19,"set-signal-handler!");
lf[195]=C_h_intern(&lf[195],16,"set-signal-mask!");
lf[196]=C_h_intern(&lf[196],14,"\000process-error");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[198]=C_h_intern(&lf[198],11,"signal-mask");
lf[199]=C_h_intern(&lf[199],14,"signal-masked\077");
lf[200]=C_h_intern(&lf[200],12,"signal-mask!");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[202]=C_h_intern(&lf[202],14,"signal-unmask!");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[204]=C_h_intern(&lf[204],18,"system-information");
lf[205]=C_h_intern(&lf[205],25,"\003syspeek-nonnull-c-string");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[207]=C_h_intern(&lf[207],15,"current-user-id");
lf[208]=C_h_intern(&lf[208],25,"current-effective-user-id");
lf[209]=C_h_intern(&lf[209],16,"current-group-id");
lf[210]=C_h_intern(&lf[210],26,"current-effective-group-id");
lf[211]=C_h_intern(&lf[211],16,"user-information");
lf[212]=C_h_intern(&lf[212],6,"vector");
lf[213]=C_h_intern(&lf[213],4,"list");
lf[214]=C_h_intern(&lf[214],27,"current-effective-user-name");
lf[215]=C_h_intern(&lf[215],17,"group-information");
lf[217]=C_h_intern(&lf[217],10,"get-groups");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[221]=C_h_intern(&lf[221],11,"set-groups!");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[224]=C_h_intern(&lf[224],17,"initialize-groups");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[226]=C_h_intern(&lf[226],10,"errno/perm");
lf[227]=C_h_intern(&lf[227],11,"errno/noent");
lf[228]=C_h_intern(&lf[228],10,"errno/srch");
lf[229]=C_h_intern(&lf[229],10,"errno/intr");
lf[230]=C_h_intern(&lf[230],8,"errno/io");
lf[231]=C_h_intern(&lf[231],12,"errno/noexec");
lf[232]=C_h_intern(&lf[232],10,"errno/badf");
lf[233]=C_h_intern(&lf[233],11,"errno/child");
lf[234]=C_h_intern(&lf[234],11,"errno/nomem");
lf[235]=C_h_intern(&lf[235],11,"errno/acces");
lf[236]=C_h_intern(&lf[236],11,"errno/fault");
lf[237]=C_h_intern(&lf[237],10,"errno/busy");
lf[238]=C_h_intern(&lf[238],12,"errno/notdir");
lf[239]=C_h_intern(&lf[239],11,"errno/isdir");
lf[240]=C_h_intern(&lf[240],11,"errno/inval");
lf[241]=C_h_intern(&lf[241],11,"errno/mfile");
lf[242]=C_h_intern(&lf[242],11,"errno/nospc");
lf[243]=C_h_intern(&lf[243],11,"errno/spipe");
lf[244]=C_h_intern(&lf[244],10,"errno/pipe");
lf[245]=C_h_intern(&lf[245],11,"errno/again");
lf[246]=C_h_intern(&lf[246],10,"errno/rofs");
lf[247]=C_h_intern(&lf[247],11,"errno/exist");
lf[248]=C_h_intern(&lf[248],16,"errno/wouldblock");
lf[249]=C_h_intern(&lf[249],10,"errno/2big");
lf[250]=C_h_intern(&lf[250],12,"errno/deadlk");
lf[251]=C_h_intern(&lf[251],9,"errno/dom");
lf[252]=C_h_intern(&lf[252],10,"errno/fbig");
lf[253]=C_h_intern(&lf[253],11,"errno/ilseq");
lf[254]=C_h_intern(&lf[254],11,"errno/mlink");
lf[255]=C_h_intern(&lf[255],17,"errno/nametoolong");
lf[256]=C_h_intern(&lf[256],11,"errno/nfile");
lf[257]=C_h_intern(&lf[257],11,"errno/nodev");
lf[258]=C_h_intern(&lf[258],11,"errno/nolck");
lf[259]=C_h_intern(&lf[259],11,"errno/nosys");
lf[260]=C_h_intern(&lf[260],14,"errno/notempty");
lf[261]=C_h_intern(&lf[261],11,"errno/notty");
lf[262]=C_h_intern(&lf[262],10,"errno/nxio");
lf[263]=C_h_intern(&lf[263],11,"errno/range");
lf[264]=C_h_intern(&lf[264],10,"errno/xdev");
lf[265]=C_h_intern(&lf[265],16,"change-file-mode");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[267]=C_h_intern(&lf[267],17,"change-file-owner");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[269]=C_h_intern(&lf[269],17,"file-read-access\077");
lf[270]=C_h_intern(&lf[270],18,"file-write-access\077");
lf[271]=C_h_intern(&lf[271],20,"file-execute-access\077");
lf[272]=C_h_intern(&lf[272],14,"create-session");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[274]=C_h_intern(&lf[274],16,"process-group-id");
lf[275]=C_h_intern(&lf[275],20,"create-symbolic-link");
lf[276]=C_h_intern(&lf[276],18,"create-symbol-link");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[278]=C_h_intern(&lf[278],9,"substring");
lf[279]=C_h_intern(&lf[279],18,"read-symbolic-link");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[281]=C_h_intern(&lf[281],9,"file-link");
lf[282]=C_h_intern(&lf[282],9,"hard-link");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[284]=C_h_intern(&lf[284],12,"fileno/stdin");
lf[285]=C_h_intern(&lf[285],13,"fileno/stdout");
lf[286]=C_h_intern(&lf[286],13,"fileno/stderr");
lf[287]=C_h_intern(&lf[287],7,"\000append");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[295]=C_h_intern(&lf[295],16,"open-input-file*");
lf[296]=C_h_intern(&lf[296],17,"open-output-file*");
lf[297]=C_h_intern(&lf[297],12,"port->fileno");
lf[298]=C_h_intern(&lf[298],6,"socket");
lf[299]=C_h_intern(&lf[299],20,"\003systcp-port->fileno");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[302]=C_h_intern(&lf[302],25,"\003syspeek-unsigned-integer");
lf[303]=C_h_intern(&lf[303],16,"duplicate-fileno");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[305]=C_h_intern(&lf[305],15,"make-input-port");
lf[306]=C_h_intern(&lf[306],14,"set-port-name!");
lf[307]=C_h_intern(&lf[307],21,"\003syscustom-input-port");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[309]=C_h_intern(&lf[309],17,"\003systhread-yield!");
lf[310]=C_h_intern(&lf[310],25,"\003systhread-block-for-i/o!");
lf[311]=C_h_intern(&lf[311],18,"\003syscurrent-thread");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[316]=C_h_intern(&lf[316],17,"\003sysstring-append");
lf[317]=C_h_intern(&lf[317],15,"\003sysmake-string");
lf[318]=C_h_intern(&lf[318],20,"\003sysscan-buffer-line");
lf[319]=C_h_intern(&lf[319],4,"noop");
lf[320]=C_h_intern(&lf[320],16,"make-output-port");
lf[321]=C_h_intern(&lf[321],22,"\003syscustom-output-port");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[324]=C_h_intern(&lf[324],13,"file-truncate");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[327]=C_h_intern(&lf[327],4,"lock");
lf[328]=C_h_intern(&lf[328],9,"file-lock");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[330]=C_h_intern(&lf[330],18,"file-lock/blocking");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[332]=C_h_intern(&lf[332],14,"file-test-lock");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[334]=C_h_intern(&lf[334],11,"file-unlock");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[336]=C_h_intern(&lf[336],11,"create-fifo");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[338]=C_h_intern(&lf[338],5,"fifo\077");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[340]=C_h_intern(&lf[340],6,"setenv");
lf[341]=C_h_intern(&lf[341],8,"unsetenv");
lf[342]=C_h_intern(&lf[342],25,"get-environment-variables");
lf[343]=C_h_intern(&lf[343],19,"current-environment");
lf[344]=C_h_intern(&lf[344],9,"prot/read");
lf[345]=C_h_intern(&lf[345],10,"prot/write");
lf[346]=C_h_intern(&lf[346],9,"prot/exec");
lf[347]=C_h_intern(&lf[347],9,"prot/none");
lf[348]=C_h_intern(&lf[348],9,"map/fixed");
lf[349]=C_h_intern(&lf[349],10,"map/shared");
lf[350]=C_h_intern(&lf[350],11,"map/private");
lf[351]=C_h_intern(&lf[351],13,"map/anonymous");
lf[352]=C_h_intern(&lf[352],8,"map/file");
lf[353]=C_h_intern(&lf[353],18,"map-file-to-memory");
lf[354]=C_h_intern(&lf[354],4,"mmap");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[356]=C_h_intern(&lf[356],20,"\003syspointer->address");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[358]=C_h_intern(&lf[358],16,"\003sysnull-pointer");
lf[359]=C_h_intern(&lf[359],22,"unmap-file-from-memory");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[361]=C_h_intern(&lf[361],26,"memory-mapped-file-pointer");
lf[362]=C_h_intern(&lf[362],19,"memory-mapped-file\077");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[365]=C_h_intern(&lf[365],19,"seconds->local-time");
lf[366]=C_h_intern(&lf[366],18,"\003sysdecode-seconds");
lf[367]=C_h_intern(&lf[367],17,"seconds->utc-time");
lf[368]=C_h_intern(&lf[368],15,"seconds->string");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[370]=C_h_intern(&lf[370],12,"time->string");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[373]=C_h_intern(&lf[373],12,"string->time");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[375]=C_h_intern(&lf[375],19,"local-time->seconds");
lf[376]=C_h_intern(&lf[376],15,"\003syscons-flonum");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[378]=C_h_intern(&lf[378],17,"utc-time->seconds");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[380]=C_h_intern(&lf[380],27,"local-timezone-abbreviation");
lf[381]=C_h_intern(&lf[381],5,"_exit");
lf[382]=C_h_intern(&lf[382],10,"set-alarm!");
lf[383]=C_h_intern(&lf[383],19,"set-buffering-mode!");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[385]=C_h_intern(&lf[385],5,"\000full");
lf[386]=C_h_intern(&lf[386],5,"\000line");
lf[387]=C_h_intern(&lf[387],5,"\000none");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[389]=C_h_intern(&lf[389],14,"terminal-port\077");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[392]=C_h_intern(&lf[392],13,"terminal-name");
lf[393]=C_h_intern(&lf[393],13,"terminal-size");
lf[394]=C_h_intern(&lf[394],6,"\000error");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[396]=C_h_intern(&lf[396],17,"\003sysmake-locative");
lf[397]=C_h_intern(&lf[397],8,"location");
lf[398]=C_h_intern(&lf[398],13,"get-host-name");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[400]=C_h_intern(&lf[400],6,"regexp");
lf[401]=C_h_intern(&lf[401],21,"make-anchored-pattern");
lf[402]=C_h_intern(&lf[402],12,"string-match");
lf[403]=C_h_intern(&lf[403],12,"glob->regexp");
lf[404]=C_h_intern(&lf[404],13,"make-pathname");
lf[405]=C_h_intern(&lf[405],18,"decompose-pathname");
lf[406]=C_h_intern(&lf[406],4,"glob");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[409]=C_h_intern(&lf[409],12,"process-fork");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[411]=C_h_intern(&lf[411],24,"pathname-strip-directory");
lf[412]=C_h_intern(&lf[412],15,"process-execute");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[414]=C_h_intern(&lf[414],16,"\003sysprocess-wait");
lf[415]=C_h_intern(&lf[415],12,"process-wait");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[417]=C_h_intern(&lf[417],18,"current-process-id");
lf[418]=C_h_intern(&lf[418],17,"parent-process-id");
lf[419]=C_h_intern(&lf[419],5,"sleep");
lf[420]=C_h_intern(&lf[420],14,"process-signal");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[422]=C_h_intern(&lf[422],17,"\003sysshell-command");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[425]=C_h_intern(&lf[425],27,"\003sysshell-command-arguments");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[427]=C_h_intern(&lf[427],11,"process-run");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[429]=C_h_intern(&lf[429],11,"\003sysprocess");
lf[430]=C_h_intern(&lf[430],7,"process");
lf[431]=C_h_intern(&lf[431],8,"process*");
lf[432]=C_h_intern(&lf[432],10,"find-files");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[436]=C_h_intern(&lf[436],16,"\003sysdynamic-wind");
lf[437]=C_h_intern(&lf[437],13,"pathname-file");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[439]=C_h_intern(&lf[439],7,"regexp\077");
lf[440]=C_h_intern(&lf[440],19,"set-root-directory!");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[443]=C_h_intern(&lf[443],21,"set-process-group-id!");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[445]=C_h_intern(&lf[445],18,"getter-with-setter");
lf[446]=C_h_intern(&lf[446],26,"effective-group-id!-setter");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[448]=C_h_intern(&lf[448],12,"set-user-id!");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[450]=C_h_intern(&lf[450],25,"effective-user-id!-setter");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[453]=C_h_intern(&lf[453],23,"\003sysuser-interrupt-hook");
lf[454]=C_h_intern(&lf[454],11,"make-vector");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[457]=C_h_intern(&lf[457],5,"port\077");
lf[458]=C_h_intern(&lf[458],18,"set-file-position!");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[461]=C_h_intern(&lf[461],13,"\000bounds-error");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[463]=C_h_intern(&lf[463],17,"register-feature!");
lf[464]=C_h_intern(&lf[464],5,"posix");
C_register_lf2(lf,465,create_ptable());
t2=C_mutate(&lf[0] /* (set! c150 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3430,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3428 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3431 in k3428 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3434 in k3431 in k3428 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 500  register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[463]+1)))(3,*((C_word*)lf[463]+1),t2,lf[464]);}

/* k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word ab[113],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3457,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* (set! file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3475,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! file-select-one ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3482,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1 /* (set! fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1 /* (set! fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1 /* (set! fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1 /* (set! fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1 /* (set! fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1 /* (set! open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1 /* (set! open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1 /* (set! open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1 /* (set! open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1 /* (set! perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1 /* (set! perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1 /* (set! perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1 /* (set! file-control ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3539,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[51]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3585,a[2]=t45,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[55]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3623,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[57]+1);
t49=C_mutate((C_word*)lf[58]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3638,a[2]=t48,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[62]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3680,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[65]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3719,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3751,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3767,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t55=C_mutate((C_word*)lf[68]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3777,a[2]=t53,a[3]=t54,a[4]=t52,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t56=C_mutate((C_word*)lf[71]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[72]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[73]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[74] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3969,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[77]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4006,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[78]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[79]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4044,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[80]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4050,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[81]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4056,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[82]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4062,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[83]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4068,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[84]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4074,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[85]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4083,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[86]+1 /* (set! stat-regular? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4092,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[87]+1 /* (set! stat-directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4101,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[88]+1 /* (set! stat-char-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4110,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[89]+1 /* (set! stat-block-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4119,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[90]+1 /* (set! stat-fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4128,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[91]+1 /* (set! stat-symlink? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4137,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[92]+1 /* (set! stat-socket? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4146,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t76=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t77=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9293,a[2]=((C_word)li265),tmp=(C_word)a,a+=3,tmp);
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9330,a[2]=((C_word)li266),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 827  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t76,t77,t78);}

/* a9329 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_9330r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_9330r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9330r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[458]);
t8=(C_word)C_i_check_exact_2(t6,lf[458]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9343,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 842  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[461],lf[458],lf[462],t3,t2);}
else{
t10=t9;
f_9343(2,t10,C_SCHEME_UNDEFINED);}}

/* k9341 in a9329 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9349,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 843  port? */
t4=*((C_word*)lf[457]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k9353 in k9341 in a9329 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[149]);
t4=((C_word*)t0)[4];
f_9349(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_9349(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 847  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[60],lf[458],lf[460],((C_word*)t0)[5]);}}}

/* k9347 in k9341 in a9329 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 848  posix-error */
t2=lf[3];
f_3457(7,t2,((C_word*)t0)[4],lf[48],lf[458],lf[459],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a9292 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9293,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9297,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9309,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 829  port? */
t5=*((C_word*)lf[457]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k9307 in a9292 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[149]);
t4=((C_word*)t0)[2];
f_9297(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_9297(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 834  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[93],lf[456],((C_word*)t0)[3]);}}}

/* k9295 in a9292 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9300,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 836  posix-error */
t3=lf[3];
f_3457(6,t3,t2,lf[48],lf[93],lf[455],((C_word*)t0)[2]);}
else{
t3=t2;
f_9300(2,t3,C_SCHEME_UNDEFINED);}}

/* k9298 in k9295 in a9292 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[171],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4157,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1 /* (set! file-position ...) */,t1);
t3=C_mutate((C_word*)lf[94]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4159,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[104]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4294,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[106]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4318,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[108]+1);
t7=*((C_word*)lf[57]+1);
t8=*((C_word*)lf[109]+1);
t9=C_mutate((C_word*)lf[110]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4342,a[2]=t7,a[3]=t6,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[114]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4499,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[113]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4522,a[2]=t11,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[117]+1);
t14=*((C_word*)lf[118]+1);
t15=*((C_word*)lf[119]+1);
t16=*((C_word*)lf[120]+1);
t17=*((C_word*)lf[108]+1);
t18=*((C_word*)lf[2]+1);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4570,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4575,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
t21=*((C_word*)lf[123]+1);
t22=*((C_word*)lf[124]+1);
t23=*((C_word*)lf[113]+1);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4586,a[2]=t23,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t25=C_mutate((C_word*)lf[103]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4642,a[2]=t16,a[3]=t14,a[4]=t21,a[5]=t22,a[6]=t24,a[7]=t15,a[8]=t13,a[9]=t17,a[10]=t19,a[11]=t18,a[12]=t20,a[13]=((C_word)li61),tmp=(C_word)a,a+=14,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4959,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4971,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4977,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
t29=C_mutate((C_word*)lf[150]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4992,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li65),tmp=(C_word)a,a+=6,tmp));
t30=C_mutate((C_word*)lf[152]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5028,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[153]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5064,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[157]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[153]+1));
t33=*((C_word*)lf[150]+1);
t34=*((C_word*)lf[152]+1);
t35=*((C_word*)lf[153]+1);
t36=*((C_word*)lf[157]+1);
t37=C_mutate((C_word*)lf[158]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5080,a[2]=t33,a[3]=t35,a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp));
t38=C_mutate((C_word*)lf[159]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5104,a[2]=t34,a[3]=t36,a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[160]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5128,a[2]=t33,a[3]=t35,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[162]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5148,a[2]=t34,a[3]=t36,a[4]=((C_word)li77),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[164]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5168,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[166]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t43=C_mutate((C_word*)lf[167]+1 /* (set! signal/kill ...) */,C_fix((C_word)SIGKILL));
t44=C_mutate((C_word*)lf[168]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[169]+1 /* (set! signal/hup ...) */,C_fix((C_word)SIGHUP));
t46=C_mutate((C_word*)lf[170]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t47=C_mutate((C_word*)lf[171]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t48=C_mutate((C_word*)lf[172]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t49=C_mutate((C_word*)lf[173]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t50=C_mutate((C_word*)lf[174]+1 /* (set! signal/trap ...) */,C_fix((C_word)SIGTRAP));
t51=C_mutate((C_word*)lf[175]+1 /* (set! signal/quit ...) */,C_fix((C_word)SIGQUIT));
t52=C_mutate((C_word*)lf[176]+1 /* (set! signal/alrm ...) */,C_fix((C_word)SIGALRM));
t53=C_mutate((C_word*)lf[177]+1 /* (set! signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t54=C_mutate((C_word*)lf[178]+1 /* (set! signal/prof ...) */,C_fix((C_word)SIGPROF));
t55=C_mutate((C_word*)lf[179]+1 /* (set! signal/io ...) */,C_fix((C_word)SIGIO));
t56=C_mutate((C_word*)lf[180]+1 /* (set! signal/urg ...) */,C_fix((C_word)SIGURG));
t57=C_mutate((C_word*)lf[181]+1 /* (set! signal/chld ...) */,C_fix((C_word)SIGCHLD));
t58=C_mutate((C_word*)lf[182]+1 /* (set! signal/cont ...) */,C_fix((C_word)SIGCONT));
t59=C_mutate((C_word*)lf[183]+1 /* (set! signal/stop ...) */,C_fix((C_word)SIGSTOP));
t60=C_mutate((C_word*)lf[184]+1 /* (set! signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t61=C_mutate((C_word*)lf[185]+1 /* (set! signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t62=C_mutate((C_word*)lf[186]+1 /* (set! signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t63=C_mutate((C_word*)lf[187]+1 /* (set! signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t64=C_mutate((C_word*)lf[188]+1 /* (set! signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t65=C_mutate((C_word*)lf[189]+1 /* (set! signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t66=C_mutate((C_word*)lf[190]+1 /* (set! signal/winch ...) */,C_fix((C_word)SIGWINCH));
t67=(C_word)C_a_i_list(&a,25,*((C_word*)lf[166]+1),*((C_word*)lf[167]+1),*((C_word*)lf[168]+1),*((C_word*)lf[169]+1),*((C_word*)lf[170]+1),*((C_word*)lf[171]+1),*((C_word*)lf[172]+1),*((C_word*)lf[173]+1),*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1),*((C_word*)lf[189]+1),*((C_word*)lf[190]+1));
t68=C_mutate((C_word*)lf[191]+1 /* (set! signals-list ...) */,t67);
t69=*((C_word*)lf[192]+1);
t70=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5213,a[2]=((C_word*)t0)[2],a[3]=t69,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1170 make-vector */
t71=*((C_word*)lf[454]+1);
((C_proc4)(void*)(*((C_word*)t71+1)))(4,t71,t70,C_fix(256),C_SCHEME_FALSE);}

/* k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5213,2,t0,t1);}
t2=C_mutate((C_word*)lf[193]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5215,a[2]=t1,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[194]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5224,a[2]=t1,a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[192]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5237,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[195]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5255,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[198]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5279,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[199]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5311,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[200]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5317,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[202]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5332,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9287,a[2]=((C_word)li264),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1226 set-signal-handler! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[194]+1)))(4,*((C_word*)lf[194]+1),t10,*((C_word*)lf[168]+1),t11);}

/* a9286 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9287,3,t0,t1,t2);}
/* posixunix.scm: 1228 ##sys#user-interrupt-hook */
((C_proc2)C_retrieve_proc(*((C_word*)lf[453]+1)))(2,*((C_word*)lf[453]+1),t1);}

/* k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5348,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5350,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9269,a[2]=((C_word)li262),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9272,a[2]=((C_word)li263),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1252 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t3,t4,t5);}

/* a9271 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9272,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9282,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1256 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9280 in a9271 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1257 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[448],lf[452],((C_word*)t0)[2]);}

/* a9268 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9269,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1105(C_SCHEME_UNDEFINED));}

/* k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5390,2,t0,t1);}
t2=C_mutate((C_word*)lf[207]+1 /* (set! current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9251,a[2]=((C_word)li260),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9254,a[2]=((C_word)li261),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1260 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t3,t4,t5);}

/* a9253 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9254,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9264,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1264 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9262 in a9253 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1265 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[450],lf[451],((C_word*)t0)[2]);}

/* a9250 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9251,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1114(C_SCHEME_UNDEFINED));}

/* k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5394,2,t0,t1);}
t2=C_mutate((C_word*)lf[208]+1 /* (set! current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9233,a[2]=((C_word)li258),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9236,a[2]=((C_word)li259),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1269 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t3,t4,t5);}

/* a9235 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9236,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9246,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1273 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9244 in a9235 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1274 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[448],lf[449],((C_word*)t0)[2]);}

/* a9232 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9233,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1123(C_SCHEME_UNDEFINED));}

/* k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5398,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1 /* (set! current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9215,a[2]=((C_word)li256),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9218,a[2]=((C_word)li257),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1277 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t3,t4,t5);}

/* a9217 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9218,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9228,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1281 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9226 in a9217 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1282 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[446],lf[447],((C_word*)t0)[2]);}

/* a9214 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9215,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1132(C_SCHEME_UNDEFINED));}

/* k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5402,2,t0,t1);}
t2=C_mutate((C_word*)lf[210]+1 /* (set! current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[211]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5404,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[124]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5471,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[214]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5485,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[215]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5510,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[216] /* (set! _ensure-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5596,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[217]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5603,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[221]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5666,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[224]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5740,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[226]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[227]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[228]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[229]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[230]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[231]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[232]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[233]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[234]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[235]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[236]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[237]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[238]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[239]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[240]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[241]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[242]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[243]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[244]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[245]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[246]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[247]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[248]+1 /* (set! errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[249] /* errno/2big */,0,C_fix(0));
t35=C_set_block_item(lf[250] /* errno/deadlk */,0,C_fix(0));
t36=C_set_block_item(lf[251] /* errno/dom */,0,C_fix(0));
t37=C_set_block_item(lf[252] /* errno/fbig */,0,C_fix(0));
t38=C_set_block_item(lf[253] /* errno/ilseq */,0,C_fix(0));
t39=C_set_block_item(lf[254] /* errno/mlink */,0,C_fix(0));
t40=C_set_block_item(lf[255] /* errno/nametoolong */,0,C_fix(0));
t41=C_set_block_item(lf[256] /* errno/nfile */,0,C_fix(0));
t42=C_set_block_item(lf[257] /* errno/nodev */,0,C_fix(0));
t43=C_set_block_item(lf[258] /* errno/nolck */,0,C_fix(0));
t44=C_set_block_item(lf[259] /* errno/nosys */,0,C_fix(0));
t45=C_set_block_item(lf[260] /* errno/notempty */,0,C_fix(0));
t46=C_set_block_item(lf[261] /* errno/notty */,0,C_fix(0));
t47=C_set_block_item(lf[262] /* errno/nxio */,0,C_fix(0));
t48=C_set_block_item(lf[263] /* errno/range */,0,C_fix(0));
t49=C_set_block_item(lf[264] /* errno/xdev */,0,C_fix(0));
t50=C_mutate((C_word*)lf[265]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5804,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[267]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5831,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5861,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[269]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5885,a[2]=t52,a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[270]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5891,a[2]=t52,a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[271]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5897,a[2]=t52,a[3]=((C_word)li106),tmp=(C_word)a,a+=4,tmp));
t56=C_mutate((C_word*)lf[272]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5903,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9176,a[2]=((C_word)li254),tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9194,a[2]=((C_word)li255),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1497 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t57,t58,t59);}

/* a9193 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9194,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[443]);
t5=(C_word)C_i_check_exact_2(t3,lf[443]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9210,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1509 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k9208 in a9193 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1510 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[443],lf[444],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9175 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9176,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[274]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9183,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9189,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1502 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_9183(2,t6,C_SCHEME_UNDEFINED);}}

/* k9187 in a9175 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1503 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[274],lf[442],((C_word*)t0)[2]);}

/* k9181 in a9175 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5920,2,t0,t1);}
t2=C_mutate((C_word*)lf[274]+1 /* (set! process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[275]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5922,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[278]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5959,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1530 make-string */
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word ab[262],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5959,2,t0,t1);}
t2=C_mutate((C_word*)lf[279]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5960,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[281]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6010,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[284]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[285]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[286]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6035,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6072,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp);
t9=C_mutate((C_word*)lf[295]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6087,a[2]=t7,a[3]=t8,a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[296]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6101,a[2]=t7,a[3]=t8,a[4]=((C_word)li114),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[297]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6115,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[303]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6160,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[305]+1);
t14=*((C_word*)lf[306]+1);
t15=C_mutate((C_word*)lf[307]+1 /* (set! custom-input-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6187,a[2]=t13,a[3]=t14,a[4]=((C_word)li136),tmp=(C_word)a,a+=5,tmp));
t16=*((C_word*)lf[320]+1);
t17=*((C_word*)lf[306]+1);
t18=C_mutate((C_word*)lf[321]+1 /* (set! custom-output-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6669,a[2]=t16,a[3]=t17,a[4]=((C_word)li148),tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[324]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6928,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6967,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7041,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[328]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7059,a[2]=t20,a[3]=t21,a[4]=((C_word)li152),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[330]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7074,a[2]=t20,a[3]=t21,a[4]=((C_word)li153),tmp=(C_word)a,a+=5,tmp));
t24=C_mutate((C_word*)lf[332]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7089,a[2]=t20,a[3]=t21,a[4]=((C_word)li154),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[334]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7111,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[336]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7139,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[338]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7182,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[340]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7208,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[341]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7225,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[342]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7245,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[343]+1 /* (set! current-environment ...) */,*((C_word*)lf[342]+1));
t32=C_mutate((C_word*)lf[344]+1 /* (set! prot/read ...) */,C_fix((C_word)PROT_READ));
t33=C_mutate((C_word*)lf[345]+1 /* (set! prot/write ...) */,C_fix((C_word)PROT_WRITE));
t34=C_mutate((C_word*)lf[346]+1 /* (set! prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t35=C_mutate((C_word*)lf[347]+1 /* (set! prot/none ...) */,C_fix((C_word)PROT_NONE));
t36=C_mutate((C_word*)lf[348]+1 /* (set! map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t37=C_mutate((C_word*)lf[349]+1 /* (set! map/shared ...) */,C_fix((C_word)MAP_SHARED));
t38=C_mutate((C_word*)lf[350]+1 /* (set! map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t39=C_mutate((C_word*)lf[351]+1 /* (set! map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t40=C_mutate((C_word*)lf[352]+1 /* (set! map/file ...) */,C_fix((C_word)MAP_FILE));
t41=C_mutate((C_word*)lf[353]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7349,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[359]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7411,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[361]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7446,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[362]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7455,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate(&lf[363] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7461,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[365]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7480,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[367]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7489,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[368]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7508,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[370]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7544,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[373]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7613,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[375]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7659,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[378]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7674,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[380]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7689,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[381]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7701,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[382]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7717,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[383]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7724,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[389]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7783,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate(&lf[390] /* (set! terminal-check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7802,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[392]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7834,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[393]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7857,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[398]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7892,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp));
t62=*((C_word*)lf[400]+1);
t63=*((C_word*)lf[401]+1);
t64=*((C_word*)lf[402]+1);
t65=*((C_word*)lf[403]+1);
t66=*((C_word*)lf[110]+1);
t67=*((C_word*)lf[404]+1);
t68=*((C_word*)lf[405]+1);
t69=C_mutate((C_word*)lf[406]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7904,a[2]=t65,a[3]=t63,a[4]=t62,a[5]=t66,a[6]=t64,a[7]=t67,a[8]=t68,a[9]=((C_word)li188),tmp=(C_word)a,a+=10,tmp));
t70=C_mutate((C_word*)lf[409]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8016,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp));
t71=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8058,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
t72=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8077,a[2]=((C_word)li192),tmp=(C_word)a,a+=3,tmp);
t73=*((C_word*)lf[411]+1);
t74=C_mutate((C_word*)lf[412]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8096,a[2]=t73,a[3]=t72,a[4]=t71,a[5]=((C_word)li198),tmp=(C_word)a,a+=6,tmp));
t75=C_mutate((C_word*)lf[414]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8278,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[415]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8295,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[417]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8373,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[418]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8376,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[419]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8379,a[2]=((C_word)li205),tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[420]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8386,a[2]=((C_word)li206),tmp=(C_word)a,a+=3,tmp));
t81=C_mutate((C_word*)lf[422]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8413,a[2]=((C_word)li207),tmp=(C_word)a,a+=3,tmp));
t82=C_mutate((C_word*)lf[425]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8422,a[2]=((C_word)li208),tmp=(C_word)a,a+=3,tmp));
t83=*((C_word*)lf[409]+1);
t84=*((C_word*)lf[412]+1);
t85=*((C_word*)lf[123]+1);
t86=C_mutate((C_word*)lf[427]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8428,a[2]=t83,a[3]=t84,a[4]=((C_word)li209),tmp=(C_word)a,a+=5,tmp));
t87=*((C_word*)lf[164]+1);
t88=*((C_word*)lf[415]+1);
t89=*((C_word*)lf[409]+1);
t90=*((C_word*)lf[412]+1);
t91=*((C_word*)lf[303]+1);
t92=*((C_word*)lf[55]+1);
t93=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8484,a[2]=t88,a[3]=((C_word)li213),tmp=(C_word)a,a+=4,tmp);
t94=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8521,a[2]=t87,a[3]=((C_word)li216),tmp=(C_word)a,a+=4,tmp);
t95=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8541,a[2]=t92,a[3]=((C_word)li217),tmp=(C_word)a,a+=4,tmp);
t96=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8555,a[2]=t92,a[3]=((C_word)li218),tmp=(C_word)a,a+=4,tmp);
t97=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8572,a[2]=((C_word)li219),tmp=(C_word)a,a+=3,tmp);
t98=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8588,a[2]=t94,a[3]=t89,a[4]=t96,a[5]=t90,a[6]=t97,a[7]=((C_word)li221),tmp=(C_word)a,a+=8,tmp);
t99=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8633,a[2]=t95,a[3]=((C_word)li222),tmp=(C_word)a,a+=4,tmp);
t100=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8644,a[2]=t95,a[3]=((C_word)li223),tmp=(C_word)a,a+=4,tmp);
t101=C_mutate((C_word*)lf[429]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8655,a[2]=t100,a[3]=t93,a[4]=t99,a[5]=t98,a[6]=((C_word)li226),tmp=(C_word)a,a+=7,tmp));
t102=C_set_block_item(lf[430] /* process */,0,C_SCHEME_UNDEFINED);
t103=C_set_block_item(lf[431] /* process* */,0,C_SCHEME_UNDEFINED);
t104=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8713,a[2]=((C_word)li231),tmp=(C_word)a,a+=3,tmp);
t105=C_mutate((C_word*)lf[430]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8774,a[2]=t104,a[3]=((C_word)li235),tmp=(C_word)a,a+=4,tmp));
t106=C_mutate((C_word*)lf[431]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8834,a[2]=t104,a[3]=((C_word)li239),tmp=(C_word)a,a+=4,tmp));
t107=*((C_word*)lf[406]+1);
t108=*((C_word*)lf[402]+1);
t109=*((C_word*)lf[404]+1);
t110=*((C_word*)lf[114]+1);
t111=C_mutate((C_word*)lf[432]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8894,a[2]=t110,a[3]=t109,a[4]=t107,a[5]=t108,a[6]=((C_word)li252),tmp=(C_word)a,a+=7,tmp));
t112=C_mutate((C_word*)lf[440]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9153,a[2]=((C_word)li253),tmp=(C_word)a,a+=3,tmp));
t113=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t113+1)))(2,t113,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9153(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9153,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[440]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9145,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_foreign_string_argumentp(t4);
/* ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t6=t5;
f_9145(2,t6,C_SCHEME_FALSE);}}

/* k9143 in set-root-directory! in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub3166(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2394 posix-error */
t3=lf[3];
f_3457(6,t3,((C_word*)t0)[3],lf[48],lf[440],lf[441],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_8894r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8894r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8894r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li247),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9061,a[2]=t5,a[3]=((C_word)li248),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9066,a[2]=t6,a[3]=((C_word)li249),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9071,a[2]=t7,a[3]=((C_word)li251),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action30563147 */
t9=t8;
f_9071(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id30573143 */
t11=t7;
f_9066(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit30583138 */
t13=t6;
f_9061(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body30543064 */
t15=t5;
f_8896(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action3056 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_9071(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9071,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9077,a[2]=((C_word)li250),tmp=(C_word)a,a+=3,tmp);
/* def-id30573143 */
t3=((C_word*)t0)[2];
f_9066(t3,t1,t2);}

/* a9076 in def-action3056 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9077,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id3057 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_9066(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9066,NULL,3,t0,t1,t2);}
/* def-limit30583138 */
t3=((C_word*)t0)[2];
f_9061(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit3058 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_9061(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9061,NULL,4,t0,t1,t2,t3);}
/* body30543064 */
t4=((C_word*)t0)[2];
f_8896(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8896(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8896,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[432]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8903,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_8903(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9056,a[2]=t4,a[3]=t7,a[4]=((C_word)li245),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_8903(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9048,a[2]=((C_word)li246),tmp=(C_word)a,a+=3,tmp));}}

/* f_9048 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9048(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9048,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_9056 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9056(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9056,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8903,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_9036(2,t4,t2);}
else{
/* posixunix.scm: 2366 regexp? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[439]+1)))(3,*((C_word*)lf[439]+1),t3,((C_word*)t0)[11]);}}

/* k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9036,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9037,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word)li240),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9030,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2369 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[438]);}

/* k9028 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2369 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8913,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8915,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li244),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_8915(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8915(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8915,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2375 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8934,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2376 pathname-file */
t3=*((C_word*)lf[437]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9016,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2383 pproc */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k9014 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9016,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9023,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2383 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2384 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_8915(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k9021 in k9014 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2383 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8915(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9010,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[433]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[434]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2376 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_8915(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8949,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2377 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8947 in k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8949,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8959,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8961,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,a[5]=((C_word)li241),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word)li242),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8990,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,a[5]=((C_word)li243),tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[436]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9000,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9003,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2382 pproc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k9001 in k8947 in k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2382 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_9000(2,t2,((C_word*)t0)[2]);}}

/* k8998 in k8947 in k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2382 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8915(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8989 in k8947 in k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8990,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8965 in k8947 in k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8974,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8988,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2380 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],lf[435]);}

/* k8986 in a8965 in k8947 in k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2380 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8972 in a8965 in k8947 in k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8978,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2381 pproc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k8979 in k8972 in a8965 in k8947 in k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2381 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8978(2,t2,((C_word*)t0)[2]);}}

/* k8976 in k8972 in a8965 in k8947 in k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2380 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8915(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8960 in k8947 in k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8961,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8957 in k8947 in k9008 in k8932 in loop in k8911 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2378 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8915(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_9037 in k9034 in k8901 in body3054 in find-files in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_9037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9037,3,t0,t1,t2);}
/* posixunix.scm: 2367 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8834(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8834r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8834r(t0,t1,t2,t3);}}

static void C_ccall f_8834r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8836,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li236),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8841,a[2]=t4,a[3]=((C_word)li237),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8846,a[2]=t5,a[3]=((C_word)li238),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args30093025 */
t7=t6;
f_8846(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env30103021 */
t9=t5;
f_8841(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body30073016 */
t11=t4;
f_8836(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args3009 in process* in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8846,NULL,2,t0,t1);}
/* def-env30103021 */
t2=((C_word*)t0)[2];
f_8841(t2,t1,C_SCHEME_FALSE);}

/* def-env3010 in process* in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8841(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8841,NULL,3,t0,t1,t2);}
/* body30073016 */
t3=((C_word*)t0)[2];
f_8836(t3,t1,t2,C_SCHEME_FALSE);}

/* body3007 in process* in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8836(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8836,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2344 %process */
f_8713(t1,lf[431],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8774(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8774r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8774r(t0,t1,t2,t3);}}

static void C_ccall f_8774r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8776,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li232),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8781,a[2]=t4,a[3]=((C_word)li233),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8786,a[2]=t5,a[3]=((C_word)li234),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args29652981 */
t7=t6;
f_8786(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env29662977 */
t9=t5;
f_8781(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body29632972 */
t11=t4;
f_8776(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args2965 in process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8786,NULL,2,t0,t1);}
/* def-env29662977 */
t2=((C_word*)t0)[2];
f_8781(t2,t1,C_SCHEME_FALSE);}

/* def-env2966 in process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8781(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8781,NULL,3,t0,t1,t2);}
/* body29632972 */
t3=((C_word*)t0)[2];
f_8776(t3,t1,t2,C_SCHEME_FALSE);}

/* body2963 in process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8776(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8776,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2341 %process */
f_8713(t1,lf[430],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8713(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8713,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8715,a[2]=t2,a[3]=((C_word)li228),tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8734,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2330 chkstrlst */
t12=t9;
f_8715(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8768,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2332 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[425]+1)))(3,*((C_word*)lf[425]+1),t12,((C_word*)t7)[1]);}}

/* k8766 in %process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8768,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2333 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[422]+1)))(2,*((C_word*)lf[422]+1),t3);}

/* k8770 in k8766 in %process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_8734(2,t3,t2);}

/* k8732 in %process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8737,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2334 chkstrlst */
t3=((C_word*)t0)[2];
f_8715(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_8737(2,t3,C_SCHEME_UNDEFINED);}}

/* k8735 in k8732 in %process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8742,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li229),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8748,a[2]=((C_word*)t0)[3],a[3]=((C_word)li230),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8747 in k8735 in k8732 in %process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8748,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2337 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2338 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8741 in k8735 in k8732 in %process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8742,2,t0,t1);}
/* posixunix.scm: 2335 ##sys#process */
t2=*((C_word*)lf[429]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8715(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8715,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8724,a[2]=((C_word*)t0)[2],a[3]=((C_word)li227),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a8723 in chkstrlst in %process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8724,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8655,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8661,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word)li224),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,a[10]=((C_word)li225),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a8666 in ##sys#process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8667,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8678,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8698,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2311 make-on-close */
t12=((C_word*)t0)[3];
f_8484(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k8696 in a8666 in ##sys#process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2310 input-port */
t2=((C_word*)t0)[7];
f_8633(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8676 in a8666 in ##sys#process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8682,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2313 make-on-close */
t4=((C_word*)t0)[6];
f_8484(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k8692 in k8676 in a8666 in ##sys#process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2312 output-port */
t2=((C_word*)t0)[7];
f_8644(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8680 in k8676 in a8666 in ##sys#process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8686,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8690,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2316 make-on-close */
t4=((C_word*)t0)[3];
f_8484(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k8688 in k8680 in k8676 in a8666 in ##sys#process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2315 input-port */
t2=((C_word*)t0)[7];
f_8633(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8684 in k8680 in k8676 in a8666 in ##sys#process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2309 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8660 in ##sys#process in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8661,2,t0,t1);}
/* posixunix.scm: 2304 spawn */
t2=((C_word*)t0)[8];
f_8588(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8644(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8644,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8648,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2300 connect-parent */
t8=((C_word*)t0)[2];
f_8541(t8,t7,t4,t5);}

/* k8646 in output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2301 ##sys#custom-output-port */
((C_proc8)C_retrieve_proc(*((C_word*)lf[321]+1)))(8,*((C_word*)lf[321]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8633(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8633,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8637,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2296 connect-parent */
t8=((C_word*)t0)[2];
f_8541(t8,t7,t4,t5);}

/* k8635 in input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2297 ##sys#custom-input-port */
((C_proc8)C_retrieve_proc(*((C_word*)lf[307]+1)))(8,*((C_word*)lf[307]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8588(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8588,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2283 needed-pipe */
t9=((C_word*)t0)[2];
f_8521(t9,t8,t6);}

/* k8590 in spawn in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2284 needed-pipe */
t3=((C_word*)t0)[2];
f_8521(t3,t2,((C_word*)t0)[5]);}

/* k8593 in k8590 in spawn in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2285 needed-pipe */
t3=((C_word*)t0)[2];
f_8521(t3,t2,((C_word*)t0)[6]);}

/* k8596 in k8593 in k8590 in spawn in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8598,2,t0,t1);}
t2=f_8572(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8609,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word)li220),tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2288 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8610 in k8596 in k8593 in k8590 in spawn in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8615,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2290 connect-child */
t3=((C_word*)t0)[7];
f_8555(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[284]+1));}

/* k8613 in a8610 in k8596 in k8593 in k8590 in spawn in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8618,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_8572(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2291 connect-child */
t4=((C_word*)t0)[5];
f_8555(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[285]+1));}

/* k8616 in k8613 in a8610 in k8596 in k8593 in k8590 in spawn in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8621,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_8572(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2292 connect-child */
t4=((C_word*)t0)[3];
f_8555(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[286]+1));}

/* k8619 in k8616 in k8613 in a8610 in k8596 in k8593 in k8590 in spawn in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2293 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8607 in k8596 in k8593 in k8590 in spawn in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2286 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall f_8572(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8555(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8555,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8568,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2274 file-close */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k8566 in connect-child in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8568,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8480,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2248 duplicate-fileno */
t6=*((C_word*)lf[303]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k8478 in k8566 in connect-child in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2249 file-close */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8541(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8541,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8554,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2268 file-close */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k8552 in connect-parent in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8521(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8521,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8530,a[2]=((C_word*)t0)[2],a[3]=((C_word)li214),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8536,a[2]=((C_word)li215),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a8535 in needed-pipe in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8536,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a8529 in needed-pipe in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8530,2,t0,t1);}
/* posixunix.scm: 2263 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* make-on-close in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8484(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8484,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8486,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,a[9]=((C_word)li212),tmp=(C_word)a,a+=10,tmp));}

/* f_8486 in make-on-close in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8486,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li210),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li211),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a8506 */
static void C_ccall f_8507(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8507,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2258 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[196],((C_word*)t0)[3],lf[428],((C_word*)t0)[2],t4);}}

/* a8500 */
static void C_ccall f_8501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8501,2,t0,t1);}
/* posixunix.scm: 2256 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8428(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8428r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8428r(t0,t1,t2,t3);}}

static void C_ccall f_8428r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8435,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2212 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k8433 in process-run in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8435,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2214 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2216 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[422]+1)))(2,*((C_word*)lf[422]+1),t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k8452 in k8433 in process-run in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8458,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2216 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[425]+1)))(3,*((C_word*)lf[425]+1),t2,((C_word*)t0)[2]);}

/* k8456 in k8452 in k8433 in process-run in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2216 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8422(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8422,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[426],t2));}

/* ##sys#shell-command in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8417,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2201 getenv */
t3=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[424]);}

/* k8415 in ##sys#shell-command in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[423]));}

/* process-signal in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8386(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8386r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8386r(t0,t1,t2,t3);}}

static void C_ccall f_8386r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[420]);
t7=(C_word)C_i_check_exact_2(t5,lf[420]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2198 posix-error */
t10=lf[3];
f_3457(7,t10,t1,lf[196],lf[420],lf[421],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8379(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8379,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2713(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8376,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2708(C_SCHEME_UNDEFINED));}

/* current-process-id in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8373,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2704(C_SCHEME_UNDEFINED));}

/* process-wait in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8295(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_8295r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8295r(t0,t1,t2);}}

static void C_ccall f_8295r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[415]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8325,a[2]=t8,a[3]=t11,a[4]=((C_word)li200),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8331,a[2]=t11,a[3]=((C_word)li201),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t13,t14);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* a8330 in process-wait in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8331,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2184 posix-error */
t6=lf[3];
f_3457(6,t6,t1,lf[196],lf[415],lf[416],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2185 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8324 in process-wait in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8325,2,t0,t1);}
/* posixunix.scm: 2182 ##sys#process-wait */
((C_proc4)C_retrieve_proc(*((C_word*)lf[414]+1)))(4,*((C_word*)lf[414]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8278,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 2169 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8096(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_8096r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8096r(t0,t1,t2,t3);}}

static void C_ccall f_8096r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li195),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8225,a[2]=t4,a[3]=((C_word)li196),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8230,a[2]=t5,a[3]=((C_word)li197),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist25702638 */
t7=t6;
f_8230(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist25712634 */
t9=t5;
f_8225(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body25682577 */
t11=t4;
f_8098(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist2570 in process-execute in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8230,NULL,2,t0,t1);}
/* def-envlist25712634 */
t2=((C_word*)t0)[2];
f_8225(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist2571 in process-execute in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8225(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8225,NULL,3,t0,t1,t2);}
/* body25682577 */
t3=((C_word*)t0)[2];
f_8098(t3,t1,t2,C_SCHEME_FALSE);}

/* body2568 in process-execute in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8098(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8098,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[412]);
t5=(C_word)C_i_check_list_2(t2,lf[412]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8108,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2137 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k8106 in body2568 in process-execute in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8108,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_8058(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8116,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li194),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_8116(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* doloop2583 in k8106 in body2568 in process-execute in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8116(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8116,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_8058(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8129,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[412]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8162,a[2]=((C_word*)t0)[3],a[3]=((C_word)li193),tmp=(C_word)a,a+=4,tmp);
t8=t5;
f_8129(t8,f_8162(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_8129(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[412]);
t6=(C_word)C_block_size(t4);
t7=f_8058(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* doloop2594 in doloop2583 in k8106 in body2568 in process-execute in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall f_8162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_8077(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[412]);
t5=(C_word)C_block_size(t3);
t6=f_8077(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k8127 in doloop2583 in k8106 in body2568 in process-execute in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_8129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8129,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8154,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2151 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8152 in k8127 in doloop2583 in k8106 in body2568 in process-execute in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2151 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8130 in k8127 in doloop2583 in k8106 in body2568 in process-execute in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub2533(C_SCHEME_UNDEFINED);
t5=(C_word)stub2548(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2158 posix-error */
t6=lf[3];
f_3457(6,t6,((C_word*)t0)[3],lf[196],lf[412],lf[413],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall f_8077(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub2539(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall f_8058(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub2524(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8016(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_8016r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_8016r(t0,t1,t2);}}

static void C_ccall f_8016r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub2492(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2122 posix-error */
t5=lf[3];
f_3457(5,t5,t1,lf[196],lf[409],lf[410]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8038,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_vector_ref(t2,C_fix(0));
t9=t8;
((C_proc2)C_retrieve_proc(t9))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k8036 in process-fork in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8042,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_8042 in k8036 in process-fork in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8042,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2510(C_SCHEME_UNDEFINED,t3));}

/* glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7904(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_7904r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7904r(t0,t1,t2);}}

static void C_ccall f_7904r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li187),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_7910(t6,t1,t2);}

/* conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_7910(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7910,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7925,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li184),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li186),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a7930 in conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7931,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8008,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[408]);
/* posixunix.scm: 2106 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k8006 in a7930 in conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_8008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2106 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7933 in a7930 in conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixunix.scm: 2107 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k7936 in k7933 in a7930 in conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7941,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2108 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k7939 in k7936 in k7933 in a7930 in conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7948,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[407]);
/* posixunix.scm: 2109 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k7946 in k7939 in k7936 in k7933 in a7930 in conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7948,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7950,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li185),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_7950(t5,((C_word*)t0)[2],t1);}

/* loop in k7946 in k7939 in k7936 in k7933 in a7930 in conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_7950(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7950,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixunix.scm: 2110 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_7910(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7967,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixunix.scm: 2111 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k7965 in loop in k7946 in k7939 in k7936 in k7933 in a7930 in conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7967,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7977,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixunix.scm: 2112 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixunix.scm: 2113 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7950(t3,((C_word*)t0)[6],t2);}}

/* k7975 in k7965 in loop in k7946 in k7939 in k7936 in k7933 in a7930 in conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7981,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixunix.scm: 2112 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7950(t4,t2,t3);}

/* k7979 in k7975 in k7965 in loop in k7946 in k7939 in k7936 in k7933 in a7930 in conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7981,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a7924 in conc-loop in glob in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7925,2,t0,t1);}
/* posixunix.scm: 2105 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7896,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub2403(t3),C_fix(0));}

/* k7894 in get-host-name in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7899,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7899(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2086 posix-error */
t3=lf[3];
f_3457(5,t3,t2,lf[394],lf[398],lf[399]);}}

/* k7897 in k7894 in get-host-name in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7857,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7861,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2067 ##sys#terminal-check */
f_7802(t3,lf[393],t2);}

/* k7859 in terminal-size in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7861,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7881,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[396]+1)))(6,*((C_word*)lf[396]+1),t4,t2,C_fix(0),C_SCHEME_FALSE,lf[397]);}

/* k7879 in k7859 in terminal-size in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[396]+1)))(6,*((C_word*)lf[396]+1),t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[397]);}

/* k7883 in k7879 in k7859 in terminal-size in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_pointer_argumentp(t3);
t6=(C_word)C_i_foreign_pointer_argumentp(t1);
t7=(C_word)stub2374(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(C_word)C_eqp(C_fix(0),t7);
if(C_truep(t8)){
/* posixunix.scm: 2074 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2075 posix-error */
t9=lf[3];
f_3457(6,t9,((C_word*)t0)[4],lf[394],lf[393],lf[395],((C_word*)t0)[6]);}}

/* terminal-name in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7834,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7838,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2059 ##sys#terminal-check */
f_7802(t3,lf[392],t2);}

/* k7836 in terminal-name in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7838,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub2359(t4,t5);
/* ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* ##sys#terminal-check in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_7802(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7802,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7806,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2051 ##sys#check-port */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k7804 in ##sys#terminal-check in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[149],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2054 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[391],((C_word*)t0)[4]);}}

/* terminal-port? in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7783,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7787,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2046 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[389]);}

/* k7785 in terminal-port? in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2047 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k7788 in k7785 in terminal-port? in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_7724r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_7724r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7724r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7728,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2031 ##sys#check-port */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[383]);}

/* k7726 in set-buffering-mode! in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7728,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[385]);
if(C_truep(t6)){
t7=t5;
f_7734(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[386]);
if(C_truep(t7)){
t8=t5;
f_7734(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[387]);
if(C_truep(t8)){
t9=t5;
f_7734(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2037 ##sys#error */
t9=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[383],lf[388],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k7732 in k7726 in set-buffering-mode! in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[383]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[149],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 2043 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[383],lf[384],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7717,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2310(C_SCHEME_UNDEFINED,t3));}

/* _exit in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7701(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7701r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7701r(t0,t1,t2);}}

static void C_ccall f_7701r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub2301(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7689,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub2293(t2),C_fix(0));}

/* utc-time->seconds in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7674(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7674,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7678,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1999 check-time-vector */
f_7461(t3,lf[378],t2);}

/* k7676 in utc-time->seconds in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 2001 ##sys#cons-flonum */
t2=*((C_word*)lf[376]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2002 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[378],lf[379],((C_word*)t0)[3]);}}

/* local-time->seconds in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7659,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7663,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1993 check-time-vector */
f_7461(t3,lf[375],t2);}

/* k7661 in local-time->seconds in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 1995 ##sys#cons-flonum */
t2=*((C_word*)lf[376]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1996 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[375],lf[377],((C_word*)t0)[3]);}}

/* string->time in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7613(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7613r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7613r(t0,t1,t2,t3);}}

static void C_ccall f_7613r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7617,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7617(2,t5,lf[374]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7617(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7615 in string->time in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7617,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[373]);
t3=(C_word)C_i_check_string_2(t1,lf[373]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7630,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1990 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* k7628 in k7615 in string->time in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7634,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1990 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7632 in k7628 in k7615 in string->time in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7634,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub2254(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7544(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7544r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7544r(t0,t1,t2,t3);}}

static void C_ccall f_7544r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7548,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7548(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7548(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7546 in time->string in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1974 check-time-vector */
f_7461(t2,lf[370],((C_word*)t0)[2]);}

/* k7549 in k7546 in time->string in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7551,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[370]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7570,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1978 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub2204(t4,t3),C_fix(0));}}

/* k7571 in k7549 in k7546 in time->string in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1982 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1983 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[370],lf[372],((C_word*)t0)[2]);}}

/* k7568 in k7549 in k7546 in time->string in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7570,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub2212(t3,t2,t1),C_fix(0));}

/* k7558 in k7549 in k7546 in time->string in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1979 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[370],lf[371],((C_word*)t0)[2]);}}

/* seconds->string in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7508(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7508,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[368]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7515,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t7=(C_word)C_i_foreign_integer_argumentp(t5);
t8=(C_word)stub2188(t6,t7);
/* ##sys#peek-c-string */
t9=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t4,t8,C_fix(0));}

/* k7513 in seconds->string in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1967 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1968 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[368],lf[369],((C_word*)t0)[2]);}}

/* seconds->utc-time in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7489,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[367]);
/* posixunix.scm: 1959 ##sys#decode-seconds */
t4=*((C_word*)lf[366]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7480,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[365]);
/* posixunix.scm: 1955 ##sys#decode-seconds */
t4=*((C_word*)lf[366]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* check-time-vector in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_7461(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7461,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1951 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[364],t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* memory-mapped-file? in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7455,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[354]));}

/* memory-mapped-file-pointer in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7446,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[354],lf[361]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7411(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7411r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7411r(t0,t1,t2,t3);}}

static void C_ccall f_7411r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_i_check_structure_2(t2,lf[354],lf[359]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub2141(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1937 posix-error */
t12=lf[3];
f_3457(7,t12,t1,lf[48],lf[359],lf[360],t2,t6);}}

/* map-file-to-memory in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_7349r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_7349r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_7349r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7353,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_7353(2,t10,t2);}
else{
/* posixunix.scm: 1922 ##sys#null-pointer */
t10=*((C_word*)lf[358]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k7351 in map-file-to-memory in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7353,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7359,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_7359(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1925 ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[60],lf[353],lf[357],t1);}}

/* k7357 in k7351 in map-file-to-memory in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7359,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub2102(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7365,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7378,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1927 ##sys#pointer->address */
t17=*((C_word*)lf[356]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,t14);}

/* k7376 in k7357 in k7351 in map-file-to-memory in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1928 posix-error */
t3=lf[3];
f_3457(11,t3,((C_word*)t0)[8],lf[48],lf[353],lf[355],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_7365(2,t3,C_SCHEME_UNDEFINED);}}

/* k7363 in k7357 in k7351 in map-file-to-memory in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7365,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[354],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* get-environment-variables in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7245,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7251,a[2]=t3,a[3]=((C_word)li161),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7251(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_7251(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7251,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7255,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub2053(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k7253 in loop in get-environment-variables in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7255,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7263,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li160),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_7263(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k7253 in loop in get-environment-variables in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_7263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7263,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7289,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1886 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1889 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k7287 in scan in k7253 in loop in get-environment-variables in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7293,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1887 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k7291 in k7287 in scan in k7253 in loop in get-environment-variables in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7293,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7281,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1888 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7251(t5,t3,t4);}

/* k7279 in k7291 in k7287 in scan in k7253 in loop in get-environment-variables in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7281,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7225,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[341]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7233,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1875 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7231 in unsetenv in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7208,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[340]);
t5=(C_word)C_i_check_string_2(t3,lf[340]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7219,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1870 ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k7217 in setenv in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7223,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1870 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7221 in k7217 in setenv in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7182,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[338]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7189,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7206,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1858 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k7204 in fifo? in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1858 ##sys#file-info */
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7187 in fifo? in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1861 posix-error */
t2=lf[3];
f_3457(6,t2,((C_word*)t0)[3],lf[48],lf[338],lf[339],((C_word*)t0)[2]);}}

/* create-fifo in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7139(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7139r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7139r(t0,t1,t2,t3);}}

static void C_ccall f_7139r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[336]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7146,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_7146(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_7146(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k7144 in create-fifo in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_7146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7146,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[336]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7167,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1852 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k7165 in k7144 in create-fifo in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1852 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7161 in k7144 in create-fifo in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1853 posix-error */
t3=lf[3];
f_3457(7,t3,((C_word*)t0)[3],lf[48],lf[336],lf[337],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7111,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[327],lf[334]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1842 posix-error */
t9=lf[3];
f_3457(6,t9,t1,lf[48],lf[334],lf[335],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7089r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7089r(t0,t1,t2,t3);}}

static void C_ccall f_7089r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7093,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1833 setup */
f_6967(t4,t2,t3,lf[332]);}

/* k7091 in file-test-lock in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1835 err */
f_7041(((C_word*)t0)[3],lf[333],t1,lf[332]);}}

/* file-lock/blocking in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7074r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7074r(t0,t1,t2,t3);}}

static void C_ccall f_7074r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7078,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1827 setup */
f_6967(t4,t2,t3,lf[330]);}

/* k7076 in file-lock/blocking in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1829 err */
f_7041(((C_word*)t0)[2],lf[331],t1,lf[330]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7059r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7059r(t0,t1,t2,t3);}}

static void C_ccall f_7059r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7063,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1821 setup */
f_6967(t4,t2,t3,lf[328]);}

/* k7061 in file-lock in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_7063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1823 err */
f_7041(((C_word*)t0)[2],lf[329],t1,lf[328]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_7041(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7041,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1818 posix-error */
t8=lf[3];
f_3457(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6967(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6967,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6989,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1810 ##sys#check-port */
t16=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k6987 in setup in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6989,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_6995(t6,t5);}
else{
t5=t3;
f_6995(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k6993 in k6987 in setup in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6995,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[327],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6928,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[324]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6945,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6952,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6956,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1793 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_6945(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1795 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[324],lf[326],t2);}}}

/* k6954 in file-truncate in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1793 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6950 in file-truncate in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6945(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k6943 in file-truncate in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1797 posix-error */
t2=lf[3];
f_3457(7,t2,((C_word*)t0)[4],lf[48],lf[324],lf[325],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_6669r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6669r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6669r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li144),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6855,a[2]=t6,a[3]=((C_word)li145),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6860,a[2]=t7,a[3]=((C_word)li146),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6865,a[2]=t8,a[3]=((C_word)li147),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?18271918 */
t10=t9;
f_6865(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi18281914 */
t12=t8;
f_6860(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close18291909 */
t14=t7;
f_6855(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* body18251835 */
t16=t6;
f_6671(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-nonblocking?1827 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6865(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6865,NULL,2,t0,t1);}
/* def-bufi18281914 */
t2=((C_word*)t0)[2];
f_6860(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1828 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6860(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6860,NULL,3,t0,t1,t2);}
/* def-on-close18291909 */
t3=((C_word*)t0)[2];
f_6855(t3,t1,t2,C_fix(0));}

/* def-on-close1829 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6855(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6855,NULL,4,t0,t1,t2,t3);}
/* body18251835 */
t4=((C_word*)t0)[2];
f_6671(t4,t1,t2,t3,*((C_word*)lf[319]+1));}

/* body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6671(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6671,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6675,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1735 ##sys#file-nonblocking! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_6675(2,t6,C_SCHEME_UNDEFINED);}}

/* k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6675,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6677,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word)li137),tmp=(C_word)a,a+=7,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_6723(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6767,a[2]=t3,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6781,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1754 ##sys#make-string */
t12=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_6781(2,t12,((C_word*)t0)[6]);}}}

/* k6779 in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6781,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_6723(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6782,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li143),tmp=(C_word)a,a+=7,tmp));}

/* f_6782 in k6779 in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6782,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6799,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word)li142),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6799(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1770 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6677(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_6799(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6799,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6809,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1760 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6677(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_difference(t4,t2);
/* posixunix.scm: 1765 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k6807 in loop */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1762 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6799(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_6767 in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6767,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1753 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6677(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6721 in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6723,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6727,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6732,a[2]=((C_word*)t0)[9],a[3]=((C_word)li138),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6738,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li139),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6759,a[2]=((C_word*)t0)[9],a[3]=((C_word)li140),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1773 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t5,t6,t7,t8);}

/* a6758 in k6721 in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6759,2,t0,t1);}
/* posixunix.scm: 1783 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* a6737 in k6721 in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6738,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6748,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1780 posix-error */
t3=lf[3];
f_3457(7,t3,t2,lf[48],((C_word*)t0)[3],lf[323],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6748(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6746 in a6737 in k6721 in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1781 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6731 in k6721 in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6732,3,t0,t1,t2);}
/* posixunix.scm: 1775 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* k6725 in k6721 in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6727,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6730,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1784 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6728 in k6725 in k6721 in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6677(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6677,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6693,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1743 ##sys#thread-yield! */
t8=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1745 posix-error */
t7=lf[3];
f_3457(7,t7,t1,((C_word*)t0)[3],lf[48],lf[322],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6712,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1747 ##sys#substring */
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6710 in poke in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1747 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6677(t3,((C_word*)t0)[2],t1,t2);}

/* k6691 in poke in k6673 in body1825 in ##sys#custom-output-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1744 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6677(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_6187r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6187r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6187r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,a[7]=((C_word)li131),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6576,a[2]=t6,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6581,a[2]=t7,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6586,a[2]=t8,a[3]=((C_word)li134),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6591,a[2]=t9,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?15881786 */
t11=t10;
f_6591(t11,t1);}
else{
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi15891782 */
t13=t9;
f_6586(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close15901777 */
t15=t8;
f_6581(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?15911771 */
t17=t7;
f_6576(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
/* body15861597 */
t19=t6;
f_6189(t19,t1,t11,t13,t15,t17);}
else{
/* ##sys#error */
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[0],t18);}}}}}}

/* def-nonblocking?1588 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6591,NULL,2,t0,t1);}
/* def-bufi15891782 */
t2=((C_word*)t0)[2];
f_6586(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1589 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6586(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6586,NULL,3,t0,t1,t2);}
/* def-on-close15901777 */
t3=((C_word*)t0)[2];
f_6581(t3,t1,t2,C_fix(1));}

/* def-on-close1590 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6581(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6581,NULL,4,t0,t1,t2,t3);}
/* def-more?15911771 */
t4=((C_word*)t0)[2];
f_6576(t4,t1,t2,t3,*((C_word*)lf[319]+1));}

/* def-more?1591 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6576(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6576,NULL,5,t0,t1,t2,t3,t4);}
/* body15861597 */
t5=((C_word*)t0)[2];
f_6189(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6189(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6189,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6193,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1609 ##sys#file-nonblocking! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_6193(2,t7,C_SCHEME_UNDEFINED);}}

/* k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6193,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1611 ##sys#make-string */
t5=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_6199(2,t5,((C_word*)t0)[10]);}}

/* k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6199,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6200,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li117),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6223,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6231,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,a[10]=((C_word)li119),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6313,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6318,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word)li120),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6331,a[2]=t6,a[3]=t3,a[4]=t5,a[5]=((C_word)li121),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6343,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=((C_word)li122),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6364,a[2]=t8,a[3]=t7,a[4]=((C_word)li123),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6373,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li125),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6449,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,a[6]=((C_word)li130),tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1659 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t18))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a6448 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6449,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6455,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li129),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_6455(t7,t1,C_SCHEME_FALSE);}

/* loop in a6448 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6455(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6455,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6457,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li126),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6535,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word)li127),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6541,a[2]=((C_word*)t0)[2],a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6551,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1724 fetch */
t5=((C_word*)t0)[5];
f_6231(t5,t4);}}

/* k6549 in loop in a6448 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1726 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6455(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a6540 in loop in a6448 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6541,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1721 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6455(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a6534 in loop in a6448 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6535,2,t0,t1);}
/* posixunix.scm: 1719 ##sys#scan-buffer-line */
((C_proc6)C_retrieve_proc(*((C_word*)lf[318]+1)))(6,*((C_word*)lf[318]+1),t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a6448 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6457,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6464,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_6464(2,t8,(C_truep(t7)?t7:lf[315]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6507,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1701 ##sys#make-string */
t8=*((C_word*)lf[317]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k6505 in bumper in loop in a6448 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1707 ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[316]+1)))(4,*((C_word*)lf[316]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_6464(2,t6,t1);}}

/* k6462 in bumper in loop in a6448 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6464,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6474,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1711 fetch */
t5=((C_word*)t0)[3];
f_6231(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1716 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k6472 in k6462 in bumper in loop in a6448 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1712 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a6372 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6373,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6381,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_6381(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_6381(t8,(C_word)C_fixnum_difference(t7,t5));}}

/* k6379 in a6372 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6381,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6383,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li124),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6383(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k6379 in a6372 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6383(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6383,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* posixunix.scm: 1687 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6431,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1689 fetch */
t7=((C_word*)t0)[2];
f_6231(t7,t6);}}}

/* k6429 in loop in k6379 in a6372 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1692 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6383(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a6363 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6368,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1677 fetch */
t3=((C_word*)t0)[2];
f_6231(t3,t2);}

/* k6366 in a6363 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1678 peek */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_6223(((C_word*)t0)[2]));}

/* a6342 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6343,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6353,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1674 posix-error */
t3=lf[3];
f_3457(7,t3,t2,lf[48],((C_word*)t0)[3],lf[314],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6353(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6351 in a6342 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1675 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6330 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6331,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1669 ready? */
t3=((C_word*)t0)[2];
f_6200(t3,t1);}}

/* a6317 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6322,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1661 fetch */
t3=((C_word*)t0)[2];
f_6231(t3,t2);}

/* k6320 in a6317 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_6223(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k6311 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6313,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6316,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1728 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6314 in k6311 in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6231(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6231,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6243,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li118),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_6243(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6243,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6259,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1636 ##sys#thread-block-for-i/o! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[310]+1)))(5,*((C_word*)lf[310]+1),t5,*((C_word*)lf[311]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1639 posix-error */
t5=lf[3];
f_3457(7,t5,t1,lf[48],((C_word*)t0)[6],lf[312],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6280,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1643 more? */
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k6278 in loop in fetch in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6280,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6283,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1645 ##sys#thread-yield! */
t3=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6289,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_6289(2,t8,t7);}
else{
/* posixunix.scm: 1651 posix-error */
t7=lf[3];
f_3457(7,t7,t4,lf[48],((C_word*)t0)[3],lf[313],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_6289(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6287 in k6278 in loop in fetch in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6281 in k6278 in loop in fetch in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1646 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6243(t2,((C_word*)t0)[2]);}

/* k6257 in loop in fetch in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1637 ##sys#thread-yield! */
t3=*((C_word*)lf[309]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6260 in k6257 in loop in fetch in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1638 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6243(t2,((C_word*)t0)[2]);}

/* peek in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall f_6223(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6200,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1617 ##sys#file-select-one */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[3]);}

/* k6202 in ready? in k6197 in k6191 in body1586 in ##sys#custom-input-port in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* posixunix.scm: 1621 posix-error */
t4=lf[3];
f_3457(7,t4,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[308],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t1));}}

/* duplicate-fileno in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6160(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6160r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6160r(t0,t1,t2,t3);}}

static void C_ccall f_6160r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[303]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6167,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_6167(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[303]);
t8=t5;
f_6167(t8,(C_word)C_dup2(t2,t6));}}

/* k6165 in duplicate-fileno in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6167,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6170,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1602 posix-error */
t3=lf[3];
f_3457(6,t3,t2,lf[48],lf[303],lf[304],((C_word*)t0)[2]);}
else{
t3=t2;
f_6170(2,t3,C_SCHEME_UNDEFINED);}}

/* k6168 in k6165 in duplicate-fileno in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6115,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6119,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1584 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[297]);}

/* k6117 in port->fileno in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6119,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[298],t2);
if(C_truep(t3)){
/* posixunix.scm: 1585 ##sys#tcp-port->fileno */
((C_proc3)C_retrieve_proc(*((C_word*)lf[299]+1)))(3,*((C_word*)lf[299]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1586 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k6152 in k6117 in port->fileno in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6154,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1591 posix-error */
t2=lf[3];
f_3457(6,t2,((C_word*)t0)[3],lf[60],lf[297],lf[300],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6137,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1589 posix-error */
t4=lf[3];
f_3457(6,t4,t3,lf[48],lf[297],lf[301],((C_word*)t0)[2]);}
else{
t4=t3;
f_6137(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6135 in k6152 in k6117 in port->fileno in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6101(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6101r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6101r(t0,t1,t2,t3);}}

static void C_ccall f_6101r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[296]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6113,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1580 mode */
f_6035(t5,C_SCHEME_FALSE,t3);}

/* k6111 in open-output-file* in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6113,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1580 check */
f_6072(((C_word*)t0)[2],lf[296],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6087(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6087r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6087r(t0,t1,t2,t3);}}

static void C_ccall f_6087r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[295]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6099,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1576 mode */
f_6035(t5,C_SCHEME_TRUE,t3);}

/* k6097 in open-input-file* in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6099,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1576 check */
f_6072(((C_word*)t0)[2],lf[295],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6072(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6072,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1569 posix-error */
t6=lf[3];
f_3457(6,t6,t1,lf[48],t2,lf[293],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6085,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1570 ##sys#make-port */
t7=*((C_word*)lf[146]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[147]+1),lf[294],lf[149]);}}

/* k6083 in check in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_6035(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6035,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6043,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[287]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1563 ##sys#error */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[288],t5);}
else{
t8=t4;
f_6043(2,t8,lf[289]);}}
else{
/* posixunix.scm: 1564 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[290],t5);}}
else{
t5=t4;
f_6043(2,t5,(C_truep(t2)?lf[291]:lf[292]));}}

/* k6041 in mode in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1559 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_6010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6010,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[281]);
t5=(C_word)C_i_check_string_2(t3,lf[281]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5991,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5991(2,t9,C_SCHEME_FALSE);}}

/* k5989 in file-link in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_5995(2,t3,C_SCHEME_FALSE);}}

/* k5993 in k5989 in file-link in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1466(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1544 posix-error */
t3=lf[3];
f_3457(7,t3,((C_word*)t0)[4],lf[48],lf[282],lf[283],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5960(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5960,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[279]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5968,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5984,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1533 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k5982 in read-symbolic-link in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1533 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5966 in read-symbolic-link in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5968,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5971,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1535 posix-error */
t4=lf[3];
f_3457(6,t4,t3,lf[48],lf[279],lf[280],((C_word*)t0)[2]);}
else{
t4=t3;
f_5971(2,t4,C_SCHEME_UNDEFINED);}}

/* k5969 in k5966 in read-symbolic-link in k5957 in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1536 substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5922,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[275]);
t5=(C_word)C_i_check_string_2(t3,lf[275]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5943,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5955,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1521 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5953 in create-symbolic-link in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1521 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5941 in create-symbolic-link in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5951,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1522 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5949 in k5941 in create-symbolic-link in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1522 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5945 in k5941 in create-symbolic-link in k5918 in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1524 posix-error */
t3=lf[3];
f_3457(7,t3,((C_word*)t0)[4],lf[48],lf[276],lf[277],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* create-session in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5903,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5907,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5913,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1492 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5907(2,t4,C_SCHEME_UNDEFINED);}}

/* k5911 in create-session in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1493 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[272],lf[273]);}

/* k5905 in create-session in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5897,3,t0,t1,t2);}
/* posixunix.scm: 1487 check */
f_5861(t1,t2,C_fix((C_word)X_OK),lf[271]);}

/* file-write-access? in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5891,3,t0,t1,t2);}
/* posixunix.scm: 1486 check */
f_5861(t1,t2,C_fix((C_word)W_OK),lf[270]);}

/* file-read-access? in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5885,3,t0,t1,t2);}
/* posixunix.scm: 1485 check */
f_5861(t1,t2,C_fix((C_word)R_OK),lf[269]);}

/* check in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_5861(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5861,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5879,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5883,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1482 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5881 in check in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1482 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5877 in check in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5879,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5871,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5871(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1483 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5869 in k5877 in check in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5831,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[267]);
t6=(C_word)C_i_check_exact_2(t3,lf[267]);
t7=(C_word)C_i_check_exact_2(t4,lf[267]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5855,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5859,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1472 ##sys#expand-home-path */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k5857 in change-file-owner in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1472 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5853 in change-file-owner in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1473 posix-error */
t3=lf[3];
f_3457(8,t3,((C_word*)t0)[3],lf[48],lf[267],lf[268],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5804,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[265]);
t5=(C_word)C_i_check_exact_2(t3,lf[265]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5825,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5829,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1464 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5827 in change-file-mode in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1464 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5823 in change-file-mode in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1465 posix-error */
t3=lf[3];
f_3457(7,t3,((C_word*)t0)[3],lf[48],lf[265],lf[266],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5740,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[224]);
t5=(C_word)C_i_check_exact_2(t3,lf[224]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5728,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5728(2,t9,C_SCHEME_FALSE);}}

/* k5726 in initialize-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5728,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub1291(C_SCHEME_UNDEFINED,t1,t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1385 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5754 in k5726 in initialize-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1386 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[224],lf[225],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5666,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5670,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_5596(t4);
if(C_truep(t5)){
t6=t3;
f_5670(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1368 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[221],lf[223]);}}

/* k5668 in set-groups! in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5670,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5675,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li98),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5675(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop1267 in k5668 in set-groups! in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_5675(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5675,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1373 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[221]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k5689 in doloop1267 in k5668 in set-groups! in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1374 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[221],lf[222],((C_word*)t0)[2]);}

/* get-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5603,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5607,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5661,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1354 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5607(2,t4,C_SCHEME_UNDEFINED);}}

/* k5659 in get-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1355 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[217],lf[220]);}

/* k5605 in get-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_5596(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_5610(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1357 ##sys#error */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[217],lf[219]);}}

/* k5608 in k5605 in get-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub1226(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5642,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1359 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_5613(2,t5,C_SCHEME_UNDEFINED);}}

/* k5640 in k5608 in k5605 in get-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1360 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[217],lf[218]);}

/* k5611 in k5608 in k5605 in get-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5613,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5618,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li96),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5618(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5611 in k5608 in k5605 in get-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_5618(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5618,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5632,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1364 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k5630 in loop in k5611 in k5608 in k5605 in get-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall f_5596(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub1232(C_SCHEME_UNDEFINED,t2));}

/* group-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5510r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5510r(t0,t1,t2,t3);}}

static void C_ccall f_5510r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5514,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5514(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5514(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5512 in group-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5517,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_5517(t3,(C_word)C_getgrgid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[215]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5568,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1328 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5566 in k5512 in group-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5517(t2,(C_word)C_getgrnam(t1));}

/* k5515 in k5512 in group-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_5517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5517,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5525 in k5515 in k5512 in group-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5531,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k5529 in k5525 in k5515 in k5512 in group-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5535,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5540,a[2]=t4,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5540(t6,t2,C_fix(0));}

/* loop in k5529 in k5525 in k5515 in k5512 in group-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_5540(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5540,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5544,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1184(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k5542 in loop in k5529 in k5525 in k5515 in k5512 in group-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5554,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1337 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5540(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k5552 in k5542 in loop in k5529 in k5525 in k5515 in k5512 in group-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5533 in k5529 in k5525 in k5515 in k5512 in group-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[212]+1):*((C_word*)lf[213]+1));
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5493,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5497,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1313 current-effective-user-id */
((C_proc2)C_retrieve_proc(*((C_word*)lf[208]+1)))(2,*((C_word*)lf[208]+1),t3);}

/* k5495 in current-effective-user-name in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1313 user-information */
((C_proc3)C_retrieve_proc(*((C_word*)lf[211]+1)))(3,*((C_word*)lf[211]+1),((C_word*)t0)[2],t1);}

/* k5491 in current-effective-user-name in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5479,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5483,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1310 current-user-id */
((C_proc2)C_retrieve_proc(*((C_word*)lf[207]+1)))(2,*((C_word*)lf[207]+1),t3);}

/* k5481 in current-user-name in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1310 user-information */
((C_proc3)C_retrieve_proc(*((C_word*)lf[211]+1)))(3,*((C_word*)lf[211]+1),((C_word*)t0)[2],t1);}

/* k5477 in current-user-name in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* user-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5404r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5404r(t0,t1,t2,t3);}}

static void C_ccall f_5404r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5408,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5408(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5408(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5406 in user-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5411,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_5411(t3,(C_word)C_getpwuid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[211]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5450,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1298 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5448 in k5406 in user-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5411(t2,(C_word)C_getpwnam(t1));}

/* k5409 in k5406 in user-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_5411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5411,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5419 in k5409 in k5406 in user-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5425,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k5423 in k5419 in k5409 in k5406 in user-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5429,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k5427 in k5423 in k5419 in k5409 in k5406 in user-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5433,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k5431 in k5427 in k5423 in k5419 in k5409 in k5406 in user-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5437,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k5435 in k5431 in k5427 in k5423 in k5419 in k5409 in k5406 in user-information in k5400 in k5396 in k5392 in k5388 in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[212]+1):*((C_word*)lf[213]+1));
t3=t2;
((C_proc9)C_retrieve_proc(t3))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* system-information in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5354,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5383,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1243 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_5354(2,t3,C_SCHEME_UNDEFINED);}}

/* k5381 in system-information in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1244 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[204],lf[206]);}

/* k5352 in system-information in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k5359 in k5352 in system-information in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5365,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k5363 in k5359 in k5352 in system-information in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5369,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k5367 in k5363 in k5359 in k5352 in system-information in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5373,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k5371 in k5367 in k5363 in k5359 in k5352 in system-information in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5377,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k5375 in k5371 in k5367 in k5363 in k5359 in k5352 in system-information in k5346 in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5377,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5332,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[202]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1222 posix-error */
t5=lf[3];
f_3457(5,t5,t1,lf[196],lf[202],lf[203]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5317,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[200]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1216 posix-error */
t5=lf[3];
f_3457(5,t5,t1,lf[196],lf[200],lf[201]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5311,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[199]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5285,a[2]=t3,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5285(t5,t1,*((C_word*)lf[191]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_5285(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5285,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1206 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5255,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[195]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5262,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5273,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5272 in set-signal-mask! in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5273,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[195]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k5260 in set-signal-mask! in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1199 posix-error */
t2=lf[3];
f_3457(5,t2,((C_word*)t0)[2],lf[196],lf[195],lf[197]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5237,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5247,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1185 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1187 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k5245 in ##sys#interrupt-hook in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1186 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5224,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[194]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k5211 in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5215,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[193]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5172,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1102 posix-error */
t3=lf[3];
f_3457(5,t3,t2,lf[48],lf[164],lf[165]);}
else{
t3=t2;
f_5172(2,t3,C_SCHEME_UNDEFINED);}}

/* k5170 in create-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1103 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5148r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5148r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5148r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[163]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5152,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5150 in with-output-to-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5152,2,t0,t1);}
t2=C_mutate((C_word*)lf[163]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5158,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li76),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1090 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5157 in k5150 in with-output-to-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5158r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5158r(t0,t1,t2);}}

static void C_ccall f_5158r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5162,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1092 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5160 in a5157 in k5150 in with-output-to-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[163]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5128r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5128r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5128r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[161]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5132,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5130 in with-input-from-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5132,2,t0,t1);}
t2=C_mutate((C_word*)lf[161]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5138,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1080 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5137 in k5130 in with-input-from-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5138r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5138r(t0,t1,t2);}}

static void C_ccall f_5138r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5142,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1082 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5140 in a5137 in k5130 in with-input-from-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[161]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5104r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5104r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5104r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5108,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5106 in call-with-output-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5113,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5119,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1070 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5118 in k5106 in call-with-output-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5119r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5119r(t0,t1,t2);}}

static void C_ccall f_5119r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5123,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1073 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5121 in a5118 in k5106 in call-with-output-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5112 in k5106 in call-with-output-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5113,2,t0,t1);}
/* posixunix.scm: 1071 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5080r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5080r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5080r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5084,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5082 in call-with-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5089,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5095,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1062 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5094 in k5082 in call-with-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5095(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5095r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5095r(t0,t1,t2);}}

static void C_ccall f_5095r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5099,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1065 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5097 in a5094 in k5082 in call-with-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5088 in k5082 in call-with-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5089,2,t0,t1);}
/* posixunix.scm: 1063 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5064,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5068,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1049 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[153]);}

/* k5066 in close-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5068,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5071,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1051 posix-error */
t5=lf[3];
f_3457(6,t5,t3,lf[48],lf[154],lf[155],((C_word*)t0)[3]);}
else{
t5=t3;
f_5071(2,t5,C_SCHEME_UNDEFINED);}}

/* k5069 in k5066 in close-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_5028r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5028r(t0,t1,t2,t3);}}

static void C_ccall f_5028r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[152]);
t5=f_4959(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5042,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5049,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1044 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5059,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1045 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1046 badmode */
f_4971(t6,t5);}}}

/* k5057 in open-output-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5059,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5042(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k5047 in open-output-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5049,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5042(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k5040 in open-output-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1040 check */
f_4977(((C_word*)t0)[3],lf[152],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4992r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4992r(t0,t1,t2,t3);}}

static void C_ccall f_4992r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[150]);
t5=f_4959(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5006,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5013,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1033 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5023,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1034 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1035 badmode */
f_4971(t6,t5);}}}

/* k5021 in open-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5023,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5006(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k5011 in open-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5013,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5006(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k5004 in open-input-pipe in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1029 check */
f_4977(((C_word*)t0)[3],lf[150],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4977(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4977,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1021 posix-error */
t6=lf[3];
f_3457(6,t6,t1,lf[48],t2,lf[145],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4990,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1022 ##sys#make-port */
t7=*((C_word*)lf[146]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[147]+1),lf[148],lf[149]);}}

/* k4988 in check in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4971(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4971,NULL,2,t1,t2);}
/* posixunix.scm: 1018 ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[144],t2);}

/* mode in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall f_4959(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[143]));}

/* canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4642(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4642,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4649,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4763,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 966  cwd */
t8=((C_word*)t0)[6];
f_4586(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[12],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 968  sref */
t10=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_4769(t9,C_SCHEME_FALSE);}}}

/* k4947 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 968  sep? */
t2=((C_word*)t0)[3];
f_4769(t2,f_4575(t1));}

/* k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4769,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
f_4649(2,t2,((C_word*)t0)[10]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 971  cwd */
t5=((C_word*)t0)[8];
f_4586(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4935,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 972  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k4933 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 972  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k4922 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4924,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 973  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4788(t2,C_SCHEME_FALSE);}}

/* k4929 in k4922 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 973  sep? */
t2=((C_word*)t0)[3];
f_4788(t2,f_4575(t1));}

/* k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4788,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4795,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 975  getenv */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[140]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 980  cwd */
t5=((C_word*)t0)[6];
f_4586(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4917,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 981  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(0));}}}

/* k4915 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 981  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4894 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4913,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 982  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_4832(t2,C_SCHEME_FALSE);}}

/* k4911 in k4894 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 982  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4900 in k4894 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4902,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4909,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 983  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_4832(t2,C_SCHEME_FALSE);}}

/* k4907 in k4900 in k4894 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 983  sep? */
t2=((C_word*)t0)[3];
f_4832(t2,f_4575(t1));}

/* k4830 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4832,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
/* posixunix.scm: 984  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)t0)[9],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4845,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4893,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 985  sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[9],C_fix(0));}}

/* k4891 in k4830 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 985  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k4870 in k4830 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4872,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4889,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 986  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4845(2,t2,C_SCHEME_FALSE);}}

/* k4887 in k4870 in k4830 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 986  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4876 in k4870 in k4830 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4878,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4885,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 987  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_4845(2,t2,C_SCHEME_FALSE);}}

/* k4883 in k4876 in k4870 in k4830 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 987  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4843 in k4830 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4845,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
/* posixunix.scm: 988  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 989  sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],C_fix(0));}}

/* k4867 in k4843 in k4830 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4869,2,t0,t1);}
t2=f_4575(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_4649(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4865,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 992  cwd */
t4=((C_word*)t0)[2];
f_4586(t4,t3);}}

/* k4863 in k4867 in k4843 in k4830 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 992  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[142],((C_word*)t0)[2]);}

/* k4824 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 980  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[141],((C_word*)t0)[2]);}

/* k4793 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4798(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4813,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 976  user */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k4811 in k4793 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 976  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[139],t1);}

/* k4796 in k4793 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4802,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 977  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k4800 in k4796 in k4793 in k4786 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 974  sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4780 in k4767 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 971  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[138],((C_word*)t0)[2]);}

/* k4761 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 966  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[137]);}

/* k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=t1;
/* string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[101]+1)))(4,*((C_word*)lf[101]+1),t2,t3,lf[136]);}

/* k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4656,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li60),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_4658(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4658(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4658,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 995  null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4663 in loop in k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4671,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 996  null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4726,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 1007 string=? */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[135],t5);}}

/* k4727 in k4663 in loop in k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4729,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4726(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4738,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 1009 string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[134],t3);}}

/* k4736 in k4727 in k4663 in loop in k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4726(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_4726(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k4724 in k4663 in loop in k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4726(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1005 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4658(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4669 in k4663 in loop in k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[129]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 998  sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k4705 in k4669 in k4663 in loop in k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
t2=f_4575(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4688,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[131],((C_word*)t0)[2]);
/* posixunix.scm: 1001 reverse */
t6=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4699,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4703,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1004 reverse */
t5=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4701 in k4705 in k4669 in k4663 in loop in k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1004 isperse */
f_4570(((C_word*)t0)[2],t1);}

/* k4697 in k4705 in k4669 in k4663 in loop in k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1002 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[133],t1);}

/* k4686 in k4705 in k4669 in k4663 in loop in k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1001 isperse */
f_4570(((C_word*)t0)[2],t1);}

/* k4682 in k4705 in k4669 in k4663 in loop in k4654 in k4647 in canonical-path in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 999  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[130],t1);}

/* cwd in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4586,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4593,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[2],a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a4594 in cwd in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4595,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4601,a[2]=t2,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4619,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t1,t3,t4);}

/* a4618 in a4594 in cwd in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4625,a[2]=((C_word*)t0)[3],a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[2],a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4630 in a4618 in a4594 in cwd in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4631r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4631r(t0,t1,t2);}}

static void C_ccall f_4631r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4637,a[2]=t2,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
/* k787793 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4636 in a4630 in a4618 in a4594 in cwd in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4624 in a4618 in a4594 in cwd in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4625,2,t0,t1);}
/* posixunix.scm: 961  cw */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a4600 in a4594 in cwd in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4601,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4607,a[2]=t2,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
/* k787793 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4606 in a4600 in a4594 in cwd in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[125]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[126]);}

/* k4591 in cwd in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* sep? in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall f_4575(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4570(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4570,NULL,2,t1,t2);}
/* string-intersperse */
((C_proc4)C_retrieve_proc(*((C_word*)lf[121]+1)))(4,*((C_word*)lf[121]+1),t1,t2,lf[122]);}

/* current-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4522r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4522r(t0,t1,t2);}}

static void C_ccall f_4522r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4526,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4526(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4526(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4524 in current-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4526,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 939  change-directory */
t2=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 940  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k4533 in k4524 in current-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 943  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 944  posix-error */
t3=lf[3];
f_3457(5,t3,((C_word*)t0)[2],lf[48],lf[113],lf[116]);}}

/* directory? in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4499,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[114]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4506,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4520,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 932  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4518 in directory? in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 932  ##sys#file-info */
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4504 in directory? in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_4342r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4342r(t0,t1,t2);}}

static void C_ccall f_4342r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4442,a[2]=t3,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4447,a[2]=t4,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec635692 */
t6=t5;
f_4447(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?636688 */
t8=t4;
f_4442(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body633642 */
t10=t3;
f_4344(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec635 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4447(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4447,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4455,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 905  current-directory */
t3=*((C_word*)lf[113]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4453 in def-spec635 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?636688 */
t2=((C_word*)t0)[3];
f_4442(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?636 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4442(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4442,NULL,3,t0,t1,t2);}
/* body633642 */
t3=((C_word*)t0)[2];
f_4344(t3,t1,t2,C_SCHEME_FALSE);}

/* body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4344(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4344,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[110]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 907  make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k4349 in body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 908  ##sys#make-pointer */
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4352 in k4349 in body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 909  ##sys#make-pointer */
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4355 in k4352 in k4349 in body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4441,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 910  ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k4439 in k4355 in k4352 in k4349 in body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 910  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4359 in k4355 in k4352 in k4349 in body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4361,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 912  posix-error */
t3=lf[3];
f_3457(6,t3,((C_word*)t0)[7],lf[48],lf[110],lf[111],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word)li43),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_4375(t6,((C_word*)t0)[7]);}}

/* loop in k4359 in k4355 in k4352 in k4349 in body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4375(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4375,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 920  ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k4383 in loop in k4359 in k4355 in k4352 in k4349 in body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 921  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_fix(0));}

/* k4386 in k4383 in loop in k4359 in k4355 in k4352 in k4349 in body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 922  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_4391(2,t3,C_SCHEME_FALSE);}}

/* k4389 in k4386 in k4383 in loop in k4359 in k4355 in k4352 in k4349 in body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_4397(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_4397(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_4397(t4,C_SCHEME_FALSE);}}

/* k4395 in k4389 in k4386 in k4383 in loop in k4359 in k4355 in k4352 in k4349 in body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_4397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4397,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 927  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4375(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 928  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4375(t3,t2);}}

/* k4405 in k4395 in k4389 in k4386 in k4383 in loop in k4359 in k4355 in k4352 in k4349 in body633 in directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4407,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4318,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[106]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4336,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4340,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 898  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4338 in delete-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 898  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4334 in delete-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 899  posix-error */
t3=lf[3];
f_3457(6,t3,((C_word*)t0)[3],lf[48],lf[106],lf[107],((C_word*)t0)[2]);}}

/* change-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4294,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[104]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4312,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4316,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 892  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4314 in change-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 892  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4310 in change-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 893  posix-error */
t3=lf[3];
f_3457(6,t3,((C_word*)t0)[3],lf[48],lf[104],lf[105],((C_word*)t0)[2]);}}

/* create-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4159r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4159r(t0,t1,t2,t3);}}

static void C_ccall f_4159r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4163,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4163(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4163(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4161 in create-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[94]);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 884  canonical-path */
t4=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4257,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 885  canonical-path */
t4=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}}

/* k4255 in k4161 in create-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4258,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4258 in k4255 in k4161 in create-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4258,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4273,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 854  ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4271 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 855  posix-error */
t3=lf[3];
f_3457(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[96],((C_word*)t0)[2]);}}

/* k4174 in k4161 in create-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4177,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4177 in k4174 in k4161 in create-directory in k4155 in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4177,3,t0,t1,t2);}
t3=lf[95];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4183,a[2]=t4,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4250,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 878  string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[101]+1)))(4,*((C_word*)lf[101]+1),t6,t2,lf[102]);}

/* k4248 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4182 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4183,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4188,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 876  string-append */
t4=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[100],t2);}

/* k4186 in a4182 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4192,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}

/* f_4192 in k4186 in a4182 */
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4192,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4199,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4219,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_4219 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4219,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4226,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 859  file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[99]+1)))(3,*((C_word*)lf[99]+1),t3,t2);}

/* k4224 */
static void C_ccall f_4226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4226,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 860  ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4244 in k4224 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_stat(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 861  posix-error */
t3=lf[3];
f_3457(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[97],((C_word*)t0)[2]);}
else{
t3=C_mk_bool(C_isdir);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* posixunix.scm: 864  posix-error */
t4=lf[3];
f_3457(6,t4,((C_word*)t0)[3],lf[48],lf[94],lf[98],((C_word*)t0)[2]);}}}

/* k4197 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4199,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4203,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_4203 in k4197 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4203,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4218,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 854  ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4216 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 855  posix-error */
t3=lf[3];
f_3457(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[96],((C_word*)t0)[2]);}}

/* stat-socket? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4146,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[92]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4153,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 823  ##sys#stat */
f_3969(t4,t2,C_SCHEME_FALSE,lf[92]);}

/* k4151 in stat-socket? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* stat-symlink? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4137,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[91]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4144,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 818  ##sys#stat */
f_3969(t4,t2,C_SCHEME_TRUE,lf[91]);}

/* k4142 in stat-symlink? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* stat-fifo? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4128,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4135,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 813  ##sys#stat */
f_3969(t4,t2,C_SCHEME_FALSE,lf[90]);}

/* k4133 in stat-fifo? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* stat-block-device? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4119,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4126,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 808  ##sys#stat */
f_3969(t4,t2,C_SCHEME_FALSE,lf[89]);}

/* k4124 in stat-block-device? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* stat-char-device? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4110,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4117,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 803  ##sys#stat */
f_3969(t4,t2,C_SCHEME_FALSE,lf[88]);}

/* k4115 in stat-char-device? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4101,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4108,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 798  ##sys#stat */
f_3969(t4,t2,C_SCHEME_FALSE,lf[87]);}

/* k4106 in stat-directory? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4092,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4099,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 793  ##sys#stat */
f_3969(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k4097 in stat-regular? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4083,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4090,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 788  ##sys#stat */
f_3969(t4,t2,C_SCHEME_TRUE,lf[85]);}

/* k4088 in symbolic-link? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4074,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4081,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 783  ##sys#stat */
f_3969(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k4079 in regular-file? in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4068,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4072,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#stat */
f_3969(t3,t2,C_SCHEME_FALSE,lf[83]);}

/* k4070 in file-permissions in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4062,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4066,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 778  ##sys#stat */
f_3969(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k4064 in file-owner in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4056,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4060,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 777  ##sys#stat */
f_3969(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k4058 in file-change-time in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4050,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4054,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 776  ##sys#stat */
f_3969(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k4052 in file-access-time in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4044,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4048,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 775  ##sys#stat */
f_3969(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k4046 in file-modification-time in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4038,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4042,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 774  ##sys#stat */
f_3969(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k4040 in file-size in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4006r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4006r(t0,t1,t2,t3);}}

static void C_ccall f_4006r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4010,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4017,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_4017(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4017(2,t7,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k4015 in file-stat in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 767  ##sys#stat */
f_3969(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[77]);}

/* k4008 in file-stat in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4010,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_3969(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3969,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3973,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_3973(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3994,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4001,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 758  ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 762  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[76],t2);}}}

/* k3999 in ##sys#stat in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 758  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3992 in ##sys#stat in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3973(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k3971 in ##sys#stat in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 764  posix-error */
t2=lf[3];
f_3457(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[75],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3777r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3777r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3777r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_3751(C_fix(0));
t10=f_3751(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3793,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_3793(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 687  fd_set */
t14=t12;
f_3793(2,t14,f_3757(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[68]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t15=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a3949 in file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3950,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 694  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_3757(C_fix(0),t2));}

/* k3791 in file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3793,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_3799(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 699  fd_set */
t5=t3;
f_3799(2,t5,f_3757(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[68]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a3923 in k3791 in file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3924,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 706  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_3757(C_fix(1),t2));}

/* k3797 in k3791 in file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3802,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[68]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_3802(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_3802(t4,(C_word)C_C_select(t3));}}

/* k3800 in k3797 in k3791 in file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_3802(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3802,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 713  posix-error */
t2=lf[3];
f_3457(7,t2,((C_word*)t0)[5],lf[48],lf[68],lf[69],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 714  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 719  fd_test */
t4=t3;
f_3841(t4,f_3767(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3882,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3884,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_3841(t4,C_SCHEME_FALSE);}}}}

/* a3883 in k3800 in k3797 in k3791 in file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3884,3,t0,t1,t2);}
t3=f_3767(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3880 in k3800 in k3797 in k3791 in file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3841(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3839 in k3800 in k3797 in k3791 in file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_3841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3841,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3845,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 725  fd_test */
t3=t2;
f_3845(t3,f_3767(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3857,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3859,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_3845(t3,C_SCHEME_FALSE);}}

/* a3858 in k3839 in k3800 in k3797 in k3791 in file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3859,3,t0,t1,t2);}
t3=f_3767(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3855 in k3839 in k3800 in k3797 in k3791 in file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3845(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3843 in k3839 in k3800 in k3797 in k3791 in file-select in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_fcall f_3845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 716  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall f_3767(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub252(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_set in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall f_3757(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub245(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_zero in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static C_word C_fcall f_3751(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub239(C_SCHEME_UNDEFINED,t2));}

/* file-mkstemp in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3719,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[65]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3726,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 665  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3724 in file-mkstemp in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3726,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3732,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 669  posix-error */
t6=lf[3];
f_3457(6,t6,t4,lf[48],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t6=t4;
f_3732(2,t6,C_SCHEME_UNDEFINED);}}

/* k3730 in k3724 in file-mkstemp in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3739,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 670  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k3737 in k3730 in k3724 in file-mkstemp in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 670  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3680r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3680r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3680r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[62]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3687,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_3687(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 654  ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[60],lf[62],lf[64],t3);}}

/* k3685 in file-write in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3687,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[62]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3696,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 659  posix-error */
t8=lf[3];
f_3457(7,t8,t6,lf[48],lf[62],lf[63],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_3696(2,t8,C_SCHEME_UNDEFINED);}}

/* k3694 in k3685 in file-write in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3638r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3638r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3638r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3648,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_3648(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixunix.scm: 642  make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k3646 in file-read in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_3651(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 644  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[60],lf[58],lf[61],t1);}}

/* k3649 in k3646 in file-read in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3651,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3654,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 647  posix-error */
t5=lf[3];
f_3457(7,t5,t3,lf[48],lf[58],lf[59],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_3654(2,t5,C_SCHEME_UNDEFINED);}}

/* k3652 in k3649 in k3646 in file-read in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3654,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3623,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[55]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 635  posix-error */
t4=lf[3];
f_3457(6,t4,t1,lf[48],lf[55],lf[56],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3585r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3585r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3585r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[51]);
t8=(C_word)C_i_check_exact_2(t3,lf[51]);
t9=(C_word)C_i_check_exact_2(t6,lf[51]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3602,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3615,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 626  ##sys#expand-home-path */
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k3613 in file-open in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 626  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3600 in file-open in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3602,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3605,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 628  posix-error */
t5=lf[3];
f_3457(8,t5,t3,lf[48],lf[51],lf[52],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_3605(2,t5,C_SCHEME_UNDEFINED);}}

/* k3603 in k3600 in file-open in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3539r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3539r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3539r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3543,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3543(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3543(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3541 in file-control in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[47]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[47]);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_integer_argumentp(t1);
t9=(C_word)stub124(C_SCHEME_UNDEFINED,t6,t7,t8);
t10=(C_word)C_eqp(t9,C_fix(-1));
if(C_truep(t10)){
/* posixunix.scm: 616  posix-error */
t11=lf[3];
f_3457(7,t11,((C_word*)t0)[2],lf[48],lf[47],lf[49],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t9);}}

/* ##sys#file-select-one in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3482,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub46(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-nonblocking! in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3475,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub40(C_SCHEME_UNDEFINED,t3));}

/* posix-error in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_3457r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3457r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3457r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3461,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 506  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3459 in posix-error in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3468,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub23(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k3470 in k3459 in posix-error in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 507  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k3466 in k3459 in posix-error in k3443 in k3440 in k3437 in k3434 in k3431 in k3428 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[623] = {
{"toplevel:posixunix_scm",(void*)C_posix_toplevel},
{"f_3430:posixunix_scm",(void*)f_3430},
{"f_3433:posixunix_scm",(void*)f_3433},
{"f_3436:posixunix_scm",(void*)f_3436},
{"f_3439:posixunix_scm",(void*)f_3439},
{"f_3442:posixunix_scm",(void*)f_3442},
{"f_3445:posixunix_scm",(void*)f_3445},
{"f_9330:posixunix_scm",(void*)f_9330},
{"f_9343:posixunix_scm",(void*)f_9343},
{"f_9355:posixunix_scm",(void*)f_9355},
{"f_9349:posixunix_scm",(void*)f_9349},
{"f_9293:posixunix_scm",(void*)f_9293},
{"f_9309:posixunix_scm",(void*)f_9309},
{"f_9297:posixunix_scm",(void*)f_9297},
{"f_9300:posixunix_scm",(void*)f_9300},
{"f_4157:posixunix_scm",(void*)f_4157},
{"f_5213:posixunix_scm",(void*)f_5213},
{"f_9287:posixunix_scm",(void*)f_9287},
{"f_5348:posixunix_scm",(void*)f_5348},
{"f_9272:posixunix_scm",(void*)f_9272},
{"f_9282:posixunix_scm",(void*)f_9282},
{"f_9269:posixunix_scm",(void*)f_9269},
{"f_5390:posixunix_scm",(void*)f_5390},
{"f_9254:posixunix_scm",(void*)f_9254},
{"f_9264:posixunix_scm",(void*)f_9264},
{"f_9251:posixunix_scm",(void*)f_9251},
{"f_5394:posixunix_scm",(void*)f_5394},
{"f_9236:posixunix_scm",(void*)f_9236},
{"f_9246:posixunix_scm",(void*)f_9246},
{"f_9233:posixunix_scm",(void*)f_9233},
{"f_5398:posixunix_scm",(void*)f_5398},
{"f_9218:posixunix_scm",(void*)f_9218},
{"f_9228:posixunix_scm",(void*)f_9228},
{"f_9215:posixunix_scm",(void*)f_9215},
{"f_5402:posixunix_scm",(void*)f_5402},
{"f_9194:posixunix_scm",(void*)f_9194},
{"f_9210:posixunix_scm",(void*)f_9210},
{"f_9176:posixunix_scm",(void*)f_9176},
{"f_9189:posixunix_scm",(void*)f_9189},
{"f_9183:posixunix_scm",(void*)f_9183},
{"f_5920:posixunix_scm",(void*)f_5920},
{"f_5959:posixunix_scm",(void*)f_5959},
{"f_9153:posixunix_scm",(void*)f_9153},
{"f_9145:posixunix_scm",(void*)f_9145},
{"f_8894:posixunix_scm",(void*)f_8894},
{"f_9071:posixunix_scm",(void*)f_9071},
{"f_9077:posixunix_scm",(void*)f_9077},
{"f_9066:posixunix_scm",(void*)f_9066},
{"f_9061:posixunix_scm",(void*)f_9061},
{"f_8896:posixunix_scm",(void*)f_8896},
{"f_9048:posixunix_scm",(void*)f_9048},
{"f_9056:posixunix_scm",(void*)f_9056},
{"f_8903:posixunix_scm",(void*)f_8903},
{"f_9036:posixunix_scm",(void*)f_9036},
{"f_9030:posixunix_scm",(void*)f_9030},
{"f_8913:posixunix_scm",(void*)f_8913},
{"f_8915:posixunix_scm",(void*)f_8915},
{"f_8934:posixunix_scm",(void*)f_8934},
{"f_9016:posixunix_scm",(void*)f_9016},
{"f_9023:posixunix_scm",(void*)f_9023},
{"f_9010:posixunix_scm",(void*)f_9010},
{"f_8949:posixunix_scm",(void*)f_8949},
{"f_9003:posixunix_scm",(void*)f_9003},
{"f_9000:posixunix_scm",(void*)f_9000},
{"f_8990:posixunix_scm",(void*)f_8990},
{"f_8966:posixunix_scm",(void*)f_8966},
{"f_8988:posixunix_scm",(void*)f_8988},
{"f_8974:posixunix_scm",(void*)f_8974},
{"f_8981:posixunix_scm",(void*)f_8981},
{"f_8978:posixunix_scm",(void*)f_8978},
{"f_8961:posixunix_scm",(void*)f_8961},
{"f_8959:posixunix_scm",(void*)f_8959},
{"f_9037:posixunix_scm",(void*)f_9037},
{"f_8834:posixunix_scm",(void*)f_8834},
{"f_8846:posixunix_scm",(void*)f_8846},
{"f_8841:posixunix_scm",(void*)f_8841},
{"f_8836:posixunix_scm",(void*)f_8836},
{"f_8774:posixunix_scm",(void*)f_8774},
{"f_8786:posixunix_scm",(void*)f_8786},
{"f_8781:posixunix_scm",(void*)f_8781},
{"f_8776:posixunix_scm",(void*)f_8776},
{"f_8713:posixunix_scm",(void*)f_8713},
{"f_8768:posixunix_scm",(void*)f_8768},
{"f_8772:posixunix_scm",(void*)f_8772},
{"f_8734:posixunix_scm",(void*)f_8734},
{"f_8737:posixunix_scm",(void*)f_8737},
{"f_8748:posixunix_scm",(void*)f_8748},
{"f_8742:posixunix_scm",(void*)f_8742},
{"f_8715:posixunix_scm",(void*)f_8715},
{"f_8724:posixunix_scm",(void*)f_8724},
{"f_8655:posixunix_scm",(void*)f_8655},
{"f_8667:posixunix_scm",(void*)f_8667},
{"f_8698:posixunix_scm",(void*)f_8698},
{"f_8678:posixunix_scm",(void*)f_8678},
{"f_8694:posixunix_scm",(void*)f_8694},
{"f_8682:posixunix_scm",(void*)f_8682},
{"f_8690:posixunix_scm",(void*)f_8690},
{"f_8686:posixunix_scm",(void*)f_8686},
{"f_8661:posixunix_scm",(void*)f_8661},
{"f_8644:posixunix_scm",(void*)f_8644},
{"f_8648:posixunix_scm",(void*)f_8648},
{"f_8633:posixunix_scm",(void*)f_8633},
{"f_8637:posixunix_scm",(void*)f_8637},
{"f_8588:posixunix_scm",(void*)f_8588},
{"f_8592:posixunix_scm",(void*)f_8592},
{"f_8595:posixunix_scm",(void*)f_8595},
{"f_8598:posixunix_scm",(void*)f_8598},
{"f_8611:posixunix_scm",(void*)f_8611},
{"f_8615:posixunix_scm",(void*)f_8615},
{"f_8618:posixunix_scm",(void*)f_8618},
{"f_8621:posixunix_scm",(void*)f_8621},
{"f_8609:posixunix_scm",(void*)f_8609},
{"f_8572:posixunix_scm",(void*)f_8572},
{"f_8555:posixunix_scm",(void*)f_8555},
{"f_8568:posixunix_scm",(void*)f_8568},
{"f_8480:posixunix_scm",(void*)f_8480},
{"f_8541:posixunix_scm",(void*)f_8541},
{"f_8554:posixunix_scm",(void*)f_8554},
{"f_8521:posixunix_scm",(void*)f_8521},
{"f_8536:posixunix_scm",(void*)f_8536},
{"f_8530:posixunix_scm",(void*)f_8530},
{"f_8484:posixunix_scm",(void*)f_8484},
{"f_8486:posixunix_scm",(void*)f_8486},
{"f_8507:posixunix_scm",(void*)f_8507},
{"f_8501:posixunix_scm",(void*)f_8501},
{"f_8428:posixunix_scm",(void*)f_8428},
{"f_8435:posixunix_scm",(void*)f_8435},
{"f_8454:posixunix_scm",(void*)f_8454},
{"f_8458:posixunix_scm",(void*)f_8458},
{"f_8422:posixunix_scm",(void*)f_8422},
{"f_8413:posixunix_scm",(void*)f_8413},
{"f_8417:posixunix_scm",(void*)f_8417},
{"f_8386:posixunix_scm",(void*)f_8386},
{"f_8379:posixunix_scm",(void*)f_8379},
{"f_8376:posixunix_scm",(void*)f_8376},
{"f_8373:posixunix_scm",(void*)f_8373},
{"f_8295:posixunix_scm",(void*)f_8295},
{"f_8331:posixunix_scm",(void*)f_8331},
{"f_8325:posixunix_scm",(void*)f_8325},
{"f_8278:posixunix_scm",(void*)f_8278},
{"f_8096:posixunix_scm",(void*)f_8096},
{"f_8230:posixunix_scm",(void*)f_8230},
{"f_8225:posixunix_scm",(void*)f_8225},
{"f_8098:posixunix_scm",(void*)f_8098},
{"f_8108:posixunix_scm",(void*)f_8108},
{"f_8116:posixunix_scm",(void*)f_8116},
{"f_8162:posixunix_scm",(void*)f_8162},
{"f_8129:posixunix_scm",(void*)f_8129},
{"f_8154:posixunix_scm",(void*)f_8154},
{"f_8132:posixunix_scm",(void*)f_8132},
{"f_8077:posixunix_scm",(void*)f_8077},
{"f_8058:posixunix_scm",(void*)f_8058},
{"f_8016:posixunix_scm",(void*)f_8016},
{"f_8038:posixunix_scm",(void*)f_8038},
{"f_8042:posixunix_scm",(void*)f_8042},
{"f_7904:posixunix_scm",(void*)f_7904},
{"f_7910:posixunix_scm",(void*)f_7910},
{"f_7931:posixunix_scm",(void*)f_7931},
{"f_8008:posixunix_scm",(void*)f_8008},
{"f_7935:posixunix_scm",(void*)f_7935},
{"f_7938:posixunix_scm",(void*)f_7938},
{"f_7941:posixunix_scm",(void*)f_7941},
{"f_7948:posixunix_scm",(void*)f_7948},
{"f_7950:posixunix_scm",(void*)f_7950},
{"f_7967:posixunix_scm",(void*)f_7967},
{"f_7977:posixunix_scm",(void*)f_7977},
{"f_7981:posixunix_scm",(void*)f_7981},
{"f_7925:posixunix_scm",(void*)f_7925},
{"f_7892:posixunix_scm",(void*)f_7892},
{"f_7896:posixunix_scm",(void*)f_7896},
{"f_7899:posixunix_scm",(void*)f_7899},
{"f_7857:posixunix_scm",(void*)f_7857},
{"f_7861:posixunix_scm",(void*)f_7861},
{"f_7881:posixunix_scm",(void*)f_7881},
{"f_7885:posixunix_scm",(void*)f_7885},
{"f_7834:posixunix_scm",(void*)f_7834},
{"f_7838:posixunix_scm",(void*)f_7838},
{"f_7802:posixunix_scm",(void*)f_7802},
{"f_7806:posixunix_scm",(void*)f_7806},
{"f_7783:posixunix_scm",(void*)f_7783},
{"f_7787:posixunix_scm",(void*)f_7787},
{"f_7790:posixunix_scm",(void*)f_7790},
{"f_7724:posixunix_scm",(void*)f_7724},
{"f_7728:posixunix_scm",(void*)f_7728},
{"f_7734:posixunix_scm",(void*)f_7734},
{"f_7717:posixunix_scm",(void*)f_7717},
{"f_7701:posixunix_scm",(void*)f_7701},
{"f_7689:posixunix_scm",(void*)f_7689},
{"f_7674:posixunix_scm",(void*)f_7674},
{"f_7678:posixunix_scm",(void*)f_7678},
{"f_7659:posixunix_scm",(void*)f_7659},
{"f_7663:posixunix_scm",(void*)f_7663},
{"f_7613:posixunix_scm",(void*)f_7613},
{"f_7617:posixunix_scm",(void*)f_7617},
{"f_7630:posixunix_scm",(void*)f_7630},
{"f_7634:posixunix_scm",(void*)f_7634},
{"f_7544:posixunix_scm",(void*)f_7544},
{"f_7548:posixunix_scm",(void*)f_7548},
{"f_7551:posixunix_scm",(void*)f_7551},
{"f_7573:posixunix_scm",(void*)f_7573},
{"f_7570:posixunix_scm",(void*)f_7570},
{"f_7560:posixunix_scm",(void*)f_7560},
{"f_7508:posixunix_scm",(void*)f_7508},
{"f_7515:posixunix_scm",(void*)f_7515},
{"f_7489:posixunix_scm",(void*)f_7489},
{"f_7480:posixunix_scm",(void*)f_7480},
{"f_7461:posixunix_scm",(void*)f_7461},
{"f_7455:posixunix_scm",(void*)f_7455},
{"f_7446:posixunix_scm",(void*)f_7446},
{"f_7411:posixunix_scm",(void*)f_7411},
{"f_7349:posixunix_scm",(void*)f_7349},
{"f_7353:posixunix_scm",(void*)f_7353},
{"f_7359:posixunix_scm",(void*)f_7359},
{"f_7378:posixunix_scm",(void*)f_7378},
{"f_7365:posixunix_scm",(void*)f_7365},
{"f_7245:posixunix_scm",(void*)f_7245},
{"f_7251:posixunix_scm",(void*)f_7251},
{"f_7255:posixunix_scm",(void*)f_7255},
{"f_7263:posixunix_scm",(void*)f_7263},
{"f_7289:posixunix_scm",(void*)f_7289},
{"f_7293:posixunix_scm",(void*)f_7293},
{"f_7281:posixunix_scm",(void*)f_7281},
{"f_7225:posixunix_scm",(void*)f_7225},
{"f_7233:posixunix_scm",(void*)f_7233},
{"f_7208:posixunix_scm",(void*)f_7208},
{"f_7219:posixunix_scm",(void*)f_7219},
{"f_7223:posixunix_scm",(void*)f_7223},
{"f_7182:posixunix_scm",(void*)f_7182},
{"f_7206:posixunix_scm",(void*)f_7206},
{"f_7189:posixunix_scm",(void*)f_7189},
{"f_7139:posixunix_scm",(void*)f_7139},
{"f_7146:posixunix_scm",(void*)f_7146},
{"f_7167:posixunix_scm",(void*)f_7167},
{"f_7163:posixunix_scm",(void*)f_7163},
{"f_7111:posixunix_scm",(void*)f_7111},
{"f_7089:posixunix_scm",(void*)f_7089},
{"f_7093:posixunix_scm",(void*)f_7093},
{"f_7074:posixunix_scm",(void*)f_7074},
{"f_7078:posixunix_scm",(void*)f_7078},
{"f_7059:posixunix_scm",(void*)f_7059},
{"f_7063:posixunix_scm",(void*)f_7063},
{"f_7041:posixunix_scm",(void*)f_7041},
{"f_6967:posixunix_scm",(void*)f_6967},
{"f_6989:posixunix_scm",(void*)f_6989},
{"f_6995:posixunix_scm",(void*)f_6995},
{"f_6928:posixunix_scm",(void*)f_6928},
{"f_6956:posixunix_scm",(void*)f_6956},
{"f_6952:posixunix_scm",(void*)f_6952},
{"f_6945:posixunix_scm",(void*)f_6945},
{"f_6669:posixunix_scm",(void*)f_6669},
{"f_6865:posixunix_scm",(void*)f_6865},
{"f_6860:posixunix_scm",(void*)f_6860},
{"f_6855:posixunix_scm",(void*)f_6855},
{"f_6671:posixunix_scm",(void*)f_6671},
{"f_6675:posixunix_scm",(void*)f_6675},
{"f_6781:posixunix_scm",(void*)f_6781},
{"f_6782:posixunix_scm",(void*)f_6782},
{"f_6799:posixunix_scm",(void*)f_6799},
{"f_6809:posixunix_scm",(void*)f_6809},
{"f_6767:posixunix_scm",(void*)f_6767},
{"f_6723:posixunix_scm",(void*)f_6723},
{"f_6759:posixunix_scm",(void*)f_6759},
{"f_6738:posixunix_scm",(void*)f_6738},
{"f_6748:posixunix_scm",(void*)f_6748},
{"f_6732:posixunix_scm",(void*)f_6732},
{"f_6727:posixunix_scm",(void*)f_6727},
{"f_6730:posixunix_scm",(void*)f_6730},
{"f_6677:posixunix_scm",(void*)f_6677},
{"f_6712:posixunix_scm",(void*)f_6712},
{"f_6693:posixunix_scm",(void*)f_6693},
{"f_6187:posixunix_scm",(void*)f_6187},
{"f_6591:posixunix_scm",(void*)f_6591},
{"f_6586:posixunix_scm",(void*)f_6586},
{"f_6581:posixunix_scm",(void*)f_6581},
{"f_6576:posixunix_scm",(void*)f_6576},
{"f_6189:posixunix_scm",(void*)f_6189},
{"f_6193:posixunix_scm",(void*)f_6193},
{"f_6199:posixunix_scm",(void*)f_6199},
{"f_6449:posixunix_scm",(void*)f_6449},
{"f_6455:posixunix_scm",(void*)f_6455},
{"f_6551:posixunix_scm",(void*)f_6551},
{"f_6541:posixunix_scm",(void*)f_6541},
{"f_6535:posixunix_scm",(void*)f_6535},
{"f_6457:posixunix_scm",(void*)f_6457},
{"f_6507:posixunix_scm",(void*)f_6507},
{"f_6464:posixunix_scm",(void*)f_6464},
{"f_6474:posixunix_scm",(void*)f_6474},
{"f_6373:posixunix_scm",(void*)f_6373},
{"f_6381:posixunix_scm",(void*)f_6381},
{"f_6383:posixunix_scm",(void*)f_6383},
{"f_6431:posixunix_scm",(void*)f_6431},
{"f_6364:posixunix_scm",(void*)f_6364},
{"f_6368:posixunix_scm",(void*)f_6368},
{"f_6343:posixunix_scm",(void*)f_6343},
{"f_6353:posixunix_scm",(void*)f_6353},
{"f_6331:posixunix_scm",(void*)f_6331},
{"f_6318:posixunix_scm",(void*)f_6318},
{"f_6322:posixunix_scm",(void*)f_6322},
{"f_6313:posixunix_scm",(void*)f_6313},
{"f_6316:posixunix_scm",(void*)f_6316},
{"f_6231:posixunix_scm",(void*)f_6231},
{"f_6243:posixunix_scm",(void*)f_6243},
{"f_6280:posixunix_scm",(void*)f_6280},
{"f_6289:posixunix_scm",(void*)f_6289},
{"f_6283:posixunix_scm",(void*)f_6283},
{"f_6259:posixunix_scm",(void*)f_6259},
{"f_6262:posixunix_scm",(void*)f_6262},
{"f_6223:posixunix_scm",(void*)f_6223},
{"f_6200:posixunix_scm",(void*)f_6200},
{"f_6204:posixunix_scm",(void*)f_6204},
{"f_6160:posixunix_scm",(void*)f_6160},
{"f_6167:posixunix_scm",(void*)f_6167},
{"f_6170:posixunix_scm",(void*)f_6170},
{"f_6115:posixunix_scm",(void*)f_6115},
{"f_6119:posixunix_scm",(void*)f_6119},
{"f_6154:posixunix_scm",(void*)f_6154},
{"f_6137:posixunix_scm",(void*)f_6137},
{"f_6101:posixunix_scm",(void*)f_6101},
{"f_6113:posixunix_scm",(void*)f_6113},
{"f_6087:posixunix_scm",(void*)f_6087},
{"f_6099:posixunix_scm",(void*)f_6099},
{"f_6072:posixunix_scm",(void*)f_6072},
{"f_6085:posixunix_scm",(void*)f_6085},
{"f_6035:posixunix_scm",(void*)f_6035},
{"f_6043:posixunix_scm",(void*)f_6043},
{"f_6010:posixunix_scm",(void*)f_6010},
{"f_5991:posixunix_scm",(void*)f_5991},
{"f_5995:posixunix_scm",(void*)f_5995},
{"f_5960:posixunix_scm",(void*)f_5960},
{"f_5984:posixunix_scm",(void*)f_5984},
{"f_5968:posixunix_scm",(void*)f_5968},
{"f_5971:posixunix_scm",(void*)f_5971},
{"f_5922:posixunix_scm",(void*)f_5922},
{"f_5955:posixunix_scm",(void*)f_5955},
{"f_5943:posixunix_scm",(void*)f_5943},
{"f_5951:posixunix_scm",(void*)f_5951},
{"f_5947:posixunix_scm",(void*)f_5947},
{"f_5903:posixunix_scm",(void*)f_5903},
{"f_5913:posixunix_scm",(void*)f_5913},
{"f_5907:posixunix_scm",(void*)f_5907},
{"f_5897:posixunix_scm",(void*)f_5897},
{"f_5891:posixunix_scm",(void*)f_5891},
{"f_5885:posixunix_scm",(void*)f_5885},
{"f_5861:posixunix_scm",(void*)f_5861},
{"f_5883:posixunix_scm",(void*)f_5883},
{"f_5879:posixunix_scm",(void*)f_5879},
{"f_5871:posixunix_scm",(void*)f_5871},
{"f_5831:posixunix_scm",(void*)f_5831},
{"f_5859:posixunix_scm",(void*)f_5859},
{"f_5855:posixunix_scm",(void*)f_5855},
{"f_5804:posixunix_scm",(void*)f_5804},
{"f_5829:posixunix_scm",(void*)f_5829},
{"f_5825:posixunix_scm",(void*)f_5825},
{"f_5740:posixunix_scm",(void*)f_5740},
{"f_5728:posixunix_scm",(void*)f_5728},
{"f_5756:posixunix_scm",(void*)f_5756},
{"f_5666:posixunix_scm",(void*)f_5666},
{"f_5670:posixunix_scm",(void*)f_5670},
{"f_5675:posixunix_scm",(void*)f_5675},
{"f_5691:posixunix_scm",(void*)f_5691},
{"f_5603:posixunix_scm",(void*)f_5603},
{"f_5661:posixunix_scm",(void*)f_5661},
{"f_5607:posixunix_scm",(void*)f_5607},
{"f_5610:posixunix_scm",(void*)f_5610},
{"f_5642:posixunix_scm",(void*)f_5642},
{"f_5613:posixunix_scm",(void*)f_5613},
{"f_5618:posixunix_scm",(void*)f_5618},
{"f_5632:posixunix_scm",(void*)f_5632},
{"f_5596:posixunix_scm",(void*)f_5596},
{"f_5510:posixunix_scm",(void*)f_5510},
{"f_5514:posixunix_scm",(void*)f_5514},
{"f_5568:posixunix_scm",(void*)f_5568},
{"f_5517:posixunix_scm",(void*)f_5517},
{"f_5527:posixunix_scm",(void*)f_5527},
{"f_5531:posixunix_scm",(void*)f_5531},
{"f_5540:posixunix_scm",(void*)f_5540},
{"f_5544:posixunix_scm",(void*)f_5544},
{"f_5554:posixunix_scm",(void*)f_5554},
{"f_5535:posixunix_scm",(void*)f_5535},
{"f_5485:posixunix_scm",(void*)f_5485},
{"f_5497:posixunix_scm",(void*)f_5497},
{"f_5493:posixunix_scm",(void*)f_5493},
{"f_5471:posixunix_scm",(void*)f_5471},
{"f_5483:posixunix_scm",(void*)f_5483},
{"f_5479:posixunix_scm",(void*)f_5479},
{"f_5404:posixunix_scm",(void*)f_5404},
{"f_5408:posixunix_scm",(void*)f_5408},
{"f_5450:posixunix_scm",(void*)f_5450},
{"f_5411:posixunix_scm",(void*)f_5411},
{"f_5421:posixunix_scm",(void*)f_5421},
{"f_5425:posixunix_scm",(void*)f_5425},
{"f_5429:posixunix_scm",(void*)f_5429},
{"f_5433:posixunix_scm",(void*)f_5433},
{"f_5437:posixunix_scm",(void*)f_5437},
{"f_5350:posixunix_scm",(void*)f_5350},
{"f_5383:posixunix_scm",(void*)f_5383},
{"f_5354:posixunix_scm",(void*)f_5354},
{"f_5361:posixunix_scm",(void*)f_5361},
{"f_5365:posixunix_scm",(void*)f_5365},
{"f_5369:posixunix_scm",(void*)f_5369},
{"f_5373:posixunix_scm",(void*)f_5373},
{"f_5377:posixunix_scm",(void*)f_5377},
{"f_5332:posixunix_scm",(void*)f_5332},
{"f_5317:posixunix_scm",(void*)f_5317},
{"f_5311:posixunix_scm",(void*)f_5311},
{"f_5279:posixunix_scm",(void*)f_5279},
{"f_5285:posixunix_scm",(void*)f_5285},
{"f_5255:posixunix_scm",(void*)f_5255},
{"f_5273:posixunix_scm",(void*)f_5273},
{"f_5262:posixunix_scm",(void*)f_5262},
{"f_5237:posixunix_scm",(void*)f_5237},
{"f_5247:posixunix_scm",(void*)f_5247},
{"f_5224:posixunix_scm",(void*)f_5224},
{"f_5215:posixunix_scm",(void*)f_5215},
{"f_5168:posixunix_scm",(void*)f_5168},
{"f_5172:posixunix_scm",(void*)f_5172},
{"f_5148:posixunix_scm",(void*)f_5148},
{"f_5152:posixunix_scm",(void*)f_5152},
{"f_5158:posixunix_scm",(void*)f_5158},
{"f_5162:posixunix_scm",(void*)f_5162},
{"f_5128:posixunix_scm",(void*)f_5128},
{"f_5132:posixunix_scm",(void*)f_5132},
{"f_5138:posixunix_scm",(void*)f_5138},
{"f_5142:posixunix_scm",(void*)f_5142},
{"f_5104:posixunix_scm",(void*)f_5104},
{"f_5108:posixunix_scm",(void*)f_5108},
{"f_5119:posixunix_scm",(void*)f_5119},
{"f_5123:posixunix_scm",(void*)f_5123},
{"f_5113:posixunix_scm",(void*)f_5113},
{"f_5080:posixunix_scm",(void*)f_5080},
{"f_5084:posixunix_scm",(void*)f_5084},
{"f_5095:posixunix_scm",(void*)f_5095},
{"f_5099:posixunix_scm",(void*)f_5099},
{"f_5089:posixunix_scm",(void*)f_5089},
{"f_5064:posixunix_scm",(void*)f_5064},
{"f_5068:posixunix_scm",(void*)f_5068},
{"f_5071:posixunix_scm",(void*)f_5071},
{"f_5028:posixunix_scm",(void*)f_5028},
{"f_5059:posixunix_scm",(void*)f_5059},
{"f_5049:posixunix_scm",(void*)f_5049},
{"f_5042:posixunix_scm",(void*)f_5042},
{"f_4992:posixunix_scm",(void*)f_4992},
{"f_5023:posixunix_scm",(void*)f_5023},
{"f_5013:posixunix_scm",(void*)f_5013},
{"f_5006:posixunix_scm",(void*)f_5006},
{"f_4977:posixunix_scm",(void*)f_4977},
{"f_4990:posixunix_scm",(void*)f_4990},
{"f_4971:posixunix_scm",(void*)f_4971},
{"f_4959:posixunix_scm",(void*)f_4959},
{"f_4642:posixunix_scm",(void*)f_4642},
{"f_4949:posixunix_scm",(void*)f_4949},
{"f_4769:posixunix_scm",(void*)f_4769},
{"f_4935:posixunix_scm",(void*)f_4935},
{"f_4924:posixunix_scm",(void*)f_4924},
{"f_4931:posixunix_scm",(void*)f_4931},
{"f_4788:posixunix_scm",(void*)f_4788},
{"f_4917:posixunix_scm",(void*)f_4917},
{"f_4896:posixunix_scm",(void*)f_4896},
{"f_4913:posixunix_scm",(void*)f_4913},
{"f_4902:posixunix_scm",(void*)f_4902},
{"f_4909:posixunix_scm",(void*)f_4909},
{"f_4832:posixunix_scm",(void*)f_4832},
{"f_4893:posixunix_scm",(void*)f_4893},
{"f_4872:posixunix_scm",(void*)f_4872},
{"f_4889:posixunix_scm",(void*)f_4889},
{"f_4878:posixunix_scm",(void*)f_4878},
{"f_4885:posixunix_scm",(void*)f_4885},
{"f_4845:posixunix_scm",(void*)f_4845},
{"f_4869:posixunix_scm",(void*)f_4869},
{"f_4865:posixunix_scm",(void*)f_4865},
{"f_4826:posixunix_scm",(void*)f_4826},
{"f_4795:posixunix_scm",(void*)f_4795},
{"f_4813:posixunix_scm",(void*)f_4813},
{"f_4798:posixunix_scm",(void*)f_4798},
{"f_4802:posixunix_scm",(void*)f_4802},
{"f_4782:posixunix_scm",(void*)f_4782},
{"f_4763:posixunix_scm",(void*)f_4763},
{"f_4649:posixunix_scm",(void*)f_4649},
{"f_4656:posixunix_scm",(void*)f_4656},
{"f_4658:posixunix_scm",(void*)f_4658},
{"f_4665:posixunix_scm",(void*)f_4665},
{"f_4729:posixunix_scm",(void*)f_4729},
{"f_4738:posixunix_scm",(void*)f_4738},
{"f_4726:posixunix_scm",(void*)f_4726},
{"f_4671:posixunix_scm",(void*)f_4671},
{"f_4707:posixunix_scm",(void*)f_4707},
{"f_4703:posixunix_scm",(void*)f_4703},
{"f_4699:posixunix_scm",(void*)f_4699},
{"f_4688:posixunix_scm",(void*)f_4688},
{"f_4684:posixunix_scm",(void*)f_4684},
{"f_4586:posixunix_scm",(void*)f_4586},
{"f_4595:posixunix_scm",(void*)f_4595},
{"f_4619:posixunix_scm",(void*)f_4619},
{"f_4631:posixunix_scm",(void*)f_4631},
{"f_4637:posixunix_scm",(void*)f_4637},
{"f_4625:posixunix_scm",(void*)f_4625},
{"f_4601:posixunix_scm",(void*)f_4601},
{"f_4607:posixunix_scm",(void*)f_4607},
{"f_4593:posixunix_scm",(void*)f_4593},
{"f_4575:posixunix_scm",(void*)f_4575},
{"f_4570:posixunix_scm",(void*)f_4570},
{"f_4522:posixunix_scm",(void*)f_4522},
{"f_4526:posixunix_scm",(void*)f_4526},
{"f_4535:posixunix_scm",(void*)f_4535},
{"f_4499:posixunix_scm",(void*)f_4499},
{"f_4520:posixunix_scm",(void*)f_4520},
{"f_4506:posixunix_scm",(void*)f_4506},
{"f_4342:posixunix_scm",(void*)f_4342},
{"f_4447:posixunix_scm",(void*)f_4447},
{"f_4455:posixunix_scm",(void*)f_4455},
{"f_4442:posixunix_scm",(void*)f_4442},
{"f_4344:posixunix_scm",(void*)f_4344},
{"f_4351:posixunix_scm",(void*)f_4351},
{"f_4354:posixunix_scm",(void*)f_4354},
{"f_4357:posixunix_scm",(void*)f_4357},
{"f_4441:posixunix_scm",(void*)f_4441},
{"f_4361:posixunix_scm",(void*)f_4361},
{"f_4375:posixunix_scm",(void*)f_4375},
{"f_4385:posixunix_scm",(void*)f_4385},
{"f_4388:posixunix_scm",(void*)f_4388},
{"f_4391:posixunix_scm",(void*)f_4391},
{"f_4397:posixunix_scm",(void*)f_4397},
{"f_4407:posixunix_scm",(void*)f_4407},
{"f_4318:posixunix_scm",(void*)f_4318},
{"f_4340:posixunix_scm",(void*)f_4340},
{"f_4336:posixunix_scm",(void*)f_4336},
{"f_4294:posixunix_scm",(void*)f_4294},
{"f_4316:posixunix_scm",(void*)f_4316},
{"f_4312:posixunix_scm",(void*)f_4312},
{"f_4159:posixunix_scm",(void*)f_4159},
{"f_4163:posixunix_scm",(void*)f_4163},
{"f_4257:posixunix_scm",(void*)f_4257},
{"f_4258:posixunix_scm",(void*)f_4258},
{"f_4273:posixunix_scm",(void*)f_4273},
{"f_4176:posixunix_scm",(void*)f_4176},
{"f_4177:posixunix_scm",(void*)f_4177},
{"f_4250:posixunix_scm",(void*)f_4250},
{"f_4183:posixunix_scm",(void*)f_4183},
{"f_4188:posixunix_scm",(void*)f_4188},
{"f_4192:posixunix_scm",(void*)f_4192},
{"f_4219:posixunix_scm",(void*)f_4219},
{"f_4226:posixunix_scm",(void*)f_4226},
{"f_4246:posixunix_scm",(void*)f_4246},
{"f_4199:posixunix_scm",(void*)f_4199},
{"f_4203:posixunix_scm",(void*)f_4203},
{"f_4218:posixunix_scm",(void*)f_4218},
{"f_4146:posixunix_scm",(void*)f_4146},
{"f_4153:posixunix_scm",(void*)f_4153},
{"f_4137:posixunix_scm",(void*)f_4137},
{"f_4144:posixunix_scm",(void*)f_4144},
{"f_4128:posixunix_scm",(void*)f_4128},
{"f_4135:posixunix_scm",(void*)f_4135},
{"f_4119:posixunix_scm",(void*)f_4119},
{"f_4126:posixunix_scm",(void*)f_4126},
{"f_4110:posixunix_scm",(void*)f_4110},
{"f_4117:posixunix_scm",(void*)f_4117},
{"f_4101:posixunix_scm",(void*)f_4101},
{"f_4108:posixunix_scm",(void*)f_4108},
{"f_4092:posixunix_scm",(void*)f_4092},
{"f_4099:posixunix_scm",(void*)f_4099},
{"f_4083:posixunix_scm",(void*)f_4083},
{"f_4090:posixunix_scm",(void*)f_4090},
{"f_4074:posixunix_scm",(void*)f_4074},
{"f_4081:posixunix_scm",(void*)f_4081},
{"f_4068:posixunix_scm",(void*)f_4068},
{"f_4072:posixunix_scm",(void*)f_4072},
{"f_4062:posixunix_scm",(void*)f_4062},
{"f_4066:posixunix_scm",(void*)f_4066},
{"f_4056:posixunix_scm",(void*)f_4056},
{"f_4060:posixunix_scm",(void*)f_4060},
{"f_4050:posixunix_scm",(void*)f_4050},
{"f_4054:posixunix_scm",(void*)f_4054},
{"f_4044:posixunix_scm",(void*)f_4044},
{"f_4048:posixunix_scm",(void*)f_4048},
{"f_4038:posixunix_scm",(void*)f_4038},
{"f_4042:posixunix_scm",(void*)f_4042},
{"f_4006:posixunix_scm",(void*)f_4006},
{"f_4017:posixunix_scm",(void*)f_4017},
{"f_4010:posixunix_scm",(void*)f_4010},
{"f_3969:posixunix_scm",(void*)f_3969},
{"f_4001:posixunix_scm",(void*)f_4001},
{"f_3994:posixunix_scm",(void*)f_3994},
{"f_3973:posixunix_scm",(void*)f_3973},
{"f_3777:posixunix_scm",(void*)f_3777},
{"f_3950:posixunix_scm",(void*)f_3950},
{"f_3793:posixunix_scm",(void*)f_3793},
{"f_3924:posixunix_scm",(void*)f_3924},
{"f_3799:posixunix_scm",(void*)f_3799},
{"f_3802:posixunix_scm",(void*)f_3802},
{"f_3884:posixunix_scm",(void*)f_3884},
{"f_3882:posixunix_scm",(void*)f_3882},
{"f_3841:posixunix_scm",(void*)f_3841},
{"f_3859:posixunix_scm",(void*)f_3859},
{"f_3857:posixunix_scm",(void*)f_3857},
{"f_3845:posixunix_scm",(void*)f_3845},
{"f_3767:posixunix_scm",(void*)f_3767},
{"f_3757:posixunix_scm",(void*)f_3757},
{"f_3751:posixunix_scm",(void*)f_3751},
{"f_3719:posixunix_scm",(void*)f_3719},
{"f_3726:posixunix_scm",(void*)f_3726},
{"f_3732:posixunix_scm",(void*)f_3732},
{"f_3739:posixunix_scm",(void*)f_3739},
{"f_3680:posixunix_scm",(void*)f_3680},
{"f_3687:posixunix_scm",(void*)f_3687},
{"f_3696:posixunix_scm",(void*)f_3696},
{"f_3638:posixunix_scm",(void*)f_3638},
{"f_3648:posixunix_scm",(void*)f_3648},
{"f_3651:posixunix_scm",(void*)f_3651},
{"f_3654:posixunix_scm",(void*)f_3654},
{"f_3623:posixunix_scm",(void*)f_3623},
{"f_3585:posixunix_scm",(void*)f_3585},
{"f_3615:posixunix_scm",(void*)f_3615},
{"f_3602:posixunix_scm",(void*)f_3602},
{"f_3605:posixunix_scm",(void*)f_3605},
{"f_3539:posixunix_scm",(void*)f_3539},
{"f_3543:posixunix_scm",(void*)f_3543},
{"f_3482:posixunix_scm",(void*)f_3482},
{"f_3475:posixunix_scm",(void*)f_3475},
{"f_3457:posixunix_scm",(void*)f_3457},
{"f_3461:posixunix_scm",(void*)f_3461},
{"f_3472:posixunix_scm",(void*)f_3472},
{"f_3468:posixunix_scm",(void*)f_3468},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
