/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-23 17:53
   Version 3.0.6 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 9498	compiled 2008-03-11 on tablet (Linux)
   command line: posixunix.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
#endif
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set_9(v) \
        (C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)))

#define C_tm_get_08(v) \
        (C_set_block_item(v, 0, C_fix(C_tm.tm_sec)), \
        C_set_block_item(v, 1, C_fix(C_tm.tm_min)), \
        C_set_block_item(v, 2, C_fix(C_tm.tm_hour)), \
        C_set_block_item(v, 3, C_fix(C_tm.tm_mday)), \
        C_set_block_item(v, 4, C_fix(C_tm.tm_mon)), \
        C_set_block_item(v, 5, C_fix(C_tm.tm_year)), \
        C_set_block_item(v, 6, C_fix(C_tm.tm_wday)), \
        C_set_block_item(v, 7, C_fix(C_tm.tm_yday)), \
        C_set_block_item(v, 8, (C_tm.tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define C_tm_get_9(v) \
        (C_set_block_item(v, 9, C_fix(C_tm.tm_gmtoff)))

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  return &C_tm;
}

static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  return v;
}

#else

static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  C_tm_set_9 (v);
  return &C_tm;
}

static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  C_tm_get_9 (v);
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[461];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,38),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,55,32,108,111,99,56,32,109,115,103,57,32,46,32,97,114,103,115,49,48,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,49,50,49,53,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,49,54,49,57,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,51,48,32,99,109,100,51,49,32,46,32,103,50,57,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,52,49,32,102,108,97,103,115,52,50,32,46,32,109,111,100,101,52,51,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,99,108,111,115,101,32,102,100,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,114,101,97,100,32,102,100,53,51,32,115,105,122,101,53,52,32,46,32,98,117,102,102,101,114,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,119,114,105,116,101,32,102,100,54,50,32,98,117,102,102,101,114,54,51,32,46,32,115,105,122,101,54,52,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,9),40,102,100,95,122,101,114,111,41,0,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,14),40,102,100,95,115,101,116,32,97,56,52,56,57,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,15),40,102,100,95,116,101,115,116,32,97,57,48,57,53,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,50,48,51,55,32,102,100,49,50,49,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,97,50,48,54,50,32,102,100,49,49,56,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,13),40,97,50,49,48,50,32,102,100,49,49,49,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,50,49,50,56,32,102,100,49,48,52,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,57,54,32,102,100,115,119,57,55,32,46,32,116,105,109,101,111,117,116,57,56,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,49,50,55,32,108,105,110,107,49,50,56,32,108,111,99,49,50,57,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,49,51,50,32,46,32,108,105,110,107,49,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,49,51,55,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,49,51,57,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,49,52,49,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,49,52,51,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,49,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,49,52,55,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,49,52,57,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,49,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,114,101,103,117,108,97,114,63,32,102,110,97,109,101,49,53,55,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,115,116,97,116,45,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,49,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,28),40,115,116,97,116,45,99,104,97,114,45,100,101,118,105,99,101,63,32,102,110,97,109,101,49,54,53,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,29),40,115,116,97,116,45,98,108,111,99,107,45,100,101,118,105,99,101,63,32,102,110,97,109,101,49,54,57,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,21),40,115,116,97,116,45,102,105,102,111,63,32,102,110,97,109,101,49,55,51,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,115,121,109,108,105,110,107,63,32,102,110,97,109,101,49,55,55,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,115,116,97,116,45,115,111,99,107,101,116,63,32,102,110,97,109,101,49,56,49,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,49,56,53,32,112,111,115,49,56,54,32,46,32,119,104,101,110,99,101,49,56,55,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,26),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,57,53,41,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,57,57,41,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,50,48,56,32,115,112,101,99,50,49,52,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,50,49,53,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,50,49,49,32,37,115,112,101,99,50,48,54,50,51,52,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,50,49,48,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,32,46,32,103,50,48,52,50,48,53,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,50,52,48,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,103,50,52,52,50,52,53,41,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,17),40,105,115,112,101,114,115,101,32,103,50,54,53,50,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,50,55,51,50,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,15),40,97,50,55,50,54,32,103,50,55,49,50,55,54,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,50,55,53,48,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,7),40,97,50,55,54,50,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,17),40,97,50,55,53,54,32,46,32,103,50,55,52,50,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,50,55,52,52,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,15),40,97,50,55,50,48,32,103,50,55,51,50,55,53,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,50,56,53,32,114,50,56,54,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,50,56,48,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,50,57,51,41,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,50,57,52,32,99,109,100,50,57,53,32,105,110,112,50,57,54,32,114,50,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,51,48,48,32,46,32,109,51,48,49,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,51,48,54,32,46,32,109,51,48,55,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,51,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,7),40,97,51,50,49,52,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,20),40,97,51,50,50,48,32,46,32,114,101,115,117,108,116,115,51,51,48,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,51,50,54,32,112,114,111,99,51,50,55,32,46,32,109,111,100,101,51,50,56,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,7),40,97,51,50,51,56,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,20),40,97,51,50,52,52,32,46,32,114,101,115,117,108,116,115,51,51,54,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,51,51,50,32,112,114,111,99,51,51,51,32,46,32,109,111,100,101,51,51,52,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,20),40,97,51,50,54,51,32,46,32,114,101,115,117,108,116,115,51,52,51,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,51,51,56,32,116,104,117,110,107,51,51,57,32,46,32,109,111,100,101,51,52,48,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,20),40,97,51,50,56,51,32,46,32,114,101,115,117,108,116,115,51,53,50,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,51,52,55,32,116,104,117,110,107,51,52,56,32,46,32,109,111,100,101,51,52,57,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,51,54,50,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,51,54,52,32,112,114,111,99,51,54,53,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,51,54,56,32,115,116,97,116,101,51,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,12),40,97,51,51,57,56,32,115,51,55,53,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,26),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,51,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,105,103,115,51,56,49,32,109,97,115,107,51,56,50,41,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,51,56,53,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,21),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,51,56,55,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,51,57,48,41,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,20),40,115,101,116,45,117,115,101,114,45,105,100,33,32,105,100,51,57,54,41,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,103,114,111,117,112,45,105,100,33,32,105,100,52,48,52,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,36),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,52,49,51,32,46,32,103,52,49,50,52,49,52,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,52,51,52,41,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,38),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,52,50,54,32,46,32,103,52,50,53,52,50,55,41,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,16),40,95,101,110,115,117,114,101,45,103,114,111,117,112,115,41};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,52,53,48,41,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,19),40,100,111,52,53,54,32,108,115,116,52,53,56,32,105,52,53,57,41,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,52,53,53,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,33),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,52,55,53,32,105,100,52,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,52,56,48,32,109,52,56,49,41};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,39),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,52,56,52,32,117,105,100,52,56,53,32,103,105,100,52,56,54,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,52,57,49,32,97,99,99,52,57,50,32,108,111,99,52,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,57,55,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,57,56,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,57,57,41,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,38),40,115,101,116,45,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,33,32,112,105,100,53,48,54,32,112,103,105,100,53,48,55,41,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,36),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,53,49,54,32,110,101,119,53,49,55,41,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,29),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,53,50,50,41,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,108,105,110,107,32,111,108,100,53,51,55,32,110,101,119,53,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,53,52,51,32,109,53,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,32),40,99,104,101,99,107,32,108,111,99,53,52,56,32,102,100,53,52,57,32,105,110,112,53,53,48,32,114,53,53,49,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,53,53,52,32,46,32,109,53,53,53,41,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,53,53,55,32,46,32,109,53,53,56,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,53,54,51,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,34),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,53,54,55,32,46,32,110,101,119,53,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,8),40,114,101,97,100,121,63,41};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,7),40,102,101,116,99,104,41,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,7),40,97,52,52,56,54,41,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,7),40,97,52,52,57,57,41,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,7),40,97,52,53,49,49,41,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,7),40,97,52,53,51,50,41,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,110,54,50,55,32,109,54,50,56,32,115,116,97,114,116,54,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,37),40,97,52,53,52,49,32,112,111,114,116,54,50,50,32,110,54,50,51,32,100,101,115,116,54,50,52,32,115,116,97,114,116,54,50,53,41,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,22),40,98,117,109,112,101,114,32,99,117,114,54,52,51,32,112,116,114,54,52,52,41,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,7),40,97,52,55,48,51,41,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,30),40,97,52,55,48,57,32,100,101,115,116,54,53,54,54,53,56,32,99,111,110,116,63,54,53,55,54,53,57,41,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,116,114,54,52,49,41,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,24),40,97,52,54,49,55,32,112,111,114,116,54,51,56,32,108,105,109,105,116,54,51,57,41};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,54),40,98,111,100,121,53,56,53,32,110,111,110,98,108,111,99,107,105,110,103,63,53,57,51,32,98,117,102,105,53,57,52,32,111,110,45,99,108,111,115,101,53,57,53,32,109,111,114,101,63,53,57,54,41,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,62),40,100,101,102,45,109,111,114,101,63,53,57,48,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,56,49,54,54,56,32,37,98,117,102,105,53,56,50,54,54,57,32,37,111,110,45,99,108,111,115,101,53,56,51,54,55,48,41,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,49),40,100,101,102,45,111,110,45,99,108,111,115,101,53,56,57,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,56,49,54,55,50,32,37,98,117,102,105,53,56,50,54,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,117,102,105,53,56,56,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,56,49,54,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,21),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,53,56,55,41,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,55),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,53,55,55,32,110,97,109,53,55,56,32,102,100,53,55,57,32,46,32,103,53,55,54,53,56,48,41,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,20),40,112,111,107,101,32,115,116,114,55,48,55,32,108,101,110,55,48,56,41,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,14),40,97,52,57,48,48,32,115,116,114,55,50,54,41,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,7),40,97,52,57,48,54,41,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,7),40,97,52,57,50,55,41,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,15),40,102,95,52,57,51,54,32,115,116,114,55,49,50,41,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,29),40,108,111,111,112,32,114,101,109,55,49,55,32,115,116,97,114,116,55,49,56,32,108,101,110,55,49,57,41,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,15),40,102,95,52,57,53,49,32,115,116,114,55,49,53,41,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,45),40,98,111,100,121,54,57,53,32,110,111,110,98,108,111,99,107,105,110,103,63,55,48,50,32,98,117,102,105,55,48,51,32,111,110,45,99,108,111,115,101,55,48,52,41,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,49),40,100,101,102,45,111,110,45,99,108,111,115,101,54,57,57,32,37,110,111,110,98,108,111,99,107,105,110,103,63,54,57,50,55,51,52,32,37,98,117,102,105,54,57,51,55,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,117,102,105,54,57,56,32,37,110,111,110,98,108,111,99,107,105,110,103,63,54,57,50,55,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,21),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,54,57,55,41,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,56),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,54,56,56,32,110,97,109,54,56,57,32,102,100,54,57,48,32,46,32,103,54,56,55,54,57,49,41};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,55,52,53,32,111,102,102,55,52,54,41,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,32,112,111,114,116,55,53,48,32,97,114,103,115,55,53,49,32,108,111,99,55,53,50,41,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,27),40,101,114,114,32,109,115,103,55,54,53,32,108,111,99,107,55,54,54,32,108,111,99,55,54,55,41,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,55,54,56,32,46,32,97,114,103,115,55,54,57,41,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,55,55,49,32,46,32,97,114,103,115,55,55,50,41,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,55,55,52,32,46,32,97,114,103,115,55,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,21),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,55,56,52,41,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,32),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,55,56,55,32,46,32,109,111,100,101,55,56,56,41};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,19),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,55,57,50,41,0,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,22),40,115,101,116,101,110,118,32,118,97,114,55,57,53,32,118,97,108,55,57,54,41,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,17),40,117,110,115,101,116,101,110,118,32,118,97,114,56,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,56,49,51,41,0,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,49,48,41,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,21),40,99,117,114,114,101,110,116,45,101,110,118,105,114,111,110,109,101,110,116,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,66),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,56,51,52,32,108,101,110,56,51,53,32,112,114,111,116,56,51,54,32,102,108,97,103,56,51,55,32,102,100,56,51,56,32,46,32,111,102,102,56,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,41),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,56,53,52,32,46,32,108,101,110,56,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,36),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,56,53,56,41,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,26),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,56,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,29),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,56,54,49,41,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,27),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,56,54,51,41,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,25),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,56,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,30),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,56,56,56,32,46,32,103,56,56,55,56,56,57,41,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,31),40,115,116,114,105,110,103,45,62,116,105,109,101,32,116,105,109,57,48,57,32,46,32,103,57,48,56,57,49,48,41,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,27),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,57,49,54,41,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,25),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,57,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,17),40,95,101,120,105,116,32,46,32,99,111,100,101,57,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,20),40,115,101,116,45,97,108,97,114,109,33,32,97,57,51,49,57,51,52,41,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,57,51,53,32,109,111,100,101,57,51,54,32,46,32,115,105,122,101,57,51,55,41,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,57,52,52,41};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,57,52,55,32,112,111,114,116,57,52,56,41};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,23),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,57,53,54,41,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,23),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,57,54,55,41,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,7),40,97,54,49,48,57,41,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,49,48,48,55,41,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,37),40,97,54,49,49,53,32,100,105,114,57,57,50,57,57,53,32,102,105,108,57,57,51,57,57,54,32,101,120,116,57,57,52,57,57,55,41,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,20),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,57,57,48,41,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,17),40,103,108,111,98,32,46,32,112,97,116,104,115,57,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,18),40,102,95,54,50,50,55,32,97,49,48,50,48,49,48,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,49,48,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,28),40,115,101,116,97,114,103,32,97,49,48,51,49,49,48,51,55,32,97,49,48,51,48,49,48,51,56,41,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,28),40,115,101,116,101,110,118,32,97,49,48,52,51,49,48,52,57,32,97,49,48,52,50,49,48,53,48,41,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,14),40,100,111,49,48,55,50,32,105,49,48,55,53,41,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,21),40,100,111,49,48,54,56,32,97,108,49,48,55,48,32,105,49,48,55,49,41,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,49,48,53,57,32,97,114,103,108,105,115,116,49,48,54,53,32,101,110,118,108,105,115,116,49,48,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,34),40,100,101,102,45,101,110,118,108,105,115,116,49,48,54,50,32,37,97,114,103,108,105,115,116,49,48,53,55,49,48,57,53,41,0,0,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,97,114,103,108,105,115,116,49,48,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,42),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,49,48,53,53,32,46,32,103,49,48,53,52,49,48,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,49,48,49,32,110,111,104,97,110,103,49,49,48,50,41,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,7),40,97,54,53,48,57,41,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,36),40,97,54,53,49,53,32,101,112,105,100,49,49,49,55,32,101,110,111,114,109,49,49,49,56,32,101,99,111,100,101,49,49,49,57,41,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,49,49,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,49,49,50,53,49,49,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,49,49,50,57,32,46,32,115,105,103,49,49,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,49,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,49,52,49,32,46,32,97,114,103,115,49,49,52,50,41,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,7),40,97,54,54,56,53,41,0};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,29),40,97,54,54,57,49,32,95,49,49,54,54,32,102,108,103,49,49,54,55,32,99,111,100,49,49,54,56,41,0,0,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,8),40,102,95,54,54,55,49,41};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,111,110,45,99,108,111,115,101,32,108,111,99,49,49,54,48,32,112,105,100,49,49,54,49,32,99,108,115,118,101,99,49,49,54,50,32,105,100,120,49,49,54,51,32,105,100,120,97,49,49,54,52,32,105,100,120,98,49,49,54,53,41,0,0,0,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,7),40,97,54,55,49,52,41,0};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,19),40,97,54,55,50,48,32,105,49,49,55,50,32,111,49,49,55,51,41,0,0,0,0,0};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,101,100,45,112,105,112,101,32,112,111,114,116,49,49,55,49,41,0,0};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,34),40,99,111,110,110,101,99,116,45,112,97,114,101,110,116,32,112,105,112,101,49,49,55,53,32,112,111,114,116,49,49,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,43),40,99,111,110,110,101,99,116,45,99,104,105,108,100,32,112,105,112,101,49,49,56,50,32,112,111,114,116,49,49,56,51,32,115,116,100,102,100,49,49,56,52,41,0,0,0,0,0};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,14),40,115,119,97,112,112,101,100,45,101,110,100,115,41,0,0};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,7),40,97,54,55,57,53,41,0};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,67),40,115,112,97,119,110,32,99,109,100,49,49,57,52,32,97,114,103,115,49,49,57,53,32,101,110,118,49,49,57,54,32,115,116,100,111,117,116,102,49,49,57,55,32,115,116,100,105,110,102,49,49,57,56,32,115,116,100,101,114,114,102,49,49,57,57,41,0,0,0,0,0};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,59),40,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,50,48,54,32,99,109,100,49,50,48,56,32,112,105,112,101,49,50,48,57,32,115,116,100,102,49,50,49,48,32,111,110,45,99,108,111,115,101,49,50,49,50,41,0,0,0,0,0};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,60),40,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,50,49,52,32,99,109,100,49,50,49,54,32,112,105,112,101,49,50,49,55,32,115,116,100,102,49,50,49,56,32,111,110,45,99,108,111,115,101,49,50,50,48,41,0,0,0,0};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,7),40,97,54,56,52,53,41,0};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,50),40,97,54,56,53,49,32,105,110,112,105,112,101,49,50,50,57,32,111,117,116,112,105,112,101,49,50,51,48,32,101,114,114,112,105,112,101,49,50,51,49,32,112,105,100,49,50,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,49,50,50,50,32,99,109,100,49,50,50,51,32,97,114,103,115,49,50,50,52,32,101,110,118,49,50,50,53,32,115,116,100,111,117,116,102,49,50,50,54,32,115,116,100,105,110,102,49,50,50,55,32,115,116,100,101,114,114,102,49,50,50,56,41,0,0,0,0,0};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,17),40,97,54,57,49,52,32,103,49,50,52,50,49,50,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,49,50,52,49,41,0,0,0,0,0};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,7),40,97,54,57,51,50,41,0};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,38),40,97,54,57,51,56,32,105,110,49,50,52,54,32,111,117,116,49,50,52,55,32,112,105,100,49,50,52,56,32,101,114,114,49,50,52,57,41,0,0};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,52),40,37,112,114,111,99,101,115,115,32,108,111,99,49,50,51,53,32,101,114,114,63,49,50,51,54,32,99,109,100,49,50,51,55,32,97,114,103,115,49,50,51,56,32,101,110,118,49,50,51,57,41,0,0,0,0};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,49,50,53,56,32,97,114,103,115,49,50,54,52,32,101,110,118,49,50,54,53,41,0,0,0,0,0};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,50,54,49,32,37,97,114,103,115,49,50,53,54,49,50,54,55,41,0,0,0,0,0};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,50,54,48,41,0,0};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,29),40,112,114,111,99,101,115,115,32,99,109,100,49,50,53,52,32,46,32,103,49,50,53,51,49,50,53,53,41,0,0,0};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,49,50,55,56,32,97,114,103,115,49,50,56,52,32,101,110,118,49,50,56,53,41,0,0,0,0,0};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,50,56,49,32,37,97,114,103,115,49,50,55,54,49,50,56,55,41,0,0,0,0,0};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,50,56,48,41,0,0};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,42,32,99,109,100,49,50,55,52,32,46,32,103,49,50,55,51,49,50,55,53,41,0,0};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,14),40,102,95,55,50,51,52,32,120,49,51,50,49,41,0,0};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,7),40,97,55,49,53,49,41,0};
static C_char C_TLS li239[] C_aligned={C_lihdr(0,0,7),40,97,55,49,53,57,41,0};
static C_char C_TLS li240[] C_aligned={C_lihdr(0,0,7),40,97,55,49,56,51,41,0};
static C_char C_TLS li241[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,49,51,50,51,32,114,49,51,50,52,41,0,0,0,0,0};
static C_char C_TLS li242[] C_aligned={C_lihdr(0,0,16),40,102,95,55,50,53,51,32,46,32,95,49,51,49,55,41};
static C_char C_TLS li243[] C_aligned={C_lihdr(0,0,16),40,102,95,55,50,52,53,32,46,32,95,49,51,49,54,41};
static C_char C_TLS li244[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,51,48,52,32,97,99,116,105,111,110,49,51,49,49,32,105,100,49,51,49,50,32,108,105,109,105,116,49,51,49,51,41,0,0};
static C_char C_TLS li245[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,49,51,48,56,32,37,97,99,116,105,111,110,49,51,48,49,49,51,51,56,32,37,105,100,49,51,48,50,49,51,51,57,41,0,0,0,0,0};
static C_char C_TLS li246[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,49,51,48,55,32,37,97,99,116,105,111,110,49,51,48,49,49,51,52,49,41,0,0,0,0};
static C_char C_TLS li247[] C_aligned={C_lihdr(0,0,19),40,97,55,50,55,51,32,120,49,51,52,51,32,121,49,51,52,52,41,0,0,0,0,0};
static C_char C_TLS li248[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,49,51,48,54,41};
static C_char C_TLS li249[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,49,50,57,56,32,112,114,101,100,49,50,57,57,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,49,51,48,48,41,0,0,0,0,0};
static C_char C_TLS li250[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,49,51,53,56,41,0,0,0};
static C_char C_TLS li251[] C_aligned={C_lihdr(0,0,14),40,97,55,51,55,50,32,112,105,100,53,49,49,41,0,0};
static C_char C_TLS li252[] C_aligned={C_lihdr(0,0,7),40,97,55,51,57,48,41,0};
static C_char C_TLS li253[] C_aligned={C_lihdr(0,0,13),40,97,55,51,57,51,32,105,100,52,49,48,41,0,0,0};
static C_char C_TLS li254[] C_aligned={C_lihdr(0,0,7),40,97,55,52,48,56,41,0};
static C_char C_TLS li255[] C_aligned={C_lihdr(0,0,7),40,97,55,52,49,49,41,0};
static C_char C_TLS li256[] C_aligned={C_lihdr(0,0,13),40,97,55,52,49,52,32,105,100,52,48,50,41,0,0,0};
static C_char C_TLS li257[] C_aligned={C_lihdr(0,0,7),40,97,55,52,50,57,41,0};
static C_char C_TLS li258[] C_aligned={C_lihdr(0,0,12),40,97,55,52,51,50,32,110,51,57,51,41,0,0,0,0};
static C_char C_TLS li259[] C_aligned={C_lihdr(0,0,15),40,97,55,52,51,56,32,112,111,114,116,49,57,50,41,0};
static C_char C_TLS li260[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k7340 in set-root-directory! in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub1353(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1353(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k6567 */
static C_word C_fcall stub1126(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1126(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub1123(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1123(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub1121(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1121(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub1052(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1052(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k6273 */
static C_word C_fcall stub1045(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1045(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub1040(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1040(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k6254 */
static C_word C_fcall stub1033(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1033(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k6230 */
static C_word C_fcall stub1021(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1021(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub1016(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1016(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub976(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub976(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k6039 */
static C_word C_fcall stub962(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub962(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k6016 */
static C_word C_fcall stub952(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub952(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k5905 */
static C_word C_fcall stub932(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub932(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k5883 */
static C_word C_fcall stub927(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub927(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub922(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub922(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub903(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub903(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub882(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub882(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub876(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub876(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k5654 */
static C_word C_fcall stub867(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub867(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k5573 */
static C_word C_fcall stub848(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub848(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k5511 */
static C_word C_fcall stub823(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub823(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k5411 */
static C_word C_fcall stub805(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub805(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k4170 in k4166 in file-link in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub529(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub529(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k3886 */
static C_word C_fcall stub469(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub469(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k3755 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub442(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub442(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from k3748 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub438(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub438(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from k3662 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub421(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub421(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a7390 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub408(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub408(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a7408 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub406(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub406(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a7411 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub400(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub400(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a7429 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall stub398(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub398(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k1953 */
static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k1943 */
static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k1933 */
static C_word C_fcall stub81(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub81(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k1715 */
static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from k1664 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub17(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub17(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from k1657 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub13(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub13(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k1633 */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1615)
static void C_ccall f_1615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7439)
static void C_ccall f_7439(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7455)
static void C_ccall f_7455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7443)
static void C_ccall f_7443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7446)
static void C_ccall f_7446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7433)
static void C_ccall f_7433(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7430)
static void C_ccall f_7430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7415)
static void C_ccall f_7415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7425)
static void C_ccall f_7425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7412)
static void C_ccall f_7412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7409)
static void C_ccall f_7409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3554)
static void C_ccall f_3554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7394)
static void C_ccall f_7394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7391)
static void C_ccall f_7391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7386)
static void C_ccall f_7386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7380)
static void C_ccall f_7380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7350)
static void C_ccall f_7350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7342)
static void C_ccall f_7342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7085)
static void C_ccall f_7085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7085)
static void C_ccall f_7085r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7268)
static void C_fcall f_7268(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7274)
static void C_ccall f_7274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7263)
static void C_fcall f_7263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7258)
static void C_fcall f_7258(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7087)
static void C_fcall f_7087(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7245)
static void C_ccall f_7245(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7094)
static void C_fcall f_7094(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7233)
static void C_ccall f_7233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7227)
static void C_ccall f_7227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7104)
static void C_ccall f_7104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_fcall f_7106(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7213)
static void C_ccall f_7213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7220)
static void C_ccall f_7220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7207)
static void C_ccall f_7207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7200)
static void C_ccall f_7200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7197)
static void C_ccall f_7197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7184)
static void C_ccall f_7184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7168)
static void C_ccall f_7168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7175)
static void C_ccall f_7175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7172)
static void C_ccall f_7172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7150)
static void C_ccall f_7150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7234)
static void C_ccall f_7234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7037)
static void C_fcall f_7037(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7032)
static void C_fcall f_7032(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7027)
static void C_fcall f_7027(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6965)
static void C_ccall f_6965(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6965)
static void C_ccall f_6965r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6977)
static void C_fcall f_6977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6972)
static void C_fcall f_6972(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6967)
static void C_fcall f_6967(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6904)
static void C_fcall f_6904(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6925)
static void C_ccall f_6925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6928)
static void C_ccall f_6928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6939)
static void C_ccall f_6939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_fcall f_6906(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6840)
static void C_ccall f_6840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6871)
static void C_ccall f_6871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6846)
static void C_ccall f_6846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6829)
static void C_fcall f_6829(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6833)
static void C_ccall f_6833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6818)
static void C_fcall f_6818(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6773)
static void C_fcall f_6773(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6783)
static void C_ccall f_6783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6796)
static void C_ccall f_6796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6806)
static void C_ccall f_6806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6757)
static C_word C_fcall f_6757(C_word *a,C_word t0);
C_noret_decl(f_6740)
static void C_fcall f_6740(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6726)
static void C_fcall f_6726(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6739)
static void C_ccall f_6739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6706)
static void C_fcall f_6706(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6721)
static void C_ccall f_6721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6669)
static void C_fcall f_6669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_6671)
static void C_ccall f_6671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6692)
static void C_ccall f_6692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6620)
static void C_ccall f_6620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6602)
static void C_ccall f_6602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6564)
static void C_ccall f_6564(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6558)
static void C_ccall f_6558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6516)
static void C_ccall f_6516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6510)
static void C_ccall f_6510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6415)
static void C_fcall f_6415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6410)
static void C_fcall f_6410(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6283)
static void C_fcall f_6283(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6293)
static void C_ccall f_6293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_fcall f_6301(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6347)
static C_word C_fcall f_6347(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6314)
static void C_fcall f_6314(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static C_word C_fcall f_6262(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6243)
static C_word C_fcall f_6243(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6201)
static void C_ccall f_6201(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6201)
static void C_ccall f_6201r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6223)
static void C_ccall f_6223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6095)
static void C_fcall f_6095(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6120)
static void C_ccall f_6120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6126)
static void C_ccall f_6126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6135)
static void C_fcall f_6135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6084)
static void C_ccall f_6084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6042)
static void C_ccall f_6042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6046)
static void C_ccall f_6046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6066)
static void C_ccall f_6066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6019)
static void C_ccall f_6019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static void C_fcall f_5987(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5972)
static void C_ccall f_5972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5909)
static void C_ccall f_5909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5909)
static void C_ccall f_5909r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5874)
static void C_ccall f_5874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5772)
static void C_ccall f_5772(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5772)
static void C_ccall f_5772r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5722)
static void C_ccall f_5722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5719)
static void C_ccall f_5719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5709)
static void C_ccall f_5709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5661)
static void C_ccall f_5661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5629)
static void C_ccall f_5629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_fcall f_5420(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_fcall f_5432(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5315)
static void C_fcall f_5315(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5232)
static void C_ccall f_5232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_fcall f_5210(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5136)
static void C_fcall f_5136(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_fcall f_5164(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5121)
static void C_ccall f_5121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5034)
static void C_fcall f_5034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_fcall f_5029(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5024)
static void C_fcall f_5024(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4840)
static void C_fcall f_4840(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4968)
static void C_fcall f_4968(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4892)
static void C_fcall f_4892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_fcall f_4846(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4760)
static void C_fcall f_4760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_fcall f_4755(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4750)
static void C_fcall f_4750(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4745)
static void C_fcall f_4745(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4366)
static void C_fcall f_4366(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4624)
static void C_fcall f_4624(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4550)
static void C_fcall f_4550(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_fcall f_4552(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4600)
static void C_ccall f_4600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_fcall f_4400(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_fcall f_4412(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static C_word C_fcall f_4392(C_word t0);
C_noret_decl(f_4377)
static void C_fcall f_4377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4344)
static void C_fcall f_4344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_fcall f_4249(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_fcall f_4212(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4017)
static void C_fcall f_4017(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3831)
static void C_fcall f_3831(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3766)
static void C_ccall f_3766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_fcall f_3774(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3752)
static C_word C_fcall f_3752(C_word t0);
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_fcall f_3673(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_fcall f_3696(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3635)
static void C_ccall f_3635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_fcall f_3567(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_fcall f_3411(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3254)
static void C_ccall f_3254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3254)
static void C_ccall f_3254r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_fcall f_3103(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_fcall f_3097(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static C_word C_fcall f_3085(C_word t0);
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_fcall f_2895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_fcall f_2914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_fcall f_2958(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_fcall f_2784(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_fcall f_2852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_fcall f_2712(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static C_word C_fcall f_2701(C_word t0);
C_noret_decl(f_2696)
static void C_fcall f_2696(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_ccall f_2468(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2468)
static void C_ccall f_2468r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2573)
static void C_fcall f_2573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_fcall f_2568(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2470)
static void C_fcall f_2470(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_fcall f_2501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_fcall f_2523(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_fcall f_2148(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_fcall f_1981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_fcall f_2020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_fcall f_2024(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static C_word C_fcall f_1946(C_word t0,C_word t1);
C_noret_decl(f_1936)
static C_word C_fcall f_1936(C_word t0,C_word t1);
C_noret_decl(f_1930)
static C_word C_fcall f_1930(C_word t0);
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_7268)
static void C_fcall trf_7268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7268(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7268(t0,t1);}

C_noret_decl(trf_7263)
static void C_fcall trf_7263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7263(t0,t1,t2);}

C_noret_decl(trf_7258)
static void C_fcall trf_7258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7258(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7258(t0,t1,t2,t3);}

C_noret_decl(trf_7087)
static void C_fcall trf_7087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7087(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7087(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7094)
static void C_fcall trf_7094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7094(t0,t1);}

C_noret_decl(trf_7106)
static void C_fcall trf_7106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7106(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7106(t0,t1,t2,t3);}

C_noret_decl(trf_7037)
static void C_fcall trf_7037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7037(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7037(t0,t1);}

C_noret_decl(trf_7032)
static void C_fcall trf_7032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7032(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7032(t0,t1,t2);}

C_noret_decl(trf_7027)
static void C_fcall trf_7027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7027(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7027(t0,t1,t2,t3);}

C_noret_decl(trf_6977)
static void C_fcall trf_6977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6977(t0,t1);}

C_noret_decl(trf_6972)
static void C_fcall trf_6972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6972(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6972(t0,t1,t2);}

C_noret_decl(trf_6967)
static void C_fcall trf_6967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6967(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6967(t0,t1,t2,t3);}

C_noret_decl(trf_6904)
static void C_fcall trf_6904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6904(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6904(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6906)
static void C_fcall trf_6906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6906(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6906(t0,t1,t2);}

C_noret_decl(trf_6829)
static void C_fcall trf_6829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6829(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6829(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6818)
static void C_fcall trf_6818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6818(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6818(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6773)
static void C_fcall trf_6773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6773(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6773(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6740)
static void C_fcall trf_6740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6740(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6740(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6726)
static void C_fcall trf_6726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6726(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6726(t0,t1,t2,t3);}

C_noret_decl(trf_6706)
static void C_fcall trf_6706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6706(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6706(t0,t1,t2);}

C_noret_decl(trf_6669)
static void C_fcall trf_6669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6669(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6669(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6415)
static void C_fcall trf_6415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6415(t0,t1);}

C_noret_decl(trf_6410)
static void C_fcall trf_6410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6410(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6410(t0,t1,t2);}

C_noret_decl(trf_6283)
static void C_fcall trf_6283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6283(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6283(t0,t1,t2,t3);}

C_noret_decl(trf_6301)
static void C_fcall trf_6301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6301(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6301(t0,t1,t2,t3);}

C_noret_decl(trf_6314)
static void C_fcall trf_6314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6314(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6314(t0,t1);}

C_noret_decl(trf_6095)
static void C_fcall trf_6095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6095(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6095(t0,t1,t2);}

C_noret_decl(trf_6135)
static void C_fcall trf_6135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6135(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6135(t0,t1,t2);}

C_noret_decl(trf_5987)
static void C_fcall trf_5987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5987(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5987(t0,t1,t2);}

C_noret_decl(trf_5420)
static void C_fcall trf_5420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5420(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5420(t0,t1,t2);}

C_noret_decl(trf_5432)
static void C_fcall trf_5432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5432(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5432(t0,t1,t2);}

C_noret_decl(trf_5315)
static void C_fcall trf_5315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5315(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5315(t0,t1);}

C_noret_decl(trf_5210)
static void C_fcall trf_5210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5210(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5210(t0,t1,t2,t3);}

C_noret_decl(trf_5136)
static void C_fcall trf_5136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5136(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5136(t0,t1,t2,t3);}

C_noret_decl(trf_5164)
static void C_fcall trf_5164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5164(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5164(t0,t1);}

C_noret_decl(trf_5034)
static void C_fcall trf_5034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5034(t0,t1);}

C_noret_decl(trf_5029)
static void C_fcall trf_5029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5029(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5029(t0,t1,t2);}

C_noret_decl(trf_5024)
static void C_fcall trf_5024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5024(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5024(t0,t1,t2,t3);}

C_noret_decl(trf_4840)
static void C_fcall trf_4840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4840(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4840(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4968)
static void C_fcall trf_4968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4968(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4968(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4892)
static void C_fcall trf_4892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4892(t0,t1);}

C_noret_decl(trf_4846)
static void C_fcall trf_4846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4846(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4846(t0,t1,t2,t3);}

C_noret_decl(trf_4760)
static void C_fcall trf_4760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4760(t0,t1);}

C_noret_decl(trf_4755)
static void C_fcall trf_4755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4755(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4755(t0,t1,t2);}

C_noret_decl(trf_4750)
static void C_fcall trf_4750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4750(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4750(t0,t1,t2,t3);}

C_noret_decl(trf_4745)
static void C_fcall trf_4745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4745(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4745(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4366)
static void C_fcall trf_4366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4366(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4366(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4624)
static void C_fcall trf_4624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4624(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4624(t0,t1,t2);}

C_noret_decl(trf_4550)
static void C_fcall trf_4550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4550(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4550(t0,t1);}

C_noret_decl(trf_4552)
static void C_fcall trf_4552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4552(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4552(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4400)
static void C_fcall trf_4400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4400(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4400(t0,t1);}

C_noret_decl(trf_4412)
static void C_fcall trf_4412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4412(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4412(t0,t1);}

C_noret_decl(trf_4377)
static void C_fcall trf_4377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4377(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4377(t0,t1);}

C_noret_decl(trf_4344)
static void C_fcall trf_4344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4344(t0,t1);}

C_noret_decl(trf_4249)
static void C_fcall trf_4249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4249(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4249(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4212)
static void C_fcall trf_4212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4212(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4212(t0,t1,t2);}

C_noret_decl(trf_4017)
static void C_fcall trf_4017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4017(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4017(t0,t1,t2,t3);}

C_noret_decl(trf_3831)
static void C_fcall trf_3831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3831(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3831(t0,t1,t2,t3);}

C_noret_decl(trf_3774)
static void C_fcall trf_3774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3774(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3774(t0,t1,t2);}

C_noret_decl(trf_3673)
static void C_fcall trf_3673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3673(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3673(t0,t1);}

C_noret_decl(trf_3696)
static void C_fcall trf_3696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3696(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3696(t0,t1,t2);}

C_noret_decl(trf_3567)
static void C_fcall trf_3567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3567(t0,t1);}

C_noret_decl(trf_3411)
static void C_fcall trf_3411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3411(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3411(t0,t1,t2,t3);}

C_noret_decl(trf_3103)
static void C_fcall trf_3103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3103(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3103(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3097)
static void C_fcall trf_3097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3097(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3097(t0,t1);}

C_noret_decl(trf_2895)
static void C_fcall trf_2895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2895(t0,t1);}

C_noret_decl(trf_2914)
static void C_fcall trf_2914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2914(t0,t1);}

C_noret_decl(trf_2958)
static void C_fcall trf_2958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2958(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2958(t0,t1);}

C_noret_decl(trf_2784)
static void C_fcall trf_2784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2784(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2784(t0,t1,t2,t3);}

C_noret_decl(trf_2852)
static void C_fcall trf_2852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2852(t0,t1);}

C_noret_decl(trf_2712)
static void C_fcall trf_2712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2712(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2712(t0,t1);}

C_noret_decl(trf_2696)
static void C_fcall trf_2696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2696(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2696(t0,t1);}

C_noret_decl(trf_2573)
static void C_fcall trf_2573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2573(t0,t1);}

C_noret_decl(trf_2568)
static void C_fcall trf_2568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2568(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2568(t0,t1,t2);}

C_noret_decl(trf_2470)
static void C_fcall trf_2470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2470(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2470(t0,t1,t2,t3);}

C_noret_decl(trf_2501)
static void C_fcall trf_2501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2501(t0,t1);}

C_noret_decl(trf_2523)
static void C_fcall trf_2523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2523(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2523(t0,t1);}

C_noret_decl(trf_2148)
static void C_fcall trf_2148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2148(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2148(t0,t1,t2,t3);}

C_noret_decl(trf_1981)
static void C_fcall trf_1981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1981(t0,t1);}

C_noret_decl(trf_2020)
static void C_fcall trf_2020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2020(t0,t1);}

C_noret_decl(trf_2024)
static void C_fcall trf_2024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2024(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2024(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3340)){
C_save(t1);
C_rereclaim2(3340*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,461);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_h_intern(&lf[51],9,"file-open");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[53]=C_h_intern(&lf[53],17,"\003sysmake-c-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysexpand-home-path");
lf[55]=C_h_intern(&lf[55],10,"file-close");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],10,"file-write");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[65]=C_h_intern(&lf[65],12,"file-mkstemp");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[68]=C_h_intern(&lf[68],11,"file-select");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[70]=C_h_intern(&lf[70],12,"\003sysfor-each");
lf[71]=C_h_intern(&lf[71],8,"seek/set");
lf[72]=C_h_intern(&lf[72],8,"seek/end");
lf[73]=C_h_intern(&lf[73],8,"seek/cur");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[77]=C_h_intern(&lf[77],9,"file-stat");
lf[78]=C_h_intern(&lf[78],9,"file-size");
lf[79]=C_h_intern(&lf[79],22,"file-modification-time");
lf[80]=C_h_intern(&lf[80],16,"file-access-time");
lf[81]=C_h_intern(&lf[81],16,"file-change-time");
lf[82]=C_h_intern(&lf[82],10,"file-owner");
lf[83]=C_h_intern(&lf[83],16,"file-permissions");
lf[84]=C_h_intern(&lf[84],13,"regular-file\077");
lf[85]=C_h_intern(&lf[85],14,"symbolic-link\077");
lf[86]=C_h_intern(&lf[86],13,"stat-regular\077");
lf[87]=C_h_intern(&lf[87],15,"stat-directory\077");
lf[88]=C_h_intern(&lf[88],17,"stat-char-device\077");
lf[89]=C_h_intern(&lf[89],18,"stat-block-device\077");
lf[90]=C_h_intern(&lf[90],10,"stat-fifo\077");
lf[91]=C_h_intern(&lf[91],13,"stat-symlink\077");
lf[92]=C_h_intern(&lf[92],12,"stat-socket\077");
lf[93]=C_h_intern(&lf[93],18,"set-file-position!");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[95]=C_h_intern(&lf[95],6,"stream");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[97]=C_h_intern(&lf[97],5,"port\077");
lf[98]=C_h_intern(&lf[98],13,"\000bounds-error");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[100]=C_h_intern(&lf[100],13,"file-position");
lf[101]=C_h_intern(&lf[101],16,"create-directory");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[103]=C_h_intern(&lf[103],16,"change-directory");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[105]=C_h_intern(&lf[105],16,"delete-directory");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[107]=C_h_intern(&lf[107],10,"string-ref");
lf[108]=C_h_intern(&lf[108],6,"string");
lf[109]=C_h_intern(&lf[109],9,"directory");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[111]=C_h_intern(&lf[111],16,"\003sysmake-pointer");
lf[112]=C_h_intern(&lf[112],17,"current-directory");
lf[113]=C_h_intern(&lf[113],10,"directory\077");
lf[114]=C_h_intern(&lf[114],13,"\003sysfile-info");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[116]=C_h_intern(&lf[116],5,"null\077");
lf[117]=C_h_intern(&lf[117],6,"char=\077");
lf[118]=C_h_intern(&lf[118],8,"string=\077");
lf[119]=C_h_intern(&lf[119],16,"char-alphabetic\077");
lf[120]=C_h_intern(&lf[120],18,"string-intersperse");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[122]=C_h_intern(&lf[122],6,"getenv");
lf[123]=C_h_intern(&lf[123],17,"current-user-name");
lf[124]=C_h_intern(&lf[124],9,"condition");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[126]=C_h_intern(&lf[126],22,"with-exception-handler");
lf[127]=C_h_intern(&lf[127],30,"call-with-current-continuation");
lf[128]=C_h_intern(&lf[128],14,"canonical-path");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[132]=C_h_intern(&lf[132],7,"reverse");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[136]=C_h_intern(&lf[136],12,"string-split");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[144]=C_h_intern(&lf[144],5,"\000text");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[147]=C_h_intern(&lf[147],13,"\003sysmake-port");
lf[148]=C_h_intern(&lf[148],21,"\003sysstream-port-class");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[150]=C_h_intern(&lf[150],15,"open-input-pipe");
lf[151]=C_h_intern(&lf[151],7,"\000binary");
lf[152]=C_h_intern(&lf[152],16,"open-output-pipe");
lf[153]=C_h_intern(&lf[153],16,"close-input-pipe");
lf[154]=C_h_intern(&lf[154],23,"close-input/output-pipe");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[156]=C_h_intern(&lf[156],14,"\003syscheck-port");
lf[157]=C_h_intern(&lf[157],17,"close-output-pipe");
lf[158]=C_h_intern(&lf[158],20,"call-with-input-pipe");
lf[159]=C_h_intern(&lf[159],21,"call-with-output-pipe");
lf[160]=C_h_intern(&lf[160],20,"with-input-from-pipe");
lf[161]=C_h_intern(&lf[161],18,"\003sysstandard-input");
lf[162]=C_h_intern(&lf[162],19,"with-output-to-pipe");
lf[163]=C_h_intern(&lf[163],19,"\003sysstandard-output");
lf[164]=C_h_intern(&lf[164],11,"create-pipe");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[166]=C_h_intern(&lf[166],11,"signal/term");
lf[167]=C_h_intern(&lf[167],11,"signal/kill");
lf[168]=C_h_intern(&lf[168],10,"signal/int");
lf[169]=C_h_intern(&lf[169],10,"signal/hup");
lf[170]=C_h_intern(&lf[170],10,"signal/fpe");
lf[171]=C_h_intern(&lf[171],10,"signal/ill");
lf[172]=C_h_intern(&lf[172],11,"signal/segv");
lf[173]=C_h_intern(&lf[173],11,"signal/abrt");
lf[174]=C_h_intern(&lf[174],11,"signal/trap");
lf[175]=C_h_intern(&lf[175],11,"signal/quit");
lf[176]=C_h_intern(&lf[176],11,"signal/alrm");
lf[177]=C_h_intern(&lf[177],13,"signal/vtalrm");
lf[178]=C_h_intern(&lf[178],11,"signal/prof");
lf[179]=C_h_intern(&lf[179],9,"signal/io");
lf[180]=C_h_intern(&lf[180],10,"signal/urg");
lf[181]=C_h_intern(&lf[181],11,"signal/chld");
lf[182]=C_h_intern(&lf[182],11,"signal/cont");
lf[183]=C_h_intern(&lf[183],11,"signal/stop");
lf[184]=C_h_intern(&lf[184],11,"signal/tstp");
lf[185]=C_h_intern(&lf[185],11,"signal/pipe");
lf[186]=C_h_intern(&lf[186],11,"signal/xcpu");
lf[187]=C_h_intern(&lf[187],11,"signal/xfsz");
lf[188]=C_h_intern(&lf[188],11,"signal/usr1");
lf[189]=C_h_intern(&lf[189],11,"signal/usr2");
lf[190]=C_h_intern(&lf[190],12,"signal/winch");
lf[191]=C_h_intern(&lf[191],12,"signals-list");
lf[192]=C_h_intern(&lf[192],18,"\003sysinterrupt-hook");
lf[193]=C_h_intern(&lf[193],14,"signal-handler");
lf[194]=C_h_intern(&lf[194],19,"set-signal-handler!");
lf[195]=C_h_intern(&lf[195],16,"set-signal-mask!");
lf[196]=C_h_intern(&lf[196],14,"\000process-error");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[198]=C_h_intern(&lf[198],11,"signal-mask");
lf[199]=C_h_intern(&lf[199],14,"signal-masked\077");
lf[200]=C_h_intern(&lf[200],12,"signal-mask!");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[202]=C_h_intern(&lf[202],14,"signal-unmask!");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[204]=C_h_intern(&lf[204],18,"system-information");
lf[205]=C_h_intern(&lf[205],25,"\003syspeek-nonnull-c-string");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[207]=C_h_intern(&lf[207],12,"set-user-id!");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[209]=C_h_intern(&lf[209],15,"current-user-id");
lf[210]=C_h_intern(&lf[210],25,"current-effective-user-id");
lf[211]=C_h_intern(&lf[211],13,"set-group-id!");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[213]=C_h_intern(&lf[213],16,"current-group-id");
lf[214]=C_h_intern(&lf[214],26,"current-effective-group-id");
lf[215]=C_h_intern(&lf[215],16,"user-information");
lf[216]=C_h_intern(&lf[216],6,"vector");
lf[217]=C_h_intern(&lf[217],4,"list");
lf[218]=C_h_intern(&lf[218],27,"current-effective-user-name");
lf[219]=C_h_intern(&lf[219],17,"group-information");
lf[221]=C_h_intern(&lf[221],10,"get-groups");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[225]=C_h_intern(&lf[225],11,"set-groups!");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[228]=C_h_intern(&lf[228],17,"initialize-groups");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[230]=C_h_intern(&lf[230],10,"errno/perm");
lf[231]=C_h_intern(&lf[231],11,"errno/noent");
lf[232]=C_h_intern(&lf[232],10,"errno/srch");
lf[233]=C_h_intern(&lf[233],10,"errno/intr");
lf[234]=C_h_intern(&lf[234],8,"errno/io");
lf[235]=C_h_intern(&lf[235],12,"errno/noexec");
lf[236]=C_h_intern(&lf[236],10,"errno/badf");
lf[237]=C_h_intern(&lf[237],11,"errno/child");
lf[238]=C_h_intern(&lf[238],11,"errno/nomem");
lf[239]=C_h_intern(&lf[239],11,"errno/acces");
lf[240]=C_h_intern(&lf[240],11,"errno/fault");
lf[241]=C_h_intern(&lf[241],10,"errno/busy");
lf[242]=C_h_intern(&lf[242],12,"errno/notdir");
lf[243]=C_h_intern(&lf[243],11,"errno/isdir");
lf[244]=C_h_intern(&lf[244],11,"errno/inval");
lf[245]=C_h_intern(&lf[245],11,"errno/mfile");
lf[246]=C_h_intern(&lf[246],11,"errno/nospc");
lf[247]=C_h_intern(&lf[247],11,"errno/spipe");
lf[248]=C_h_intern(&lf[248],10,"errno/pipe");
lf[249]=C_h_intern(&lf[249],11,"errno/again");
lf[250]=C_h_intern(&lf[250],10,"errno/rofs");
lf[251]=C_h_intern(&lf[251],11,"errno/exist");
lf[252]=C_h_intern(&lf[252],16,"errno/wouldblock");
lf[253]=C_h_intern(&lf[253],10,"errno/2big");
lf[254]=C_h_intern(&lf[254],12,"errno/deadlk");
lf[255]=C_h_intern(&lf[255],9,"errno/dom");
lf[256]=C_h_intern(&lf[256],10,"errno/fbig");
lf[257]=C_h_intern(&lf[257],11,"errno/ilseq");
lf[258]=C_h_intern(&lf[258],11,"errno/mlink");
lf[259]=C_h_intern(&lf[259],17,"errno/nametoolong");
lf[260]=C_h_intern(&lf[260],11,"errno/nfile");
lf[261]=C_h_intern(&lf[261],11,"errno/nodev");
lf[262]=C_h_intern(&lf[262],11,"errno/nolck");
lf[263]=C_h_intern(&lf[263],11,"errno/nosys");
lf[264]=C_h_intern(&lf[264],14,"errno/notempty");
lf[265]=C_h_intern(&lf[265],11,"errno/notty");
lf[266]=C_h_intern(&lf[266],10,"errno/nxio");
lf[267]=C_h_intern(&lf[267],11,"errno/range");
lf[268]=C_h_intern(&lf[268],10,"errno/xdev");
lf[269]=C_h_intern(&lf[269],16,"change-file-mode");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[271]=C_h_intern(&lf[271],17,"change-file-owner");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[273]=C_h_intern(&lf[273],17,"file-read-access\077");
lf[274]=C_h_intern(&lf[274],18,"file-write-access\077");
lf[275]=C_h_intern(&lf[275],20,"file-execute-access\077");
lf[276]=C_h_intern(&lf[276],14,"create-session");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[278]=C_h_intern(&lf[278],21,"set-process-group-id!");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[280]=C_h_intern(&lf[280],16,"process-group-id");
lf[281]=C_h_intern(&lf[281],20,"create-symbolic-link");
lf[282]=C_h_intern(&lf[282],18,"create-symbol-link");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[284]=C_h_intern(&lf[284],9,"substring");
lf[285]=C_h_intern(&lf[285],18,"read-symbolic-link");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[287]=C_h_intern(&lf[287],9,"file-link");
lf[288]=C_h_intern(&lf[288],9,"hard-link");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[290]=C_h_intern(&lf[290],12,"fileno/stdin");
lf[291]=C_h_intern(&lf[291],13,"fileno/stdout");
lf[292]=C_h_intern(&lf[292],13,"fileno/stderr");
lf[293]=C_h_intern(&lf[293],7,"\000append");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[301]=C_h_intern(&lf[301],16,"open-input-file*");
lf[302]=C_h_intern(&lf[302],17,"open-output-file*");
lf[303]=C_h_intern(&lf[303],12,"port->fileno");
lf[304]=C_h_intern(&lf[304],6,"socket");
lf[305]=C_h_intern(&lf[305],20,"\003systcp-port->fileno");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[308]=C_h_intern(&lf[308],25,"\003syspeek-unsigned-integer");
lf[309]=C_h_intern(&lf[309],16,"duplicate-fileno");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[311]=C_h_intern(&lf[311],15,"make-input-port");
lf[312]=C_h_intern(&lf[312],14,"set-port-name!");
lf[313]=C_h_intern(&lf[313],21,"\003syscustom-input-port");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[315]=C_h_intern(&lf[315],17,"\003systhread-yield!");
lf[316]=C_h_intern(&lf[316],25,"\003systhread-block-for-i/o!");
lf[317]=C_h_intern(&lf[317],18,"\003syscurrent-thread");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[322]=C_h_intern(&lf[322],17,"\003sysstring-append");
lf[323]=C_h_intern(&lf[323],15,"\003sysmake-string");
lf[324]=C_h_intern(&lf[324],20,"\003sysscan-buffer-line");
lf[325]=C_h_intern(&lf[325],4,"noop");
lf[326]=C_h_intern(&lf[326],16,"make-output-port");
lf[327]=C_h_intern(&lf[327],22,"\003syscustom-output-port");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[330]=C_h_intern(&lf[330],13,"file-truncate");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[333]=C_h_intern(&lf[333],4,"lock");
lf[334]=C_h_intern(&lf[334],9,"file-lock");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[336]=C_h_intern(&lf[336],18,"file-lock/blocking");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[338]=C_h_intern(&lf[338],14,"file-test-lock");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[340]=C_h_intern(&lf[340],11,"file-unlock");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[342]=C_h_intern(&lf[342],11,"create-fifo");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[344]=C_h_intern(&lf[344],5,"fifo\077");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[346]=C_h_intern(&lf[346],6,"setenv");
lf[347]=C_h_intern(&lf[347],8,"unsetenv");
lf[348]=C_h_intern(&lf[348],19,"current-environment");
lf[349]=C_h_intern(&lf[349],9,"prot/read");
lf[350]=C_h_intern(&lf[350],10,"prot/write");
lf[351]=C_h_intern(&lf[351],9,"prot/exec");
lf[352]=C_h_intern(&lf[352],9,"prot/none");
lf[353]=C_h_intern(&lf[353],9,"map/fixed");
lf[354]=C_h_intern(&lf[354],10,"map/shared");
lf[355]=C_h_intern(&lf[355],11,"map/private");
lf[356]=C_h_intern(&lf[356],13,"map/anonymous");
lf[357]=C_h_intern(&lf[357],8,"map/file");
lf[358]=C_h_intern(&lf[358],18,"map-file-to-memory");
lf[359]=C_h_intern(&lf[359],4,"mmap");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[361]=C_h_intern(&lf[361],20,"\003syspointer->address");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[363]=C_h_intern(&lf[363],16,"\003sysnull-pointer");
lf[364]=C_h_intern(&lf[364],22,"unmap-file-from-memory");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[366]=C_h_intern(&lf[366],26,"memory-mapped-file-pointer");
lf[367]=C_h_intern(&lf[367],19,"memory-mapped-file\077");
lf[368]=C_h_intern(&lf[368],19,"seconds->local-time");
lf[369]=C_h_intern(&lf[369],18,"\003sysdecode-seconds");
lf[370]=C_h_intern(&lf[370],17,"seconds->utc-time");
lf[371]=C_h_intern(&lf[371],15,"seconds->string");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[373]=C_h_intern(&lf[373],12,"time->string");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[377]=C_h_intern(&lf[377],12,"string->time");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[379]=C_h_intern(&lf[379],19,"local-time->seconds");
lf[380]=C_h_intern(&lf[380],15,"\003syscons-flonum");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[383]=C_h_intern(&lf[383],17,"utc-time->seconds");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[386]=C_h_intern(&lf[386],27,"local-timezone-abbreviation");
lf[387]=C_h_intern(&lf[387],5,"_exit");
lf[388]=C_h_intern(&lf[388],10,"set-alarm!");
lf[389]=C_h_intern(&lf[389],19,"set-buffering-mode!");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[391]=C_h_intern(&lf[391],5,"\000full");
lf[392]=C_h_intern(&lf[392],5,"\000line");
lf[393]=C_h_intern(&lf[393],5,"\000none");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[395]=C_h_intern(&lf[395],14,"terminal-port\077");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[398]=C_h_intern(&lf[398],13,"terminal-name");
lf[399]=C_h_intern(&lf[399],13,"terminal-size");
lf[400]=C_h_intern(&lf[400],6,"\000error");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[402]=C_h_intern(&lf[402],17,"\003sysmake-locative");
lf[403]=C_h_intern(&lf[403],8,"location");
lf[404]=C_h_intern(&lf[404],13,"get-host-name");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[406]=C_h_intern(&lf[406],6,"regexp");
lf[407]=C_h_intern(&lf[407],21,"make-anchored-pattern");
lf[408]=C_h_intern(&lf[408],12,"string-match");
lf[409]=C_h_intern(&lf[409],12,"glob->regexp");
lf[410]=C_h_intern(&lf[410],13,"make-pathname");
lf[411]=C_h_intern(&lf[411],18,"decompose-pathname");
lf[412]=C_h_intern(&lf[412],4,"glob");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[415]=C_h_intern(&lf[415],12,"process-fork");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[417]=C_h_intern(&lf[417],24,"pathname-strip-directory");
lf[418]=C_h_intern(&lf[418],15,"process-execute");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[420]=C_h_intern(&lf[420],16,"\003sysprocess-wait");
lf[421]=C_h_intern(&lf[421],12,"process-wait");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[423]=C_h_intern(&lf[423],18,"current-process-id");
lf[424]=C_h_intern(&lf[424],17,"parent-process-id");
lf[425]=C_h_intern(&lf[425],5,"sleep");
lf[426]=C_h_intern(&lf[426],14,"process-signal");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[428]=C_h_intern(&lf[428],17,"\003sysshell-command");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[431]=C_h_intern(&lf[431],27,"\003sysshell-command-arguments");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[433]=C_h_intern(&lf[433],11,"process-run");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[435]=C_h_intern(&lf[435],11,"\003sysprocess");
lf[436]=C_h_intern(&lf[436],19,"\003sysundefined-value");
lf[437]=C_h_intern(&lf[437],7,"process");
lf[438]=C_h_intern(&lf[438],8,"process*");
lf[439]=C_h_intern(&lf[439],10,"find-files");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[443]=C_h_intern(&lf[443],16,"\003sysdynamic-wind");
lf[444]=C_h_intern(&lf[444],13,"pathname-file");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[446]=C_h_intern(&lf[446],7,"regexp\077");
lf[447]=C_h_intern(&lf[447],19,"set-root-directory!");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[450]=C_h_intern(&lf[450],18,"getter-with-setter");
lf[451]=C_h_intern(&lf[451],26,"effective-group-id!-setter");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[453]=C_h_intern(&lf[453],25,"effective-user-id!-setter");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[455]=C_h_intern(&lf[455],23,"\003sysuser-interrupt-hook");
lf[456]=C_h_intern(&lf[456],11,"make-vector");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[459]=C_h_intern(&lf[459],17,"register-feature!");
lf[460]=C_h_intern(&lf[460],5,"posix");
C_register_lf2(lf,461,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1612,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1610 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1615,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1613 in k1610 */
static void C_ccall f_1615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1616 in k1613 in k1610 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 502  register-feature! */
t3=*((C_word*)lf[459]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[460]);}

/* k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word ab[113],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1636,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1,lf[3]);
t5=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1654,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1661,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1718,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1764,a[2]=t45,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1802,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[57]+1);
t49=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1817,a[2]=t48,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1859,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1898,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1930,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1946,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t55=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1956,a[2]=t53,a[3]=t54,a[4]=t52,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t56=C_mutate((C_word*)lf[71]+1,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[72]+1,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[73]+1,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[74],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2148,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2185,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2217,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2223,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2229,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2235,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2241,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2247,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2262,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2271,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2280,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2289,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2298,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t73=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2307,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2316,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2325,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2334,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t77=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7439,a[2]=((C_word)li259),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 842  getter-with-setter */
t79=*((C_word*)lf[450]+1);
((C_proc4)C_retrieve_proc(t79))(4,t79,t77,t78,*((C_word*)lf[93]+1));}

/* a7438 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7439(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7439,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7443,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7455,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 844  port? */
t5=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7453 in a7438 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[95]);
t4=((C_word*)t0)[2];
f_7443(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_7443(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 849  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[100],lf[458],((C_word*)t0)[3]);}}}

/* k7441 in a7438 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7446,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 851  posix-error */
t3=lf[3];
f_1636(6,t3,t2,lf[48],lf[100],lf[457],((C_word*)t0)[2]);}
else{
t3=t2;
f_7446(2,t3,C_SCHEME_UNDEFINED);}}

/* k7444 in k7441 in a7438 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[171],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
t2=C_mutate((C_word*)lf[100]+1,t1);
t3=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2420,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2444,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[107]+1);
t7=*((C_word*)lf[57]+1);
t8=*((C_word*)lf[108]+1);
t9=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2468,a[2]=t7,a[3]=t6,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[113]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2625,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2648,a[2]=t11,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[116]+1);
t14=*((C_word*)lf[117]+1);
t15=*((C_word*)lf[118]+1);
t16=*((C_word*)lf[119]+1);
t17=*((C_word*)lf[107]+1);
t18=*((C_word*)lf[2]+1);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2696,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2701,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
t21=*((C_word*)lf[122]+1);
t22=*((C_word*)lf[123]+1);
t23=*((C_word*)lf[112]+1);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2712,a[2]=t23,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t25=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2768,a[2]=t16,a[3]=t14,a[4]=t21,a[5]=t22,a[6]=t24,a[7]=t15,a[8]=t13,a[9]=t17,a[10]=t19,a[11]=t18,a[12]=t20,a[13]=((C_word)li56),tmp=(C_word)a,a+=14,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3085,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3097,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3103,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
t29=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3118,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp));
t30=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3154,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3190,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[157]+1,*((C_word*)lf[153]+1));
t33=*((C_word*)lf[150]+1);
t34=*((C_word*)lf[152]+1);
t35=*((C_word*)lf[153]+1);
t36=*((C_word*)lf[157]+1);
t37=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3206,a[2]=t33,a[3]=t35,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t38=C_mutate((C_word*)lf[159]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3230,a[2]=t34,a[3]=t36,a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3254,a[2]=t33,a[3]=t35,a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[162]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3274,a[2]=t34,a[3]=t36,a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[164]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3294,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[166]+1,C_fix((C_word)SIGTERM));
t43=C_mutate((C_word*)lf[167]+1,C_fix((C_word)SIGKILL));
t44=C_mutate((C_word*)lf[168]+1,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[169]+1,C_fix((C_word)SIGHUP));
t46=C_mutate((C_word*)lf[170]+1,C_fix((C_word)SIGFPE));
t47=C_mutate((C_word*)lf[171]+1,C_fix((C_word)SIGILL));
t48=C_mutate((C_word*)lf[172]+1,C_fix((C_word)SIGSEGV));
t49=C_mutate((C_word*)lf[173]+1,C_fix((C_word)SIGABRT));
t50=C_mutate((C_word*)lf[174]+1,C_fix((C_word)SIGTRAP));
t51=C_mutate((C_word*)lf[175]+1,C_fix((C_word)SIGQUIT));
t52=C_mutate((C_word*)lf[176]+1,C_fix((C_word)SIGALRM));
t53=C_mutate((C_word*)lf[177]+1,C_fix((C_word)SIGVTALRM));
t54=C_mutate((C_word*)lf[178]+1,C_fix((C_word)SIGPROF));
t55=C_mutate((C_word*)lf[179]+1,C_fix((C_word)SIGIO));
t56=C_mutate((C_word*)lf[180]+1,C_fix((C_word)SIGURG));
t57=C_mutate((C_word*)lf[181]+1,C_fix((C_word)SIGCHLD));
t58=C_mutate((C_word*)lf[182]+1,C_fix((C_word)SIGCONT));
t59=C_mutate((C_word*)lf[183]+1,C_fix((C_word)SIGSTOP));
t60=C_mutate((C_word*)lf[184]+1,C_fix((C_word)SIGTSTP));
t61=C_mutate((C_word*)lf[185]+1,C_fix((C_word)SIGPIPE));
t62=C_mutate((C_word*)lf[186]+1,C_fix((C_word)SIGXCPU));
t63=C_mutate((C_word*)lf[187]+1,C_fix((C_word)SIGXFSZ));
t64=C_mutate((C_word*)lf[188]+1,C_fix((C_word)SIGUSR1));
t65=C_mutate((C_word*)lf[189]+1,C_fix((C_word)SIGUSR2));
t66=C_mutate((C_word*)lf[190]+1,C_fix((C_word)SIGWINCH));
t67=(C_word)C_a_i_list(&a,25,*((C_word*)lf[166]+1),*((C_word*)lf[167]+1),*((C_word*)lf[168]+1),*((C_word*)lf[169]+1),*((C_word*)lf[170]+1),*((C_word*)lf[171]+1),*((C_word*)lf[172]+1),*((C_word*)lf[173]+1),*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1),*((C_word*)lf[189]+1),*((C_word*)lf[190]+1));
t68=C_mutate((C_word*)lf[191]+1,t67);
t69=*((C_word*)lf[192]+1);
t70=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[2],a[3]=t69,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1145 make-vector */
t71=*((C_word*)lf[456]+1);
((C_proc4)(void*)(*((C_word*)t71+1)))(4,t71,t70,C_fix(256),C_SCHEME_FALSE);}

/* k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=C_mutate((C_word*)lf[193]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3341,a[2]=t1,a[3]=((C_word)li74),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[194]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3350,a[2]=t1,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[192]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[195]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3381,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[198]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[199]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3437,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[200]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3443,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3458,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7433,a[2]=((C_word)li258),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1201 set-signal-handler! */
t12=*((C_word*)lf[194]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,*((C_word*)lf[168]+1),t11);}

/* a7432 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7433(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7433,3,t0,t1,t2);}
/* posixunix.scm: 1203 ##sys#user-interrupt-hook */
t3=*((C_word*)lf[455]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3476,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3514,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7430,a[2]=((C_word)li257),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1233 getter-with-setter */
t6=*((C_word*)lf[450]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,*((C_word*)lf[207]+1));}

/* a7429 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7430,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub398(C_SCHEME_UNDEFINED));}

/* k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3535,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7412,a[2]=((C_word)li255),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7415,a[2]=((C_word)li256),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1238 getter-with-setter */
t6=*((C_word*)lf[450]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a7414 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7415,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7425,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1242 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7423 in a7414 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1243 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[453],lf[454],((C_word*)t0)[2]);}

/* a7411 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7412,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub400(C_SCHEME_UNDEFINED));}

/* k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3535,2,t0,t1);}
t2=C_mutate((C_word*)lf[210]+1,t1);
t3=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3537,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3554,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7409,a[2]=((C_word)li254),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1253 getter-with-setter */
t6=*((C_word*)lf[450]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,*((C_word*)lf[211]+1));}

/* a7408 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7409,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub406(C_SCHEME_UNDEFINED));}

/* k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3554,2,t0,t1);}
t2=C_mutate((C_word*)lf[213]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7391,a[2]=((C_word)li252),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7394,a[2]=((C_word)li253),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1258 getter-with-setter */
t6=*((C_word*)lf[450]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a7393 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7394,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7404,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1262 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7402 in a7393 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1263 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[451],lf[452],((C_word*)t0)[2]);}

/* a7390 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7391,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub408(C_SCHEME_UNDEFINED));}

/* k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3558,2,t0,t1);}
t2=C_mutate((C_word*)lf[214]+1,t1);
t3=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3560,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3627,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3641,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[219]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3666,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[220],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3752,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3759,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[225]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3822,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3896,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[230]+1,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[231]+1,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[232]+1,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[233]+1,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[234]+1,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[235]+1,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[236]+1,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[237]+1,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[238]+1,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[239]+1,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[240]+1,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[241]+1,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[242]+1,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[243]+1,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[244]+1,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[245]+1,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[246]+1,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[247]+1,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[248]+1,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[249]+1,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[250]+1,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[251]+1,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[252]+1,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[253],0,C_fix(0));
t35=C_set_block_item(lf[254],0,C_fix(0));
t36=C_set_block_item(lf[255],0,C_fix(0));
t37=C_set_block_item(lf[256],0,C_fix(0));
t38=C_set_block_item(lf[257],0,C_fix(0));
t39=C_set_block_item(lf[258],0,C_fix(0));
t40=C_set_block_item(lf[259],0,C_fix(0));
t41=C_set_block_item(lf[260],0,C_fix(0));
t42=C_set_block_item(lf[261],0,C_fix(0));
t43=C_set_block_item(lf[262],0,C_fix(0));
t44=C_set_block_item(lf[263],0,C_fix(0));
t45=C_set_block_item(lf[264],0,C_fix(0));
t46=C_set_block_item(lf[265],0,C_fix(0));
t47=C_set_block_item(lf[266],0,C_fix(0));
t48=C_set_block_item(lf[267],0,C_fix(0));
t49=C_set_block_item(lf[268],0,C_fix(0));
t50=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3960,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[271]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3987,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4017,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[273]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4041,a[2]=t52,a[3]=((C_word)li101),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[274]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4047,a[2]=t52,a[3]=((C_word)li102),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[275]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4053,a[2]=t52,a[3]=((C_word)li103),tmp=(C_word)a,a+=4,tmp));
t56=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4059,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[278]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4074,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7373,a[2]=((C_word)li251),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1485 getter-with-setter */
t60=*((C_word*)lf[450]+1);
((C_proc4)C_retrieve_proc(t60))(4,t60,t58,t59,*((C_word*)lf[278]+1));}

/* a7372 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7373,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[280]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7380,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7386,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1490 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_7380(2,t6,C_SCHEME_UNDEFINED);}}

/* k7384 in a7372 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1491 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[280],lf[449],((C_word*)t0)[2]);}

/* k7378 in a7372 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4097,2,t0,t1);}
t2=C_mutate((C_word*)lf[280]+1,t1);
t3=C_mutate((C_word*)lf[281]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4099,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[284]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4136,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1512 make-string */
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word ab[259],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4136,2,t0,t1);}
t2=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4137,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li107),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4187,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[290]+1,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[291]+1,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[292]+1,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4212,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4249,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp);
t9=C_mutate((C_word*)lf[301]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4264,a[2]=t7,a[3]=t8,a[4]=((C_word)li111),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4278,a[2]=t7,a[3]=t8,a[4]=((C_word)li112),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[303]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4292,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4337,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[311]+1);
t14=*((C_word*)lf[312]+1);
t15=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4364,a[2]=t13,a[3]=t14,a[4]=((C_word)li134),tmp=(C_word)a,a+=5,tmp));
t16=*((C_word*)lf[326]+1);
t17=*((C_word*)lf[312]+1);
t18=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4838,a[2]=t16,a[3]=t17,a[4]=((C_word)li146),tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5097,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5136,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5210,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[334]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5228,a[2]=t20,a[3]=t21,a[4]=((C_word)li150),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5243,a[2]=t20,a[3]=t21,a[4]=((C_word)li151),tmp=(C_word)a,a+=5,tmp));
t24=C_mutate((C_word*)lf[338]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5258,a[2]=t20,a[3]=t21,a[4]=((C_word)li152),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[340]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5280,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5308,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[344]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5351,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[346]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5377,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[347]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5394,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[348]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5414,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[349]+1,C_fix((C_word)PROT_READ));
t32=C_mutate((C_word*)lf[350]+1,C_fix((C_word)PROT_WRITE));
t33=C_mutate((C_word*)lf[351]+1,C_fix((C_word)PROT_EXEC));
t34=C_mutate((C_word*)lf[352]+1,C_fix((C_word)PROT_NONE));
t35=C_mutate((C_word*)lf[353]+1,C_fix((C_word)MAP_FIXED));
t36=C_mutate((C_word*)lf[354]+1,C_fix((C_word)MAP_SHARED));
t37=C_mutate((C_word*)lf[355]+1,C_fix((C_word)MAP_PRIVATE));
t38=C_mutate((C_word*)lf[356]+1,C_fix((C_word)MAP_ANON));
t39=C_mutate((C_word*)lf[357]+1,C_fix((C_word)MAP_FILE));
t40=C_mutate((C_word*)lf[358]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5517,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5579,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5614,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5623,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5629,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5638,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[371]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5657,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5690,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[377]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5772,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[379]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5818,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[383]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5846,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[386]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5874,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[387]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5886,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[388]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5902,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[389]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5909,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[395]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5968,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate(&lf[396],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5987,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[398]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6019,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[399]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6042,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[404]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6077,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp));
t60=*((C_word*)lf[406]+1);
t61=*((C_word*)lf[407]+1);
t62=*((C_word*)lf[408]+1);
t63=*((C_word*)lf[409]+1);
t64=*((C_word*)lf[109]+1);
t65=*((C_word*)lf[410]+1);
t66=*((C_word*)lf[411]+1);
t67=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6089,a[2]=t63,a[3]=t61,a[4]=t60,a[5]=t64,a[6]=t62,a[7]=t65,a[8]=t66,a[9]=((C_word)li185),tmp=(C_word)a,a+=10,tmp));
t68=C_mutate((C_word*)lf[415]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6201,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp));
t69=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6243,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6262,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp);
t71=*((C_word*)lf[417]+1);
t72=C_mutate((C_word*)lf[418]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6281,a[2]=t71,a[3]=t70,a[4]=t69,a[5]=((C_word)li195),tmp=(C_word)a,a+=6,tmp));
t73=C_mutate((C_word*)lf[420]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6463,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[421]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6480,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[423]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6558,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[424]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6561,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[425]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6564,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[426]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6571,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[428]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6598,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[431]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6607,a[2]=((C_word)li205),tmp=(C_word)a,a+=3,tmp));
t81=*((C_word*)lf[415]+1);
t82=*((C_word*)lf[418]+1);
t83=*((C_word*)lf[122]+1);
t84=C_mutate((C_word*)lf[433]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6613,a[2]=t81,a[3]=t82,a[4]=((C_word)li206),tmp=(C_word)a,a+=5,tmp));
t85=*((C_word*)lf[164]+1);
t86=*((C_word*)lf[421]+1);
t87=*((C_word*)lf[415]+1);
t88=*((C_word*)lf[418]+1);
t89=*((C_word*)lf[309]+1);
t90=*((C_word*)lf[55]+1);
t91=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6669,a[2]=t86,a[3]=((C_word)li210),tmp=(C_word)a,a+=4,tmp);
t92=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6706,a[2]=t85,a[3]=((C_word)li213),tmp=(C_word)a,a+=4,tmp);
t93=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6726,a[2]=t90,a[3]=((C_word)li214),tmp=(C_word)a,a+=4,tmp);
t94=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6740,a[2]=t90,a[3]=((C_word)li215),tmp=(C_word)a,a+=4,tmp);
t95=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6757,a[2]=((C_word)li216),tmp=(C_word)a,a+=3,tmp);
t96=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6773,a[2]=t92,a[3]=t87,a[4]=t94,a[5]=t88,a[6]=t95,a[7]=((C_word)li218),tmp=(C_word)a,a+=8,tmp);
t97=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6818,a[2]=t93,a[3]=((C_word)li219),tmp=(C_word)a,a+=4,tmp);
t98=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6829,a[2]=t93,a[3]=((C_word)li220),tmp=(C_word)a,a+=4,tmp);
t99=C_mutate((C_word*)lf[435]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6840,a[2]=t98,a[3]=t91,a[4]=t97,a[5]=t96,a[6]=((C_word)li223),tmp=(C_word)a,a+=7,tmp));
t100=*((C_word*)lf[436]+1);
t101=C_mutate((C_word*)lf[437]+1,t100);
t102=*((C_word*)lf[436]+1);
t103=C_mutate((C_word*)lf[438]+1,t102);
t104=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6904,a[2]=((C_word)li228),tmp=(C_word)a,a+=3,tmp);
t105=C_mutate((C_word*)lf[437]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6965,a[2]=t104,a[3]=((C_word)li232),tmp=(C_word)a,a+=4,tmp));
t106=C_mutate((C_word*)lf[438]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7025,a[2]=t104,a[3]=((C_word)li236),tmp=(C_word)a,a+=4,tmp));
t107=*((C_word*)lf[412]+1);
t108=*((C_word*)lf[408]+1);
t109=*((C_word*)lf[410]+1);
t110=*((C_word*)lf[113]+1);
t111=C_mutate((C_word*)lf[439]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7085,a[2]=t110,a[3]=t109,a[4]=t107,a[5]=t108,a[6]=((C_word)li249),tmp=(C_word)a,a+=7,tmp));
t112=C_mutate((C_word*)lf[447]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7350,a[2]=((C_word)li250),tmp=(C_word)a,a+=3,tmp));
t113=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t113+1)))(2,t113,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7350,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[447]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7342,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_foreign_string_argumentp(t4);
/* ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t6=t5;
f_7342(2,t6,C_SCHEME_FALSE);}}

/* k7340 in set-root-directory! in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1353(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2365 posix-error */
t3=lf[3];
f_1636(6,t3,((C_word*)t0)[3],lf[48],lf[447],lf[448],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_7085r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7085r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7085r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li244),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7258,a[2]=t5,a[3]=((C_word)li245),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7263,a[2]=t6,a[3]=((C_word)li246),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7268,a[2]=t7,a[3]=((C_word)li248),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action13061342 */
t9=t8;
f_7268(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id13071340 */
t11=t7;
f_7263(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit13081337 */
t13=t6;
f_7258(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body13041310 */
t15=t5;
f_7087(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action1306 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7268(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7268,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7274,a[2]=((C_word)li247),tmp=(C_word)a,a+=3,tmp);
/* def-id13071340 */
t3=((C_word*)t0)[2];
f_7263(t3,t1,t2);}

/* a7273 in def-action1306 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7274,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1307 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7263,NULL,3,t0,t1,t2);}
/* def-limit13081337 */
t3=((C_word*)t0)[2];
f_7258(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1308 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7258(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7258,NULL,4,t0,t1,t2,t3);}
/* body13041310 */
t4=((C_word*)t0)[2];
f_7087(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7087(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7087,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[439]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7094,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_7094(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7253,a[2]=t4,a[3]=t7,a[4]=((C_word)li242),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_7094(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7245,a[2]=((C_word)li243),tmp=(C_word)a,a+=3,tmp));}}

/* f_7245 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7245(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7245,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_7253 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7253,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7094,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_7233(2,t4,t2);}
else{
/* posixunix.scm: 2337 regexp? */
t4=*((C_word*)lf[446]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[11]);}}

/* k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7233,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7234,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word)li237),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7104,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7227,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2340 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[445]);}

/* k7225 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2340 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7104,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7106,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li241),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7106(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7106(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7106,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2346 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7125,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2347 pathname-file */
t3=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7213,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2354 pproc */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k7211 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7213,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7220,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2354 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2355 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7106(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k7218 in k7211 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2354 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7106(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7207,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[440]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[441]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2347 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_7106(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7140,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2348 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k7138 in k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7140,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7150,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7152,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,a[5]=((C_word)li238),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word)li239),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7184,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,a[5]=((C_word)li240),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2350 ##sys#dynamic-wind */
t11=*((C_word*)lf[443]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7197,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7200,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2353 pproc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k7198 in k7138 in k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2353 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7197(2,t2,((C_word*)t0)[2]);}}

/* k7195 in k7138 in k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2353 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7106(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7183 in k7138 in k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7184,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[436]+1));}

/* a7159 in k7138 in k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7168,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7182,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2351 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],lf[442]);}

/* k7180 in a7159 in k7138 in k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2351 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7166 in a7159 in k7138 in k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7172,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2352 pproc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k7173 in k7166 in a7159 in k7138 in k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2352 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_7172(2,t2,((C_word*)t0)[2]);}}

/* k7170 in k7166 in a7159 in k7138 in k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2351 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7106(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7151 in k7138 in k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7152,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[436]+1));}

/* k7148 in k7138 in k7205 in k7123 in loop in k7102 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2349 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7106(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_7234 in k7231 in k7092 in body1304 in find-files in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7234,3,t0,t1,t2);}
/* posixunix.scm: 2338 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_7025(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_7025r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7025r(t0,t1,t2,t3);}}

static void C_ccall f_7025r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7027,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li233),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7032,a[2]=t4,a[3]=((C_word)li234),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7037,a[2]=t5,a[3]=((C_word)li235),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args12801288 */
t7=t6;
f_7037(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env12811286 */
t9=t5;
f_7032(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body12781283 */
t11=t4;
f_7027(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args1280 in process* in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7037(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7037,NULL,2,t0,t1);}
/* def-env12811286 */
t2=((C_word*)t0)[2];
f_7032(t2,t1,C_SCHEME_FALSE);}

/* def-env1281 in process* in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7032(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7032,NULL,3,t0,t1,t2);}
/* body12781283 */
t3=((C_word*)t0)[2];
f_7027(t3,t1,t2,C_SCHEME_FALSE);}

/* body1278 in process* in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_7027(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7027,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2315 %process */
f_6904(t1,lf[438],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6965(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_6965r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6965r(t0,t1,t2,t3);}}

static void C_ccall f_6965r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6967,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li229),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6972,a[2]=t4,a[3]=((C_word)li230),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6977,a[2]=t5,a[3]=((C_word)li231),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args12601268 */
t7=t6;
f_6977(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env12611266 */
t9=t5;
f_6972(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body12581263 */
t11=t4;
f_6967(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args1260 in process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6977,NULL,2,t0,t1);}
/* def-env12611266 */
t2=((C_word*)t0)[2];
f_6972(t2,t1,C_SCHEME_FALSE);}

/* def-env1261 in process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6972(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6972,NULL,3,t0,t1,t2);}
/* body12581263 */
t3=((C_word*)t0)[2];
f_6967(t3,t1,t2,C_SCHEME_FALSE);}

/* body1258 in process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6967(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6967,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2312 %process */
f_6904(t1,lf[437],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6904(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6904,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6906,a[2]=t2,a[3]=((C_word)li225),tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6925,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2301 chkstrlst */
t12=t9;
f_6906(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6959,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2303 ##sys#shell-command-arguments */
t13=*((C_word*)lf[431]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)t7)[1]);}}

/* k6957 in %process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6959,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2304 ##sys#shell-command */
t4=*((C_word*)lf[428]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6961 in k6957 in %process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6925(2,t3,t2);}

/* k6923 in %process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2305 chkstrlst */
t3=((C_word*)t0)[2];
f_6906(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6928(2,t3,C_SCHEME_UNDEFINED);}}

/* k6926 in k6923 in %process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6933,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li226),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6939,a[2]=((C_word*)t0)[3],a[3]=((C_word)li227),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2306 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6938 in k6926 in k6923 in %process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6939,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2308 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2309 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a6932 in k6926 in k6923 in %process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6933,2,t0,t1);}
/* posixunix.scm: 2306 ##sys#process */
t2=*((C_word*)lf[435]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6906(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6906,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6915,a[2]=((C_word*)t0)[2],a[3]=((C_word)li224),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6914 in chkstrlst in %process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6915,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6840,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6846,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word)li221),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,a[10]=((C_word)li222),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a6851 in ##sys#process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6852,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6863,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6883,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2282 make-on-close */
t12=((C_word*)t0)[3];
f_6669(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k6881 in a6851 in ##sys#process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2281 input-port */
t2=((C_word*)t0)[7];
f_6818(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6861 in a6851 in ##sys#process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6867,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2284 make-on-close */
t4=((C_word*)t0)[6];
f_6669(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k6877 in k6861 in a6851 in ##sys#process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2283 output-port */
t2=((C_word*)t0)[7];
f_6829(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6865 in k6861 in a6851 in ##sys#process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6871,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6875,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2287 make-on-close */
t4=((C_word*)t0)[3];
f_6669(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k6873 in k6865 in k6861 in a6851 in ##sys#process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2286 input-port */
t2=((C_word*)t0)[7];
f_6818(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6869 in k6865 in k6861 in a6851 in ##sys#process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2280 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6845 in ##sys#process in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6846,2,t0,t1);}
/* posixunix.scm: 2275 spawn */
t2=((C_word*)t0)[8];
f_6773(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6829(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6829,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6833,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2271 connect-parent */
t8=((C_word*)t0)[2];
f_6726(t8,t7,t4,t5);}

/* k6831 in output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2272 ##sys#custom-output-port */
t2=*((C_word*)lf[327]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6818(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6818,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6822,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2267 connect-parent */
t8=((C_word*)t0)[2];
f_6726(t8,t7,t4,t5);}

/* k6820 in input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2268 ##sys#custom-input-port */
t2=*((C_word*)lf[313]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6773(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6773,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2254 needed-pipe */
t9=((C_word*)t0)[2];
f_6706(t9,t8,t6);}

/* k6775 in spawn in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2255 needed-pipe */
t3=((C_word*)t0)[2];
f_6706(t3,t2,((C_word*)t0)[5]);}

/* k6778 in k6775 in spawn in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2256 needed-pipe */
t3=((C_word*)t0)[2];
f_6706(t3,t2,((C_word*)t0)[6]);}

/* k6781 in k6778 in k6775 in spawn in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6783,2,t0,t1);}
t2=f_6757(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6794,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word)li217),tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2259 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6795 in k6781 in k6778 in k6775 in spawn in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6800,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2261 connect-child */
t3=((C_word*)t0)[7];
f_6740(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[290]+1));}

/* k6798 in a6795 in k6781 in k6778 in k6775 in spawn in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6803,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_6757(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2262 connect-child */
t4=((C_word*)t0)[5];
f_6740(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[291]+1));}

/* k6801 in k6798 in a6795 in k6781 in k6778 in k6775 in spawn in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6806,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_6757(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2263 connect-child */
t4=((C_word*)t0)[3];
f_6740(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[292]+1));}

/* k6804 in k6801 in k6798 in a6795 in k6781 in k6778 in k6775 in spawn in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2264 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6792 in k6781 in k6778 in k6775 in spawn in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2257 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_6757(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6740(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6740,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6753,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2245 file-close */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k6751 in connect-child in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6753,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2219 duplicate-fileno */
t6=*((C_word*)lf[309]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k6663 in k6751 in connect-child in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2220 file-close */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6726(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6726,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6739,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2239 file-close */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6737 in connect-parent in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6706(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6706,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6715,a[2]=((C_word*)t0)[2],a[3]=((C_word)li211),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6721,a[2]=((C_word)li212),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2234 ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a6720 in needed-pipe in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6721,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a6714 in needed-pipe in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6715,2,t0,t1);}
/* posixunix.scm: 2234 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* make-on-close in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6669,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6671,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,a[9]=((C_word)li209),tmp=(C_word)a,a+=10,tmp));}

/* f_6671 in make-on-close in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6671,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li207),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6692,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li208),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2227 ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a6691 */
static void C_ccall f_6692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6692,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2229 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[196],((C_word*)t0)[3],lf[434],((C_word*)t0)[2],t4);}}

/* a6685 */
static void C_ccall f_6686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6686,2,t0,t1);}
/* posixunix.scm: 2227 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6613(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6613r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6613r(t0,t1,t2,t3);}}

static void C_ccall f_6613r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6620,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2183 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k6618 in process-run in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6620,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2185 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2187 ##sys#shell-command */
t4=*((C_word*)lf[428]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k6637 in k6618 in process-run in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6643,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2187 ##sys#shell-command-arguments */
t3=*((C_word*)lf[431]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6641 in k6637 in k6618 in process-run in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2187 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6607,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[432],t2));}

/* ##sys#shell-command in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6602,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2172 getenv */
t3=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[430]);}

/* k6600 in ##sys#shell-command in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[429]));}

/* process-signal in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6571r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6571r(t0,t1,t2,t3);}}

static void C_ccall f_6571r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[426]);
t7=(C_word)C_i_check_exact_2(t5,lf[426]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2169 posix-error */
t10=lf[3];
f_1636(7,t10,t1,lf[196],lf[426],lf[427],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6564(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6564,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1126(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6561,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1123(C_SCHEME_UNDEFINED));}

/* current-process-id in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6558,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1121(C_SCHEME_UNDEFINED));}

/* process-wait in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_6480r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6480r(t0,t1,t2);}}

static void C_ccall f_6480r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[421]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6510,a[2]=t8,a[3]=t11,a[4]=((C_word)li197),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6516,a[2]=t11,a[3]=((C_word)li198),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2153 ##sys#call-with-values */
C_call_with_values(4,0,t1,t13,t14);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* a6515 in process-wait in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6516,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2155 posix-error */
t6=lf[3];
f_1636(6,t6,t1,lf[196],lf[421],lf[422],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2156 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a6509 in process-wait in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6510,2,t0,t1);}
/* posixunix.scm: 2153 ##sys#process-wait */
t2=*((C_word*)lf[420]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6463,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 2140 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6281(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_6281r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6281r(t0,t1,t2,t3);}}

static void C_ccall f_6281r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li192),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6410,a[2]=t4,a[3]=((C_word)li193),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6415,a[2]=t5,a[3]=((C_word)li194),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist10611096 */
t7=t6;
f_6415(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist10621094 */
t9=t5;
f_6410(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body10591064 */
t11=t4;
f_6283(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist1061 in process-execute in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6415,NULL,2,t0,t1);}
/* def-envlist10621094 */
t2=((C_word*)t0)[2];
f_6410(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist1062 in process-execute in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6410(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6410,NULL,3,t0,t1,t2);}
/* body10591064 */
t3=((C_word*)t0)[2];
f_6283(t3,t1,t2,C_SCHEME_FALSE);}

/* body1059 in process-execute in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6283(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6283,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[418]);
t5=(C_word)C_i_check_list_2(t2,lf[418]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6293,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2108 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k6291 in body1059 in process-execute in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6293,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_6243(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6301,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li191),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_6301(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do1068 in k6291 in body1059 in process-execute in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6301(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6301,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_6243(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6314,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[418]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6347,a[2]=((C_word*)t0)[3],a[3]=((C_word)li190),tmp=(C_word)a,a+=4,tmp);
t8=t5;
f_6314(t8,f_6347(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_6314(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[418]);
t6=(C_word)C_block_size(t4);
t7=f_6243(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* do1072 in do1068 in k6291 in body1059 in process-execute in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_6347(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_6262(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[418]);
t5=(C_word)C_block_size(t3);
t6=f_6262(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k6312 in do1068 in k6291 in body1059 in process-execute in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6314(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6314,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6339,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2122 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k6337 in k6312 in do1068 in k6291 in body1059 in process-execute in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2122 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6315 in k6312 in do1068 in k6291 in body1059 in process-execute in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub1040(C_SCHEME_UNDEFINED);
t5=(C_word)stub1052(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2129 posix-error */
t6=lf[3];
f_1636(6,t6,((C_word*)t0)[3],lf[196],lf[418],lf[419],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_6262(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub1045(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_6243(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub1033(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6201(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6201r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6201r(t0,t1,t2);}}

static void C_ccall f_6201r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub1016(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2093 posix-error */
t5=lf[3];
f_1636(5,t5,t1,lf[196],lf[415],lf[416]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6223,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_vector_ref(t2,C_fix(0));
t9=t8;
((C_proc2)C_retrieve_proc(t9))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k6221 in process-fork in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6227,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_6227 in k6221 in process-fork in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6227,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1021(C_SCHEME_UNDEFINED,t3));}

/* glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6089(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_6089r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6089r(t0,t1,t2);}}

static void C_ccall f_6089r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li184),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_6095(t6,t1,t2);}

/* conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6095(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6095,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6110,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li181),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li183),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a6115 in conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6116,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6193,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[414]);
/* posixunix.scm: 2077 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k6191 in a6115 in conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2077 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6118 in a6115 in conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6123,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixunix.scm: 2078 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k6121 in k6118 in a6115 in conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6126,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2079 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k6124 in k6121 in k6118 in a6115 in conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6133,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[413]);
/* posixunix.scm: 2080 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k6131 in k6124 in k6121 in k6118 in a6115 in conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6133,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li182),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_6135(t5,((C_word*)t0)[2],t1);}

/* loop in k6131 in k6124 in k6121 in k6118 in a6115 in conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_6135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6135,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixunix.scm: 2081 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_6095(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6152,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixunix.scm: 2082 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k6150 in loop in k6131 in k6124 in k6121 in k6118 in a6115 in conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6152,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6162,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixunix.scm: 2083 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixunix.scm: 2084 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6135(t3,((C_word*)t0)[6],t2);}}

/* k6160 in k6150 in loop in k6131 in k6124 in k6121 in k6118 in a6115 in conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6166,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixunix.scm: 2083 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6135(t4,t2,t3);}

/* k6164 in k6160 in k6150 in loop in k6131 in k6124 in k6121 in k6118 in a6115 in conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6166,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a6109 in conc-loop in glob in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6110,2,t0,t1);}
/* posixunix.scm: 2076 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6081,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub976(t3),C_fix(0));}

/* k6079 in get-host-name in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6084,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6084(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2057 posix-error */
t3=lf[3];
f_1636(5,t3,t2,lf[400],lf[404],lf[405]);}}

/* k6082 in k6079 in get-host-name in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6042,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6046,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2038 ##sys#terminal-check */
f_5987(t3,lf[399],t2);}

/* k6044 in terminal-size in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6046,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6066,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
t5=*((C_word*)lf[402]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[403]);}

/* k6064 in k6044 in terminal-size in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[402]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[403]);}

/* k6068 in k6064 in k6044 in terminal-size in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_pointer_argumentp(t3);
t6=(C_word)C_i_foreign_pointer_argumentp(t1);
t7=(C_word)stub962(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(C_word)C_eqp(C_fix(0),t7);
if(C_truep(t8)){
/* posixunix.scm: 2045 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2046 posix-error */
t9=lf[3];
f_1636(6,t9,((C_word*)t0)[4],lf[400],lf[399],lf[401],((C_word*)t0)[6]);}}

/* terminal-name in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6019,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6023,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2030 ##sys#terminal-check */
f_5987(t3,lf[398],t2);}

/* k6021 in terminal-name in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6023,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub952(t4,t5);
/* ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* ##sys#terminal-check in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5987(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5987,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5991,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2022 ##sys#check-port */
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k5989 in ##sys#terminal-check in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[95],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2025 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[397],((C_word*)t0)[4]);}}

/* terminal-port? in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5968,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5972,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2017 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[395]);}

/* k5970 in terminal-port? in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2018 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k5973 in k5970 in terminal-port? in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5909r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5909r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5909r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5913,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2002 ##sys#check-port */
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[389]);}

/* k5911 in set-buffering-mode! in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5913,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[391]);
if(C_truep(t6)){
t7=t5;
f_5919(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[392]);
if(C_truep(t7)){
t8=t5;
f_5919(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[393]);
if(C_truep(t8)){
t9=t5;
f_5919(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2008 ##sys#error */
t9=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[389],lf[394],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k5917 in k5911 in set-buffering-mode! in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[389]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[95],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 2014 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[389],lf[390],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5902,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub932(C_SCHEME_UNDEFINED,t3));}

/* _exit in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5886r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5886r(t0,t1,t2);}}

static void C_ccall f_5886r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub927(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5874,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub922(t2),C_fix(0));}

/* utc-time->seconds in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5846,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[383]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5853,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1970 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[383],lf[385],t2);}
else{
t6=t4;
f_5853(2,t6,C_SCHEME_UNDEFINED);}}

/* k5851 in utc-time->seconds in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 1972 ##sys#cons-flonum */
t2=*((C_word*)lf[380]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1973 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[383],lf[384],((C_word*)t0)[3]);}}

/* local-time->seconds in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5818,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[379]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5825,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1963 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[379],lf[382],t2);}
else{
t6=t4;
f_5825(2,t6,C_SCHEME_UNDEFINED);}}

/* k5823 in local-time->seconds in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 1965 ##sys#cons-flonum */
t2=*((C_word*)lf[380]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1966 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[379],lf[381],((C_word*)t0)[3]);}}

/* string->time in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5772(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5772r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5772r(t0,t1,t2,t3);}}

static void C_ccall f_5772r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5776,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5776(2,t5,lf[378]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5776(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5774 in string->time in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5776,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[377]);
t3=(C_word)C_i_check_string_2(t1,lf[377]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5789,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1959 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* k5787 in k5774 in string->time in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5793,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1959 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5791 in k5787 in k5774 in string->time in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5793,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub903(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5690r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5690r(t0,t1,t2,t3);}}

static void C_ccall f_5690r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5694,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5694(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5694(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5692 in time->string in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5694,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[3],lf[373]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(10)))){
/* posixunix.scm: 1943 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[373],lf[376],((C_word*)t0)[3]);}
else{
t5=t3;
f_5700(2,t5,C_SCHEME_UNDEFINED);}}

/* k5698 in k5692 in time->string in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5700,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[373]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5719,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1947 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub876(t4,t3),C_fix(0));}}

/* k5720 in k5698 in k5692 in time->string in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1951 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1952 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[373],lf[375],((C_word*)t0)[2]);}}

/* k5717 in k5698 in k5692 in time->string in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5719,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub882(t3,t2,t1),C_fix(0));}

/* k5707 in k5698 in k5692 in time->string in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1948 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[373],lf[374],((C_word*)t0)[2]);}}

/* seconds->string in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5657,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5661,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub867(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k5659 in seconds->string in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1935 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1936 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[371],lf[372],((C_word*)t0)[2]);}}

/* seconds->utc-time in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5638,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[370]);
/* posixunix.scm: 1928 ##sys#decode-seconds */
t4=*((C_word*)lf[369]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5629,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[368]);
/* posixunix.scm: 1924 ##sys#decode-seconds */
t4=*((C_word*)lf[369]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* memory-mapped-file? in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5623,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[359]));}

/* memory-mapped-file-pointer in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5614,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[359],lf[366]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5579r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5579r(t0,t1,t2,t3);}}

static void C_ccall f_5579r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_i_check_structure_2(t2,lf[359],lf[364]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub848(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1911 posix-error */
t12=lf[3];
f_1636(7,t12,t1,lf[48],lf[364],lf[365],t2,t6);}}

/* map-file-to-memory in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_5517r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_5517r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_5517r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5521,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_5521(2,t10,t2);}
else{
/* posixunix.scm: 1896 ##sys#null-pointer */
t10=*((C_word*)lf[363]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k5519 in map-file-to-memory in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5521,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5527,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_5527(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1899 ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[60],lf[358],lf[362],t1);}}

/* k5525 in k5519 in map-file-to-memory in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5527,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub823(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1901 ##sys#pointer->address */
t17=*((C_word*)lf[361]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,t14);}

/* k5544 in k5525 in k5519 in map-file-to-memory in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1902 posix-error */
t3=lf[3];
f_1636(11,t3,((C_word*)t0)[8],lf[48],lf[358],lf[360],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_5533(2,t3,C_SCHEME_UNDEFINED);}}

/* k5531 in k5525 in k5519 in map-file-to-memory in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5533,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[359],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* current-environment in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5414,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5420,a[2]=t3,a[3]=((C_word)li159),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5420(t5,t1,C_fix(0));}

/* loop in current-environment in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5420(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5420,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5424,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub805(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k5422 in loop in current-environment in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5424,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5432,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li158),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5432(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k5422 in loop in current-environment in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5432(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5432,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5458,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1863 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1866 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k5456 in scan in k5422 in loop in current-environment in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5462,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1864 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k5460 in k5456 in scan in k5422 in loop in current-environment in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5462,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5450,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1865 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5420(t5,t3,t4);}

/* k5448 in k5460 in k5456 in scan in k5422 in loop in current-environment in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5450,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5394,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[347]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5402,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1852 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5400 in unsetenv in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5377,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[346]);
t5=(C_word)C_i_check_string_2(t3,lf[346]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5388,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1847 ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k5386 in setenv in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5392,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1847 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5390 in k5386 in setenv in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5351,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[344]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5358,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5375,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1836 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k5373 in fifo? in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1836 ##sys#file-info */
t2=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5356 in fifo? in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1839 posix-error */
t2=lf[3];
f_1636(6,t2,((C_word*)t0)[3],lf[48],lf[344],lf[345],((C_word*)t0)[2]);}}

/* create-fifo in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5308(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5308r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5308r(t0,t1,t2,t3);}}

static void C_ccall f_5308r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[342]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5315,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_5315(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_5315(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k5313 in create-fifo in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5315(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5315,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[342]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5336,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1830 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k5334 in k5313 in create-fifo in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1830 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5330 in k5313 in create-fifo in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1831 posix-error */
t3=lf[3];
f_1636(7,t3,((C_word*)t0)[3],lf[48],lf[342],lf[343],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5280,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[333],lf[340]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1820 posix-error */
t9=lf[3];
f_1636(6,t9,t1,lf[48],lf[340],lf[341],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5258r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5258r(t0,t1,t2,t3);}}

static void C_ccall f_5258r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5262,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1811 setup */
f_5136(t4,t2,t3,lf[338]);}

/* k5260 in file-test-lock in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1813 err */
f_5210(((C_word*)t0)[3],lf[339],t1,lf[338]);}}

/* file-lock/blocking in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5243(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5243r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5243r(t0,t1,t2,t3);}}

static void C_ccall f_5243r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5247,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1805 setup */
f_5136(t4,t2,t3,lf[336]);}

/* k5245 in file-lock/blocking in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1807 err */
f_5210(((C_word*)t0)[2],lf[337],t1,lf[336]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5228r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5228r(t0,t1,t2,t3);}}

static void C_ccall f_5228r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5232,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1799 setup */
f_5136(t4,t2,t3,lf[334]);}

/* k5230 in file-lock in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1801 err */
f_5210(((C_word*)t0)[2],lf[335],t1,lf[334]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5210(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5210,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1796 posix-error */
t8=lf[3];
f_1636(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5136(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5136,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5158,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1788 ##sys#check-port */
t16=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k5156 in setup in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5158,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_5164(t6,t5);}
else{
t5=t3;
f_5164(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k5162 in k5156 in setup in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5164(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5164,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[333],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5097,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[330]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5114,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5121,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5125,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1771 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_5114(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1773 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[330],lf[332],t2);}}}

/* k5123 in file-truncate in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1771 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5119 in file-truncate in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5114(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k5112 in file-truncate in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1775 posix-error */
t2=lf[3];
f_1636(7,t2,((C_word*)t0)[4],lf[48],lf[330],lf[331],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_4838r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4838r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4838r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li142),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5024,a[2]=t6,a[3]=((C_word)li143),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5029,a[2]=t7,a[3]=((C_word)li144),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5034,a[2]=t8,a[3]=((C_word)li145),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?697738 */
t10=t9;
f_5034(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi698736 */
t12=t8;
f_5029(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close699733 */
t14=t7;
f_5024(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* body695701 */
t16=t6;
f_4840(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-nonblocking?697 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5034,NULL,2,t0,t1);}
/* def-bufi698736 */
t2=((C_word*)t0)[2];
f_5029(t2,t1,C_SCHEME_FALSE);}

/* def-bufi698 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5029(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5029,NULL,3,t0,t1,t2);}
/* def-on-close699733 */
t3=((C_word*)t0)[2];
f_5024(t3,t1,t2,C_fix(0));}

/* def-on-close699 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_5024(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5024,NULL,4,t0,t1,t2,t3);}
/* body695701 */
t4=((C_word*)t0)[2];
f_4840(t4,t1,t2,t3,*((C_word*)lf[325]+1));}

/* body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4840(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4840,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1713 ##sys#file-nonblocking! */
t6=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_4844(2,t6,C_SCHEME_UNDEFINED);}}

/* k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4844,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4846,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word)li135),tmp=(C_word)a,a+=7,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_4892(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4936,a[2]=t3,a[3]=((C_word)li139),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4950,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1732 ##sys#make-string */
t12=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_4950(2,t12,((C_word*)t0)[6]);}}}

/* k4948 in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4950,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_4892(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4951,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li141),tmp=(C_word)a,a+=7,tmp));}

/* f_4951 in k4948 in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4951,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4968,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word)li140),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_4968(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1748 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4846(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_4968(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4968,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4978,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1738 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_4846(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_difference(t4,t2);
/* posixunix.scm: 1743 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k4976 in loop */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1740 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4968(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_4936 in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4936,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1731 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4846(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4890 in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4892,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[9],a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li137),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4928,a[2]=((C_word*)t0)[9],a[3]=((C_word)li138),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1751 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t5,t6,t7,t8);}

/* a4927 in k4890 in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4928,2,t0,t1);}
/* posixunix.scm: 1761 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* a4906 in k4890 in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4907,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4917,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1758 posix-error */
t3=lf[3];
f_1636(7,t3,t2,lf[48],((C_word*)t0)[3],lf[329],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_4917(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4915 in a4906 in k4890 in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1759 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a4900 in k4890 in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4901,3,t0,t1,t2);}
/* posixunix.scm: 1753 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* k4894 in k4890 in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4899,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1762 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k4897 in k4894 in k4890 in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4846(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4846,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4862,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1721 ##sys#thread-yield! */
t8=*((C_word*)lf[315]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1723 posix-error */
t7=lf[3];
f_1636(7,t7,t1,((C_word*)t0)[3],lf[48],lf[328],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4881,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1725 ##sys#substring */
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4879 in poke in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1725 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4846(t3,((C_word*)t0)[2],t1,t2);}

/* k4860 in poke in k4842 in body695 in ##sys#custom-output-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1722 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4846(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_4364r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4364r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4364r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,a[7]=((C_word)li129),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4745,a[2]=t6,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4750,a[2]=t7,a[3]=((C_word)li131),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4755,a[2]=t8,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4760,a[2]=t9,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?587676 */
t11=t10;
f_4760(t11,t1);}
else{
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi588674 */
t13=t9;
f_4755(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close589671 */
t15=t8;
f_4750(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?590667 */
t17=t7;
f_4745(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
/* body585592 */
t19=t6;
f_4366(t19,t1,t11,t13,t15,t17);}
else{
/* ##sys#error */
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[0],t18);}}}}}}

/* def-nonblocking?587 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4760,NULL,2,t0,t1);}
/* def-bufi588674 */
t2=((C_word*)t0)[2];
f_4755(t2,t1,C_SCHEME_FALSE);}

/* def-bufi588 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4755(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4755,NULL,3,t0,t1,t2);}
/* def-on-close589671 */
t3=((C_word*)t0)[2];
f_4750(t3,t1,t2,C_fix(1));}

/* def-on-close589 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4750(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4750,NULL,4,t0,t1,t2,t3);}
/* def-more?590667 */
t4=((C_word*)t0)[2];
f_4745(t4,t1,t2,t3,*((C_word*)lf[325]+1));}

/* def-more?590 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4745(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4745,NULL,5,t0,t1,t2,t3,t4);}
/* body585592 */
t5=((C_word*)t0)[2];
f_4366(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4366(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4366,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1591 ##sys#file-nonblocking! */
t7=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_4370(2,t7,C_SCHEME_UNDEFINED);}}

/* k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1593 ##sys#make-string */
t5=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_4376(2,t5,((C_word*)t0)[10]);}}

/* k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4376,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4377,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li115),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4392,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,a[10]=((C_word)li117),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4482,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4487,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word)li118),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4500,a[2]=t6,a[3]=t3,a[4]=t5,a[5]=((C_word)li119),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=((C_word)li120),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4533,a[2]=t8,a[3]=t7,a[4]=((C_word)li121),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4542,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li123),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4618,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,a[6]=((C_word)li128),tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1637 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t18))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a4617 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4618,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4624,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li127),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_4624(t7,t1,C_SCHEME_FALSE);}

/* loop in a4617 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4624(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4624,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li124),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4704,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word)li125),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[2],a[3]=((C_word)li126),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1696 ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4720,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1702 fetch */
t5=((C_word*)t0)[5];
f_4400(t5,t4);}}

/* k4718 in loop in a4617 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1704 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4624(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a4709 in loop in a4617 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4710,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1699 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4624(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a4703 in loop in a4617 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
/* posixunix.scm: 1697 ##sys#scan-buffer-line */
t2=*((C_word*)lf[324]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a4617 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4626,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_4633(2,t8,(C_truep(t7)?t7:lf[321]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4676,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1679 ##sys#make-string */
t8=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k4674 in bumper in loop in a4617 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1685 ##sys#string-append */
t6=*((C_word*)lf[322]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_4633(2,t6,t1);}}

/* k4631 in bumper in loop in a4617 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4633,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4643,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1689 fetch */
t5=((C_word*)t0)[3];
f_4400(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1694 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k4641 in k4631 in bumper in loop in a4617 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1690 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4541 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4542,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4550,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_4550(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_4550(t8,(C_word)C_fixnum_difference(t7,t5));}}

/* k4548 in a4541 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4550(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4550,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4552,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li122),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_4552(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k4548 in a4541 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4552(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4552,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* posixunix.scm: 1665 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4600,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1667 fetch */
t7=((C_word*)t0)[2];
f_4400(t7,t6);}}}

/* k4598 in loop in k4548 in a4541 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1670 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4552(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a4532 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1655 fetch */
t3=((C_word*)t0)[2];
f_4400(t3,t2);}

/* k4535 in a4532 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1656 peek */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_4392(((C_word*)t0)[2]));}

/* a4511 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4512,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4522,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1652 posix-error */
t3=lf[3];
f_1636(7,t3,t2,lf[48],((C_word*)t0)[3],lf[320],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_4522(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4520 in a4511 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1653 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a4499 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4500,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1647 ready? */
t3=((C_word*)t0)[2];
f_4377(t3,t1);}}

/* a4486 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4491,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1639 fetch */
t3=((C_word*)t0)[2];
f_4400(t3,t2);}

/* k4489 in a4486 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_4392(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k4480 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4482,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4485,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1706 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k4483 in k4480 in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4400(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4400,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li116),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_4412(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4412(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4412,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4428,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1614 ##sys#thread-block-for-i/o! */
t6=*((C_word*)lf[316]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[317]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1617 posix-error */
t5=lf[3];
f_1636(7,t5,t1,lf[48],((C_word*)t0)[6],lf[318],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4449,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1621 more? */
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k4447 in loop in fetch in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4452,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1623 ##sys#thread-yield! */
t3=*((C_word*)lf[315]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_4458(2,t8,t7);}
else{
/* posixunix.scm: 1629 posix-error */
t7=lf[3];
f_1636(7,t7,t4,lf[48],((C_word*)t0)[3],lf[319],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_4458(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4456 in k4447 in loop in fetch in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4450 in k4447 in loop in fetch in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1624 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4412(t2,((C_word*)t0)[2]);}

/* k4426 in loop in fetch in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1615 ##sys#thread-yield! */
t3=*((C_word*)lf[315]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4429 in k4426 in loop in fetch in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1616 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4412(t2,((C_word*)t0)[2]);}

/* peek in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_4392(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4377,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1599 ##sys#file-select-one */
t3=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k4389 in ready? in k4374 in k4368 in body585 in ##sys#custom-input-port in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1600 posix-error */
t3=lf[3];
f_1636(7,t3,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[314],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* duplicate-fileno in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4337r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4337r(t0,t1,t2,t3);}}

static void C_ccall f_4337r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[309]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4344,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_4344(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[309]);
t8=t5;
f_4344(t8,(C_word)C_dup2(t2,t6));}}

/* k4342 in duplicate-fileno in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4344,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4347,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1584 posix-error */
t3=lf[3];
f_1636(6,t3,t2,lf[48],lf[309],lf[310],((C_word*)t0)[2]);}
else{
t3=t2;
f_4347(2,t3,C_SCHEME_UNDEFINED);}}

/* k4345 in k4342 in duplicate-fileno in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4292,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4296,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1566 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[303]);}

/* k4294 in port->fileno in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[304],t2);
if(C_truep(t3)){
/* posixunix.scm: 1567 ##sys#tcp-port->fileno */
t4=*((C_word*)lf[305]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1568 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k4329 in k4294 in port->fileno in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4331,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1573 posix-error */
t2=lf[3];
f_1636(6,t2,((C_word*)t0)[3],lf[60],lf[303],lf[306],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4314,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1571 posix-error */
t4=lf[3];
f_1636(6,t4,t3,lf[48],lf[303],lf[307],((C_word*)t0)[2]);}
else{
t4=t3;
f_4314(2,t4,C_SCHEME_UNDEFINED);}}}

/* k4312 in k4329 in k4294 in port->fileno in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4278r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4278r(t0,t1,t2,t3);}}

static void C_ccall f_4278r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[302]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4290,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1562 mode */
f_4212(t5,C_SCHEME_FALSE,t3);}

/* k4288 in open-output-file* in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1562 check */
f_4249(((C_word*)t0)[2],lf[302],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4264r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4264r(t0,t1,t2,t3);}}

static void C_ccall f_4264r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[301]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4276,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1558 mode */
f_4212(t5,C_SCHEME_TRUE,t3);}

/* k4274 in open-input-file* in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4276,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1558 check */
f_4249(((C_word*)t0)[2],lf[301],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4249(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4249,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1551 posix-error */
t6=lf[3];
f_1636(6,t6,t1,lf[48],t2,lf[299],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4262,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1552 ##sys#make-port */
t7=*((C_word*)lf[147]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[148]+1),lf[300],lf[95]);}}

/* k4260 in check in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4212(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4212,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4220,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[293]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1545 ##sys#error */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[294],t5);}
else{
t8=t4;
f_4220(2,t8,lf[295]);}}
else{
/* posixunix.scm: 1546 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[296],t5);}}
else{
t5=t4;
f_4220(2,t5,(C_truep(t2)?lf[297]:lf[298]));}}

/* k4218 in mode in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1541 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4187,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[287]);
t5=(C_word)C_i_check_string_2(t3,lf[287]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4168,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_4168(2,t9,C_SCHEME_FALSE);}}

/* k4166 in file-link in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_4172(2,t3,C_SCHEME_FALSE);}}

/* k4170 in k4166 in file-link in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub529(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1526 posix-error */
t3=lf[3];
f_1636(7,t3,((C_word*)t0)[4],lf[48],lf[288],lf[289],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4137,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[285]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4145,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4161,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1515 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4159 in read-symbolic-link in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1515 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4143 in read-symbolic-link in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4145,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4148,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1517 posix-error */
t4=lf[3];
f_1636(6,t4,t3,lf[48],lf[285],lf[286],((C_word*)t0)[2]);}
else{
t4=t3;
f_4148(2,t4,C_SCHEME_UNDEFINED);}}

/* k4146 in k4143 in read-symbolic-link in k4134 in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1518 substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4099,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[281]);
t5=(C_word)C_i_check_string_2(t3,lf[281]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4120,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4132,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1503 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4130 in create-symbolic-link in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1503 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4118 in create-symbolic-link in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4128,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1504 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4126 in k4118 in create-symbolic-link in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1504 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4122 in k4118 in create-symbolic-link in k4095 in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1506 posix-error */
t3=lf[3];
f_1636(7,t3,((C_word*)t0)[4],lf[48],lf[282],lf[283],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* set-process-group-id! in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4074,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[278]);
t5=(C_word)C_i_check_exact_2(t3,lf[278]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4090,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1481 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k4088 in set-process-group-id! in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1482 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[278],lf[279],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* create-session in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4063,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4069,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1473 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4063(2,t4,C_SCHEME_UNDEFINED);}}

/* k4067 in create-session in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1474 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[276],lf[277]);}

/* k4061 in create-session in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4053,3,t0,t1,t2);}
/* posixunix.scm: 1468 check */
f_4017(t1,t2,C_fix((C_word)X_OK),lf[275]);}

/* file-write-access? in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4047,3,t0,t1,t2);}
/* posixunix.scm: 1467 check */
f_4017(t1,t2,C_fix((C_word)W_OK),lf[274]);}

/* file-read-access? in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4041,3,t0,t1,t2);}
/* posixunix.scm: 1466 check */
f_4017(t1,t2,C_fix((C_word)R_OK),lf[273]);}

/* check in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_4017(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4017,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4035,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4039,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1463 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4037 in check in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1463 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4033 in check in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4035,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4027,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_4027(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1464 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4025 in k4033 in check in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3987,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[271]);
t6=(C_word)C_i_check_exact_2(t3,lf[271]);
t7=(C_word)C_i_check_exact_2(t4,lf[271]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4011,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4015,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1453 ##sys#expand-home-path */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k4013 in change-file-owner in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1453 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4009 in change-file-owner in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1454 posix-error */
t3=lf[3];
f_1636(8,t3,((C_word*)t0)[3],lf[48],lf[271],lf[272],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3960,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[269]);
t5=(C_word)C_i_check_exact_2(t3,lf[269]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3981,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3985,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1445 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3983 in change-file-mode in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1445 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3979 in change-file-mode in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1446 posix-error */
t3=lf[3];
f_1636(7,t3,((C_word*)t0)[3],lf[48],lf[269],lf[270],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3896,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[228]);
t5=(C_word)C_i_check_exact_2(t3,lf[228]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3884,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_3884(2,t9,C_SCHEME_FALSE);}}

/* k3882 in initialize-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3884,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub469(C_SCHEME_UNDEFINED,t1,t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1366 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3910 in k3882 in initialize-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1367 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[228],lf[229],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3822,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3826,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_3752(t4);
if(C_truep(t5)){
t6=t3;
f_3826(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1349 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[225],lf[227]);}}

/* k3824 in set-groups! in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3826,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3831,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li95),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3831(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do456 in k3824 in set-groups! in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3831(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3831,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3847,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1354 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[225]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k3845 in do456 in k3824 in set-groups! in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1355 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[225],lf[226],((C_word*)t0)[2]);}

/* get-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3759,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3763,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3817,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1335 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3763(2,t4,C_SCHEME_UNDEFINED);}}

/* k3815 in get-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1336 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[221],lf[224]);}

/* k3761 in get-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_3752(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_3766(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1338 ##sys#error */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[221],lf[223]);}}

/* k3764 in k3761 in get-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub438(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3798,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1340 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_3769(2,t5,C_SCHEME_UNDEFINED);}}

/* k3796 in k3764 in k3761 in get-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1341 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[221],lf[222]);}

/* k3767 in k3764 in k3761 in get-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3769,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3774,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3774(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k3767 in k3764 in k3761 in get-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3774(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3774,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3788,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1345 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3786 in loop in k3767 in k3764 in k3761 in get-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3788,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_3752(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub442(C_SCHEME_UNDEFINED,t2));}

/* group-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3666r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3666r(t0,t1,t2,t3);}}

static void C_ccall f_3666r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3670,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3670(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3670(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3668 in group-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_3673(t3,(C_word)C_getgrgid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[219]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3724,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1309 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3722 in k3668 in group-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3673(t2,(C_word)C_getgrnam(t1));}

/* k3671 in k3668 in group-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3673(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3673,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3681 in k3671 in k3668 in group-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3687,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k3685 in k3681 in k3671 in k3668 in group-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3691,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3696,a[2]=t4,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3696(t6,t2,C_fix(0));}

/* loop in k3685 in k3681 in k3671 in k3668 in group-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3696(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3696,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub421(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k3698 in loop in k3685 in k3681 in k3671 in k3668 in group-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3710,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1318 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3696(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k3708 in k3698 in loop in k3685 in k3681 in k3671 in k3668 in group-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3710,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3689 in k3685 in k3681 in k3671 in k3668 in group-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[216]+1):*((C_word*)lf[217]+1));
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3649,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3653,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1294 current-effective-user-id */
t4=*((C_word*)lf[210]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3651 in current-effective-user-name in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1294 user-information */
t2=*((C_word*)lf[215]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3647 in current-effective-user-name in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3635,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3639,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1291 current-user-id */
t4=*((C_word*)lf[209]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3637 in current-user-name in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1291 user-information */
t2=*((C_word*)lf[215]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3633 in current-user-name in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* user-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3560r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3560r(t0,t1,t2,t3);}}

static void C_ccall f_3560r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3564,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3564(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3564(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3562 in user-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_3567(t3,(C_word)C_getpwuid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[215]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3606,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1279 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3604 in k3562 in user-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3567(t2,(C_word)C_getpwnam(t1));}

/* k3565 in k3562 in user-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3567,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3575 in k3565 in k3562 in user-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3581,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k3579 in k3575 in k3565 in k3562 in user-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3585,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k3583 in k3579 in k3575 in k3565 in k3562 in user-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3589,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k3587 in k3583 in k3579 in k3575 in k3565 in k3562 in user-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3593,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k3591 in k3587 in k3583 in k3579 in k3575 in k3565 in k3562 in user-information in k3556 in k3552 in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[216]+1):*((C_word*)lf[217]+1));
t3=t2;
((C_proc9)C_retrieve_proc(t3))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* set-group-id! in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3537,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3547,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1249 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3545 in set-group-id! in k3533 in k3529 in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1250 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[207],lf[212],((C_word*)t0)[2]);}

/* set-user-id! in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3514,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3524,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1229 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3522 in set-user-id! in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1230 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[207],lf[208],((C_word*)t0)[2]);}

/* system-information in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3480,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3509,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1218 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_3480(2,t3,C_SCHEME_UNDEFINED);}}

/* k3507 in system-information in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1219 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[204],lf[206]);}

/* k3478 in system-information in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k3485 in k3478 in system-information in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3491,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k3489 in k3485 in k3478 in system-information in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3495,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k3493 in k3489 in k3485 in k3478 in system-information in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3499,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k3497 in k3493 in k3489 in k3485 in k3478 in system-information in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3503,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[205]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k3501 in k3497 in k3493 in k3489 in k3485 in k3478 in system-information in k3472 in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3503,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3458,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[202]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1197 posix-error */
t5=lf[3];
f_1636(5,t5,t1,lf[196],lf[202],lf[203]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3443,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[200]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1191 posix-error */
t5=lf[3];
f_1636(5,t5,t1,lf[196],lf[200],lf[201]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3437,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[199]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3405,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3411,a[2]=t3,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3411(t5,t1,*((C_word*)lf[191]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3411(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3411,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1181 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3381,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[195]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3388,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3399,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a3398 in set-signal-mask! in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3399,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[195]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k3386 in set-signal-mask! in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1174 posix-error */
t2=lf[3];
f_1636(5,t2,((C_word*)t0)[2],lf[196],lf[195],lf[197]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3363,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3373,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1160 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1162 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k3371 in ##sys#interrupt-hook in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1161 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3350,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[194]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k3337 in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3341,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[193]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3298,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1077 posix-error */
t3=lf[3];
f_1636(5,t3,t2,lf[48],lf[164],lf[165]);}
else{
t3=t2;
f_3298(2,t3,C_SCHEME_UNDEFINED);}}

/* k3296 in create-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1078 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3274r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3274r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3274r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[163]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3278,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k3276 in with-output-to-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3278,2,t0,t1);}
t2=C_mutate((C_word*)lf[163]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3284,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li71),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1065 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a3283 in k3276 in with-output-to-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3284r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3284r(t0,t1,t2);}}

static void C_ccall f_3284r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3288,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1067 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3286 in a3283 in k3276 in with-output-to-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[163]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3254r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3254r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3254r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[161]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3258,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k3256 in with-input-from-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3258,2,t0,t1);}
t2=C_mutate((C_word*)lf[161]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3264,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li69),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1055 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a3263 in k3256 in with-input-from-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3264r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3264r(t0,t1,t2);}}

static void C_ccall f_3264r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3268,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1057 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3266 in a3263 in k3256 in with-input-from-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[161]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3230r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3230r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3230r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3234,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k3232 in call-with-output-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3239,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li66),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3245,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1045 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3244 in k3232 in call-with-output-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3245r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3245r(t0,t1,t2);}}

static void C_ccall f_3245r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3249,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1048 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3247 in a3244 in k3232 in call-with-output-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3238 in k3232 in call-with-output-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
/* posixunix.scm: 1046 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3206r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3206r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3206r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3210,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k3208 in call-with-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3215,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3221,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1037 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3220 in k3208 in call-with-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3221r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3221r(t0,t1,t2);}}

static void C_ccall f_3221r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3225,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1040 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3223 in a3220 in k3208 in call-with-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3214 in k3208 in call-with-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3215,2,t0,t1);}
/* posixunix.scm: 1038 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3190,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3194,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1024 ##sys#check-port */
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[153]);}

/* k3192 in close-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3194,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3197,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1026 posix-error */
t5=lf[3];
f_1636(6,t5,t3,lf[48],lf[154],lf[155],((C_word*)t0)[3]);}
else{
t5=t3;
f_3197(2,t5,C_SCHEME_UNDEFINED);}}

/* k3195 in k3192 in close-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3154r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3154r(t0,t1,t2,t3);}}

static void C_ccall f_3154r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[152]);
t5=f_3085(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3168,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[144]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3175,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1019 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3185,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1020 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1021 badmode */
f_3097(t6,t5);}}}

/* k3183 in open-output-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3168(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k3173 in open-output-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3175,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3168(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k3166 in open-output-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1015 check */
f_3103(((C_word*)t0)[3],lf[152],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3118r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3118r(t0,t1,t2,t3);}}

static void C_ccall f_3118r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[150]);
t5=f_3085(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3132,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[144]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3139,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1008 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3149,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1009 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1010 badmode */
f_3097(t6,t5);}}}

/* k3147 in open-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3149,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3132(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k3137 in open-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3139,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3132(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k3130 in open-input-pipe in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1004 check */
f_3103(((C_word*)t0)[3],lf[150],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3103(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3103,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 996  posix-error */
t6=lf[3];
f_1636(6,t6,t1,lf[48],t2,lf[146],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3116,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 997  ##sys#make-port */
t7=*((C_word*)lf[147]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[148]+1),lf[149],lf[95]);}}

/* k3114 in check in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_3097(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3097,NULL,2,t1,t2);}
/* posixunix.scm: 993  ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[145],t2);}

/* mode in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_3085(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[144]));}

/* canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2768,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[128]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2775,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2889,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 941  cwd */
t8=((C_word*)t0)[6];
f_2712(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3075,a[2]=((C_word*)t0)[12],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 943  sref */
t10=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_2895(t9,C_SCHEME_FALSE);}}}

/* k3073 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 943  sep? */
t2=((C_word*)t0)[3];
f_2895(t2,f_2701(t1));}

/* k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2895,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
f_2775(2,t2,((C_word*)t0)[10]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 946  cwd */
t5=((C_word*)t0)[8];
f_2712(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3061,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 947  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k3059 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 947  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k3048 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3050,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3057,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 948  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_2914(t2,C_SCHEME_FALSE);}}

/* k3055 in k3048 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 948  sep? */
t2=((C_word*)t0)[3];
f_2914(t2,f_2701(t1));}

/* k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2914,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2921,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 950  getenv */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[141]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2952,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 955  cwd */
t5=((C_word*)t0)[6];
f_2712(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3043,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 956  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(0));}}}

/* k3041 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 956  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3020 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3022,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3039,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 957  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_2958(t2,C_SCHEME_FALSE);}}

/* k3037 in k3020 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 957  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3026 in k3020 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3028,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3035,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 958  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_2958(t2,C_SCHEME_FALSE);}}

/* k3033 in k3026 in k3020 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 958  sep? */
t2=((C_word*)t0)[3];
f_2958(t2,f_2701(t1));}

/* k2956 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2958(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2958,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
/* posixunix.scm: 959  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)t0)[9],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3019,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 960  sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[9],C_fix(0));}}

/* k3017 in k2956 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 960  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k2996 in k2956 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2998,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3004,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3015,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 961  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_2971(2,t2,C_SCHEME_FALSE);}}

/* k3013 in k2996 in k2956 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 961  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3002 in k2996 in k2956 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3004,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3011,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 962  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_2971(2,t2,C_SCHEME_FALSE);}}

/* k3009 in k3002 in k2996 in k2956 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 962  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k2969 in k2956 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2971,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
/* posixunix.scm: 963  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 964  sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],C_fix(0));}}

/* k2993 in k2969 in k2956 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2995,2,t0,t1);}
t2=f_2701(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_2775(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 967  cwd */
t4=((C_word*)t0)[2];
f_2712(t4,t3);}}

/* k2989 in k2993 in k2969 in k2956 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 967  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[143],((C_word*)t0)[2]);}

/* k2950 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 955  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[142],((C_word*)t0)[2]);}

/* k2919 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2924(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2939,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 951  user */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2937 in k2919 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 951  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[140],t1);}

/* k2922 in k2919 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2928,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 952  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k2926 in k2922 in k2919 in k2912 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 949  sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2906 in k2893 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 946  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[139],((C_word*)t0)[2]);}

/* k2887 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 941  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[138]);}

/* k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=t1;
/* string-split */
t4=*((C_word*)lf[136]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,lf[137]);}

/* k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li55),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_2784(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2784(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2784,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 970  null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2789 in loop in k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2797,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 971  null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2852,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 982  string=? */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[135],t5);}}

/* k2853 in k2789 in loop in k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2852(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 984  string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[134],t3);}}

/* k2862 in k2853 in k2789 in loop in k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2852(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_2852(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k2850 in k2789 in loop in k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 980  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2784(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2795 in k2789 in loop in k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2797,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[129]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2833,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 973  sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k2831 in k2795 in k2789 in loop in k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2833,2,t0,t1);}
t2=f_2701(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2810,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2814,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[131],((C_word*)t0)[2]);
/* posixunix.scm: 976  reverse */
t6=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2829,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 979  reverse */
t5=*((C_word*)lf[132]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2827 in k2831 in k2795 in k2789 in loop in k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 979  isperse */
f_2696(((C_word*)t0)[2],t1);}

/* k2823 in k2831 in k2795 in k2789 in loop in k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 977  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[133],t1);}

/* k2812 in k2831 in k2795 in k2789 in loop in k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 976  isperse */
f_2696(((C_word*)t0)[2],t1);}

/* k2808 in k2831 in k2795 in k2789 in loop in k2780 in k2773 in canonical-path in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 974  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[130],t1);}

/* cwd in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2712(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2712,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2719,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[2],a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a2720 in cwd in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2721,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2727,a[2]=t2,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2745,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[126]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a2744 in a2720 in cwd in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2751,a[2]=((C_word*)t0)[3],a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2757,a[2]=((C_word*)t0)[2],a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2756 in a2744 in a2720 in cwd in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2757r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2757r(t0,t1,t2);}}

static void C_ccall f_2757r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2763,a[2]=t2,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp);
/* g273275 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2762 in a2756 in a2744 in a2720 in cwd in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2750 in a2744 in a2720 in cwd in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2751,2,t0,t1);}
/* posixunix.scm: 936  cw */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a2726 in a2720 in cwd in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2727,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2733,a[2]=t2,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
/* g273275 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2732 in a2726 in a2720 in cwd in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[124]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[125]);}

/* k2717 in cwd in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* sep? in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_2701(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2696(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2696,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[120]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[121]);}

/* current-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2648r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2648r(t0,t1,t2);}}

static void C_ccall f_2648r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2652(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2652(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2650 in current-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 914  change-directory */
t2=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 915  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k2659 in k2650 in current-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 918  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 919  posix-error */
t3=lf[3];
f_1636(5,t3,((C_word*)t0)[2],lf[48],lf[112],lf[115]);}}

/* directory? in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2625,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[113]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2632,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2646,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 907  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2644 in directory? in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 907  ##sys#file-info */
t2=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2630 in directory? in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2468(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_2468r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2468r(t0,t1,t2);}}

static void C_ccall f_2468r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2568,a[2]=t3,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2573,a[2]=t4,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec210235 */
t6=t5;
f_2573(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?211233 */
t8=t4;
f_2568(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body208213 */
t10=t3;
f_2470(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec210 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2573,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2581,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 880  current-directory */
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2579 in def-spec210 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?211233 */
t2=((C_word*)t0)[3];
f_2568(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?211 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2568(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2568,NULL,3,t0,t1,t2);}
/* body208213 */
t3=((C_word*)t0)[2];
f_2470(t3,t1,t2,C_SCHEME_FALSE);}

/* body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2470(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2470,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[109]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2477,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 882  make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k2475 in body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 883  ##sys#make-pointer */
t3=*((C_word*)lf[111]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2478 in k2475 in body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 884  ##sys#make-pointer */
t3=*((C_word*)lf[111]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2481 in k2478 in k2475 in body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2567,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 885  ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k2565 in k2481 in k2478 in k2475 in body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 885  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2485 in k2481 in k2478 in k2475 in body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2487,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 887  posix-error */
t3=lf[3];
f_1636(6,t3,((C_word*)t0)[7],lf[48],lf[109],lf[110],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word)li38),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_2501(t6,((C_word*)t0)[7]);}}

/* loop in k2485 in k2481 in k2478 in k2475 in body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2501,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 895  ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k2509 in loop in k2485 in k2481 in k2478 in k2475 in body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 896  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_fix(0));}

/* k2512 in k2509 in loop in k2485 in k2481 in k2478 in k2475 in body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 897  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_2517(2,t3,C_SCHEME_FALSE);}}

/* k2515 in k2512 in k2509 in loop in k2485 in k2481 in k2478 in k2475 in body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2523,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_2523(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_2523(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_2523(t4,C_SCHEME_FALSE);}}

/* k2521 in k2515 in k2512 in k2509 in loop in k2485 in k2481 in k2478 in k2475 in body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2523(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2523,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 902  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2501(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 903  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2501(t3,t2);}}

/* k2531 in k2521 in k2515 in k2512 in k2509 in loop in k2485 in k2481 in k2478 in k2475 in body208 in directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2533,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2444,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[105]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2462,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2466,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 873  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2464 in delete-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 873  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2460 in delete-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 874  posix-error */
t3=lf[3];
f_1636(6,t3,((C_word*)t0)[3],lf[48],lf[105],lf[106],((C_word*)t0)[2]);}}

/* change-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2420,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2438,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2442,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 867  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2440 in change-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 867  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2436 in change-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 868  posix-error */
t3=lf[3];
f_1636(6,t3,((C_word*)t0)[3],lf[48],lf[103],lf[104],((C_word*)t0)[2]);}}

/* create-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2396,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[101]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2414,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2418,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 861  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2416 in create-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 861  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2412 in create-directory in k2392 in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 862  posix-error */
t3=lf[3];
f_1636(6,t3,((C_word*)t0)[3],lf[48],lf[101],lf[102],((C_word*)t0)[2]);}}

/* set-file-position! in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2334r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2334r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2334r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[93]);
t8=(C_word)C_i_check_exact_2(t6,lf[93]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2347,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 833  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[98],lf[93],lf[99],t3,t2);}
else{
t10=t9;
f_2347(2,t10,C_SCHEME_UNDEFINED);}}

/* k2345 in set-file-position! in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 834  port? */
t4=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k2357 in k2345 in set-file-position! in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[95]);
t4=((C_word*)t0)[4];
f_2353(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_2353(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 838  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[60],lf[93],lf[96],((C_word*)t0)[5]);}}}

/* k2351 in k2345 in set-file-position! in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 839  posix-error */
t2=lf[3];
f_1636(7,t2,((C_word*)t0)[4],lf[48],lf[93],lf[94],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* stat-socket? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2325,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[92]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2332,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 825  ##sys#stat */
f_2148(t4,t2,C_SCHEME_FALSE,lf[92]);}

/* k2330 in stat-socket? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* stat-symlink? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2316,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[91]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2323,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 820  ##sys#stat */
f_2148(t4,t2,C_SCHEME_TRUE,lf[91]);}

/* k2321 in stat-symlink? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* stat-fifo? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2307,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2314,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 815  ##sys#stat */
f_2148(t4,t2,C_SCHEME_FALSE,lf[90]);}

/* k2312 in stat-fifo? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* stat-block-device? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2298,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 810  ##sys#stat */
f_2148(t4,t2,C_SCHEME_FALSE,lf[89]);}

/* k2303 in stat-block-device? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* stat-char-device? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2289,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2296,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 805  ##sys#stat */
f_2148(t4,t2,C_SCHEME_FALSE,lf[88]);}

/* k2294 in stat-char-device? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2280,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2287,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 800  ##sys#stat */
f_2148(t4,t2,C_SCHEME_FALSE,lf[87]);}

/* k2285 in stat-directory? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2271,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2278,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 795  ##sys#stat */
f_2148(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k2276 in stat-regular? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2262,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2269,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 790  ##sys#stat */
f_2148(t4,t2,C_SCHEME_TRUE,lf[85]);}

/* k2267 in symbolic-link? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2253,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2260,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 785  ##sys#stat */
f_2148(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k2258 in regular-file? in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2247,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 781  ##sys#stat */
f_2148(t3,t2,C_SCHEME_FALSE,lf[83]);}

/* k2249 in file-permissions in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2241,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2245,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 780  ##sys#stat */
f_2148(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k2243 in file-owner in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2235,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#stat */
f_2148(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k2237 in file-change-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2229,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2233,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 778  ##sys#stat */
f_2148(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k2231 in file-access-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2223,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2227,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 777  ##sys#stat */
f_2148(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k2225 in file-modification-time in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2217,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2221,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 776  ##sys#stat */
f_2148(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k2219 in file-size in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2185r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2185r(t0,t1,t2,t3);}}

static void C_ccall f_2185r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2189,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2196,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_2196(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2196(2,t7,(C_word)C_i_car(t3));}
else{
/* posixunix.scm: 769  ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k2194 in file-stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 769  ##sys#stat */
f_2148(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[77]);}

/* k2187 in file-stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2148(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2148,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2152,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_2152(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2173,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 760  ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 764  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[76],t2);}}}

/* k2178 in ##sys#stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 760  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2171 in ##sys#stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2152(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k2150 in ##sys#stat in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 766  posix-error */
t2=lf[3];
f_1636(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[75],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1956r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1956r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1956r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_1930(C_fix(0));
t10=f_1930(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_1972(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 689  fd_set */
t14=t12;
f_1972(2,t14,f_1936(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[68]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2129,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t15=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a2128 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2129,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 696  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1936(C_fix(0),t2));}

/* k1970 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1972,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_1978(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 701  fd_set */
t5=t3;
f_1978(2,t5,f_1936(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[68]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a2102 in k1970 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2103,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 708  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1936(C_fix(1),t2));}

/* k1976 in k1970 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[68]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_1981(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_1981(t4,(C_word)C_C_select(t3));}}

/* k1979 in k1976 in k1970 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_1981(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1981,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 715  posix-error */
t2=lf[3];
f_1636(7,t2,((C_word*)t0)[5],lf[48],lf[68],lf[69],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 716  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 721  fd_test */
t4=t3;
f_2020(t4,f_1946(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2061,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2063,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_2020(t4,C_SCHEME_FALSE);}}}}

/* a2062 in k1979 in k1976 in k1970 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2063,3,t0,t1,t2);}
t3=f_1946(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2059 in k1979 in k1976 in k1970 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2020(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2018 in k1979 in k1976 in k1970 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2020,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2024,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 727  fd_test */
t3=t2;
f_2024(t3,f_1946(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2036,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2038,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_2024(t3,C_SCHEME_FALSE);}}

/* a2037 in k2018 in k1979 in k1976 in k1970 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2038,3,t0,t1,t2);}
t3=f_1946(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2034 in k2018 in k1979 in k1976 in k1970 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2024(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2022 in k2018 in k1979 in k1976 in k1970 in file-select in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_fcall f_2024(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 718  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_1946(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub92(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_set in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_1936(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub86(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_zero in k1622 in k1619 in k1616 in k1613 in k1610 */
static C_word C_fcall f_1930(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub81(C_SCHEME_UNDEFINED,t2));}

/* file-mkstemp in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1898,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[65]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1905,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 667  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1903 in file-mkstemp in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1911,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 671  posix-error */
t6=lf[3];
f_1636(6,t6,t4,lf[48],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t6=t4;
f_1911(2,t6,C_SCHEME_UNDEFINED);}}

/* k1909 in k1903 in file-mkstemp in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 672  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1916 in k1909 in k1903 in file-mkstemp in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 672  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1859r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1859r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1859r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[62]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1866,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1866(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 656  ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[60],lf[62],lf[64],t3);}}

/* k1864 in file-write in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[62]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1875,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 661  posix-error */
t8=lf[3];
f_1636(7,t8,t6,lf[48],lf[62],lf[63],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_1875(2,t8,C_SCHEME_UNDEFINED);}}

/* k1873 in k1864 in file-write in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1817r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1817r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1817r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1827,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1827(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixunix.scm: 644  make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k1825 in file-read in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1830(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 646  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[60],lf[58],lf[61],t1);}}

/* k1828 in k1825 in file-read in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1830,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1833,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 649  posix-error */
t5=lf[3];
f_1636(7,t5,t3,lf[48],lf[58],lf[59],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_1833(2,t5,C_SCHEME_UNDEFINED);}}

/* k1831 in k1828 in k1825 in file-read in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1833,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1802,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[55]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 637  posix-error */
t4=lf[3];
f_1636(6,t4,t1,lf[48],lf[55],lf[56],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1764r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1764r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1764r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[51]);
t8=(C_word)C_i_check_exact_2(t3,lf[51]);
t9=(C_word)C_i_check_exact_2(t6,lf[51]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1781,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1794,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 628  ##sys#expand-home-path */
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k1792 in file-open in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 628  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1779 in file-open in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1781,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1784,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 630  posix-error */
t5=lf[3];
f_1636(8,t5,t3,lf[48],lf[51],lf[52],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_1784(2,t5,C_SCHEME_UNDEFINED);}}

/* k1782 in k1779 in file-open in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1718r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1718r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1718r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1722,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1722(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1722(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1720 in file-control in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[47]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[47]);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_integer_argumentp(t1);
t9=(C_word)stub24(C_SCHEME_UNDEFINED,t6,t7,t8);
t10=(C_word)C_eqp(t9,C_fix(-1));
if(C_truep(t10)){
/* posixunix.scm: 618  posix-error */
t11=lf[3];
f_1636(7,t11,((C_word*)t0)[2],lf[48],lf[47],lf[49],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t9);}}

/* ##sys#file-select-one in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1661,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub17(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-nonblocking! in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1654,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub13(C_SCHEME_UNDEFINED,t3));}

/* posix-error in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1636r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1636r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1636r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1640,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 508  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1638 in posix-error in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1647,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1651,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub3(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k1649 in k1638 in posix-error in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 509  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k1645 in k1638 in posix-error in k1622 in k1619 in k1616 in k1613 in k1610 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[607] = {
{"toplevelposixunix.scm",(void*)C_posix_toplevel},
{"f_1612posixunix.scm",(void*)f_1612},
{"f_1615posixunix.scm",(void*)f_1615},
{"f_1618posixunix.scm",(void*)f_1618},
{"f_1621posixunix.scm",(void*)f_1621},
{"f_1624posixunix.scm",(void*)f_1624},
{"f_7439posixunix.scm",(void*)f_7439},
{"f_7455posixunix.scm",(void*)f_7455},
{"f_7443posixunix.scm",(void*)f_7443},
{"f_7446posixunix.scm",(void*)f_7446},
{"f_2394posixunix.scm",(void*)f_2394},
{"f_3339posixunix.scm",(void*)f_3339},
{"f_7433posixunix.scm",(void*)f_7433},
{"f_3474posixunix.scm",(void*)f_3474},
{"f_7430posixunix.scm",(void*)f_7430},
{"f_3531posixunix.scm",(void*)f_3531},
{"f_7415posixunix.scm",(void*)f_7415},
{"f_7425posixunix.scm",(void*)f_7425},
{"f_7412posixunix.scm",(void*)f_7412},
{"f_3535posixunix.scm",(void*)f_3535},
{"f_7409posixunix.scm",(void*)f_7409},
{"f_3554posixunix.scm",(void*)f_3554},
{"f_7394posixunix.scm",(void*)f_7394},
{"f_7404posixunix.scm",(void*)f_7404},
{"f_7391posixunix.scm",(void*)f_7391},
{"f_3558posixunix.scm",(void*)f_3558},
{"f_7373posixunix.scm",(void*)f_7373},
{"f_7386posixunix.scm",(void*)f_7386},
{"f_7380posixunix.scm",(void*)f_7380},
{"f_4097posixunix.scm",(void*)f_4097},
{"f_4136posixunix.scm",(void*)f_4136},
{"f_7350posixunix.scm",(void*)f_7350},
{"f_7342posixunix.scm",(void*)f_7342},
{"f_7085posixunix.scm",(void*)f_7085},
{"f_7268posixunix.scm",(void*)f_7268},
{"f_7274posixunix.scm",(void*)f_7274},
{"f_7263posixunix.scm",(void*)f_7263},
{"f_7258posixunix.scm",(void*)f_7258},
{"f_7087posixunix.scm",(void*)f_7087},
{"f_7245posixunix.scm",(void*)f_7245},
{"f_7253posixunix.scm",(void*)f_7253},
{"f_7094posixunix.scm",(void*)f_7094},
{"f_7233posixunix.scm",(void*)f_7233},
{"f_7227posixunix.scm",(void*)f_7227},
{"f_7104posixunix.scm",(void*)f_7104},
{"f_7106posixunix.scm",(void*)f_7106},
{"f_7125posixunix.scm",(void*)f_7125},
{"f_7213posixunix.scm",(void*)f_7213},
{"f_7220posixunix.scm",(void*)f_7220},
{"f_7207posixunix.scm",(void*)f_7207},
{"f_7140posixunix.scm",(void*)f_7140},
{"f_7200posixunix.scm",(void*)f_7200},
{"f_7197posixunix.scm",(void*)f_7197},
{"f_7184posixunix.scm",(void*)f_7184},
{"f_7160posixunix.scm",(void*)f_7160},
{"f_7182posixunix.scm",(void*)f_7182},
{"f_7168posixunix.scm",(void*)f_7168},
{"f_7175posixunix.scm",(void*)f_7175},
{"f_7172posixunix.scm",(void*)f_7172},
{"f_7152posixunix.scm",(void*)f_7152},
{"f_7150posixunix.scm",(void*)f_7150},
{"f_7234posixunix.scm",(void*)f_7234},
{"f_7025posixunix.scm",(void*)f_7025},
{"f_7037posixunix.scm",(void*)f_7037},
{"f_7032posixunix.scm",(void*)f_7032},
{"f_7027posixunix.scm",(void*)f_7027},
{"f_6965posixunix.scm",(void*)f_6965},
{"f_6977posixunix.scm",(void*)f_6977},
{"f_6972posixunix.scm",(void*)f_6972},
{"f_6967posixunix.scm",(void*)f_6967},
{"f_6904posixunix.scm",(void*)f_6904},
{"f_6959posixunix.scm",(void*)f_6959},
{"f_6963posixunix.scm",(void*)f_6963},
{"f_6925posixunix.scm",(void*)f_6925},
{"f_6928posixunix.scm",(void*)f_6928},
{"f_6939posixunix.scm",(void*)f_6939},
{"f_6933posixunix.scm",(void*)f_6933},
{"f_6906posixunix.scm",(void*)f_6906},
{"f_6915posixunix.scm",(void*)f_6915},
{"f_6840posixunix.scm",(void*)f_6840},
{"f_6852posixunix.scm",(void*)f_6852},
{"f_6883posixunix.scm",(void*)f_6883},
{"f_6863posixunix.scm",(void*)f_6863},
{"f_6879posixunix.scm",(void*)f_6879},
{"f_6867posixunix.scm",(void*)f_6867},
{"f_6875posixunix.scm",(void*)f_6875},
{"f_6871posixunix.scm",(void*)f_6871},
{"f_6846posixunix.scm",(void*)f_6846},
{"f_6829posixunix.scm",(void*)f_6829},
{"f_6833posixunix.scm",(void*)f_6833},
{"f_6818posixunix.scm",(void*)f_6818},
{"f_6822posixunix.scm",(void*)f_6822},
{"f_6773posixunix.scm",(void*)f_6773},
{"f_6777posixunix.scm",(void*)f_6777},
{"f_6780posixunix.scm",(void*)f_6780},
{"f_6783posixunix.scm",(void*)f_6783},
{"f_6796posixunix.scm",(void*)f_6796},
{"f_6800posixunix.scm",(void*)f_6800},
{"f_6803posixunix.scm",(void*)f_6803},
{"f_6806posixunix.scm",(void*)f_6806},
{"f_6794posixunix.scm",(void*)f_6794},
{"f_6757posixunix.scm",(void*)f_6757},
{"f_6740posixunix.scm",(void*)f_6740},
{"f_6753posixunix.scm",(void*)f_6753},
{"f_6665posixunix.scm",(void*)f_6665},
{"f_6726posixunix.scm",(void*)f_6726},
{"f_6739posixunix.scm",(void*)f_6739},
{"f_6706posixunix.scm",(void*)f_6706},
{"f_6721posixunix.scm",(void*)f_6721},
{"f_6715posixunix.scm",(void*)f_6715},
{"f_6669posixunix.scm",(void*)f_6669},
{"f_6671posixunix.scm",(void*)f_6671},
{"f_6692posixunix.scm",(void*)f_6692},
{"f_6686posixunix.scm",(void*)f_6686},
{"f_6613posixunix.scm",(void*)f_6613},
{"f_6620posixunix.scm",(void*)f_6620},
{"f_6639posixunix.scm",(void*)f_6639},
{"f_6643posixunix.scm",(void*)f_6643},
{"f_6607posixunix.scm",(void*)f_6607},
{"f_6598posixunix.scm",(void*)f_6598},
{"f_6602posixunix.scm",(void*)f_6602},
{"f_6571posixunix.scm",(void*)f_6571},
{"f_6564posixunix.scm",(void*)f_6564},
{"f_6561posixunix.scm",(void*)f_6561},
{"f_6558posixunix.scm",(void*)f_6558},
{"f_6480posixunix.scm",(void*)f_6480},
{"f_6516posixunix.scm",(void*)f_6516},
{"f_6510posixunix.scm",(void*)f_6510},
{"f_6463posixunix.scm",(void*)f_6463},
{"f_6281posixunix.scm",(void*)f_6281},
{"f_6415posixunix.scm",(void*)f_6415},
{"f_6410posixunix.scm",(void*)f_6410},
{"f_6283posixunix.scm",(void*)f_6283},
{"f_6293posixunix.scm",(void*)f_6293},
{"f_6301posixunix.scm",(void*)f_6301},
{"f_6347posixunix.scm",(void*)f_6347},
{"f_6314posixunix.scm",(void*)f_6314},
{"f_6339posixunix.scm",(void*)f_6339},
{"f_6317posixunix.scm",(void*)f_6317},
{"f_6262posixunix.scm",(void*)f_6262},
{"f_6243posixunix.scm",(void*)f_6243},
{"f_6201posixunix.scm",(void*)f_6201},
{"f_6223posixunix.scm",(void*)f_6223},
{"f_6227posixunix.scm",(void*)f_6227},
{"f_6089posixunix.scm",(void*)f_6089},
{"f_6095posixunix.scm",(void*)f_6095},
{"f_6116posixunix.scm",(void*)f_6116},
{"f_6193posixunix.scm",(void*)f_6193},
{"f_6120posixunix.scm",(void*)f_6120},
{"f_6123posixunix.scm",(void*)f_6123},
{"f_6126posixunix.scm",(void*)f_6126},
{"f_6133posixunix.scm",(void*)f_6133},
{"f_6135posixunix.scm",(void*)f_6135},
{"f_6152posixunix.scm",(void*)f_6152},
{"f_6162posixunix.scm",(void*)f_6162},
{"f_6166posixunix.scm",(void*)f_6166},
{"f_6110posixunix.scm",(void*)f_6110},
{"f_6077posixunix.scm",(void*)f_6077},
{"f_6081posixunix.scm",(void*)f_6081},
{"f_6084posixunix.scm",(void*)f_6084},
{"f_6042posixunix.scm",(void*)f_6042},
{"f_6046posixunix.scm",(void*)f_6046},
{"f_6066posixunix.scm",(void*)f_6066},
{"f_6070posixunix.scm",(void*)f_6070},
{"f_6019posixunix.scm",(void*)f_6019},
{"f_6023posixunix.scm",(void*)f_6023},
{"f_5987posixunix.scm",(void*)f_5987},
{"f_5991posixunix.scm",(void*)f_5991},
{"f_5968posixunix.scm",(void*)f_5968},
{"f_5972posixunix.scm",(void*)f_5972},
{"f_5975posixunix.scm",(void*)f_5975},
{"f_5909posixunix.scm",(void*)f_5909},
{"f_5913posixunix.scm",(void*)f_5913},
{"f_5919posixunix.scm",(void*)f_5919},
{"f_5902posixunix.scm",(void*)f_5902},
{"f_5886posixunix.scm",(void*)f_5886},
{"f_5874posixunix.scm",(void*)f_5874},
{"f_5846posixunix.scm",(void*)f_5846},
{"f_5853posixunix.scm",(void*)f_5853},
{"f_5818posixunix.scm",(void*)f_5818},
{"f_5825posixunix.scm",(void*)f_5825},
{"f_5772posixunix.scm",(void*)f_5772},
{"f_5776posixunix.scm",(void*)f_5776},
{"f_5789posixunix.scm",(void*)f_5789},
{"f_5793posixunix.scm",(void*)f_5793},
{"f_5690posixunix.scm",(void*)f_5690},
{"f_5694posixunix.scm",(void*)f_5694},
{"f_5700posixunix.scm",(void*)f_5700},
{"f_5722posixunix.scm",(void*)f_5722},
{"f_5719posixunix.scm",(void*)f_5719},
{"f_5709posixunix.scm",(void*)f_5709},
{"f_5657posixunix.scm",(void*)f_5657},
{"f_5661posixunix.scm",(void*)f_5661},
{"f_5638posixunix.scm",(void*)f_5638},
{"f_5629posixunix.scm",(void*)f_5629},
{"f_5623posixunix.scm",(void*)f_5623},
{"f_5614posixunix.scm",(void*)f_5614},
{"f_5579posixunix.scm",(void*)f_5579},
{"f_5517posixunix.scm",(void*)f_5517},
{"f_5521posixunix.scm",(void*)f_5521},
{"f_5527posixunix.scm",(void*)f_5527},
{"f_5546posixunix.scm",(void*)f_5546},
{"f_5533posixunix.scm",(void*)f_5533},
{"f_5414posixunix.scm",(void*)f_5414},
{"f_5420posixunix.scm",(void*)f_5420},
{"f_5424posixunix.scm",(void*)f_5424},
{"f_5432posixunix.scm",(void*)f_5432},
{"f_5458posixunix.scm",(void*)f_5458},
{"f_5462posixunix.scm",(void*)f_5462},
{"f_5450posixunix.scm",(void*)f_5450},
{"f_5394posixunix.scm",(void*)f_5394},
{"f_5402posixunix.scm",(void*)f_5402},
{"f_5377posixunix.scm",(void*)f_5377},
{"f_5388posixunix.scm",(void*)f_5388},
{"f_5392posixunix.scm",(void*)f_5392},
{"f_5351posixunix.scm",(void*)f_5351},
{"f_5375posixunix.scm",(void*)f_5375},
{"f_5358posixunix.scm",(void*)f_5358},
{"f_5308posixunix.scm",(void*)f_5308},
{"f_5315posixunix.scm",(void*)f_5315},
{"f_5336posixunix.scm",(void*)f_5336},
{"f_5332posixunix.scm",(void*)f_5332},
{"f_5280posixunix.scm",(void*)f_5280},
{"f_5258posixunix.scm",(void*)f_5258},
{"f_5262posixunix.scm",(void*)f_5262},
{"f_5243posixunix.scm",(void*)f_5243},
{"f_5247posixunix.scm",(void*)f_5247},
{"f_5228posixunix.scm",(void*)f_5228},
{"f_5232posixunix.scm",(void*)f_5232},
{"f_5210posixunix.scm",(void*)f_5210},
{"f_5136posixunix.scm",(void*)f_5136},
{"f_5158posixunix.scm",(void*)f_5158},
{"f_5164posixunix.scm",(void*)f_5164},
{"f_5097posixunix.scm",(void*)f_5097},
{"f_5125posixunix.scm",(void*)f_5125},
{"f_5121posixunix.scm",(void*)f_5121},
{"f_5114posixunix.scm",(void*)f_5114},
{"f_4838posixunix.scm",(void*)f_4838},
{"f_5034posixunix.scm",(void*)f_5034},
{"f_5029posixunix.scm",(void*)f_5029},
{"f_5024posixunix.scm",(void*)f_5024},
{"f_4840posixunix.scm",(void*)f_4840},
{"f_4844posixunix.scm",(void*)f_4844},
{"f_4950posixunix.scm",(void*)f_4950},
{"f_4951posixunix.scm",(void*)f_4951},
{"f_4968posixunix.scm",(void*)f_4968},
{"f_4978posixunix.scm",(void*)f_4978},
{"f_4936posixunix.scm",(void*)f_4936},
{"f_4892posixunix.scm",(void*)f_4892},
{"f_4928posixunix.scm",(void*)f_4928},
{"f_4907posixunix.scm",(void*)f_4907},
{"f_4917posixunix.scm",(void*)f_4917},
{"f_4901posixunix.scm",(void*)f_4901},
{"f_4896posixunix.scm",(void*)f_4896},
{"f_4899posixunix.scm",(void*)f_4899},
{"f_4846posixunix.scm",(void*)f_4846},
{"f_4881posixunix.scm",(void*)f_4881},
{"f_4862posixunix.scm",(void*)f_4862},
{"f_4364posixunix.scm",(void*)f_4364},
{"f_4760posixunix.scm",(void*)f_4760},
{"f_4755posixunix.scm",(void*)f_4755},
{"f_4750posixunix.scm",(void*)f_4750},
{"f_4745posixunix.scm",(void*)f_4745},
{"f_4366posixunix.scm",(void*)f_4366},
{"f_4370posixunix.scm",(void*)f_4370},
{"f_4376posixunix.scm",(void*)f_4376},
{"f_4618posixunix.scm",(void*)f_4618},
{"f_4624posixunix.scm",(void*)f_4624},
{"f_4720posixunix.scm",(void*)f_4720},
{"f_4710posixunix.scm",(void*)f_4710},
{"f_4704posixunix.scm",(void*)f_4704},
{"f_4626posixunix.scm",(void*)f_4626},
{"f_4676posixunix.scm",(void*)f_4676},
{"f_4633posixunix.scm",(void*)f_4633},
{"f_4643posixunix.scm",(void*)f_4643},
{"f_4542posixunix.scm",(void*)f_4542},
{"f_4550posixunix.scm",(void*)f_4550},
{"f_4552posixunix.scm",(void*)f_4552},
{"f_4600posixunix.scm",(void*)f_4600},
{"f_4533posixunix.scm",(void*)f_4533},
{"f_4537posixunix.scm",(void*)f_4537},
{"f_4512posixunix.scm",(void*)f_4512},
{"f_4522posixunix.scm",(void*)f_4522},
{"f_4500posixunix.scm",(void*)f_4500},
{"f_4487posixunix.scm",(void*)f_4487},
{"f_4491posixunix.scm",(void*)f_4491},
{"f_4482posixunix.scm",(void*)f_4482},
{"f_4485posixunix.scm",(void*)f_4485},
{"f_4400posixunix.scm",(void*)f_4400},
{"f_4412posixunix.scm",(void*)f_4412},
{"f_4449posixunix.scm",(void*)f_4449},
{"f_4458posixunix.scm",(void*)f_4458},
{"f_4452posixunix.scm",(void*)f_4452},
{"f_4428posixunix.scm",(void*)f_4428},
{"f_4431posixunix.scm",(void*)f_4431},
{"f_4392posixunix.scm",(void*)f_4392},
{"f_4377posixunix.scm",(void*)f_4377},
{"f_4391posixunix.scm",(void*)f_4391},
{"f_4337posixunix.scm",(void*)f_4337},
{"f_4344posixunix.scm",(void*)f_4344},
{"f_4347posixunix.scm",(void*)f_4347},
{"f_4292posixunix.scm",(void*)f_4292},
{"f_4296posixunix.scm",(void*)f_4296},
{"f_4331posixunix.scm",(void*)f_4331},
{"f_4314posixunix.scm",(void*)f_4314},
{"f_4278posixunix.scm",(void*)f_4278},
{"f_4290posixunix.scm",(void*)f_4290},
{"f_4264posixunix.scm",(void*)f_4264},
{"f_4276posixunix.scm",(void*)f_4276},
{"f_4249posixunix.scm",(void*)f_4249},
{"f_4262posixunix.scm",(void*)f_4262},
{"f_4212posixunix.scm",(void*)f_4212},
{"f_4220posixunix.scm",(void*)f_4220},
{"f_4187posixunix.scm",(void*)f_4187},
{"f_4168posixunix.scm",(void*)f_4168},
{"f_4172posixunix.scm",(void*)f_4172},
{"f_4137posixunix.scm",(void*)f_4137},
{"f_4161posixunix.scm",(void*)f_4161},
{"f_4145posixunix.scm",(void*)f_4145},
{"f_4148posixunix.scm",(void*)f_4148},
{"f_4099posixunix.scm",(void*)f_4099},
{"f_4132posixunix.scm",(void*)f_4132},
{"f_4120posixunix.scm",(void*)f_4120},
{"f_4128posixunix.scm",(void*)f_4128},
{"f_4124posixunix.scm",(void*)f_4124},
{"f_4074posixunix.scm",(void*)f_4074},
{"f_4090posixunix.scm",(void*)f_4090},
{"f_4059posixunix.scm",(void*)f_4059},
{"f_4069posixunix.scm",(void*)f_4069},
{"f_4063posixunix.scm",(void*)f_4063},
{"f_4053posixunix.scm",(void*)f_4053},
{"f_4047posixunix.scm",(void*)f_4047},
{"f_4041posixunix.scm",(void*)f_4041},
{"f_4017posixunix.scm",(void*)f_4017},
{"f_4039posixunix.scm",(void*)f_4039},
{"f_4035posixunix.scm",(void*)f_4035},
{"f_4027posixunix.scm",(void*)f_4027},
{"f_3987posixunix.scm",(void*)f_3987},
{"f_4015posixunix.scm",(void*)f_4015},
{"f_4011posixunix.scm",(void*)f_4011},
{"f_3960posixunix.scm",(void*)f_3960},
{"f_3985posixunix.scm",(void*)f_3985},
{"f_3981posixunix.scm",(void*)f_3981},
{"f_3896posixunix.scm",(void*)f_3896},
{"f_3884posixunix.scm",(void*)f_3884},
{"f_3912posixunix.scm",(void*)f_3912},
{"f_3822posixunix.scm",(void*)f_3822},
{"f_3826posixunix.scm",(void*)f_3826},
{"f_3831posixunix.scm",(void*)f_3831},
{"f_3847posixunix.scm",(void*)f_3847},
{"f_3759posixunix.scm",(void*)f_3759},
{"f_3817posixunix.scm",(void*)f_3817},
{"f_3763posixunix.scm",(void*)f_3763},
{"f_3766posixunix.scm",(void*)f_3766},
{"f_3798posixunix.scm",(void*)f_3798},
{"f_3769posixunix.scm",(void*)f_3769},
{"f_3774posixunix.scm",(void*)f_3774},
{"f_3788posixunix.scm",(void*)f_3788},
{"f_3752posixunix.scm",(void*)f_3752},
{"f_3666posixunix.scm",(void*)f_3666},
{"f_3670posixunix.scm",(void*)f_3670},
{"f_3724posixunix.scm",(void*)f_3724},
{"f_3673posixunix.scm",(void*)f_3673},
{"f_3683posixunix.scm",(void*)f_3683},
{"f_3687posixunix.scm",(void*)f_3687},
{"f_3696posixunix.scm",(void*)f_3696},
{"f_3700posixunix.scm",(void*)f_3700},
{"f_3710posixunix.scm",(void*)f_3710},
{"f_3691posixunix.scm",(void*)f_3691},
{"f_3641posixunix.scm",(void*)f_3641},
{"f_3653posixunix.scm",(void*)f_3653},
{"f_3649posixunix.scm",(void*)f_3649},
{"f_3627posixunix.scm",(void*)f_3627},
{"f_3639posixunix.scm",(void*)f_3639},
{"f_3635posixunix.scm",(void*)f_3635},
{"f_3560posixunix.scm",(void*)f_3560},
{"f_3564posixunix.scm",(void*)f_3564},
{"f_3606posixunix.scm",(void*)f_3606},
{"f_3567posixunix.scm",(void*)f_3567},
{"f_3577posixunix.scm",(void*)f_3577},
{"f_3581posixunix.scm",(void*)f_3581},
{"f_3585posixunix.scm",(void*)f_3585},
{"f_3589posixunix.scm",(void*)f_3589},
{"f_3593posixunix.scm",(void*)f_3593},
{"f_3537posixunix.scm",(void*)f_3537},
{"f_3547posixunix.scm",(void*)f_3547},
{"f_3514posixunix.scm",(void*)f_3514},
{"f_3524posixunix.scm",(void*)f_3524},
{"f_3476posixunix.scm",(void*)f_3476},
{"f_3509posixunix.scm",(void*)f_3509},
{"f_3480posixunix.scm",(void*)f_3480},
{"f_3487posixunix.scm",(void*)f_3487},
{"f_3491posixunix.scm",(void*)f_3491},
{"f_3495posixunix.scm",(void*)f_3495},
{"f_3499posixunix.scm",(void*)f_3499},
{"f_3503posixunix.scm",(void*)f_3503},
{"f_3458posixunix.scm",(void*)f_3458},
{"f_3443posixunix.scm",(void*)f_3443},
{"f_3437posixunix.scm",(void*)f_3437},
{"f_3405posixunix.scm",(void*)f_3405},
{"f_3411posixunix.scm",(void*)f_3411},
{"f_3381posixunix.scm",(void*)f_3381},
{"f_3399posixunix.scm",(void*)f_3399},
{"f_3388posixunix.scm",(void*)f_3388},
{"f_3363posixunix.scm",(void*)f_3363},
{"f_3373posixunix.scm",(void*)f_3373},
{"f_3350posixunix.scm",(void*)f_3350},
{"f_3341posixunix.scm",(void*)f_3341},
{"f_3294posixunix.scm",(void*)f_3294},
{"f_3298posixunix.scm",(void*)f_3298},
{"f_3274posixunix.scm",(void*)f_3274},
{"f_3278posixunix.scm",(void*)f_3278},
{"f_3284posixunix.scm",(void*)f_3284},
{"f_3288posixunix.scm",(void*)f_3288},
{"f_3254posixunix.scm",(void*)f_3254},
{"f_3258posixunix.scm",(void*)f_3258},
{"f_3264posixunix.scm",(void*)f_3264},
{"f_3268posixunix.scm",(void*)f_3268},
{"f_3230posixunix.scm",(void*)f_3230},
{"f_3234posixunix.scm",(void*)f_3234},
{"f_3245posixunix.scm",(void*)f_3245},
{"f_3249posixunix.scm",(void*)f_3249},
{"f_3239posixunix.scm",(void*)f_3239},
{"f_3206posixunix.scm",(void*)f_3206},
{"f_3210posixunix.scm",(void*)f_3210},
{"f_3221posixunix.scm",(void*)f_3221},
{"f_3225posixunix.scm",(void*)f_3225},
{"f_3215posixunix.scm",(void*)f_3215},
{"f_3190posixunix.scm",(void*)f_3190},
{"f_3194posixunix.scm",(void*)f_3194},
{"f_3197posixunix.scm",(void*)f_3197},
{"f_3154posixunix.scm",(void*)f_3154},
{"f_3185posixunix.scm",(void*)f_3185},
{"f_3175posixunix.scm",(void*)f_3175},
{"f_3168posixunix.scm",(void*)f_3168},
{"f_3118posixunix.scm",(void*)f_3118},
{"f_3149posixunix.scm",(void*)f_3149},
{"f_3139posixunix.scm",(void*)f_3139},
{"f_3132posixunix.scm",(void*)f_3132},
{"f_3103posixunix.scm",(void*)f_3103},
{"f_3116posixunix.scm",(void*)f_3116},
{"f_3097posixunix.scm",(void*)f_3097},
{"f_3085posixunix.scm",(void*)f_3085},
{"f_2768posixunix.scm",(void*)f_2768},
{"f_3075posixunix.scm",(void*)f_3075},
{"f_2895posixunix.scm",(void*)f_2895},
{"f_3061posixunix.scm",(void*)f_3061},
{"f_3050posixunix.scm",(void*)f_3050},
{"f_3057posixunix.scm",(void*)f_3057},
{"f_2914posixunix.scm",(void*)f_2914},
{"f_3043posixunix.scm",(void*)f_3043},
{"f_3022posixunix.scm",(void*)f_3022},
{"f_3039posixunix.scm",(void*)f_3039},
{"f_3028posixunix.scm",(void*)f_3028},
{"f_3035posixunix.scm",(void*)f_3035},
{"f_2958posixunix.scm",(void*)f_2958},
{"f_3019posixunix.scm",(void*)f_3019},
{"f_2998posixunix.scm",(void*)f_2998},
{"f_3015posixunix.scm",(void*)f_3015},
{"f_3004posixunix.scm",(void*)f_3004},
{"f_3011posixunix.scm",(void*)f_3011},
{"f_2971posixunix.scm",(void*)f_2971},
{"f_2995posixunix.scm",(void*)f_2995},
{"f_2991posixunix.scm",(void*)f_2991},
{"f_2952posixunix.scm",(void*)f_2952},
{"f_2921posixunix.scm",(void*)f_2921},
{"f_2939posixunix.scm",(void*)f_2939},
{"f_2924posixunix.scm",(void*)f_2924},
{"f_2928posixunix.scm",(void*)f_2928},
{"f_2908posixunix.scm",(void*)f_2908},
{"f_2889posixunix.scm",(void*)f_2889},
{"f_2775posixunix.scm",(void*)f_2775},
{"f_2782posixunix.scm",(void*)f_2782},
{"f_2784posixunix.scm",(void*)f_2784},
{"f_2791posixunix.scm",(void*)f_2791},
{"f_2855posixunix.scm",(void*)f_2855},
{"f_2864posixunix.scm",(void*)f_2864},
{"f_2852posixunix.scm",(void*)f_2852},
{"f_2797posixunix.scm",(void*)f_2797},
{"f_2833posixunix.scm",(void*)f_2833},
{"f_2829posixunix.scm",(void*)f_2829},
{"f_2825posixunix.scm",(void*)f_2825},
{"f_2814posixunix.scm",(void*)f_2814},
{"f_2810posixunix.scm",(void*)f_2810},
{"f_2712posixunix.scm",(void*)f_2712},
{"f_2721posixunix.scm",(void*)f_2721},
{"f_2745posixunix.scm",(void*)f_2745},
{"f_2757posixunix.scm",(void*)f_2757},
{"f_2763posixunix.scm",(void*)f_2763},
{"f_2751posixunix.scm",(void*)f_2751},
{"f_2727posixunix.scm",(void*)f_2727},
{"f_2733posixunix.scm",(void*)f_2733},
{"f_2719posixunix.scm",(void*)f_2719},
{"f_2701posixunix.scm",(void*)f_2701},
{"f_2696posixunix.scm",(void*)f_2696},
{"f_2648posixunix.scm",(void*)f_2648},
{"f_2652posixunix.scm",(void*)f_2652},
{"f_2661posixunix.scm",(void*)f_2661},
{"f_2625posixunix.scm",(void*)f_2625},
{"f_2646posixunix.scm",(void*)f_2646},
{"f_2632posixunix.scm",(void*)f_2632},
{"f_2468posixunix.scm",(void*)f_2468},
{"f_2573posixunix.scm",(void*)f_2573},
{"f_2581posixunix.scm",(void*)f_2581},
{"f_2568posixunix.scm",(void*)f_2568},
{"f_2470posixunix.scm",(void*)f_2470},
{"f_2477posixunix.scm",(void*)f_2477},
{"f_2480posixunix.scm",(void*)f_2480},
{"f_2483posixunix.scm",(void*)f_2483},
{"f_2567posixunix.scm",(void*)f_2567},
{"f_2487posixunix.scm",(void*)f_2487},
{"f_2501posixunix.scm",(void*)f_2501},
{"f_2511posixunix.scm",(void*)f_2511},
{"f_2514posixunix.scm",(void*)f_2514},
{"f_2517posixunix.scm",(void*)f_2517},
{"f_2523posixunix.scm",(void*)f_2523},
{"f_2533posixunix.scm",(void*)f_2533},
{"f_2444posixunix.scm",(void*)f_2444},
{"f_2466posixunix.scm",(void*)f_2466},
{"f_2462posixunix.scm",(void*)f_2462},
{"f_2420posixunix.scm",(void*)f_2420},
{"f_2442posixunix.scm",(void*)f_2442},
{"f_2438posixunix.scm",(void*)f_2438},
{"f_2396posixunix.scm",(void*)f_2396},
{"f_2418posixunix.scm",(void*)f_2418},
{"f_2414posixunix.scm",(void*)f_2414},
{"f_2334posixunix.scm",(void*)f_2334},
{"f_2347posixunix.scm",(void*)f_2347},
{"f_2359posixunix.scm",(void*)f_2359},
{"f_2353posixunix.scm",(void*)f_2353},
{"f_2325posixunix.scm",(void*)f_2325},
{"f_2332posixunix.scm",(void*)f_2332},
{"f_2316posixunix.scm",(void*)f_2316},
{"f_2323posixunix.scm",(void*)f_2323},
{"f_2307posixunix.scm",(void*)f_2307},
{"f_2314posixunix.scm",(void*)f_2314},
{"f_2298posixunix.scm",(void*)f_2298},
{"f_2305posixunix.scm",(void*)f_2305},
{"f_2289posixunix.scm",(void*)f_2289},
{"f_2296posixunix.scm",(void*)f_2296},
{"f_2280posixunix.scm",(void*)f_2280},
{"f_2287posixunix.scm",(void*)f_2287},
{"f_2271posixunix.scm",(void*)f_2271},
{"f_2278posixunix.scm",(void*)f_2278},
{"f_2262posixunix.scm",(void*)f_2262},
{"f_2269posixunix.scm",(void*)f_2269},
{"f_2253posixunix.scm",(void*)f_2253},
{"f_2260posixunix.scm",(void*)f_2260},
{"f_2247posixunix.scm",(void*)f_2247},
{"f_2251posixunix.scm",(void*)f_2251},
{"f_2241posixunix.scm",(void*)f_2241},
{"f_2245posixunix.scm",(void*)f_2245},
{"f_2235posixunix.scm",(void*)f_2235},
{"f_2239posixunix.scm",(void*)f_2239},
{"f_2229posixunix.scm",(void*)f_2229},
{"f_2233posixunix.scm",(void*)f_2233},
{"f_2223posixunix.scm",(void*)f_2223},
{"f_2227posixunix.scm",(void*)f_2227},
{"f_2217posixunix.scm",(void*)f_2217},
{"f_2221posixunix.scm",(void*)f_2221},
{"f_2185posixunix.scm",(void*)f_2185},
{"f_2196posixunix.scm",(void*)f_2196},
{"f_2189posixunix.scm",(void*)f_2189},
{"f_2148posixunix.scm",(void*)f_2148},
{"f_2180posixunix.scm",(void*)f_2180},
{"f_2173posixunix.scm",(void*)f_2173},
{"f_2152posixunix.scm",(void*)f_2152},
{"f_1956posixunix.scm",(void*)f_1956},
{"f_2129posixunix.scm",(void*)f_2129},
{"f_1972posixunix.scm",(void*)f_1972},
{"f_2103posixunix.scm",(void*)f_2103},
{"f_1978posixunix.scm",(void*)f_1978},
{"f_1981posixunix.scm",(void*)f_1981},
{"f_2063posixunix.scm",(void*)f_2063},
{"f_2061posixunix.scm",(void*)f_2061},
{"f_2020posixunix.scm",(void*)f_2020},
{"f_2038posixunix.scm",(void*)f_2038},
{"f_2036posixunix.scm",(void*)f_2036},
{"f_2024posixunix.scm",(void*)f_2024},
{"f_1946posixunix.scm",(void*)f_1946},
{"f_1936posixunix.scm",(void*)f_1936},
{"f_1930posixunix.scm",(void*)f_1930},
{"f_1898posixunix.scm",(void*)f_1898},
{"f_1905posixunix.scm",(void*)f_1905},
{"f_1911posixunix.scm",(void*)f_1911},
{"f_1918posixunix.scm",(void*)f_1918},
{"f_1859posixunix.scm",(void*)f_1859},
{"f_1866posixunix.scm",(void*)f_1866},
{"f_1875posixunix.scm",(void*)f_1875},
{"f_1817posixunix.scm",(void*)f_1817},
{"f_1827posixunix.scm",(void*)f_1827},
{"f_1830posixunix.scm",(void*)f_1830},
{"f_1833posixunix.scm",(void*)f_1833},
{"f_1802posixunix.scm",(void*)f_1802},
{"f_1764posixunix.scm",(void*)f_1764},
{"f_1794posixunix.scm",(void*)f_1794},
{"f_1781posixunix.scm",(void*)f_1781},
{"f_1784posixunix.scm",(void*)f_1784},
{"f_1718posixunix.scm",(void*)f_1718},
{"f_1722posixunix.scm",(void*)f_1722},
{"f_1661posixunix.scm",(void*)f_1661},
{"f_1654posixunix.scm",(void*)f_1654},
{"f_1636posixunix.scm",(void*)f_1636},
{"f_1640posixunix.scm",(void*)f_1640},
{"f_1651posixunix.scm",(void*)f_1651},
{"f_1647posixunix.scm",(void*)f_1647},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
