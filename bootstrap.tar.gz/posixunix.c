/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-01 09:35
   Version 3.0.0rc1 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook lockts ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-17 on dill (Linux)
   command line: posixunix.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
#endif
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)

#ifdef C_GNU_ENV
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__CYGWIN__) || defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set_9(v) \
        (C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)))

#define C_tm_get_08(v) \
        (C_set_block_item(v, 0, C_fix(C_tm.tm_sec)), \
        C_set_block_item(v, 1, C_fix(C_tm.tm_min)), \
        C_set_block_item(v, 2, C_fix(C_tm.tm_hour)), \
        C_set_block_item(v, 3, C_fix(C_tm.tm_mday)), \
        C_set_block_item(v, 4, C_fix(C_tm.tm_mon)), \
        C_set_block_item(v, 5, C_fix(C_tm.tm_year)), \
        C_set_block_item(v, 6, C_fix(C_tm.tm_wday)), \
        C_set_block_item(v, 7, C_fix(C_tm.tm_yday)), \
        C_set_block_item(v, 8, (C_tm.tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define C_tm_get_9(v) \
        (C_set_block_item(v, 9, C_fix(C_tm.tm_gmtoff)))

#if 0
#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)
# define C_tm_set(v) (C_tm_set_08(v), &C_tm)
# define C_tm_get(v) (C_tm_get_08(v), v)
#else
# define C_tm_set(v) (C_tm_set_08(v), C_tm_set_9(v), &C_tm)
# define C_tm_get(v) (C_tm_get_08(v), C_tm_get_9(v), v)
#endif
#else
#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)
static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  return &C_tm;
}
static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  C_tm_set_9 (v);
  return v;
}
#else
static struct tm *
C_tm_set (C_word v)
{
  C_tm_set_08 (v);
  return &C_tm;
}
static C_word
C_tm_get (C_word v)
{
  C_tm_get_08 (v);
  C_tm_get_9 (v);
  return v;
}
#endif
#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[428];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,38),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,55,32,108,111,99,56,32,109,115,103,57,32,46,32,97,114,103,115,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,49,50,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,49,54,49,57,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,51,48,32,99,109,100,51,49,32,46,32,103,50,57,51,50,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,52,49,32,102,108,97,103,115,52,50,32,46,32,109,111,100,101,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,99,108,111,115,101,32,102,100,53,48,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,114,101,97,100,32,102,100,53,51,32,115,105,122,101,53,52,32,46,32,98,117,102,102,101,114,53,53,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,119,114,105,116,101,32,102,100,54,50,32,98,117,102,102,101,114,54,51,32,46,32,115,105,122,101,54,52,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,55,49,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,9),40,102,100,95,122,101,114,111,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,14),40,102,100,95,115,101,116,32,97,56,52,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,15),40,102,100,95,116,101,115,116,32,97,57,48,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,49,57,54,51,32,102,100,49,50,49,41,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,97,49,57,56,56,32,102,100,49,49,56,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,13),40,97,50,48,50,56,32,102,100,49,49,49,41,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,50,48,53,52,32,102,100,49,48,52,41,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,57,54,32,102,100,115,119,57,55,32,46,32,116,105,109,101,111,117,116,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,49,50,55,32,108,105,110,107,49,50,56,32,108,111,99,49,50,57,41,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,49,51,50,32,46,32,108,105,110,107,49,51,51,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,49,51,55,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,49,51,57,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,49,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,49,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,49,52,53,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,49,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,49,52,57,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,49,53,51,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,49,53,55,32,112,111,115,49,53,56,32,46,32,119,104,101,110,99,101,49,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,54,55,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,54,57,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,55,49,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,49,56,48,32,115,112,101,99,49,56,54,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,49,56,55,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,49,56,51,32,37,115,112,101,99,49,55,56,50,48,54,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,49,56,50,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,32,46,32,103,49,55,54,49,55,55,41,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,50,49,50,41,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,103,50,49,54,50,49,55,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,50,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,50,50,56,32,99,109,100,50,50,57,32,105,110,112,50,51,48,32,114,50,51,49,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,50,51,52,32,46,32,109,50,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,50,52,48,32,46,32,109,50,52,49,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,50,52,54,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,50,54,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,20),40,97,50,54,56,57,32,46,32,114,101,115,117,108,116,115,50,54,52,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,50,54,48,32,112,114,111,99,50,54,49,32,46,32,109,111,100,101,50,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,50,55,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,20),40,97,50,55,49,51,32,46,32,114,101,115,117,108,116,115,50,55,48,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,50,54,54,32,112,114,111,99,50,54,55,32,46,32,109,111,100,101,50,54,56,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,20),40,97,50,55,51,50,32,46,32,114,101,115,117,108,116,115,50,55,55,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,50,55,50,32,116,104,117,110,107,50,55,51,32,46,32,109,111,100,101,50,55,52,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,20),40,97,50,55,53,50,32,46,32,114,101,115,117,108,116,115,50,56,54,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,50,56,49,32,116,104,117,110,107,50,56,50,32,46,32,109,111,100,101,50,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,50,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,50,57,56,32,112,114,111,99,50,57,57,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,51,48,50,32,115,116,97,116,101,51,48,51,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,12),40,97,50,56,54,55,32,115,51,48,57,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,26),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,51,48,56,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,105,103,115,51,49,53,32,109,97,115,107,51,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,51,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,21),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,51,50,49,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,51,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,20),40,115,101,116,45,117,115,101,114,45,105,100,33,32,105,100,51,51,48,41,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,103,114,111,117,112,45,105,100,33,32,105,100,51,51,56,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,36),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,51,52,55,32,46,32,103,51,52,54,51,52,56,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,51,54,56,41,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,38),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,51,54,48,32,46,32,103,51,53,57,51,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,16),40,95,101,110,115,117,114,101,45,103,114,111,117,112,115,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,51,56,52,41,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,19),40,100,111,51,57,48,32,108,115,116,51,57,50,32,105,51,57,51,41,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,51,56,57,41,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,33),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,52,48,57,32,105,100,52,49,48,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,52,49,52,32,109,52,49,53,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,39),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,52,49,56,32,117,105,100,52,49,57,32,103,105,100,52,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,52,50,53,32,97,99,99,52,50,54,32,108,111,99,52,50,55,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,51,50,41};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,52,51,51,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,38),40,115,101,116,45,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,33,32,112,105,100,52,52,48,32,112,103,105,100,52,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,36),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,52,53,48,32,110,101,119,52,53,49,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,29),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,52,53,54,41,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,108,105,110,107,32,111,108,100,52,55,49,32,110,101,119,52,55,50,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,52,55,55,32,109,52,55,56,41,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,32),40,99,104,101,99,107,32,108,111,99,52,56,50,32,102,100,52,56,51,32,105,110,112,52,56,52,32,114,52,56,53,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,52,56,56,32,46,32,109,52,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,52,57,49,32,46,32,109,52,57,50,41};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,52,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,34),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,53,48,49,32,46,32,110,101,119,53,48,50,41,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,8),40,114,101,97,100,121,63,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,7),40,102,101,116,99,104,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,7),40,97,51,57,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,7),40,97,51,57,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,7),40,97,51,57,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,7),40,97,52,48,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,110,53,54,49,32,109,53,54,50,32,115,116,97,114,116,53,54,51,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,37),40,97,52,48,49,48,32,112,111,114,116,53,53,54,32,110,53,53,55,32,100,101,115,116,53,53,56,32,115,116,97,114,116,53,53,57,41,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,22),40,98,117,109,112,101,114,32,99,117,114,53,55,55,32,112,116,114,53,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,7),40,97,52,49,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,30),40,97,52,49,55,56,32,100,101,115,116,53,57,48,53,57,50,32,99,111,110,116,63,53,57,49,53,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,116,114,53,55,53,41,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,24),40,97,52,48,56,54,32,112,111,114,116,53,55,50,32,108,105,109,105,116,53,55,51,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,54),40,98,111,100,121,53,49,57,32,110,111,110,98,108,111,99,107,105,110,103,63,53,50,55,32,98,117,102,105,53,50,56,32,111,110,45,99,108,111,115,101,53,50,57,32,109,111,114,101,63,53,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,62),40,100,101,102,45,109,111,114,101,63,53,50,52,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,49,53,54,48,50,32,37,98,117,102,105,53,49,54,54,48,51,32,37,111,110,45,99,108,111,115,101,53,49,55,54,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,49),40,100,101,102,45,111,110,45,99,108,111,115,101,53,50,51,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,49,53,54,48,54,32,37,98,117,102,105,53,49,54,54,48,55,41,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,117,102,105,53,50,50,32,37,110,111,110,98,108,111,99,107,105,110,103,63,53,49,53,54,48,57,41,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,21),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,53,50,49,41,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,55),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,53,49,49,32,110,97,109,53,49,50,32,102,100,53,49,51,32,46,32,103,53,49,48,53,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,20),40,112,111,107,101,32,115,116,114,54,52,49,32,108,101,110,54,52,50,41,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,14),40,97,52,51,54,57,32,115,116,114,54,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,7),40,97,52,51,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,7),40,97,52,51,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,15),40,102,95,52,52,48,53,32,115,116,114,54,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,29),40,108,111,111,112,32,114,101,109,54,53,49,32,115,116,97,114,116,54,53,50,32,108,101,110,54,53,51,41,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,15),40,102,95,52,52,50,48,32,115,116,114,54,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,45),40,98,111,100,121,54,50,57,32,110,111,110,98,108,111,99,107,105,110,103,63,54,51,54,32,98,117,102,105,54,51,55,32,111,110,45,99,108,111,115,101,54,51,56,41,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,49),40,100,101,102,45,111,110,45,99,108,111,115,101,54,51,51,32,37,110,111,110,98,108,111,99,107,105,110,103,63,54,50,54,54,54,56,32,37,98,117,102,105,54,50,55,54,54,57,41,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,117,102,105,54,51,50,32,37,110,111,110,98,108,111,99,107,105,110,103,63,54,50,54,54,55,49,41,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,21),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,54,51,49,41,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,56),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,54,50,50,32,110,97,109,54,50,51,32,102,100,54,50,52,32,46,32,103,54,50,49,54,50,53,41};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,54,55,57,32,111,102,102,54,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,32,112,111,114,116,54,56,52,32,97,114,103,115,54,56,53,32,108,111,99,54,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,27),40,101,114,114,32,109,115,103,54,57,57,32,108,111,99,107,55,48,48,32,108,111,99,55,48,49,41,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,55,48,50,32,46,32,97,114,103,115,55,48,51,41,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,55,48,53,32,46,32,97,114,103,115,55,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,55,48,56,32,46,32,97,114,103,115,55,48,57,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,21),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,55,49,56,41,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,32),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,55,50,49,32,46,32,109,111,100,101,55,50,50,41};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,19),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,55,50,54,41,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,22),40,115,101,116,101,110,118,32,118,97,114,55,50,57,32,118,97,108,55,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,17),40,117,110,115,101,116,101,110,118,32,118,97,114,55,51,52,41,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,55,52,55,41,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,55,52,52,41,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,21),40,99,117,114,114,101,110,116,45,101,110,118,105,114,111,110,109,101,110,116,41,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,66),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,55,54,56,32,108,101,110,55,54,57,32,112,114,111,116,55,55,48,32,102,108,97,103,55,55,49,32,102,100,55,55,50,32,46,32,111,102,102,55,55,51,41,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,41),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,55,56,56,32,46,32,108,101,110,55,56,57,41,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,36),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,55,57,50,41,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,26),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,55,57,52,41,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,29),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,55,57,53,41,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,27),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,55,57,55,41,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,25),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,56,48,53,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,30),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,56,50,50,32,46,32,103,56,50,49,56,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,31),40,115,116,114,105,110,103,45,62,116,105,109,101,32,116,105,109,56,52,51,32,46,32,103,56,52,50,56,52,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,27),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,56,53,48,41,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,25),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,56,53,51,41,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,17),40,95,101,120,105,116,32,46,32,99,111,100,101,56,54,52,41,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,20),40,115,101,116,45,97,108,97,114,109,33,32,97,56,54,53,56,54,56,41,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,56,54,57,32,109,111,100,101,56,55,48,32,46,32,115,105,122,101,56,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,56,55,56,41};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,56,56,49,32,112,111,114,116,56,56,50,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,23),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,56,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,23),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,57,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0,0,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,7),40,97,53,53,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,110,115,57,52,49,41,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,37),40,97,53,53,55,50,32,100,105,114,57,50,54,57,50,57,32,102,105,108,57,50,55,57,51,48,32,101,120,116,57,50,56,57,51,49,41,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,20),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,57,50,52,41,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,17),40,103,108,111,98,32,46,32,112,97,116,104,115,57,50,50,41,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,16),40,102,95,53,54,56,52,32,97,57,53,52,57,53,55,41};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,57,53,50,41,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,24),40,115,101,116,97,114,103,32,97,57,54,53,57,55,49,32,97,57,54,52,57,55,50,41};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,97,57,55,55,57,56,51,32,97,57,55,54,57,56,52,41};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,14),40,100,111,49,48,48,54,32,105,49,48,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,21),40,100,111,49,48,48,50,32,97,108,49,48,48,52,32,105,49,48,48,53,41,0,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,32),40,98,111,100,121,57,57,51,32,97,114,103,108,105,115,116,57,57,57,32,101,110,118,108,105,115,116,49,48,48,48,41};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,101,110,118,108,105,115,116,57,57,54,32,37,97,114,103,108,105,115,116,57,57,49,49,48,50,57,41};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,114,103,108,105,115,116,57,57,53,41};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,39),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,57,56,57,32,46,32,103,57,56,56,57,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,48,51,53,32,110,111,104,97,110,103,49,48,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,7),40,97,53,57,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,36),40,97,53,57,55,50,32,101,112,105,100,49,48,53,49,32,101,110,111,114,109,49,48,53,50,32,101,99,111,100,101,49,48,53,51,41,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,49,48,51,57,41,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,49,48,53,57,49,48,54,50,41,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,49,48,54,51,32,46,32,115,105,103,49,48,54,52,41,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,48,55,49,41,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,48,55,53,32,46,32,97,114,103,115,49,48,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,7),40,97,54,49,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,29),40,97,54,49,52,56,32,95,49,49,48,48,32,102,108,103,49,49,48,49,32,99,111,100,49,49,48,50,41,0,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,8),40,102,95,54,49,50,56,41};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,111,110,45,99,108,111,115,101,32,108,111,99,49,48,57,52,32,112,105,100,49,48,57,53,32,99,108,115,118,101,99,49,48,57,54,32,105,100,120,49,48,57,55,32,105,100,120,97,49,48,57,56,32,105,100,120,98,49,48,57,57,41,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,7),40,97,54,49,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,19),40,97,54,49,55,55,32,105,49,49,48,54,32,111,49,49,48,55,41,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,101,100,45,112,105,112,101,32,112,111,114,116,49,49,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,34),40,99,111,110,110,101,99,116,45,112,97,114,101,110,116,32,112,105,112,101,49,49,48,57,32,112,111,114,116,49,49,49,48,41,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,43),40,99,111,110,110,101,99,116,45,99,104,105,108,100,32,112,105,112,101,49,49,49,54,32,112,111,114,116,49,49,49,55,32,115,116,100,102,100,49,49,49,56,41,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,14),40,115,119,97,112,112,101,100,45,101,110,100,115,41,0,0,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,7),40,97,54,50,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,67),40,115,112,97,119,110,32,99,109,100,49,49,50,56,32,97,114,103,115,49,49,50,57,32,101,110,118,49,49,51,48,32,115,116,100,111,117,116,102,49,49,51,49,32,115,116,100,105,110,102,49,49,51,50,32,115,116,100,101,114,114,102,49,49,51,51,41,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,59),40,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,49,52,48,32,99,109,100,49,49,52,50,32,112,105,112,101,49,49,52,51,32,115,116,100,102,49,49,52,52,32,111,110,45,99,108,111,115,101,49,49,52,54,41,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,60),40,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,49,52,56,32,99,109,100,49,49,53,48,32,112,105,112,101,49,49,53,49,32,115,116,100,102,49,49,53,50,32,111,110,45,99,108,111,115,101,49,49,53,52,41,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,7),40,97,54,51,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,50),40,97,54,51,48,56,32,105,110,112,105,112,101,49,49,54,51,32,111,117,116,112,105,112,101,49,49,54,52,32,101,114,114,112,105,112,101,49,49,54,53,32,112,105,100,49,49,54,54,41,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,49,49,53,54,32,99,109,100,49,49,53,55,32,97,114,103,115,49,49,53,56,32,101,110,118,49,49,53,57,32,115,116,100,111,117,116,102,49,49,54,48,32,115,116,100,105,110,102,49,49,54,49,32,115,116,100,101,114,114,102,49,49,54,50,41,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,17),40,97,54,51,55,49,32,103,49,49,55,54,49,49,55,55,41,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,49,49,55,53,41,0,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,7),40,97,54,51,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,38),40,97,54,51,57,53,32,105,110,49,49,56,48,32,111,117,116,49,49,56,49,32,112,105,100,49,49,56,50,32,101,114,114,49,49,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,52),40,37,112,114,111,99,101,115,115,32,108,111,99,49,49,54,57,32,101,114,114,63,49,49,55,48,32,99,109,100,49,49,55,49,32,97,114,103,115,49,49,55,50,32,101,110,118,49,49,55,51,41,0,0,0,0};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,49,49,57,50,32,97,114,103,115,49,49,57,56,32,101,110,118,49,49,57,57,41,0,0,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,49,57,53,32,37,97,114,103,115,49,49,57,48,49,50,48,49,41,0,0,0};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,49,57,52,41,0,0,0,0,0,0};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,29),40,112,114,111,99,101,115,115,32,99,109,100,49,49,56,56,32,46,32,103,49,49,56,55,49,49,56,57,41,0,0,0,0,0};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,49,50,49,50,32,97,114,103,115,49,50,49,56,32,101,110,118,49,50,49,57,41,0,0,0};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,49,50,49,53,32,37,97,114,103,115,49,50,49,48,49,50,50,49,41,0,0,0};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,49,50,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,42,32,99,109,100,49,50,48,56,32,46,32,103,49,50,48,55,49,50,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,14),40,102,95,54,54,57,49,32,120,49,50,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,7),40,97,54,54,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,7),40,97,54,54,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,7),40,97,54,54,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,49,50,53,55,32,114,49,50,53,56,41,0,0,0};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,16),40,102,95,54,55,49,48,32,46,32,95,49,50,53,49,41};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,16),40,102,95,54,55,48,50,32,46,32,95,49,50,53,48,41};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,49,50,51,56,32,97,99,116,105,111,110,49,50,52,53,32,105,100,49,50,52,54,32,108,105,109,105,116,49,50,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,49,50,52,50,32,37,97,99,116,105,111,110,49,50,51,53,49,50,55,50,32,37,105,100,49,50,51,54,49,50,55,51,41,0,0,0};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,49,50,52,49,32,37,97,99,116,105,111,110,49,50,51,53,49,50,55,53,41,0,0,0,0};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,19),40,97,54,55,51,48,32,120,49,50,55,55,32,121,49,50,55,56,41,0,0,0};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,49,50,52,48,41};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,49,50,51,50,32,112,114,101,100,49,50,51,51,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,49,50,51,52,41,0,0,0};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,49,50,57,50,41,0,0,0,0,0};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,14),40,97,54,56,50,57,32,112,105,100,52,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,7),40,97,54,56,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,13),40,97,54,56,53,48,32,105,100,51,52,52,41,0,0,0,0,0};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,7),40,97,54,56,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,7),40,97,54,56,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,13),40,97,54,56,55,49,32,105,100,51,51,54,41,0,0,0,0,0};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,7),40,97,54,56,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li239[] C_aligned={C_lihdr(0,0,12),40,97,54,56,56,57,32,110,51,50,55,41,0,0,0,0};
static C_char C_TLS li240[] C_aligned={C_lihdr(0,0,15),40,97,54,56,57,53,32,112,111,114,116,49,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li241[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0};


/* from k6797 in set-root-directory! in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall stub1287(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1287(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k6024 */
static C_word C_fcall stub1060(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1060(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall stub1057(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1057(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall stub1055(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1055(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub986(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub986(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k5730 */
static C_word C_fcall stub979(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub979(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub974(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub974(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k5711 */
static C_word C_fcall stub967(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub967(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k5687 */
static C_word C_fcall stub955(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub955(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub950(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub950(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub910(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub910(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k5496 */
static C_word C_fcall stub896(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub896(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k5473 */
static C_word C_fcall stub886(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub886(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k5362 */
static C_word C_fcall stub866(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub866(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k5340 */
static C_word C_fcall stub861(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub861(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub856(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub856(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub837(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub837(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub816(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub816(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub810(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub810(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k5123 */
static C_word C_fcall stub801(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub801(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k5042 */
static C_word C_fcall stub782(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub782(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k4980 */
static C_word C_fcall stub757(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub757(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k4880 */
static C_word C_fcall stub739(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub739(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k3639 in k3635 in file-link in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall stub463(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub463(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k3355 */
static C_word C_fcall stub403(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub403(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k3224 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub376(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub376(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from k3217 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub372(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub372(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from k3131 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub355(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub355(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a6847 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall stub342(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub342(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a6865 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall stub340(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub340(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a6868 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall stub334(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub334(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a6886 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall stub332(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub332(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k1879 */
static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k1869 */
static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k1859 */
static C_word C_fcall stub81(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub81(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k1641 */
static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from k1590 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub17(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub17(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from k1583 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub13(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub13(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k1559 */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6900)
static void C_ccall f_6900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6903)
static void C_ccall f_6903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6890)
static void C_ccall f_6890(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6887)
static void C_ccall f_6887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6882)
static void C_ccall f_6882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6866)
static void C_ccall f_6866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6861)
static void C_ccall f_6861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6830)
static void C_ccall f_6830(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6843)
static void C_ccall f_6843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6837)
static void C_ccall f_6837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3566)
static void C_ccall f_3566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6807)
static void C_ccall f_6807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6799)
static void C_ccall f_6799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6725)
static void C_fcall f_6725(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6731)
static void C_ccall f_6731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6720)
static void C_fcall f_6720(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6715)
static void C_fcall f_6715(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6544)
static void C_fcall f_6544(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6702)
static void C_ccall f_6702(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6710)
static void C_ccall f_6710(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6551)
static void C_fcall f_6551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6690)
static void C_ccall f_6690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_ccall f_6684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6563)
static void C_fcall f_6563(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6582)
static void C_ccall f_6582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6670)
static void C_ccall f_6670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6677)
static void C_ccall f_6677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6664)
static void C_ccall f_6664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6597)
static void C_ccall f_6597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6657)
static void C_ccall f_6657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6654)
static void C_ccall f_6654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6617)
static void C_ccall f_6617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6632)
static void C_ccall f_6632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6629)
static void C_ccall f_6629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6609)
static void C_ccall f_6609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6482)
static void C_ccall f_6482(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6482)
static void C_ccall f_6482r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6494)
static void C_fcall f_6494(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6489)
static void C_fcall f_6489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6484)
static void C_fcall f_6484(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6434)
static void C_fcall f_6434(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6429)
static void C_fcall f_6429(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6424)
static void C_fcall f_6424(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6361)
static void C_fcall f_6361(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6382)
static void C_ccall f_6382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6385)
static void C_ccall f_6385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6340)
static void C_ccall f_6340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6320)
static void C_ccall f_6320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6328)
static void C_ccall f_6328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6286)
static void C_fcall f_6286(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_fcall f_6275(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6279)
static void C_ccall f_6279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6230)
static void C_fcall f_6230(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_6234)
static void C_ccall f_6234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6237)
static void C_ccall f_6237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_ccall f_6257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6260)
static void C_ccall f_6260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6263)
static void C_ccall f_6263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6251)
static void C_ccall f_6251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6214)
static C_word C_fcall f_6214(C_word *a,C_word t0);
C_noret_decl(f_6197)
static void C_fcall f_6197(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6183)
static void C_fcall f_6183(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6163)
static void C_fcall f_6163(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6126)
static void C_fcall f_6126(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6064)
static void C_ccall f_6064(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5967)
static void C_ccall f_5967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5920)
static void C_ccall f_5920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5738)
static void C_ccall f_5738(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5738)
static void C_ccall f_5738r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5872)
static void C_fcall f_5872(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_fcall f_5867(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5740)
static void C_fcall f_5740(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5758)
static void C_fcall f_5758(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5804)
static C_word C_fcall f_5804(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5771)
static void C_fcall f_5771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5719)
static C_word C_fcall f_5719(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5700)
static C_word C_fcall f_5700(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5658)
static void C_ccall f_5658(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5658)
static void C_ccall f_5658r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5680)
static void C_ccall f_5680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5684)
static void C_ccall f_5684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5552)
static void C_fcall f_5552(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5650)
static void C_ccall f_5650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5583)
static void C_ccall f_5583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_fcall f_5592(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5499)
static void C_ccall f_5499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_fcall f_5444(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5376)
static void C_ccall f_5376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5343)
static void C_ccall f_5343(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5343)
static void C_ccall f_5343r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5237)
static void C_ccall f_5237(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5237)
static void C_ccall f_5237r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_4990)
static void C_ccall f_4990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4889)
static void C_fcall f_4889(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_fcall f_4901(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4784)
static void C_fcall f_4784(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_fcall f_4679(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4605)
static void C_fcall f_4605(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_fcall f_4633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4503)
static void C_fcall f_4503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4498)
static void C_fcall f_4498(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4493)
static void C_fcall f_4493(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4309)
static void C_fcall f_4309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4437)
static void C_fcall f_4437(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4361)
static void C_fcall f_4361(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_fcall f_4315(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4229)
static void C_fcall f_4229(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_fcall f_4224(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4219)
static void C_fcall f_4219(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4214)
static void C_fcall f_4214(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3835)
static void C_fcall f_3835(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4093)
static void C_fcall f_4093(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4019)
static void C_fcall f_4019(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_fcall f_4021(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_fcall f_3869(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_fcall f_3881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static C_word C_fcall f_3861(C_word t0);
C_noret_decl(f_3846)
static void C_fcall f_3846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3813)
static void C_fcall f_3813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3745)
static void C_ccall f_3745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_fcall f_3718(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_fcall f_3681(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3510)
static void C_ccall f_3510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3486)
static void C_fcall f_3486(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3504)
static void C_ccall f_3504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3300)
static void C_fcall f_3300(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_fcall f_3243(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static C_word C_fcall f_3221(C_word t0);
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_fcall f_3142(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_fcall f_3165(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3160)
static void C_ccall f_3160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3108)
static void C_ccall f_3108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_fcall f_3036(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3054)
static void C_ccall f_3054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_fcall f_2880(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2699)
static void C_ccall f_2699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2699)
static void C_ccall f_2699r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_fcall f_2572(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_fcall f_2566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static C_word C_fcall f_2554(C_word t0);
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2436)
static void C_fcall f_2436(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2431)
static void C_fcall f_2431(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2333)
static void C_fcall f_2333(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_fcall f_2364(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_fcall f_2386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_fcall f_2074(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_fcall f_1907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_fcall f_1946(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_fcall f_1950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static C_word C_fcall f_1872(C_word t0,C_word t1);
C_noret_decl(f_1862)
static C_word C_fcall f_1862(C_word t0,C_word t1);
C_noret_decl(f_1856)
static C_word C_fcall f_1856(C_word t0);
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1743)
static void C_ccall f_1743r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6725)
static void C_fcall trf_6725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6725(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6725(t0,t1);}

C_noret_decl(trf_6720)
static void C_fcall trf_6720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6720(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6720(t0,t1,t2);}

C_noret_decl(trf_6715)
static void C_fcall trf_6715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6715(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6715(t0,t1,t2,t3);}

C_noret_decl(trf_6544)
static void C_fcall trf_6544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6544(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6544(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6551)
static void C_fcall trf_6551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6551(t0,t1);}

C_noret_decl(trf_6563)
static void C_fcall trf_6563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6563(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6563(t0,t1,t2,t3);}

C_noret_decl(trf_6494)
static void C_fcall trf_6494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6494(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6494(t0,t1);}

C_noret_decl(trf_6489)
static void C_fcall trf_6489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6489(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6489(t0,t1,t2);}

C_noret_decl(trf_6484)
static void C_fcall trf_6484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6484(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6484(t0,t1,t2,t3);}

C_noret_decl(trf_6434)
static void C_fcall trf_6434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6434(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6434(t0,t1);}

C_noret_decl(trf_6429)
static void C_fcall trf_6429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6429(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6429(t0,t1,t2);}

C_noret_decl(trf_6424)
static void C_fcall trf_6424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6424(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6424(t0,t1,t2,t3);}

C_noret_decl(trf_6361)
static void C_fcall trf_6361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6361(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6361(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6363)
static void C_fcall trf_6363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6363(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6363(t0,t1,t2);}

C_noret_decl(trf_6286)
static void C_fcall trf_6286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6286(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6286(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6275)
static void C_fcall trf_6275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6275(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6275(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6230)
static void C_fcall trf_6230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6230(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6230(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6197)
static void C_fcall trf_6197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6197(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6197(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6183)
static void C_fcall trf_6183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6183(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6183(t0,t1,t2,t3);}

C_noret_decl(trf_6163)
static void C_fcall trf_6163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6163(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6163(t0,t1,t2);}

C_noret_decl(trf_6126)
static void C_fcall trf_6126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6126(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6126(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_5872)
static void C_fcall trf_5872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5872(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5872(t0,t1);}

C_noret_decl(trf_5867)
static void C_fcall trf_5867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5867(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5867(t0,t1,t2);}

C_noret_decl(trf_5740)
static void C_fcall trf_5740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5740(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5740(t0,t1,t2,t3);}

C_noret_decl(trf_5758)
static void C_fcall trf_5758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5758(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5758(t0,t1,t2,t3);}

C_noret_decl(trf_5771)
static void C_fcall trf_5771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5771(t0,t1);}

C_noret_decl(trf_5552)
static void C_fcall trf_5552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5552(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5552(t0,t1,t2);}

C_noret_decl(trf_5592)
static void C_fcall trf_5592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5592(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5592(t0,t1,t2);}

C_noret_decl(trf_5444)
static void C_fcall trf_5444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5444(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5444(t0,t1,t2);}

C_noret_decl(trf_4889)
static void C_fcall trf_4889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4889(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4889(t0,t1,t2);}

C_noret_decl(trf_4901)
static void C_fcall trf_4901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4901(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4901(t0,t1,t2);}

C_noret_decl(trf_4784)
static void C_fcall trf_4784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4784(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4784(t0,t1);}

C_noret_decl(trf_4679)
static void C_fcall trf_4679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4679(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4679(t0,t1,t2,t3);}

C_noret_decl(trf_4605)
static void C_fcall trf_4605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4605(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4605(t0,t1,t2,t3);}

C_noret_decl(trf_4633)
static void C_fcall trf_4633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4633(t0,t1);}

C_noret_decl(trf_4503)
static void C_fcall trf_4503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4503(t0,t1);}

C_noret_decl(trf_4498)
static void C_fcall trf_4498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4498(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4498(t0,t1,t2);}

C_noret_decl(trf_4493)
static void C_fcall trf_4493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4493(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4493(t0,t1,t2,t3);}

C_noret_decl(trf_4309)
static void C_fcall trf_4309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4309(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4309(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4437)
static void C_fcall trf_4437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4437(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4437(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4361)
static void C_fcall trf_4361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4361(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4361(t0,t1);}

C_noret_decl(trf_4315)
static void C_fcall trf_4315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4315(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4315(t0,t1,t2,t3);}

C_noret_decl(trf_4229)
static void C_fcall trf_4229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4229(t0,t1);}

C_noret_decl(trf_4224)
static void C_fcall trf_4224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4224(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4224(t0,t1,t2);}

C_noret_decl(trf_4219)
static void C_fcall trf_4219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4219(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4219(t0,t1,t2,t3);}

C_noret_decl(trf_4214)
static void C_fcall trf_4214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4214(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4214(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3835)
static void C_fcall trf_3835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3835(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3835(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4093)
static void C_fcall trf_4093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4093(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4093(t0,t1,t2);}

C_noret_decl(trf_4019)
static void C_fcall trf_4019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4019(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4019(t0,t1);}

C_noret_decl(trf_4021)
static void C_fcall trf_4021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4021(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4021(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3869)
static void C_fcall trf_3869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3869(t0,t1);}

C_noret_decl(trf_3881)
static void C_fcall trf_3881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3881(t0,t1);}

C_noret_decl(trf_3846)
static void C_fcall trf_3846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3846(t0,t1);}

C_noret_decl(trf_3813)
static void C_fcall trf_3813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3813(t0,t1);}

C_noret_decl(trf_3718)
static void C_fcall trf_3718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3718(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3718(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3681)
static void C_fcall trf_3681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3681(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3681(t0,t1,t2);}

C_noret_decl(trf_3486)
static void C_fcall trf_3486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3486(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3486(t0,t1,t2,t3);}

C_noret_decl(trf_3300)
static void C_fcall trf_3300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3300(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3300(t0,t1,t2,t3);}

C_noret_decl(trf_3243)
static void C_fcall trf_3243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3243(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3243(t0,t1,t2);}

C_noret_decl(trf_3142)
static void C_fcall trf_3142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3142(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3142(t0,t1);}

C_noret_decl(trf_3165)
static void C_fcall trf_3165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3165(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3165(t0,t1,t2);}

C_noret_decl(trf_3036)
static void C_fcall trf_3036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3036(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3036(t0,t1);}

C_noret_decl(trf_2880)
static void C_fcall trf_2880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2880(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2880(t0,t1,t2,t3);}

C_noret_decl(trf_2572)
static void C_fcall trf_2572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2572(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2572(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2566)
static void C_fcall trf_2566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2566(t0,t1);}

C_noret_decl(trf_2436)
static void C_fcall trf_2436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2436(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2436(t0,t1);}

C_noret_decl(trf_2431)
static void C_fcall trf_2431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2431(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2431(t0,t1,t2);}

C_noret_decl(trf_2333)
static void C_fcall trf_2333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2333(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2333(t0,t1,t2,t3);}

C_noret_decl(trf_2364)
static void C_fcall trf_2364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2364(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2364(t0,t1);}

C_noret_decl(trf_2386)
static void C_fcall trf_2386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2386(t0,t1);}

C_noret_decl(trf_2074)
static void C_fcall trf_2074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2074(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2074(t0,t1,t2,t3);}

C_noret_decl(trf_1907)
static void C_fcall trf_1907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1907(t0,t1);}

C_noret_decl(trf_1946)
static void C_fcall trf_1946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1946(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1946(t0,t1);}

C_noret_decl(trf_1950)
static void C_fcall trf_1950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1950(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3160)){
C_save(t1);
C_rereclaim2(3160*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,428);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_h_intern(&lf[51],9,"file-open");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[53]=C_h_intern(&lf[53],17,"\003sysmake-c-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysexpand-home-path");
lf[55]=C_h_intern(&lf[55],10,"file-close");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],10,"file-write");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[65]=C_h_intern(&lf[65],12,"file-mkstemp");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[68]=C_h_intern(&lf[68],11,"file-select");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[70]=C_h_intern(&lf[70],12,"\003sysfor-each");
lf[71]=C_h_intern(&lf[71],8,"seek/set");
lf[72]=C_h_intern(&lf[72],8,"seek/end");
lf[73]=C_h_intern(&lf[73],8,"seek/cur");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[77]=C_h_intern(&lf[77],9,"file-stat");
lf[78]=C_h_intern(&lf[78],9,"file-size");
lf[79]=C_h_intern(&lf[79],22,"file-modification-time");
lf[80]=C_h_intern(&lf[80],16,"file-access-time");
lf[81]=C_h_intern(&lf[81],16,"file-change-time");
lf[82]=C_h_intern(&lf[82],10,"file-owner");
lf[83]=C_h_intern(&lf[83],16,"file-permissions");
lf[84]=C_h_intern(&lf[84],13,"regular-file\077");
lf[85]=C_h_intern(&lf[85],14,"symbolic-link\077");
lf[86]=C_h_intern(&lf[86],18,"set-file-position!");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[88]=C_h_intern(&lf[88],6,"stream");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[90]=C_h_intern(&lf[90],5,"port\077");
lf[91]=C_h_intern(&lf[91],13,"\000bounds-error");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[93]=C_h_intern(&lf[93],13,"file-position");
lf[94]=C_h_intern(&lf[94],16,"create-directory");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[96]=C_h_intern(&lf[96],16,"change-directory");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[98]=C_h_intern(&lf[98],16,"delete-directory");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[100]=C_h_intern(&lf[100],10,"string-ref");
lf[101]=C_h_intern(&lf[101],6,"string");
lf[102]=C_h_intern(&lf[102],9,"directory");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[104]=C_h_intern(&lf[104],16,"\003sysmake-pointer");
lf[105]=C_h_intern(&lf[105],17,"current-directory");
lf[106]=C_h_intern(&lf[106],10,"directory\077");
lf[107]=C_h_intern(&lf[107],13,"\003sysfile-info");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[109]=C_h_intern(&lf[109],5,"\000text");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[112]=C_h_intern(&lf[112],13,"\003sysmake-port");
lf[113]=C_h_intern(&lf[113],21,"\003sysstream-port-class");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[115]=C_h_intern(&lf[115],15,"open-input-pipe");
lf[116]=C_h_intern(&lf[116],7,"\000binary");
lf[117]=C_h_intern(&lf[117],16,"open-output-pipe");
lf[118]=C_h_intern(&lf[118],16,"close-input-pipe");
lf[119]=C_h_intern(&lf[119],23,"close-input/output-pipe");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[121]=C_h_intern(&lf[121],14,"\003syscheck-port");
lf[122]=C_h_intern(&lf[122],17,"close-output-pipe");
lf[123]=C_h_intern(&lf[123],20,"call-with-input-pipe");
lf[124]=C_h_intern(&lf[124],21,"call-with-output-pipe");
lf[125]=C_h_intern(&lf[125],20,"with-input-from-pipe");
lf[126]=C_h_intern(&lf[126],18,"\003sysstandard-input");
lf[127]=C_h_intern(&lf[127],19,"with-output-to-pipe");
lf[128]=C_h_intern(&lf[128],19,"\003sysstandard-output");
lf[129]=C_h_intern(&lf[129],11,"create-pipe");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[131]=C_h_intern(&lf[131],11,"signal/term");
lf[132]=C_h_intern(&lf[132],11,"signal/kill");
lf[133]=C_h_intern(&lf[133],10,"signal/int");
lf[134]=C_h_intern(&lf[134],10,"signal/hup");
lf[135]=C_h_intern(&lf[135],10,"signal/fpe");
lf[136]=C_h_intern(&lf[136],10,"signal/ill");
lf[137]=C_h_intern(&lf[137],11,"signal/segv");
lf[138]=C_h_intern(&lf[138],11,"signal/abrt");
lf[139]=C_h_intern(&lf[139],11,"signal/trap");
lf[140]=C_h_intern(&lf[140],11,"signal/quit");
lf[141]=C_h_intern(&lf[141],11,"signal/alrm");
lf[142]=C_h_intern(&lf[142],13,"signal/vtalrm");
lf[143]=C_h_intern(&lf[143],11,"signal/prof");
lf[144]=C_h_intern(&lf[144],9,"signal/io");
lf[145]=C_h_intern(&lf[145],10,"signal/urg");
lf[146]=C_h_intern(&lf[146],11,"signal/chld");
lf[147]=C_h_intern(&lf[147],11,"signal/cont");
lf[148]=C_h_intern(&lf[148],11,"signal/stop");
lf[149]=C_h_intern(&lf[149],11,"signal/tstp");
lf[150]=C_h_intern(&lf[150],11,"signal/pipe");
lf[151]=C_h_intern(&lf[151],11,"signal/xcpu");
lf[152]=C_h_intern(&lf[152],11,"signal/xfsz");
lf[153]=C_h_intern(&lf[153],11,"signal/usr1");
lf[154]=C_h_intern(&lf[154],11,"signal/usr2");
lf[155]=C_h_intern(&lf[155],12,"signal/winch");
lf[156]=C_h_intern(&lf[156],12,"signals-list");
lf[157]=C_h_intern(&lf[157],18,"\003sysinterrupt-hook");
lf[158]=C_h_intern(&lf[158],14,"signal-handler");
lf[159]=C_h_intern(&lf[159],19,"set-signal-handler!");
lf[160]=C_h_intern(&lf[160],16,"set-signal-mask!");
lf[161]=C_h_intern(&lf[161],14,"\000process-error");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[163]=C_h_intern(&lf[163],11,"signal-mask");
lf[164]=C_h_intern(&lf[164],14,"signal-masked\077");
lf[165]=C_h_intern(&lf[165],12,"signal-mask!");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[167]=C_h_intern(&lf[167],14,"signal-unmask!");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[169]=C_h_intern(&lf[169],18,"system-information");
lf[170]=C_h_intern(&lf[170],25,"\003syspeek-nonnull-c-string");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[172]=C_h_intern(&lf[172],12,"set-user-id!");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[174]=C_h_intern(&lf[174],15,"current-user-id");
lf[175]=C_h_intern(&lf[175],25,"current-effective-user-id");
lf[176]=C_h_intern(&lf[176],13,"set-group-id!");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[178]=C_h_intern(&lf[178],16,"current-group-id");
lf[179]=C_h_intern(&lf[179],26,"current-effective-group-id");
lf[180]=C_h_intern(&lf[180],16,"user-information");
lf[181]=C_h_intern(&lf[181],6,"vector");
lf[182]=C_h_intern(&lf[182],4,"list");
lf[183]=C_h_intern(&lf[183],17,"current-user-name");
lf[184]=C_h_intern(&lf[184],27,"current-effective-user-name");
lf[185]=C_h_intern(&lf[185],17,"group-information");
lf[187]=C_h_intern(&lf[187],10,"get-groups");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[191]=C_h_intern(&lf[191],11,"set-groups!");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[194]=C_h_intern(&lf[194],17,"initialize-groups");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[196]=C_h_intern(&lf[196],10,"errno/perm");
lf[197]=C_h_intern(&lf[197],11,"errno/noent");
lf[198]=C_h_intern(&lf[198],10,"errno/srch");
lf[199]=C_h_intern(&lf[199],10,"errno/intr");
lf[200]=C_h_intern(&lf[200],8,"errno/io");
lf[201]=C_h_intern(&lf[201],12,"errno/noexec");
lf[202]=C_h_intern(&lf[202],10,"errno/badf");
lf[203]=C_h_intern(&lf[203],11,"errno/child");
lf[204]=C_h_intern(&lf[204],11,"errno/nomem");
lf[205]=C_h_intern(&lf[205],11,"errno/acces");
lf[206]=C_h_intern(&lf[206],11,"errno/fault");
lf[207]=C_h_intern(&lf[207],10,"errno/busy");
lf[208]=C_h_intern(&lf[208],12,"errno/notdir");
lf[209]=C_h_intern(&lf[209],11,"errno/isdir");
lf[210]=C_h_intern(&lf[210],11,"errno/inval");
lf[211]=C_h_intern(&lf[211],11,"errno/mfile");
lf[212]=C_h_intern(&lf[212],11,"errno/nospc");
lf[213]=C_h_intern(&lf[213],11,"errno/spipe");
lf[214]=C_h_intern(&lf[214],10,"errno/pipe");
lf[215]=C_h_intern(&lf[215],11,"errno/again");
lf[216]=C_h_intern(&lf[216],10,"errno/rofs");
lf[217]=C_h_intern(&lf[217],11,"errno/exist");
lf[218]=C_h_intern(&lf[218],16,"errno/wouldblock");
lf[219]=C_h_intern(&lf[219],10,"errno/2big");
lf[220]=C_h_intern(&lf[220],12,"errno/deadlk");
lf[221]=C_h_intern(&lf[221],9,"errno/dom");
lf[222]=C_h_intern(&lf[222],10,"errno/fbig");
lf[223]=C_h_intern(&lf[223],11,"errno/ilseq");
lf[224]=C_h_intern(&lf[224],11,"errno/mlink");
lf[225]=C_h_intern(&lf[225],17,"errno/nametoolong");
lf[226]=C_h_intern(&lf[226],11,"errno/nfile");
lf[227]=C_h_intern(&lf[227],11,"errno/nodev");
lf[228]=C_h_intern(&lf[228],11,"errno/nolck");
lf[229]=C_h_intern(&lf[229],11,"errno/nosys");
lf[230]=C_h_intern(&lf[230],14,"errno/notempty");
lf[231]=C_h_intern(&lf[231],11,"errno/notty");
lf[232]=C_h_intern(&lf[232],10,"errno/nxio");
lf[233]=C_h_intern(&lf[233],11,"errno/range");
lf[234]=C_h_intern(&lf[234],10,"errno/xdev");
lf[235]=C_h_intern(&lf[235],16,"change-file-mode");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[237]=C_h_intern(&lf[237],17,"change-file-owner");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[239]=C_h_intern(&lf[239],17,"file-read-access\077");
lf[240]=C_h_intern(&lf[240],18,"file-write-access\077");
lf[241]=C_h_intern(&lf[241],20,"file-execute-access\077");
lf[242]=C_h_intern(&lf[242],14,"create-session");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[244]=C_h_intern(&lf[244],21,"set-process-group-id!");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[246]=C_h_intern(&lf[246],16,"process-group-id");
lf[247]=C_h_intern(&lf[247],20,"create-symbolic-link");
lf[248]=C_h_intern(&lf[248],18,"create-symbol-link");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[250]=C_h_intern(&lf[250],9,"substring");
lf[251]=C_h_intern(&lf[251],18,"read-symbolic-link");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[253]=C_h_intern(&lf[253],9,"file-link");
lf[254]=C_h_intern(&lf[254],9,"hard-link");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[256]=C_h_intern(&lf[256],12,"fileno/stdin");
lf[257]=C_h_intern(&lf[257],13,"fileno/stdout");
lf[258]=C_h_intern(&lf[258],13,"fileno/stderr");
lf[259]=C_h_intern(&lf[259],7,"\000append");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[267]=C_h_intern(&lf[267],16,"open-input-file*");
lf[268]=C_h_intern(&lf[268],17,"open-output-file*");
lf[269]=C_h_intern(&lf[269],12,"port->fileno");
lf[270]=C_h_intern(&lf[270],6,"socket");
lf[271]=C_h_intern(&lf[271],20,"\003systcp-port->fileno");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[274]=C_h_intern(&lf[274],25,"\003syspeek-unsigned-integer");
lf[275]=C_h_intern(&lf[275],16,"duplicate-fileno");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[277]=C_h_intern(&lf[277],15,"make-input-port");
lf[278]=C_h_intern(&lf[278],14,"set-port-name!");
lf[279]=C_h_intern(&lf[279],21,"\003syscustom-input-port");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[281]=C_h_intern(&lf[281],17,"\003systhread-yield!");
lf[282]=C_h_intern(&lf[282],25,"\003systhread-block-for-i/o!");
lf[283]=C_h_intern(&lf[283],18,"\003syscurrent-thread");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[288]=C_h_intern(&lf[288],17,"\003sysstring-append");
lf[289]=C_h_intern(&lf[289],15,"\003sysmake-string");
lf[290]=C_h_intern(&lf[290],20,"\003sysscan-buffer-line");
lf[291]=C_h_intern(&lf[291],4,"noop");
lf[292]=C_h_intern(&lf[292],16,"make-output-port");
lf[293]=C_h_intern(&lf[293],22,"\003syscustom-output-port");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[296]=C_h_intern(&lf[296],13,"file-truncate");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[299]=C_h_intern(&lf[299],4,"lock");
lf[300]=C_h_intern(&lf[300],9,"file-lock");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[302]=C_h_intern(&lf[302],18,"file-lock/blocking");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[304]=C_h_intern(&lf[304],14,"file-test-lock");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[306]=C_h_intern(&lf[306],11,"file-unlock");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[308]=C_h_intern(&lf[308],11,"create-fifo");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[310]=C_h_intern(&lf[310],5,"fifo\077");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[312]=C_h_intern(&lf[312],6,"setenv");
lf[313]=C_h_intern(&lf[313],8,"unsetenv");
lf[314]=C_h_intern(&lf[314],19,"current-environment");
lf[315]=C_h_intern(&lf[315],9,"prot/read");
lf[316]=C_h_intern(&lf[316],10,"prot/write");
lf[317]=C_h_intern(&lf[317],9,"prot/exec");
lf[318]=C_h_intern(&lf[318],9,"prot/none");
lf[319]=C_h_intern(&lf[319],9,"map/fixed");
lf[320]=C_h_intern(&lf[320],10,"map/shared");
lf[321]=C_h_intern(&lf[321],11,"map/private");
lf[322]=C_h_intern(&lf[322],13,"map/anonymous");
lf[323]=C_h_intern(&lf[323],8,"map/file");
lf[324]=C_h_intern(&lf[324],18,"map-file-to-memory");
lf[325]=C_h_intern(&lf[325],4,"mmap");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[327]=C_h_intern(&lf[327],20,"\003syspointer->address");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[329]=C_h_intern(&lf[329],16,"\003sysnull-pointer");
lf[330]=C_h_intern(&lf[330],22,"unmap-file-from-memory");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[332]=C_h_intern(&lf[332],26,"memory-mapped-file-pointer");
lf[333]=C_h_intern(&lf[333],19,"memory-mapped-file\077");
lf[334]=C_h_intern(&lf[334],19,"seconds->local-time");
lf[335]=C_h_intern(&lf[335],18,"\003sysdecode-seconds");
lf[336]=C_h_intern(&lf[336],17,"seconds->utc-time");
lf[337]=C_h_intern(&lf[337],15,"seconds->string");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[339]=C_h_intern(&lf[339],12,"time->string");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[343]=C_h_intern(&lf[343],12,"string->time");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[345]=C_h_intern(&lf[345],19,"local-time->seconds");
lf[346]=C_h_intern(&lf[346],15,"\003syscons-flonum");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[349]=C_h_intern(&lf[349],17,"utc-time->seconds");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[352]=C_h_intern(&lf[352],27,"local-timezone-abbreviation");
lf[353]=C_h_intern(&lf[353],5,"_exit");
lf[354]=C_h_intern(&lf[354],10,"set-alarm!");
lf[355]=C_h_intern(&lf[355],19,"set-buffering-mode!");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[357]=C_h_intern(&lf[357],5,"\000full");
lf[358]=C_h_intern(&lf[358],5,"\000line");
lf[359]=C_h_intern(&lf[359],5,"\000none");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[361]=C_h_intern(&lf[361],14,"terminal-port\077");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[364]=C_h_intern(&lf[364],13,"terminal-name");
lf[365]=C_h_intern(&lf[365],13,"terminal-size");
lf[366]=C_h_intern(&lf[366],6,"\000error");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[368]=C_h_intern(&lf[368],17,"\003sysmake-locative");
lf[369]=C_h_intern(&lf[369],8,"location");
lf[370]=C_h_intern(&lf[370],13,"get-host-name");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[372]=C_h_intern(&lf[372],6,"regexp");
lf[373]=C_h_intern(&lf[373],21,"make-anchored-pattern");
lf[374]=C_h_intern(&lf[374],12,"string-match");
lf[375]=C_h_intern(&lf[375],12,"glob->regexp");
lf[376]=C_h_intern(&lf[376],13,"make-pathname");
lf[377]=C_h_intern(&lf[377],18,"decompose-pathname");
lf[378]=C_h_intern(&lf[378],4,"glob");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[381]=C_h_intern(&lf[381],12,"process-fork");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[383]=C_h_intern(&lf[383],24,"pathname-strip-directory");
lf[384]=C_h_intern(&lf[384],15,"process-execute");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[386]=C_h_intern(&lf[386],16,"\003sysprocess-wait");
lf[387]=C_h_intern(&lf[387],12,"process-wait");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[389]=C_h_intern(&lf[389],18,"current-process-id");
lf[390]=C_h_intern(&lf[390],17,"parent-process-id");
lf[391]=C_h_intern(&lf[391],5,"sleep");
lf[392]=C_h_intern(&lf[392],14,"process-signal");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[394]=C_h_intern(&lf[394],17,"\003sysshell-command");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[396]=C_h_intern(&lf[396],6,"getenv");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[398]=C_h_intern(&lf[398],27,"\003sysshell-command-arguments");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[400]=C_h_intern(&lf[400],11,"process-run");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[402]=C_h_intern(&lf[402],11,"\003sysprocess");
lf[403]=C_h_intern(&lf[403],19,"\003sysundefined-value");
lf[404]=C_h_intern(&lf[404],7,"process");
lf[405]=C_h_intern(&lf[405],8,"process*");
lf[406]=C_h_intern(&lf[406],10,"find-files");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[410]=C_h_intern(&lf[410],16,"\003sysdynamic-wind");
lf[411]=C_h_intern(&lf[411],13,"pathname-file");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[413]=C_h_intern(&lf[413],7,"regexp\077");
lf[414]=C_h_intern(&lf[414],19,"set-root-directory!");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[417]=C_h_intern(&lf[417],18,"getter-with-setter");
lf[418]=C_h_intern(&lf[418],26,"effective-group-id!-setter");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[420]=C_h_intern(&lf[420],25,"effective-user-id!-setter");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[422]=C_h_intern(&lf[422],23,"\003sysuser-interrupt-hook");
lf[423]=C_h_intern(&lf[423],11,"make-vector");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[426]=C_h_intern(&lf[426],17,"register-feature!");
lf[427]=C_h_intern(&lf[427],5,"posix");
C_register_lf2(lf,428,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1538,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1536 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1541,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1539 in k1536 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1544,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1542 in k1539 in k1536 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1547,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1550,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 503  register-feature! */
t3=*((C_word*)lf[426]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[427]);}

/* k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word ab[92],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1550,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1562,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1,lf[3]);
t5=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1580,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1587,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1644,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1690,a[2]=t45,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[57]+1);
t49=C_mutate((C_word*)lf[58]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1743,a[2]=t48,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1785,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1824,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1856,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1862,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1872,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t55=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1882,a[2]=t53,a[3]=t54,a[4]=t52,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t56=C_mutate((C_word*)lf[71]+1,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[72]+1,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[73]+1,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[74],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2074,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2111,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2143,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2149,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2155,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2161,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2167,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2173,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2179,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2188,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2257,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t71=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6896,a[2]=((C_word)li240),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 808  getter-with-setter */
t72=*((C_word*)lf[417]+1);
((C_proc4)C_retrieve_proc(t72))(4,t72,t70,t71,*((C_word*)lf[86]+1));}

/* a6895 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6896(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6896,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6900,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6912,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 810  port? */
t5=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6910 in a6895 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[88]);
t4=((C_word*)t0)[2];
f_6900(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_6900(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 815  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[93],lf[425],((C_word*)t0)[3]);}}}

/* k6898 in a6895 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6903,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 817  posix-error */
t3=lf[3];
f_1562(6,t3,t2,lf[48],lf[93],lf[424],((C_word*)t0)[2]);}
else{
t3=t2;
f_6903(2,t3,C_SCHEME_UNDEFINED);}}

/* k6901 in k6898 in a6895 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word ab[147],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2257,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1,t1);
t3=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2259,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2283,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2307,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[100]+1);
t7=*((C_word*)lf[57]+1);
t8=*((C_word*)lf[101]+1);
t9=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2331,a[2]=t7,a[3]=t6,a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2488,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2511,a[2]=t11,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2554,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2566,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2572,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp);
t16=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2587,a[2]=t14,a[3]=t15,a[4]=t13,a[5]=((C_word)li41),tmp=(C_word)a,a+=6,tmp));
t17=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2623,a[2]=t14,a[3]=t15,a[4]=t13,a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp));
t18=C_mutate((C_word*)lf[118]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2659,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[122]+1,*((C_word*)lf[118]+1));
t20=*((C_word*)lf[115]+1);
t21=*((C_word*)lf[117]+1);
t22=*((C_word*)lf[118]+1);
t23=*((C_word*)lf[122]+1);
t24=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2675,a[2]=t20,a[3]=t22,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2699,a[2]=t21,a[3]=t23,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
t26=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2723,a[2]=t20,a[3]=t22,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp));
t27=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2743,a[2]=t21,a[3]=t23,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp));
t28=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2763,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[131]+1,C_fix((C_word)SIGTERM));
t30=C_mutate((C_word*)lf[132]+1,C_fix((C_word)SIGKILL));
t31=C_mutate((C_word*)lf[133]+1,C_fix((C_word)SIGINT));
t32=C_mutate((C_word*)lf[134]+1,C_fix((C_word)SIGHUP));
t33=C_mutate((C_word*)lf[135]+1,C_fix((C_word)SIGFPE));
t34=C_mutate((C_word*)lf[136]+1,C_fix((C_word)SIGILL));
t35=C_mutate((C_word*)lf[137]+1,C_fix((C_word)SIGSEGV));
t36=C_mutate((C_word*)lf[138]+1,C_fix((C_word)SIGABRT));
t37=C_mutate((C_word*)lf[139]+1,C_fix((C_word)SIGTRAP));
t38=C_mutate((C_word*)lf[140]+1,C_fix((C_word)SIGQUIT));
t39=C_mutate((C_word*)lf[141]+1,C_fix((C_word)SIGALRM));
t40=C_mutate((C_word*)lf[142]+1,C_fix((C_word)SIGVTALRM));
t41=C_mutate((C_word*)lf[143]+1,C_fix((C_word)SIGPROF));
t42=C_mutate((C_word*)lf[144]+1,C_fix((C_word)SIGIO));
t43=C_mutate((C_word*)lf[145]+1,C_fix((C_word)SIGURG));
t44=C_mutate((C_word*)lf[146]+1,C_fix((C_word)SIGCHLD));
t45=C_mutate((C_word*)lf[147]+1,C_fix((C_word)SIGCONT));
t46=C_mutate((C_word*)lf[148]+1,C_fix((C_word)SIGSTOP));
t47=C_mutate((C_word*)lf[149]+1,C_fix((C_word)SIGTSTP));
t48=C_mutate((C_word*)lf[150]+1,C_fix((C_word)SIGPIPE));
t49=C_mutate((C_word*)lf[151]+1,C_fix((C_word)SIGXCPU));
t50=C_mutate((C_word*)lf[152]+1,C_fix((C_word)SIGXFSZ));
t51=C_mutate((C_word*)lf[153]+1,C_fix((C_word)SIGUSR1));
t52=C_mutate((C_word*)lf[154]+1,C_fix((C_word)SIGUSR2));
t53=C_mutate((C_word*)lf[155]+1,C_fix((C_word)SIGWINCH));
t54=(C_word)C_a_i_list(&a,25,*((C_word*)lf[131]+1),*((C_word*)lf[132]+1),*((C_word*)lf[133]+1),*((C_word*)lf[134]+1),*((C_word*)lf[135]+1),*((C_word*)lf[136]+1),*((C_word*)lf[137]+1),*((C_word*)lf[138]+1),*((C_word*)lf[139]+1),*((C_word*)lf[140]+1),*((C_word*)lf[141]+1),*((C_word*)lf[142]+1),*((C_word*)lf[143]+1),*((C_word*)lf[144]+1),*((C_word*)lf[145]+1),*((C_word*)lf[146]+1),*((C_word*)lf[147]+1),*((C_word*)lf[148]+1),*((C_word*)lf[149]+1),*((C_word*)lf[150]+1),*((C_word*)lf[151]+1),*((C_word*)lf[152]+1),*((C_word*)lf[153]+1),*((C_word*)lf[154]+1),*((C_word*)lf[155]+1));
t55=C_mutate((C_word*)lf[156]+1,t54);
t56=*((C_word*)lf[157]+1);
t57=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[2],a[3]=t56,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1044 make-vector */
t58=*((C_word*)lf[423]+1);
((C_proc4)(void*)(*((C_word*)t58+1)))(4,t58,t57,C_fix(256),C_SCHEME_FALSE);}

/* k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2810,a[2]=t1,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[159]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2819,a[2]=t1,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[157]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2832,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2850,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[163]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2874,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[164]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2906,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2912,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2927,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2943,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6890,a[2]=((C_word)li239),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1100 set-signal-handler! */
t12=*((C_word*)lf[159]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,*((C_word*)lf[133]+1),t11);}

/* a6889 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6890(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6890,3,t0,t1,t2);}
/* posixunix.scm: 1102 ##sys#user-interrupt-hook */
t3=*((C_word*)lf[422]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2943,2,t0,t1);}
t2=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2945,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6887,a[2]=((C_word)li238),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1132 getter-with-setter */
t6=*((C_word*)lf[417]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,*((C_word*)lf[172]+1));}

/* a6886 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6887,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub332(C_SCHEME_UNDEFINED));}

/* k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3000,2,t0,t1);}
t2=C_mutate((C_word*)lf[174]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6869,a[2]=((C_word)li236),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6872,a[2]=((C_word)li237),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1137 getter-with-setter */
t6=*((C_word*)lf[417]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a6871 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6872,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6882,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1141 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6880 in a6871 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1142 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[420],lf[421],((C_word*)t0)[2]);}

/* a6868 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6869,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub334(C_SCHEME_UNDEFINED));}

/* k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3004,2,t0,t1);}
t2=C_mutate((C_word*)lf[175]+1,t1);
t3=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3006,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3023,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6866,a[2]=((C_word)li235),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1152 getter-with-setter */
t6=*((C_word*)lf[417]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,*((C_word*)lf[176]+1));}

/* a6865 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6866,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub340(C_SCHEME_UNDEFINED));}

/* k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3023,2,t0,t1);}
t2=C_mutate((C_word*)lf[178]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6848,a[2]=((C_word)li233),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6851,a[2]=((C_word)li234),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1157 getter-with-setter */
t6=*((C_word*)lf[417]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}

/* a6850 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6851,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6861,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1161 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6859 in a6850 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1162 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[418],lf[419],((C_word*)t0)[2]);}

/* a6847 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6848,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub342(C_SCHEME_UNDEFINED));}

/* k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3027,2,t0,t1);}
t2=C_mutate((C_word*)lf[179]+1,t1);
t3=C_mutate((C_word*)lf[180]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3029,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[183]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3096,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[184]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[185]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3135,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[186],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3221,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[187]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3228,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[191]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3291,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[194]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3365,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[196]+1,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[197]+1,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[198]+1,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[199]+1,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[200]+1,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[201]+1,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[202]+1,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[203]+1,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[204]+1,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[205]+1,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[206]+1,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[207]+1,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[208]+1,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[209]+1,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[210]+1,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[211]+1,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[212]+1,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[213]+1,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[214]+1,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[215]+1,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[216]+1,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[217]+1,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[218]+1,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[219],0,C_fix(0));
t35=C_set_block_item(lf[220],0,C_fix(0));
t36=C_set_block_item(lf[221],0,C_fix(0));
t37=C_set_block_item(lf[222],0,C_fix(0));
t38=C_set_block_item(lf[223],0,C_fix(0));
t39=C_set_block_item(lf[224],0,C_fix(0));
t40=C_set_block_item(lf[225],0,C_fix(0));
t41=C_set_block_item(lf[226],0,C_fix(0));
t42=C_set_block_item(lf[227],0,C_fix(0));
t43=C_set_block_item(lf[228],0,C_fix(0));
t44=C_set_block_item(lf[229],0,C_fix(0));
t45=C_set_block_item(lf[230],0,C_fix(0));
t46=C_set_block_item(lf[231],0,C_fix(0));
t47=C_set_block_item(lf[232],0,C_fix(0));
t48=C_set_block_item(lf[233],0,C_fix(0));
t49=C_set_block_item(lf[234],0,C_fix(0));
t50=C_mutate((C_word*)lf[235]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3429,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[237]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3456,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3486,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[239]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3510,a[2]=t52,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[240]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3516,a[2]=t52,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[241]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3522,a[2]=t52,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t56=C_mutate((C_word*)lf[242]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3528,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[244]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3543,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3566,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6830,a[2]=((C_word)li232),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1384 getter-with-setter */
t60=*((C_word*)lf[417]+1);
((C_proc4)C_retrieve_proc(t60))(4,t60,t58,t59,*((C_word*)lf[244]+1));}

/* a6829 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6830(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6830,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[246]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6837,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6843,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1389 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_6837(2,t6,C_SCHEME_UNDEFINED);}}

/* k6841 in a6829 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1390 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[246],lf[416],((C_word*)t0)[2]);}

/* k6835 in a6829 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3566,2,t0,t1);}
t2=C_mutate((C_word*)lf[246]+1,t1);
t3=C_mutate((C_word*)lf[247]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3568,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[250]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3605,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1411 make-string */
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word ab[259],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3605,2,t0,t1);}
t2=C_mutate((C_word*)lf[251]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li88),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[253]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3656,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[256]+1,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[257]+1,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[258]+1,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3681,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3718,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
t9=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3733,a[2]=t7,a[3]=t8,a[4]=((C_word)li92),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[268]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3747,a[2]=t7,a[3]=t8,a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3761,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[275]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3806,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[277]+1);
t14=*((C_word*)lf[278]+1);
t15=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3833,a[2]=t13,a[3]=t14,a[4]=((C_word)li115),tmp=(C_word)a,a+=5,tmp));
t16=*((C_word*)lf[292]+1);
t17=*((C_word*)lf[278]+1);
t18=C_mutate((C_word*)lf[293]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4307,a[2]=t16,a[3]=t17,a[4]=((C_word)li127),tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[296]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4566,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4605,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4679,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[300]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4697,a[2]=t20,a[3]=t21,a[4]=((C_word)li131),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4712,a[2]=t20,a[3]=t21,a[4]=((C_word)li132),tmp=(C_word)a,a+=5,tmp));
t24=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4727,a[2]=t20,a[3]=t21,a[4]=((C_word)li133),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[306]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4749,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4777,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4820,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[312]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4846,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4863,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[314]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4883,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[315]+1,C_fix((C_word)PROT_READ));
t32=C_mutate((C_word*)lf[316]+1,C_fix((C_word)PROT_WRITE));
t33=C_mutate((C_word*)lf[317]+1,C_fix((C_word)PROT_EXEC));
t34=C_mutate((C_word*)lf[318]+1,C_fix((C_word)PROT_NONE));
t35=C_mutate((C_word*)lf[319]+1,C_fix((C_word)MAP_FIXED));
t36=C_mutate((C_word*)lf[320]+1,C_fix((C_word)MAP_SHARED));
t37=C_mutate((C_word*)lf[321]+1,C_fix((C_word)MAP_PRIVATE));
t38=C_mutate((C_word*)lf[322]+1,C_fix((C_word)MAP_ANON));
t39=C_mutate((C_word*)lf[323]+1,C_fix((C_word)MAP_FILE));
t40=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4986,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5048,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5083,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5092,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[334]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5098,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5107,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[337]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5126,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5159,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[343]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5237,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[345]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5275,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[349]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5303,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[352]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5331,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[353]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5343,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[354]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5359,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[355]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5366,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5425,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate(&lf[362],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5444,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5476,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5499,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5534,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t60=*((C_word*)lf[372]+1);
t61=*((C_word*)lf[373]+1);
t62=*((C_word*)lf[374]+1);
t63=*((C_word*)lf[375]+1);
t64=*((C_word*)lf[102]+1);
t65=*((C_word*)lf[376]+1);
t66=*((C_word*)lf[377]+1);
t67=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5546,a[2]=t63,a[3]=t61,a[4]=t60,a[5]=t64,a[6]=t62,a[7]=t65,a[8]=t66,a[9]=((C_word)li166),tmp=(C_word)a,a+=10,tmp));
t68=C_mutate((C_word*)lf[381]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5658,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t69=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5700,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5719,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp);
t71=*((C_word*)lf[383]+1);
t72=C_mutate((C_word*)lf[384]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5738,a[2]=t71,a[3]=t70,a[4]=t69,a[5]=((C_word)li176),tmp=(C_word)a,a+=6,tmp));
t73=C_mutate((C_word*)lf[386]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5920,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[387]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5937,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[389]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6015,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[390]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6018,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[391]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6021,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[392]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6028,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[394]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6055,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[398]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6064,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp));
t81=*((C_word*)lf[381]+1);
t82=*((C_word*)lf[384]+1);
t83=*((C_word*)lf[396]+1);
t84=C_mutate((C_word*)lf[400]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6070,a[2]=t81,a[3]=t82,a[4]=((C_word)li187),tmp=(C_word)a,a+=5,tmp));
t85=*((C_word*)lf[129]+1);
t86=*((C_word*)lf[387]+1);
t87=*((C_word*)lf[381]+1);
t88=*((C_word*)lf[384]+1);
t89=*((C_word*)lf[275]+1);
t90=*((C_word*)lf[55]+1);
t91=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6126,a[2]=t86,a[3]=((C_word)li191),tmp=(C_word)a,a+=4,tmp);
t92=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6163,a[2]=t85,a[3]=((C_word)li194),tmp=(C_word)a,a+=4,tmp);
t93=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6183,a[2]=t90,a[3]=((C_word)li195),tmp=(C_word)a,a+=4,tmp);
t94=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6197,a[2]=t90,a[3]=((C_word)li196),tmp=(C_word)a,a+=4,tmp);
t95=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6214,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp);
t96=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6230,a[2]=t92,a[3]=t87,a[4]=t94,a[5]=t88,a[6]=t95,a[7]=((C_word)li199),tmp=(C_word)a,a+=8,tmp);
t97=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6275,a[2]=t93,a[3]=((C_word)li200),tmp=(C_word)a,a+=4,tmp);
t98=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6286,a[2]=t93,a[3]=((C_word)li201),tmp=(C_word)a,a+=4,tmp);
t99=C_mutate((C_word*)lf[402]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6297,a[2]=t98,a[3]=t91,a[4]=t97,a[5]=t96,a[6]=((C_word)li204),tmp=(C_word)a,a+=7,tmp));
t100=*((C_word*)lf[403]+1);
t101=C_mutate((C_word*)lf[404]+1,t100);
t102=*((C_word*)lf[403]+1);
t103=C_mutate((C_word*)lf[405]+1,t102);
t104=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6361,a[2]=((C_word)li209),tmp=(C_word)a,a+=3,tmp);
t105=C_mutate((C_word*)lf[404]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6422,a[2]=t104,a[3]=((C_word)li213),tmp=(C_word)a,a+=4,tmp));
t106=C_mutate((C_word*)lf[405]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6482,a[2]=t104,a[3]=((C_word)li217),tmp=(C_word)a,a+=4,tmp));
t107=*((C_word*)lf[378]+1);
t108=*((C_word*)lf[374]+1);
t109=*((C_word*)lf[376]+1);
t110=*((C_word*)lf[106]+1);
t111=C_mutate((C_word*)lf[406]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6542,a[2]=t110,a[3]=t109,a[4]=t107,a[5]=t108,a[6]=((C_word)li230),tmp=(C_word)a,a+=7,tmp));
t112=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6807,a[2]=((C_word)li231),tmp=(C_word)a,a+=3,tmp));
t113=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t113+1)))(2,t113,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6807,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[414]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6799,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_foreign_string_argumentp(t4);
/* ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t6=t5;
f_6799(2,t6,C_SCHEME_FALSE);}}

/* k6797 in set-root-directory! in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1287(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2264 posix-error */
t3=lf[3];
f_1562(6,t3,((C_word*)t0)[3],lf[48],lf[414],lf[415],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_6542r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6542r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6542r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li225),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6715,a[2]=t5,a[3]=((C_word)li226),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6720,a[2]=t6,a[3]=((C_word)li227),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6725,a[2]=t7,a[3]=((C_word)li229),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action12401276 */
t9=t8;
f_6725(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id12411274 */
t11=t7;
f_6720(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit12421271 */
t13=t6;
f_6715(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body12381244 */
t15=t5;
f_6544(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action1240 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6725(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6725,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6731,a[2]=((C_word)li228),tmp=(C_word)a,a+=3,tmp);
/* def-id12411274 */
t3=((C_word*)t0)[2];
f_6720(t3,t1,t2);}

/* a6730 in def-action1240 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6731,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1241 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6720(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6720,NULL,3,t0,t1,t2);}
/* def-limit12421271 */
t3=((C_word*)t0)[2];
f_6715(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1242 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6715(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6715,NULL,4,t0,t1,t2,t3);}
/* body12381244 */
t4=((C_word*)t0)[2];
f_6544(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6544(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6544,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[406]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6551,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_6551(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6710,a[2]=t4,a[3]=t7,a[4]=((C_word)li223),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_6551(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6702,a[2]=((C_word)li224),tmp=(C_word)a,a+=3,tmp));}}

/* f_6702 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6702(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6702,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_6710 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6710(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6710,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6551,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_6690(2,t4,t2);}
else{
/* posixunix.scm: 2236 regexp? */
t4=*((C_word*)lf[413]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[11]);}}

/* k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6690,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6691,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word)li218),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6684,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2239 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[412]);}

/* k6682 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2239 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6561,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6563,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li222),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6563(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6563(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6563,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2245 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6582,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2246 pathname-file */
t3=*((C_word*)lf[411]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6670,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2253 pproc */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k6668 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6670,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6677,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2253 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2254 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6563(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k6675 in k6668 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2253 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6563(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6664,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[407]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[408]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2246 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_6563(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2247 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k6595 in k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6597,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6607,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6609,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,a[5]=((C_word)li219),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word)li220),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6641,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,a[5]=((C_word)li221),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2249 ##sys#dynamic-wind */
t11=*((C_word*)lf[410]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6654,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6657,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2252 pproc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k6655 in k6595 in k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2252 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_6654(2,t2,((C_word*)t0)[2]);}}

/* k6652 in k6595 in k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2252 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6563(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6640 in k6595 in k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6641,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[403]+1));}

/* a6616 in k6595 in k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6625,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6639,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2250 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],lf[409]);}

/* k6637 in a6616 in k6595 in k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2250 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6623 in a6616 in k6595 in k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6629,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2251 pproc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k6630 in k6623 in a6616 in k6595 in k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2251 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_6629(2,t2,((C_word*)t0)[2]);}}

/* k6627 in k6623 in a6616 in k6595 in k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2250 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6563(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6608 in k6595 in k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6609,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[403]+1));}

/* k6605 in k6595 in k6662 in k6580 in loop in k6559 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2248 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6563(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6691 in k6688 in k6549 in body1238 in find-files in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6691,3,t0,t1,t2);}
/* posixunix.scm: 2237 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6482(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_6482r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6482r(t0,t1,t2,t3);}}

static void C_ccall f_6482r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6484,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li214),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6489,a[2]=t4,a[3]=((C_word)li215),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6494,a[2]=t5,a[3]=((C_word)li216),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args12141222 */
t7=t6;
f_6494(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env12151220 */
t9=t5;
f_6489(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body12121217 */
t11=t4;
f_6484(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args1214 in process* in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6494(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6494,NULL,2,t0,t1);}
/* def-env12151220 */
t2=((C_word*)t0)[2];
f_6489(t2,t1,C_SCHEME_FALSE);}

/* def-env1215 in process* in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6489(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6489,NULL,3,t0,t1,t2);}
/* body12121217 */
t3=((C_word*)t0)[2];
f_6484(t3,t1,t2,C_SCHEME_FALSE);}

/* body1212 in process* in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6484(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6484,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2214 %process */
f_6361(t1,lf[405],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_6422r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6422r(t0,t1,t2,t3);}}

static void C_ccall f_6422r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6424,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li210),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6429,a[2]=t4,a[3]=((C_word)li211),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6434,a[2]=t5,a[3]=((C_word)li212),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args11941202 */
t7=t6;
f_6434(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env11951200 */
t9=t5;
f_6429(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body11921197 */
t11=t4;
f_6424(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args1194 in process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6434(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6434,NULL,2,t0,t1);}
/* def-env11951200 */
t2=((C_word*)t0)[2];
f_6429(t2,t1,C_SCHEME_FALSE);}

/* def-env1195 in process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6429(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6429,NULL,3,t0,t1,t2);}
/* body11921197 */
t3=((C_word*)t0)[2];
f_6424(t3,t1,t2,C_SCHEME_FALSE);}

/* body1192 in process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6424(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6424,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2211 %process */
f_6361(t1,lf[404],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6361(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6361,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6363,a[2]=t2,a[3]=((C_word)li206),tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6382,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2200 chkstrlst */
t12=t9;
f_6363(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6416,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2202 ##sys#shell-command-arguments */
t13=*((C_word*)lf[398]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)t7)[1]);}}

/* k6414 in %process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2203 ##sys#shell-command */
t4=*((C_word*)lf[394]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6418 in k6414 in %process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6382(2,t3,t2);}

/* k6380 in %process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2204 chkstrlst */
t3=((C_word*)t0)[2];
f_6363(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6385(2,t3,C_SCHEME_UNDEFINED);}}

/* k6383 in k6380 in %process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li207),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[3],a[3]=((C_word)li208),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2205 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6395 in k6383 in k6380 in %process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6396,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2207 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2208 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a6389 in k6383 in k6380 in %process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6390,2,t0,t1);}
/* posixunix.scm: 2205 ##sys#process */
t2=*((C_word*)lf[402]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6363,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6372,a[2]=((C_word*)t0)[2],a[3]=((C_word)li205),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6371 in chkstrlst in %process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6372,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6297,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6303,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word)li202),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,a[10]=((C_word)li203),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a6308 in ##sys#process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6309,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6320,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6340,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2181 make-on-close */
t12=((C_word*)t0)[3];
f_6126(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k6338 in a6308 in ##sys#process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2180 input-port */
t2=((C_word*)t0)[7];
f_6275(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6318 in a6308 in ##sys#process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2183 make-on-close */
t4=((C_word*)t0)[6];
f_6126(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k6334 in k6318 in a6308 in ##sys#process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2182 output-port */
t2=((C_word*)t0)[7];
f_6286(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6322 in k6318 in a6308 in ##sys#process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6328,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6332,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2186 make-on-close */
t4=((C_word*)t0)[3];
f_6126(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k6330 in k6322 in k6318 in a6308 in ##sys#process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2185 input-port */
t2=((C_word*)t0)[7];
f_6275(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6326 in k6322 in k6318 in a6308 in ##sys#process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2179 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6302 in ##sys#process in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
/* posixunix.scm: 2174 spawn */
t2=((C_word*)t0)[8];
f_6230(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6286(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6286,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6290,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2170 connect-parent */
t8=((C_word*)t0)[2];
f_6183(t8,t7,t4,t5);}

/* k6288 in output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2171 ##sys#custom-output-port */
t2=*((C_word*)lf[293]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6275(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6275,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6279,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2166 connect-parent */
t8=((C_word*)t0)[2];
f_6183(t8,t7,t4,t5);}

/* k6277 in input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2167 ##sys#custom-input-port */
t2=*((C_word*)lf[279]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6230(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6230,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2153 needed-pipe */
t9=((C_word*)t0)[2];
f_6163(t9,t8,t6);}

/* k6232 in spawn in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2154 needed-pipe */
t3=((C_word*)t0)[2];
f_6163(t3,t2,((C_word*)t0)[5]);}

/* k6235 in k6232 in spawn in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2155 needed-pipe */
t3=((C_word*)t0)[2];
f_6163(t3,t2,((C_word*)t0)[6]);}

/* k6238 in k6235 in k6232 in spawn in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6240,2,t0,t1);}
t2=f_6214(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6251,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word)li198),tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2158 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a6252 in k6238 in k6235 in k6232 in spawn in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6257,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2160 connect-child */
t3=((C_word*)t0)[7];
f_6197(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[256]+1));}

/* k6255 in a6252 in k6238 in k6235 in k6232 in spawn in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6260,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_6214(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2161 connect-child */
t4=((C_word*)t0)[5];
f_6197(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[257]+1));}

/* k6258 in k6255 in a6252 in k6238 in k6235 in k6232 in spawn in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6263,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_6214(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2162 connect-child */
t4=((C_word*)t0)[3];
f_6197(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[258]+1));}

/* k6261 in k6258 in k6255 in a6252 in k6238 in k6235 in k6232 in spawn in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2163 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6249 in k6238 in k6235 in k6232 in spawn in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2156 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall f_6214(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6197(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6197,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6210,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2144 file-close */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k6208 in connect-child in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6210,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6122,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2118 duplicate-fileno */
t6=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k6120 in k6208 in connect-child in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2119 file-close */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6183(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6183,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6196,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2138 file-close */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6194 in connect-parent in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6163(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6163,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6172,a[2]=((C_word*)t0)[2],a[3]=((C_word)li192),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6178,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2133 ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a6177 in needed-pipe in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6178,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a6171 in needed-pipe in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6172,2,t0,t1);}
/* posixunix.scm: 2133 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* make-on-close in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_6126(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6126,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6128,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,a[9]=((C_word)li190),tmp=(C_word)a,a+=10,tmp));}

/* f_6128 in make-on-close in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6128,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li188),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li189),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2126 ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a6148 */
static void C_ccall f_6149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6149,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2128 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[161],((C_word*)t0)[3],lf[401],((C_word*)t0)[2],t4);}}

/* a6142 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6143,2,t0,t1);}
/* posixunix.scm: 2126 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6070r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6070r(t0,t1,t2,t3);}}

static void C_ccall f_6070r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6077,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2082 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k6075 in process-run in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6077,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2084 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2086 ##sys#shell-command */
t4=*((C_word*)lf[394]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k6094 in k6075 in process-run in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6100,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2086 ##sys#shell-command-arguments */
t3=*((C_word*)lf[398]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6098 in k6094 in k6075 in process-run in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2086 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6064(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6064,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[399],t2));}

/* ##sys#shell-command in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6059,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2071 getenv */
t3=*((C_word*)lf[396]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[397]);}

/* k6057 in ##sys#shell-command in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[395]));}

/* process-signal in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6028r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6028r(t0,t1,t2,t3);}}

static void C_ccall f_6028r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[392]);
t7=(C_word)C_i_check_exact_2(t5,lf[392]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2068 posix-error */
t10=lf[3];
f_1562(7,t10,t1,lf[161],lf[392],lf[393],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6021,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1060(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6018,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1057(C_SCHEME_UNDEFINED));}

/* current-process-id in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_6015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6015,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1055(C_SCHEME_UNDEFINED));}

/* process-wait in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5937(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_5937r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5937r(t0,t1,t2);}}

static void C_ccall f_5937r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[387]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5967,a[2]=t8,a[3]=t11,a[4]=((C_word)li178),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5973,a[2]=t11,a[3]=((C_word)li179),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2052 ##sys#call-with-values */
C_call_with_values(4,0,t1,t13,t14);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* a5972 in process-wait in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5973,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2054 posix-error */
t6=lf[3];
f_1562(6,t6,t1,lf[161],lf[387],lf[388],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2055 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a5966 in process-wait in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5967,2,t0,t1);}
/* posixunix.scm: 2052 ##sys#process-wait */
t2=*((C_word*)lf[386]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5920,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 2039 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5738(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_5738r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5738r(t0,t1,t2,t3);}}

static void C_ccall f_5738r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li173),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5867,a[2]=t4,a[3]=((C_word)li174),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5872,a[2]=t5,a[3]=((C_word)li175),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist9951030 */
t7=t6;
f_5872(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist9961028 */
t9=t5;
f_5867(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body993998 */
t11=t4;
f_5740(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist995 in process-execute in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_5872(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5872,NULL,2,t0,t1);}
/* def-envlist9961028 */
t2=((C_word*)t0)[2];
f_5867(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist996 in process-execute in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_5867(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5867,NULL,3,t0,t1,t2);}
/* body993998 */
t3=((C_word*)t0)[2];
f_5740(t3,t1,t2,C_SCHEME_FALSE);}

/* body993 in process-execute in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_5740(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5740,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[384]);
t5=(C_word)C_i_check_list_2(t2,lf[384]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5750,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2007 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k5748 in body993 in process-execute in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5750,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_5700(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5758,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li172),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_5758(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do1002 in k5748 in body993 in process-execute in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_5758(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5758,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_5700(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5771,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[384]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5804,a[2]=((C_word*)t0)[3],a[3]=((C_word)li171),tmp=(C_word)a,a+=4,tmp);
t8=t5;
f_5771(t8,f_5804(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_5771(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[384]);
t6=(C_word)C_block_size(t4);
t7=f_5700(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* do1006 in do1002 in k5748 in body993 in process-execute in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall f_5804(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_5719(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[384]);
t5=(C_word)C_block_size(t3);
t6=f_5719(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k5769 in do1002 in k5748 in body993 in process-execute in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_5771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5771,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5796,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2021 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5794 in k5769 in do1002 in k5748 in body993 in process-execute in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2021 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5772 in k5769 in do1002 in k5748 in body993 in process-execute in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub974(C_SCHEME_UNDEFINED);
t5=(C_word)stub986(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2028 posix-error */
t6=lf[3];
f_1562(6,t6,((C_word*)t0)[3],lf[161],lf[384],lf[385],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall f_5719(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub979(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall f_5700(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub967(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5658(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5658r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5658r(t0,t1,t2);}}

static void C_ccall f_5658r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub950(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 1992 posix-error */
t5=lf[3];
f_1562(5,t5,t1,lf[161],lf[381],lf[382]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5680,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_vector_ref(t2,C_fix(0));
t9=t8;
((C_proc2)C_retrieve_proc(t9))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k5678 in process-fork in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5684,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_5684 in k5678 in process-fork in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5684,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub955(C_SCHEME_UNDEFINED,t3));}

/* glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_5546r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5546r(t0,t1,t2);}}

static void C_ccall f_5546r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li165),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_5552(t6,t1,t2);}

/* conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_5552(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5552,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5567,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li162),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li164),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a5572 in conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5573,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5577,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5650,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[380]);
/* posixunix.scm: 1976 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k5648 in a5572 in conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1976 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5575 in a5572 in conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5580,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixunix.scm: 1977 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5578 in k5575 in a5572 in conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1978 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k5581 in k5578 in k5575 in a5572 in conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5590,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[379]);
/* posixunix.scm: 1979 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k5588 in k5581 in k5578 in k5575 in a5572 in conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5590,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li163),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_5592(t5,((C_word*)t0)[2],t1);}

/* loop in k5588 in k5581 in k5578 in k5575 in a5572 in conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_5592(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5592,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixunix.scm: 1980 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5552(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixunix.scm: 1981 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k5607 in loop in k5588 in k5581 in k5578 in k5575 in a5572 in conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5609,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5619,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixunix.scm: 1982 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixunix.scm: 1983 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5592(t3,((C_word*)t0)[6],t2);}}

/* k5617 in k5607 in loop in k5588 in k5581 in k5578 in k5575 in a5572 in conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5623,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixunix.scm: 1982 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5592(t4,t2,t3);}

/* k5621 in k5617 in k5607 in loop in k5588 in k5581 in k5578 in k5575 in a5572 in conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5623,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a5566 in conc-loop in glob in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5567,2,t0,t1);}
/* posixunix.scm: 1975 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5538,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub910(t3),C_fix(0));}

/* k5536 in get-host-name in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5541,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_5541(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1956 posix-error */
t3=lf[3];
f_1562(5,t3,t2,lf[366],lf[370],lf[371]);}}

/* k5539 in k5536 in get-host-name in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5499,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5503,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1937 ##sys#terminal-check */
f_5444(t3,lf[365],t2);}

/* k5501 in terminal-size in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5503,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5523,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
t5=*((C_word*)lf[368]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[369]);}

/* k5521 in k5501 in terminal-size in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[368]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[369]);}

/* k5525 in k5521 in k5501 in terminal-size in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_pointer_argumentp(t3);
t6=(C_word)C_i_foreign_pointer_argumentp(t1);
t7=(C_word)stub896(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(C_word)C_eqp(C_fix(0),t7);
if(C_truep(t8)){
/* posixunix.scm: 1944 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 1945 posix-error */
t9=lf[3];
f_1562(6,t9,((C_word*)t0)[4],lf[366],lf[365],lf[367],((C_word*)t0)[6]);}}

/* terminal-name in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5476,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5480,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1929 ##sys#terminal-check */
f_5444(t3,lf[364],t2);}

/* k5478 in terminal-name in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5480,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub886(t4,t5);
/* ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* ##sys#terminal-check in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_5444(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5444,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5448,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1921 ##sys#check-port */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k5446 in ##sys#terminal-check in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[88],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1924 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[363],((C_word*)t0)[4]);}}

/* terminal-port? in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5425,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5429,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1916 ##sys#check-port */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[361]);}

/* k5427 in terminal-port? in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1917 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[274]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k5430 in k5427 in terminal-port? in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5366r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5366r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5366r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5370,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1901 ##sys#check-port */
t6=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[355]);}

/* k5368 in set-buffering-mode! in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5370,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[357]);
if(C_truep(t6)){
t7=t5;
f_5376(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[358]);
if(C_truep(t7)){
t8=t5;
f_5376(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[359]);
if(C_truep(t8)){
t9=t5;
f_5376(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 1907 ##sys#error */
t9=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[355],lf[360],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k5374 in k5368 in set-buffering-mode! in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[355]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[88],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 1913 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[355],lf[356],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5359,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub866(C_SCHEME_UNDEFINED,t3));}

/* _exit in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5343(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5343r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5343r(t0,t1,t2);}}

static void C_ccall f_5343r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub861(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5331,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub856(t2),C_fix(0));}

/* utc-time->seconds in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5303,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[349]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5310,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1869 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[349],lf[351],t2);}
else{
t6=t4;
f_5310(2,t6,C_SCHEME_UNDEFINED);}}

/* k5308 in utc-time->seconds in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 1871 ##sys#cons-flonum */
t2=*((C_word*)lf[346]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1872 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[349],lf[350],((C_word*)t0)[3]);}}

/* local-time->seconds in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5275,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[345]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5282,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1862 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[345],lf[348],t2);}
else{
t6=t4;
f_5282(2,t6,C_SCHEME_UNDEFINED);}}

/* k5280 in local-time->seconds in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 1864 ##sys#cons-flonum */
t2=*((C_word*)lf[346]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1865 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[345],lf[347],((C_word*)t0)[3]);}}

/* string->time in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5237(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5237r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5237r(t0,t1,t2,t3);}}

static void C_ccall f_5237r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5241,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5241(2,t5,lf[344]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5241(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5239 in string->time in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5241,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[343]);
t3=(C_word)C_i_check_string_2(t1,lf[343]);
t4=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[3];
t7=t1;
t8=t5;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub837(C_SCHEME_UNDEFINED,t6,t7,t4));}

/* time->string in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5159r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5159r(t0,t1,t2,t3);}}

static void C_ccall f_5159r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5163,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5163(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5163(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5161 in time->string in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5163,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[3],lf[339]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(10)))){
/* posixunix.scm: 1842 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[339],lf[342],((C_word*)t0)[3]);}
else{
t5=t3;
f_5169(2,t5,C_SCHEME_UNDEFINED);}}

/* k5167 in k5161 in time->string in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5169,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[339]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[4];
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,(C_word)stub816(t6,t4,t5),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub810(t4,t3),C_fix(0));}}

/* k5185 in k5167 in k5161 in time->string in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1850 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1851 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[339],lf[341],((C_word*)t0)[2]);}}

/* k5176 in k5167 in k5161 in time->string in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1847 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[339],lf[340],((C_word*)t0)[2]);}}

/* seconds->string in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5126,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5130,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub801(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k5128 in seconds->string in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1834 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1835 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[337],lf[338],((C_word*)t0)[2]);}}

/* seconds->utc-time in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5107,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[336]);
/* posixunix.scm: 1827 ##sys#decode-seconds */
t4=*((C_word*)lf[335]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5098,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[334]);
/* posixunix.scm: 1823 ##sys#decode-seconds */
t4=*((C_word*)lf[335]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* memory-mapped-file? in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5092,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[325]));}

/* memory-mapped-file-pointer in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5083,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[325],lf[332]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5048r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5048r(t0,t1,t2,t3);}}

static void C_ccall f_5048r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_i_check_structure_2(t2,lf[325],lf[330]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub782(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1810 posix-error */
t12=lf[3];
f_1562(7,t12,t1,lf[48],lf[330],lf[331],t2,t6);}}

/* map-file-to-memory in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_4986r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_4986r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_4986r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4990,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_4990(2,t10,t2);}
else{
/* posixunix.scm: 1795 ##sys#null-pointer */
t10=*((C_word*)lf[329]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k4988 in map-file-to-memory in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4990,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4996,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_4996(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1798 ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[60],lf[324],lf[328],t1);}}

/* k4994 in k4988 in map-file-to-memory in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4996,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub757(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5002,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1800 ##sys#pointer->address */
t17=*((C_word*)lf[327]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,t14);}

/* k5013 in k4994 in k4988 in map-file-to-memory in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1801 posix-error */
t3=lf[3];
f_1562(11,t3,((C_word*)t0)[8],lf[48],lf[324],lf[326],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_5002(2,t3,C_SCHEME_UNDEFINED);}}

/* k5000 in k4994 in k4988 in map-file-to-memory in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5002,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[325],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* current-environment in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4883,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4889,a[2]=t3,a[3]=((C_word)li140),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4889(t5,t1,C_fix(0));}

/* loop in current-environment in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4889(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4889,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4893,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub739(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4891 in loop in current-environment in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4893,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4901,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li139),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_4901(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k4891 in loop in current-environment in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4901(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4901,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4927,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1762 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1765 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k4925 in scan in k4891 in loop in current-environment in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1763 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k4929 in k4925 in scan in k4891 in loop in current-environment in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4931,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4919,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1764 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4889(t5,t3,t4);}

/* k4917 in k4929 in k4925 in scan in k4891 in loop in current-environment in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4919,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4863,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[313]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4871,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1751 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4869 in unsetenv in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4846,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[312]);
t5=(C_word)C_i_check_string_2(t3,lf[312]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4857,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1746 ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4855 in setenv in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4861,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1746 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4859 in k4855 in setenv in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4820(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4820,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[310]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4827,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4844,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1735 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4842 in fifo? in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1735 ##sys#file-info */
t2=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4825 in fifo? in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1738 posix-error */
t2=lf[3];
f_1562(6,t2,((C_word*)t0)[3],lf[48],lf[310],lf[311],((C_word*)t0)[2]);}}

/* create-fifo in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4777r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4777r(t0,t1,t2,t3);}}

static void C_ccall f_4777r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[308]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4784,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_4784(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_4784(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k4782 in create-fifo in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4784(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4784,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[308]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4805,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1729 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k4803 in k4782 in create-fifo in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1729 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4799 in k4782 in create-fifo in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1730 posix-error */
t3=lf[3];
f_1562(7,t3,((C_word*)t0)[3],lf[48],lf[308],lf[309],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4749,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[299],lf[306]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1719 posix-error */
t9=lf[3];
f_1562(6,t9,t1,lf[48],lf[306],lf[307],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4727r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4727r(t0,t1,t2,t3);}}

static void C_ccall f_4727r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1710 setup */
f_4605(t4,t2,t3,lf[304]);}

/* k4729 in file-test-lock in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1712 err */
f_4679(((C_word*)t0)[3],lf[305],t1,lf[304]);}}

/* file-lock/blocking in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4712r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4712r(t0,t1,t2,t3);}}

static void C_ccall f_4712r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4716,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1704 setup */
f_4605(t4,t2,t3,lf[302]);}

/* k4714 in file-lock/blocking in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1706 err */
f_4679(((C_word*)t0)[2],lf[303],t1,lf[302]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4697r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4697r(t0,t1,t2,t3);}}

static void C_ccall f_4697r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4701,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1698 setup */
f_4605(t4,t2,t3,lf[300]);}

/* k4699 in file-lock in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1700 err */
f_4679(((C_word*)t0)[2],lf[301],t1,lf[300]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4679(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4679,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1695 posix-error */
t8=lf[3];
f_1562(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4605(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4605,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4627,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1687 ##sys#check-port */
t16=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k4625 in setup in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4627,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_4633(t6,t5);}
else{
t5=t3;
f_4633(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k4631 in k4625 in setup in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4633,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[299],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4566,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[296]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4583,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4590,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4594,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1670 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_4583(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1672 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[296],lf[298],t2);}}}

/* k4592 in file-truncate in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1670 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4588 in file-truncate in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4583(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k4581 in file-truncate in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1674 posix-error */
t2=lf[3];
f_1562(7,t2,((C_word*)t0)[4],lf[48],lf[296],lf[297],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_4307r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4307r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4307r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li123),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4493,a[2]=t6,a[3]=((C_word)li124),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4498,a[2]=t7,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4503,a[2]=t8,a[3]=((C_word)li126),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?631672 */
t10=t9;
f_4503(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi632670 */
t12=t8;
f_4498(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close633667 */
t14=t7;
f_4493(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* body629635 */
t16=t6;
f_4309(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-nonblocking?631 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4503,NULL,2,t0,t1);}
/* def-bufi632670 */
t2=((C_word*)t0)[2];
f_4498(t2,t1,C_SCHEME_FALSE);}

/* def-bufi632 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4498(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4498,NULL,3,t0,t1,t2);}
/* def-on-close633667 */
t3=((C_word*)t0)[2];
f_4493(t3,t1,t2,C_fix(0));}

/* def-on-close633 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4493(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4493,NULL,4,t0,t1,t2,t3);}
/* body629635 */
t4=((C_word*)t0)[2];
f_4309(t4,t1,t2,t3,*((C_word*)lf[291]+1));}

/* body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4309,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1612 ##sys#file-nonblocking! */
t6=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_4313(2,t6,C_SCHEME_UNDEFINED);}}

/* k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4313,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4315,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word)li116),tmp=(C_word)a,a+=7,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_4361(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4405,a[2]=t3,a[3]=((C_word)li120),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4419,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1631 ##sys#make-string */
t12=*((C_word*)lf[289]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_4419(2,t12,((C_word*)t0)[6]);}}}

/* k4417 in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4419,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_4361(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4420,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li122),tmp=(C_word)a,a+=7,tmp));}

/* f_4420 in k4417 in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4420,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4437,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word)li121),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_4437(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1647 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4315(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_4437(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4437,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4447,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1637 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_4315(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_difference(t4,t2);
/* posixunix.scm: 1642 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k4445 in loop */
static void C_ccall f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1639 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4437(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_4405 in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4405,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1630 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4315(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4359 in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4361,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4365,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[9],a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li118),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[9],a[3]=((C_word)li119),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1650 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t5,t6,t7,t8);}

/* a4396 in k4359 in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4397,2,t0,t1);}
/* posixunix.scm: 1660 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* a4375 in k4359 in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4376,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4386,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1657 posix-error */
t3=lf[3];
f_1562(7,t3,t2,lf[48],((C_word*)t0)[3],lf[295],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_4386(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4384 in a4375 in k4359 in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1658 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a4369 in k4359 in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4370,3,t0,t1,t2);}
/* posixunix.scm: 1652 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* k4363 in k4359 in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4365,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4368,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1661 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k4366 in k4363 in k4359 in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4315(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4315,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4331,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1620 ##sys#thread-yield! */
t8=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1622 posix-error */
t7=lf[3];
f_1562(7,t7,t1,((C_word*)t0)[3],lf[48],lf[294],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4350,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1624 ##sys#substring */
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4348 in poke in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1624 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4315(t3,((C_word*)t0)[2],t1,t2);}

/* k4329 in poke in k4311 in body629 in ##sys#custom-output-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1621 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4315(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_3833r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3833r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3833r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,a[7]=((C_word)li110),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4214,a[2]=t6,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4219,a[2]=t7,a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4224,a[2]=t8,a[3]=((C_word)li113),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4229,a[2]=t9,a[3]=((C_word)li114),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?521610 */
t11=t10;
f_4229(t11,t1);}
else{
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi522608 */
t13=t9;
f_4224(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close523605 */
t15=t8;
f_4219(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?524601 */
t17=t7;
f_4214(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
/* body519526 */
t19=t6;
f_3835(t19,t1,t11,t13,t15,t17);}
else{
/* ##sys#error */
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[0],t18);}}}}}}

/* def-nonblocking?521 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4229(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4229,NULL,2,t0,t1);}
/* def-bufi522608 */
t2=((C_word*)t0)[2];
f_4224(t2,t1,C_SCHEME_FALSE);}

/* def-bufi522 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4224(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4224,NULL,3,t0,t1,t2);}
/* def-on-close523605 */
t3=((C_word*)t0)[2];
f_4219(t3,t1,t2,C_fix(1));}

/* def-on-close523 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4219(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4219,NULL,4,t0,t1,t2,t3);}
/* def-more?524601 */
t4=((C_word*)t0)[2];
f_4214(t4,t1,t2,t3,*((C_word*)lf[291]+1));}

/* def-more?524 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4214(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4214,NULL,5,t0,t1,t2,t3,t4);}
/* body519526 */
t5=((C_word*)t0)[2];
f_3835(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3835(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3835,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1490 ##sys#file-nonblocking! */
t7=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_3839(2,t7,C_SCHEME_UNDEFINED);}}

/* k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3839,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1492 ##sys#make-string */
t5=*((C_word*)lf[289]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_3845(2,t5,((C_word*)t0)[10]);}}

/* k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li96),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3861,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3869,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,a[10]=((C_word)li98),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3956,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word)li99),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3969,a[2]=t6,a[3]=t3,a[4]=t5,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=((C_word)li101),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4002,a[2]=t8,a[3]=t7,a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4011,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li104),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4087,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,a[6]=((C_word)li109),tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1536 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t18))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a4086 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4087,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4093,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li108),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_4093(t7,t1,C_SCHEME_FALSE);}

/* loop in a4086 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4093(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4093,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4095,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li105),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4173,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word)li106),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4179,a[2]=((C_word*)t0)[2],a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1595 ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4189,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1601 fetch */
t5=((C_word*)t0)[5];
f_3869(t5,t4);}}

/* k4187 in loop in a4086 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1603 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4093(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a4178 in loop in a4086 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4179,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1598 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4093(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a4172 in loop in a4086 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4173,2,t0,t1);}
/* posixunix.scm: 1596 ##sys#scan-buffer-line */
t2=*((C_word*)lf[290]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a4086 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4095,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4102,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_4102(2,t8,(C_truep(t7)?t7:lf[287]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4145,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1578 ##sys#make-string */
t8=*((C_word*)lf[289]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k4143 in bumper in loop in a4086 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1584 ##sys#string-append */
t6=*((C_word*)lf[288]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_4102(2,t6,t1);}}

/* k4100 in bumper in loop in a4086 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4102,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4112,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1588 fetch */
t5=((C_word*)t0)[3];
f_3869(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1593 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k4110 in k4100 in bumper in loop in a4086 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1589 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4010 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4011,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4019,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_4019(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_4019(t8,(C_word)C_fixnum_difference(t7,t5));}}

/* k4017 in a4010 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4019(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4019,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li103),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_4021(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k4017 in a4010 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_4021(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4021,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* posixunix.scm: 1564 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4069,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1566 fetch */
t7=((C_word*)t0)[2];
f_3869(t7,t6);}}}

/* k4067 in loop in k4017 in a4010 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1569 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4021(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a4001 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4006,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1554 fetch */
t3=((C_word*)t0)[2];
f_3869(t3,t2);}

/* k4004 in a4001 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1555 peek */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_3861(((C_word*)t0)[2]));}

/* a3980 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3991,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1551 posix-error */
t3=lf[3];
f_1562(7,t3,t2,lf[48],((C_word*)t0)[3],lf[286],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_3991(2,t3,C_SCHEME_UNDEFINED);}}}

/* k3989 in a3980 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1552 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a3968 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1546 ready? */
t3=((C_word*)t0)[2];
f_3846(t3,t1);}}

/* a3955 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3960,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1538 fetch */
t3=((C_word*)t0)[2];
f_3869(t3,t2);}

/* k3958 in a3955 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_3861(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k3949 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1605 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k3952 in k3949 in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3869(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3869,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3881,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li97),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_3881(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3881,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3897,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1513 ##sys#thread-block-for-i/o! */
t6=*((C_word*)lf[282]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,*((C_word*)lf[283]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1516 posix-error */
t5=lf[3];
f_1562(7,t5,t1,lf[48],((C_word*)t0)[6],lf[284],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3918,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1520 more? */
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k3916 in loop in fetch in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1522 ##sys#thread-yield! */
t3=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_3927(2,t8,t7);}
else{
/* posixunix.scm: 1528 posix-error */
t7=lf[3];
f_1562(7,t7,t4,lf[48],((C_word*)t0)[3],lf[285],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_3927(2,t6,C_SCHEME_UNDEFINED);}}}

/* k3925 in k3916 in loop in fetch in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3919 in k3916 in loop in fetch in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1523 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3881(t2,((C_word*)t0)[2]);}

/* k3895 in loop in fetch in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1514 ##sys#thread-yield! */
t3=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3898 in k3895 in loop in fetch in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1515 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3881(t2,((C_word*)t0)[2]);}

/* peek in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall f_3861(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3846,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1498 ##sys#file-select-one */
t3=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k3858 in ready? in k3843 in k3837 in body519 in ##sys#custom-input-port in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1499 posix-error */
t3=lf[3];
f_1562(7,t3,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[280],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* duplicate-fileno in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3806r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3806r(t0,t1,t2,t3);}}

static void C_ccall f_3806r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[275]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3813,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_3813(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[275]);
t8=t5;
f_3813(t8,(C_word)C_dup2(t2,t6));}}

/* k3811 in duplicate-fileno in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3813,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3816,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1483 posix-error */
t3=lf[3];
f_1562(6,t3,t2,lf[48],lf[275],lf[276],((C_word*)t0)[2]);}
else{
t3=t2;
f_3816(2,t3,C_SCHEME_UNDEFINED);}}

/* k3814 in k3811 in duplicate-fileno in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3761,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3765,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1465 ##sys#check-port */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[269]);}

/* k3763 in port->fileno in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3765,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[270],t2);
if(C_truep(t3)){
/* posixunix.scm: 1466 ##sys#tcp-port->fileno */
t4=*((C_word*)lf[271]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1467 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[274]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k3798 in k3763 in port->fileno in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1472 posix-error */
t2=lf[3];
f_1562(6,t2,((C_word*)t0)[3],lf[60],lf[269],lf[272],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3783,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1470 posix-error */
t4=lf[3];
f_1562(6,t4,t3,lf[48],lf[269],lf[273],((C_word*)t0)[2]);}
else{
t4=t3;
f_3783(2,t4,C_SCHEME_UNDEFINED);}}}

/* k3781 in k3798 in k3763 in port->fileno in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3747r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3747r(t0,t1,t2,t3);}}

static void C_ccall f_3747r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[268]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3759,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1461 mode */
f_3681(t5,C_SCHEME_FALSE,t3);}

/* k3757 in open-output-file* in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3759,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1461 check */
f_3718(((C_word*)t0)[2],lf[268],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3733r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3733r(t0,t1,t2,t3);}}

static void C_ccall f_3733r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[267]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3745,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1457 mode */
f_3681(t5,C_SCHEME_TRUE,t3);}

/* k3743 in open-input-file* in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3745,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1457 check */
f_3718(((C_word*)t0)[2],lf[267],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3718(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3718,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1450 posix-error */
t6=lf[3];
f_1562(6,t6,t1,lf[48],t2,lf[265],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3731,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1451 ##sys#make-port */
t7=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[113]+1),lf[266],lf[88]);}}

/* k3729 in check in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3681(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3681,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3689,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[259]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1444 ##sys#error */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[260],t5);}
else{
t8=t4;
f_3689(2,t8,lf[261]);}}
else{
/* posixunix.scm: 1445 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[262],t5);}}
else{
t5=t4;
f_3689(2,t5,(C_truep(t2)?lf[263]:lf[264]));}}

/* k3687 in mode in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1440 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3656,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[253]);
t5=(C_word)C_i_check_string_2(t3,lf[253]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3637,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_3637(2,t9,C_SCHEME_FALSE);}}

/* k3635 in file-link in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_3641(2,t3,C_SCHEME_FALSE);}}

/* k3639 in k3635 in file-link in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub463(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1425 posix-error */
t3=lf[3];
f_1562(7,t3,((C_word*)t0)[4],lf[48],lf[254],lf[255],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3606,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[251]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3614,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3630,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1414 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3628 in read-symbolic-link in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1414 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3612 in read-symbolic-link in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3614,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3617,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1416 posix-error */
t4=lf[3];
f_1562(6,t4,t3,lf[48],lf[251],lf[252],((C_word*)t0)[2]);}
else{
t4=t3;
f_3617(2,t4,C_SCHEME_UNDEFINED);}}

/* k3615 in k3612 in read-symbolic-link in k3603 in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1417 substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3568,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[247]);
t5=(C_word)C_i_check_string_2(t3,lf[247]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3589,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1402 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3599 in create-symbolic-link in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1402 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3587 in create-symbolic-link in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3597,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1403 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3595 in k3587 in create-symbolic-link in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1403 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3591 in k3587 in create-symbolic-link in k3564 in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1405 posix-error */
t3=lf[3];
f_1562(7,t3,((C_word*)t0)[4],lf[48],lf[248],lf[249],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* set-process-group-id! in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3543,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[244]);
t5=(C_word)C_i_check_exact_2(t3,lf[244]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3559,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1380 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k3557 in set-process-group-id! in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1381 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[244],lf[245],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* create-session in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3528,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3532,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3538,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1372 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3532(2,t4,C_SCHEME_UNDEFINED);}}

/* k3536 in create-session in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1373 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[242],lf[243]);}

/* k3530 in create-session in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3522,3,t0,t1,t2);}
/* posixunix.scm: 1367 check */
f_3486(t1,t2,C_fix((C_word)X_OK),lf[241]);}

/* file-write-access? in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3516,3,t0,t1,t2);}
/* posixunix.scm: 1366 check */
f_3486(t1,t2,C_fix((C_word)W_OK),lf[240]);}

/* file-read-access? in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3510,3,t0,t1,t2);}
/* posixunix.scm: 1365 check */
f_3486(t1,t2,C_fix((C_word)R_OK),lf[239]);}

/* check in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3486(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3486,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3504,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3508,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1362 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3506 in check in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1362 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3502 in check in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3504,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3496,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3496(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1363 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3494 in k3502 in check in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3456,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[237]);
t6=(C_word)C_i_check_exact_2(t3,lf[237]);
t7=(C_word)C_i_check_exact_2(t4,lf[237]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3480,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3484,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1352 ##sys#expand-home-path */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k3482 in change-file-owner in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1352 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3478 in change-file-owner in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1353 posix-error */
t3=lf[3];
f_1562(8,t3,((C_word*)t0)[3],lf[48],lf[237],lf[238],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3429,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[235]);
t5=(C_word)C_i_check_exact_2(t3,lf[235]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3450,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3454,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1344 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3452 in change-file-mode in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1344 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3448 in change-file-mode in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1345 posix-error */
t3=lf[3];
f_1562(7,t3,((C_word*)t0)[3],lf[48],lf[235],lf[236],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3365,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[194]);
t5=(C_word)C_i_check_exact_2(t3,lf[194]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3353,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_3353(2,t9,C_SCHEME_FALSE);}}

/* k3351 in initialize-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3353,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub403(C_SCHEME_UNDEFINED,t1,t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1265 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3379 in k3351 in initialize-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1266 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[194],lf[195],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3291,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3295,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_3221(t4);
if(C_truep(t5)){
t6=t3;
f_3295(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1248 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[191],lf[193]);}}

/* k3293 in set-groups! in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3300,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3300(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do390 in k3293 in set-groups! in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3300(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3300,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1253 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[191]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k3314 in do390 in k3293 in set-groups! in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1254 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[191],lf[192],((C_word*)t0)[2]);}

/* get-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3228,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3232,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3286,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1234 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3232(2,t4,C_SCHEME_UNDEFINED);}}

/* k3284 in get-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1235 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[187],lf[190]);}

/* k3230 in get-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_3221(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_3235(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1237 ##sys#error */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[187],lf[189]);}}

/* k3233 in k3230 in get-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub372(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3267,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1239 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_3238(2,t5,C_SCHEME_UNDEFINED);}}

/* k3265 in k3233 in k3230 in get-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1240 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[187],lf[188]);}

/* k3236 in k3233 in k3230 in get-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3238,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3243,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3243(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k3236 in k3233 in k3230 in get-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3243(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3243,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3257,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1244 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3255 in loop in k3236 in k3233 in k3230 in get-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3257,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall f_3221(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub376(C_SCHEME_UNDEFINED,t2));}

/* group-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3135r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3135r(t0,t1,t2,t3);}}

static void C_ccall f_3135r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3139,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3139(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3139(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3137 in group-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_3142(t3,(C_word)C_getgrgid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[185]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3193,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1208 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3191 in k3137 in group-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3142(t2,(C_word)C_getgrnam(t1));}

/* k3140 in k3137 in group-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3142,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3150 in k3140 in k3137 in group-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3156,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k3154 in k3150 in k3140 in k3137 in group-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3160,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3165,a[2]=t4,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3165(t6,t2,C_fix(0));}

/* loop in k3154 in k3150 in k3140 in k3137 in group-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3165(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3165,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3169,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub355(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k3167 in loop in k3154 in k3150 in k3140 in k3137 in group-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3169,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3179,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1217 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3165(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k3177 in k3167 in loop in k3154 in k3150 in k3140 in k3137 in group-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3179,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3158 in k3154 in k3150 in k3140 in k3137 in group-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[181]+1):*((C_word*)lf[182]+1));
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3118,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3122,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1193 current-effective-user-id */
t4=*((C_word*)lf[175]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3120 in current-effective-user-name in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1193 user-information */
t2=*((C_word*)lf[180]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3116 in current-effective-user-name in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3104,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3108,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1190 current-user-id */
t4=*((C_word*)lf[174]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3106 in current-user-name in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1190 user-information */
t2=*((C_word*)lf[180]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3102 in current-user-name in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* user-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3029(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3029r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3029r(t0,t1,t2,t3);}}

static void C_ccall f_3029r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3033,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3033(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3033(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3031 in user-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_3036(t3,(C_word)C_getpwuid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[180]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3075,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1178 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k3073 in k3031 in user-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3036(t2,(C_word)C_getpwnam(t1));}

/* k3034 in k3031 in user-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_3036(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3036,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3044 in k3034 in k3031 in user-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3050,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k3048 in k3044 in k3034 in k3031 in user-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3054,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k3052 in k3048 in k3044 in k3034 in k3031 in user-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3058,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k3056 in k3052 in k3048 in k3044 in k3034 in k3031 in user-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3062,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k3060 in k3056 in k3052 in k3048 in k3044 in k3034 in k3031 in user-information in k3025 in k3021 in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[181]+1):*((C_word*)lf[182]+1));
t3=t2;
((C_proc9)C_retrieve_proc(t3))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* set-group-id! in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3006,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3016,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1148 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3014 in set-group-id! in k3002 in k2998 in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1149 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[172],lf[177],((C_word*)t0)[2]);}

/* set-user-id! in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2983,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2993,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1128 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2991 in set-user-id! in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1129 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[172],lf[173],((C_word*)t0)[2]);}

/* system-information in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2949,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2978,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1117 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2949(2,t3,C_SCHEME_UNDEFINED);}}

/* k2976 in system-information in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1118 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[169],lf[171]);}

/* k2947 in system-information in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k2954 in k2947 in system-information in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2960,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k2958 in k2954 in k2947 in system-information in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2964,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k2962 in k2958 in k2954 in k2947 in system-information in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2968,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k2966 in k2962 in k2958 in k2954 in k2947 in system-information in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2972,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k2970 in k2966 in k2962 in k2958 in k2954 in k2947 in system-information in k2941 in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2972,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2927,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[167]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1096 posix-error */
t5=lf[3];
f_1562(5,t5,t1,lf[161],lf[167],lf[168]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2912,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[165]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1090 posix-error */
t5=lf[3];
f_1562(5,t5,t1,lf[161],lf[165],lf[166]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2906,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[164]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2880,a[2]=t3,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2880(t5,t1,*((C_word*)lf[156]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_2880(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2880,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1080 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2850,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[160]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2857,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2868,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a2867 in set-signal-mask! in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2868,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[160]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k2855 in set-signal-mask! in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1073 posix-error */
t2=lf[3];
f_1562(5,t2,((C_word*)t0)[2],lf[161],lf[160],lf[162]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2832,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2842,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1059 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1061 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k2840 in ##sys#interrupt-hook in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1060 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2819,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[159]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k2806 in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2810,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[158]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 976  posix-error */
t3=lf[3];
f_1562(5,t3,t2,lf[48],lf[129],lf[130]);}
else{
t3=t2;
f_2767(2,t3,C_SCHEME_UNDEFINED);}}

/* k2765 in create-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 977  values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2743r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2743r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2743r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[128]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2747,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2745 in with-output-to-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2747,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2753,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 964  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2752 in k2745 in with-output-to-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2753r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2753r(t0,t1,t2);}}

static void C_ccall f_2753r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2757,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 966  close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2755 in a2752 in k2745 in with-output-to-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[128]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2723r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2723r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2723r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[126]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2727,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2725 in with-input-from-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2727,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2733,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 954  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2732 in k2725 in with-input-from-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2733r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2733r(t0,t1,t2);}}

static void C_ccall f_2733r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2737,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 956  close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2735 in a2732 in k2725 in with-input-from-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[126]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2699(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2699r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2699r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2699r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2703,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2701 in call-with-output-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2708,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2714,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li48),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 944  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2713 in k2701 in call-with-output-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2714r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2714r(t0,t1,t2);}}

static void C_ccall f_2714r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2718,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 947  close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2716 in a2713 in k2701 in call-with-output-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2707 in k2701 in call-with-output-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2708,2,t0,t1);}
/* posixunix.scm: 945  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2675r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2675r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2675r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2679,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2677 in call-with-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2684,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2690,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li45),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 936  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2689 in k2677 in call-with-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2690r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2690r(t0,t1,t2);}}

static void C_ccall f_2690r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 939  close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2692 in a2689 in k2677 in call-with-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2683 in k2677 in call-with-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
/* posixunix.scm: 937  proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2659,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2663,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 923  ##sys#check-port */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[118]);}

/* k2661 in close-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2663,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2666,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 925  posix-error */
t5=lf[3];
f_1562(6,t5,t3,lf[48],lf[119],lf[120],((C_word*)t0)[3]);}
else{
t5=t3;
f_2666(2,t5,C_SCHEME_UNDEFINED);}}

/* k2664 in k2661 in close-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2623r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2623r(t0,t1,t2,t3);}}

static void C_ccall f_2623r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[117]);
t5=f_2554(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2637,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[109]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2644,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 918  ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[116]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2654,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 919  ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 920  badmode */
f_2566(t6,t5);}}}

/* k2652 in open-output-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2637(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k2642 in open-output-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2637(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k2635 in open-output-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 914  check */
f_2572(((C_word*)t0)[3],lf[117],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2587r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2587r(t0,t1,t2,t3);}}

static void C_ccall f_2587r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[115]);
t5=f_2554(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2601,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[109]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2608,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 907  ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[116]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2618,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 908  ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 909  badmode */
f_2566(t6,t5);}}}

/* k2616 in open-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2601(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k2606 in open-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2608,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2601(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k2599 in open-input-pipe in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 903  check */
f_2572(((C_word*)t0)[3],lf[115],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_2572(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2572,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 895  posix-error */
t6=lf[3];
f_1562(6,t6,t1,lf[48],t2,lf[111],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2585,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 896  ##sys#make-port */
t7=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[113]+1),lf[114],lf[88]);}}

/* k2583 in check in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_2566(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2566,NULL,2,t1,t2);}
/* posixunix.scm: 892  ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[110],t2);}

/* mode in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall f_2554(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[109]));}

/* current-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2511r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2511r(t0,t1,t2);}}

static void C_ccall f_2511r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2515(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2515(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2513 in current-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 880  change-directory */
t2=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2524,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 881  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k2522 in k2513 in current-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 884  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 885  posix-error */
t3=lf[3];
f_1562(5,t3,((C_word*)t0)[2],lf[48],lf[105],lf[108]);}}

/* directory? in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2488,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[106]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2495,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2509,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 873  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2507 in directory? in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 873  ##sys#file-info */
t2=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2493 in directory? in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_2331r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2331r(t0,t1,t2);}}

static void C_ccall f_2331r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2431,a[2]=t3,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2436,a[2]=t4,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec182207 */
t6=t5;
f_2436(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?183205 */
t8=t4;
f_2431(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body180185 */
t10=t3;
f_2333(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec182 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_2436(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2436,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2444,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 846  current-directory */
t3=*((C_word*)lf[105]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2442 in def-spec182 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?183205 */
t2=((C_word*)t0)[3];
f_2431(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?183 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_2431(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2431,NULL,3,t0,t1,t2);}
/* body180185 */
t3=((C_word*)t0)[2];
f_2333(t3,t1,t2,C_SCHEME_FALSE);}

/* body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_2333(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2333,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[102]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 848  make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k2338 in body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 849  ##sys#make-pointer */
t3=*((C_word*)lf[104]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2341 in k2338 in body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 850  ##sys#make-pointer */
t3=*((C_word*)lf[104]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2344 in k2341 in k2338 in body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 851  ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k2428 in k2344 in k2341 in k2338 in body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 851  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2348 in k2344 in k2341 in k2338 in body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2350,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 853  posix-error */
t3=lf[3];
f_1562(6,t3,((C_word*)t0)[7],lf[48],lf[102],lf[103],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word)li31),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_2364(t6,((C_word*)t0)[7]);}}

/* loop in k2348 in k2344 in k2341 in k2338 in body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_2364(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2364,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 861  ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k2372 in loop in k2348 in k2344 in k2341 in k2338 in body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 862  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_fix(0));}

/* k2375 in k2372 in loop in k2348 in k2344 in k2341 in k2338 in body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2380,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 863  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_2380(2,t3,C_SCHEME_FALSE);}}

/* k2378 in k2375 in k2372 in loop in k2348 in k2344 in k2341 in k2338 in body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_2386(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_2386(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_2386(t4,C_SCHEME_FALSE);}}

/* k2384 in k2378 in k2375 in k2372 in loop in k2348 in k2344 in k2341 in k2338 in body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_2386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2386,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 868  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2364(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 869  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2364(t3,t2);}}

/* k2394 in k2384 in k2378 in k2375 in k2372 in loop in k2348 in k2344 in k2341 in k2338 in body180 in directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2396,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2307,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[98]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2325,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2329,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 839  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2327 in delete-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 839  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2323 in delete-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 840  posix-error */
t3=lf[3];
f_1562(6,t3,((C_word*)t0)[3],lf[48],lf[98],lf[99],((C_word*)t0)[2]);}}

/* change-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2283,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[96]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2301,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 833  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2303 in change-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 833  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2299 in change-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 834  posix-error */
t3=lf[3];
f_1562(6,t3,((C_word*)t0)[3],lf[48],lf[96],lf[97],((C_word*)t0)[2]);}}

/* create-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2259,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[94]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2277,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2281,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 827  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2279 in create-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 827  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2275 in create-directory in k2255 in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 828  posix-error */
t3=lf[3];
f_1562(6,t3,((C_word*)t0)[3],lf[48],lf[94],lf[95],((C_word*)t0)[2]);}}

/* set-file-position! in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2197r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2197r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2197r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[86]);
t8=(C_word)C_i_check_exact_2(t6,lf[86]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2210,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 799  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[91],lf[86],lf[92],t3,t2);}
else{
t10=t9;
f_2210(2,t10,C_SCHEME_UNDEFINED);}}

/* k2208 in set-file-position! in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 800  port? */
t4=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k2220 in k2208 in set-file-position! in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[88]);
t4=((C_word*)t0)[4];
f_2216(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_2216(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 804  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[60],lf[86],lf[89],((C_word*)t0)[5]);}}}

/* k2214 in k2208 in set-file-position! in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 805  posix-error */
t2=lf[3];
f_1562(7,t2,((C_word*)t0)[4],lf[48],lf[86],lf[87],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* symbolic-link? in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2188,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2195,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 791  ##sys#stat */
f_2074(t4,t2,C_SCHEME_TRUE,lf[85]);}

/* k2193 in symbolic-link? in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2179,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 786  ##sys#stat */
f_2074(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k2184 in regular-file? in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2173,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2177,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 782  ##sys#stat */
f_2074(t3,t2,C_SCHEME_FALSE,lf[83]);}

/* k2175 in file-permissions in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2167,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2171,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 781  ##sys#stat */
f_2074(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k2169 in file-owner in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2161,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2165,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 780  ##sys#stat */
f_2074(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k2163 in file-change-time in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2155,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2159,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#stat */
f_2074(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k2157 in file-access-time in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2159,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2149,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2153,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 778  ##sys#stat */
f_2074(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k2151 in file-modification-time in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2143,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 777  ##sys#stat */
f_2074(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k2145 in file-size in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2147,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2111r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2111r(t0,t1,t2,t3);}}

static void C_ccall f_2111r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2115,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2122,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_2122(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2122(2,t7,(C_word)C_i_car(t3));}
else{
/* posixunix.scm: 770  ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k2120 in file-stat in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 770  ##sys#stat */
f_2074(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[77]);}

/* k2113 in file-stat in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2115,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_2074(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2074,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2078,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_2078(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2099,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2106,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 761  ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 765  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[76],t2);}}}

/* k2104 in ##sys#stat in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 761  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2097 in ##sys#stat in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2078(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k2076 in ##sys#stat in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 767  posix-error */
t2=lf[3];
f_1562(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[75],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1882r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1882r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1882r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_1856(C_fix(0));
t10=f_1856(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1898,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_1898(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 690  fd_set */
t14=t12;
f_1898(2,t14,f_1862(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[68]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2055,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t15=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a2054 in file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2055,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 697  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1862(C_fix(0),t2));}

/* k1896 in file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_1904(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 702  fd_set */
t5=t3;
f_1904(2,t5,f_1862(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[68]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a2028 in k1896 in file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2029,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 709  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_1862(C_fix(1),t2));}

/* k1902 in k1896 in file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[68]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_1907(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_1907(t4,(C_word)C_C_select(t3));}}

/* k1905 in k1902 in k1896 in file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_1907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1907,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 716  posix-error */
t2=lf[3];
f_1562(7,t2,((C_word*)t0)[5],lf[48],lf[68],lf[69],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 717  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 722  fd_test */
t4=t3;
f_1946(t4,f_1872(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1987,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1989,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_1946(t4,C_SCHEME_FALSE);}}}}

/* a1988 in k1905 in k1902 in k1896 in file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1989,3,t0,t1,t2);}
t3=f_1872(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1985 in k1905 in k1902 in k1896 in file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1946(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1944 in k1905 in k1902 in k1896 in file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_1946(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1946,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1950,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 728  fd_test */
t3=t2;
f_1950(t3,f_1872(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1962,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1964,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_1950(t3,C_SCHEME_FALSE);}}

/* a1963 in k1944 in k1905 in k1902 in k1896 in file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1964,3,t0,t1,t2);}
t3=f_1872(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1960 in k1944 in k1905 in k1902 in k1896 in file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1950(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1948 in k1944 in k1905 in k1902 in k1896 in file-select in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_fcall f_1950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 719  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall f_1872(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub92(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_set in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall f_1862(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub86(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_zero in k1548 in k1545 in k1542 in k1539 in k1536 */
static C_word C_fcall f_1856(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub81(C_SCHEME_UNDEFINED,t2));}

/* file-mkstemp in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1824,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[65]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1831,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 668  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1829 in file-mkstemp in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1837,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 672  posix-error */
t6=lf[3];
f_1562(6,t6,t4,lf[48],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t6=t4;
f_1837(2,t6,C_SCHEME_UNDEFINED);}}

/* k1835 in k1829 in file-mkstemp in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 673  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1842 in k1835 in k1829 in file-mkstemp in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 673  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1785r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1785r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1785r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[62]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1792,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1792(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 657  ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[60],lf[62],lf[64],t3);}}

/* k1790 in file-write in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[62]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1801,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 662  posix-error */
t8=lf[3];
f_1562(7,t8,t6,lf[48],lf[62],lf[63],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_1801(2,t8,C_SCHEME_UNDEFINED);}}

/* k1799 in k1790 in file-write in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1743r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1743r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1743r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1753,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1753(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixunix.scm: 645  make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k1751 in file-read in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1756(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 647  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[60],lf[58],lf[61],t1);}}

/* k1754 in k1751 in file-read in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1759,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 650  posix-error */
t5=lf[3];
f_1562(7,t5,t3,lf[48],lf[58],lf[59],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_1759(2,t5,C_SCHEME_UNDEFINED);}}

/* k1757 in k1754 in k1751 in file-read in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1728,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[55]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 638  posix-error */
t4=lf[3];
f_1562(6,t4,t1,lf[48],lf[55],lf[56],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1690r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1690r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1690r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[51]);
t8=(C_word)C_i_check_exact_2(t3,lf[51]);
t9=(C_word)C_i_check_exact_2(t6,lf[51]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1707,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1720,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 629  ##sys#expand-home-path */
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k1718 in file-open in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 629  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1705 in file-open in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1707,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1710,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 631  posix-error */
t5=lf[3];
f_1562(8,t5,t3,lf[48],lf[51],lf[52],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_1710(2,t5,C_SCHEME_UNDEFINED);}}

/* k1708 in k1705 in file-open in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1644r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1644r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1644r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1648,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1648(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1648(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1646 in file-control in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[47]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[47]);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_integer_argumentp(t1);
t9=(C_word)stub24(C_SCHEME_UNDEFINED,t6,t7,t8);
t10=(C_word)C_eqp(t9,C_fix(-1));
if(C_truep(t10)){
/* posixunix.scm: 619  posix-error */
t11=lf[3];
f_1562(7,t11,((C_word*)t0)[2],lf[48],lf[47],lf[49],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t9);}}

/* ##sys#file-select-one in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1587,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub17(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-nonblocking! in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1580,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub13(C_SCHEME_UNDEFINED,t3));}

/* posix-error in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1562r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1562r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1562r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1566,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 509  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1564 in posix-error in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1573,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1577,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub3(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k1575 in k1564 in posix-error in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 510  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k1571 in k1564 in posix-error in k1548 in k1545 in k1542 in k1539 in k1536 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[538] = {
{"toplevelposixunix.scm",(void*)C_posix_toplevel},
{"f_1538posixunix.scm",(void*)f_1538},
{"f_1541posixunix.scm",(void*)f_1541},
{"f_1544posixunix.scm",(void*)f_1544},
{"f_1547posixunix.scm",(void*)f_1547},
{"f_1550posixunix.scm",(void*)f_1550},
{"f_6896posixunix.scm",(void*)f_6896},
{"f_6912posixunix.scm",(void*)f_6912},
{"f_6900posixunix.scm",(void*)f_6900},
{"f_6903posixunix.scm",(void*)f_6903},
{"f_2257posixunix.scm",(void*)f_2257},
{"f_2808posixunix.scm",(void*)f_2808},
{"f_6890posixunix.scm",(void*)f_6890},
{"f_2943posixunix.scm",(void*)f_2943},
{"f_6887posixunix.scm",(void*)f_6887},
{"f_3000posixunix.scm",(void*)f_3000},
{"f_6872posixunix.scm",(void*)f_6872},
{"f_6882posixunix.scm",(void*)f_6882},
{"f_6869posixunix.scm",(void*)f_6869},
{"f_3004posixunix.scm",(void*)f_3004},
{"f_6866posixunix.scm",(void*)f_6866},
{"f_3023posixunix.scm",(void*)f_3023},
{"f_6851posixunix.scm",(void*)f_6851},
{"f_6861posixunix.scm",(void*)f_6861},
{"f_6848posixunix.scm",(void*)f_6848},
{"f_3027posixunix.scm",(void*)f_3027},
{"f_6830posixunix.scm",(void*)f_6830},
{"f_6843posixunix.scm",(void*)f_6843},
{"f_6837posixunix.scm",(void*)f_6837},
{"f_3566posixunix.scm",(void*)f_3566},
{"f_3605posixunix.scm",(void*)f_3605},
{"f_6807posixunix.scm",(void*)f_6807},
{"f_6799posixunix.scm",(void*)f_6799},
{"f_6542posixunix.scm",(void*)f_6542},
{"f_6725posixunix.scm",(void*)f_6725},
{"f_6731posixunix.scm",(void*)f_6731},
{"f_6720posixunix.scm",(void*)f_6720},
{"f_6715posixunix.scm",(void*)f_6715},
{"f_6544posixunix.scm",(void*)f_6544},
{"f_6702posixunix.scm",(void*)f_6702},
{"f_6710posixunix.scm",(void*)f_6710},
{"f_6551posixunix.scm",(void*)f_6551},
{"f_6690posixunix.scm",(void*)f_6690},
{"f_6684posixunix.scm",(void*)f_6684},
{"f_6561posixunix.scm",(void*)f_6561},
{"f_6563posixunix.scm",(void*)f_6563},
{"f_6582posixunix.scm",(void*)f_6582},
{"f_6670posixunix.scm",(void*)f_6670},
{"f_6677posixunix.scm",(void*)f_6677},
{"f_6664posixunix.scm",(void*)f_6664},
{"f_6597posixunix.scm",(void*)f_6597},
{"f_6657posixunix.scm",(void*)f_6657},
{"f_6654posixunix.scm",(void*)f_6654},
{"f_6641posixunix.scm",(void*)f_6641},
{"f_6617posixunix.scm",(void*)f_6617},
{"f_6639posixunix.scm",(void*)f_6639},
{"f_6625posixunix.scm",(void*)f_6625},
{"f_6632posixunix.scm",(void*)f_6632},
{"f_6629posixunix.scm",(void*)f_6629},
{"f_6609posixunix.scm",(void*)f_6609},
{"f_6607posixunix.scm",(void*)f_6607},
{"f_6691posixunix.scm",(void*)f_6691},
{"f_6482posixunix.scm",(void*)f_6482},
{"f_6494posixunix.scm",(void*)f_6494},
{"f_6489posixunix.scm",(void*)f_6489},
{"f_6484posixunix.scm",(void*)f_6484},
{"f_6422posixunix.scm",(void*)f_6422},
{"f_6434posixunix.scm",(void*)f_6434},
{"f_6429posixunix.scm",(void*)f_6429},
{"f_6424posixunix.scm",(void*)f_6424},
{"f_6361posixunix.scm",(void*)f_6361},
{"f_6416posixunix.scm",(void*)f_6416},
{"f_6420posixunix.scm",(void*)f_6420},
{"f_6382posixunix.scm",(void*)f_6382},
{"f_6385posixunix.scm",(void*)f_6385},
{"f_6396posixunix.scm",(void*)f_6396},
{"f_6390posixunix.scm",(void*)f_6390},
{"f_6363posixunix.scm",(void*)f_6363},
{"f_6372posixunix.scm",(void*)f_6372},
{"f_6297posixunix.scm",(void*)f_6297},
{"f_6309posixunix.scm",(void*)f_6309},
{"f_6340posixunix.scm",(void*)f_6340},
{"f_6320posixunix.scm",(void*)f_6320},
{"f_6336posixunix.scm",(void*)f_6336},
{"f_6324posixunix.scm",(void*)f_6324},
{"f_6332posixunix.scm",(void*)f_6332},
{"f_6328posixunix.scm",(void*)f_6328},
{"f_6303posixunix.scm",(void*)f_6303},
{"f_6286posixunix.scm",(void*)f_6286},
{"f_6290posixunix.scm",(void*)f_6290},
{"f_6275posixunix.scm",(void*)f_6275},
{"f_6279posixunix.scm",(void*)f_6279},
{"f_6230posixunix.scm",(void*)f_6230},
{"f_6234posixunix.scm",(void*)f_6234},
{"f_6237posixunix.scm",(void*)f_6237},
{"f_6240posixunix.scm",(void*)f_6240},
{"f_6253posixunix.scm",(void*)f_6253},
{"f_6257posixunix.scm",(void*)f_6257},
{"f_6260posixunix.scm",(void*)f_6260},
{"f_6263posixunix.scm",(void*)f_6263},
{"f_6251posixunix.scm",(void*)f_6251},
{"f_6214posixunix.scm",(void*)f_6214},
{"f_6197posixunix.scm",(void*)f_6197},
{"f_6210posixunix.scm",(void*)f_6210},
{"f_6122posixunix.scm",(void*)f_6122},
{"f_6183posixunix.scm",(void*)f_6183},
{"f_6196posixunix.scm",(void*)f_6196},
{"f_6163posixunix.scm",(void*)f_6163},
{"f_6178posixunix.scm",(void*)f_6178},
{"f_6172posixunix.scm",(void*)f_6172},
{"f_6126posixunix.scm",(void*)f_6126},
{"f_6128posixunix.scm",(void*)f_6128},
{"f_6149posixunix.scm",(void*)f_6149},
{"f_6143posixunix.scm",(void*)f_6143},
{"f_6070posixunix.scm",(void*)f_6070},
{"f_6077posixunix.scm",(void*)f_6077},
{"f_6096posixunix.scm",(void*)f_6096},
{"f_6100posixunix.scm",(void*)f_6100},
{"f_6064posixunix.scm",(void*)f_6064},
{"f_6055posixunix.scm",(void*)f_6055},
{"f_6059posixunix.scm",(void*)f_6059},
{"f_6028posixunix.scm",(void*)f_6028},
{"f_6021posixunix.scm",(void*)f_6021},
{"f_6018posixunix.scm",(void*)f_6018},
{"f_6015posixunix.scm",(void*)f_6015},
{"f_5937posixunix.scm",(void*)f_5937},
{"f_5973posixunix.scm",(void*)f_5973},
{"f_5967posixunix.scm",(void*)f_5967},
{"f_5920posixunix.scm",(void*)f_5920},
{"f_5738posixunix.scm",(void*)f_5738},
{"f_5872posixunix.scm",(void*)f_5872},
{"f_5867posixunix.scm",(void*)f_5867},
{"f_5740posixunix.scm",(void*)f_5740},
{"f_5750posixunix.scm",(void*)f_5750},
{"f_5758posixunix.scm",(void*)f_5758},
{"f_5804posixunix.scm",(void*)f_5804},
{"f_5771posixunix.scm",(void*)f_5771},
{"f_5796posixunix.scm",(void*)f_5796},
{"f_5774posixunix.scm",(void*)f_5774},
{"f_5719posixunix.scm",(void*)f_5719},
{"f_5700posixunix.scm",(void*)f_5700},
{"f_5658posixunix.scm",(void*)f_5658},
{"f_5680posixunix.scm",(void*)f_5680},
{"f_5684posixunix.scm",(void*)f_5684},
{"f_5546posixunix.scm",(void*)f_5546},
{"f_5552posixunix.scm",(void*)f_5552},
{"f_5573posixunix.scm",(void*)f_5573},
{"f_5650posixunix.scm",(void*)f_5650},
{"f_5577posixunix.scm",(void*)f_5577},
{"f_5580posixunix.scm",(void*)f_5580},
{"f_5583posixunix.scm",(void*)f_5583},
{"f_5590posixunix.scm",(void*)f_5590},
{"f_5592posixunix.scm",(void*)f_5592},
{"f_5609posixunix.scm",(void*)f_5609},
{"f_5619posixunix.scm",(void*)f_5619},
{"f_5623posixunix.scm",(void*)f_5623},
{"f_5567posixunix.scm",(void*)f_5567},
{"f_5534posixunix.scm",(void*)f_5534},
{"f_5538posixunix.scm",(void*)f_5538},
{"f_5541posixunix.scm",(void*)f_5541},
{"f_5499posixunix.scm",(void*)f_5499},
{"f_5503posixunix.scm",(void*)f_5503},
{"f_5523posixunix.scm",(void*)f_5523},
{"f_5527posixunix.scm",(void*)f_5527},
{"f_5476posixunix.scm",(void*)f_5476},
{"f_5480posixunix.scm",(void*)f_5480},
{"f_5444posixunix.scm",(void*)f_5444},
{"f_5448posixunix.scm",(void*)f_5448},
{"f_5425posixunix.scm",(void*)f_5425},
{"f_5429posixunix.scm",(void*)f_5429},
{"f_5432posixunix.scm",(void*)f_5432},
{"f_5366posixunix.scm",(void*)f_5366},
{"f_5370posixunix.scm",(void*)f_5370},
{"f_5376posixunix.scm",(void*)f_5376},
{"f_5359posixunix.scm",(void*)f_5359},
{"f_5343posixunix.scm",(void*)f_5343},
{"f_5331posixunix.scm",(void*)f_5331},
{"f_5303posixunix.scm",(void*)f_5303},
{"f_5310posixunix.scm",(void*)f_5310},
{"f_5275posixunix.scm",(void*)f_5275},
{"f_5282posixunix.scm",(void*)f_5282},
{"f_5237posixunix.scm",(void*)f_5237},
{"f_5241posixunix.scm",(void*)f_5241},
{"f_5159posixunix.scm",(void*)f_5159},
{"f_5163posixunix.scm",(void*)f_5163},
{"f_5169posixunix.scm",(void*)f_5169},
{"f_5187posixunix.scm",(void*)f_5187},
{"f_5178posixunix.scm",(void*)f_5178},
{"f_5126posixunix.scm",(void*)f_5126},
{"f_5130posixunix.scm",(void*)f_5130},
{"f_5107posixunix.scm",(void*)f_5107},
{"f_5098posixunix.scm",(void*)f_5098},
{"f_5092posixunix.scm",(void*)f_5092},
{"f_5083posixunix.scm",(void*)f_5083},
{"f_5048posixunix.scm",(void*)f_5048},
{"f_4986posixunix.scm",(void*)f_4986},
{"f_4990posixunix.scm",(void*)f_4990},
{"f_4996posixunix.scm",(void*)f_4996},
{"f_5015posixunix.scm",(void*)f_5015},
{"f_5002posixunix.scm",(void*)f_5002},
{"f_4883posixunix.scm",(void*)f_4883},
{"f_4889posixunix.scm",(void*)f_4889},
{"f_4893posixunix.scm",(void*)f_4893},
{"f_4901posixunix.scm",(void*)f_4901},
{"f_4927posixunix.scm",(void*)f_4927},
{"f_4931posixunix.scm",(void*)f_4931},
{"f_4919posixunix.scm",(void*)f_4919},
{"f_4863posixunix.scm",(void*)f_4863},
{"f_4871posixunix.scm",(void*)f_4871},
{"f_4846posixunix.scm",(void*)f_4846},
{"f_4857posixunix.scm",(void*)f_4857},
{"f_4861posixunix.scm",(void*)f_4861},
{"f_4820posixunix.scm",(void*)f_4820},
{"f_4844posixunix.scm",(void*)f_4844},
{"f_4827posixunix.scm",(void*)f_4827},
{"f_4777posixunix.scm",(void*)f_4777},
{"f_4784posixunix.scm",(void*)f_4784},
{"f_4805posixunix.scm",(void*)f_4805},
{"f_4801posixunix.scm",(void*)f_4801},
{"f_4749posixunix.scm",(void*)f_4749},
{"f_4727posixunix.scm",(void*)f_4727},
{"f_4731posixunix.scm",(void*)f_4731},
{"f_4712posixunix.scm",(void*)f_4712},
{"f_4716posixunix.scm",(void*)f_4716},
{"f_4697posixunix.scm",(void*)f_4697},
{"f_4701posixunix.scm",(void*)f_4701},
{"f_4679posixunix.scm",(void*)f_4679},
{"f_4605posixunix.scm",(void*)f_4605},
{"f_4627posixunix.scm",(void*)f_4627},
{"f_4633posixunix.scm",(void*)f_4633},
{"f_4566posixunix.scm",(void*)f_4566},
{"f_4594posixunix.scm",(void*)f_4594},
{"f_4590posixunix.scm",(void*)f_4590},
{"f_4583posixunix.scm",(void*)f_4583},
{"f_4307posixunix.scm",(void*)f_4307},
{"f_4503posixunix.scm",(void*)f_4503},
{"f_4498posixunix.scm",(void*)f_4498},
{"f_4493posixunix.scm",(void*)f_4493},
{"f_4309posixunix.scm",(void*)f_4309},
{"f_4313posixunix.scm",(void*)f_4313},
{"f_4419posixunix.scm",(void*)f_4419},
{"f_4420posixunix.scm",(void*)f_4420},
{"f_4437posixunix.scm",(void*)f_4437},
{"f_4447posixunix.scm",(void*)f_4447},
{"f_4405posixunix.scm",(void*)f_4405},
{"f_4361posixunix.scm",(void*)f_4361},
{"f_4397posixunix.scm",(void*)f_4397},
{"f_4376posixunix.scm",(void*)f_4376},
{"f_4386posixunix.scm",(void*)f_4386},
{"f_4370posixunix.scm",(void*)f_4370},
{"f_4365posixunix.scm",(void*)f_4365},
{"f_4368posixunix.scm",(void*)f_4368},
{"f_4315posixunix.scm",(void*)f_4315},
{"f_4350posixunix.scm",(void*)f_4350},
{"f_4331posixunix.scm",(void*)f_4331},
{"f_3833posixunix.scm",(void*)f_3833},
{"f_4229posixunix.scm",(void*)f_4229},
{"f_4224posixunix.scm",(void*)f_4224},
{"f_4219posixunix.scm",(void*)f_4219},
{"f_4214posixunix.scm",(void*)f_4214},
{"f_3835posixunix.scm",(void*)f_3835},
{"f_3839posixunix.scm",(void*)f_3839},
{"f_3845posixunix.scm",(void*)f_3845},
{"f_4087posixunix.scm",(void*)f_4087},
{"f_4093posixunix.scm",(void*)f_4093},
{"f_4189posixunix.scm",(void*)f_4189},
{"f_4179posixunix.scm",(void*)f_4179},
{"f_4173posixunix.scm",(void*)f_4173},
{"f_4095posixunix.scm",(void*)f_4095},
{"f_4145posixunix.scm",(void*)f_4145},
{"f_4102posixunix.scm",(void*)f_4102},
{"f_4112posixunix.scm",(void*)f_4112},
{"f_4011posixunix.scm",(void*)f_4011},
{"f_4019posixunix.scm",(void*)f_4019},
{"f_4021posixunix.scm",(void*)f_4021},
{"f_4069posixunix.scm",(void*)f_4069},
{"f_4002posixunix.scm",(void*)f_4002},
{"f_4006posixunix.scm",(void*)f_4006},
{"f_3981posixunix.scm",(void*)f_3981},
{"f_3991posixunix.scm",(void*)f_3991},
{"f_3969posixunix.scm",(void*)f_3969},
{"f_3956posixunix.scm",(void*)f_3956},
{"f_3960posixunix.scm",(void*)f_3960},
{"f_3951posixunix.scm",(void*)f_3951},
{"f_3954posixunix.scm",(void*)f_3954},
{"f_3869posixunix.scm",(void*)f_3869},
{"f_3881posixunix.scm",(void*)f_3881},
{"f_3918posixunix.scm",(void*)f_3918},
{"f_3927posixunix.scm",(void*)f_3927},
{"f_3921posixunix.scm",(void*)f_3921},
{"f_3897posixunix.scm",(void*)f_3897},
{"f_3900posixunix.scm",(void*)f_3900},
{"f_3861posixunix.scm",(void*)f_3861},
{"f_3846posixunix.scm",(void*)f_3846},
{"f_3860posixunix.scm",(void*)f_3860},
{"f_3806posixunix.scm",(void*)f_3806},
{"f_3813posixunix.scm",(void*)f_3813},
{"f_3816posixunix.scm",(void*)f_3816},
{"f_3761posixunix.scm",(void*)f_3761},
{"f_3765posixunix.scm",(void*)f_3765},
{"f_3800posixunix.scm",(void*)f_3800},
{"f_3783posixunix.scm",(void*)f_3783},
{"f_3747posixunix.scm",(void*)f_3747},
{"f_3759posixunix.scm",(void*)f_3759},
{"f_3733posixunix.scm",(void*)f_3733},
{"f_3745posixunix.scm",(void*)f_3745},
{"f_3718posixunix.scm",(void*)f_3718},
{"f_3731posixunix.scm",(void*)f_3731},
{"f_3681posixunix.scm",(void*)f_3681},
{"f_3689posixunix.scm",(void*)f_3689},
{"f_3656posixunix.scm",(void*)f_3656},
{"f_3637posixunix.scm",(void*)f_3637},
{"f_3641posixunix.scm",(void*)f_3641},
{"f_3606posixunix.scm",(void*)f_3606},
{"f_3630posixunix.scm",(void*)f_3630},
{"f_3614posixunix.scm",(void*)f_3614},
{"f_3617posixunix.scm",(void*)f_3617},
{"f_3568posixunix.scm",(void*)f_3568},
{"f_3601posixunix.scm",(void*)f_3601},
{"f_3589posixunix.scm",(void*)f_3589},
{"f_3597posixunix.scm",(void*)f_3597},
{"f_3593posixunix.scm",(void*)f_3593},
{"f_3543posixunix.scm",(void*)f_3543},
{"f_3559posixunix.scm",(void*)f_3559},
{"f_3528posixunix.scm",(void*)f_3528},
{"f_3538posixunix.scm",(void*)f_3538},
{"f_3532posixunix.scm",(void*)f_3532},
{"f_3522posixunix.scm",(void*)f_3522},
{"f_3516posixunix.scm",(void*)f_3516},
{"f_3510posixunix.scm",(void*)f_3510},
{"f_3486posixunix.scm",(void*)f_3486},
{"f_3508posixunix.scm",(void*)f_3508},
{"f_3504posixunix.scm",(void*)f_3504},
{"f_3496posixunix.scm",(void*)f_3496},
{"f_3456posixunix.scm",(void*)f_3456},
{"f_3484posixunix.scm",(void*)f_3484},
{"f_3480posixunix.scm",(void*)f_3480},
{"f_3429posixunix.scm",(void*)f_3429},
{"f_3454posixunix.scm",(void*)f_3454},
{"f_3450posixunix.scm",(void*)f_3450},
{"f_3365posixunix.scm",(void*)f_3365},
{"f_3353posixunix.scm",(void*)f_3353},
{"f_3381posixunix.scm",(void*)f_3381},
{"f_3291posixunix.scm",(void*)f_3291},
{"f_3295posixunix.scm",(void*)f_3295},
{"f_3300posixunix.scm",(void*)f_3300},
{"f_3316posixunix.scm",(void*)f_3316},
{"f_3228posixunix.scm",(void*)f_3228},
{"f_3286posixunix.scm",(void*)f_3286},
{"f_3232posixunix.scm",(void*)f_3232},
{"f_3235posixunix.scm",(void*)f_3235},
{"f_3267posixunix.scm",(void*)f_3267},
{"f_3238posixunix.scm",(void*)f_3238},
{"f_3243posixunix.scm",(void*)f_3243},
{"f_3257posixunix.scm",(void*)f_3257},
{"f_3221posixunix.scm",(void*)f_3221},
{"f_3135posixunix.scm",(void*)f_3135},
{"f_3139posixunix.scm",(void*)f_3139},
{"f_3193posixunix.scm",(void*)f_3193},
{"f_3142posixunix.scm",(void*)f_3142},
{"f_3152posixunix.scm",(void*)f_3152},
{"f_3156posixunix.scm",(void*)f_3156},
{"f_3165posixunix.scm",(void*)f_3165},
{"f_3169posixunix.scm",(void*)f_3169},
{"f_3179posixunix.scm",(void*)f_3179},
{"f_3160posixunix.scm",(void*)f_3160},
{"f_3110posixunix.scm",(void*)f_3110},
{"f_3122posixunix.scm",(void*)f_3122},
{"f_3118posixunix.scm",(void*)f_3118},
{"f_3096posixunix.scm",(void*)f_3096},
{"f_3108posixunix.scm",(void*)f_3108},
{"f_3104posixunix.scm",(void*)f_3104},
{"f_3029posixunix.scm",(void*)f_3029},
{"f_3033posixunix.scm",(void*)f_3033},
{"f_3075posixunix.scm",(void*)f_3075},
{"f_3036posixunix.scm",(void*)f_3036},
{"f_3046posixunix.scm",(void*)f_3046},
{"f_3050posixunix.scm",(void*)f_3050},
{"f_3054posixunix.scm",(void*)f_3054},
{"f_3058posixunix.scm",(void*)f_3058},
{"f_3062posixunix.scm",(void*)f_3062},
{"f_3006posixunix.scm",(void*)f_3006},
{"f_3016posixunix.scm",(void*)f_3016},
{"f_2983posixunix.scm",(void*)f_2983},
{"f_2993posixunix.scm",(void*)f_2993},
{"f_2945posixunix.scm",(void*)f_2945},
{"f_2978posixunix.scm",(void*)f_2978},
{"f_2949posixunix.scm",(void*)f_2949},
{"f_2956posixunix.scm",(void*)f_2956},
{"f_2960posixunix.scm",(void*)f_2960},
{"f_2964posixunix.scm",(void*)f_2964},
{"f_2968posixunix.scm",(void*)f_2968},
{"f_2972posixunix.scm",(void*)f_2972},
{"f_2927posixunix.scm",(void*)f_2927},
{"f_2912posixunix.scm",(void*)f_2912},
{"f_2906posixunix.scm",(void*)f_2906},
{"f_2874posixunix.scm",(void*)f_2874},
{"f_2880posixunix.scm",(void*)f_2880},
{"f_2850posixunix.scm",(void*)f_2850},
{"f_2868posixunix.scm",(void*)f_2868},
{"f_2857posixunix.scm",(void*)f_2857},
{"f_2832posixunix.scm",(void*)f_2832},
{"f_2842posixunix.scm",(void*)f_2842},
{"f_2819posixunix.scm",(void*)f_2819},
{"f_2810posixunix.scm",(void*)f_2810},
{"f_2763posixunix.scm",(void*)f_2763},
{"f_2767posixunix.scm",(void*)f_2767},
{"f_2743posixunix.scm",(void*)f_2743},
{"f_2747posixunix.scm",(void*)f_2747},
{"f_2753posixunix.scm",(void*)f_2753},
{"f_2757posixunix.scm",(void*)f_2757},
{"f_2723posixunix.scm",(void*)f_2723},
{"f_2727posixunix.scm",(void*)f_2727},
{"f_2733posixunix.scm",(void*)f_2733},
{"f_2737posixunix.scm",(void*)f_2737},
{"f_2699posixunix.scm",(void*)f_2699},
{"f_2703posixunix.scm",(void*)f_2703},
{"f_2714posixunix.scm",(void*)f_2714},
{"f_2718posixunix.scm",(void*)f_2718},
{"f_2708posixunix.scm",(void*)f_2708},
{"f_2675posixunix.scm",(void*)f_2675},
{"f_2679posixunix.scm",(void*)f_2679},
{"f_2690posixunix.scm",(void*)f_2690},
{"f_2694posixunix.scm",(void*)f_2694},
{"f_2684posixunix.scm",(void*)f_2684},
{"f_2659posixunix.scm",(void*)f_2659},
{"f_2663posixunix.scm",(void*)f_2663},
{"f_2666posixunix.scm",(void*)f_2666},
{"f_2623posixunix.scm",(void*)f_2623},
{"f_2654posixunix.scm",(void*)f_2654},
{"f_2644posixunix.scm",(void*)f_2644},
{"f_2637posixunix.scm",(void*)f_2637},
{"f_2587posixunix.scm",(void*)f_2587},
{"f_2618posixunix.scm",(void*)f_2618},
{"f_2608posixunix.scm",(void*)f_2608},
{"f_2601posixunix.scm",(void*)f_2601},
{"f_2572posixunix.scm",(void*)f_2572},
{"f_2585posixunix.scm",(void*)f_2585},
{"f_2566posixunix.scm",(void*)f_2566},
{"f_2554posixunix.scm",(void*)f_2554},
{"f_2511posixunix.scm",(void*)f_2511},
{"f_2515posixunix.scm",(void*)f_2515},
{"f_2524posixunix.scm",(void*)f_2524},
{"f_2488posixunix.scm",(void*)f_2488},
{"f_2509posixunix.scm",(void*)f_2509},
{"f_2495posixunix.scm",(void*)f_2495},
{"f_2331posixunix.scm",(void*)f_2331},
{"f_2436posixunix.scm",(void*)f_2436},
{"f_2444posixunix.scm",(void*)f_2444},
{"f_2431posixunix.scm",(void*)f_2431},
{"f_2333posixunix.scm",(void*)f_2333},
{"f_2340posixunix.scm",(void*)f_2340},
{"f_2343posixunix.scm",(void*)f_2343},
{"f_2346posixunix.scm",(void*)f_2346},
{"f_2430posixunix.scm",(void*)f_2430},
{"f_2350posixunix.scm",(void*)f_2350},
{"f_2364posixunix.scm",(void*)f_2364},
{"f_2374posixunix.scm",(void*)f_2374},
{"f_2377posixunix.scm",(void*)f_2377},
{"f_2380posixunix.scm",(void*)f_2380},
{"f_2386posixunix.scm",(void*)f_2386},
{"f_2396posixunix.scm",(void*)f_2396},
{"f_2307posixunix.scm",(void*)f_2307},
{"f_2329posixunix.scm",(void*)f_2329},
{"f_2325posixunix.scm",(void*)f_2325},
{"f_2283posixunix.scm",(void*)f_2283},
{"f_2305posixunix.scm",(void*)f_2305},
{"f_2301posixunix.scm",(void*)f_2301},
{"f_2259posixunix.scm",(void*)f_2259},
{"f_2281posixunix.scm",(void*)f_2281},
{"f_2277posixunix.scm",(void*)f_2277},
{"f_2197posixunix.scm",(void*)f_2197},
{"f_2210posixunix.scm",(void*)f_2210},
{"f_2222posixunix.scm",(void*)f_2222},
{"f_2216posixunix.scm",(void*)f_2216},
{"f_2188posixunix.scm",(void*)f_2188},
{"f_2195posixunix.scm",(void*)f_2195},
{"f_2179posixunix.scm",(void*)f_2179},
{"f_2186posixunix.scm",(void*)f_2186},
{"f_2173posixunix.scm",(void*)f_2173},
{"f_2177posixunix.scm",(void*)f_2177},
{"f_2167posixunix.scm",(void*)f_2167},
{"f_2171posixunix.scm",(void*)f_2171},
{"f_2161posixunix.scm",(void*)f_2161},
{"f_2165posixunix.scm",(void*)f_2165},
{"f_2155posixunix.scm",(void*)f_2155},
{"f_2159posixunix.scm",(void*)f_2159},
{"f_2149posixunix.scm",(void*)f_2149},
{"f_2153posixunix.scm",(void*)f_2153},
{"f_2143posixunix.scm",(void*)f_2143},
{"f_2147posixunix.scm",(void*)f_2147},
{"f_2111posixunix.scm",(void*)f_2111},
{"f_2122posixunix.scm",(void*)f_2122},
{"f_2115posixunix.scm",(void*)f_2115},
{"f_2074posixunix.scm",(void*)f_2074},
{"f_2106posixunix.scm",(void*)f_2106},
{"f_2099posixunix.scm",(void*)f_2099},
{"f_2078posixunix.scm",(void*)f_2078},
{"f_1882posixunix.scm",(void*)f_1882},
{"f_2055posixunix.scm",(void*)f_2055},
{"f_1898posixunix.scm",(void*)f_1898},
{"f_2029posixunix.scm",(void*)f_2029},
{"f_1904posixunix.scm",(void*)f_1904},
{"f_1907posixunix.scm",(void*)f_1907},
{"f_1989posixunix.scm",(void*)f_1989},
{"f_1987posixunix.scm",(void*)f_1987},
{"f_1946posixunix.scm",(void*)f_1946},
{"f_1964posixunix.scm",(void*)f_1964},
{"f_1962posixunix.scm",(void*)f_1962},
{"f_1950posixunix.scm",(void*)f_1950},
{"f_1872posixunix.scm",(void*)f_1872},
{"f_1862posixunix.scm",(void*)f_1862},
{"f_1856posixunix.scm",(void*)f_1856},
{"f_1824posixunix.scm",(void*)f_1824},
{"f_1831posixunix.scm",(void*)f_1831},
{"f_1837posixunix.scm",(void*)f_1837},
{"f_1844posixunix.scm",(void*)f_1844},
{"f_1785posixunix.scm",(void*)f_1785},
{"f_1792posixunix.scm",(void*)f_1792},
{"f_1801posixunix.scm",(void*)f_1801},
{"f_1743posixunix.scm",(void*)f_1743},
{"f_1753posixunix.scm",(void*)f_1753},
{"f_1756posixunix.scm",(void*)f_1756},
{"f_1759posixunix.scm",(void*)f_1759},
{"f_1728posixunix.scm",(void*)f_1728},
{"f_1690posixunix.scm",(void*)f_1690},
{"f_1720posixunix.scm",(void*)f_1720},
{"f_1707posixunix.scm",(void*)f_1707},
{"f_1710posixunix.scm",(void*)f_1710},
{"f_1644posixunix.scm",(void*)f_1644},
{"f_1648posixunix.scm",(void*)f_1648},
{"f_1587posixunix.scm",(void*)f_1587},
{"f_1580posixunix.scm",(void*)f_1580},
{"f_1562posixunix.scm",(void*)f_1562},
{"f_1566posixunix.scm",(void*)f_1566},
{"f_1577posixunix.scm",(void*)f_1577},
{"f_1573posixunix.scm",(void*)f_1573},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
