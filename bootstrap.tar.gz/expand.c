/* Generated from expand.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:16
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: expand.scm -optimize-level 2 -include-path . -include-path . -explicit-use -output-file expand.c
   unit: expand
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[351];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,17),40,100,32,97,114,103,49,55,32,46,32,109,111,114,101,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,20),40,108,111,111,107,117,112,32,105,100,49,52,48,32,115,101,49,52,49,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,26),40,109,97,99,114,111,45,97,108,105,97,115,32,118,97,114,49,54,49,32,115,101,49,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,12),40,97,51,55,49,55,32,97,49,57,55,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,14),40,109,97,112,45,115,101,32,115,101,49,57,53,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,11),40,119,97,108,107,32,120,50,50,53,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,115,116,114,105,112,45,115,121,110,116,97,120,32,101,120,112,50,48,55,32,46,32,116,109,112,50,48,54,50,48,56,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,101,120,116,101,110,100,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,110,97,109,101,50,53,49,32,115,101,50,53,50,32,104,97,110,100,108,101,114,50,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,99,111,112,121,45,109,97,99,114,111,32,111,108,100,50,55,51,32,110,101,119,50,55,52,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,27),40,109,97,99,114,111,63,32,115,121,109,50,56,54,32,46,32,116,109,112,50,56,53,50,56,55,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,109,101,51,50,50,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,109,97,99,114,111,32,110,97,109,101,51,49,54,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,25),40,117,110,100,101,102,105,110,101,45,109,97,99,114,111,33,32,110,97,109,101,51,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,112,115,51,54,57,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,52,48,52,48,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,52,48,51,52,32,101,120,51,54,48,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,7),40,97,52,49,52,55,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,7),40,97,52,49,54,50,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,20),40,97,52,49,53,54,32,46,32,97,114,103,115,51,53,52,51,56,54,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,52,49,52,49,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,15),40,97,52,48,50,56,32,107,51,53,51,51,53,56,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,46),40,99,97,108,108,45,104,97,110,100,108,101,114,32,110,97,109,101,51,52,54,32,104,97,110,100,108,101,114,51,52,55,32,101,120,112,51,52,56,32,115,101,51,52,57,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,31),40,101,120,112,97,110,100,32,104,101,97,100,51,57,49,32,101,120,112,51,57,50,32,109,100,101,102,51,57,51,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,52,51,50,57,32,98,52,52,53,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,101,120,112,97,110,100,45,48,32,101,120,112,51,52,49,32,100,115,101,51,52,50,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,109,111,100,117,108,101,45,114,101,110,97,109,101,32,115,121,109,52,54,50,32,112,114,101,102,105,120,52,54,51,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,16),40,109,114,101,110,97,109,101,32,115,121,109,52,55,57,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,97,108,105,97,115,45,103,108,111,98,97,108,45,104,111,111,107,32,115,121,109,52,54,55,32,97,115,115,105,103,110,52,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,7),40,97,52,53,51,54,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,32),40,97,52,53,52,50,32,101,120,112,50,53,53,50,53,53,51,53,53,56,32,109,53,53,52,53,53,53,53,53,57,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,53,52,57,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,101,120,112,97,110,100,32,101,120,112,53,51,50,32,46,32,116,109,112,53,51,49,53,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,108,105,115,116,53,55,53,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,63,32,108,108,105,115,116,53,54,57,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,12),40,101,114,114,32,109,115,103,54,49,50,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,12),40,97,52,56,52,49,32,107,54,52,55,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,109,111,100,101,54,50,57,32,114,101,113,54,51,48,32,111,112,116,54,51,49,32,107,101,121,54,51,50,32,108,108,105,115,116,54,51,51,41,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,67),40,35,35,115,121,115,35,101,120,112,97,110,100,45,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,32,108,108,105,115,116,48,54,48,53,32,98,111,100,121,54,48,54,32,101,114,114,104,54,48,55,32,115,101,54,48,56,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,98,111,100,121,50,55,57,48,32,101,120,112,115,55,57,49,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,17),40,97,53,51,57,55,32,118,56,52,55,32,116,56,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,18),40,97,53,51,54,48,32,118,115,56,51,56,32,120,56,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,17),40,97,53,52,50,55,32,118,56,51,49,32,120,56,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,12),40,97,53,52,52,53,32,118,56,50,57,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,48),40,102,105,110,105,32,118,97,114,115,55,55,56,32,118,97,108,115,55,55,57,32,109,118,97,114,115,55,56,48,32,109,118,97,108,115,55,56,49,32,98,111,100,121,55,56,50,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,30),40,108,111,111,112,32,98,111,100,121,56,54,56,32,100,101,102,115,56,54,57,32,100,111,110,101,56,55,48,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,55),40,102,105,110,105,47,115,121,110,116,97,120,32,118,97,114,115,56,53,56,32,118,97,108,115,56,53,57,32,109,118,97,114,115,56,54,48,32,109,118,97,108,115,56,54,49,32,98,111,100,121,56,54,50,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,50,32,120,57,52,56,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,48),40,108,111,111,112,32,98,111,100,121,57,48,57,32,118,97,114,115,57,49,48,32,118,97,108,115,57,49,49,32,109,118,97,114,115,57,49,50,32,109,118,97,108,115,57,49,51,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,98,111,100,121,57,48,51,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,99,97,110,111,110,105,99,97,108,105,122,101,45,98,111,100,121,32,98,111,100,121,55,54,50,32,46,32,116,109,112,55,54,49,55,54,51,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,17),40,109,119,97,108,107,32,120,57,57,53,32,112,57,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,40),40,109,97,116,99,104,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,57,56,54,32,112,97,116,57,56,55,32,118,97,114,115,57,56,56,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,104,101,97,100,49,48,51,49,32,98,111,100,121,49,48,51,50,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,101,120,112,97,110,100,45,99,117,114,114,105,101,100,45,100,101,102,105,110,101,32,104,101,97,100,49,48,50,52,32,98,111,100,121,49,48,50,53,32,115,101,49,48,50,54,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,45,104,111,111,107,32,46,32,97,114,103,115,49,48,53,48,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,26),40,103,101,116,45,108,105,110,101,45,110,117,109,98,101,114,32,115,101,120,112,49,48,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,13),40,101,114,114,32,109,115,103,49,49,51,49,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,29),40,116,101,115,116,32,120,49,49,50,53,32,112,114,101,100,49,49,50,54,32,109,115,103,49,49,50,55,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,49,49,53,49,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,20),40,108,97,109,98,100,97,45,108,105,115,116,63,32,120,49,49,51,57,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,20),40,112,114,111,112,101,114,45,108,105,115,116,63,32,120,49,49,55,50,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,50,50,53,32,120,49,50,51,52,32,110,49,50,51,53,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,13),40,97,54,52,56,55,32,121,49,50,53,54,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,49,57,57,32,112,49,50,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,49,49,48,54,32,99,117,108,112,114,105,116,49,49,49,54,32,115,101,49,49,49,55,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,101,49,49,48,57,32,37,99,117,108,112,114,105,116,49,49,48,52,49,50,55,50,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,99,117,108,112,114,105,116,49,49,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,99,104,101,99,107,45,115,121,110,116,97,120,32,105,100,49,48,57,52,32,101,120,112,49,48,57,53,32,112,97,116,49,48,57,54,32,46,32,116,109,112,49,48,57,51,49,48,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,16),40,114,101,110,97,109,101,32,115,121,109,49,50,57,55,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,25),40,108,111,111,107,117,112,50,32,115,121,109,49,52,50,48,32,100,115,101,49,52,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,23),40,99,111,109,112,97,114,101,32,115,49,49,51,51,56,32,115,50,49,51,51,57,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,32),40,102,95,54,54,49,55,32,102,111,114,109,49,50,56,56,32,115,101,49,50,56,57,32,100,115,101,49,50,57,48,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,101,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,50,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,17),40,114,101,115,111,108,118,101,32,115,121,109,49,52,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,13),40,116,111,115,116,114,32,120,49,52,53,55,41,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,10),40,115,119,97,112,49,52,56,53,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,7),40,97,54,57,52,51,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,110,97,109,101,32,115,112,101,99,49,52,54,54,41,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,105,100,115,49,53,55,53,32,118,49,53,55,54,32,115,49,53,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,115,49,54,50,48,32,115,49,54,50,49,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,118,49,54,48,54,32,118,49,54,48,55,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,14),40,97,55,50,50,48,32,105,100,49,54,54,49,41,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,105,109,112,118,49,54,51,57,32,105,109,112,115,49,54,52,48,32,118,49,54,52,49,32,115,49,54,52,50,32,105,100,115,49,54,52,51,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,13),40,114,101,110,32,105,109,112,49,54,56,48,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,115,112,101,99,32,115,112,101,99,49,53,51,55,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,15),40,97,55,52,56,49,32,105,109,112,49,55,49,49,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,15),40,97,55,53,50,51,32,105,109,112,49,55,48,49,41,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,16),40,97,55,52,50,57,32,115,112,101,99,49,54,56,56,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,86),40,35,35,115,121,115,35,101,120,112,97,110,100,45,105,109,112,111,114,116,32,120,49,52,51,50,32,114,49,52,51,51,32,99,49,52,51,52,32,105,109,112,111,114,116,45,101,110,118,49,52,51,53,32,109,97,99,114,111,45,101,110,118,49,52,51,54,32,109,101,116,97,63,49,52,51,55,32,108,111,99,49,52,51,56,41,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,18),40,102,95,55,56,48,54,32,114,117,108,101,115,50,52,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,13),40,97,55,57,52,57,32,120,50,52,51,48,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,17),40,102,95,55,57,48,48,32,114,117,108,101,50,52,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,30),40,102,95,55,57,56,52,32,105,110,112,117,116,50,52,51,50,32,112,97,116,116,101,114,110,50,52,51,51,41,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,30),40,102,95,56,50,48,53,32,105,110,112,117,116,50,52,56,50,32,112,97,116,116,101,114,110,50,52,56,51,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,53,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,30),40,102,95,56,51,50,51,32,105,110,112,117,116,50,52,57,57,32,112,97,116,116,101,114,110,50,53,48,48,41,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,13),40,97,56,54,52,57,32,120,50,53,54,50,41,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,53,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,39),40,102,95,56,54,49,49,32,112,97,116,116,101,114,110,50,53,53,49,32,112,97,116,104,50,53,53,50,32,109,97,112,105,116,50,53,53,51,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,50,54,52,56,32,100,50,54,53,54,32,103,101,110,50,54,53,55,41,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,37),40,102,95,56,56,49,56,32,116,101,109,112,108,97,116,101,50,54,48,55,32,100,105,109,50,54,48,56,32,101,110,118,50,54,48,57,41,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,37),40,102,95,57,48,55,50,32,112,97,116,116,101,114,110,50,54,56,51,32,100,105,109,50,54,56,52,32,118,97,114,115,50,54,56,53,41,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,46),40,102,95,57,49,52,53,32,116,101,109,112,108,97,116,101,50,54,57,52,32,100,105,109,50,54,57,53,32,101,110,118,50,54,57,54,32,102,114,101,101,50,54,57,55,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,20),40,102,95,57,50,51,56,32,112,97,116,116,101,114,110,50,55,49,50,41,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,20),40,102,95,57,50,54,48,32,112,97,116,116,101,114,110,50,55,50,50,41,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,20),40,102,95,57,50,56,54,32,112,97,116,116,101,114,110,50,55,50,56,41,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,97,116,116,101,114,110,50,55,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,48,54,32,112,97,116,116,101,114,110,50,55,51,48,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,79),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,115,121,110,116,97,120,45,114,117,108,101,115,32,101,108,108,105,112,115,105,115,50,51,53,53,32,114,117,108,101,115,50,51,53,54,32,115,117,98,107,101,121,119,111,114,100,115,50,51,53,55,32,114,50,51,53,56,32,99,50,51,53,57,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,19),40,109,111,100,117,108,101,63,32,120,50,56,48,50,50,56,49,57,41,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,13),40,109,111,100,117,108,101,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,20),40,109,111,100,117,108,101,45,101,120,112,111,114,116,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,46),40,115,101,116,45,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,56,48,50,50,56,51,51,32,121,50,56,48,51,50,56,51,52,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,41,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,19),40,109,111,100,117,108,101,45,101,120,105,115,116,45,108,105,115,116,41,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,28),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,115,121,110,116,97,120,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,48),40,115,101,116,45,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,56,48,50,50,56,53,55,32,121,50,56,48,51,50,56,53,56,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,32,120,50,56,48,50,50,56,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,26),40,109,111,100,117,108,101,45,109,101,116,97,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,25),40,109,111,100,117,108,101,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,118,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,115,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,51),40,109,97,107,101,45,109,111,100,117,108,101,32,101,120,112,108,105,115,116,50,57,50,57,32,118,101,120,112,111,114,116,115,50,57,51,48,32,115,101,120,112,111,114,116,115,50,57,51,49,41,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,102,105,110,100,45,109,111,100,117,108,101,32,110,97,109,101,50,57,52,49,32,46,32,116,109,112,50,57,52,48,50,57,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,64),40,35,35,115,121,115,35,116,111,112,108,101,118,101,108,45,100,101,102,105,110,105,116,105,111,110,45,104,111,111,107,32,115,121,109,50,57,54,54,32,109,111,100,50,57,54,55,32,101,120,112,50,57,54,56,32,118,97,108,50,57,54,57,41};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,50,57,55,51,41};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,42),40,99,104,101,99,107,45,102,111,114,45,114,101,100,101,102,32,115,121,109,50,57,56,50,32,101,110,118,50,57,56,51,32,115,101,110,118,50,57,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,101,120,112,111,114,116,32,115,121,109,50,57,57,57,32,109,111,100,51,48,48,48,41,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,115,121,110,116,97,120,45,101,120,112,111,114,116,32,115,121,109,51,48,50,53,32,109,111,100,51,48,50,54,32,118,97,108,51,48,50,55,41,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,117,110,100,101,102,105,110,101,100,32,115,121,109,51,48,53,50,32,109,111,100,51,48,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,51,48,56,48,32,115,101,120,112,111,114,116,115,51,48,57,49,41,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,18),40,100,101,102,45,115,101,120,112,111,114,116,115,51,48,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,58),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,32,110,97,109,101,51,48,54,57,32,101,120,112,108,105,115,116,51,48,55,48,32,46,32,116,109,112,51,48,54,56,51,48,55,49,41,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,15),40,97,57,57,48,57,32,105,109,112,51,49,49,53,41,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,109,97,114,107,45,105,109,112,111,114,116,101,100,45,115,121,109,98,111,108,115,32,115,101,51,49,49,51,41,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,21),40,119,97,114,110,32,109,115,103,51,49,53,51,32,105,100,51,49,53,52,41,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,50,32,105,101,120,112,111,114,116,115,51,49,55,51,41,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,101,120,112,111,114,116,115,51,49,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,105,110,100,105,114,101,99,116,45,101,120,112,111,114,116,115,32,109,111,100,51,49,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,101,51,50,50,55,41,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,18),40,109,101,114,103,101,45,115,101,32,115,101,115,51,50,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,20),40,97,49,48,51,55,50,32,115,101,120,112,111,114,116,51,50,55,51,41,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,15),40,97,49,48,52,51,55,32,105,101,51,50,54,51,41,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,45,114,101,103,105,115,116,114,97,116,105,111,110,32,109,111,100,51,50,52,52,41,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,17),40,97,49,48,54,48,52,32,105,101,120,112,51,51,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,17),40,97,49,48,54,50,52,32,115,101,120,112,51,51,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,15),40,97,49,48,54,52,50,32,105,101,51,51,48,49,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,15),40,97,49,48,54,55,52,32,115,101,51,50,57,55,41,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,80),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,32,110,97,109,101,51,50,57,48,32,105,101,120,112,111,114,116,115,51,50,57,49,32,118,101,120,112,111,114,116,115,51,50,57,50,32,115,101,120,112,111,114,116,115,51,50,57,51,41};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,50,48,32,115,101,51,51,53,48,41,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,51,56,32,118,101,51,51,52,53,41,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,69),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,105,109,105,116,105,118,101,45,109,111,100,117,108,101,32,110,97,109,101,51,51,50,55,32,118,101,120,112,111,114,116,115,51,51,50,56,32,46,32,116,109,112,51,51,50,54,51,51,50,57,41,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,51,55,51,41,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,102,105,110,100,45,101,120,112,111,114,116,32,115,121,109,51,51,54,51,32,109,111,100,51,51,54,52,32,105,110,100,105,114,101,99,116,51,51,54,53,41};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,14),40,97,49,48,57,49,54,32,109,51,52,57,57,41,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,16),40,97,49,48,57,52,52,32,101,120,112,51,52,56,48,41};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,14),40,97,49,48,57,56,50,32,117,51,52,55,52,41,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,52,52,53,41,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,15),40,97,49,49,49,50,54,32,115,100,51,52,50,50,41,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,52,50,56,41,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,16),40,97,49,49,49,56,56,32,115,121,109,51,52,49,56,41};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,110,97,108,105,122,101,45,109,111,100,117,108,101,32,109,111,100,51,52,48,54,41,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,53,50,48,41,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,109,97,99,114,111,45,115,117,98,115,101,116,32,109,101,48,51,53,49,52,41,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,28),40,97,49,49,50,53,49,32,101,120,112,50,51,51,57,32,114,50,51,52,48,32,99,50,51,52,49,41,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,16),40,97,49,49,51,49,56,32,101,120,112,50,51,49,51,41};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,26),40,97,49,49,50,56,56,32,120,50,51,48,52,32,114,50,51,48,53,32,99,50,51,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,26),40,97,49,49,51,57,49,32,120,50,50,56,52,32,114,50,50,56,53,32,99,50,50,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,26),40,97,49,49,52,52,53,32,120,50,50,55,52,32,114,50,50,55,53,32,99,50,50,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,26),40,97,49,49,52,57,54,32,120,50,50,54,51,32,114,50,50,54,52,32,99,50,50,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,49,55,32,120,50,50,53,50,32,114,50,50,53,51,32,99,50,50,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,11),40,101,114,114,32,120,50,49,54,54,41,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,13),40,116,101,115,116,32,102,120,50,49,54,56,41,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,14),40,97,49,49,55,51,53,32,120,50,50,50,51,41,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,99,108,115,50,50,49,52,41};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,29),40,97,49,49,53,51,56,32,102,111,114,109,50,49,53,50,32,114,50,49,53,51,32,99,50,49,53,52,41,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,29),40,97,49,49,56,50,50,32,102,111,114,109,50,49,52,50,32,114,50,49,52,51,32,99,50,49,52,52,41,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,50,48,51,52,32,110,50,48,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,19),40,119,97,108,107,49,32,120,50,48,51,55,32,110,50,48,51,56,41,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,16),40,115,105,109,112,108,105,102,121,32,120,50,49,48,50,41};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,29),40,97,49,49,56,53,53,32,102,111,114,109,50,48,50,50,32,114,50,48,50,51,32,99,50,48,50,52,41,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,14),40,97,49,50,51,53,53,32,98,50,48,49,56,41,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,14),40,97,49,50,52,49,48,32,98,50,48,48,54,41,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,29),40,97,49,50,50,53,48,32,102,111,114,109,49,57,57,48,32,114,49,57,57,49,32,99,49,57,57,50,41,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,14),40,97,49,50,52,56,50,32,98,49,57,56,50,41,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,14),40,97,49,50,53,48,52,32,98,49,57,56,48,41,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,29),40,97,49,50,52,51,50,32,102,111,114,109,49,57,54,56,32,114,49,57,54,57,32,99,49,57,55,48,41,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,15),40,101,120,112,97,110,100,32,98,115,49,57,53,52,41,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,29),40,97,49,50,53,49,56,32,102,111,114,109,49,57,52,50,32,114,49,57,52,51,32,99,49,57,52,52,41,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,14),40,97,49,50,55,49,52,32,120,49,57,51,49,41,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,57,49,56,41,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,29),40,97,49,50,53,56,55,32,102,111,114,109,49,56,57,54,32,114,49,56,57,55,32,99,49,56,57,56,41,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,56,53,50,41,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,29),40,97,49,50,55,54,48,32,102,111,114,109,49,56,51,53,32,114,49,56,51,54,32,99,49,56,51,55,41,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,29),40,97,49,51,48,57,51,32,102,111,114,109,49,56,49,57,32,114,49,56,50,48,32,99,49,56,50,49,41,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,29),40,97,49,51,49,56,51,32,102,111,114,109,49,56,48,53,32,114,49,56,48,54,32,99,49,56,48,55,41,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,102,111,114,109,49,55,55,52,41,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,29),40,97,49,51,50,52,50,32,102,111,114,109,49,55,54,54,32,114,49,55,54,55,32,99,49,55,54,56,41,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,50),40,97,49,51,51,56,52,32,103,49,55,53,52,49,55,53,53,49,55,54,48,32,103,49,55,53,54,49,55,53,55,49,55,54,49,32,103,49,55,53,56,49,55,53,57,49,55,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,50),40,97,49,51,51,57,52,32,103,49,55,51,56,49,55,51,57,49,55,52,52,32,103,49,55,52,48,49,55,52,49,49,55,52,53,32,103,49,55,52,50,49,55,52,51,49,55,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_expand_toplevel)
C_externexport void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3650)
static void C_ccall f_3650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13395)
static void C_ccall f_13395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13393)
static void C_ccall f_13393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7598)
static void C_ccall f_7598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13385)
static void C_ccall f_13385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13383)
static void C_ccall f_13383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7601)
static void C_ccall f_7601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7605)
static void C_ccall f_7605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13243)
static void C_ccall f_13243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13253)
static void C_fcall f_13253(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13269)
static void C_ccall f_13269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13272)
static void C_ccall f_13272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13300)
static void C_ccall f_13300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13275)
static void C_ccall f_13275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13322)
static void C_ccall f_13322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13325)
static void C_ccall f_13325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13371)
static void C_ccall f_13371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13328)
static void C_ccall f_13328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13351)
static void C_ccall f_13351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13363)
static void C_ccall f_13363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13309)
static void C_ccall f_13309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13312)
static void C_ccall f_13312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13319)
static void C_ccall f_13319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13241)
static void C_ccall f_13241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7608)
static void C_ccall f_7608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13184)
static void C_ccall f_13184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13213)
static void C_ccall f_13213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13233)
static void C_ccall f_13233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13237)
static void C_ccall f_13237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13182)
static void C_ccall f_13182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7611)
static void C_ccall f_7611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13094)
static void C_ccall f_13094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13119)
static void C_ccall f_13119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13126)
static void C_ccall f_13126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13146)
static void C_ccall f_13146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13166)
static void C_ccall f_13166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13170)
static void C_ccall f_13170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13092)
static void C_ccall f_13092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7614)
static void C_ccall f_7614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12761)
static void C_ccall f_12761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12768)
static void C_ccall f_12768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12771)
static void C_ccall f_12771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12774)
static void C_ccall f_12774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12777)
static void C_ccall f_12777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12780)
static void C_ccall f_12780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12783)
static void C_ccall f_12783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12786)
static void C_ccall f_12786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12791)
static void C_fcall f_12791(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12807)
static void C_ccall f_12807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12813)
static void C_ccall f_12813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12855)
static void C_ccall f_12855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12923)
static void C_ccall f_12923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13048)
static void C_ccall f_13048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13044)
static void C_ccall f_13044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12926)
static void C_ccall f_12926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12981)
static void C_ccall f_12981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12858)
static void C_ccall f_12858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12897)
static void C_ccall f_12897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12849)
static void C_ccall f_12849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12820)
static void C_ccall f_12820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12759)
static void C_ccall f_12759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7617)
static void C_ccall f_7617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12588)
static void C_ccall f_12588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12592)
static void C_ccall f_12592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12601)
static void C_ccall f_12601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12604)
static void C_ccall f_12604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12607)
static void C_ccall f_12607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12610)
static void C_ccall f_12610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12613)
static void C_ccall f_12613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12616)
static void C_ccall f_12616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12637)
static void C_fcall f_12637(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12653)
static void C_ccall f_12653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12659)
static void C_ccall f_12659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12715)
static void C_ccall f_12715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12713)
static void C_ccall f_12713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12709)
static void C_ccall f_12709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12701)
static void C_ccall f_12701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12697)
static void C_ccall f_12697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12666)
static void C_ccall f_12666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12635)
static void C_ccall f_12635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12586)
static void C_ccall f_12586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7620)
static void C_ccall f_7620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12519)
static void C_ccall f_12519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12523)
static void C_ccall f_12523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12532)
static void C_ccall f_12532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12537)
static void C_fcall f_12537(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12574)
static void C_ccall f_12574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12555)
static void C_ccall f_12555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12517)
static void C_ccall f_12517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7623)
static void C_ccall f_7623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12433)
static void C_ccall f_12433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12437)
static void C_ccall f_12437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12446)
static void C_ccall f_12446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12505)
static void C_ccall f_12505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12457)
static void C_ccall f_12457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12483)
static void C_ccall f_12483(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12465)
static void C_ccall f_12465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12481)
static void C_ccall f_12481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12461)
static void C_ccall f_12461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12431)
static void C_ccall f_12431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7626)
static void C_ccall f_7626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12251)
static void C_ccall f_12251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12255)
static void C_ccall f_12255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12267)
static void C_ccall f_12267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12270)
static void C_ccall f_12270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12273)
static void C_ccall f_12273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12276)
static void C_ccall f_12276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12411)
static void C_ccall f_12411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12291)
static void C_ccall f_12291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12409)
static void C_ccall f_12409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12318)
static void C_fcall f_12318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12399)
static void C_ccall f_12399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12334)
static void C_fcall f_12334(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12356)
static void C_ccall f_12356(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12354)
static void C_ccall f_12354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12350)
static void C_ccall f_12350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12249)
static void C_ccall f_12249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7629)
static void C_ccall f_7629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11856)
static void C_ccall f_11856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11860)
static void C_ccall f_11860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11863)
static void C_ccall f_11863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11866)
static void C_ccall f_11866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11869)
static void C_ccall f_11869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12238)
static void C_ccall f_12238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12150)
static void C_fcall f_12150(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12154)
static void C_ccall f_12154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12179)
static void C_ccall f_12179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12225)
static void C_ccall f_12225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12210)
static void C_ccall f_12210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11881)
static void C_fcall f_11881(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11928)
static void C_ccall f_11928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11975)
static void C_ccall f_11975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12136)
static void C_ccall f_12136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12144)
static void C_ccall f_12144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12122)
static void C_ccall f_12122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12111)
static void C_ccall f_12111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12119)
static void C_ccall f_12119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12096)
static void C_ccall f_12096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12084)
static void C_ccall f_12084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12065)
static void C_ccall f_12065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12023)
static void C_ccall f_12023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12000)
static void C_ccall f_12000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11954)
static void C_ccall f_11954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11903)
static void C_ccall f_11903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11899)
static void C_ccall f_11899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11871)
static void C_fcall f_11871(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11879)
static void C_ccall f_11879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11854)
static void C_ccall f_11854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7632)
static void C_ccall f_7632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11823)
static void C_ccall f_11823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11827)
static void C_ccall f_11827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11821)
static void C_ccall f_11821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11539)
static void C_ccall f_11539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11546)
static void C_ccall f_11546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11549)
static void C_ccall f_11549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11552)
static void C_ccall f_11552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11555)
static void C_ccall f_11555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11558)
static void C_ccall f_11558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11720)
static void C_fcall f_11720(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11773)
static void C_ccall f_11773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11795)
static void C_ccall f_11795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11802)
static void C_ccall f_11802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11789)
static void C_ccall f_11789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11736)
static void C_ccall f_11736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11734)
static void C_ccall f_11734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11570)
static void C_fcall f_11570(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11601)
static void C_ccall f_11601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11647)
static void C_ccall f_11647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11697)
static void C_ccall f_11697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11704)
static void C_ccall f_11704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11662)
static void C_ccall f_11662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11676)
static void C_ccall f_11676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11619)
static void C_ccall f_11619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11630)
static void C_ccall f_11630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11560)
static void C_fcall f_11560(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11537)
static void C_ccall f_11537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7638)
static void C_ccall f_7638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11518)
static void C_ccall f_11518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11516)
static void C_ccall f_11516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11497)
static void C_ccall f_11497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11495)
static void C_ccall f_11495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7644)
static void C_ccall f_7644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11446)
static void C_ccall f_11446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11450)
static void C_ccall f_11450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11487)
static void C_ccall f_11487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11480)
static void C_ccall f_11480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11473)
static void C_ccall f_11473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11444)
static void C_ccall f_11444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7647)
static void C_ccall f_7647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11392)
static void C_ccall f_11392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11396)
static void C_ccall f_11396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11399)
static void C_ccall f_11399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11436)
static void C_ccall f_11436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11402)
static void C_ccall f_11402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11417)
static void C_ccall f_11417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11421)
static void C_ccall f_11421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11390)
static void C_ccall f_11390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11289)
static void C_ccall f_11289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11296)
static void C_ccall f_11296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11299)
static void C_ccall f_11299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11319)
static void C_ccall f_11319(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11341)
static C_word C_fcall f_11341(C_word t0);
C_noret_decl(f_11326)
static void C_fcall f_11326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11302)
static void C_ccall f_11302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11317)
static void C_ccall f_11317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11309)
static void C_ccall f_11309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11305)
static void C_ccall f_11305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11287)
static void C_ccall f_11287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7653)
static void C_ccall f_7653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11252)
static void C_ccall f_11252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11256)
static void C_ccall f_11256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11274)
static void C_ccall f_11274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11265)
static void C_fcall f_11265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11250)
static void C_ccall f_11250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7656)
static void C_ccall f_7656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9347)
static void C_ccall f_9347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11246)
static void C_ccall f_11246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9351)
static void C_ccall f_9351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9355)
static void C_ccall f_9355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11204)
static void C_ccall f_11204(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11212)
static void C_ccall f_11212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11214)
static void C_fcall f_11214(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11235)
static void C_ccall f_11235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10869)
static void C_ccall f_10869(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11189)
static void C_ccall f_11189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11197)
static void C_ccall f_11197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10885)
static void C_ccall f_10885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11146)
static void C_ccall f_11146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11148)
static void C_fcall f_11148(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11187)
static void C_ccall f_11187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11161)
static void C_ccall f_11161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11172)
static void C_ccall f_11172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11127)
static void C_ccall f_11127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11139)
static void C_ccall f_11139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10888)
static void C_ccall f_10888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11003)
static void C_fcall f_11003(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11054)
static void C_fcall f_11054(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11103)
static void C_ccall f_11103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11066)
static void C_fcall f_11066(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11089)
static void C_ccall f_11089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11085)
static void C_ccall f_11085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11051)
static void C_ccall f_11051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11040)
static void C_ccall f_11040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10891)
static void C_ccall f_10891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10997)
static void C_ccall f_10997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10983)
static void C_ccall f_10983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10894)
static void C_ccall f_10894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10981)
static void C_ccall f_10981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10945)
static void C_ccall f_10945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10973)
static void C_ccall f_10973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10897)
static void C_ccall f_10897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10939)
static void C_ccall f_10939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10943)
static void C_ccall f_10943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10900)
static void C_ccall f_10900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10903)
static void C_ccall f_10903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10917)
static void C_ccall f_10917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10921)
static void C_ccall f_10921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10906)
static void C_ccall f_10906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10912)
static void C_ccall f_10912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10784)
static void C_ccall f_10784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10795)
static void C_ccall f_10795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10797)
static void C_fcall f_10797(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10846)
static void C_ccall f_10846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10842)
static void C_ccall f_10842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10825)
static void C_fcall f_10825(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10693)
static void C_ccall f_10693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10693)
static void C_ccall f_10693r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10697)
static void C_ccall f_10697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10700)
static void C_ccall f_10700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10739)
static void C_ccall f_10739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10759)
static void C_ccall f_10759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10749)
static void C_ccall f_10749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10752)
static void C_ccall f_10752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10715)
static void C_ccall f_10715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10721)
static void C_ccall f_10721(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10719)
static void C_ccall f_10719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10573)
static void C_ccall f_10573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10675)
static void C_ccall f_10675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10687)
static void C_ccall f_10687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10577)
static void C_ccall f_10577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10643)
static void C_ccall f_10643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10665)
static void C_ccall f_10665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10580)
static void C_ccall f_10580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10637)
static void C_ccall f_10637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10641)
static void C_ccall f_10641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10586)
static void C_ccall f_10586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10589)
static void C_ccall f_10589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10625)
static void C_ccall f_10625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10592)
static void C_ccall f_10592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10605)
static void C_ccall f_10605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10595)
static void C_ccall f_10595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10287)
static void C_ccall f_10287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10571)
static void C_ccall f_10571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10307)
static void C_fcall f_10307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10541)
static void C_ccall f_10541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10315)
static void C_fcall f_10315(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10523)
static void C_ccall f_10523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10323)
static void C_ccall f_10323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10511)
static void C_ccall f_10511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10438)
static void C_ccall f_10438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10436)
static void C_ccall f_10436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10432)
static void C_ccall f_10432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10373)
static void C_ccall f_10373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10383)
static void C_ccall f_10383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10371)
static void C_ccall f_10371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10367)
static void C_ccall f_10367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10319)
static void C_ccall f_10319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10311)
static void C_ccall f_10311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10227)
static void C_fcall f_10227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10231)
static void C_ccall f_10231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10242)
static void C_fcall f_10242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10281)
static void C_ccall f_10281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10273)
static void C_ccall f_10273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10237)
static void C_ccall f_10237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9951)
static void C_fcall f_9951(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10032)
static void C_fcall f_10032(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10059)
static void C_ccall f_10059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10061)
static void C_fcall f_10061(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10221)
static void C_ccall f_10221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10209)
static void C_ccall f_10209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10190)
static void C_ccall f_10190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10172)
static void C_ccall f_10172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10157)
static void C_ccall f_10157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10127)
static void C_ccall f_10127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10112)
static void C_ccall f_10112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10084)
static void C_ccall f_10084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10009)
static void C_fcall f_10009(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10021)
static void C_ccall f_10021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10017)
static void C_ccall f_10017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9904)
static void C_ccall f_9904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9910)
static void C_ccall f_9910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9917)
static void C_fcall f_9917(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9836)
static void C_ccall f_9836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9836)
static void C_ccall f_9836r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9856)
static C_word C_fcall f_9856(C_word *a,C_word t0);
C_noret_decl(f_9851)
static C_word C_fcall f_9851(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_9838)
static C_word C_fcall f_9838(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9814)
static void C_ccall f_9814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9821)
static void C_ccall f_9821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9737)
static void C_ccall f_9737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9747)
static void C_ccall f_9747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9750)
static void C_ccall f_9750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9756)
static void C_ccall f_9756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9795)
static void C_ccall f_9795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9799)
static void C_ccall f_9799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9759)
static void C_ccall f_9759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9765)
static void C_ccall f_9765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9648)
static void C_ccall f_9648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9658)
static void C_ccall f_9658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9661)
static void C_ccall f_9661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9724)
static void C_ccall f_9724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9664)
static void C_ccall f_9664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9720)
static void C_ccall f_9720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9667)
static void C_ccall f_9667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9706)
static void C_ccall f_9706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9710)
static void C_ccall f_9710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9670)
static void C_ccall f_9670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9673)
static void C_ccall f_9673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9627)
static void C_fcall f_9627(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9634)
static void C_ccall f_9634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9607)
static void C_ccall f_9607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9611)
static void C_ccall f_9611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9604)
static void C_ccall f_9604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9564)
static void C_ccall f_9564(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9564)
static void C_ccall f_9564r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9568)
static void C_ccall f_9568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9558)
static C_word C_fcall f_9558(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3);
C_noret_decl(f_9549)
static C_word C_fcall f_9549(C_word t0);
C_noret_decl(f_9531)
static C_word C_fcall f_9531(C_word t0);
C_noret_decl(f_9513)
static C_word C_fcall f_9513(C_word t0);
C_noret_decl(f_9495)
static C_word C_fcall f_9495(C_word t0);
C_noret_decl(f_9477)
static C_word C_fcall f_9477(C_word t0);
C_noret_decl(f_9459)
static void C_ccall f_9459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9450)
static void C_ccall f_9450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9441)
static C_word C_fcall f_9441(C_word t0);
C_noret_decl(f_9423)
static C_word C_fcall f_9423(C_word t0);
C_noret_decl(f_9405)
static C_word C_fcall f_9405(C_word t0);
C_noret_decl(f_9396)
static void C_fcall f_9396(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9387)
static C_word C_fcall f_9387(C_word t0);
C_noret_decl(f_9369)
static C_word C_fcall f_9369(C_word t0);
C_noret_decl(f_9363)
static void C_ccall f_9363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7658)
static void C_ccall f_7658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7663)
static void C_ccall f_7663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7667)
static void C_ccall f_7667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7671)
static void C_ccall f_7671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7675)
static void C_ccall f_7675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7683)
static void C_ccall f_7683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7687)
static void C_ccall f_7687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7691)
static void C_ccall f_7691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7695)
static void C_ccall f_7695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7699)
static void C_ccall f_7699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7707)
static void C_ccall f_7707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7715)
static void C_ccall f_7715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7719)
static void C_ccall f_7719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7723)
static void C_ccall f_7723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7727)
static void C_ccall f_7727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7743)
static void C_ccall f_7743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7747)
static void C_ccall f_7747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7751)
static void C_ccall f_7751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7755)
static void C_ccall f_7755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7759)
static void C_ccall f_7759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7763)
static void C_ccall f_7763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7767)
static void C_ccall f_7767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7771)
static void C_ccall f_7771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7775)
static void C_ccall f_7775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7779)
static void C_ccall f_7779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7795)
static void C_ccall f_7795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7799)
static void C_ccall f_7799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7803)
static void C_ccall f_7803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9306)
static void C_ccall f_9306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9316)
static void C_fcall f_9316(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9323)
static void C_fcall f_9323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9286)
static void C_ccall f_9286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9293)
static void C_ccall f_9293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9300)
static void C_ccall f_9300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9260)
static void C_ccall f_9260(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9238)
static void C_ccall f_9238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9245)
static void C_ccall f_9245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9145)
static void C_ccall f_9145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9187)
static void C_ccall f_9187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9236)
static void C_ccall f_9236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9219)
static void C_ccall f_9219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9198)
static void C_ccall f_9198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9158)
static void C_fcall f_9158(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9072)
static void C_ccall f_9072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9098)
static void C_ccall f_9098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9143)
static void C_ccall f_9143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9126)
static void C_ccall f_9126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8818)
static void C_ccall f_8818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8865)
static void C_ccall f_8865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9063)
static void C_ccall f_9063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9059)
static void C_ccall f_9059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9026)
static void C_ccall f_9026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8868)
static void C_ccall f_8868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8874)
static void C_ccall f_8874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8886)
static void C_ccall f_8886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8952)
static void C_fcall f_8952(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8967)
static void C_ccall f_8967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8889)
static void C_fcall f_8889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8923)
static void C_fcall f_8923(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8892)
static void C_ccall f_8892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8921)
static void C_ccall f_8921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8917)
static void C_ccall f_8917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8913)
static void C_ccall f_8913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8611)
static void C_ccall f_8611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8641)
static void C_ccall f_8641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8741)
static void C_fcall f_8741(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8764)
static void C_fcall f_8764(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8778)
static void C_ccall f_8778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8782)
static void C_ccall f_8782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8751)
static void C_ccall f_8751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8701)
static void C_ccall f_8701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8705)
static void C_ccall f_8705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8650)
static void C_ccall f_8650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8658)
static void C_fcall f_8658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8635)
static void C_ccall f_8635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8323)
static void C_ccall f_8323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8330)
static void C_fcall f_8330(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8369)
static void C_fcall f_8369(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8379)
static void C_fcall f_8379(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8510)
static void C_ccall f_8510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8514)
static void C_ccall f_8514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8443)
static void C_ccall f_8443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8439)
static void C_ccall f_8439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8377)
static void C_ccall f_8377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8373)
static void C_ccall f_8373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8034)
static void C_ccall f_8034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8148)
static void C_fcall f_8148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8094)
static void C_ccall f_8094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7900)
static void C_ccall f_7900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7907)
static void C_fcall f_7907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7959)
static void C_ccall f_7959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7955)
static void C_ccall f_7955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7936)
static void C_ccall f_7936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7944)
static void C_ccall f_7944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7806)
static void C_ccall f_7806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6807)
static void C_ccall f_6807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6811)
static void C_ccall f_6811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6820)
static void C_ccall f_6820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7572)
static void C_ccall f_7572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7425)
static void C_ccall f_7425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7430)
static void C_ccall f_7430(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7452)
static void C_ccall f_7452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7524)
static void C_ccall f_7524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7455)
static void C_ccall f_7455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7482)
static void C_ccall f_7482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7522)
static void C_ccall f_7522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7458)
static void C_ccall f_7458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7480)
static void C_ccall f_7480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7461)
static void C_ccall f_7461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7428)
static void C_ccall f_7428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6961)
static void C_fcall f_6961(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6980)
static void C_fcall f_6980(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7001)
static void C_ccall f_7001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7081)
static void C_ccall f_7081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7188)
static void C_ccall f_7188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7335)
static void C_ccall f_7335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7338)
static void C_ccall f_7338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7341)
static void C_ccall f_7341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7343)
static void C_ccall f_7343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7363)
static void C_ccall f_7363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7351)
static void C_ccall f_7351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7191)
static void C_ccall f_7191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7200)
static void C_fcall f_7200(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7329)
static void C_ccall f_7329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7298)
static void C_ccall f_7298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7277)
static void C_ccall f_7277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7258)
static void C_ccall f_7258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7246)
static void C_ccall f_7246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7221)
static void C_ccall f_7221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7216)
static void C_ccall f_7216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7092)
static void C_fcall f_7092(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7178)
static void C_ccall f_7178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7104)
static void C_fcall f_7104(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_ccall f_7004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7007)
static void C_ccall f_7007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7012)
static void C_fcall f_7012(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6874)
static void C_fcall f_6874(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6878)
static void C_ccall f_6878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6881)
static void C_ccall f_6881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6902)
static void C_ccall f_6902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6905)
static void C_ccall f_6905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6944)
static void C_ccall f_6944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6938)
static void C_ccall f_6938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6942)
static void C_ccall f_6942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6917)
static void C_ccall f_6917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6920)
static void C_ccall f_6920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6934)
static void C_ccall f_6934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6884)
static void C_ccall f_6884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6831)
static void C_fcall f_6831(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6844)
static void C_ccall f_6844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6826)
static void C_ccall f_6826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6615)
static void C_ccall f_6615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6617)
static void C_ccall f_6617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6781)
static void C_ccall f_6781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6694)
static void C_fcall f_6694(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6697)
static void C_ccall f_6697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6775)
static void C_ccall f_6775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6700)
static void C_fcall f_6700(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6769)
static void C_ccall f_6769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6719)
static void C_ccall f_6719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6726)
static void C_ccall f_6726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6682)
static void C_fcall f_6682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6795)
static void C_fcall f_6795(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6799)
static void C_ccall f_6799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6620)
static void C_ccall f_6620(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6651)
static void C_ccall f_6651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6567)
static void C_fcall f_6567(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6558)
static void C_fcall f_6558(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6566)
static void C_ccall f_6566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6155)
static void C_fcall f_6155(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6286)
static void C_fcall f_6286(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_fcall f_6291(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6492)
static void C_ccall f_6492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6310)
static void C_fcall f_6310(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6315)
static void C_fcall f_6315(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_ccall f_6257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6263)
static C_word C_fcall f_6263(C_word t0);
C_noret_decl(f_6201)
static void C_ccall f_6201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6213)
static void C_fcall f_6213(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6158)
static void C_fcall f_6158(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6165)
static void C_ccall f_6165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6170)
static void C_fcall f_6170(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6181)
static void C_ccall f_6181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6114)
static void C_ccall f_6114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6036)
static void C_ccall f_6036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6099)
static void C_ccall f_6099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6039)
static void C_fcall f_6039(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5953)
static void C_fcall f_5953(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6034)
static void C_ccall f_6034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5956)
static void C_fcall f_5956(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_fcall f_5643(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5649)
static void C_fcall f_5649(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5671)
static void C_fcall f_5671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5689)
static void C_ccall f_5689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5694)
static void C_fcall f_5694(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5763)
static void C_ccall f_5763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5741)
static void C_ccall f_5741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5466)
static void C_fcall f_5466(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5476)
static void C_fcall f_5476(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_fcall f_5522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static void C_fcall f_5540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5491)
static void C_ccall f_5491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5499)
static void C_ccall f_5499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_fcall f_5214(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5325)
static void C_ccall f_5325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5339)
static void C_ccall f_5339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5361)
static void C_ccall f_5361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5365)
static void C_ccall f_5365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5396)
static void C_ccall f_5396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5343)
static void C_ccall f_5343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5226)
static void C_fcall f_5226(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5249)
static void C_fcall f_5249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5260)
static void C_ccall f_5260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_fcall f_4655(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5145)
static void C_fcall f_5145(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_fcall f_5064(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_fcall f_5018(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_fcall f_5021(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_fcall f_4981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_fcall f_4943(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_fcall f_4877(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4673)
static void C_fcall f_4673(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_fcall f_4685(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4780)
static void C_ccall f_4780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_fcall f_4676(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_fcall f_4621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4581)
static void C_fcall f_4581(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4600)
static void C_fcall f_4600(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4531)
static void C_fcall f_4531(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_fcall f_4439(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4237)
static void C_fcall f_4237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4343)
static void C_fcall f_4343(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_fcall f_4169(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_fcall f_4014(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_fcall f_4052(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_fcall f_4069(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4088)
static void C_fcall f_4088(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_fcall f_4049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_fcall f_3965(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3746)
static void C_ccall f_3746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3670)
static void C_fcall f_3670(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_fcall f_3680(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_fcall f_3652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

C_noret_decl(trf_13253)
static void C_fcall trf_13253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13253(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13253(t0,t1,t2);}

C_noret_decl(trf_12791)
static void C_fcall trf_12791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12791(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12791(t0,t1,t2);}

C_noret_decl(trf_12637)
static void C_fcall trf_12637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12637(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12637(t0,t1,t2);}

C_noret_decl(trf_12537)
static void C_fcall trf_12537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12537(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12537(t0,t1,t2);}

C_noret_decl(trf_12318)
static void C_fcall trf_12318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12318(t0,t1);}

C_noret_decl(trf_12334)
static void C_fcall trf_12334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12334(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12334(t0,t1);}

C_noret_decl(trf_12150)
static void C_fcall trf_12150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12150(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12150(t0,t1,t2);}

C_noret_decl(trf_11881)
static void C_fcall trf_11881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11881(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11881(t0,t1,t2,t3);}

C_noret_decl(trf_11871)
static void C_fcall trf_11871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11871(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11871(t0,t1,t2,t3);}

C_noret_decl(trf_11720)
static void C_fcall trf_11720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11720(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11720(t0,t1,t2);}

C_noret_decl(trf_11570)
static void C_fcall trf_11570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11570(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11570(t0,t1,t2);}

C_noret_decl(trf_11560)
static void C_fcall trf_11560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11560(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11560(t0,t1,t2);}

C_noret_decl(trf_11326)
static void C_fcall trf_11326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11326(t0,t1);}

C_noret_decl(trf_11265)
static void C_fcall trf_11265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11265(t0,t1);}

C_noret_decl(trf_11214)
static void C_fcall trf_11214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11214(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11214(t0,t1,t2);}

C_noret_decl(trf_11148)
static void C_fcall trf_11148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11148(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11148(t0,t1,t2);}

C_noret_decl(trf_11003)
static void C_fcall trf_11003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11003(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11003(t0,t1,t2);}

C_noret_decl(trf_11054)
static void C_fcall trf_11054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11054(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11054(t0,t1);}

C_noret_decl(trf_11066)
static void C_fcall trf_11066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11066(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11066(t0,t1);}

C_noret_decl(trf_10797)
static void C_fcall trf_10797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10797(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10797(t0,t1,t2);}

C_noret_decl(trf_10825)
static void C_fcall trf_10825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10825(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10825(t0,t1);}

C_noret_decl(trf_10307)
static void C_fcall trf_10307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10307(t0,t1);}

C_noret_decl(trf_10315)
static void C_fcall trf_10315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10315(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10315(t0,t1);}

C_noret_decl(trf_10227)
static void C_fcall trf_10227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10227(t0,t1);}

C_noret_decl(trf_10242)
static void C_fcall trf_10242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10242(t0,t1,t2);}

C_noret_decl(trf_9951)
static void C_fcall trf_9951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9951(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9951(t0,t1);}

C_noret_decl(trf_10032)
static void C_fcall trf_10032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10032(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10032(t0,t1,t2);}

C_noret_decl(trf_10061)
static void C_fcall trf_10061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10061(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10061(t0,t1,t2);}

C_noret_decl(trf_10009)
static void C_fcall trf_10009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10009(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10009(t0,t1,t2,t3);}

C_noret_decl(trf_9917)
static void C_fcall trf_9917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9917(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9917(t0,t1);}

C_noret_decl(trf_9627)
static void C_fcall trf_9627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9627(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9627(t0,t1,t2,t3);}

C_noret_decl(trf_9396)
static void C_fcall trf_9396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9396(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9396(t0,t1,t2);}

C_noret_decl(trf_9316)
static void C_fcall trf_9316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9316(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9316(t0,t1,t2);}

C_noret_decl(trf_9323)
static void C_fcall trf_9323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9323(t0,t1);}

C_noret_decl(trf_9158)
static void C_fcall trf_9158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9158(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9158(t0,t1);}

C_noret_decl(trf_8952)
static void C_fcall trf_8952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8952(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8952(t0,t1);}

C_noret_decl(trf_8889)
static void C_fcall trf_8889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8889(t0,t1);}

C_noret_decl(trf_8923)
static void C_fcall trf_8923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8923(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8923(t0,t1,t2,t3);}

C_noret_decl(trf_8741)
static void C_fcall trf_8741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8741(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8741(t0,t1);}

C_noret_decl(trf_8764)
static void C_fcall trf_8764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8764(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8764(t0,t1,t2);}

C_noret_decl(trf_8658)
static void C_fcall trf_8658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8658(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8658(t0,t1);}

C_noret_decl(trf_8330)
static void C_fcall trf_8330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8330(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8330(t0,t1);}

C_noret_decl(trf_8369)
static void C_fcall trf_8369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8369(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8369(t0,t1);}

C_noret_decl(trf_8379)
static void C_fcall trf_8379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8379(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8379(t0,t1,t2);}

C_noret_decl(trf_8148)
static void C_fcall trf_8148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8148(t0,t1);}

C_noret_decl(trf_7907)
static void C_fcall trf_7907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7907(t0,t1);}

C_noret_decl(trf_6961)
static void C_fcall trf_6961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6961(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6961(t0,t1,t2);}

C_noret_decl(trf_6980)
static void C_fcall trf_6980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6980(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6980(t0,t1);}

C_noret_decl(trf_7200)
static void C_fcall trf_7200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7200(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7200(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7092)
static void C_fcall trf_7092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7092(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7092(t0,t1,t2,t3);}

C_noret_decl(trf_7104)
static void C_fcall trf_7104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7104(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7104(t0,t1,t2,t3);}

C_noret_decl(trf_7012)
static void C_fcall trf_7012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7012(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7012(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6874)
static void C_fcall trf_6874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6874(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6874(t0,t1,t2);}

C_noret_decl(trf_6831)
static void C_fcall trf_6831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6831(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6831(t0,t1,t2);}

C_noret_decl(trf_6694)
static void C_fcall trf_6694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6694(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6694(t0,t1);}

C_noret_decl(trf_6700)
static void C_fcall trf_6700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6700(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6700(t0,t1);}

C_noret_decl(trf_6682)
static void C_fcall trf_6682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6682(t0,t1);}

C_noret_decl(trf_6795)
static void C_fcall trf_6795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6795(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6795(t0,t1,t2);}

C_noret_decl(trf_6567)
static void C_fcall trf_6567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6567(t0,t1);}

C_noret_decl(trf_6558)
static void C_fcall trf_6558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6558(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6558(t0,t1,t2);}

C_noret_decl(trf_6155)
static void C_fcall trf_6155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6155(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6155(t0,t1,t2,t3);}

C_noret_decl(trf_6286)
static void C_fcall trf_6286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6286(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6286(t0,t1);}

C_noret_decl(trf_6291)
static void C_fcall trf_6291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6291(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6291(t0,t1,t2,t3);}

C_noret_decl(trf_6310)
static void C_fcall trf_6310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6310(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6310(t0,t1);}

C_noret_decl(trf_6315)
static void C_fcall trf_6315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6315(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6315(t0,t1,t2,t3);}

C_noret_decl(trf_6213)
static void C_fcall trf_6213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6213(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6213(t0,t1,t2);}

C_noret_decl(trf_6158)
static void C_fcall trf_6158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6158(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6158(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6170)
static void C_fcall trf_6170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6170(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6170(t0,t1,t2);}

C_noret_decl(trf_6039)
static void C_fcall trf_6039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6039(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6039(t0,t1,t2,t3);}

C_noret_decl(trf_5953)
static void C_fcall trf_5953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5953(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5953(t0,t1,t2,t3);}

C_noret_decl(trf_5956)
static void C_fcall trf_5956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5956(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5956(t0,t1,t2,t3);}

C_noret_decl(trf_5643)
static void C_fcall trf_5643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5643(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5643(t0,t1,t2);}

C_noret_decl(trf_5649)
static void C_fcall trf_5649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5649(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5649(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5671)
static void C_fcall trf_5671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5671(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5671(t0,t1);}

C_noret_decl(trf_5694)
static void C_fcall trf_5694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5694(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5694(t0,t1,t2);}

C_noret_decl(trf_5466)
static void C_fcall trf_5466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5466(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5466(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5476)
static void C_fcall trf_5476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5476(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5476(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5522)
static void C_fcall trf_5522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5522(t0,t1);}

C_noret_decl(trf_5540)
static void C_fcall trf_5540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5540(t0,t1);}

C_noret_decl(trf_5214)
static void C_fcall trf_5214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5214(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5214(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5226)
static void C_fcall trf_5226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5226(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5226(t0,t1,t2,t3);}

C_noret_decl(trf_5249)
static void C_fcall trf_5249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5249(t0,t1);}

C_noret_decl(trf_4655)
static void C_fcall trf_4655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4655(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4655(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5145)
static void C_fcall trf_5145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5145(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5145(t0,t1);}

C_noret_decl(trf_5064)
static void C_fcall trf_5064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5064(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5064(t0,t1);}

C_noret_decl(trf_5018)
static void C_fcall trf_5018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5018(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5018(t0,t1);}

C_noret_decl(trf_5021)
static void C_fcall trf_5021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5021(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5021(t0,t1);}

C_noret_decl(trf_4981)
static void C_fcall trf_4981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4981(t0,t1);}

C_noret_decl(trf_4943)
static void C_fcall trf_4943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4943(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4943(t0,t1);}

C_noret_decl(trf_4877)
static void C_fcall trf_4877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4877(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4877(t0,t1);}

C_noret_decl(trf_4673)
static void C_fcall trf_4673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4673(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4673(t0,t1);}

C_noret_decl(trf_4685)
static void C_fcall trf_4685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4685(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4685(t0,t1);}

C_noret_decl(trf_4676)
static void C_fcall trf_4676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4676(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4676(t0,t1);}

C_noret_decl(trf_4621)
static void C_fcall trf_4621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4621(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4621(t0,t1,t2);}

C_noret_decl(trf_4581)
static void C_fcall trf_4581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4581(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4581(t0,t1,t2);}

C_noret_decl(trf_4600)
static void C_fcall trf_4600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4600(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4600(t0,t1);}

C_noret_decl(trf_4531)
static void C_fcall trf_4531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4531(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4531(t0,t1,t2);}

C_noret_decl(trf_4439)
static void C_fcall trf_4439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4439(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4439(t0,t1,t2);}

C_noret_decl(trf_4237)
static void C_fcall trf_4237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4237(t0,t1);}

C_noret_decl(trf_4343)
static void C_fcall trf_4343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4343(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4343(t0,t1);}

C_noret_decl(trf_4169)
static void C_fcall trf_4169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4169(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4169(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4014)
static void C_fcall trf_4014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4014(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4014(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4052)
static void C_fcall trf_4052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4052(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4052(t0,t1);}

C_noret_decl(trf_4069)
static void C_fcall trf_4069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4069(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4069(t0,t1,t2);}

C_noret_decl(trf_4088)
static void C_fcall trf_4088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4088(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4088(t0,t1);}

C_noret_decl(trf_4049)
static void C_fcall trf_4049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4049(t0,t1);}

C_noret_decl(trf_3965)
static void C_fcall trf_3965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3965(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3965(t0,t1,t2);}

C_noret_decl(trf_3670)
static void C_fcall trf_3670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3670(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3670(t0,t1,t2);}

C_noret_decl(trf_3680)
static void C_fcall trf_3680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3680(t0,t1);}

C_noret_decl(trf_3652)
static void C_fcall trf_3652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3652(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3652(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_expand_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("expand_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3595)){
C_save(t1);
C_rereclaim2(3595*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,351);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],12,"\003sysfeatures");
lf[4]=C_h_intern(&lf[4],2,"pp");
lf[5]=C_h_intern(&lf[5],5,"print");
lf[8]=C_h_intern(&lf[8],23,"\003syscurrent-environment");
lf[9]=C_h_intern(&lf[9],28,"\003syscurrent-meta-environment");
lf[11]=C_h_intern(&lf[11],7,"\003sysget");
lf[12]=C_h_intern(&lf[12],16,"\004coremacro-alias");
lf[14]=C_h_intern(&lf[14],19,"\003sysundefined-value");
lf[15]=C_h_intern(&lf[15],8,"\003sysput!");
lf[16]=C_h_intern(&lf[16],6,"gensym");
lf[17]=C_h_intern(&lf[17],21,"\003sysqualified-symbol\077");
lf[19]=C_h_intern(&lf[19],7,"<macro>");
lf[20]=C_h_intern(&lf[20],7,"\003sysmap");
lf[21]=C_h_intern(&lf[21],16,"\003sysstrip-syntax");
lf[22]=C_h_intern(&lf[22],3,"get");
lf[23]=C_h_intern(&lf[23],12,"list->vector");
lf[24]=C_h_intern(&lf[24],12,"vector->list");
lf[25]=C_h_intern(&lf[25],9,"\003syserror");
lf[26]=C_h_intern(&lf[26],12,"strip-syntax");
lf[27]=C_h_intern(&lf[27],21,"\003sysmacro-environment");
lf[28]=C_h_intern(&lf[28],29,"\003syschicken-macro-environment");
lf[29]=C_h_intern(&lf[29],33,"\003syschicken-ffi-macro-environment");
lf[30]=C_h_intern(&lf[30],28,"\003sysextend-macro-environment");
lf[31]=C_h_intern(&lf[31],14,"\003syscopy-macro");
lf[32]=C_h_intern(&lf[32],6,"macro\077");
lf[33]=C_h_intern(&lf[33],20,"\003sysunregister-macro");
lf[34]=C_h_intern(&lf[34],4,"caar");
lf[35]=C_h_intern(&lf[35],15,"undefine-macro!");
lf[36]=C_h_intern(&lf[36],12,"\003sysexpand-0");
lf[37]=C_h_intern(&lf[37],9,"\003sysabort");
lf[38]=C_h_intern(&lf[38],9,"condition");
lf[39]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[40]=C_h_intern(&lf[40],13,"string-append");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[43]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[44]=C_h_intern(&lf[44],3,"exn");
lf[45]=C_h_intern(&lf[45],22,"with-exception-handler");
lf[46]=C_h_intern(&lf[46],30,"call-with-current-continuation");
lf[47]=C_h_intern(&lf[47],21,"\003syssyntax-error-hook");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[49]=C_h_intern(&lf[49],3,"let");
lf[50]=C_h_intern(&lf[50],8,"\004corelet");
lf[51]=C_h_intern(&lf[51],16,"\004coreloop-lambda");
lf[52]=C_h_intern(&lf[52],8,"\004coreapp");
lf[53]=C_h_intern(&lf[53],10,"\003sysappend");
lf[54]=C_h_intern(&lf[54],4,"cadr");
lf[55]=C_h_intern(&lf[55],6,"letrec");
lf[56]=C_h_intern(&lf[56],16,"\003syscheck-syntax");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[58]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[59]=C_h_intern(&lf[59],10,"\003syssetter");
lf[60]=C_h_intern(&lf[60],6,"append");
lf[61]=C_h_intern(&lf[61],4,"set!");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[63]=C_h_intern(&lf[63],9,"\004coreset!");
lf[64]=C_h_intern(&lf[64],25,"\003sysenable-runtime-macros");
lf[65]=C_h_intern(&lf[65],17,"\003sysmodule-rename");
lf[66]=C_h_intern(&lf[66],18,"\003sysstring->symbol");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[68]=C_h_intern(&lf[68],21,"\003sysalias-global-hook");
lf[70]=C_h_intern(&lf[70],22,"\003sysregister-undefined");
lf[71]=C_h_intern(&lf[71],18,"\003syscurrent-module");
lf[72]=C_h_intern(&lf[72],14,"\004coreprimitive");
lf[73]=C_h_intern(&lf[73],12,"\004corealiased");
lf[74]=C_h_intern(&lf[74],10,"\003sysexpand");
lf[75]=C_h_intern(&lf[75],6,"expand");
lf[76]=C_h_intern(&lf[76],25,"\003sysextended-lambda-list\077");
lf[77]=C_h_intern(&lf[77],6,"#!rest");
lf[78]=C_h_intern(&lf[78],10,"#!optional");
lf[79]=C_h_intern(&lf[79],5,"#!key");
lf[80]=C_h_intern(&lf[80],7,"reverse");
lf[81]=C_h_intern(&lf[81],31,"\003sysexpand-extended-lambda-list");
lf[82]=C_h_intern(&lf[82],5,"cadar");
lf[83]=C_h_intern(&lf[83],5,"quote");
lf[84]=C_h_intern(&lf[84],15,"\003sysget-keyword");
lf[85]=C_h_intern(&lf[85],11,"\004corelambda");
lf[86]=C_h_intern(&lf[86],15,"string->keyword");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[89]=C_h_intern(&lf[89],3,"tmp");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[98]=C_h_intern(&lf[98],14,"let-optionals*");
lf[99]=C_h_intern(&lf[99],13,"let-optionals");
lf[100]=C_h_intern(&lf[100],8,"optional");
lf[101]=C_h_intern(&lf[101],4,"let*");
lf[102]=C_h_intern(&lf[102],3,"map");
lf[103]=C_h_intern(&lf[103],21,"\003syscanonicalize-body");
lf[104]=C_h_intern(&lf[104],5,"begin");
lf[105]=C_h_intern(&lf[105],6,"define");
lf[106]=C_h_intern(&lf[106],13,"define-values");
lf[107]=C_h_intern(&lf[107],20,"\003syscall-with-values");
lf[108]=C_h_intern(&lf[108],14,"\004coreundefined");
lf[109]=C_h_intern(&lf[109],3,"cdr");
lf[110]=C_h_intern(&lf[110],13,"letrec-syntax");
lf[111]=C_h_intern(&lf[111],13,"define-syntax");
lf[112]=C_h_intern(&lf[112],5,"cdadr");
lf[113]=C_h_intern(&lf[113],6,"lambda");
lf[114]=C_h_intern(&lf[114],5,"caadr");
lf[115]=C_h_intern(&lf[115],25,"\003sysexpand-curried-define");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[119]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[120]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[121]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-syntax\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[122]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[123]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[125]=C_h_intern(&lf[125],24,"\003sysline-number-database");
lf[126]=C_h_intern(&lf[126],24,"\003syssyntax-error-culprit");
lf[127]=C_h_intern(&lf[127],15,"\003syssignal-hook");
lf[128]=C_h_intern(&lf[128],13,"\000syntax-error");
lf[129]=C_h_intern(&lf[129],12,"syntax-error");
lf[130]=C_h_intern(&lf[130],15,"get-line-number");
lf[131]=C_h_intern(&lf[131],18,"\003syshash-table-ref");
lf[132]=C_h_intern(&lf[132],8,"keyword\077");
lf[133]=C_h_intern(&lf[133],14,"symbol->string");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[143]=C_h_intern(&lf[143],1,"_");
lf[144]=C_h_intern(&lf[144],4,"pair");
lf[145]=C_h_intern(&lf[145],5,"pair\077");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[147]=C_h_intern(&lf[147],8,"variable");
lf[148]=C_h_intern(&lf[148],7,"symbol\077");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[150]=C_h_intern(&lf[150],6,"symbol");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[152]=C_h_intern(&lf[152],4,"list");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[154]=C_h_intern(&lf[154],6,"number");
lf[155]=C_h_intern(&lf[155],7,"number\077");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[157]=C_h_intern(&lf[157],6,"string");
lf[158]=C_h_intern(&lf[158],7,"string\077");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[160]=C_h_intern(&lf[160],11,"lambda-list");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[165]=C_h_intern(&lf[165],18,"\003syser-transformer");
lf[166]=C_h_intern(&lf[166],17,"\003sysexpand-import");
lf[167]=C_h_intern(&lf[167],17,"\003sysstring-append");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[169]=C_h_intern(&lf[169],18,"\003syssymbol->string");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid prefix");
lf[173]=C_h_intern(&lf[173],15,"\003sysfind-module");
lf[174]=C_h_intern(&lf[174],8,"\003sysload");
lf[175]=C_h_intern(&lf[175],16,"\003sysdynamic-wind");
lf[176]=C_h_intern(&lf[176],26,"\003sysmeta-macro-environment");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000$can not import from undefined module");
lf[178]=C_h_intern(&lf[178],18,"\003sysfind-extension");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\007.import");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[181]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[182]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[183]=C_h_intern(&lf[183],8,"\003syswarn");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\037renamed identifier not imported");
lf[185]=C_h_intern(&lf[185],12,"\003sysfor-each");
lf[186]=C_h_intern(&lf[186],8,"\003sysdelq");
lf[187]=C_h_intern(&lf[187],4,"cdar");
lf[188]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[191]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000&re-importing already imported syntax: ");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000)re-importing already imported identfier: ");
lf[194]=C_h_intern(&lf[194],25,"\003sysmark-imported-symbols");
lf[195]=C_h_intern(&lf[195],6,"module");
lf[196]=C_h_intern(&lf[196],14,"\003sysblock-set!");
lf[199]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[200]=C_h_intern(&lf[200],6,"prefix");
lf[201]=C_h_intern(&lf[201],6,"except");
lf[202]=C_h_intern(&lf[202],6,"rename");
lf[203]=C_h_intern(&lf[203],4,"only");
lf[204]=C_h_intern(&lf[204],29,"\003sysinitial-macro-environment");
lf[205]=C_h_intern(&lf[205],24,"\003sysprocess-syntax-rules");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\026ill-formed syntax rule");
lf[208]=C_h_intern(&lf[208],6,"syntax");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000,template dimension error (too few ellipses\077)");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\021too many ellipses");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000 segment matching not implemented");
lf[212]=C_h_intern(&lf[212],4,"temp");
lf[213]=C_h_intern(&lf[213],4,"tail");
lf[214]=C_h_intern(&lf[214],2,"or");
lf[215]=C_h_intern(&lf[215],5,"null\077");
lf[216]=C_h_intern(&lf[216],4,"loop");
lf[217]=C_h_intern(&lf[217],5,"list\077");
lf[218]=C_h_intern(&lf[218],1,"l");
lf[219]=C_h_intern(&lf[219],5,"input");
lf[220]=C_h_intern(&lf[220],6,"equal\077");
lf[221]=C_h_intern(&lf[221],3,"eq\077");
lf[222]=C_h_intern(&lf[222],4,"else");
lf[223]=C_h_intern(&lf[223],4,"cons");
lf[224]=C_h_intern(&lf[224],4,"cond");
lf[225]=C_h_intern(&lf[225],7,"compare");
lf[226]=C_h_intern(&lf[226],1,"i");
lf[227]=C_h_intern(&lf[227],1,"+");
lf[228]=C_h_intern(&lf[228],1,"=");
lf[229]=C_h_intern(&lf[229],2,">=");
lf[230]=C_h_intern(&lf[230],10,"vector-ref");
lf[231]=C_h_intern(&lf[231],13,"vector-length");
lf[232]=C_h_intern(&lf[232],7,"vector\077");
lf[233]=C_h_intern(&lf[233],3,"car");
lf[234]=C_h_intern(&lf[234],3,"and");
lf[235]=C_h_intern(&lf[235],5,"apply");
lf[236]=C_h_intern(&lf[236],29,"\003sysdefault-macro-environment");
lf[243]=C_h_intern(&lf[243],26,"set-module-undefined-list!");
lf[244]=C_h_intern(&lf[244],21,"module-undefined-list");
lf[247]=C_h_intern(&lf[247],16,"\003sysmodule-table");
lf[248]=C_h_intern(&lf[248],5,"error");
lf[249]=C_h_intern(&lf[249],6,"import");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\020module not found");
lf[251]=C_h_intern(&lf[251],28,"\003systoplevel-definition-hook");
lf[252]=C_h_intern(&lf[252],28,"\003sysregister-meta-expression");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\047redefinition of imported syntax binding");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000&redefinition of imported value binding");
lf[256]=C_h_intern(&lf[256],19,"\003sysregister-export");
lf[257]=C_h_intern(&lf[257],15,"\003sysfind-export");
lf[258]=C_h_intern(&lf[258],26,"\003sysregister-syntax-export");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000!use of syntax precedes definition");
lf[260]=C_h_intern(&lf[260],19,"\003sysregister-module");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\014 in module `");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000!indirect export of syntax binding");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\033indirect reexport of syntax");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\042indirect export of unknown binding");
lf[268]=C_h_intern(&lf[268],32,"\003syscompiled-module-registration");
lf[269]=C_h_intern(&lf[269],28,"\003sysregister-compiled-module");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000((internal) exported syntax has no source");
lf[271]=C_h_intern(&lf[271],4,"eval");
lf[272]=C_h_intern(&lf[272],29,"\003sysregister-primitive-module");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\0001unknown macro referenced while registering module");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\002#%");
lf[275]=C_h_intern(&lf[275],18,"module-exists-list");
lf[276]=C_h_intern(&lf[276],19,"\003sysfinalize-module");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000$(internal) indirect export not found");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000(reference to possibly unbound identifier");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000 exported identifier for module `");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\026\047 has not been defined");
lf[281]=C_h_intern(&lf[281],16,"\003sysmacro-subset");
lf[282]=C_h_intern(&lf[282],14,"make-parameter");
lf[283]=C_h_intern(&lf[283],12,"syntax-rules");
lf[284]=C_h_intern(&lf[284],3,"...");
lf[285]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[286]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[287]=C_h_intern(&lf[287],6,"export");
lf[288]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000!`export\047 used outside module body");
lf[291]=C_h_intern(&lf[291],16,"begin-for-syntax");
lf[292]=C_h_intern(&lf[292],24,"\004coreelaborationtimeonly");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[294]=C_h_intern(&lf[294],11,"\004coremodule");
lf[295]=C_h_intern(&lf[295],1,"*");
lf[296]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[297]=C_h_intern(&lf[297],17,"require-extension");
lf[298]=C_h_intern(&lf[298],22,"\004corerequire-extension");
lf[299]=C_h_intern(&lf[299],15,"require-library");
lf[300]=C_h_intern(&lf[300],11,"cond-expand");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[302]=C_h_intern(&lf[302],12,"\003sysfeature\077");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[304]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[305]=C_h_intern(&lf[305],3,"not");
lf[306]=C_h_intern(&lf[306],5,"delay");
lf[307]=C_h_intern(&lf[307],16,"\003sysmake-promise");
lf[308]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[309]=C_h_intern(&lf[309],10,"quasiquote");
lf[310]=C_h_intern(&lf[310],16,"\003syslist->vector");
lf[311]=C_h_intern(&lf[311],8,"\003syslist");
lf[312]=C_h_intern(&lf[312],8,"\003syscons");
lf[313]=C_h_intern(&lf[313],17,"%unquote-splicing");
lf[314]=C_h_intern(&lf[314],1,"a");
lf[315]=C_h_intern(&lf[315],1,"b");
lf[316]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[317]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[318]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[319]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[320]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[321]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[322]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[323]=C_h_intern(&lf[323],16,"unquote-splicing");
lf[324]=C_h_intern(&lf[324],7,"unquote");
lf[325]=C_h_intern(&lf[325],2,"do");
lf[326]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[327]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[328]=C_h_intern(&lf[328],2,"if");
lf[329]=C_h_intern(&lf[329],6,"doloop");
lf[330]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001"
"\000\000\000\001");
lf[331]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[332]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[333]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[334]=C_h_intern(&lf[334],4,"case");
lf[335]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[336]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[337]=C_h_intern(&lf[337],4,"eqv\077");
lf[338]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[339]=C_h_intern(&lf[339],9,"\003sysapply");
lf[340]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[341]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[342]=C_h_intern(&lf[342],2,"=>");
lf[343]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[344]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[345]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[346]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[347]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[348]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[349]=C_h_intern(&lf[349],17,"import-for-syntax");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\020\000hygienic-macros\376\003\000\000\002\376\001\000\000\015\000syntax-rules\376\377\016");
C_register_lf2(lf,351,create_ptable());
t2=C_mutate(&lf[0] /* c219 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3619,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 38   append");
t4=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[350],*((C_word*)lf[2]+1));}

/* k3617 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3619,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* features ...) */,t1);
t3=C_mutate(&lf[3] /* d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3621,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[6] /* dd ...) */,C_retrieve2(lf[3],"d"));
t5=C_mutate(&lf[7] /* dm ...) */,C_retrieve2(lf[3],"d"));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 66   make-parameter");
t7=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_END_OF_LIST);}

/* k3644 in k3617 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3646,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1 /* current-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3650,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 67   make-parameter");
t4=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}

/* k3648 in k3644 in k3617 */
static void C_ccall f_3650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3650,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* current-meta-environment ...) */,t1);
t3=C_mutate(&lf[10] /* lookup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3652,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[13] /* macro-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[18] /* map-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3712,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[21]+1 /* strip-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3742,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[26]+1 /* strip-syntax ...) */,C_retrieve(lf[21]));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 117  make-parameter");
t9=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_END_OF_LIST);}

/* k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1 /* macro-environment ...) */,t1);
t3=C_set_block_item(lf[28] /* chicken-macro-environment */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[29] /* chicken-ffi-macro-environment */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[30]+1 /* extend-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3849,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[31]+1 /* copy-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3882,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[32]+1 /* macro? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3895,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[33]+1 /* unregister-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3951,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[35]+1 /* undefine-macro! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4002,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[36]+1 /* expand-0 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4011,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(lf[64] /* enable-runtime-macros */,0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[65]+1 /* module-rename ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4418,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[68]+1 /* alias-global-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4436,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[74]+1 /* expand ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4522,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[75]+1 /* expand ...) */,C_retrieve(lf[74]));
t16=C_mutate((C_word*)lf[76]+1 /* extended-lambda-list? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4575,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[80]+1);
t18=C_retrieve(lf[16]);
t19=C_mutate((C_word*)lf[81]+1 /* expand-extended-lambda-list ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4618,a[2]=t17,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[80]+1);
t21=*((C_word*)lf[102]+1);
t22=C_mutate((C_word*)lf[103]+1 /* canonicalize-body ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5208,a[2]=t21,a[3]=t20,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate(&lf[124] /* match-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5953,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[115]+1 /* expand-curried-define ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6036,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(lf[125] /* line-number-database */,0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[126] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
t27=C_mutate((C_word*)lf[47]+1 /* syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6106,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[129]+1 /* syntax-error ...) */,C_retrieve(lf[47]));
t29=C_mutate((C_word*)lf[130]+1 /* get-line-number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6117,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[40]+1);
t31=C_retrieve(lf[132]);
t32=C_retrieve(lf[130]);
t33=*((C_word*)lf[133]+1);
t34=C_mutate((C_word*)lf[56]+1 /* check-syntax ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6153,a[2]=t31,a[3]=t32,a[4]=t33,a[5]=t30,a[6]=((C_word)li68),tmp=(C_word)a,a+=7,tmp));
t35=C_mutate((C_word*)lf[165]+1 /* er-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6615,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[166]+1 /* expand-import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6807,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7598,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13393,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13395,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 865  ##sys#er-transformer");
t40=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t40))(3,t40,t38,t39);}

/* a13394 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13395(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13395,5,t0,t1,t2,t3,t4);}
C_trace("##sys#expand-import");
t5=C_retrieve(lf[166]);
((C_proc9)C_retrieve_proc(t5))(9,t5,t1,t2,t3,t4,C_retrieve(lf[8]),C_retrieve(lf[27]),C_SCHEME_FALSE,lf[249]);}

/* k13391 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 863  ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[249],C_SCHEME_END_OF_LIST,t1);}

/* k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7601,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13383,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13385,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 871  ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13384 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13385,5,t0,t1,t2,t3,t4);}
C_trace("##sys#expand-import");
t5=C_retrieve(lf[166]);
((C_proc9)C_retrieve_proc(t5))(9,t5,t1,t2,t3,t4,C_retrieve(lf[9]),C_retrieve(lf[176]),C_SCHEME_TRUE,lf[349]);}

/* k13381 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 869  ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[349],C_SCHEME_END_OF_LIST,t1);}

/* k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7605,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 875  ##sys#macro-environment");
t3=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7605,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1 /* initial-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7608,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13241,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13243,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 880  ##sys#er-transformer");
t6=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13243(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13243,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13253,a[2]=t3,a[3]=t7,a[4]=((C_word)li199),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_13253(t9,t1,t5);}

/* loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_13253(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13253,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13309,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 891  ##sys#check-syntax");
t7=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[105],t3,lf[344]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13322,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 895  ##sys#check-syntax");
t7=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[105],t3,lf[346]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13269,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 886  ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[105],t3,lf[150]);}}

/* k13267 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 887  ##sys#check-syntax");
t3=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[105],((C_word*)t0)[4],lf[348]);}

/* k13270 in k13267 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13300,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 888  ##sys#current-module");
t4=C_retrieve(lf[71]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k13298 in k13270 in k13267 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 888  ##sys#register-export");
t2=C_retrieve(lf[256]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13273 in k13270 in k13267 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13275,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):lf[347]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[63],t5));}

/* k13320 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 896  ##sys#check-syntax");
t3=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[105],((C_word*)t0)[3],lf[345]);}

/* k13323 in k13320 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13371,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 897  ##sys#current-module");
t5=C_retrieve(lf[71]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k13369 in k13323 in k13320 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 897  ##sys#register-export");
t2=C_retrieve(lf[256]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13326 in k13323 in k13320 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13328,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 900  r");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[113]);}

/* k13349 in k13326 in k13323 in k13320 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13351,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13363,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13361 in k13349 in k13326 in k13323 in k13320 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13363,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[63],t5));}

/* k13307 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 892  ##sys#check-syntax");
t3=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[105],((C_word*)t0)[2],lf[343]);}

/* k13310 in k13307 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13319,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 893  ##sys#expand-curried-define");
t3=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13317 in k13310 in k13307 in loop in a13242 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 893  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_13253(t2,((C_word*)t0)[2],t1);}

/* k13239 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 877  ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[105],C_SCHEME_END_OF_LIST,t1);}

/* k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7611,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13182,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13184,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 905  ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13183 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13184,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13213,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 914  r");
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[328]);}}}

/* k13211 in a13183 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13233,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 914  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[234]);}

/* k13231 in k13211 in a13183 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13235 in k13231 in k13211 in a13183 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13237,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k13180 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 902  ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[234],C_SCHEME_END_OF_LIST,t1);}

/* k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7614,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13092,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13094,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 919  ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13093 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13094,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13119,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 928  r");
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[89]);}}}

/* k13117 in a13093 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 929  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[49]);}

/* k13124 in k13117 in a13093 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13126,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 930  r");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[328]);}

/* k13144 in k13124 in k13117 in a13093 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13166,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 930  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[214]);}

/* k13164 in k13144 in k13124 in k13117 in a13093 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13170,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13168 in k13164 in k13144 in k13124 in k13117 in a13093 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13170,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k13090 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 916  ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[214],C_SCHEME_END_OF_LIST,t1);}

/* k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12759,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12761,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 935  ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12761,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12768,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 938  r");
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[104]);}

/* k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 939  r");
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[49]);}

/* k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 940  r");
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[328]);}

/* k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 941  r");
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[342]);}

/* k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("expand.scm: 942  r");
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[214]);}

/* k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 943  r");
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[222]);}

/* k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("expand.scm: 944  r");
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[113]);}

/* k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12786,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12791,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word)li195),tmp=(C_word)a,a+=13,tmp));
t5=((C_word*)t3)[1];
f_12791(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_12791(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12791,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_12807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=((C_word*)t0)[11],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
C_trace("expand.scm: 950  ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[224],t3,lf[340]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[341]);}}

/* k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_12813,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
C_trace("expand.scm: 951  c");
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k12811 in k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12813,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12820,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
C_trace("##sys#append");
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12849,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 952  expand");
t5=((C_word*)((C_word*)t0)[9])[1];
f_12791(t5,t4,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[11]);
C_trace("expand.scm: 953  c");
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}}

/* k12853 in k12811 in k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12855,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12858,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 954  r");
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[89]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12923,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[12]))){
t3=(C_word)C_i_length(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t3,C_fix(4));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[12]);
C_trace("expand.scm: 960  c");
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,((C_word*)t0)[2],t5);}
else{
t5=t2;
f_12923(2,t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_12923(2,t3,C_SCHEME_FALSE);}}}

/* k12921 in k12853 in k12811 in k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12923,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12926,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 961  r");
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[89]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13048,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[9]);
C_trace("##sys#append");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k13046 in k12921 in k12853 in k12811 in k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13048,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13044,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 970  expand");
t4=((C_word*)((C_word*)t0)[3])[1];
f_12791(t4,t3,((C_word*)t0)[2]);}

/* k13042 in k13046 in k12921 in k12853 in k12811 in k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_13044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13044,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k12924 in k12921 in k12853 in k12811 in k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12926,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[339],t8);
t10=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[339],t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12981,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t9,a[7]=t13,tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 967  expand");
t15=((C_word*)((C_word*)t0)[3])[1];
f_12791(t15,t14,((C_word*)t0)[2]);}

/* k12979 in k12924 in k12921 in k12853 in k12811 in k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12981,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[328],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[107],t10));}

/* k12856 in k12853 in k12811 in k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12858,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12897,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 958  expand");
t10=((C_word*)((C_word*)t0)[3])[1];
f_12791(t10,t9,((C_word*)t0)[2]);}

/* k12895 in k12856 in k12853 in k12811 in k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12897,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k12847 in k12811 in k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12849,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k12818 in k12811 in k12805 in expand in k12784 in k12781 in k12778 in k12775 in k12772 in k12769 in k12766 in a12760 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12820,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12757 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 932  ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[224],C_SCHEME_END_OF_LIST,t1);}

/* k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7620,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12586,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12588,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 975  ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12588,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12592,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 977  ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[334],t2,lf[338]);}

/* k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12592,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12601,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 980  r");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[89]);}

/* k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 981  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[104]);}

/* k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 982  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[328]);}

/* k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("expand.scm: 983  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[214]);}

/* k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 984  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[337]);}

/* k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 985  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[222]);}

/* k12614 in k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12616,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12635,a[2]=((C_word*)t0)[8],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12637,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word)li193),tmp=(C_word)a,a+=11,tmp));
t9=((C_word*)t7)[1];
f_12637(t9,t5,((C_word*)t0)[2]);}

/* expand in k12614 in k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_12637(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12637,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
C_trace("expand.scm: 992  ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[334],t3,lf[335]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[336]);}}

/* k12651 in expand in k12614 in k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12659,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("expand.scm: 993  c");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k12657 in k12651 in expand in k12614 in k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12659,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12666,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
C_trace("##sys#append");
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12709,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12713,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li192),tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[8]);
C_trace("expand.scm: 995  ##sys#map");
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a12714 in k12657 in k12651 in expand in k12614 in k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12715,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k12711 in k12657 in k12651 in expand in k12614 in k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k12707 in k12657 in k12651 in expand in k12614 in k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12709,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12701,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("##sys#append");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k12699 in k12707 in k12657 in k12651 in expand in k12614 in k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12701,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12697,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 998  expand");
t4=((C_word*)((C_word*)t0)[3])[1];
f_12637(t4,t3,((C_word*)t0)[2]);}

/* k12695 in k12699 in k12707 in k12657 in k12651 in expand in k12614 in k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12697,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k12664 in k12657 in k12651 in expand in k12614 in k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12666,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12633 in k12614 in k12611 in k12608 in k12605 in k12602 in k12599 in k12590 in a12587 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12635,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[49],t3));}

/* k12584 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 972  ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[334],C_SCHEME_END_OF_LIST,t1);}

/* k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7623,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12517,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12519,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1003 ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12518 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12519,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12523,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1005 ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[101],t2,lf[333]);}

/* k12521 in a12518 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12523,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12532,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1008 r");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[49]);}

/* k12530 in k12521 in a12518 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12532,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12537,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li190),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_12537(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k12530 in k12521 in a12518 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_12537(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12537,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12555,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12574,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
C_trace("expand.scm: 1012 expand");
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k12572 in expand in k12530 in k12521 in a12518 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12574,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k12553 in expand in k12530 in k12521 in a12518 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12555,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12515 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1000 ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[101],C_SCHEME_END_OF_LIST,t1);}

/* k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7626,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12431,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12433,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1017 ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12432 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12433,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12437,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1019 ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[55],t2,lf[332]);}

/* k12435 in a12432 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12437,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12446,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1022 r");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[49]);}

/* k12444 in k12435 in a12432 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12505,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1023 ##sys#map");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a12504 in k12444 in k12435 in a12432 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12505,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[331]));}

/* k12455 in k12444 in k12435 in a12432 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12461,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12465,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12483,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1024 ##sys#map");
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a12482 in k12455 in k12444 in k12435 in a12432 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12483(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12483,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[63],t6));}

/* k12463 in k12455 in k12444 in k12435 in a12432 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12481,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k12479 in k12463 in k12455 in k12444 in k12435 in a12432 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12481,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k12459 in k12455 in k12444 in k12435 in a12432 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12461,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12429 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1014 ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[55],C_SCHEME_END_OF_LIST,t1);}

/* k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7629,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12249,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12251,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1030 ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12251,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12255,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1032 ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[325],t2,lf[330]);}

/* k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12255,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12267,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 1036 r");
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[329]);}

/* k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 1037 r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[49]);}

/* k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 1038 r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[328]);}

/* k12271 in k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 1039 r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[104]);}

/* k12274 in k12271 in k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12411,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1040 ##sys#map");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a12410 in k12274 in k12271 in k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12411,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k12289 in k12274 in k12271 in k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12291,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_12318(t6,lf[327]);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12409,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t7=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,C_SCHEME_END_OF_LIST);}}

/* k12407 in k12289 in k12274 in k12271 in k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12409,2,t0,t1);}
t2=((C_word*)t0)[3];
f_12318(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12316 in k12289 in k12274 in k12271 in k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_12318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12318,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12334,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_12334(t4,lf[326]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12399,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k12397 in k12316 in k12289 in k12274 in k12271 in k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12399,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_12334(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12332 in k12316 in k12289 in k12274 in k12271 in k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_12334(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12334,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12354,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12356,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1051 ##sys#map");
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a12355 in k12332 in k12316 in k12289 in k12274 in k12271 in k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12356(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12356,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_car(t2));}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t7));}}

/* k12352 in k12332 in k12316 in k12289 in k12274 in k12271 in k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k12348 in k12332 in k12316 in k12289 in k12274 in k12271 in k12268 in k12265 in k12253 in a12250 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12350,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[52],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k12247 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1027 ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[325],C_SCHEME_END_OF_LIST,t1);}

/* k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11854,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11856,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1060 ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11856,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11860,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 1062 r");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[83]);}

/* k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 1063 r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[309]);}

/* k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 1064 r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[324]);}

/* k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 1065 r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[323]);}

/* k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11869,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11871,a[2]=t5,a[3]=t7,a[4]=((C_word)li180),tmp=(C_word)a,a+=5,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11881,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word)li181),tmp=(C_word)a,a+=9,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12150,a[2]=t7,a[3]=((C_word)li182),tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12238,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1115 ##sys#check-syntax");
t12=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[309],((C_word*)t0)[3],lf[322]);}

/* k12236 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("expand.scm: 1116 walk");
t3=((C_word*)((C_word*)t0)[3])[1];
f_11871(t3,((C_word*)t0)[2],t2,C_fix(0));}

/* simplify in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_12150(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12150,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12154,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1103 match-expression");
f_5953(t3,t2,lf[320],lf[321]);}

/* k12152 in simplify in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12154,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[314],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[311],t4);
C_trace("expand.scm: 1104 simplify");
t6=((C_word*)((C_word*)t0)[4])[1];
f_12150(t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1105 match-expression");
f_5953(t2,((C_word*)t0)[2],lf[318],lf[319]);}}

/* k12177 in k12152 in simplify in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12179,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[315],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_i_assq(lf[314],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
C_trace("##sys#append");
t8=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1112 match-expression");
f_5953(t2,((C_word*)t0)[2],lf[316],lf[317]);}}

/* k12223 in k12177 in k12152 in simplify in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[314],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k12208 in k12177 in k12152 in simplify in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12210,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[311],t2);
C_trace("expand.scm: 1109 simplify");
t4=((C_word*)((C_word*)t0)[3])[1];
f_12150(t4,((C_word*)t0)[2],t3);}

/* walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11881(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11881,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11899,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11903,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1069 vector->list");
t6=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=t3,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
C_trace("expand.scm: 1074 c");
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t4);}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4));}}}

/* k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11928,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11954,a[2]=t5,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
C_trace("expand.scm: 1080 walk");
t8=((C_word*)((C_word*)t0)[6])[1];
f_11871(t8,t6,t2,t7);}}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2));}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 1082 c");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k11973 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11975,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12000,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
C_trace("expand.scm: 1085 walk");
t7=((C_word*)((C_word*)t0)[5])[1];
f_11871(t7,t4,t5,t6);}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12023,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1087 walk");
t4=((C_word*)((C_word*)t0)[5])[1];
f_11871(t4,t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12122,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 1091 c");
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12136,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 1101 walk");
t3=((C_word*)((C_word*)t0)[5])[1];
f_11871(t3,t2,((C_word*)t0)[4],((C_word*)t0)[6]);}}}

/* k12134 in k11973 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12144,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1101 walk");
t3=((C_word*)((C_word*)t0)[4])[1];
f_11871(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12142 in k12134 in k11973 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12144,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[312],t3));}

/* k12120 in k11973 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12122,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12065,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1095 walk");
t6=((C_word*)((C_word*)t0)[4])[1];
f_11871(t6,t5,((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12096,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
C_trace("expand.scm: 1097 walk");
t7=((C_word*)((C_word*)t0)[4])[1];
f_11871(t7,t5,t3,t6);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12111,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 1099 walk");
t4=((C_word*)((C_word*)t0)[4])[1];
f_11871(t4,t3,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* k12109 in k12120 in k11973 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12119,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1099 walk");
t3=((C_word*)((C_word*)t0)[4])[1];
f_11871(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12117 in k12109 in k12120 in k11973 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12119,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[312],t3));}

/* k12094 in k12120 in k11973 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12096,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[313],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[311],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12084,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1098 walk");
t6=((C_word*)((C_word*)t0)[4])[1];
f_11871(t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12082 in k12094 in k12120 in k11973 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12084,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[312],t3));}

/* k12063 in k12120 in k11973 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12065,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[53],t3));}

/* k12021 in k11973 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12023,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[312],((C_word*)t0)[2],t1));}

/* k11998 in k11973 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_12000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12000,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[311],t3));}

/* k11952 in k11926 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11954,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[311],((C_word*)t0)[2],t1));}

/* k11901 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1069 walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_11871(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11897 in walk1 in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11899,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[310],t2));}

/* walk in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11871(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11871,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11879,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1066 walk1");
t5=((C_word*)((C_word*)t0)[2])[1];
f_11881(t5,t4,t2,t3);}

/* k11877 in walk in k11867 in k11864 in k11861 in k11858 in a11855 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1066 simplify");
t2=((C_word*)((C_word*)t0)[3])[1];
f_12150(t2,((C_word*)t0)[2],t1);}

/* k11852 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1057 ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[309],C_SCHEME_END_OF_LIST,t1);}

/* k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7635,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11821,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11823,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1121 ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11822 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11823,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11827,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1123 ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[306],t2,lf[308]);}

/* k11825 in a11822 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11827,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[113],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[307],t6));}

/* k11819 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1118 ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[306],C_SCHEME_END_OF_LIST,t1);}

/* k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7638,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11537,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11539,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1129 ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11539,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11546,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 1132 r");
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[214]);}

/* k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 1133 r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[305]);}

/* k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 1134 r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[222]);}

/* k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 1135 r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[104]);}

/* k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 1136 r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[234]);}

/* k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11560,a[2]=((C_word*)t0)[8],a[3]=((C_word)li174),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11570,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=t4,a[7]=t1,a[8]=((C_word)li175),tmp=(C_word)a,a+=9,tmp));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11720,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=((C_word)li177),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_11720(t9,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* expand in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11720(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11720,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11734,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11736,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11773,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t4,tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 1173 c");
t8=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t6,((C_word*)t0)[3]);}
else{
C_trace("expand.scm: 1171 err");
t6=((C_word*)t0)[2];
f_11560(t6,t1,t4);}}
else{
C_trace("expand.scm: 1166 err");
t4=((C_word*)t0)[2];
f_11560(t4,t1,t2);}}}

/* k11771 in expand in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11773,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[304]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11789,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11795,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 1178 test");
t3=((C_word*)((C_word*)t0)[3])[1];
f_11570(t3,t2,((C_word*)t0)[2]);}}

/* k11793 in k11771 in expand in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11795,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11802,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("##sys#append");
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
C_trace("expand.scm: 1179 expand");
t2=((C_word*)((C_word*)t0)[3])[1];
f_11720(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k11800 in k11793 in k11771 in expand in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11802,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11787 in k11771 in expand in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11789,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a11735 in expand in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11736,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k11732 in expand in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[25]+1),lf[303],t1);}

/* test in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11570(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11570,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
C_trace("expand.scm: 1142 ##sys#feature?");
t3=C_retrieve(lf[302]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11601,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
C_trace("expand.scm: 1147 c");
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],t3);}
else{
C_trace("expand.scm: 1143 err");
t3=((C_word*)t0)[5];
f_11560(t3,t1,t2);}}}

/* k11599 in test in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11601,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11619,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[11]);
C_trace("expand.scm: 1150 test");
t5=((C_word*)((C_word*)t0)[8])[1];
f_11570(t5,t3,t4);}
else{
C_trace("expand.scm: 1152 err");
t3=((C_word*)t0)[7];
f_11560(t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 1153 c");
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k11645 in k11599 in test in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11647,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11662,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("expand.scm: 1156 test");
t5=((C_word*)((C_word*)t0)[7])[1];
f_11570(t5,t3,t4);}
else{
C_trace("expand.scm: 1158 err");
t3=((C_word*)t0)[6];
f_11560(t3,((C_word*)t0)[9],((C_word*)t0)[5]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11697,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 1159 c");
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11695 in k11645 in k11599 in test in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11697,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11704,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("expand.scm: 1159 test");
t4=((C_word*)((C_word*)t0)[3])[1];
f_11570(t4,t2,t3);}
else{
C_trace("expand.scm: 1160 err");
t2=((C_word*)t0)[2];
f_11560(t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k11702 in k11695 in k11645 in k11599 in test in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k11660 in k11645 in k11599 in test in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11662,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11676,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("##sys#append");
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k11674 in k11660 in k11645 in k11599 in test in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11676,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("expand.scm: 1157 test");
t3=((C_word*)((C_word*)t0)[3])[1];
f_11570(t3,((C_word*)t0)[2],t2);}

/* k11617 in k11599 in test in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11619,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("##sys#append");
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11628 in k11617 in k11599 in test in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11630,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("expand.scm: 1151 test");
t3=((C_word*)((C_word*)t0)[3])[1];
f_11570(t3,((C_word*)t0)[2],t2);}

/* err in k11556 in k11553 in k11550 in k11547 in k11544 in a11538 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11560(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11560,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[300],((C_word*)t0)[2]);
C_trace("expand.scm: 1138 ##sys#error");
t4=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[301],t2,t3);}

/* k11535 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1126 ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[300],C_SCHEME_END_OF_LIST,t1);}

/* k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7641,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11516,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11518,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1184 ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11517 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11518,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[298],t7));}

/* k11514 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1181 ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[299],C_SCHEME_END_OF_LIST,t1);}

/* k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7644,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11495,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11497,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1192 ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11496 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11497,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[298],t7));}

/* k11493 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1189 ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[297],C_SCHEME_END_OF_LIST,t1);}

/* k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7647,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11444,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11446,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1200 ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11445 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11446,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11450,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 1202 ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[195],t2,lf[296]);}

/* k11448 in a11445 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11450,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11480,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11487,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1205 r");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[295]);}

/* k11485 in k11448 in a11445 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
C_trace("expand.scm: 1205 c");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k11478 in k11448 in a11445 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11480,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_TRUE:(C_word)C_i_caddr(((C_word*)t0)[4]));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
C_trace("##sys#append");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k11471 in k11478 in k11448 in a11445 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11473,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[294],t3));}

/* k11442 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1197 ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[195],C_SCHEME_END_OF_LIST,t1);}

/* k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7650,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11390,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11392,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1213 ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11391 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11392,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11396,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1215 ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[291],t2,lf[293]);}

/* k11394 in a11391 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1216 ##sys#current-module");
t3=C_retrieve(lf[71]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11397 in k11394 in a11391 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11436,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("##sys#append");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_11402(2,t3,C_SCHEME_FALSE);}}

/* k11434 in k11397 in k11394 in a11391 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11436,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[104],t1);
C_trace("expand.scm: 1217 ##sys#register-meta-expression");
t3=C_retrieve(lf[252]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k11400 in k11397 in k11394 in a11391 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11417,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1218 r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[104]);}

/* k11415 in k11400 in k11397 in k11394 in a11391 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11421,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("##sys#append");
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k11419 in k11415 in k11400 in k11397 in k11394 in a11391 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11421,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[292],t3));}

/* k11388 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1210 ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[291],C_SCHEME_END_OF_LIST,t1);}

/* k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7653,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11287,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11289,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1223 ##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11288 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11289,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11296,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1226 ##sys#current-module");
t7=C_retrieve(lf[71]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k11294 in a11288 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11299,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_11299(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("expand.scm: 1228 syntax-error");
t3=C_retrieve(lf[129]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[287],lf[290]);}}

/* k11297 in k11294 in a11288 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11319,a[2]=((C_word*)t0)[3],a[3]=((C_word)li168),tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t4=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11318 in k11297 in k11294 in a11288 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11319(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11319,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11326,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t3;
f_11326(t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11341,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
t5=t3;
f_11326(t5,f_11341(t2));}}

/* loop in a11318 in k11297 in k11294 in a11288 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_11341(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_TRUE);}}
else{
return(C_SCHEME_TRUE);}}}

/* k11324 in a11318 in k11297 in k11294 in a11288 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=f_9369(((C_word*)t0)[4]);
C_trace("expand.scm: 1237 syntax-error");
t3=C_retrieve(lf[129]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],lf[287],lf[289],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k11300 in k11297 in k11294 in a11288 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11305,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11309,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=f_9387(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11317,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[21]),((C_word*)t0)[2]);}

/* k11315 in k11300 in k11297 in k11294 in a11288 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1241 append");
t2=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11307 in k11300 in k11297 in k11294 in a11288 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[195]);
C_trace("##sys#block-set!");
t4=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(2),t1);}

/* k11303 in k11300 in k11297 in k11294 in a11288 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[288]);}

/* k11285 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1220 ##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[287],C_SCHEME_END_OF_LIST,t1);}

/* k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7656,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11250,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11252,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#er-transformer");
t5=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11251 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11252,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11256,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[283],t2,lf[286]);}

/* k11254 in a11251 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11256,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[5]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=lf[284];
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t7,a[6]=t9,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t4)[1]))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11274,a[2]=t10,a[3]=t7,a[4]=t4,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#check-syntax");
t12=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[283],((C_word*)t0)[5],lf[285]);}
else{
t11=t10;
f_11265(t11,C_SCHEME_UNDEFINED);}}

/* k11272 in k11254 in a11251 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_11265(t7,t6);}

/* k11263 in k11254 in a11251 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#process-syntax-rules");
t2=C_retrieve(lf[205]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11248 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#extend-macro-environment");
t2=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[283],C_SCHEME_END_OF_LIST,t1);}

/* k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7656,2,t0,t1);}
t2=C_mutate((C_word*)lf[205]+1 /* process-syntax-rules ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7658,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1253 ##sys#macro-environment");
t4=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9347,2,t0,t1);}
t2=C_mutate((C_word*)lf[236]+1 /* default-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11246,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1258 ##sys#macro-environment");
t5=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k11244 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1258 make-parameter");
t2=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9351,2,t0,t1);}
t2=C_mutate((C_word*)lf[176]+1 /* meta-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1259 make-parameter");
t4=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9355,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* current-module ...) */,t1);
t3=C_mutate(&lf[237] /* module? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9363,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[69] /* module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9369,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[238] /* module-export-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9387,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[239] /* set-module-defined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9396,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[240] /* module-defined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9405,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[241] /* module-exist-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9423,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[242] /* module-defined-syntax-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9441,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[243]+1 /* set-module-undefined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9450,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[244]+1 /* module-undefined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9459,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[198] /* module-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9477,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[197] /* module-meta-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9495,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[245] /* module-meta-expressions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9513,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[171] /* module-vexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9531,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[172] /* module-sexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9549,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[246] /* make-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9558,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[173]+1 /* find-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9564,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[251]+1 /* toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9604,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[252]+1 /* register-meta-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9607,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate(&lf[253] /* check-for-redef ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9627,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[256]+1 /* register-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9648,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[258]+1 /* register-syntax-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9737,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[70]+1 /* register-undefined ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9814,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[260]+1 /* register-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9836,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[194]+1 /* mark-imported-symbols ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9904,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate(&lf[261] /* module-indirect-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9951,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate(&lf[267] /* merge-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10227,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[268]+1 /* compiled-module-registration ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10287,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[269]+1 /* register-compiled-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10573,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[272]+1 /* register-primitive-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10693,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[257]+1 /* find-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10784,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[276]+1 /* finalize-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10869,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t34=C_set_block_item(lf[247] /* module-table */,0,C_SCHEME_END_OF_LIST);
t35=C_mutate((C_word*)lf[281]+1 /* macro-subset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11204,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,C_SCHEME_UNDEFINED);}

/* ##sys#macro-subset in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11204(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11204,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11212,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1587 ##sys#macro-environment");
t4=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11210 in ##sys#macro-subset in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11212,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11214,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li164),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11214(t5,((C_word*)t0)[2],t1);}

/* loop in k11210 in ##sys#macro-subset in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11214(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11214,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,((C_word*)t0)[3]));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11235,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
C_trace("expand.scm: 1590 loop");
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* k11233 in loop in k11210 in ##sys#macro-subset in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11235,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10869(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10869,3,t0,t1,t2);}
t3=f_9387(t2);
t4=f_9369(t2);
t5=f_9405(t2);
t6=f_9423(t2);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10885,a[2]=t4,a[3]=t5,a[4]=t3,a[5]=t6,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11189,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
t9=f_9441(t2);
C_trace("map");
t10=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}

/* a11188 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11189,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11197,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1514 ##sys#macro-environment");
t4=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11195 in a11188 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11127,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11146,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1520 ##sys#macro-environment");
t5=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k11144 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11146,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11148,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li161),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11148(t5,((C_word*)t0)[2],t1);}

/* loop in k11144 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11148(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11148,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11161,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11187,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1522 caar");
t5=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k11185 in loop in k11144 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1522 ##sys#find-export");
t2=C_retrieve(lf[257]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11159 in loop in k11144 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11161,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11172,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("expand.scm: 1523 loop");
t5=((C_word*)((C_word*)t0)[2])[1];
f_11148(t5,t3,t4);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("expand.scm: 1524 loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_11148(t3,((C_word*)t0)[3],t2);}}

/* k11170 in k11159 in loop in k11144 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11172,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a11126 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11127,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11139,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1518 ##sys#macro-environment");
t5=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k11137 in a11126 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10891,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[4]);
t4=(C_truep(t3)?((C_word*)t0)[5]:((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t1,a[6]=((C_word)li159),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_11003(t8,t2,t4);}

/* loop in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11003(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11003,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?t3:(C_word)C_i_car(t3));
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[5]))){
t6=(C_word)C_i_cdr(t2);
C_trace("expand.scm: 1532 loop");
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}
else{
t6=(C_word)C_i_assq(t5,((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11051,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11054,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_cdr(t6);
t10=t8;
f_11054(t10,(C_word)C_i_symbolp(t9));}
else{
t9=t8;
f_11054(t9,C_SCHEME_FALSE);}}}}

/* k11052 in loop in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11054(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11054,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11051(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 1539 ##sys#current-environment");
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k11101 in k11052 in loop in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11103,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_11066(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_11066(t4,C_SCHEME_FALSE);}}

/* k11064 in k11101 in k11052 in loop in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_11066(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11066,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[14]);
t3=((C_word*)t0)[6];
f_11051(2,t3,(C_word)C_i_cdr(((C_word*)t0)[5]));}
else{
if(C_truep(((C_word*)t0)[4])){
C_trace("expand.scm: 1550 ##sys#module-rename");
t2=C_retrieve(lf[65]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11085,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11089,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 1547 symbol->string");
t4=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}

/* k11087 in k11064 in k11101 in k11052 in loop in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1545 string-append");
t2=*((C_word*)lf[40]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[279],t1,lf[280]);}

/* k11083 in k11064 in k11101 in k11052 in loop in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1544 ##sys#warn");
t2=C_retrieve(lf[183]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11049 in loop in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11051,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11040,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("expand.scm: 1551 loop");
t5=((C_word*)((C_word*)t0)[2])[1];
f_11003(t5,t3,t4);}

/* k11038 in k11049 in loop in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_11040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11040,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10894,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10983,a[2]=((C_word*)t0)[2],a[3]=((C_word)li158),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10997,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1556 module-undefined-list");
t5=C_retrieve(lf[244]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}

/* k10995 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10982 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10983,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("expand.scm: 1555 ##sys#warn");
t3=C_retrieve(lf[183]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[278],t2);}}

/* k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10945,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10981,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1562 module-indirect-exports");
f_9951(t4,((C_word*)t0)[5]);}

/* k10979 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10944 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10945,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10973,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1560 ##sys#macro-environment");
t6=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}

/* k10971 in a10944 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("expand.scm: 1561 ##sys#error");
t4=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],lf[277],t3);}}

/* k10895 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10900,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10939,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1564 ##sys#macro-environment");
t4=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k10937 in k10895 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10943,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1565 ##sys#current-environment");
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10941 in k10937 in k10895 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10943,2,t0,t1);}
C_trace("expand.scm: 1563 merge-se");
f_10227(((C_word*)t0)[4],(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k10898 in k10895 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10903,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 1567 ##sys#mark-imported-symbols");
t3=C_retrieve(lf[194]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k10901 in k10898 in k10895 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10906,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10917,a[2]=((C_word*)t0)[3],a[3]=((C_word)li156),tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t4=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10916 in k10901 in k10898 in k10895 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10917,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10921,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(t2);
C_trace("expand.scm: 1570 merge-se");
f_10227(t3,(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[2]));}

/* k10919 in a10916 in k10901 in k10898 in k10895 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_retrieve(lf[14]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,t1));}

/* k10904 in k10901 in k10898 in k10895 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10906,2,t0,t1);}
t2=C_retrieve(lf[14]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[2];
t6=(C_word)C_i_check_structure(t4,lf[195]);
C_trace("##sys#block-set!");
t7=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,C_fix(10),t5);}

/* k10910 in k10904 in k10901 in k10898 in k10895 in k10892 in k10889 in k10886 in k10883 in ##sys#finalize-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[195]);
C_trace("##sys#block-set!");
t6=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(11),t4);}

/* ##sys#find-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10784,5,t0,t1,t2,t3,t4);}
t5=f_9387(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10795,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t5);
if(C_truep(t7)){
C_trace("expand.scm: 1500 module-exists-list");
t8=C_retrieve(lf[275]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t3);}
else{
t8=t6;
f_10795(2,t8,t5);}}

/* k10793 in ##sys#find-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10795,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10797,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li154),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_10797(t5,((C_word*)t0)[2],t1);}

/* loop in k10793 in ##sys#find-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_10797(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10797,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 1504 caar");
t7=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_i_cdr(t2);
C_trace("expand.scm: 1507 loop");
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}}

/* k10844 in loop in k10793 in ##sys#find-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10846,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10842,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1505 cdar");
t5=*((C_word*)lf[187]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t4=t3;
f_10825(t4,C_SCHEME_FALSE);}}}

/* k10840 in k10844 in loop in k10793 in ##sys#find-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_10825(t2,(C_word)C_i_memq(((C_word*)t0)[2],t1));}

/* k10823 in k10844 in loop in k10793 in ##sys#find-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_10825(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("expand.scm: 1506 loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_10797(t3,((C_word*)t0)[4],t2);}}

/* ##sys#register-primitive-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_10693r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10693r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10693r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10697,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_10697(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_10697(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k10695 in ##sys#register-primitive-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10700,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 1477 ##sys#macro-environment");
t3=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10698 in k10695 in ##sys#register-primitive-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10715,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10739,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10738 in k10698 in k10695 in ##sys#register-primitive-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10739,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10749,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10759,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
C_trace("expand.scm: 1484 ##sys#string-append");
t6=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[274],t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10757 in a10738 in k10698 in k10695 in ##sys#register-primitive-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1483 ##sys#string->symbol");
t2=C_retrieve(lf[66]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10747 in a10738 in k10698 in k10695 in ##sys#register-primitive-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10752,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1485 ##sys#put!");
t3=C_retrieve(lf[15]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[72],((C_word*)t0)[2]);}

/* k10750 in k10747 in a10738 in k10698 in k10695 in ##sys#register-primitive-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10752,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10713 in k10698 in k10695 in ##sys#register-primitive-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10719,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10721,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word)li151),tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10720 in k10713 in k10698 in k10695 in ##sys#register-primitive-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10721(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10721,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
C_trace("expand.scm: 1492 ##sys#error");
t4=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[273],t2,((C_word*)t0)[2]);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10717 in k10713 in k10698 in k10695 in ##sys#register-primitive-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10719,2,t0,t1);}
t2=f_9558(C_a_i(&a,13),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve(lf[247]));
t5=C_mutate((C_word*)lf[247]+1 /* module-table ...) */,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_10573,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10577,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10675,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t8=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t5);}

/* a10674 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10675,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10687,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
C_trace("expand.scm: 1450 ##sys#er-transformer");
t6=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k10685 in a10674 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10687,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10580,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10643,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10642 in k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10643,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10665,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_caddr(t2);
C_trace("expand.scm: 1455 ##sys#er-transformer");
t8=C_retrieve(lf[165]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k10663 in a10642 in k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10665,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10578 in k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10580,2,t0,t1);}
t2=f_9558(C_a_i(&a,13),((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10586,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 1460 ##sys#macro-environment");
t5=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k10635 in k10578 in k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 1461 ##sys#current-environment");
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10639 in k10635 in k10578 in k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10641,2,t0,t1);}
C_trace("expand.scm: 1459 merge-se");
f_10227(((C_word*)t0)[6],(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10584 in k10578 in k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 1463 ##sys#mark-imported-symbols");
t3=C_retrieve(lf[194]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k10587 in k10584 in k10578 in k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10625,a[2]=((C_word*)t0)[4],a[3]=((C_word)li147),tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t4=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10624 in k10587 in k10584 in k10578 in k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10625,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}

/* k10590 in k10587 in k10584 in k10578 in k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10595,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10605,a[2]=((C_word*)t0)[3],a[3]=((C_word)li146),tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t4=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10604 in k10590 in k10587 in k10584 in k10578 in k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10605,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_set_car(t4,((C_word*)t0)[2]));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k10593 in k10590 in k10587 in k10584 in k10578 in k10575 in ##sys#register-compiled-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10595,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[247]));
t4=C_mutate((C_word*)lf[247]+1 /* module-table ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10287,3,t0,t1,t2);}
t3=f_9405(t2);
t4=f_9369(t2);
t5=f_9477(t2);
t6=f_9495(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10307,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10571,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#append");
t9=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t5,C_SCHEME_END_OF_LIST);}
else{
t8=t7;
f_10307(t8,C_SCHEME_END_OF_LIST);}}

/* k10569 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10571,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[249],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[271],t5);
t7=((C_word*)t0)[2];
f_10307(t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_10307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10307,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10311,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10541,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#append");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_10315(t4,C_SCHEME_END_OF_LIST);}}

/* k10539 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10541,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[249],t1);
t3=((C_word*)t0)[2];
f_10315(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_10315(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10315,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10319,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10523,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=f_9513(((C_word*)t0)[4]);
C_trace("map");
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[21]),t5);}

/* k10521 in k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1428 reverse");
t2=*((C_word*)lf[80]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10321 in k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10323,2,t0,t1);}
t2=f_9369(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10436,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10438,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10511,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1436 module-indirect-exports");
f_9951(t8,((C_word*)t0)[5]);}

/* k10509 in k10321 in k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10437 in k10321 in k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[33],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10438,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[83],t7));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[83],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[152],t12));}}

/* k10434 in k10321 in k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10430 in k10321 in k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10432,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[152],t1);
t3=f_9531(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[83],t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10367,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10371,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li143),tmp=(C_word)a,a+=5,tmp);
t9=f_9549(((C_word*)t0)[7]);
C_trace("map");
t10=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}

/* a10372 in k10430 in k10321 in k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10373,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(t3,((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10383,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=t5;
f_10383(2,t6,C_SCHEME_UNDEFINED);}
else{
C_trace("expand.scm: 1443 error");
t6=*((C_word*)lf[248]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,lf[195],lf[270],t3,((C_word*)t0)[2]);}}

/* k10381 in a10372 in k10430 in k10321 in k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10383,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t4,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[223],t7));}

/* k10369 in k10430 in k10321 in k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10365 in k10430 in k10321 in k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10367,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[152],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[269],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t9=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k10317 in k10313 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10309 in k10305 in ##sys#compiled-module-registration in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* merge-se in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_10227(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10227,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10231,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,*((C_word*)lf[60]+1),t2);}

/* k10229 in merge-se in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10231,2,t0,t1);}
t2=C_retrieve(lf[14]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10237,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10242,a[2]=t5,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_10242(t7,t3,t1);}

/* loop in k10229 in merge-se in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_10242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10242,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10281,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1416 caar");
t4=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k10279 in loop in k10229 in merge-se in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10281,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(t1,t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("expand.scm: 1416 loop");
t4=((C_word*)((C_word*)t0)[3])[1];
f_10242(t4,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10273,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("expand.scm: 1417 loop");
t6=((C_word*)((C_word*)t0)[3])[1];
f_10242(t6,t4,t5);}}

/* k10271 in k10279 in loop in k10229 in merge-se in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10273,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10235 in k10229 in merge-se in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[14]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_9951(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9951,NULL,2,t1,t2);}
t3=f_9387(t2);
t4=f_9369(t2);
t5=f_9405(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10009,a[2]=t4,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t3);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10032,a[2]=t4,a[3]=t5,a[4]=t6,a[5]=t9,a[6]=((C_word)li139),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_10032(t11,t1,t3);}}

/* loop in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_10032(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10032,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_cdr(t2);
C_trace("expand.scm: 1385 loop");
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10059,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 1387 cdar");
t5=*((C_word*)lf[187]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}}

/* k10057 in loop in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10059,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li138),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_10061(t5,((C_word*)t0)[2],t1);}

/* loop2 in k10057 in loop in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_10061(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10061,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
C_trace("expand.scm: 1388 loop");
t4=((C_word*)((C_word*)t0)[6])[1];
f_10032(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 1389 ##sys#macro-environment");
t5=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k10219 in loop2 in k10057 in loop in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10221,2,t0,t1);}
if(C_truep((C_word)C_i_assq(((C_word*)t0)[8],t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10084,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
C_trace("expand.scm: 1390 warn");
t4=((C_word*)t0)[4];
f_10009(t4,t2,lf[264],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_cdr(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10127,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_10127(2,t7,t5);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[7]);
C_trace("expand.scm: 1397 ##sys#module-rename");
t8=C_retrieve(lf[65]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,((C_word*)t0)[2]);}}
else{
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10209,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 1399 ##sys#current-environment");
t6=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}}

/* k10207 in k10219 in loop2 in k10057 in loop in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10209,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10157,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("expand.scm: 1402 loop2");
t9=((C_word*)((C_word*)t0)[3])[1];
f_10061(t9,t7,t8);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10172,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("expand.scm: 1404 warn");
t6=((C_word*)t0)[2];
f_10009(t6,t4,lf[265],t5);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10190,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("expand.scm: 1407 warn");
t5=((C_word*)t0)[2];
f_10009(t5,t3,lf[266],t4);}}

/* k10188 in k10207 in k10219 in loop2 in k10057 in loop in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("expand.scm: 1408 loop2");
t3=((C_word*)((C_word*)t0)[3])[1];
f_10061(t3,((C_word*)t0)[2],t2);}

/* k10170 in k10207 in k10219 in loop2 in k10057 in loop in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("expand.scm: 1405 loop2");
t3=((C_word*)((C_word*)t0)[3])[1];
f_10061(t3,((C_word*)t0)[2],t2);}

/* k10155 in k10207 in k10219 in loop2 in k10057 in loop in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10157,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10125 in k10219 in loop2 in k10057 in loop in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10127,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10112,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("expand.scm: 1398 loop2");
t5=((C_word*)((C_word*)t0)[2])[1];
f_10061(t5,t3,t4);}

/* k10110 in k10125 in k10219 in loop2 in k10057 in loop in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10112,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10082 in k10219 in loop2 in k10057 in loop in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("expand.scm: 1391 loop2");
t3=((C_word*)((C_word*)t0)[3])[1];
f_10061(t3,((C_word*)t0)[2],t2);}

/* warn in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_10009(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10009,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10017,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10021,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1379 symbol->string");
t6=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k10019 in warn in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1379 string-append");
t2=*((C_word*)lf[40]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[262],t1,lf[263]);}

/* k10015 in warn in module-indirect-exports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_10017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1378 ##sys#warn");
t2=C_retrieve(lf[183]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#mark-imported-symbols in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9904,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9910,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t4=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a9909 in ##sys#mark-imported-symbols in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9910,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9917,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_eqp(t5,t6);
t8=t3;
f_9917(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_9917(t5,C_SCHEME_FALSE);}}

/* k9915 in a9909 in ##sys#mark-imported-symbols in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_9917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_retrieve(lf[14]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("expand.scm: 1364 ##sys#put!");
t4=C_retrieve(lf[15]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],t3,lf[73],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#register-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+69)){
C_save_and_reclaim((void*)tr4r,(void*)f_9836r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_9836r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9836r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(69);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9838,a[2]=t3,a[3]=t2,a[4]=((C_word)li132),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9851,a[2]=t5,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9856,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-vexports30823101");
t8=t1;
((C_proc2)C_retrieve_proc(t8))(2,t8,f_9856(C_a_i(&a,19),t7));}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("def-sexports30833097");
t10=t1;
((C_proc2)C_retrieve_proc(t10))(2,t10,f_9851(C_a_i(&a,19),t6,t8));}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("body30803089");
t12=t1;
((C_proc2)C_retrieve_proc(t12))(2,t12,f_9838(C_a_i(&a,19),t5,t8,t10));}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-vexports3082 in ##sys#register-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9856(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return(f_9851(C_a_i(&a,19),((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* def-sexports3083 in ##sys#register-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9851(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return(f_9838(C_a_i(&a,19),((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST));}

/* body3080 in ##sys#register-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9838(C_word *a,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t3=f_9558(C_a_i(&a,13),((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[247]));
t6=C_mutate((C_word*)lf[247]+1 /* module-table ...) */,t5);
return(t3);}

/* ##sys#register-undefined in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9814,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9821,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1350 module-undefined-list");
t5=C_retrieve(lf[244]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k9819 in ##sys#register-undefined in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9821,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("expand.scm: 1352 set-module-undefined-list!");
t3=C_retrieve(lf[243]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* ##sys#register-syntax-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9737,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=f_9387(t3);
t6=(C_word)C_eqp(C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9747,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9747(2,t8,t6);}
else{
C_trace("expand.scm: 1332 ##sys#find-export");
t8=C_retrieve(lf[257]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,t2,t3,C_SCHEME_TRUE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k9745 in ##sys#register-syntax-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9750,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 1333 module-undefined-list");
t3=C_retrieve(lf[244]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}

/* k9748 in k9745 in ##sys#register-syntax-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9750,2,t0,t1);}
t2=f_9369(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],t1))){
C_trace("expand.scm: 1336 ##sys#warn");
t4=C_retrieve(lf[183]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[259],((C_word*)t0)[5]);}
else{
t4=t3;
f_9756(2,t4,C_SCHEME_UNDEFINED);}}

/* k9754 in k9748 in k9745 in ##sys#register-syntax-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9795,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1337 ##sys#current-environment");
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9793 in k9754 in k9748 in k9745 in ##sys#register-syntax-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9799,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1337 ##sys#macro-environment");
t3=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9797 in k9793 in k9754 in k9748 in k9745 in ##sys#register-syntax-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1337 check-for-redef");
f_9627(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9757 in k9754 in k9748 in k9745 in ##sys#register-syntax-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9759,2,t0,t1);}
t2=C_retrieve(lf[14]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9765,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]);
t5=f_9405(((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
C_trace("expand.scm: 1340 set-module-defined-list!");
f_9396(t3,((C_word*)t0)[6],t6);}
else{
t4=t3;
f_9765(2,t4,C_SCHEME_UNDEFINED);}}

/* k9763 in k9757 in k9754 in k9748 in k9745 in ##sys#register-syntax-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9765,2,t0,t1);}
t2=f_9441(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[4];
t6=(C_word)C_i_check_structure(t5,lf[195]);
C_trace("##sys#block-set!");
t7=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,C_fix(5),t3);}

/* ##sys#register-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9648,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=f_9387(t3);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9658,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_9658(2,t7,t5);}
else{
C_trace("expand.scm: 1313 ##sys#find-export");
t7=C_retrieve(lf[257]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t2,t3,C_SCHEME_TRUE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k9656 in ##sys#register-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 1314 module-undefined-list");
t3=C_retrieve(lf[244]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k9659 in k9656 in ##sys#register-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9664,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9724,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=f_9369(((C_word*)t0)[3]);
C_trace("expand.scm: 1316 ##sys#module-rename");
t5=C_retrieve(lf[65]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[4],t4);}

/* k9722 in k9659 in k9656 in ##sys#register-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1315 ##sys#toplevel-definition-hook");
t2=C_retrieve(lf[251]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9662 in k9659 in k9656 in ##sys#register-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9667,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9720,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1319 ##sys#delq");
t4=C_retrieve(lf[186]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_9667(2,t3,C_SCHEME_UNDEFINED);}}

/* k9718 in k9662 in k9659 in k9656 in ##sys#register-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1319 set-module-undefined-list!");
t2=C_retrieve(lf[243]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9665 in k9662 in k9659 in k9656 in ##sys#register-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9706,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1320 ##sys#current-environment");
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9704 in k9665 in k9662 in k9659 in k9656 in ##sys#register-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9710,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 1320 ##sys#macro-environment");
t3=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9708 in k9704 in k9665 in k9662 in k9659 in k9656 in ##sys#register-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 1320 check-for-redef");
f_9627(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9668 in k9665 in k9662 in k9659 in k9656 in ##sys#register-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=f_9423(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
t6=(C_word)C_i_check_structure(t5,lf[195]);
C_trace("##sys#block-set!");
t7=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(4),t4);}

/* k9671 in k9668 in k9665 in k9662 in k9659 in k9656 in ##sys#register-export in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9673,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=C_retrieve(lf[14]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_FALSE);
t4=f_9405(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
C_trace("expand.scm: 1324 set-module-defined-list!");
f_9396(((C_word*)t0)[2],((C_word*)t0)[3],t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* check-for-redef in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_9627(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9627,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(t2,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9634,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
C_trace("expand.scm: 1306 ##sys#warn");
t7=C_retrieve(lf[183]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[255],t2);}
else{
t7=t6;
f_9634(2,t7,C_SCHEME_FALSE);}}

/* k9632 in check-for-redef in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
C_trace("expand.scm: 1308 ##sys#warn");
t2=C_retrieve(lf[183]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[254],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#register-meta-expression in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9607,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9611,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 1301 ##sys#current-module");
t4=C_retrieve(lf[71]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9609 in ##sys#register-meta-expression in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9611,2,t0,t1);}
if(C_truep(t1)){
t2=f_9513(t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_i_check_structure(t5,lf[195]);
C_trace("##sys#block-set!");
t7=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,C_fix(9),t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#toplevel-definition-hook in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9604,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}

/* ##sys#find-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9564(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_9564r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9564r(t0,t1,t2,t3);}}

static void C_ccall f_9564r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9568,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_9568(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_9568(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k9566 in ##sys#find-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[247]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
if(C_truep(t1)){
C_trace("expand.scm: 1295 error");
t3=*((C_word*)lf[248]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[249],lf[250],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* make-module in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9558(C_word *a,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_stack_check;
return((C_word)C_a_i_record(&a,12,lf[195],t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,t4));}

/* module-sexports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9549(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[195]);
return((C_word)C_i_block_ref(t1,C_fix(11)));}

/* module-vexports in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9531(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[195]);
return((C_word)C_i_block_ref(t1,C_fix(10)));}

/* module-meta-expressions in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9513(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[195]);
return((C_word)C_i_block_ref(t1,C_fix(9)));}

/* module-meta-import-forms in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9495(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[195]);
return((C_word)C_i_block_ref(t1,C_fix(8)));}

/* module-import-forms in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9477(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[195]);
return((C_word)C_i_block_ref(t1,C_fix(7)));}

/* module-undefined-list in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9459,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[195]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* set-module-undefined-list! in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9450,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[195]);
C_trace("##sys#block-set!");
t5=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* module-defined-syntax-list in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9441(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[195]);
return((C_word)C_i_block_ref(t1,C_fix(5)));}

/* module-exist-list in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9423(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[195]);
return((C_word)C_i_block_ref(t1,C_fix(4)));}

/* module-defined-list in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9405(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[195]);
return((C_word)C_i_block_ref(t1,C_fix(3)));}

/* set-module-defined-list! in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_9396(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9396,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[195]);
C_trace("##sys#block-set!");
t5=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* module-export-list in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9387(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[195]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* module-name in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_9369(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[195]);
return((C_word)C_i_block_ref(t1,C_fix(1)));}

/* module? in k9353 in k9349 in k9345 in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9363,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[195]));}

/* ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7658(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word ab[154],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7658,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_SCHEME_UNDEFINED;
t42=(*a=C_VECTOR_TYPE|1,a[1]=t41,tmp=(C_word)a,a+=2,tmp);
t43=C_SCHEME_UNDEFINED;
t44=(*a=C_VECTOR_TYPE|1,a[1]=t43,tmp=(C_word)a,a+=2,tmp);
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_SCHEME_UNDEFINED;
t56=(*a=C_VECTOR_TYPE|1,a[1]=t55,tmp=(C_word)a,a+=2,tmp);
t57=C_SCHEME_UNDEFINED;
t58=(*a=C_VECTOR_TYPE|1,a[1]=t57,tmp=(C_word)a,a+=2,tmp);
t59=C_SCHEME_UNDEFINED;
t60=(*a=C_VECTOR_TYPE|1,a[1]=t59,tmp=(C_word)a,a+=2,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_SCHEME_UNDEFINED;
t64=(*a=C_VECTOR_TYPE|1,a[1]=t63,tmp=(C_word)a,a+=2,tmp);
t65=C_SCHEME_UNDEFINED;
t66=(*a=C_VECTOR_TYPE|1,a[1]=t65,tmp=(C_word)a,a+=2,tmp);
t67=C_SCHEME_UNDEFINED;
t68=(*a=C_VECTOR_TYPE|1,a[1]=t67,tmp=(C_word)a,a+=2,tmp);
t69=C_SCHEME_UNDEFINED;
t70=(*a=C_VECTOR_TYPE|1,a[1]=t69,tmp=(C_word)a,a+=2,tmp);
t71=C_SCHEME_UNDEFINED;
t72=(*a=C_VECTOR_TYPE|1,a[1]=t71,tmp=(C_word)a,a+=2,tmp);
t73=C_SCHEME_UNDEFINED;
t74=(*a=C_VECTOR_TYPE|1,a[1]=t73,tmp=(C_word)a,a+=2,tmp);
t75=C_SCHEME_UNDEFINED;
t76=(*a=C_VECTOR_TYPE|1,a[1]=t75,tmp=(C_word)a,a+=2,tmp);
t77=C_SCHEME_UNDEFINED;
t78=(*a=C_VECTOR_TYPE|1,a[1]=t77,tmp=(C_word)a,a+=2,tmp);
t79=C_SCHEME_UNDEFINED;
t80=(*a=C_VECTOR_TYPE|1,a[1]=t79,tmp=(C_word)a,a+=2,tmp);
t81=C_SCHEME_UNDEFINED;
t82=(*a=C_VECTOR_TYPE|1,a[1]=t81,tmp=(C_word)a,a+=2,tmp);
t83=C_SCHEME_UNDEFINED;
t84=(*a=C_VECTOR_TYPE|1,a[1]=t83,tmp=(C_word)a,a+=2,tmp);
t85=C_SCHEME_UNDEFINED;
t86=(*a=C_VECTOR_TYPE|1,a[1]=t85,tmp=(C_word)a,a+=2,tmp);
t87=C_SCHEME_UNDEFINED;
t88=(*a=C_VECTOR_TYPE|1,a[1]=t87,tmp=(C_word)a,a+=2,tmp);
t89=C_SCHEME_UNDEFINED;
t90=(*a=C_VECTOR_TYPE|1,a[1]=t89,tmp=(C_word)a,a+=2,tmp);
t91=C_SCHEME_UNDEFINED;
t92=(*a=C_VECTOR_TYPE|1,a[1]=t91,tmp=(C_word)a,a+=2,tmp);
t93=C_SCHEME_UNDEFINED;
t94=(*a=C_VECTOR_TYPE|1,a[1]=t93,tmp=(C_word)a,a+=2,tmp);
t95=C_SCHEME_UNDEFINED;
t96=(*a=C_VECTOR_TYPE|1,a[1]=t95,tmp=(C_word)a,a+=2,tmp);
t97=C_SCHEME_UNDEFINED;
t98=(*a=C_VECTOR_TYPE|1,a[1]=t97,tmp=(C_word)a,a+=2,tmp);
t99=C_SCHEME_UNDEFINED;
t100=(*a=C_VECTOR_TYPE|1,a[1]=t99,tmp=(C_word)a,a+=2,tmp);
t101=C_SCHEME_UNDEFINED;
t102=(*a=C_VECTOR_TYPE|1,a[1]=t101,tmp=(C_word)a,a+=2,tmp);
t103=C_SCHEME_UNDEFINED;
t104=(*a=C_VECTOR_TYPE|1,a[1]=t103,tmp=(C_word)a,a+=2,tmp);
t105=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7663,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=t100,a[6]=t102,a[7]=t96,a[8]=t104,a[9]=t2,a[10]=t98,a[11]=t88,a[12]=t86,a[13]=t4,a[14]=t84,a[15]=t90,a[16]=t94,a[17]=t92,a[18]=t82,a[19]=t80,a[20]=t78,a[21]=t76,a[22]=t74,a[23]=t72,a[24]=t70,a[25]=t68,a[26]=t66,a[27]=t64,a[28]=t62,a[29]=t60,a[30]=t58,a[31]=t56,a[32]=t54,a[33]=t52,a[34]=t50,a[35]=t48,a[36]=t46,a[37]=t44,a[38]=t42,a[39]=t40,a[40]=t38,a[41]=t36,a[42]=t34,a[43]=t32,a[44]=t30,a[45]=t28,a[46]=t26,a[47]=t24,a[48]=t22,a[49]=t20,a[50]=t18,a[51]=t16,a[52]=t14,a[53]=t12,a[54]=t10,a[55]=t8,tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t106=t5;
((C_proc3)C_retrieve_proc(t106))(3,t106,t105,lf[60]);}

/* k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7663,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[55],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[235]);}

/* k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7667,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[55],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[234]);}

/* k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7671,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[55],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[233]);}

/* k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7675,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[55],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[109]);}

/* k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7679,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[55],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[232]);}

/* k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7683,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[55],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[231]);}

/* k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7687,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[55],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[230]);}

/* k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7691,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[55],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[24]);}

/* k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7695,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[55],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[23]);}

/* k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7699,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[55],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[229]);}

/* k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7703,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[55],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[228]);}

/* k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7707,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[55],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[227]);}

/* k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7711,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[55],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[226]);}

/* k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7715,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[55],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[225]);}

/* k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7719,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[55],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[224]);}

/* k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7723,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[55],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[223]);}

/* k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7727,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[55],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[222]);}

/* k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7731,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[55],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[221]);}

/* k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7735,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[55],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[220]);}

/* k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7739,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[55],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[219]);}

/* k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7743,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[55],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[218]);}

/* k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7747,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[55],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[113]);}

/* k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7751,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[55],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[49]);}

/* k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7755,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[55],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[101]);}

/* k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7759,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[55],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[217]);}

/* k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7763,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[55],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[152]);}

/* k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],a[55]=((C_word*)t0)[55],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[216]);}

/* k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7771,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[55],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[102]);}

/* k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7775,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[55],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[215]);}

/* k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7779,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[55],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[214]);}

/* k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7783,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[55],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[145]);}

/* k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7787,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[55],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[83]);}

/* k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7791,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[55],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[202]);}

/* k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7795,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[55],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],tmp=(C_word)a,a+=56,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[213]);}

/* k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7799,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7803,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[44],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[47],a[47]=((C_word*)t0)[55],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],tmp=(C_word)a,a+=55,tmp);
C_trace("r2358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[212]);}

/* k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[131],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7803,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[47]);
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7806,a[2]=((C_word*)t0)[42],a[3]=((C_word*)t0)[43],a[4]=((C_word*)t0)[53],a[5]=((C_word*)t0)[44],a[6]=((C_word*)t0)[45],a[7]=((C_word*)t0)[46],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[48],a[10]=((C_word*)t0)[49],a[11]=((C_word*)t0)[50],a[12]=((C_word*)t0)[51],a[13]=((C_word)li90),tmp=(C_word)a,a+=14,tmp));
t5=C_mutate(((C_word *)((C_word*)t0)[42])+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7900,a[2]=((C_word*)t0)[36],a[3]=((C_word*)t0)[47],a[4]=((C_word*)t0)[37],a[5]=((C_word*)t0)[38],a[6]=((C_word*)t0)[39],a[7]=((C_word*)t0)[40],a[8]=((C_word*)t0)[41],a[9]=((C_word)li92),tmp=(C_word)a,a+=10,tmp));
t6=C_mutate(((C_word *)((C_word*)t0)[36])+1,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_7984,a[2]=((C_word*)t0)[28],a[3]=((C_word*)t0)[29],a[4]=((C_word*)t0)[30],a[5]=((C_word*)t0)[31],a[6]=((C_word*)t0)[32],a[7]=((C_word*)t0)[36],a[8]=((C_word*)t0)[48],a[9]=((C_word*)t0)[45],a[10]=((C_word*)t0)[41],a[11]=((C_word*)t0)[33],a[12]=((C_word*)t0)[54],a[13]=((C_word*)t0)[34],a[14]=((C_word*)t0)[51],a[15]=((C_word*)t0)[50],a[16]=((C_word*)t0)[35],a[17]=((C_word)li93),tmp=(C_word)a,a+=18,tmp));
t7=C_mutate(((C_word *)((C_word*)t0)[34])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8205,a[2]=((C_word*)t0)[36],a[3]=((C_word*)t0)[32],a[4]=((C_word*)t0)[45],a[5]=((C_word*)t0)[23],a[6]=((C_word*)t0)[41],a[7]=((C_word*)t0)[24],a[8]=((C_word*)t0)[48],a[9]=((C_word*)t0)[33],a[10]=((C_word*)t0)[25],a[11]=((C_word*)t0)[26],a[12]=((C_word*)t0)[27],a[13]=((C_word)li94),tmp=(C_word)a,a+=14,tmp));
t8=C_mutate(((C_word *)((C_word*)t0)[31])+1,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8323,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[36],a[6]=((C_word*)t0)[18],a[7]=((C_word*)t0)[19],a[8]=((C_word*)t0)[24],a[9]=((C_word*)t0)[23],a[10]=((C_word*)t0)[20],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[45],a[13]=((C_word*)t0)[41],a[14]=((C_word*)t0)[22],a[15]=((C_word*)t0)[54],a[16]=((C_word)li96),tmp=(C_word)a,a+=17,tmp));
t9=C_mutate(((C_word *)((C_word*)t0)[37])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8611,a[2]=((C_word*)t0)[28],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[32],a[7]=((C_word*)t0)[48],a[8]=((C_word*)t0)[37],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[44],a[11]=((C_word*)t0)[54],a[12]=((C_word*)t0)[35],a[13]=((C_word)li99),tmp=(C_word)a,a+=14,tmp));
t10=C_mutate(((C_word *)((C_word*)t0)[39])+1,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8818,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[44],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[39],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[50],a[15]=((C_word)li101),tmp=(C_word)a,a+=16,tmp));
t11=C_mutate(((C_word *)((C_word*)t0)[38])+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9072,a[2]=((C_word*)t0)[28],a[3]=((C_word*)t0)[38],a[4]=((C_word*)t0)[35],a[5]=((C_word)li102),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9145,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate(((C_word *)((C_word*)t0)[28])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9238,a[2]=((C_word*)t0)[4],a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9260,a[2]=((C_word*)t0)[15],a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate(((C_word *)((C_word*)t0)[8])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9286,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp));
t16=C_mutate(((C_word *)((C_word*)t0)[11])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9306,a[2]=((C_word*)t0)[15],a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp));
C_trace("make-transformer2397");
t17=((C_word*)((C_word*)t0)[52])[1];
((C_proc3)C_retrieve_proc(t17))(3,t17,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_9306 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9306,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9316,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li107),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9316(t7,t1,t3);}

/* loop */
static void C_fcall f_9316(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9316,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9323,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_9323(t5,(C_word)C_eqp(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_9323(t4,C_SCHEME_FALSE);}}

/* k9321 in loop */
static void C_fcall f_9323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("loop2734");
t3=((C_word*)((C_word*)t0)[3])[1];
f_9316(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* f_9286 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9286,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9293,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("segment-template?2407");
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9291 */
static void C_ccall f_9293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9293,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9300,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("segment-depth2408");
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* k9298 in k9291 */
static void C_ccall f_9300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(1),t1));}

/* f_9260 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9260(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9260,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t4,((C_word*)t0)[2]));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_9238 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9238,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9245,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("segment-template?2407");
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9243 */
static void C_ccall f_9245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
C_trace("##sys#syntax-error-hook");
t4=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[211],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_9145 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9145,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9158,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,t5))){
t7=t6;
f_9158(t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_i_assq(t2,t4);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t7);
t9=t3;
t10=t6;
f_9158(t10,(C_word)C_fixnum_greater_or_equal_p(t8,t9));}
else{
t8=t6;
f_9158(t8,C_SCHEME_FALSE);}}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9187,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("segment-template?2407");
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}

/* k9185 */
static void C_ccall f_9187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9187,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
C_trace("free-meta-variables2405");
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
C_trace("free-meta-variables2405");
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("vector->list");
t3=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9234 in k9185 */
static void C_ccall f_9236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("free-meta-variables2405");
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9217 in k9185 */
static void C_ccall f_9219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("free-meta-variables2405");
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9196 in k9185 */
static void C_ccall f_9198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("free-meta-variables2405");
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9156 */
static void C_fcall f_9158(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9158,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]):((C_word*)t0)[2]));}

/* f_9072 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_9072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9072,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[4]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t4));}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9098,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("segment-pattern?2406");
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k9096 */
static void C_ccall f_9098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9098,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
C_trace("meta-variables2404");
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9126,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
C_trace("meta-variables2404");
t5=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("vector->list");
t3=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9141 in k9096 */
static void C_ccall f_9143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("meta-variables2404");
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9124 in k9096 */
static void C_ccall f_9126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("meta-variables2404");
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8818 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_8818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8818,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(C_word)C_i_assq(t2,t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
t7=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
C_trace("##sys#syntax-error-hook");
t8=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[209],t2);}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[208],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[14])[1],t8));}}
else{
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t4,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t2,a[15]=t1,a[16]=t3,tmp=(C_word)a,a+=17,tmp);
C_trace("segment-template?2407");
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8863 */
static void C_ccall f_8865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8865,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8868,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],tmp=(C_word)a,a+=13,tmp);
C_trace("segment-depth2408");
t3=((C_word*)((C_word*)t0)[5])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[14]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9026,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[14]);
C_trace("process-template2403");
t4=((C_word*)((C_word*)t0)[12])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[16],((C_word*)t0)[11]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[14]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9063,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[16],a[4]=t2,a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
C_trace("vector->list");
t4=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[14]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[14],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}}}}

/* k9061 in k8863 */
static void C_ccall f_9063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("process-template2403");
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9057 in k8863 */
static void C_ccall f_9059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9059,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k9024 in k8863 */
static void C_ccall f_9026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9034,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("process-template2403");
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9032 in k9024 in k8863 */
static void C_ccall f_9034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9034,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t3));}

/* k8866 in k8863 */
static void C_ccall f_8868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8868,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[12],t1);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8874,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("free-meta-variables2405");
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,t2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);}

/* k8872 in k8866 in k8863 */
static void C_ccall f_8874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8874,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
C_trace("##sys#syntax-error-hook");
t2=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[13],lf[210],((C_word*)t0)[12]);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
C_trace("process-template2403");
t4=((C_word*)((C_word*)t0)[10])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k8884 in k8872 in k8866 in k8863 */
static void C_ccall f_8886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8889,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
if(C_truep((C_word)C_i_symbolp(t1))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_8952(t6,(C_word)C_eqp(t1,t5));}
else{
t5=t3;
f_8952(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8952(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8952(t4,C_SCHEME_FALSE);}}

/* k8950 in k8884 in k8872 in k8866 in k8863 */
static void C_fcall f_8952(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8952,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8889(t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t6=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}

/* k8965 in k8950 in k8884 in k8872 in k8866 in k8863 */
static void C_ccall f_8967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8967,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_8889(t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k8887 in k8884 in k8872 in k8866 in k8863 */
static void C_fcall f_8889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8889,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8892,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8923,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_8923(t6,t2,((C_word*)t0)[2],t1);}

/* doloop2648 in k8887 in k8884 in k8872 in k8866 in k8863 */
static void C_fcall f_8923(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8923,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t11=t1;
t12=t6;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k8890 in k8887 in k8884 in k8872 in k8866 in k8863 */
static void C_ccall f_8892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("segment-tail2409");
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8919 in k8890 in k8887 in k8884 in k8872 in k8866 in k8863 */
static void C_ccall f_8921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8921,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8913,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8917,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("segment-tail2409");
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k8915 in k8919 in k8890 in k8887 in k8884 in k8872 in k8866 in k8863 */
static void C_ccall f_8917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("process-template2403");
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8911 in k8919 in k8890 in k8887 in k8884 in k8872 in k8866 in k8863 */
static void C_ccall f_8913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8913,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t3));}

/* f_8611 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_8611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8611,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[12]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8635,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("mapit2553");
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=t4,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
C_trace("segment-pattern?2406");
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8639 */
static void C_ccall f_8641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8641,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8650,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word)li97),tmp=(C_word)a,a+=8,tmp);
C_trace("process-pattern2402");
t4=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[7],t2,((C_word*)((C_word*)t0)[12])[1],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[14]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8701,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[14]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
C_trace("process-pattern2402");
t6=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[13]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[14]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8741,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(2)))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[14],t4);
t6=t3;
f_8741(t6,(C_word)C_eqp(t5,((C_word*)t0)[2]));}
else{
t4=t3;
f_8741(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}}}

/* k8739 in k8639 */
static void C_fcall f_8741(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8741,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8751,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
C_trace("vector->list");
t3=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8764,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[3],a[9]=((C_word)li98),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_8764(t5,((C_word*)t0)[6],C_fix(0));}}

/* lp in k8739 in k8639 */
static void C_fcall f_8764(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8764,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[8]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8778,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_vector_ref(((C_word*)t0)[6],t2);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
C_trace("process-pattern2402");
t9=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,((C_word*)t0)[2]);}}

/* k8776 in lp in k8739 in k8639 */
static void C_ccall f_8778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8782,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
C_trace("lp2590");
t4=((C_word*)((C_word*)t0)[2])[1];
f_8764(t4,t2,t3);}

/* k8780 in k8776 in lp in k8739 in k8639 */
static void C_ccall f_8782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("append");
t2=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8749 in k8739 in k8639 */
static void C_ccall f_8751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8751,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
C_trace("process-pattern2402");
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k8699 in k8639 */
static void C_ccall f_8701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8705,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
C_trace("process-pattern2402");
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[2]);}

/* k8703 in k8699 in k8639 */
static void C_ccall f_8705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("append");
t2=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8649 in k8639 */
static void C_ccall f_8650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8650,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8658,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],t2);
if(C_truep(t4)){
t5=t3;
f_8658(t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=t3;
f_8658(t11,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t10));}}

/* k8656 in a8649 in k8639 */
static void C_fcall f_8658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("mapit2553");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8633 */
static void C_ccall f_8635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8635,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t2));}

/* f_8323 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_8323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8323,4,t0,t1,t2,t3);}
t4=(C_word)C_i_vector_length(t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8330,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t4,a[13]=t1,a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t6=(C_word)C_fixnum_difference(t4,C_fix(1));
t7=(C_word)C_i_vector_ref(t3,t6);
t8=t5;
f_8330(t8,(C_word)C_eqp(t7,((C_word*)t0)[2]));}
else{
t6=t5;
f_8330(t6,C_SCHEME_FALSE);}}

/* k8328 */
static void C_fcall f_8330(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8330,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[16])[1],t5);
t7=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8369,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t4,a[16]=((C_word*)t0)[15],a[17]=t6,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t1)){
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_fixnum_difference(((C_word*)t0)[12],C_fix(2));
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=t7;
f_8369(t13,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t12));}
else{
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=t7;
f_8369(t12,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t11));}}

/* k8367 in k8328 */
static void C_fcall f_8369(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8369,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8373,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[17],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8377,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8379,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word)li95),tmp=(C_word)a,a+=17,tmp));
t7=((C_word*)t5)[1];
f_8379(t7,t3,C_fix(0));}

/* lp in k8367 in k8328 */
static void C_fcall f_8379(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8379,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[15]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t5=t2;
t6=(C_word)C_eqp(t5,t4);
t7=(C_truep(t6)?((C_word*)t0)[14]:C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t12);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8439,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t10,a[6]=((C_word*)t0)[10],a[7]=t13,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8443,a[2]=t14,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t17);
t19=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t20=(C_word)C_i_vector_ref(((C_word*)t0)[4],t19);
C_trace("process-match2399");
t21=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t21))(4,t21,t15,t18,t20);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8510,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t10);
t12=(C_word)C_i_vector_ref(((C_word*)t0)[4],t2);
C_trace("process-match2399");
t13=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t13))(4,t13,t8,t11,t12);}}}

/* k8508 in lp in k8367 in k8328 */
static void C_ccall f_8510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8514,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
C_trace("lp2524");
t4=((C_word*)((C_word*)t0)[2])[1];
f_8379(t4,t2,t3);}

/* k8512 in k8508 in lp in k8367 in k8328 */
static void C_ccall f_8514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("append");
t2=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8441 in lp in k8367 in k8328 */
static void C_ccall f_8443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8443,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t8=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k8437 in lp in k8367 in k8328 */
static void C_ccall f_8439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8439,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}

/* k8375 in k8367 in k8328 */
static void C_ccall f_8377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8371 in k8367 in k8328 */
static void C_ccall f_8373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8373,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST));}

/* f_8205 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_8205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8205,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8209,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
C_trace("process-match2399");
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t6,t3);}

/* k8207 */
static void C_ccall f_8209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[75],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8209,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t8,t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t6,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t4,t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t21);
t23=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,(C_word)C_a_i_cons(&a,2,t22,C_SCHEME_END_OF_LIST));}}

/* f_7984 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[40],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7984,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_symbolp(t3))){
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[16]))){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[208],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[15])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[14])[1],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}
else{
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
C_trace("segment-pattern?2406");
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k8032 */
static void C_ccall f_8034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8034,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[15]);
C_trace("process-segment-match2400");
t3=((C_word*)((C_word*)t0)[14])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[13],((C_word*)t0)[12],t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8082,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8086,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t9);
t11=(C_word)C_i_car(((C_word*)t0)[15]);
C_trace("process-match2399");
t12=((C_word*)((C_word*)t0)[6])[1];
((C_proc4)C_retrieve_proc(t12))(4,t12,t8,t10,t11);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[15]))){
C_trace("process-vector-match2401");
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[15]);}
else{
t2=(C_word)C_i_nullp(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8148(t4,t2);}
else{
t4=(C_word)C_booleanp(((C_word*)t0)[15]);
t5=t3;
f_8148(t5,(C_truep(t4)?t4:(C_word)C_charp(((C_word*)t0)[15])));}}}}}

/* k8146 in k8032 */
static void C_fcall f_8148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8148,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}}

/* k8084 in k8032 */
static void C_ccall f_8086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8090,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8094,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("process-match2399");
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t5,t6);}

/* k8092 in k8084 in k8032 */
static void C_ccall f_8094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8088 in k8084 in k8032 */
static void C_ccall f_8090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8080 in k8032 */
static void C_ccall f_8082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8082,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* f_7900 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7900,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=t3;
f_7907(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_7907(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_7907(t4,C_SCHEME_FALSE);}}

/* k7905 */
static void C_fcall f_7907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7907,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("cdar");
t3=*((C_word*)lf[187]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[10]);}
else{
C_trace("##sys#syntax-error-hook");
t2=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],lf[207],((C_word*)t0)[10]);}}

/* k7908 in k7905 */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7910,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7955,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7959,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("process-match2399");
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t1);}

/* k7957 in k7908 in k7905 */
static void C_ccall f_7959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7953 in k7908 in k7905 */
static void C_ccall f_7955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7955,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7936,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7950,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
C_trace("process-pattern2402");
t5=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],t4);}

/* a7949 in k7953 in k7908 in k7905 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7950,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7934 in k7953 in k7908 in k7905 */
static void C_ccall f_7936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7944,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7948,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("meta-variables2404");
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_SCHEME_END_OF_LIST);}

/* k7946 in k7934 in k7953 in k7908 in k7905 */
static void C_ccall f_7948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("process-template2403");
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k7942 in k7934 in k7953 in k7908 in k7905 */
static void C_ccall f_7944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7944,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* f_7806 in k7801 in k7797 in k7793 in k7789 in k7785 in k7781 in k7777 in k7773 in k7769 in k7765 in k7761 in k7757 in k7753 in k7749 in k7745 in k7741 in k7737 in k7733 in k7729 in k7725 in k7721 in k7717 in k7713 in k7709 in k7705 in k7701 in k7697 in k7693 in k7689 in k7685 in k7681 in k7677 in k7673 in k7669 in k7665 in k7661 in ##sys#process-syntax-rules in k7654 in k7651 in k7648 in k7645 in k7642 in k7639 in k7636 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7612 in k7609 in k7606 in k7603 in k7599 in k7596 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[38],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7806,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7846,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t10,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7850,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
C_trace("map");
t13=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)((C_word*)t0)[2])[1],t2);}

/* k7848 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7850,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[206],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t8=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k7844 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7846,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t7));}

/* ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6807(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6807,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6811,a[2]=t3,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=t6,a[7]=t1,a[8]=t4,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
C_trace("expand.scm: 724  r");
t10=t3;
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[203]);}

/* k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 725  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[202]);}

/* k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("expand.scm: 726  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[201]);}

/* k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6820,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
C_trace("expand.scm: 727  r");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[200]);}

/* k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6822,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6831,a[2]=((C_word*)t0)[11],a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6874,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6961,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[11],a[11]=t4,a[12]=((C_word)li85),tmp=(C_word)a,a+=13,tmp));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 824  ##sys#check-syntax");
t9=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[11],((C_word*)t0)[3],lf[199]);}

/* k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 825  ##sys#current-module");
t3=C_retrieve(lf[71]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7572,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9495(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("expand.scm: 831  append");
t6=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7587,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9477(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("expand.scm: 834  append");
t6=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}}
else{
t3=t2;
f_7425(2,t3,C_SCHEME_UNDEFINED);}}

/* k7585 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[195]);
C_trace("##sys#block-set!");
t4=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(7),t1);}

/* k7570 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[195]);
C_trace("##sys#block-set!");
t4=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(8),t1);}

/* k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7428,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li88),tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("for-each");
t5=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7430(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7430,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7434,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 837  import-spec");
t4=((C_word*)((C_word*)t0)[2])[1];
f_6961(t4,t3,t2);}

/* k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7434,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=C_retrieve(lf[14]);
t5=C_retrieve(lf[14]);
t6=C_retrieve(lf[14]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7452,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 843  ##sys#mark-imported-symbols");
t8=C_retrieve(lf[194]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7524,a[2]=((C_word*)t0)[3],a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t4=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7523 in k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7524,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7558,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 848  import-env");
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7556 in a7523 in k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(((C_word*)t0)[3],t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
C_trace("expand.scm: 850  ##sys#warn");
t5=C_retrieve(lf[183]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[2],lf[193],((C_word*)t0)[4]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7453 in k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7482,a[2]=((C_word*)t0)[6],a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
C_trace("for-each");
t4=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7481 in k7453 in k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7482,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7522,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 854  macro-env");
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7520 in a7481 in k7453 in k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("expand.scm: 856  ##sys#warn");
t7=C_retrieve(lf[183]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],lf[192],t6);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7456 in k7453 in k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7461,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7476,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7480,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 858  import-env");
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7478 in k7456 in k7453 in k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 858  append");
t2=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7474 in k7456 in k7453 in k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 858  import-env");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7459 in k7456 in k7453 in k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7468,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7472,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 859  macro-env");
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7470 in k7459 in k7456 in k7453 in k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 859  append");
t2=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7466 in k7459 in k7456 in k7453 in k7450 in k7432 in a7429 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 859  macro-env");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7426 in k7423 in k7420 in k7417 in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[191]);}

/* import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6961(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6961,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
C_trace("expand.scm: 757  import-name");
t3=((C_word*)t0)[11];
f_6874(t3,t1,t2);}
else{
t3=(C_word)C_i_listp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t4)){
t6=t5;
f_6980(t6,t4);}
else{
t6=(C_word)C_i_length(t2);
t7=t5;
f_6980(t7,(C_word)C_fixnum_lessp(t6,C_fix(2)));}}}

/* k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6980(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6980,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("expand.scm: 759  syntax-error");
t2=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[12],((C_word*)t0)[11],lf[180],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[10]);
C_trace("expand.scm: 762  import-spec");
t5=((C_word*)((C_word*)t0)[2])[1];
f_6961(t5,t3,t4);}}

/* k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6989,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("expand.scm: 765  c");
t6=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}

/* k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7001,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7004,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 766  ##sys#check-syntax");
t3=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[9],lf[181]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
C_trace("expand.scm: 777  c");
t4=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7081,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7084,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 778  ##sys#check-syntax");
t3=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[8],lf[182]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7188,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
C_trace("expand.scm: 788  c");
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7188,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7191,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 789  ##sys#check-syntax");
t3=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],lf[188]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7335,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
C_trace("expand.scm: 814  c");
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7333 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7335,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7338,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 815  ##sys#check-syntax");
t3=C_retrieve(lf[56]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[189]);}
else{
C_trace("expand.scm: 823  syntax-error");
t2=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[7],((C_word*)t0)[2],lf[190],((C_word*)t0)[4]);}}

/* k7336 in k7333 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7341,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
C_trace("expand.scm: 816  tostr");
t4=((C_word*)t0)[2];
f_6831(t4,t2,t3);}

/* k7339 in k7336 in k7333 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7343,a[2]=t1,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7374,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("map");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k7372 in k7339 in k7336 in k7333 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7378,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("map");
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7376 in k7372 in k7339 in k7336 in k7333 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7378,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ren in k7339 in k7336 in k7333 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7343,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7351,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7359,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7363,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
C_trace("expand.scm: 820  ##sys#symbol->string");
t7=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* k7361 in ren in k7339 in k7336 in k7333 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 820  ##sys#string-append");
t2=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7357 in ren in k7339 in k7336 in k7333 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 819  ##sys#string->symbol");
t2=C_retrieve(lf[66]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7349 in ren in k7339 in k7336 in k7333 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7351,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k7189 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7191,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7200,a[2]=t4,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7200(t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in k7189 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_7200(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7200,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7216,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7221,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t9=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7277,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t3,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 798  caar");
t8=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7329,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=t2,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 805  caar");
t8=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}}

/* k7327 in loop in k7189 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7329,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7310,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 808  cdar");
t6=*((C_word*)lf[187]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
C_trace("expand.scm: 811  loop");
t6=((C_word*)((C_word*)t0)[5])[1];
f_7200(t6,((C_word*)t0)[4],t3,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k7308 in k7327 in loop in k7189 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7310,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7298,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 810  ##sys#delq");
t5=C_retrieve(lf[186]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7296 in k7308 in k7327 in loop in k7189 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 807  loop");
t2=((C_word*)((C_word*)t0)[7])[1];
f_7200(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7275 in loop in k7189 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7277,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7258,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 802  cdar");
t6=*((C_word*)lf[187]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
C_trace("expand.scm: 804  loop");
t6=((C_word*)((C_word*)t0)[5])[1];
f_7200(t6,((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2],t5,((C_word*)t0)[8]);}}

/* k7256 in k7275 in loop in k7189 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7258,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7246,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 803  ##sys#delq");
t5=C_retrieve(lf[186]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7244 in k7256 in k7275 in loop in k7189 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 800  loop");
t2=((C_word*)((C_word*)t0)[7])[1];
f_7200(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7220 in loop in k7189 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7221,3,t0,t1,t2);}
C_trace("expand.scm: 795  ##sys#warn");
t3=C_retrieve(lf[183]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[184],t2);}

/* k7214 in loop in k7189 in k7186 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7216,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k7082 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7087,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
C_trace("map");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7085 in k7082 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7087,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7092,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li81),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7092(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k7085 in k7082 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_7092(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7092,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7104,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7104(t7,t1,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7178,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 786  caar");
t5=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7176 in loop in k7085 in k7082 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7178,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("expand.scm: 786  loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_7092(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
C_trace("expand.scm: 787  loop");
t5=((C_word*)((C_word*)t0)[4])[1];
f_7092(t5,((C_word*)t0)[3],t2,t4);}}

/* loop in loop in k7085 in k7082 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_7104(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7104,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7146,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 784  caar");
t5=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7144 in loop in loop in k7085 in k7082 in k7079 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7146,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("expand.scm: 784  loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_7104(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
C_trace("expand.scm: 785  loop");
t5=((C_word*)((C_word*)t0)[4])[1];
f_7104(t5,((C_word*)t0)[3],t2,t4);}}

/* k7002 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7007,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
C_trace("map");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7005 in k7002 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_7007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7007,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7012,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li79),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7012(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k7005 in k7002 in k6999 in k6987 in k6978 in import-spec in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_7012(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7012,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_assq(t5,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
C_trace("expand.scm: 772  loop");
t15=t1;
t16=t7;
t17=t8;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_assq(t7,((C_word*)t0)[2]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t8,t4);
C_trace("expand.scm: 775  loop");
t15=t1;
t16=t9;
t17=t3;
t18=t10;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
C_trace("expand.scm: 776  loop");
t15=t1;
t16=t9;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}}

/* import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6874(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6874,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6878,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 737  resolve");
t4=((C_word*)t0)[2];
f_6822(3,t4,t3,t2);}

/* k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6881,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 738  ##sys#find-module");
t3=C_retrieve(lf[173]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_SCHEME_FALSE);}

/* k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6881,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6884,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t3)[1])){
t5=t4;
f_6884(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6955,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6959,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 741  symbol->string");
t8=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[3]);}}

/* k6957 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 741  string-append");
t2=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[179]);}

/* k6953 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 740  ##sys#find-extension");
t2=C_retrieve(lf[178]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6896,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[71]);
t3=C_retrieve(lf[8]);
t4=C_retrieve(lf[9]);
t5=C_retrieve(lf[27]);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6902,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t3,a[8]=t4,a[9]=t5,a[10]=t9,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
C_trace("expand.scm: 745  ##sys#current-meta-environment");
t11=C_retrieve(lf[9]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}
else{
C_trace("expand.scm: 750  syntax-error");
t2=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[177],((C_word*)t0)[3]);}}

/* k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6902,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("expand.scm: 746  ##sys#meta-macro-environment");
t5=C_retrieve(lf[176]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6905,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6906,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word)li76),tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6944,a[2]=((C_word*)t0)[2],a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#dynamic-wind");
t7=*((C_word*)lf[175]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t4,t6,t4);}

/* a6943 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6944,2,t0,t1);}
C_trace("expand.scm: 747  ##sys#load");
t2=C_retrieve(lf[174]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k6936 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 748  ##sys#find-module");
t3=C_retrieve(lf[173]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6940 in k6936 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6884(2,t3,t2);}

/* swap1485 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("g148814891504");
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6908 in swap1485 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("g148814891504");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[10])[1]);}

/* k6911 in k6908 in swap1485 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6913,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("g149014911505");
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6915 in k6911 in k6908 in swap1485 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("g149014911505");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k6918 in k6915 in k6911 in k6908 in swap1485 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6920,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("g149214931506");
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6922 in k6918 in k6915 in k6911 in k6908 in swap1485 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("g149214931506");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k6925 in k6922 in k6918 in k6915 in k6911 in k6908 in swap1485 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6927,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("g149414951507");
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6929 in k6925 in k6922 in k6918 in k6915 in k6911 in k6908 in swap1485 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6934,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("g149414951507");
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k6932 in k6929 in k6925 in k6922 in k6918 in k6915 in k6911 in k6908 in swap1485 in k6903 in k6900 in k6894 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6882 in k6879 in k6876 in import-name in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6884,2,t0,t1);}
t2=f_9531(((C_word*)((C_word*)t0)[3])[1]);
t3=f_9549(((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* tostr in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6831(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6831,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6844,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 732  keyword?");
t4=C_retrieve(lf[132]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k6842 in tostr in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6844,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6851,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 732  ##sys#symbol->string");
t3=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
C_trace("expand.scm: 733  ##sys#symbol->string");
t2=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
C_trace("expand.scm: 734  number->string");
C_number_to_string(3,0,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
C_trace("expand.scm: 735  syntax-error");
t2=C_retrieve(lf[129]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[170]);}}}}

/* k6849 in k6842 in tostr in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 732  ##sys#string-append");
t2=C_retrieve(lf[167]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[168]);}

/* resolve in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6822,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6826,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 729  lookup");
f_3652(t3,t2,C_SCHEME_END_OF_LIST);}

/* k6824 in resolve in k6818 in k6815 in k6812 in k6809 in ##sys#expand-import in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##sys#er-transformer in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6615,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6617,a[2]=t2,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp));}

/* f_6617 in ##sys#er-transformer in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6617,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6620,a[2]=t3,a[3]=t6,a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6795,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6678,a[2]=t4,a[3]=t8,a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 718  handler");
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t1,t2,t7,t9);}

/* compare */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6678,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6682,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_symbolp(t2);
t6=(C_truep(t5)?(C_word)C_i_symbolp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6691,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 689  ##sys#get");
t8=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t2,lf[12]);}
else{
t7=t4;
f_6682(t7,(C_word)C_eqp(t2,t3));}}

/* k6689 in compare */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6694(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6781,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 690  lookup2");
f_6795(t3,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k6779 in k6689 in compare */
static void C_ccall f_6781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6694(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6692 in k6689 in compare */
static void C_fcall f_6694(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6694,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 692  ##sys#get");
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[12]);}

/* k6695 in k6692 in k6689 in compare */
static void C_ccall f_6697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6700,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6700(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6775,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 693  lookup2");
f_6795(t3,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6773 in k6695 in k6692 in k6689 in compare */
static void C_ccall f_6775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6700(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6698 in k6695 in k6692 in k6689 in compare */
static void C_fcall f_6700(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6700,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6719,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 697  ##sys#get");
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[72]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6746,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 699  ##sys#macro-environment");
t3=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}
else{
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 703  ##sys#macro-environment");
t3=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_6682(t2,(C_word)C_eqp(((C_word*)t0)[3],t1));}}}

/* k6767 in k6698 in k6695 in k6692 in k6689 in compare */
static void C_ccall f_6769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6682(t4,(C_word)C_eqp(((C_word*)t0)[2],t3));}
else{
t3=((C_word*)t0)[3];
f_6682(t3,C_SCHEME_FALSE);}}

/* k6744 in k6698 in k6695 in k6692 in k6689 in compare */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6682(t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[3];
f_6682(t3,C_SCHEME_FALSE);}}

/* k6717 in k6698 in k6695 in k6692 in k6689 in compare */
static void C_ccall f_6719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6719,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6726,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 698  ##sys#get");
t4=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],lf[72]);}

/* k6724 in k6717 in k6698 in k6695 in k6692 in k6689 in compare */
static void C_ccall f_6726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_6682(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k6680 in compare */
static void C_fcall f_6682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[14]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* lookup2 */
static void C_fcall f_6795(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6795,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6799,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 711  lookup");
f_3652(t4,t2,t3);}

/* k6797 in lookup2 */
static void C_ccall f_6799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[14]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* rename */
static void C_ccall f_6620(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6620,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=C_retrieve(lf[14]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cdr(t3));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 671  lookup");
f_3652(t4,t2,((C_word*)t0)[2]);}}

/* k6634 in rename */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6636,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=C_retrieve(lf[14]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6651,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 677  macro-alias");
f_3670(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 682  macro-alias");
f_3670(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6663 in k6634 in rename */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6665,2,t0,t1);}
t2=C_retrieve(lf[14]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k6649 in k6634 in rename */
static void C_ccall f_6651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6651,2,t0,t1);}
t2=C_retrieve(lf[14]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr5r,(void*)f_6153r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6153r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6153r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6155,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word)li65),tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6558,a[2]=t6,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6567,a[2]=t7,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
C_trace("def-culprit11081275");
t9=t8;
f_6567(t9,t1);}
else{
t9=(C_word)C_i_car(t5);
t10=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("def-se11091271");
t11=t7;
f_6558(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
C_trace("body11061115");
t13=t6;
f_6155(t13,t1,t9,t11);}
else{
C_trace("##sys#error");
t13=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-culprit1108 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6567,NULL,2,t0,t1);}
C_trace("def-se11091271");
t2=((C_word*)t0)[2];
f_6558(t2,t1,C_SCHEME_FALSE);}

/* def-se1109 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6558(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6558,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6566,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 583  ##sys#current-environment");
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6564 in def-se1109 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("body11061115");
t2=((C_word*)t0)[4];
f_6155(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6155(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6155,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6170,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word)li56),tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6158,a[2]=t4,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6201,a[2]=((C_word*)t0)[3],a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6257,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t3,a[6]=t6,a[7]=t7,a[8]=t5,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t9=C_mutate((C_word*)lf[126]+1 /* syntax-error-culprit ...) */,t2);
t10=t8;
f_6286(t10,t9);}
else{
t9=t8;
f_6286(t9,C_SCHEME_UNDEFINED);}}

/* k6284 in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6286(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6286,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],a[8]=((C_word)li64),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6291(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k6284 in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6291(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a;
loop:
a=C_alloc(19);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6291,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t3))){
t4=(C_word)C_i_vector_ref(t3,C_fix(0));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6310,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_eqp(t5,C_fix(1));
if(C_truep(t9)){
t10=t8;
f_6310(t10,C_fix(1));}
else{
t10=(C_word)C_fixnum_greaterp(t5,C_fix(2));
t11=t8;
f_6310(t11,(C_truep(t10)?(C_word)C_i_vector_ref(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_immp(t3))){
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
C_trace("expand.scm: 636  err");
t5=((C_word*)t0)[7];
f_6170(t5,t1,lf[142]);}}
else{
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t3;
t5=(C_word)C_eqp(t4,lf[143]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t4,lf[144]);
if(C_truep(t6)){
C_trace("expand.scm: 640  test");
t7=((C_word*)t0)[5];
f_6158(t7,t1,t2,*((C_word*)lf[145]+1),lf[146]);}
else{
t7=(C_word)C_eqp(t4,lf[147]);
if(C_truep(t7)){
C_trace("expand.scm: 641  test");
t8=((C_word*)t0)[5];
f_6158(t8,t1,t2,*((C_word*)lf[148]+1),lf[149]);}
else{
t8=(C_word)C_eqp(t4,lf[150]);
if(C_truep(t8)){
C_trace("expand.scm: 642  test");
t9=((C_word*)t0)[5];
f_6158(t9,t1,t2,*((C_word*)lf[148]+1),lf[151]);}
else{
t9=(C_word)C_eqp(t4,lf[152]);
if(C_truep(t9)){
C_trace("expand.scm: 643  test");
t10=((C_word*)t0)[5];
f_6158(t10,t1,t2,((C_word*)t0)[4],lf[153]);}
else{
t10=(C_word)C_eqp(t4,lf[154]);
if(C_truep(t10)){
C_trace("expand.scm: 644  test");
t11=((C_word*)t0)[5];
f_6158(t11,t1,t2,*((C_word*)lf[155]+1),lf[156]);}
else{
t11=(C_word)C_eqp(t4,lf[157]);
if(C_truep(t11)){
C_trace("expand.scm: 645  test");
t12=((C_word*)t0)[5];
f_6158(t12,t1,t2,*((C_word*)lf[158]+1),lf[159]);}
else{
t12=(C_word)C_eqp(t4,lf[160]);
if(C_truep(t12)){
C_trace("expand.scm: 646  test");
t13=((C_word*)t0)[5];
f_6158(t13,t1,t2,((C_word*)t0)[3],lf[161]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6488,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 648  test");
t14=((C_word*)t0)[5];
f_6158(t14,t1,t2,t13,lf[162]);}}}}}}}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6529,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
C_trace("expand.scm: 658  walk");
t26=t4;
t27=t5;
t28=t6;
t1=t26;
t2=t27;
t3=t28;
goto loop;}
else{
C_trace("expand.scm: 656  err");
t4=((C_word*)t0)[7];
f_6170(t4,t1,lf[163]);}}
else{
C_trace("expand.scm: 655  err");
t4=((C_word*)t0)[7];
f_6170(t4,t1,lf[164]);}}}}}

/* k6527 in walk in k6284 in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("expand.scm: 659  walk");
t4=((C_word*)((C_word*)t0)[3])[1];
f_6291(t4,((C_word*)t0)[2],t2,t3);}

/* a6487 in walk in k6284 in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6488,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6492,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
C_trace("expand.scm: 651  lookup");
f_3652(t3,t2,((C_word*)t0)[2]);}
else{
t4=t3;
f_6492(2,t4,C_SCHEME_FALSE);}}

/* k6490 in a6487 in walk in k6284 in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}

/* k6308 in walk in k6284 in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6310(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6310,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6315,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li62),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6315(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop1225 in k6308 in walk in k6284 in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6315(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6315,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
C_trace("expand.scm: 629  err");
t5=((C_word*)t0)[6];
f_6170(t5,t1,lf[139]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6334,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
C_trace("expand.scm: 631  err");
t6=((C_word*)t0)[6];
f_6170(t6,t5,lf[140]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
C_trace("expand.scm: 634  walk");
t7=((C_word*)((C_word*)t0)[3])[1];
f_6291(t7,t5,t6,((C_word*)t0)[2]);}
else{
C_trace("expand.scm: 633  err");
t6=((C_word*)t0)[6];
f_6170(t6,t5,lf[141]);}}}}

/* k6332 in doloop1225 in k6308 in walk in k6284 in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6315(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6263,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_6263(t2));}

/* loop in proper-list? in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static C_word C_fcall f_6263(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6201,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6205,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 598  ##sys#extended-lambda-list?");
t4=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6203 in lambda-list? in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6205,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6213,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6213(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k6203 in lambda-list? in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6213(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6213,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6233,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 601  keyword?");
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_cdr(t2);
C_trace("expand.scm: 605  loop");
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k6231 in loop in k6203 in lambda-list? in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6158(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6158,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6165,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 586  pred");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k6163 in test in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("expand.scm: 586  err");
t2=((C_word*)t0)[3];
f_6170(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6170(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6170,NULL,3,t0,t1,t2);}
t3=C_retrieve(lf[126]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 590  get-line-number");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6172 in err in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6181,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6188,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 593  symbol->string");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 594  symbol->string");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k6197 in k6172 in err in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 594  string-append");
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[137],t1,lf[138],((C_word*)t0)[2]);}

/* k6186 in k6172 in err in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6192,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 593  number->string");
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k6190 in k6186 in k6172 in err in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 593  string-append");
t2=((C_word*)t0)[5];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],lf[134],((C_word*)t0)[3],lf[135],t1,lf[136],((C_word*)t0)[2]);}

/* k6179 in k6172 in err in body1106 in ##sys#check-syntax in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 591  ##sys#syntax-error-hook");
t2=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6117,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[125]))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6139,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 572  ##sys#hash-table-ref");
t5=C_retrieve(lf[131]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[125]),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6137 in get-line-number in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6106r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6106r(t0,t1,t2);}}

static void C_ccall f_6106r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6114,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 563  ##sys#strip-syntax");
t4=C_retrieve(lf[21]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6112 in ##sys#syntax-error-hook in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],C_retrieve(lf[127]),lf[128],t1);}

/* ##sys#expand-curried-define in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6036,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6039,a[2]=t8,a[3]=t6,a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6099,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 552  loop");
t11=((C_word*)t8)[1];
f_6039(t11,t10,t2,t3);}

/* k6097 in ##sys#expand-curried-define in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6099,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_6039(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6039,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_i_cdr(t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6065,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t9=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6092,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#append");
t8=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t3,C_SCHEME_END_OF_LIST);}}

/* k6090 in loop in ##sys#expand-curried-define in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6092,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[85],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
C_trace("expand.scm: 551  loop");
t5=((C_word*)((C_word*)t0)[4])[1];
f_6039(t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k6063 in loop in ##sys#expand-curried-define in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6065,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[85],t2));}

/* match-expression in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5953(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5953,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5956,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6034,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 539  mwalk");
t11=((C_word*)t8)[1];
f_5956(t11,t10,t2,t3);}

/* k6032 in match-expression in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in match-expression in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5956(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5956,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6005,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
C_trace("expand.scm: 536  mwalk");
t13=t4;
t14=t5;
t15=t6;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_i_assq(t3,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t2,t5));}
else{
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[2]))){
t5=(C_word)C_a_i_cons(&a,2,t3,t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}}

/* k6003 in mwalk in match-expression in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_6005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
C_trace("expand.scm: 537  mwalk");
t4=((C_word*)((C_word*)t0)[3])[1];
f_5956(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5208r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5208r(t0,t1,t2,t3);}}

static void C_ccall f_5208r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5212,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("expand.scm: 413  ##sys#current-environment");
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5212(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5212,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t7,a[6]=((C_word)li43),tmp=(C_word)a,a+=7,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5466,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li45),tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5643,a[2]=t3,a[3]=t5,a[4]=t1,a[5]=((C_word)li48),tmp=(C_word)a,a+=6,tmp));
C_trace("expand.scm: 520  expand");
t11=((C_word*)t7)[1];
f_5643(t11,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5643(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5643,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5649(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5649(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5649,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_i_car(t7):C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5671,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t1,a[7]=t6,a[8]=t5,a[9]=t8,a[10]=((C_word*)t0)[4],a[11]=t4,a[12]=t3,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t10)){
if(C_truep((C_word)C_i_symbolp(t10))){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5913,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 480  lookup");
f_3652(t12,t10,((C_word*)t0)[5]);}
else{
t12=t11;
f_5671(t12,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5671(t12,C_SCHEME_FALSE);}}
else{
C_trace("expand.scm: 474  fini");
t7=((C_word*)((C_word*)t0)[2])[1];
f_5214(t7,t1,t3,t4,t5,t6,t2);}}

/* k5911 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5671(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5671,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(C_word)C_eqp(lf[105],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5689,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 483  ##sys#check-syntax");
t4=C_retrieve(lf[56]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[105],((C_word*)t0)[5],lf[120],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t3=(C_word)C_eqp(lf[111],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5815,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 505  ##sys#check-syntax");
t5=C_retrieve(lf[56]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[111],((C_word*)t0)[5],lf[121],((C_word*)t0)[13]);}
else{
t4=(C_word)C_eqp(lf[106],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5827,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
C_trace("expand.scm: 508  ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[106],((C_word*)t0)[5],lf[122],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t5=(C_word)C_eqp(lf[104],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5855,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("expand.scm: 511  ##sys#check-syntax");
t7=C_retrieve(lf[56]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t6,lf[104],((C_word*)t0)[5],lf[123],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t6=(C_word)C_i_memq(t1,((C_word*)t0)[12]);
t7=(C_truep(t6)?t6:(C_word)C_i_memq(t1,((C_word*)t0)[8]));
if(C_truep(t7)){
C_trace("expand.scm: 514  fini");
t8=((C_word*)((C_word*)t0)[2])[1];
f_5214(t8,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5881,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp);
C_trace("expand.scm: 516  ##sys#expand-0");
t9=C_retrieve(lf[36]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[5],((C_word*)t0)[13]);}}}}}}
else{
C_trace("expand.scm: 481  fini");
t2=((C_word*)((C_word*)t0)[2])[1];
f_5214(t2,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}}

/* k5879 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5881,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
C_trace("expand.scm: 518  fini");
t3=((C_word*)((C_word*)t0)[10])[1];
f_5214(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
C_trace("expand.scm: 519  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_5649(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k5853 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("expand.scm: 512  ##sys#append");
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k5860 in k5853 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 512  loop");
t2=((C_word*)((C_word*)t0)[7])[1];
f_5649(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5825 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5827,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
C_trace("expand.scm: 509  loop");
t6=((C_word*)((C_word*)t0)[6])[1];
f_5649(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k5813 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 506  fini/syntax");
t2=((C_word*)((C_word*)t0)[8])[1];
f_5466(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5687 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5689,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5694,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li46),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5694(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k5687 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5694(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5694,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5741,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 495  ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[105],t2,lf[116],C_SCHEME_FALSE,((C_word*)t0)[8]);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5763,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 499  ##sys#check-syntax");
t6=C_retrieve(lf[56]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[105],t2,lf[117],C_SCHEME_FALSE,((C_word*)t0)[8]);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 487  ##sys#check-syntax");
t5=C_retrieve(lf[56]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t4,lf[105],t2,lf[119],C_SCHEME_FALSE,((C_word*)t0)[8]);}}

/* k5705 in loop2 in k5687 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5707,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[8]):lf[118]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
C_trace("expand.scm: 488  loop");
t7=((C_word*)((C_word*)t0)[6])[1];
f_5649(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5761 in loop2 in k5687 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5763,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[2]);
C_trace("##sys#append");
t7=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k5788 in k5761 in loop2 in k5687 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5790,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[85],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
C_trace("expand.scm: 500  loop");
t5=((C_word*)((C_word*)t0)[7])[1];
f_5649(t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5739 in loop2 in k5687 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 496  macro-alias");
f_3670(t2,lf[105],((C_word*)t0)[2]);}

/* k5750 in k5739 in loop2 in k5687 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5756,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
C_trace("expand.scm: 497  ##sys#expand-curried-define");
t4=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5754 in k5750 in k5739 in loop2 in k5687 in k5669 in loop in expand in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5756,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
C_trace("expand.scm: 496  loop2");
t3=((C_word*)((C_word*)t0)[3])[1];
f_5694(t3,((C_word*)t0)[2],t2);}

/* fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5466(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5466,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5474,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5476,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li44),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5476(t11,t7,t6,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5476(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(19);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5476,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5491,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 455  macro-alias");
f_3670(t5,lf[110],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5522,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_length(t7);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_fix(3),t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5625,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 460  caar");
t10=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}
else{
t9=t5;
f_5522(t9,C_SCHEME_FALSE);}}
else{
t7=t5;
f_5522(t7,C_SCHEME_FALSE);}}
else{
C_trace("expand.scm: 457  loop");
t12=t1;
t13=t2;
t14=t3;
t15=C_SCHEME_TRUE;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}}

/* k5623 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5625,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5621,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 461  caar");
t4=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
f_5522(t2,C_SCHEME_FALSE);}}

/* k5619 in k5623 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 461  lookup");
f_3652(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5609 in k5623 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5614,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5614(2,t3,t1);}
else{
C_trace("expand.scm: 461  caar");
t3=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k5612 in k5609 in k5623 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5522(t2,(C_word)C_eqp(lf[111],t1));}

/* k5520 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5522,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5540,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 466  caadr");
t7=*((C_word*)lf[114]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=t4;
f_5540(t6,t2);}}
else{
C_trace("expand.scm: 470  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_5476(t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_TRUE);}}

/* k5552 in k5520 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 466  macro-alias");
f_3670(t2,lf[113],((C_word*)t0)[2]);}

/* k5564 in k5552 in k5520 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 466  cdadr");
t3=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5572 in k5564 in k5552 in k5520 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5578,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
C_trace("##sys#append");
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5576 in k5572 in k5564 in k5552 in k5520 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5578,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
f_5540(t6,(C_word)C_a_i_cons(&a,2,lf[111],t5));}

/* k5538 in k5520 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5540,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
C_trace("expand.scm: 463  loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_5476(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k5489 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5499,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5507,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 456  reverse");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5505 in k5489 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 456  map");
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[109]+1),t1);}

/* k5497 in k5489 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5501 in k5497 in k5489 in loop in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5503,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k5472 in fini/syntax in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 452  fini");
t2=((C_word*)((C_word*)t0)[7])[1];
f_5214(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5214(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5214,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5226,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li38),tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_5226(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5325,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
C_trace("expand.scm: 431  reverse");
t10=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}

/* k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5339,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5446,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5458,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[53]+1),t1,((C_word*)t0)[3]);}

/* k5456 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 434  ##sys#map");
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5445 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5446,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[108]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5343,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5428,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5444,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 436  reverse");
t6=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5442 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 436  map");
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5427 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5428,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[63],t5));}

/* k5345 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5351,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5361,a[2]=((C_word*)t0)[5],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5422,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 446  reverse");
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5420 in k5345 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5426,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 447  reverse");
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5424 in k5420 in k5345 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 437  map");
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5360 in k5345 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5361,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5365,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 438  ##sys#map");
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[16]),t2);}

/* k5363 in a5360 in k5345 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5365,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[85],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5392,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5396,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5398,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 443  map");
t8=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a5397 in k5363 in a5360 in k5345 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5398,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[63],t5));}

/* k5394 in k5363 in a5360 in k5345 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5390 in k5363 in a5360 in k5345 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5392,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[85],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[107],t5));}

/* k5353 in k5345 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5359,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5357 in k5353 in k5345 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5349 in k5345 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5341 in k5337 in k5323 in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5343,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[50],t2);
t4=C_retrieve(lf[14]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* loop in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5226(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5226,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5249,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5315,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 425  lookup");
f_3652(t7,t6,((C_word*)t0)[4]);}
else{
t7=t5;
f_5249(t7,C_SCHEME_FALSE);}}
else{
t6=t5;
f_5249(t6,C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5240,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 419  macro-alias");
f_3670(t4,lf[104],((C_word*)t0)[4]);}}

/* k5238 in loop in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5240,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5313 in loop in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5315,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[105]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_5249(t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 426  lookup");
f_3652(t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k5306 in k5313 in loop in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_5249(t3,(C_word)C_eqp(t2,lf[106]));}

/* k5247 in loop in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5249,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5256,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 428  macro-alias");
f_3670(t2,lf[104],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]);
C_trace("expand.scm: 430  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_5226(t4,((C_word*)t0)[9],t2,t3);}}

/* k5254 in k5247 in loop in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5260,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5264,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 429  reverse");
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5262 in k5254 in k5247 in loop in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5272,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 429  expand");
t3=((C_word*)((C_word*)t0)[3])[1];
f_5643(t3,t2,((C_word*)t0)[2]);}

/* k5270 in k5262 in k5254 in k5247 in loop in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5272,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("expand.scm: 429  ##sys#append");
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5258 in k5254 in k5247 in loop in fini in k5210 in ##sys#canonicalize-body in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5260,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4618,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4621,a[2]=t2,a[3]=t4,a[4]=((C_word)li34),tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4638,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t10,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
C_trace("expand.scm: 320  macro-alias");
f_3670(t11,lf[101],t5);}

/* k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("expand.scm: 322  macro-alias");
f_3670(t2,lf[100],((C_word*)t0)[4]);}

/* k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("expand.scm: 323  macro-alias");
f_3670(t2,lf[99],((C_word*)t0)[4]);}

/* k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("expand.scm: 324  macro-alias");
f_3670(t2,lf[98],((C_word*)t0)[4]);}

/* k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("expand.scm: 325  macro-alias");
f_3670(t2,lf[49],((C_word*)t0)[4]);}

/* k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4650,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word)li36),tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_4655(t5,((C_word*)t0)[3],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4655(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4655,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t5,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t4,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)((C_word*)t0)[13])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 333  reverse");
t9=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}
else{
C_trace("expand.scm: 333  reverse");
t8=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
C_trace("expand.scm: 361  err");
t7=((C_word*)t0)[4];
f_4621(t7,t1,lf[87]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4943,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[13])[1];
if(C_truep(t8)){
t9=t7;
f_4943(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t6);
t10=t7;
f_4943(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4966,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[3],a[11]=t2,a[12]=t6,a[13]=t7,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t7))){
C_trace("expand.scm: 370  lookup");
f_3652(t8,t7,((C_word*)t0)[2]);}
else{
t9=t8;
f_4966(2,t9,C_SCHEME_FALSE);}}
else{
C_trace("expand.scm: 367  err");
t7=((C_word*)t0)[4];
f_4621(t7,t1,lf[97]);}}}}

/* k4964 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[64],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[13]);
t3=(C_word)C_i_cdr(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t2,lf[78]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t6)){
t7=t5;
f_4981(t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5000,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 374  macro-alias");
f_3670(t7,lf[89],((C_word*)t0)[5]);}}
else{
t5=(C_word)C_eqp(t2,lf[77]);
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[11],C_fix(1)))){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[4],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_5018(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_5018(t7,C_SCHEME_FALSE);}}
else{
C_trace("expand.scm: 386  err");
t6=((C_word*)t0)[7];
f_4621(t6,((C_word*)t0)[9],lf[91]);}}
else{
t6=(C_word)C_eqp(t2,lf[79]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5064,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t8)){
t9=t7;
f_5064(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5083,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 388  macro-alias");
f_3670(t9,lf[89],((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t7=((C_word*)t0)[11];
switch(t7){
case C_fix(0):
t8=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
C_trace("expand.scm: 395  loop");
t9=((C_word*)((C_word*)t0)[10])[1];
f_4655(t9,((C_word*)t0)[9],C_fix(0),t8,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3);
case C_fix(1):
t8=(C_word)C_a_i_list(&a,2,t2,C_SCHEME_FALSE);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[3]);
C_trace("expand.scm: 396  loop");
t10=((C_word*)((C_word*)t0)[10])[1];
f_4655(t10,((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8],t9,C_SCHEME_END_OF_LIST,t3);
case C_fix(2):
C_trace("expand.scm: 397  err");
t8=((C_word*)t0)[7];
f_4621(t8,((C_word*)t0)[9],lf[93]);
default:
t8=(C_word)C_a_i_list(&a,1,t2);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[2]);
C_trace("expand.scm: 398  loop");
t10=((C_word*)((C_word*)t0)[10])[1];
f_4655(t10,((C_word*)t0)[9],C_fix(3),((C_word*)t0)[8],((C_word*)t0)[3],t9,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5145,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t8=(C_word)C_i_length(t2);
t9=t7;
f_5145(t9,(C_word)C_eqp(C_fix(2),t8));}
else{
t8=t7;
f_5145(t8,C_SCHEME_FALSE);}}}}}}

/* k5143 in k4964 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5145(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5145,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
C_trace("expand.scm: 401  err");
t3=((C_word*)t0)[9];
f_4621(t3,((C_word*)t0)[8],lf[94]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
C_trace("expand.scm: 402  loop");
t4=((C_word*)((C_word*)t0)[5])[1];
f_4655(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
C_trace("expand.scm: 403  err");
t3=((C_word*)t0)[9];
f_4621(t3,((C_word*)t0)[8],lf[95]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
C_trace("expand.scm: 404  loop");
t4=((C_word*)((C_word*)t0)[5])[1];
f_4655(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
C_trace("expand.scm: 405  err");
t2=((C_word*)t0)[9];
f_4621(t2,((C_word*)t0)[8],lf[96]);}}

/* k5081 in k4964 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5064(t3,t2);}

/* k5062 in k4964 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5064(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
C_trace("expand.scm: 390  loop");
t2=((C_word*)((C_word*)t0)[7])[1];
f_4655(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
C_trace("expand.scm: 391  err");
t2=((C_word*)t0)[2];
f_4621(t2,((C_word*)t0)[6],lf[92]);}}

/* k5016 in k4964 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5018(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5018,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_5021(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_5021(t6,t5);}}
else{
C_trace("expand.scm: 385  err");
t2=((C_word*)t0)[2];
f_4621(t2,((C_word*)t0)[6],lf[90]);}}

/* k5019 in k5016 in k4964 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_5021(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
C_trace("expand.scm: 384  loop");
t5=((C_word*)((C_word*)t0)[5])[1];
f_4655(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k4998 in k4964 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4981(t3,t2);}

/* k4979 in k4964 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4981(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
C_trace("expand.scm: 376  loop");
t3=((C_word*)((C_word*)t0)[6])[1];
f_4655(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
C_trace("expand.scm: 377  err");
t3=((C_word*)t0)[2];
f_4621(t3,((C_word*)t0)[5],lf[88]);}}

/* k4941 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4943(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
C_trace("expand.scm: 365  loop");
t3=((C_word*)((C_word*)t0)[5])[1];
f_4655(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k4920 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 333  ##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4673,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t3=t2;
f_4673(t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[11],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4915,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 345  reverse");
t6=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}

/* k4913 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4841 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4842,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4911,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
C_trace("expand.scm: 317  string->keyword");
t6=C_retrieve(lf[86]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k4909 in a4841 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4911,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[83],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4877,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4895,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("##sys#append");
t9=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t7=t5;
f_4877(t7,C_SCHEME_END_OF_LIST);}}

/* k4893 in k4909 in a4841 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4895,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[85],t2);
t4=((C_word*)t0)[2];
f_4877(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4875 in k4909 in a4841 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4877(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4871 in k4909 in a4841 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[84],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k4834 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4838 in k4834 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4840,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4673(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4671 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4673(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4673,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[10]))){
t3=t2;
f_4676(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t4)){
t5=t3;
f_4685(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[10]);
t6=t3;
f_4685(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_4685(t5,C_SCHEME_FALSE);}}}}

/* k4683 in k4671 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4685(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4685,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 350  caar");
t3=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[5]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4757,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 354  reverse");
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4780,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4788,a[2]=t4,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 357  reverse");
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}}

/* k4786 in k4683 in k4671 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4788,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
C_trace("expand.scm: 357  ##sys#append");
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4778 in k4683 in k4671 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4782 in k4778 in k4683 in k4671 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4784,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4676(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4755 in k4683 in k4671 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4761,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#append");
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4759 in k4755 in k4683 in k4671 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4761,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4676(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4710 in k4683 in k4671 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4732,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 350  cadar");
t3=*((C_word*)lf[82]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4730 in k4710 in k4683 in k4671 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4732,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t9=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4702 in k4730 in k4710 in k4683 in k4671 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4676(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4674 in k4671 in k4667 in loop in k4648 in k4645 in k4642 in k4639 in k4636 in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4676(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 332  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4621,NULL,3,t0,t1,t2);}
C_trace("expand.scm: 316  errh");
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4575,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4581,a[2]=t4,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4581(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4581(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4581,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[77]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4600,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4600(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[78]);
t7=t5;
f_4600(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[79])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4598 in loop in ##sys#extended-lambda-list? in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4600(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("expand.scm: 310  loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_4581(t3,((C_word*)t0)[4],t2);}}

/* ##sys#expand in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4522r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4522r(t0,t1,t2,t3);}}

static void C_ccall f_4522r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4526,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("expand.scm: 283  ##sys#current-environment");
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4526(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4524 in ##sys#expand in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4526,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4531,a[2]=t3,a[3]=t1,a[4]=((C_word)li30),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4531(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4524 in ##sys#expand in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4531(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4531,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4537,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4543,a[2]=((C_word*)t0)[2],a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t3,t4);}

/* a4542 in loop in k4524 in ##sys#expand in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4543,4,t0,t1,t2,t3);}
if(C_truep(t3)){
C_trace("expand.scm: 287  loop");
t4=((C_word*)((C_word*)t0)[2])[1];
f_4531(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a4536 in loop in k4524 in ##sys#expand in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
C_trace("expand.scm: 285  ##sys#expand-0");
t2=C_retrieve(lf[36]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#alias-global-hook in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4436,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4439,a[2]=t3,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4468,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 263  ##sys#qualified-symbol?");
t6=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k4466 in ##sys#alias-global-hook in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 264  ##sys#get");
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[72]);}}

/* k4469 in k4466 in ##sys#alias-global-hook in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4471,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[14]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 268  ##sys#get");
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[73]);}}

/* k4481 in k4469 in k4466 in ##sys#alias-global-hook in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4483,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[14]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 271  ##sys#current-environment");
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k4518 in k4481 in k4469 in k4466 in ##sys#alias-global-hook in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4520,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=C_retrieve(lf[14]);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
C_trace("expand.scm: 276  mrename");
t5=((C_word*)t0)[3];
f_4439(t5,((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4510,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 277  ##sys#get");
t6=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,lf[72]);}}
else{
C_trace("expand.scm: 278  mrename");
t3=((C_word*)t0)[3];
f_4439(t3,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k4508 in k4518 in k4481 in k4469 in k4466 in ##sys#alias-global-hook in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* mrename in ##sys#alias-global-hook in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4439(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4439,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 257  ##sys#current-module");
t4=C_retrieve(lf[71]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k4441 in mrename in ##sys#alias-global-hook in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4443,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[14]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=t3;
f_4452(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("expand.scm: 260  ##sys#register-undefined");
t4=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],t1);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k4450 in k4441 in mrename in ##sys#alias-global-hook in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_9369(((C_word*)t0)[4]);
C_trace("expand.scm: 261  ##sys#module-rename");
t3=C_retrieve(lf[65]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* ##sys#module-rename in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4418,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4426,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
C_trace("expand.scm: 250  string-append");
t7=*((C_word*)lf[40]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t4,t5,lf[67],t6);}

/* k4424 in ##sys#module-rename in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 249  ##sys#string->symbol");
t2=C_retrieve(lf[66]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4011,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4014,a[2]=t3,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4169,a[2]=t4,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4231,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t7,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
C_trace("expand.scm: 215  lookup");
f_3652(t8,t6,t3);}
else{
C_trace("expand.scm: 243  values");
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
C_trace("expand.scm: 244  values");
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4231,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[7]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4237,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=t5;
f_4237(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4402,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4409,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 217  ##sys#macro-environment");
t8=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}}

/* k4407 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 217  lookup");
f_3652(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4400 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4237(t4,t3);}

/* k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4237,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[49]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[50]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4246,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 219  ##sys#check-syntax");
t4=C_retrieve(lf[56]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[49],((C_word*)t0)[7],lf[58],C_SCHEME_FALSE,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t4,lf[61]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[63]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=t3;
f_4343(t6,(C_word)C_i_pairp(t5));}
else{
t5=t3;
f_4343(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4343(t5,C_SCHEME_FALSE);}}}

/* k4341 in k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4343(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4343,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 236  ##sys#check-syntax");
t4=C_retrieve(lf[56]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[61],((C_word*)t0)[8],lf[62],C_SCHEME_FALSE,((C_word*)t0)[6]);}
else{
C_trace("expand.scm: 242  expand");
t2=((C_word*)t0)[5];
f_4169(t2,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4347 in k4341 in k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4356,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[59],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
C_trace("expand.scm: 238  append");
t8=*((C_word*)lf[60]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t2,t5,t6,t7);}

/* k4354 in k4347 in k4341 in k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 237  values");
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k4244 in k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 222  ##sys#check-syntax");
t4=C_retrieve(lf[56]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[49],((C_word*)t0)[5],lf[57],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
C_trace("expand.scm: 231  values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4256 in k4244 in k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4258,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 226  macro-alias");
f_3670(t3,lf[55],((C_word*)t0)[2]);}

/* k4286 in k4256 in k4244 in k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4330,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a4329 in k4286 in k4256 in k4244 in k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4330,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k4318 in k4286 in k4256 in k4244 in k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4324,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
C_trace("##sys#append");
t4=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k4322 in k4318 in k4286 in k4256 in k4244 in k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4324,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[51],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[3],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4284,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 229  ##sys#map");
t12=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[54]+1),((C_word*)t0)[2]);}

/* k4282 in k4322 in k4318 in k4286 in k4256 in k4244 in k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4278 in k4322 in k4318 in k4286 in k4256 in k4244 in k4235 in k4229 in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4280,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[52],t2);
C_trace("expand.scm: 224  values");
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4169(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4169,NULL,5,t0,t1,t2,t3,t4);}
t5=C_retrieve(lf[14]);
if(C_truep((C_word)C_i_listp(t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4195,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cadr(t4);
t8=(C_word)C_i_car(t4);
C_trace("expand.scm: 208  call-handler");
t9=((C_word*)t0)[2];
f_4014(t9,t6,t2,t7,t3,t8);}
else{
C_trace("expand.scm: 210  values");
C_values(4,0,t1,t3,C_SCHEME_FALSE);}}
else{
C_trace("expand.scm: 204  ##sys#syntax-error-hook");
t6=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,lf[48],t3);}}

/* k4193 in expand in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 206  values");
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4014(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4014,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_retrieve(lf[14]);
t7=C_retrieve(lf[14]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4027,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4029,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=((C_word)li20),tmp=(C_word)a,a+=8,tmp);
C_trace("call-with-current-continuation");
t10=*((C_word*)lf[46]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t8,t9);}

/* a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4029,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4035,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4142,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li19),tmp=(C_word)a,a+=8,tmp);
C_trace("with-exception-handler");
t5=C_retrieve(lf[45]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4141 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li16),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4157,a[2]=((C_word*)t0)[2],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a4156 in a4141 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4157r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4157r(t0,t1,t2);}}

static void C_ccall f_4157r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4163,a[2]=t2,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
C_trace("k353358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4162 in a4156 in a4141 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4147 in a4141 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4152,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 190  handler");
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4150 in a4147 in a4141 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[14]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a4034 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4035,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
C_trace("k353358");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4040 in a4034 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4049,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[3],lf[38]))){
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=t3;
f_4052(t5,(C_word)C_i_memq(lf[44],t4));}
else{
t4=t3;
f_4052(t4,C_SCHEME_FALSE);}}

/* k4050 in a4040 in a4034 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4052(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4052,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4063,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4069,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4069(t8,t3,t4);}
else{
t2=((C_word*)t0)[3];
f_4049(t2,((C_word*)t0)[4]);}}

/* copy in k4050 in a4040 in a4034 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4069,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_equalp(lf[43],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=t5;
f_4088(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_4088(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_4088(t6,C_SCHEME_FALSE);}}}

/* k4086 in copy in k4050 in a4040 in a4034 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4088(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4088,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("expand.scm: 182  string-append");
t5=*((C_word*)lf[40]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[41],t3,lf[42],t4);}
else{
C_trace("expand.scm: 188  copy");
t2=((C_word*)((C_word*)t0)[2])[1];
f_4069(t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k4097 in k4086 in copy in k4050 in a4040 in a4034 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4099,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[39],t3));}

/* k4061 in k4050 in a4040 in a4034 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=((C_word*)t0)[3];
f_4049(t2,(C_word)C_a_i_record(&a,3,lf[38],((C_word*)t0)[2],t1));}

/* k4047 in a4040 in a4034 in a4028 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_4049(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 166  ##sys#abort");
t2=C_retrieve(lf[37]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4025 in call-handler in ##sys#expand-0 in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4002,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[35]);
C_trace("expand.scm: 154  ##sys#unregister-macro");
t4=C_retrieve(lf[33]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* ##sys#unregister-macro in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3951,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3959,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3963,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 147  ##sys#macro-environment");
t5=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3961 in ##sys#unregister-macro in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3963,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3965,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3965(t5,((C_word*)t0)[2],t1);}

/* loop in k3961 in ##sys#unregister-macro in k3843 in k3648 in k3644 in k3617 */
static void C_fcall f_3965(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3965,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 149  caar");
t4=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k3998 in loop in k3961 in ##sys#unregister-macro in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3992,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("expand.scm: 150  loop");
t6=((C_word*)((C_word*)t0)[2])[1];
f_3965(t6,t4,t5);}}

/* k3990 in k3998 in loop in k3961 in ##sys#unregister-macro in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3957 in ##sys#unregister-macro in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 145  ##sys#macro-environment");
t2=C_retrieve(lf[27]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* macro? in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3895r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3895r(t0,t1,t2,t3);}}

static void C_ccall f_3895r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3899,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("expand.scm: 136  ##sys#current-environment");
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3899(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3897 in macro? in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[3],lf[32]);
t3=(C_word)C_i_check_list_2(t1,lf[32]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 139  lookup");
f_3652(t4,((C_word*)t0)[3],t1);}

/* k3906 in k3897 in macro? in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3908,2,t0,t1);}
t2=(C_word)C_i_pairp(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 141  ##sys#macro-environment");
t5=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k3925 in k3906 in k3897 in macro? in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 141  lookup");
f_3652(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3915 in k3906 in k3897 in macro? in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE));}

/* ##sys#copy-macro in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3882,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3886,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3893,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 133  ##sys#macro-environment");
t6=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3891 in ##sys#copy-macro in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 133  lookup");
f_3652(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3884 in ##sys#copy-macro in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],C_retrieve(lf[30]),((C_word*)t0)[2],t1);}

/* ##sys#extend-macro-environment in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3849,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3853,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("expand.scm: 122  ##sys#macro-environment");
t6=C_retrieve(lf[27]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3851 in ##sys#extend-macro-environment in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3856,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("expand.scm: 123  lookup");
f_3652(t2,((C_word*)t0)[2],t1);}

/* k3854 in k3851 in ##sys#extend-macro-environment in k3843 in k3648 in k3644 in k3617 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3856,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_set_car(t1,((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(t1);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[4]));}
else{
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
C_trace("expand.scm: 128  ##sys#macro-environment");
t4=C_retrieve(lf[27]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}}

/* ##sys#strip-syntax in k3648 in k3644 in k3617 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3742r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3742r(t0,t1,t2,t3);}}

static void C_ccall f_3742r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3746,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3746(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3746(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[25]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3744 in ##sys#strip-syntax in k3648 in k3644 in k3617 */
static void C_ccall f_3746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3746,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3751,a[2]=t3,a[3]=t1,a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3751(3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k3744 in ##sys#strip-syntax in k3648 in k3644 in k3617 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(16);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3751,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3761,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("expand.scm: 100  lookup");
f_3652(t3,t2,((C_word*)t0)[3]);}
else{
C_trace("expand.scm: 101  get");
t4=C_retrieve(lf[22]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[12]);}}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
C_trace("expand.scm: 106  walk");
t9=t3;
t10=t4;
t1=t9;
t2=t10;
c=3;
goto loop;}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3817,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3821,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 109  vector->list");
t5=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}}

/* k3819 in walk in k3744 in ##sys#strip-syntax in k3648 in k3644 in k3617 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3815 in walk in k3744 in ##sys#strip-syntax in k3648 in k3644 in k3617 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("expand.scm: 109  list->vector");
t2=*((C_word*)lf[23]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3790 in walk in k3744 in ##sys#strip-syntax in k3648 in k3644 in k3617 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3796,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("expand.scm: 107  walk");
t4=((C_word*)((C_word*)t0)[2])[1];
f_3751(3,t4,t2,t3);}

/* k3794 in k3790 in walk in k3744 in ##sys#strip-syntax in k3648 in k3644 in k3617 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3796,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3759 in walk in k3744 in ##sys#strip-syntax in k3648 in k3644 in k3617 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_i_pairp(t1);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?((C_word*)t0)[2]:t1));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* map-se in k3648 in k3644 in k3617 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3712,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3718,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a3717 in map-se in k3648 in k3644 in k3617 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3718,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_symbolp(t4);
t6=(C_truep(t5)?(C_word)C_i_cdr(t2):lf[19]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t3,t6));}

/* macro-alias in k3648 in k3644 in k3617 */
static void C_fcall f_3670(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3670,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3677,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 75   ##sys#qualified-symbol?");
t5=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3675 in macro-alias in k3648 in k3644 in k3617 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3680(t3,t1);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(C_word)C_fixnum_greaterp(t4,C_fix(0));
t6=t2;
f_3680(t6,(C_truep(t5)?(C_word)C_eqp(C_make_character(35),(C_word)C_subchar(t3,C_fix(0))):C_SCHEME_FALSE));}}

/* k3678 in k3675 in macro-alias in k3648 in k3644 in k3617 */
static void C_fcall f_3680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3680,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 81   gensym");
t3=C_retrieve(lf[16]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3681 in k3678 in k3675 in macro-alias in k3648 in k3644 in k3617 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3686,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("expand.scm: 82   lookup");
f_3652(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k3684 in k3681 in k3678 in k3675 in macro-alias in k3648 in k3644 in k3617 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3692,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("expand.scm: 83   ##sys#put!");
t4=C_retrieve(lf[15]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[12],t2);}

/* k3690 in k3684 in k3681 in k3678 in k3675 in macro-alias in k3648 in k3644 in k3617 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[14]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* lookup in k3648 in k3644 in k3617 */
static void C_fcall f_3652(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3652,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cdr(t4));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3665,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("expand.scm: 71   ##sys#get");
t6=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[12]);}}

/* k3663 in lookup in k3648 in k3644 in k3617 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:C_SCHEME_FALSE));}

/* d in k3617 */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3621r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3621r(t0,t1,t2,t3);}}

static void C_ccall f_3621r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_fudge(C_fix(13)))){
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("expand.scm: 43   pp");
t4=C_retrieve(lf[4]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}
else{
C_apply(5,0,t1,*((C_word*)lf[5]+1),t2,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[839] = {
{"toplevelexpand.scm",(void*)C_expand_toplevel},
{"f_3619expand.scm",(void*)f_3619},
{"f_3646expand.scm",(void*)f_3646},
{"f_3650expand.scm",(void*)f_3650},
{"f_3845expand.scm",(void*)f_3845},
{"f_13395expand.scm",(void*)f_13395},
{"f_13393expand.scm",(void*)f_13393},
{"f_7598expand.scm",(void*)f_7598},
{"f_13385expand.scm",(void*)f_13385},
{"f_13383expand.scm",(void*)f_13383},
{"f_7601expand.scm",(void*)f_7601},
{"f_7605expand.scm",(void*)f_7605},
{"f_13243expand.scm",(void*)f_13243},
{"f_13253expand.scm",(void*)f_13253},
{"f_13269expand.scm",(void*)f_13269},
{"f_13272expand.scm",(void*)f_13272},
{"f_13300expand.scm",(void*)f_13300},
{"f_13275expand.scm",(void*)f_13275},
{"f_13322expand.scm",(void*)f_13322},
{"f_13325expand.scm",(void*)f_13325},
{"f_13371expand.scm",(void*)f_13371},
{"f_13328expand.scm",(void*)f_13328},
{"f_13351expand.scm",(void*)f_13351},
{"f_13363expand.scm",(void*)f_13363},
{"f_13309expand.scm",(void*)f_13309},
{"f_13312expand.scm",(void*)f_13312},
{"f_13319expand.scm",(void*)f_13319},
{"f_13241expand.scm",(void*)f_13241},
{"f_7608expand.scm",(void*)f_7608},
{"f_13184expand.scm",(void*)f_13184},
{"f_13213expand.scm",(void*)f_13213},
{"f_13233expand.scm",(void*)f_13233},
{"f_13237expand.scm",(void*)f_13237},
{"f_13182expand.scm",(void*)f_13182},
{"f_7611expand.scm",(void*)f_7611},
{"f_13094expand.scm",(void*)f_13094},
{"f_13119expand.scm",(void*)f_13119},
{"f_13126expand.scm",(void*)f_13126},
{"f_13146expand.scm",(void*)f_13146},
{"f_13166expand.scm",(void*)f_13166},
{"f_13170expand.scm",(void*)f_13170},
{"f_13092expand.scm",(void*)f_13092},
{"f_7614expand.scm",(void*)f_7614},
{"f_12761expand.scm",(void*)f_12761},
{"f_12768expand.scm",(void*)f_12768},
{"f_12771expand.scm",(void*)f_12771},
{"f_12774expand.scm",(void*)f_12774},
{"f_12777expand.scm",(void*)f_12777},
{"f_12780expand.scm",(void*)f_12780},
{"f_12783expand.scm",(void*)f_12783},
{"f_12786expand.scm",(void*)f_12786},
{"f_12791expand.scm",(void*)f_12791},
{"f_12807expand.scm",(void*)f_12807},
{"f_12813expand.scm",(void*)f_12813},
{"f_12855expand.scm",(void*)f_12855},
{"f_12923expand.scm",(void*)f_12923},
{"f_13048expand.scm",(void*)f_13048},
{"f_13044expand.scm",(void*)f_13044},
{"f_12926expand.scm",(void*)f_12926},
{"f_12981expand.scm",(void*)f_12981},
{"f_12858expand.scm",(void*)f_12858},
{"f_12897expand.scm",(void*)f_12897},
{"f_12849expand.scm",(void*)f_12849},
{"f_12820expand.scm",(void*)f_12820},
{"f_12759expand.scm",(void*)f_12759},
{"f_7617expand.scm",(void*)f_7617},
{"f_12588expand.scm",(void*)f_12588},
{"f_12592expand.scm",(void*)f_12592},
{"f_12601expand.scm",(void*)f_12601},
{"f_12604expand.scm",(void*)f_12604},
{"f_12607expand.scm",(void*)f_12607},
{"f_12610expand.scm",(void*)f_12610},
{"f_12613expand.scm",(void*)f_12613},
{"f_12616expand.scm",(void*)f_12616},
{"f_12637expand.scm",(void*)f_12637},
{"f_12653expand.scm",(void*)f_12653},
{"f_12659expand.scm",(void*)f_12659},
{"f_12715expand.scm",(void*)f_12715},
{"f_12713expand.scm",(void*)f_12713},
{"f_12709expand.scm",(void*)f_12709},
{"f_12701expand.scm",(void*)f_12701},
{"f_12697expand.scm",(void*)f_12697},
{"f_12666expand.scm",(void*)f_12666},
{"f_12635expand.scm",(void*)f_12635},
{"f_12586expand.scm",(void*)f_12586},
{"f_7620expand.scm",(void*)f_7620},
{"f_12519expand.scm",(void*)f_12519},
{"f_12523expand.scm",(void*)f_12523},
{"f_12532expand.scm",(void*)f_12532},
{"f_12537expand.scm",(void*)f_12537},
{"f_12574expand.scm",(void*)f_12574},
{"f_12555expand.scm",(void*)f_12555},
{"f_12517expand.scm",(void*)f_12517},
{"f_7623expand.scm",(void*)f_7623},
{"f_12433expand.scm",(void*)f_12433},
{"f_12437expand.scm",(void*)f_12437},
{"f_12446expand.scm",(void*)f_12446},
{"f_12505expand.scm",(void*)f_12505},
{"f_12457expand.scm",(void*)f_12457},
{"f_12483expand.scm",(void*)f_12483},
{"f_12465expand.scm",(void*)f_12465},
{"f_12481expand.scm",(void*)f_12481},
{"f_12461expand.scm",(void*)f_12461},
{"f_12431expand.scm",(void*)f_12431},
{"f_7626expand.scm",(void*)f_7626},
{"f_12251expand.scm",(void*)f_12251},
{"f_12255expand.scm",(void*)f_12255},
{"f_12267expand.scm",(void*)f_12267},
{"f_12270expand.scm",(void*)f_12270},
{"f_12273expand.scm",(void*)f_12273},
{"f_12276expand.scm",(void*)f_12276},
{"f_12411expand.scm",(void*)f_12411},
{"f_12291expand.scm",(void*)f_12291},
{"f_12409expand.scm",(void*)f_12409},
{"f_12318expand.scm",(void*)f_12318},
{"f_12399expand.scm",(void*)f_12399},
{"f_12334expand.scm",(void*)f_12334},
{"f_12356expand.scm",(void*)f_12356},
{"f_12354expand.scm",(void*)f_12354},
{"f_12350expand.scm",(void*)f_12350},
{"f_12249expand.scm",(void*)f_12249},
{"f_7629expand.scm",(void*)f_7629},
{"f_11856expand.scm",(void*)f_11856},
{"f_11860expand.scm",(void*)f_11860},
{"f_11863expand.scm",(void*)f_11863},
{"f_11866expand.scm",(void*)f_11866},
{"f_11869expand.scm",(void*)f_11869},
{"f_12238expand.scm",(void*)f_12238},
{"f_12150expand.scm",(void*)f_12150},
{"f_12154expand.scm",(void*)f_12154},
{"f_12179expand.scm",(void*)f_12179},
{"f_12225expand.scm",(void*)f_12225},
{"f_12210expand.scm",(void*)f_12210},
{"f_11881expand.scm",(void*)f_11881},
{"f_11928expand.scm",(void*)f_11928},
{"f_11975expand.scm",(void*)f_11975},
{"f_12136expand.scm",(void*)f_12136},
{"f_12144expand.scm",(void*)f_12144},
{"f_12122expand.scm",(void*)f_12122},
{"f_12111expand.scm",(void*)f_12111},
{"f_12119expand.scm",(void*)f_12119},
{"f_12096expand.scm",(void*)f_12096},
{"f_12084expand.scm",(void*)f_12084},
{"f_12065expand.scm",(void*)f_12065},
{"f_12023expand.scm",(void*)f_12023},
{"f_12000expand.scm",(void*)f_12000},
{"f_11954expand.scm",(void*)f_11954},
{"f_11903expand.scm",(void*)f_11903},
{"f_11899expand.scm",(void*)f_11899},
{"f_11871expand.scm",(void*)f_11871},
{"f_11879expand.scm",(void*)f_11879},
{"f_11854expand.scm",(void*)f_11854},
{"f_7632expand.scm",(void*)f_7632},
{"f_11823expand.scm",(void*)f_11823},
{"f_11827expand.scm",(void*)f_11827},
{"f_11821expand.scm",(void*)f_11821},
{"f_7635expand.scm",(void*)f_7635},
{"f_11539expand.scm",(void*)f_11539},
{"f_11546expand.scm",(void*)f_11546},
{"f_11549expand.scm",(void*)f_11549},
{"f_11552expand.scm",(void*)f_11552},
{"f_11555expand.scm",(void*)f_11555},
{"f_11558expand.scm",(void*)f_11558},
{"f_11720expand.scm",(void*)f_11720},
{"f_11773expand.scm",(void*)f_11773},
{"f_11795expand.scm",(void*)f_11795},
{"f_11802expand.scm",(void*)f_11802},
{"f_11789expand.scm",(void*)f_11789},
{"f_11736expand.scm",(void*)f_11736},
{"f_11734expand.scm",(void*)f_11734},
{"f_11570expand.scm",(void*)f_11570},
{"f_11601expand.scm",(void*)f_11601},
{"f_11647expand.scm",(void*)f_11647},
{"f_11697expand.scm",(void*)f_11697},
{"f_11704expand.scm",(void*)f_11704},
{"f_11662expand.scm",(void*)f_11662},
{"f_11676expand.scm",(void*)f_11676},
{"f_11619expand.scm",(void*)f_11619},
{"f_11630expand.scm",(void*)f_11630},
{"f_11560expand.scm",(void*)f_11560},
{"f_11537expand.scm",(void*)f_11537},
{"f_7638expand.scm",(void*)f_7638},
{"f_11518expand.scm",(void*)f_11518},
{"f_11516expand.scm",(void*)f_11516},
{"f_7641expand.scm",(void*)f_7641},
{"f_11497expand.scm",(void*)f_11497},
{"f_11495expand.scm",(void*)f_11495},
{"f_7644expand.scm",(void*)f_7644},
{"f_11446expand.scm",(void*)f_11446},
{"f_11450expand.scm",(void*)f_11450},
{"f_11487expand.scm",(void*)f_11487},
{"f_11480expand.scm",(void*)f_11480},
{"f_11473expand.scm",(void*)f_11473},
{"f_11444expand.scm",(void*)f_11444},
{"f_7647expand.scm",(void*)f_7647},
{"f_11392expand.scm",(void*)f_11392},
{"f_11396expand.scm",(void*)f_11396},
{"f_11399expand.scm",(void*)f_11399},
{"f_11436expand.scm",(void*)f_11436},
{"f_11402expand.scm",(void*)f_11402},
{"f_11417expand.scm",(void*)f_11417},
{"f_11421expand.scm",(void*)f_11421},
{"f_11390expand.scm",(void*)f_11390},
{"f_7650expand.scm",(void*)f_7650},
{"f_11289expand.scm",(void*)f_11289},
{"f_11296expand.scm",(void*)f_11296},
{"f_11299expand.scm",(void*)f_11299},
{"f_11319expand.scm",(void*)f_11319},
{"f_11341expand.scm",(void*)f_11341},
{"f_11326expand.scm",(void*)f_11326},
{"f_11302expand.scm",(void*)f_11302},
{"f_11317expand.scm",(void*)f_11317},
{"f_11309expand.scm",(void*)f_11309},
{"f_11305expand.scm",(void*)f_11305},
{"f_11287expand.scm",(void*)f_11287},
{"f_7653expand.scm",(void*)f_7653},
{"f_11252expand.scm",(void*)f_11252},
{"f_11256expand.scm",(void*)f_11256},
{"f_11274expand.scm",(void*)f_11274},
{"f_11265expand.scm",(void*)f_11265},
{"f_11250expand.scm",(void*)f_11250},
{"f_7656expand.scm",(void*)f_7656},
{"f_9347expand.scm",(void*)f_9347},
{"f_11246expand.scm",(void*)f_11246},
{"f_9351expand.scm",(void*)f_9351},
{"f_9355expand.scm",(void*)f_9355},
{"f_11204expand.scm",(void*)f_11204},
{"f_11212expand.scm",(void*)f_11212},
{"f_11214expand.scm",(void*)f_11214},
{"f_11235expand.scm",(void*)f_11235},
{"f_10869expand.scm",(void*)f_10869},
{"f_11189expand.scm",(void*)f_11189},
{"f_11197expand.scm",(void*)f_11197},
{"f_10885expand.scm",(void*)f_10885},
{"f_11146expand.scm",(void*)f_11146},
{"f_11148expand.scm",(void*)f_11148},
{"f_11187expand.scm",(void*)f_11187},
{"f_11161expand.scm",(void*)f_11161},
{"f_11172expand.scm",(void*)f_11172},
{"f_11127expand.scm",(void*)f_11127},
{"f_11139expand.scm",(void*)f_11139},
{"f_10888expand.scm",(void*)f_10888},
{"f_11003expand.scm",(void*)f_11003},
{"f_11054expand.scm",(void*)f_11054},
{"f_11103expand.scm",(void*)f_11103},
{"f_11066expand.scm",(void*)f_11066},
{"f_11089expand.scm",(void*)f_11089},
{"f_11085expand.scm",(void*)f_11085},
{"f_11051expand.scm",(void*)f_11051},
{"f_11040expand.scm",(void*)f_11040},
{"f_10891expand.scm",(void*)f_10891},
{"f_10997expand.scm",(void*)f_10997},
{"f_10983expand.scm",(void*)f_10983},
{"f_10894expand.scm",(void*)f_10894},
{"f_10981expand.scm",(void*)f_10981},
{"f_10945expand.scm",(void*)f_10945},
{"f_10973expand.scm",(void*)f_10973},
{"f_10897expand.scm",(void*)f_10897},
{"f_10939expand.scm",(void*)f_10939},
{"f_10943expand.scm",(void*)f_10943},
{"f_10900expand.scm",(void*)f_10900},
{"f_10903expand.scm",(void*)f_10903},
{"f_10917expand.scm",(void*)f_10917},
{"f_10921expand.scm",(void*)f_10921},
{"f_10906expand.scm",(void*)f_10906},
{"f_10912expand.scm",(void*)f_10912},
{"f_10784expand.scm",(void*)f_10784},
{"f_10795expand.scm",(void*)f_10795},
{"f_10797expand.scm",(void*)f_10797},
{"f_10846expand.scm",(void*)f_10846},
{"f_10842expand.scm",(void*)f_10842},
{"f_10825expand.scm",(void*)f_10825},
{"f_10693expand.scm",(void*)f_10693},
{"f_10697expand.scm",(void*)f_10697},
{"f_10700expand.scm",(void*)f_10700},
{"f_10739expand.scm",(void*)f_10739},
{"f_10759expand.scm",(void*)f_10759},
{"f_10749expand.scm",(void*)f_10749},
{"f_10752expand.scm",(void*)f_10752},
{"f_10715expand.scm",(void*)f_10715},
{"f_10721expand.scm",(void*)f_10721},
{"f_10719expand.scm",(void*)f_10719},
{"f_10573expand.scm",(void*)f_10573},
{"f_10675expand.scm",(void*)f_10675},
{"f_10687expand.scm",(void*)f_10687},
{"f_10577expand.scm",(void*)f_10577},
{"f_10643expand.scm",(void*)f_10643},
{"f_10665expand.scm",(void*)f_10665},
{"f_10580expand.scm",(void*)f_10580},
{"f_10637expand.scm",(void*)f_10637},
{"f_10641expand.scm",(void*)f_10641},
{"f_10586expand.scm",(void*)f_10586},
{"f_10589expand.scm",(void*)f_10589},
{"f_10625expand.scm",(void*)f_10625},
{"f_10592expand.scm",(void*)f_10592},
{"f_10605expand.scm",(void*)f_10605},
{"f_10595expand.scm",(void*)f_10595},
{"f_10287expand.scm",(void*)f_10287},
{"f_10571expand.scm",(void*)f_10571},
{"f_10307expand.scm",(void*)f_10307},
{"f_10541expand.scm",(void*)f_10541},
{"f_10315expand.scm",(void*)f_10315},
{"f_10523expand.scm",(void*)f_10523},
{"f_10323expand.scm",(void*)f_10323},
{"f_10511expand.scm",(void*)f_10511},
{"f_10438expand.scm",(void*)f_10438},
{"f_10436expand.scm",(void*)f_10436},
{"f_10432expand.scm",(void*)f_10432},
{"f_10373expand.scm",(void*)f_10373},
{"f_10383expand.scm",(void*)f_10383},
{"f_10371expand.scm",(void*)f_10371},
{"f_10367expand.scm",(void*)f_10367},
{"f_10319expand.scm",(void*)f_10319},
{"f_10311expand.scm",(void*)f_10311},
{"f_10227expand.scm",(void*)f_10227},
{"f_10231expand.scm",(void*)f_10231},
{"f_10242expand.scm",(void*)f_10242},
{"f_10281expand.scm",(void*)f_10281},
{"f_10273expand.scm",(void*)f_10273},
{"f_10237expand.scm",(void*)f_10237},
{"f_9951expand.scm",(void*)f_9951},
{"f_10032expand.scm",(void*)f_10032},
{"f_10059expand.scm",(void*)f_10059},
{"f_10061expand.scm",(void*)f_10061},
{"f_10221expand.scm",(void*)f_10221},
{"f_10209expand.scm",(void*)f_10209},
{"f_10190expand.scm",(void*)f_10190},
{"f_10172expand.scm",(void*)f_10172},
{"f_10157expand.scm",(void*)f_10157},
{"f_10127expand.scm",(void*)f_10127},
{"f_10112expand.scm",(void*)f_10112},
{"f_10084expand.scm",(void*)f_10084},
{"f_10009expand.scm",(void*)f_10009},
{"f_10021expand.scm",(void*)f_10021},
{"f_10017expand.scm",(void*)f_10017},
{"f_9904expand.scm",(void*)f_9904},
{"f_9910expand.scm",(void*)f_9910},
{"f_9917expand.scm",(void*)f_9917},
{"f_9836expand.scm",(void*)f_9836},
{"f_9856expand.scm",(void*)f_9856},
{"f_9851expand.scm",(void*)f_9851},
{"f_9838expand.scm",(void*)f_9838},
{"f_9814expand.scm",(void*)f_9814},
{"f_9821expand.scm",(void*)f_9821},
{"f_9737expand.scm",(void*)f_9737},
{"f_9747expand.scm",(void*)f_9747},
{"f_9750expand.scm",(void*)f_9750},
{"f_9756expand.scm",(void*)f_9756},
{"f_9795expand.scm",(void*)f_9795},
{"f_9799expand.scm",(void*)f_9799},
{"f_9759expand.scm",(void*)f_9759},
{"f_9765expand.scm",(void*)f_9765},
{"f_9648expand.scm",(void*)f_9648},
{"f_9658expand.scm",(void*)f_9658},
{"f_9661expand.scm",(void*)f_9661},
{"f_9724expand.scm",(void*)f_9724},
{"f_9664expand.scm",(void*)f_9664},
{"f_9720expand.scm",(void*)f_9720},
{"f_9667expand.scm",(void*)f_9667},
{"f_9706expand.scm",(void*)f_9706},
{"f_9710expand.scm",(void*)f_9710},
{"f_9670expand.scm",(void*)f_9670},
{"f_9673expand.scm",(void*)f_9673},
{"f_9627expand.scm",(void*)f_9627},
{"f_9634expand.scm",(void*)f_9634},
{"f_9607expand.scm",(void*)f_9607},
{"f_9611expand.scm",(void*)f_9611},
{"f_9604expand.scm",(void*)f_9604},
{"f_9564expand.scm",(void*)f_9564},
{"f_9568expand.scm",(void*)f_9568},
{"f_9558expand.scm",(void*)f_9558},
{"f_9549expand.scm",(void*)f_9549},
{"f_9531expand.scm",(void*)f_9531},
{"f_9513expand.scm",(void*)f_9513},
{"f_9495expand.scm",(void*)f_9495},
{"f_9477expand.scm",(void*)f_9477},
{"f_9459expand.scm",(void*)f_9459},
{"f_9450expand.scm",(void*)f_9450},
{"f_9441expand.scm",(void*)f_9441},
{"f_9423expand.scm",(void*)f_9423},
{"f_9405expand.scm",(void*)f_9405},
{"f_9396expand.scm",(void*)f_9396},
{"f_9387expand.scm",(void*)f_9387},
{"f_9369expand.scm",(void*)f_9369},
{"f_9363expand.scm",(void*)f_9363},
{"f_7658expand.scm",(void*)f_7658},
{"f_7663expand.scm",(void*)f_7663},
{"f_7667expand.scm",(void*)f_7667},
{"f_7671expand.scm",(void*)f_7671},
{"f_7675expand.scm",(void*)f_7675},
{"f_7679expand.scm",(void*)f_7679},
{"f_7683expand.scm",(void*)f_7683},
{"f_7687expand.scm",(void*)f_7687},
{"f_7691expand.scm",(void*)f_7691},
{"f_7695expand.scm",(void*)f_7695},
{"f_7699expand.scm",(void*)f_7699},
{"f_7703expand.scm",(void*)f_7703},
{"f_7707expand.scm",(void*)f_7707},
{"f_7711expand.scm",(void*)f_7711},
{"f_7715expand.scm",(void*)f_7715},
{"f_7719expand.scm",(void*)f_7719},
{"f_7723expand.scm",(void*)f_7723},
{"f_7727expand.scm",(void*)f_7727},
{"f_7731expand.scm",(void*)f_7731},
{"f_7735expand.scm",(void*)f_7735},
{"f_7739expand.scm",(void*)f_7739},
{"f_7743expand.scm",(void*)f_7743},
{"f_7747expand.scm",(void*)f_7747},
{"f_7751expand.scm",(void*)f_7751},
{"f_7755expand.scm",(void*)f_7755},
{"f_7759expand.scm",(void*)f_7759},
{"f_7763expand.scm",(void*)f_7763},
{"f_7767expand.scm",(void*)f_7767},
{"f_7771expand.scm",(void*)f_7771},
{"f_7775expand.scm",(void*)f_7775},
{"f_7779expand.scm",(void*)f_7779},
{"f_7783expand.scm",(void*)f_7783},
{"f_7787expand.scm",(void*)f_7787},
{"f_7791expand.scm",(void*)f_7791},
{"f_7795expand.scm",(void*)f_7795},
{"f_7799expand.scm",(void*)f_7799},
{"f_7803expand.scm",(void*)f_7803},
{"f_9306expand.scm",(void*)f_9306},
{"f_9316expand.scm",(void*)f_9316},
{"f_9323expand.scm",(void*)f_9323},
{"f_9286expand.scm",(void*)f_9286},
{"f_9293expand.scm",(void*)f_9293},
{"f_9300expand.scm",(void*)f_9300},
{"f_9260expand.scm",(void*)f_9260},
{"f_9238expand.scm",(void*)f_9238},
{"f_9245expand.scm",(void*)f_9245},
{"f_9145expand.scm",(void*)f_9145},
{"f_9187expand.scm",(void*)f_9187},
{"f_9236expand.scm",(void*)f_9236},
{"f_9219expand.scm",(void*)f_9219},
{"f_9198expand.scm",(void*)f_9198},
{"f_9158expand.scm",(void*)f_9158},
{"f_9072expand.scm",(void*)f_9072},
{"f_9098expand.scm",(void*)f_9098},
{"f_9143expand.scm",(void*)f_9143},
{"f_9126expand.scm",(void*)f_9126},
{"f_8818expand.scm",(void*)f_8818},
{"f_8865expand.scm",(void*)f_8865},
{"f_9063expand.scm",(void*)f_9063},
{"f_9059expand.scm",(void*)f_9059},
{"f_9026expand.scm",(void*)f_9026},
{"f_9034expand.scm",(void*)f_9034},
{"f_8868expand.scm",(void*)f_8868},
{"f_8874expand.scm",(void*)f_8874},
{"f_8886expand.scm",(void*)f_8886},
{"f_8952expand.scm",(void*)f_8952},
{"f_8967expand.scm",(void*)f_8967},
{"f_8889expand.scm",(void*)f_8889},
{"f_8923expand.scm",(void*)f_8923},
{"f_8892expand.scm",(void*)f_8892},
{"f_8921expand.scm",(void*)f_8921},
{"f_8917expand.scm",(void*)f_8917},
{"f_8913expand.scm",(void*)f_8913},
{"f_8611expand.scm",(void*)f_8611},
{"f_8641expand.scm",(void*)f_8641},
{"f_8741expand.scm",(void*)f_8741},
{"f_8764expand.scm",(void*)f_8764},
{"f_8778expand.scm",(void*)f_8778},
{"f_8782expand.scm",(void*)f_8782},
{"f_8751expand.scm",(void*)f_8751},
{"f_8701expand.scm",(void*)f_8701},
{"f_8705expand.scm",(void*)f_8705},
{"f_8650expand.scm",(void*)f_8650},
{"f_8658expand.scm",(void*)f_8658},
{"f_8635expand.scm",(void*)f_8635},
{"f_8323expand.scm",(void*)f_8323},
{"f_8330expand.scm",(void*)f_8330},
{"f_8369expand.scm",(void*)f_8369},
{"f_8379expand.scm",(void*)f_8379},
{"f_8510expand.scm",(void*)f_8510},
{"f_8514expand.scm",(void*)f_8514},
{"f_8443expand.scm",(void*)f_8443},
{"f_8439expand.scm",(void*)f_8439},
{"f_8377expand.scm",(void*)f_8377},
{"f_8373expand.scm",(void*)f_8373},
{"f_8205expand.scm",(void*)f_8205},
{"f_8209expand.scm",(void*)f_8209},
{"f_7984expand.scm",(void*)f_7984},
{"f_8034expand.scm",(void*)f_8034},
{"f_8148expand.scm",(void*)f_8148},
{"f_8086expand.scm",(void*)f_8086},
{"f_8094expand.scm",(void*)f_8094},
{"f_8090expand.scm",(void*)f_8090},
{"f_8082expand.scm",(void*)f_8082},
{"f_7900expand.scm",(void*)f_7900},
{"f_7907expand.scm",(void*)f_7907},
{"f_7910expand.scm",(void*)f_7910},
{"f_7959expand.scm",(void*)f_7959},
{"f_7955expand.scm",(void*)f_7955},
{"f_7950expand.scm",(void*)f_7950},
{"f_7936expand.scm",(void*)f_7936},
{"f_7948expand.scm",(void*)f_7948},
{"f_7944expand.scm",(void*)f_7944},
{"f_7806expand.scm",(void*)f_7806},
{"f_7850expand.scm",(void*)f_7850},
{"f_7846expand.scm",(void*)f_7846},
{"f_6807expand.scm",(void*)f_6807},
{"f_6811expand.scm",(void*)f_6811},
{"f_6814expand.scm",(void*)f_6814},
{"f_6817expand.scm",(void*)f_6817},
{"f_6820expand.scm",(void*)f_6820},
{"f_7419expand.scm",(void*)f_7419},
{"f_7422expand.scm",(void*)f_7422},
{"f_7587expand.scm",(void*)f_7587},
{"f_7572expand.scm",(void*)f_7572},
{"f_7425expand.scm",(void*)f_7425},
{"f_7430expand.scm",(void*)f_7430},
{"f_7434expand.scm",(void*)f_7434},
{"f_7452expand.scm",(void*)f_7452},
{"f_7524expand.scm",(void*)f_7524},
{"f_7558expand.scm",(void*)f_7558},
{"f_7455expand.scm",(void*)f_7455},
{"f_7482expand.scm",(void*)f_7482},
{"f_7522expand.scm",(void*)f_7522},
{"f_7458expand.scm",(void*)f_7458},
{"f_7480expand.scm",(void*)f_7480},
{"f_7476expand.scm",(void*)f_7476},
{"f_7461expand.scm",(void*)f_7461},
{"f_7472expand.scm",(void*)f_7472},
{"f_7468expand.scm",(void*)f_7468},
{"f_7428expand.scm",(void*)f_7428},
{"f_6961expand.scm",(void*)f_6961},
{"f_6980expand.scm",(void*)f_6980},
{"f_6989expand.scm",(void*)f_6989},
{"f_7001expand.scm",(void*)f_7001},
{"f_7081expand.scm",(void*)f_7081},
{"f_7188expand.scm",(void*)f_7188},
{"f_7335expand.scm",(void*)f_7335},
{"f_7338expand.scm",(void*)f_7338},
{"f_7341expand.scm",(void*)f_7341},
{"f_7374expand.scm",(void*)f_7374},
{"f_7378expand.scm",(void*)f_7378},
{"f_7343expand.scm",(void*)f_7343},
{"f_7363expand.scm",(void*)f_7363},
{"f_7359expand.scm",(void*)f_7359},
{"f_7351expand.scm",(void*)f_7351},
{"f_7191expand.scm",(void*)f_7191},
{"f_7200expand.scm",(void*)f_7200},
{"f_7329expand.scm",(void*)f_7329},
{"f_7310expand.scm",(void*)f_7310},
{"f_7298expand.scm",(void*)f_7298},
{"f_7277expand.scm",(void*)f_7277},
{"f_7258expand.scm",(void*)f_7258},
{"f_7246expand.scm",(void*)f_7246},
{"f_7221expand.scm",(void*)f_7221},
{"f_7216expand.scm",(void*)f_7216},
{"f_7084expand.scm",(void*)f_7084},
{"f_7087expand.scm",(void*)f_7087},
{"f_7092expand.scm",(void*)f_7092},
{"f_7178expand.scm",(void*)f_7178},
{"f_7104expand.scm",(void*)f_7104},
{"f_7146expand.scm",(void*)f_7146},
{"f_7004expand.scm",(void*)f_7004},
{"f_7007expand.scm",(void*)f_7007},
{"f_7012expand.scm",(void*)f_7012},
{"f_6874expand.scm",(void*)f_6874},
{"f_6878expand.scm",(void*)f_6878},
{"f_6881expand.scm",(void*)f_6881},
{"f_6959expand.scm",(void*)f_6959},
{"f_6955expand.scm",(void*)f_6955},
{"f_6896expand.scm",(void*)f_6896},
{"f_6902expand.scm",(void*)f_6902},
{"f_6905expand.scm",(void*)f_6905},
{"f_6944expand.scm",(void*)f_6944},
{"f_6938expand.scm",(void*)f_6938},
{"f_6942expand.scm",(void*)f_6942},
{"f_6906expand.scm",(void*)f_6906},
{"f_6910expand.scm",(void*)f_6910},
{"f_6913expand.scm",(void*)f_6913},
{"f_6917expand.scm",(void*)f_6917},
{"f_6920expand.scm",(void*)f_6920},
{"f_6924expand.scm",(void*)f_6924},
{"f_6927expand.scm",(void*)f_6927},
{"f_6931expand.scm",(void*)f_6931},
{"f_6934expand.scm",(void*)f_6934},
{"f_6884expand.scm",(void*)f_6884},
{"f_6831expand.scm",(void*)f_6831},
{"f_6844expand.scm",(void*)f_6844},
{"f_6851expand.scm",(void*)f_6851},
{"f_6822expand.scm",(void*)f_6822},
{"f_6826expand.scm",(void*)f_6826},
{"f_6615expand.scm",(void*)f_6615},
{"f_6617expand.scm",(void*)f_6617},
{"f_6678expand.scm",(void*)f_6678},
{"f_6691expand.scm",(void*)f_6691},
{"f_6781expand.scm",(void*)f_6781},
{"f_6694expand.scm",(void*)f_6694},
{"f_6697expand.scm",(void*)f_6697},
{"f_6775expand.scm",(void*)f_6775},
{"f_6700expand.scm",(void*)f_6700},
{"f_6769expand.scm",(void*)f_6769},
{"f_6746expand.scm",(void*)f_6746},
{"f_6719expand.scm",(void*)f_6719},
{"f_6726expand.scm",(void*)f_6726},
{"f_6682expand.scm",(void*)f_6682},
{"f_6795expand.scm",(void*)f_6795},
{"f_6799expand.scm",(void*)f_6799},
{"f_6620expand.scm",(void*)f_6620},
{"f_6636expand.scm",(void*)f_6636},
{"f_6665expand.scm",(void*)f_6665},
{"f_6651expand.scm",(void*)f_6651},
{"f_6153expand.scm",(void*)f_6153},
{"f_6567expand.scm",(void*)f_6567},
{"f_6558expand.scm",(void*)f_6558},
{"f_6566expand.scm",(void*)f_6566},
{"f_6155expand.scm",(void*)f_6155},
{"f_6286expand.scm",(void*)f_6286},
{"f_6291expand.scm",(void*)f_6291},
{"f_6529expand.scm",(void*)f_6529},
{"f_6488expand.scm",(void*)f_6488},
{"f_6492expand.scm",(void*)f_6492},
{"f_6310expand.scm",(void*)f_6310},
{"f_6315expand.scm",(void*)f_6315},
{"f_6334expand.scm",(void*)f_6334},
{"f_6257expand.scm",(void*)f_6257},
{"f_6263expand.scm",(void*)f_6263},
{"f_6201expand.scm",(void*)f_6201},
{"f_6205expand.scm",(void*)f_6205},
{"f_6213expand.scm",(void*)f_6213},
{"f_6233expand.scm",(void*)f_6233},
{"f_6158expand.scm",(void*)f_6158},
{"f_6165expand.scm",(void*)f_6165},
{"f_6170expand.scm",(void*)f_6170},
{"f_6174expand.scm",(void*)f_6174},
{"f_6199expand.scm",(void*)f_6199},
{"f_6188expand.scm",(void*)f_6188},
{"f_6192expand.scm",(void*)f_6192},
{"f_6181expand.scm",(void*)f_6181},
{"f_6117expand.scm",(void*)f_6117},
{"f_6139expand.scm",(void*)f_6139},
{"f_6106expand.scm",(void*)f_6106},
{"f_6114expand.scm",(void*)f_6114},
{"f_6036expand.scm",(void*)f_6036},
{"f_6099expand.scm",(void*)f_6099},
{"f_6039expand.scm",(void*)f_6039},
{"f_6092expand.scm",(void*)f_6092},
{"f_6065expand.scm",(void*)f_6065},
{"f_5953expand.scm",(void*)f_5953},
{"f_6034expand.scm",(void*)f_6034},
{"f_5956expand.scm",(void*)f_5956},
{"f_6005expand.scm",(void*)f_6005},
{"f_5208expand.scm",(void*)f_5208},
{"f_5212expand.scm",(void*)f_5212},
{"f_5643expand.scm",(void*)f_5643},
{"f_5649expand.scm",(void*)f_5649},
{"f_5913expand.scm",(void*)f_5913},
{"f_5671expand.scm",(void*)f_5671},
{"f_5881expand.scm",(void*)f_5881},
{"f_5855expand.scm",(void*)f_5855},
{"f_5862expand.scm",(void*)f_5862},
{"f_5827expand.scm",(void*)f_5827},
{"f_5815expand.scm",(void*)f_5815},
{"f_5689expand.scm",(void*)f_5689},
{"f_5694expand.scm",(void*)f_5694},
{"f_5707expand.scm",(void*)f_5707},
{"f_5763expand.scm",(void*)f_5763},
{"f_5790expand.scm",(void*)f_5790},
{"f_5741expand.scm",(void*)f_5741},
{"f_5752expand.scm",(void*)f_5752},
{"f_5756expand.scm",(void*)f_5756},
{"f_5466expand.scm",(void*)f_5466},
{"f_5476expand.scm",(void*)f_5476},
{"f_5625expand.scm",(void*)f_5625},
{"f_5621expand.scm",(void*)f_5621},
{"f_5611expand.scm",(void*)f_5611},
{"f_5614expand.scm",(void*)f_5614},
{"f_5522expand.scm",(void*)f_5522},
{"f_5554expand.scm",(void*)f_5554},
{"f_5566expand.scm",(void*)f_5566},
{"f_5574expand.scm",(void*)f_5574},
{"f_5578expand.scm",(void*)f_5578},
{"f_5540expand.scm",(void*)f_5540},
{"f_5491expand.scm",(void*)f_5491},
{"f_5507expand.scm",(void*)f_5507},
{"f_5499expand.scm",(void*)f_5499},
{"f_5503expand.scm",(void*)f_5503},
{"f_5474expand.scm",(void*)f_5474},
{"f_5214expand.scm",(void*)f_5214},
{"f_5325expand.scm",(void*)f_5325},
{"f_5458expand.scm",(void*)f_5458},
{"f_5446expand.scm",(void*)f_5446},
{"f_5339expand.scm",(void*)f_5339},
{"f_5444expand.scm",(void*)f_5444},
{"f_5428expand.scm",(void*)f_5428},
{"f_5347expand.scm",(void*)f_5347},
{"f_5422expand.scm",(void*)f_5422},
{"f_5426expand.scm",(void*)f_5426},
{"f_5361expand.scm",(void*)f_5361},
{"f_5365expand.scm",(void*)f_5365},
{"f_5398expand.scm",(void*)f_5398},
{"f_5396expand.scm",(void*)f_5396},
{"f_5392expand.scm",(void*)f_5392},
{"f_5355expand.scm",(void*)f_5355},
{"f_5359expand.scm",(void*)f_5359},
{"f_5351expand.scm",(void*)f_5351},
{"f_5343expand.scm",(void*)f_5343},
{"f_5226expand.scm",(void*)f_5226},
{"f_5240expand.scm",(void*)f_5240},
{"f_5315expand.scm",(void*)f_5315},
{"f_5308expand.scm",(void*)f_5308},
{"f_5249expand.scm",(void*)f_5249},
{"f_5256expand.scm",(void*)f_5256},
{"f_5264expand.scm",(void*)f_5264},
{"f_5272expand.scm",(void*)f_5272},
{"f_5260expand.scm",(void*)f_5260},
{"f_4618expand.scm",(void*)f_4618},
{"f_4638expand.scm",(void*)f_4638},
{"f_4641expand.scm",(void*)f_4641},
{"f_4644expand.scm",(void*)f_4644},
{"f_4647expand.scm",(void*)f_4647},
{"f_4650expand.scm",(void*)f_4650},
{"f_4655expand.scm",(void*)f_4655},
{"f_4966expand.scm",(void*)f_4966},
{"f_5145expand.scm",(void*)f_5145},
{"f_5083expand.scm",(void*)f_5083},
{"f_5064expand.scm",(void*)f_5064},
{"f_5018expand.scm",(void*)f_5018},
{"f_5021expand.scm",(void*)f_5021},
{"f_5000expand.scm",(void*)f_5000},
{"f_4981expand.scm",(void*)f_4981},
{"f_4943expand.scm",(void*)f_4943},
{"f_4922expand.scm",(void*)f_4922},
{"f_4669expand.scm",(void*)f_4669},
{"f_4915expand.scm",(void*)f_4915},
{"f_4842expand.scm",(void*)f_4842},
{"f_4911expand.scm",(void*)f_4911},
{"f_4895expand.scm",(void*)f_4895},
{"f_4877expand.scm",(void*)f_4877},
{"f_4873expand.scm",(void*)f_4873},
{"f_4836expand.scm",(void*)f_4836},
{"f_4840expand.scm",(void*)f_4840},
{"f_4673expand.scm",(void*)f_4673},
{"f_4685expand.scm",(void*)f_4685},
{"f_4788expand.scm",(void*)f_4788},
{"f_4780expand.scm",(void*)f_4780},
{"f_4784expand.scm",(void*)f_4784},
{"f_4757expand.scm",(void*)f_4757},
{"f_4761expand.scm",(void*)f_4761},
{"f_4712expand.scm",(void*)f_4712},
{"f_4732expand.scm",(void*)f_4732},
{"f_4704expand.scm",(void*)f_4704},
{"f_4676expand.scm",(void*)f_4676},
{"f_4621expand.scm",(void*)f_4621},
{"f_4575expand.scm",(void*)f_4575},
{"f_4581expand.scm",(void*)f_4581},
{"f_4600expand.scm",(void*)f_4600},
{"f_4522expand.scm",(void*)f_4522},
{"f_4526expand.scm",(void*)f_4526},
{"f_4531expand.scm",(void*)f_4531},
{"f_4543expand.scm",(void*)f_4543},
{"f_4537expand.scm",(void*)f_4537},
{"f_4436expand.scm",(void*)f_4436},
{"f_4468expand.scm",(void*)f_4468},
{"f_4471expand.scm",(void*)f_4471},
{"f_4483expand.scm",(void*)f_4483},
{"f_4520expand.scm",(void*)f_4520},
{"f_4510expand.scm",(void*)f_4510},
{"f_4439expand.scm",(void*)f_4439},
{"f_4443expand.scm",(void*)f_4443},
{"f_4452expand.scm",(void*)f_4452},
{"f_4418expand.scm",(void*)f_4418},
{"f_4426expand.scm",(void*)f_4426},
{"f_4011expand.scm",(void*)f_4011},
{"f_4231expand.scm",(void*)f_4231},
{"f_4409expand.scm",(void*)f_4409},
{"f_4402expand.scm",(void*)f_4402},
{"f_4237expand.scm",(void*)f_4237},
{"f_4343expand.scm",(void*)f_4343},
{"f_4349expand.scm",(void*)f_4349},
{"f_4356expand.scm",(void*)f_4356},
{"f_4246expand.scm",(void*)f_4246},
{"f_4258expand.scm",(void*)f_4258},
{"f_4288expand.scm",(void*)f_4288},
{"f_4330expand.scm",(void*)f_4330},
{"f_4320expand.scm",(void*)f_4320},
{"f_4324expand.scm",(void*)f_4324},
{"f_4284expand.scm",(void*)f_4284},
{"f_4280expand.scm",(void*)f_4280},
{"f_4169expand.scm",(void*)f_4169},
{"f_4195expand.scm",(void*)f_4195},
{"f_4014expand.scm",(void*)f_4014},
{"f_4029expand.scm",(void*)f_4029},
{"f_4142expand.scm",(void*)f_4142},
{"f_4157expand.scm",(void*)f_4157},
{"f_4163expand.scm",(void*)f_4163},
{"f_4148expand.scm",(void*)f_4148},
{"f_4152expand.scm",(void*)f_4152},
{"f_4035expand.scm",(void*)f_4035},
{"f_4041expand.scm",(void*)f_4041},
{"f_4052expand.scm",(void*)f_4052},
{"f_4069expand.scm",(void*)f_4069},
{"f_4088expand.scm",(void*)f_4088},
{"f_4099expand.scm",(void*)f_4099},
{"f_4063expand.scm",(void*)f_4063},
{"f_4049expand.scm",(void*)f_4049},
{"f_4027expand.scm",(void*)f_4027},
{"f_4002expand.scm",(void*)f_4002},
{"f_3951expand.scm",(void*)f_3951},
{"f_3963expand.scm",(void*)f_3963},
{"f_3965expand.scm",(void*)f_3965},
{"f_4000expand.scm",(void*)f_4000},
{"f_3992expand.scm",(void*)f_3992},
{"f_3959expand.scm",(void*)f_3959},
{"f_3895expand.scm",(void*)f_3895},
{"f_3899expand.scm",(void*)f_3899},
{"f_3908expand.scm",(void*)f_3908},
{"f_3927expand.scm",(void*)f_3927},
{"f_3917expand.scm",(void*)f_3917},
{"f_3882expand.scm",(void*)f_3882},
{"f_3893expand.scm",(void*)f_3893},
{"f_3886expand.scm",(void*)f_3886},
{"f_3849expand.scm",(void*)f_3849},
{"f_3853expand.scm",(void*)f_3853},
{"f_3856expand.scm",(void*)f_3856},
{"f_3742expand.scm",(void*)f_3742},
{"f_3746expand.scm",(void*)f_3746},
{"f_3751expand.scm",(void*)f_3751},
{"f_3821expand.scm",(void*)f_3821},
{"f_3817expand.scm",(void*)f_3817},
{"f_3792expand.scm",(void*)f_3792},
{"f_3796expand.scm",(void*)f_3796},
{"f_3761expand.scm",(void*)f_3761},
{"f_3712expand.scm",(void*)f_3712},
{"f_3718expand.scm",(void*)f_3718},
{"f_3670expand.scm",(void*)f_3670},
{"f_3677expand.scm",(void*)f_3677},
{"f_3680expand.scm",(void*)f_3680},
{"f_3683expand.scm",(void*)f_3683},
{"f_3686expand.scm",(void*)f_3686},
{"f_3692expand.scm",(void*)f_3692},
{"f_3652expand.scm",(void*)f_3652},
{"f_3665expand.scm",(void*)f_3665},
{"f_3621expand.scm",(void*)f_3621},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
