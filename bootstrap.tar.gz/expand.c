/* Generated from expand.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-11-14 09:48
   Version 4.0.0x1 - SVN rev. 12338
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-11-03 on dill (Linux)
   command line: expand.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file expand.c
   unit: expand
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[392];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,17),40,100,32,97,114,103,49,55,32,46,32,109,111,114,101,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,108,111,111,107,117,112,32,105,100,50,52,32,115,101,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,109,97,99,114,111,45,97,108,105,97,115,32,118,97,114,52,53,32,115,101,52,54,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,11),40,97,51,54,53,52,32,97,56,48,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,13),40,109,97,112,45,115,101,32,115,101,55,56,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,11),40,119,97,108,107,32,120,49,49,53,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,24),40,98,111,100,121,49,48,48,32,115,101,49,49,48,32,97,108,105,97,115,49,49,49,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,97,108,105,97,115,49,48,51,32,37,115,101,57,56,49,51,57,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,11),40,100,101,102,45,115,101,49,48,50,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,115,116,114,105,112,45,115,121,110,116,97,120,32,101,120,112,57,48,32,46,32,116,109,112,56,57,57,49,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,101,120,116,101,110,100,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,110,97,109,101,49,53,57,32,115,101,49,54,48,32,104,97,110,100,108,101,114,49,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,99,111,112,121,45,109,97,99,114,111,32,111,108,100,49,56,49,32,110,101,119,49,56,50,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,27),40,109,97,99,114,111,63,32,115,121,109,49,57,52,32,46,32,116,109,112,49,57,51,49,57,53,41,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,109,101,50,50,56,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,109,97,99,114,111,32,110,97,109,101,50,50,52,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,117,110,100,101,102,105,110,101,45,109,97,99,114,111,33,32,110,97,109,101,50,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,112,115,50,55,53,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,7),40,97,52,48,50,53,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,97,52,48,49,57,32,101,120,50,54,56,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,52,49,51,50,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,52,49,53,57,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,20),40,97,52,49,53,51,32,46,32,97,114,103,115,50,54,50,50,57,53,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,52,49,50,54,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,15),40,97,52,48,49,51,32,107,50,54,49,50,54,54,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,46),40,99,97,108,108,45,104,97,110,100,108,101,114,32,110,97,109,101,50,53,50,32,104,97,110,100,108,101,114,50,53,51,32,101,120,112,50,53,52,32,115,101,50,53,53,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,31),40,101,120,112,97,110,100,32,104,101,97,100,51,48,48,32,101,120,112,51,48,49,32,109,100,101,102,51,48,50,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,12),40,97,52,51,56,57,32,98,51,55,52,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,101,120,112,97,110,100,45,48,32,101,120,112,50,52,55,32,100,115,101,50,52,56,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,109,111,100,117,108,101,45,114,101,110,97,109,101,32,115,121,109,51,57,49,32,112,114,101,102,105,120,51,57,50,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,16),40,109,114,101,110,97,109,101,32,115,121,109,52,48,56,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,97,108,105,97,115,45,103,108,111,98,97,108,45,104,111,111,107,32,115,121,109,51,57,54,32,97,115,115,105,103,110,51,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,52,54,48,48,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,32),40,97,52,54,48,54,32,101,120,112,50,52,55,53,52,55,54,52,56,49,32,109,52,55,55,52,55,56,52,56,50,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,52,55,50,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,101,120,112,97,110,100,32,101,120,112,52,53,55,32,46,32,116,109,112,52,53,54,52,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,108,105,115,116,52,57,54,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,63,32,108,108,105,115,116,52,57,50,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,101,114,114,32,109,115,103,53,51,50,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,97,52,57,48,53,32,107,53,54,53,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,109,111,100,101,53,52,55,32,114,101,113,53,52,56,32,111,112,116,53,52,57,32,107,101,121,53,53,48,32,108,108,105,115,116,53,53,49,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,67),40,35,35,115,121,115,35,101,120,112,97,110,100,45,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,32,108,108,105,115,116,48,53,50,53,32,98,111,100,121,53,50,54,32,101,114,114,104,53,50,55,32,115,101,53,50,56,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,98,111,100,121,50,55,48,51,32,101,120,112,115,55,48,52,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,17),40,97,53,52,54,57,32,118,55,54,48,32,116,55,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,18),40,97,53,52,51,50,32,118,115,55,53,49,32,120,55,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,17),40,97,53,52,57,57,32,118,55,52,52,32,120,55,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,97,53,53,49,55,32,118,55,52,50,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,48),40,102,105,110,105,32,118,97,114,115,54,57,51,32,118,97,108,115,54,57,52,32,109,118,97,114,115,54,57,53,32,109,118,97,108,115,54,57,54,32,98,111,100,121,54,57,55,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,30),40,108,111,111,112,32,98,111,100,121,55,56,50,32,100,101,102,115,55,56,51,32,100,111,110,101,55,56,52,41,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,55),40,102,105,110,105,47,115,121,110,116,97,120,32,118,97,114,115,55,55,52,32,118,97,108,115,55,55,53,32,109,118,97,114,115,55,55,54,32,109,118,97,108,115,55,55,55,32,98,111,100,121,55,55,56,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,50,32,120,56,53,56,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,48),40,108,111,111,112,32,98,111,100,121,56,50,49,32,118,97,114,115,56,50,50,32,118,97,108,115,56,50,51,32,109,118,97,114,115,56,50,52,32,109,118,97,108,115,56,50,53,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,98,111,100,121,56,49,55,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,99,97,110,111,110,105,99,97,108,105,122,101,45,98,111,100,121,32,98,111,100,121,54,55,55,32,46,32,116,109,112,54,55,54,54,55,56,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,17),40,109,119,97,108,107,32,120,57,48,53,32,112,57,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,40),40,109,97,116,99,104,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,56,57,54,32,112,97,116,56,57,55,32,118,97,114,115,56,57,56,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,104,101,97,100,57,52,49,32,98,111,100,121,57,52,50,41,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,51),40,35,35,115,121,115,35,101,120,112,97,110,100,45,99,117,114,114,105,101,100,45,100,101,102,105,110,101,32,104,101,97,100,57,51,52,32,98,111,100,121,57,51,53,32,115,101,57,51,54,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,45,104,111,111,107,32,46,32,97,114,103,115,57,54,48,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,25),40,103,101,116,45,108,105,110,101,45,110,117,109,98,101,114,32,115,101,120,112,57,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,101,114,114,32,109,115,103,49,48,52,49,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,29),40,116,101,115,116,32,120,49,48,51,53,32,112,114,101,100,49,48,51,54,32,109,115,103,49,48,51,55,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,49,48,53,57,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,108,97,109,98,100,97,45,108,105,115,116,63,32,120,49,48,52,57,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,20),40,112,114,111,112,101,114,45,108,105,115,116,63,32,120,49,48,56,48,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,49,50,57,32,120,49,49,51,54,32,110,49,49,51,55,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,13),40,97,54,53,53,57,32,121,49,49,53,55,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,49,48,51,32,112,49,49,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,49,48,49,54,32,99,117,108,112,114,105,116,49,48,50,54,32,115,101,49,48,50,55,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,101,49,48,49,57,32,37,99,117,108,112,114,105,116,49,48,49,52,49,49,55,51,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,99,117,108,112,114,105,116,49,48,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,99,104,101,99,107,45,115,121,110,116,97,120,32,105,100,49,48,48,52,32,101,120,112,49,48,48,53,32,112,97,116,49,48,48,54,32,46,32,116,109,112,49,48,48,51,49,48,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,16),40,114,101,110,97,109,101,32,115,121,109,49,49,57,56,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,31),40,108,111,111,107,117,112,50,32,110,49,51,51,53,32,115,121,109,49,51,51,54,32,100,115,101,49,51,51,55,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,23),40,99,111,109,112,97,114,101,32,115,49,49,50,53,49,32,115,50,49,50,53,50,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,32),40,102,95,54,54,56,57,32,102,111,114,109,49,49,56,57,32,115,101,49,49,57,48,32,100,115,101,49,49,57,49,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,101,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,49,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,17),40,114,101,115,111,108,118,101,32,115,121,109,49,51,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,13),40,116,111,115,116,114,32,120,49,51,55,52,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,10),40,115,119,97,112,49,52,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,7),40,97,55,49,49,55,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,110,97,109,101,32,115,112,101,99,49,51,56,51,41,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,105,100,115,49,52,57,48,32,118,49,52,57,49,32,115,49,52,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,115,49,53,51,49,32,115,49,53,51,50,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,118,49,53,49,57,32,118,49,53,50,48,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,14),40,97,55,51,57,52,32,105,100,49,53,55,48,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,105,109,112,118,49,53,52,56,32,105,109,112,115,49,53,52,57,32,118,49,53,53,48,32,115,49,53,53,49,32,105,100,115,49,53,53,50,41,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,13),40,114,101,110,32,105,109,112,49,53,56,57,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,115,112,101,99,32,115,112,101,99,49,52,53,52,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,15),40,97,55,54,53,53,32,105,109,112,49,54,50,57,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,97,55,54,57,55,32,105,109,112,49,54,49,57,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,16),40,97,55,54,48,51,32,115,112,101,99,49,53,57,55,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,86),40,35,35,115,121,115,35,101,120,112,97,110,100,45,105,109,112,111,114,116,32,120,49,51,52,57,32,114,49,51,53,48,32,99,49,51,53,49,32,105,109,112,111,114,116,45,101,110,118,49,51,53,50,32,109,97,99,114,111,45,101,110,118,49,51,53,51,32,109,101,116,97,63,49,51,53,52,32,108,111,99,49,51,53,53,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,14),40,102,95,55,57,55,57,32,120,50,50,57,56,41,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,18),40,102,95,55,57,56,53,32,114,117,108,101,115,50,51,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,13),40,97,56,49,50,56,32,120,50,51,49,57,41,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,17),40,102,95,56,48,55,57,32,114,117,108,101,50,51,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,30),40,102,95,56,49,54,51,32,105,110,112,117,116,50,51,50,49,32,112,97,116,116,101,114,110,50,51,50,50,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,30),40,102,95,56,51,56,52,32,105,110,112,117,116,50,51,55,49,32,112,97,116,116,101,114,110,50,51,55,50,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,52,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,30),40,102,95,56,53,48,50,32,105,110,112,117,116,50,51,56,56,32,112,97,116,116,101,114,110,50,51,56,57,41,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,13),40,97,56,56,50,56,32,120,50,52,52,57,41,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,52,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,39),40,102,95,56,55,57,48,32,112,97,116,116,101,114,110,50,52,51,56,32,112,97,116,104,50,52,51,57,32,109,97,112,105,116,50,52,52,48,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,50,53,51,51,32,100,50,53,51,57,32,103,101,110,50,53,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,37),40,102,95,56,57,57,55,32,116,101,109,112,108,97,116,101,50,52,57,50,32,100,105,109,50,52,57,51,32,101,110,118,50,52,57,52,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,37),40,102,95,57,50,53,49,32,112,97,116,116,101,114,110,50,53,54,54,32,100,105,109,50,53,54,55,32,118,97,114,115,50,53,54,56,41,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,46),40,102,95,57,51,50,52,32,116,101,109,112,108,97,116,101,50,53,55,55,32,100,105,109,50,53,55,56,32,101,110,118,50,53,55,57,32,102,114,101,101,50,53,56,48,41,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,49,55,32,112,97,116,116,101,114,110,50,53,57,53,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,51,57,32,112,97,116,116,101,114,110,50,54,48,53,41,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,54,53,32,112,97,116,116,101,114,110,50,54,49,49,41,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,97,116,116,101,114,110,50,54,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,56,53,32,112,97,116,116,101,114,110,50,54,49,51,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,79),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,115,121,110,116,97,120,45,114,117,108,101,115,32,101,108,108,105,112,115,105,115,50,50,51,57,32,114,117,108,101,115,50,50,52,48,32,115,117,98,107,101,121,119,111,114,100,115,50,50,52,49,32,114,50,50,52,50,32,99,50,50,52,51,41,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,13),40,109,111,100,117,108,101,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,20),40,109,111,100,117,108,101,45,101,120,112,111,114,116,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,46),40,115,101,116,45,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,56,54,50,55,49,55,32,121,50,54,56,55,50,55,49,56,41,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,41,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,19),40,109,111,100,117,108,101,45,101,120,105,115,116,45,108,105,115,116,41,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,28),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,115,121,110,116,97,120,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,48),40,115,101,116,45,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,56,54,50,55,52,49,32,121,50,54,56,55,50,55,52,50,41};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,32,120,50,54,56,54,50,55,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,26),40,109,111,100,117,108,101,45,109,101,116,97,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,25),40,109,111,100,117,108,101,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,118,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,115,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,51),40,109,97,107,101,45,109,111,100,117,108,101,32,101,120,112,108,105,115,116,50,56,49,51,32,118,101,120,112,111,114,116,115,50,56,49,52,32,115,101,120,112,111,114,116,115,50,56,49,53,41,0,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,102,105,110,100,45,109,111,100,117,108,101,32,110,97,109,101,50,56,50,53,32,46,32,116,109,112,50,56,50,52,50,56,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,64),40,35,35,115,121,115,35,116,111,112,108,101,118,101,108,45,100,101,102,105,110,105,116,105,111,110,45,104,111,111,107,32,115,121,109,50,56,53,50,32,109,111,100,50,56,53,51,32,101,120,112,50,56,53,52,32,118,97,108,50,56,53,53,41};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,50,56,53,57,41};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,42),40,99,104,101,99,107,45,102,111,114,45,114,101,100,101,102,32,115,121,109,50,56,54,56,32,101,110,118,50,56,54,57,32,115,101,110,118,50,56,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,101,120,112,111,114,116,32,115,121,109,50,56,56,53,32,109,111,100,50,56,56,54,41,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,115,121,110,116,97,120,45,101,120,112,111,114,116,32,115,121,109,50,57,49,48,32,109,111,100,50,57,49,49,32,118,97,108,50,57,49,50,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,117,110,100,101,102,105,110,101,100,32,115,121,109,50,57,51,54,32,109,111,100,50,57,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,50,57,54,52,32,115,101,120,112,111,114,116,115,50,57,55,53,41,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,18),40,100,101,102,45,115,101,120,112,111,114,116,115,50,57,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,58),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,32,110,97,109,101,50,57,53,51,32,101,120,112,108,105,115,116,50,57,53,52,32,46,32,116,109,112,50,57,53,50,50,57,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,16),40,97,49,48,48,57,50,32,105,109,112,50,57,57,57,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,109,97,114,107,45,105,109,112,111,114,116,101,100,45,115,121,109,98,111,108,115,32,115,101,50,57,57,55,41,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,21),40,119,97,114,110,32,109,115,103,51,48,51,56,32,105,100,51,48,51,57,41,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,50,32,105,101,120,112,111,114,116,115,51,48,53,52,41,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,101,120,112,111,114,116,115,51,48,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,105,110,100,105,114,101,99,116,45,101,120,112,111,114,116,115,32,109,111,100,51,48,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,101,51,49,48,53,41,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,18),40,109,101,114,103,101,45,115,101,32,115,101,115,51,48,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,100,51,49,55,55,41,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,20),40,97,49,48,54,55,48,32,115,101,120,112,111,114,116,51,49,53,49,41,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,51,56,32,105,101,51,49,52,49,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,45,114,101,103,105,115,116,114,97,116,105,111,110,32,109,111,100,51,49,50,49,41,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,17),40,97,49,48,57,51,55,32,110,101,120,112,51,50,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,17),40,97,49,48,57,52,55,32,105,101,120,112,51,50,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,17),40,97,49,48,57,54,55,32,115,101,120,112,51,50,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,15),40,97,49,48,57,56,53,32,110,101,51,50,51,51,41,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,15),40,97,49,49,48,48,51,32,105,101,51,50,50,57,41,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,15),40,97,49,49,48,51,53,32,115,101,51,50,50,53,41,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,94),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,32,110,97,109,101,51,50,48,50,32,105,101,120,112,111,114,116,115,51,50,48,51,32,118,101,120,112,111,114,116,115,51,50,48,52,32,115,101,120,112,111,114,116,115,51,50,48,53,32,46,32,116,109,112,51,50,48,49,51,50,48,54,41,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,15),40,97,49,49,49,48,57,32,115,101,51,50,56,54,41,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,15),40,97,49,49,49,50,55,32,118,101,51,50,56,49,41,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,69),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,105,109,105,116,105,118,101,45,109,111,100,117,108,101,32,110,97,109,101,51,50,54,51,32,118,101,120,112,111,114,116,115,51,50,54,52,32,46,32,116,109,112,51,50,54,50,51,50,54,53,41,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,51,48,55,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,102,105,110,100,45,101,120,112,111,114,116,32,115,121,109,51,50,57,57,32,109,111,100,51,51,48,48,32,105,110,100,105,114,101,99,116,51,51,48,49,41};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,14),40,97,49,49,51,57,51,32,109,51,52,50,54,41,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,16),40,97,49,49,52,52,49,32,101,120,112,51,52,48,55,41};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,14),40,97,49,49,52,55,57,32,117,51,52,48,49,41,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,51,55,51,41,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,51,53,56,41,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,16),40,97,49,49,54,55,50,32,115,121,109,51,51,53,50,41};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,110,97,108,105,122,101,45,109,111,100,117,108,101,32,109,111,100,51,51,52,48,41,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,52,53,49,41,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,109,97,99,114,111,45,115,117,98,115,101,116,32,109,101,48,51,52,52,55,41,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,28),40,97,49,49,55,51,57,32,101,120,112,50,50,50,51,32,114,50,50,50,52,32,99,50,50,50,53,41,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,16),40,97,49,49,56,48,54,32,101,120,112,50,49,57,57,41};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,55,54,32,120,50,49,57,48,32,114,50,49,57,49,32,99,50,49,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,26),40,97,49,49,56,55,57,32,120,50,49,55,48,32,114,50,49,55,49,32,99,50,49,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,26),40,97,49,49,57,51,51,32,120,50,49,54,48,32,114,50,49,54,49,32,99,50,49,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,26),40,97,49,49,57,56,52,32,120,50,49,52,57,32,114,50,49,53,48,32,99,50,49,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,26),40,97,49,50,48,48,53,32,120,50,49,51,56,32,114,50,49,51,57,32,99,50,49,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,11),40,101,114,114,32,120,50,48,53,51,41,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,13),40,116,101,115,116,32,102,120,50,48,53,53,41,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,14),40,97,49,50,50,50,51,32,120,50,49,48,57,41,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,99,108,115,50,49,48,48,41};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,29),40,97,49,50,48,50,54,32,102,111,114,109,50,48,52,48,32,114,50,48,52,49,32,99,50,48,52,50,41,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,29),40,97,49,50,51,49,48,32,102,111,114,109,50,48,51,48,32,114,50,48,51,49,32,99,50,48,51,50,41,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,57,50,50,32,110,49,57,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,19),40,119,97,108,107,49,32,120,49,57,50,53,32,110,49,57,50,54,41,0,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,16),40,115,105,109,112,108,105,102,121,32,120,49,57,57,48,41};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,29),40,97,49,50,51,52,51,32,102,111,114,109,49,57,49,48,32,114,49,57,49,49,32,99,49,57,49,50,41,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,14),40,97,49,50,56,52,51,32,98,49,57,48,54,41,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,14),40,97,49,50,56,57,56,32,98,49,56,57,52,41,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,29),40,97,49,50,55,51,56,32,102,111,114,109,49,56,55,56,32,114,49,56,55,57,32,99,49,56,56,48,41,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,15),40,101,120,112,97,110,100,32,98,115,49,56,54,52,41,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,29),40,97,49,50,57,50,48,32,102,111,114,109,49,56,53,52,32,114,49,56,53,53,32,99,49,56,53,54,41,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,14),40,97,49,51,49,49,51,32,120,49,56,52,51,41,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,56,51,48,41,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,29),40,97,49,50,57,56,57,32,102,111,114,109,49,56,49,48,32,114,49,56,49,49,32,99,49,56,49,50,41,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,55,54,54,41,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,29),40,97,49,51,49,53,57,32,102,111,114,109,49,55,53,49,32,114,49,55,53,50,32,99,49,55,53,51,41,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,29),40,97,49,51,52,57,50,32,102,111,114,109,49,55,51,53,32,114,49,55,51,54,32,99,49,55,51,55,41,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,29),40,97,49,51,53,56,50,32,102,111,114,109,49,55,50,49,32,114,49,55,50,50,32,99,49,55,50,51,41,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,102,111,114,109,49,54,57,48,41,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,29),40,97,49,51,54,52,49,32,102,111,114,109,49,54,56,52,32,114,49,54,56,53,32,99,49,54,56,54,41,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,50),40,97,49,51,55,56,51,32,103,49,54,55,50,49,54,55,51,49,54,55,56,32,103,49,54,55,52,49,54,55,53,49,54,55,57,32,103,49,54,55,54,49,54,55,55,49,54,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,50),40,97,49,51,55,57,51,32,103,49,54,53,54,49,54,53,55,49,54,54,50,32,103,49,54,53,56,49,54,53,57,49,54,54,51,32,103,49,54,54,48,49,54,54,49,49,54,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_expand_toplevel)
C_externexport void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13794)
static void C_ccall f_13794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13792)
static void C_ccall f_13792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13784)
static void C_ccall f_13784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13782)
static void C_ccall f_13782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7829)
static void C_ccall f_7829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7833)
static void C_ccall f_7833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13642)
static void C_ccall f_13642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13652)
static void C_fcall f_13652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13668)
static void C_ccall f_13668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13671)
static void C_ccall f_13671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13699)
static void C_ccall f_13699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13674)
static void C_ccall f_13674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13721)
static void C_ccall f_13721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13724)
static void C_ccall f_13724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13770)
static void C_ccall f_13770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13727)
static void C_ccall f_13727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13750)
static void C_ccall f_13750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13762)
static void C_ccall f_13762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13708)
static void C_ccall f_13708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13711)
static void C_ccall f_13711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13718)
static void C_ccall f_13718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13640)
static void C_ccall f_13640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7836)
static void C_ccall f_7836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13583)
static void C_ccall f_13583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13612)
static void C_ccall f_13612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13632)
static void C_ccall f_13632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13636)
static void C_ccall f_13636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13581)
static void C_ccall f_13581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13493)
static void C_ccall f_13493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13518)
static void C_ccall f_13518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13525)
static void C_ccall f_13525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13545)
static void C_ccall f_13545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13565)
static void C_ccall f_13565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13569)
static void C_ccall f_13569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13491)
static void C_ccall f_13491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7842)
static void C_ccall f_7842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13160)
static void C_ccall f_13160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13167)
static void C_ccall f_13167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13170)
static void C_ccall f_13170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13173)
static void C_ccall f_13173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13176)
static void C_ccall f_13176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13179)
static void C_ccall f_13179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13182)
static void C_ccall f_13182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13185)
static void C_ccall f_13185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13190)
static void C_fcall f_13190(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13206)
static void C_ccall f_13206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13212)
static void C_ccall f_13212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13254)
static void C_ccall f_13254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13322)
static void C_ccall f_13322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13447)
static void C_ccall f_13447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13443)
static void C_ccall f_13443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13325)
static void C_ccall f_13325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13380)
static void C_ccall f_13380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13257)
static void C_ccall f_13257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13296)
static void C_ccall f_13296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13248)
static void C_ccall f_13248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13219)
static void C_ccall f_13219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13158)
static void C_ccall f_13158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12990)
static void C_ccall f_12990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12994)
static void C_ccall f_12994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13003)
static void C_ccall f_13003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13006)
static void C_ccall f_13006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13009)
static void C_ccall f_13009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13012)
static void C_ccall f_13012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13015)
static void C_ccall f_13015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13036)
static void C_fcall f_13036(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13052)
static void C_ccall f_13052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13058)
static void C_ccall f_13058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13114)
static void C_ccall f_13114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13112)
static void C_ccall f_13112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13108)
static void C_ccall f_13108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13100)
static void C_ccall f_13100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13096)
static void C_ccall f_13096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13065)
static void C_ccall f_13065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13034)
static void C_ccall f_13034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12988)
static void C_ccall f_12988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12921)
static void C_ccall f_12921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12925)
static void C_ccall f_12925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12934)
static void C_ccall f_12934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12939)
static void C_fcall f_12939(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12976)
static void C_ccall f_12976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12957)
static void C_ccall f_12957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12919)
static void C_ccall f_12919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12739)
static void C_ccall f_12739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12743)
static void C_ccall f_12743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12755)
static void C_ccall f_12755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12758)
static void C_ccall f_12758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12761)
static void C_ccall f_12761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12764)
static void C_ccall f_12764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12899)
static void C_ccall f_12899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12779)
static void C_ccall f_12779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12897)
static void C_ccall f_12897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12806)
static void C_fcall f_12806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12887)
static void C_ccall f_12887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12822)
static void C_fcall f_12822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12844)
static void C_ccall f_12844(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12842)
static void C_ccall f_12842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12838)
static void C_ccall f_12838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12737)
static void C_ccall f_12737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12344)
static void C_ccall f_12344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12348)
static void C_ccall f_12348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12351)
static void C_ccall f_12351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12354)
static void C_ccall f_12354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12357)
static void C_ccall f_12357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12726)
static void C_ccall f_12726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12638)
static void C_fcall f_12638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12642)
static void C_ccall f_12642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12667)
static void C_ccall f_12667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12713)
static void C_ccall f_12713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12698)
static void C_ccall f_12698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12369)
static void C_fcall f_12369(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12416)
static void C_ccall f_12416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12463)
static void C_ccall f_12463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12624)
static void C_ccall f_12624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12632)
static void C_ccall f_12632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12610)
static void C_ccall f_12610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12599)
static void C_ccall f_12599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12607)
static void C_ccall f_12607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12584)
static void C_ccall f_12584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12572)
static void C_ccall f_12572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12553)
static void C_ccall f_12553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12511)
static void C_ccall f_12511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12488)
static void C_ccall f_12488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12442)
static void C_ccall f_12442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12391)
static void C_ccall f_12391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12387)
static void C_ccall f_12387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12359)
static void C_fcall f_12359(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12367)
static void C_ccall f_12367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12342)
static void C_ccall f_12342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12311)
static void C_ccall f_12311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12315)
static void C_ccall f_12315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12309)
static void C_ccall f_12309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12027)
static void C_ccall f_12027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12034)
static void C_ccall f_12034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12037)
static void C_ccall f_12037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12040)
static void C_ccall f_12040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12043)
static void C_ccall f_12043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12046)
static void C_ccall f_12046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12208)
static void C_fcall f_12208(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12261)
static void C_ccall f_12261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12283)
static void C_ccall f_12283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12290)
static void C_ccall f_12290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12277)
static void C_ccall f_12277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12224)
static void C_ccall f_12224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12222)
static void C_ccall f_12222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12058)
static void C_fcall f_12058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12089)
static void C_ccall f_12089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12135)
static void C_ccall f_12135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12185)
static void C_ccall f_12185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12192)
static void C_ccall f_12192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12150)
static void C_ccall f_12150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12164)
static void C_ccall f_12164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12107)
static void C_ccall f_12107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12118)
static void C_ccall f_12118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12048)
static void C_fcall f_12048(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12025)
static void C_ccall f_12025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12006)
static void C_ccall f_12006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12004)
static void C_ccall f_12004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11985)
static void C_ccall f_11985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11983)
static void C_ccall f_11983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11934)
static void C_ccall f_11934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11938)
static void C_ccall f_11938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11975)
static void C_ccall f_11975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11968)
static void C_ccall f_11968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11961)
static void C_ccall f_11961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11932)
static void C_ccall f_11932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11880)
static void C_ccall f_11880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11884)
static void C_ccall f_11884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11887)
static void C_ccall f_11887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11924)
static void C_ccall f_11924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11890)
static void C_ccall f_11890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11905)
static void C_ccall f_11905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11909)
static void C_ccall f_11909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11878)
static void C_ccall f_11878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11777)
static void C_ccall f_11777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11784)
static void C_ccall f_11784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11787)
static void C_ccall f_11787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11807)
static void C_ccall f_11807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11829)
static C_word C_fcall f_11829(C_word t0);
C_noret_decl(f_11814)
static void C_fcall f_11814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11790)
static void C_ccall f_11790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11805)
static void C_ccall f_11805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11797)
static void C_ccall f_11797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11793)
static void C_ccall f_11793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11775)
static void C_ccall f_11775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_ccall f_7878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11740)
static void C_ccall f_11740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11744)
static void C_ccall f_11744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11762)
static void C_ccall f_11762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11753)
static void C_fcall f_11753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11738)
static void C_ccall f_11738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9526)
static void C_ccall f_9526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11734)
static void C_ccall f_11734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9530)
static void C_ccall f_9530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9534)
static void C_ccall f_9534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11692)
static void C_ccall f_11692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11700)
static void C_ccall f_11700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11702)
static void C_fcall f_11702(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11723)
static void C_ccall f_11723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11258)
static void C_ccall f_11258(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11673)
static void C_ccall f_11673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11685)
static void C_ccall f_11685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11274)
static void C_ccall f_11274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11630)
static void C_ccall f_11630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11632)
static void C_fcall f_11632(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11671)
static void C_ccall f_11671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11645)
static void C_ccall f_11645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11656)
static void C_ccall f_11656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11277)
static void C_ccall f_11277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11500)
static void C_fcall f_11500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11551)
static void C_fcall f_11551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11604)
static void C_ccall f_11604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11563)
static void C_fcall f_11563(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11590)
static void C_ccall f_11590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11586)
static void C_ccall f_11586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11566)
static void C_ccall f_11566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11548)
static void C_ccall f_11548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11537)
static void C_ccall f_11537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11280)
static void C_ccall f_11280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11494)
static void C_ccall f_11494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11480)
static void C_ccall f_11480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11283)
static void C_ccall f_11283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11478)
static void C_ccall f_11478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11442)
static void C_ccall f_11442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11470)
static void C_ccall f_11470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11286)
static void C_ccall f_11286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11436)
static void C_ccall f_11436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11440)
static void C_ccall f_11440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11289)
static void C_ccall f_11289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11292)
static void C_ccall f_11292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11394)
static void C_ccall f_11394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11398)
static void C_ccall f_11398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11428)
static void C_ccall f_11428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11424)
static void C_ccall f_11424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11401)
static void C_ccall f_11401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11295)
static void C_ccall f_11295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11392)
static void C_ccall f_11392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11388)
static void C_ccall f_11388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11384)
static void C_ccall f_11384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11380)
static void C_ccall f_11380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11376)
static void C_ccall f_11376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11372)
static void C_ccall f_11372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11368)
static void C_ccall f_11368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11364)
static void C_ccall f_11364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11360)
static void C_ccall f_11360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11298)
static void C_ccall f_11298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11301)
static void C_ccall f_11301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11173)
static void C_ccall f_11173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11184)
static void C_ccall f_11184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11186)
static void C_fcall f_11186(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11235)
static void C_ccall f_11235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11231)
static void C_ccall f_11231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11214)
static void C_fcall f_11214(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11082)
static void C_ccall f_11082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11082)
static void C_ccall f_11082r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11086)
static void C_ccall f_11086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11089)
static void C_ccall f_11089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11128)
static void C_ccall f_11128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11148)
static void C_ccall f_11148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11138)
static void C_ccall f_11138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11141)
static void C_ccall f_11141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11104)
static void C_ccall f_11104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11110)
static void C_ccall f_11110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11108)
static void C_ccall f_11108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10874)
static void C_ccall f_10874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_10874)
static void C_ccall f_10874r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_10878)
static void C_ccall f_10878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11036)
static void C_ccall f_11036(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11057)
static void C_ccall f_11057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10901)
static void C_ccall f_10901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10904)
static void C_ccall f_10904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11004)
static void C_ccall f_11004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11026)
static void C_ccall f_11026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10907)
static void C_ccall f_10907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10986)
static void C_ccall f_10986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10910)
static void C_ccall f_10910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10980)
static void C_ccall f_10980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10984)
static void C_ccall f_10984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10916)
static void C_ccall f_10916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10919)
static void C_ccall f_10919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10968)
static void C_ccall f_10968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10922)
static void C_ccall f_10922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10948)
static void C_ccall f_10948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10925)
static void C_ccall f_10925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10938)
static void C_ccall f_10938(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10928)
static void C_ccall f_10928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10494)
static void C_ccall f_10494(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10872)
static void C_ccall f_10872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10517)
static void C_fcall f_10517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10842)
static void C_ccall f_10842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10525)
static void C_fcall f_10525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10824)
static void C_ccall f_10824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10533)
static void C_ccall f_10533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10812)
static void C_ccall f_10812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10739)
static void C_ccall f_10739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10737)
static void C_ccall f_10737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10733)
static void C_ccall f_10733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10671)
static void C_ccall f_10671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10714)
static void C_ccall f_10714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10669)
static void C_ccall f_10669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10665)
static void C_ccall f_10665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10595)
static void C_fcall f_10595(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10661)
static void C_ccall f_10661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10618)
static void C_ccall f_10618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10657)
static void C_ccall f_10657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10649)
static void C_ccall f_10649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10629)
static void C_ccall f_10629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10589)
static void C_ccall f_10589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10585)
static void C_ccall f_10585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10529)
static void C_ccall f_10529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10521)
static void C_ccall f_10521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10422)
static void C_fcall f_10422(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10426)
static void C_ccall f_10426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10429)
static void C_ccall f_10429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10441)
static void C_fcall f_10441(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10480)
static void C_ccall f_10480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10472)
static void C_ccall f_10472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10432)
static void C_ccall f_10432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10435)
static void C_ccall f_10435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10146)
static void C_fcall f_10146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10227)
static void C_fcall f_10227(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10254)
static void C_ccall f_10254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10256)
static void C_fcall f_10256(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10416)
static void C_ccall f_10416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10404)
static void C_ccall f_10404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10385)
static void C_ccall f_10385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10367)
static void C_ccall f_10367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10352)
static void C_ccall f_10352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10322)
static void C_ccall f_10322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10307)
static void C_ccall f_10307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10279)
static void C_ccall f_10279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10204)
static void C_fcall f_10204(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10216)
static void C_ccall f_10216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10212)
static void C_ccall f_10212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10087)
static void C_ccall f_10087(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10093)
static void C_ccall f_10093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10100)
static void C_fcall f_10100(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10103)
static void C_ccall f_10103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10019)
static void C_ccall f_10019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10019)
static void C_ccall f_10019r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10039)
static C_word C_fcall f_10039(C_word *a,C_word t0);
C_noret_decl(f_10034)
static C_word C_fcall f_10034(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_10021)
static C_word C_fcall f_10021(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9997)
static void C_ccall f_9997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10004)
static void C_ccall f_10004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9916)
static void C_ccall f_9916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9926)
static void C_ccall f_9926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9929)
static void C_ccall f_9929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9935)
static void C_ccall f_9935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9978)
static void C_ccall f_9978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9982)
static void C_ccall f_9982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9938)
static void C_ccall f_9938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9941)
static void C_ccall f_9941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9944)
static void C_ccall f_9944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9827)
static void C_ccall f_9827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9837)
static void C_ccall f_9837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9840)
static void C_ccall f_9840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9903)
static void C_ccall f_9903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9843)
static void C_ccall f_9843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9899)
static void C_ccall f_9899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9846)
static void C_ccall f_9846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9885)
static void C_ccall f_9885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9889)
static void C_ccall f_9889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9849)
static void C_ccall f_9849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9852)
static void C_ccall f_9852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9858)
static void C_ccall f_9858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9806)
static void C_fcall f_9806(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9813)
static void C_ccall f_9813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9786)
static void C_ccall f_9786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9790)
static void C_ccall f_9790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9783)
static void C_ccall f_9783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9743)
static void C_ccall f_9743(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9743)
static void C_ccall f_9743r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9747)
static void C_ccall f_9747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9737)
static C_word C_fcall f_9737(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3);
C_noret_decl(f_9728)
static C_word C_fcall f_9728(C_word t0);
C_noret_decl(f_9710)
static C_word C_fcall f_9710(C_word t0);
C_noret_decl(f_9692)
static C_word C_fcall f_9692(C_word t0);
C_noret_decl(f_9674)
static C_word C_fcall f_9674(C_word t0);
C_noret_decl(f_9656)
static C_word C_fcall f_9656(C_word t0);
C_noret_decl(f_9638)
static void C_ccall f_9638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9629)
static void C_ccall f_9629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9620)
static C_word C_fcall f_9620(C_word t0);
C_noret_decl(f_9602)
static C_word C_fcall f_9602(C_word t0);
C_noret_decl(f_9584)
static C_word C_fcall f_9584(C_word t0);
C_noret_decl(f_9575)
static void C_fcall f_9575(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9566)
static C_word C_fcall f_9566(C_word t0);
C_noret_decl(f_9548)
static C_word C_fcall f_9548(C_word t0);
C_noret_decl(f_7883)
static void C_ccall f_7883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7908)
static void C_ccall f_7908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7917)
static void C_ccall f_7917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7923)
static void C_ccall f_7923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7927)
static void C_ccall f_7927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7931)
static void C_ccall f_7931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7935)
static void C_ccall f_7935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7944)
static void C_ccall f_7944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7955)
static void C_ccall f_7955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7960)
static void C_ccall f_7960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7964)
static void C_ccall f_7964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7968)
static void C_ccall f_7968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7972)
static void C_ccall f_7972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7977)
static void C_ccall f_7977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9485)
static void C_ccall f_9485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9495)
static void C_fcall f_9495(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9502)
static void C_ccall f_9502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9465)
static void C_ccall f_9465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9472)
static void C_ccall f_9472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9479)
static void C_ccall f_9479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9439)
static void C_ccall f_9439(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9417)
static void C_ccall f_9417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9424)
static void C_ccall f_9424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9324)
static void C_ccall f_9324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9366)
static void C_ccall f_9366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9415)
static void C_ccall f_9415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9398)
static void C_ccall f_9398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9377)
static void C_ccall f_9377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9337)
static void C_fcall f_9337(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9251)
static void C_ccall f_9251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9277)
static void C_ccall f_9277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9322)
static void C_ccall f_9322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9305)
static void C_ccall f_9305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8997)
static void C_ccall f_8997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9044)
static void C_ccall f_9044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9242)
static void C_ccall f_9242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9238)
static void C_ccall f_9238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9205)
static void C_ccall f_9205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9213)
static void C_ccall f_9213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9047)
static void C_ccall f_9047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9053)
static void C_ccall f_9053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9065)
static void C_ccall f_9065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9131)
static void C_fcall f_9131(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9146)
static void C_ccall f_9146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9068)
static void C_fcall f_9068(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9102)
static void C_fcall f_9102(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9071)
static void C_ccall f_9071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9100)
static void C_ccall f_9100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9096)
static void C_ccall f_9096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9092)
static void C_ccall f_9092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8790)
static void C_ccall f_8790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8820)
static void C_ccall f_8820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8920)
static void C_ccall f_8920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8943)
static void C_fcall f_8943(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8957)
static void C_ccall f_8957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8961)
static void C_ccall f_8961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8930)
static void C_ccall f_8930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8880)
static void C_ccall f_8880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8884)
static void C_ccall f_8884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8829)
static void C_ccall f_8829(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8837)
static void C_fcall f_8837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8814)
static void C_ccall f_8814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8502)
static void C_ccall f_8502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8509)
static void C_ccall f_8509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8548)
static void C_fcall f_8548(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8558)
static void C_fcall f_8558(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8689)
static void C_ccall f_8689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8693)
static void C_ccall f_8693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8622)
static void C_ccall f_8622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8618)
static void C_ccall f_8618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8556)
static void C_ccall f_8556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8552)
static void C_ccall f_8552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8384)
static void C_ccall f_8384(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8388)
static void C_ccall f_8388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8163)
static void C_ccall f_8163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8327)
static void C_fcall f_8327(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8273)
static void C_ccall f_8273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8079)
static void C_ccall f_8079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8086)
static void C_fcall f_8086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8089)
static void C_ccall f_8089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8138)
static void C_ccall f_8138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8134)
static void C_ccall f_8134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8129)
static void C_ccall f_8129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8115)
static void C_ccall f_8115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8123)
static void C_ccall f_8123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7985)
static void C_ccall f_7985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8029)
static void C_ccall f_8029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8025)
static void C_ccall f_8025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7979)
static void C_ccall f_7979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6981)
static void C_ccall f_6981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6985)
static void C_ccall f_6985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6988)
static void C_ccall f_6988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6994)
static void C_ccall f_6994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7593)
static void C_ccall f_7593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7596)
static void C_ccall f_7596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7815)
static void C_ccall f_7815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7800)
static void C_ccall f_7800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7599)
static void C_ccall f_7599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7604)
static void C_ccall f_7604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7608)
static void C_ccall f_7608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7617)
static void C_ccall f_7617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7775)
static void C_ccall f_7775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7620)
static void C_ccall f_7620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7623)
static void C_ccall f_7623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7626)
static void C_ccall f_7626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7698)
static void C_ccall f_7698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7629)
static void C_ccall f_7629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7656)
static void C_ccall f_7656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7632)
static void C_ccall f_7632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7654)
static void C_ccall f_7654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7642)
static void C_ccall f_7642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7602)
static void C_ccall f_7602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7135)
static void C_fcall f_7135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7154)
static void C_fcall f_7154(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7163)
static void C_ccall f_7163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7175)
static void C_ccall f_7175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7255)
static void C_ccall f_7255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7509)
static void C_ccall f_7509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7512)
static void C_ccall f_7512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7548)
static void C_ccall f_7548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7552)
static void C_ccall f_7552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7517)
static void C_ccall f_7517(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7525)
static void C_ccall f_7525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7365)
static void C_ccall f_7365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7374)
static void C_fcall f_7374(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7503)
static void C_ccall f_7503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7484)
static void C_ccall f_7484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7432)
static void C_ccall f_7432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7420)
static void C_ccall f_7420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7395)
static void C_ccall f_7395(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7390)
static void C_ccall f_7390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7258)
static void C_ccall f_7258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7261)
static void C_ccall f_7261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7266)
static void C_fcall f_7266(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7352)
static void C_ccall f_7352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7278)
static void C_fcall f_7278(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7178)
static void C_ccall f_7178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7181)
static void C_ccall f_7181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7186)
static void C_fcall f_7186(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7048)
static void C_fcall f_7048(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7052)
static void C_ccall f_7052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7129)
static void C_ccall f_7129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7076)
static void C_ccall f_7076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7079)
static void C_ccall f_7079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7098)
static void C_ccall f_7098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7105)
static void C_ccall f_7105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7108)
static void C_ccall f_7108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7005)
static void C_fcall f_7005(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7018)
static void C_ccall f_7018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6996)
static void C_ccall f_6996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7000)
static void C_ccall f_7000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6689)
static void C_ccall f_6689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6941)
static void C_ccall f_6941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6854)
static void C_fcall f_6854(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6935)
static void C_ccall f_6935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6860)
static void C_fcall f_6860(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6929)
static void C_ccall f_6929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6886)
static void C_ccall f_6886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_fcall f_6822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6825)
static void C_ccall f_6825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_fcall f_6955(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6692)
static void C_ccall f_6692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6728)
static void C_ccall f_6728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6792)
static void C_ccall f_6792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6702)
static void C_ccall f_6702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6639)
static void C_fcall f_6639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6630)
static void C_fcall f_6630(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_fcall f_6227(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6358)
static void C_fcall f_6358(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6560)
static void C_ccall f_6560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6564)
static void C_ccall f_6564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6382)
static void C_fcall f_6382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_fcall f_6387(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6329)
static void C_ccall f_6329(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6335)
static C_word C_fcall f_6335(C_word t0);
C_noret_decl(f_6273)
static void C_ccall f_6273(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6277)
static void C_ccall f_6277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_fcall f_6285(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6305)
static void C_ccall f_6305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6230)
static void C_fcall f_6230(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6237)
static void C_ccall f_6237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6242)
static void C_fcall f_6242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6271)
static void C_ccall f_6271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6260)
static void C_ccall f_6260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6189)
static void C_ccall f_6189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6211)
static void C_ccall f_6211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6108)
static void C_ccall f_6108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6111)
static void C_fcall f_6111(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6025)
static void C_fcall f_6025(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_fcall f_6028(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5715)
static void C_fcall f_5715(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5721)
static void C_fcall f_5721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5985)
static void C_ccall f_5985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5743)
static void C_fcall f_5743(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5953)
static void C_ccall f_5953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5887)
static void C_ccall f_5887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5766)
static void C_fcall f_5766(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5835)
static void C_ccall f_5835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_fcall f_5538(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5548)
static void C_fcall f_5548(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5693)
static void C_ccall f_5693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5683)
static void C_ccall f_5683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5594)
static void C_fcall f_5594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5650)
static void C_ccall f_5650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_fcall f_5612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5278)
static void C_fcall f_5278(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_ccall f_5431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5395)
static void C_ccall f_5395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5304)
static void C_ccall f_5304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5379)
static void C_ccall f_5379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5313)
static void C_fcall f_5313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_ccall f_4705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4711)
static void C_ccall f_4711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4719)
static void C_fcall f_4719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5209)
static void C_fcall f_5209(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5128)
static void C_fcall f_5128(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5082)
static void C_fcall f_5082(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5085)
static void C_fcall f_5085(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5045)
static void C_fcall f_5045(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_fcall f_5007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4941)
static void C_fcall f_4941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_fcall f_4737(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4749)
static void C_fcall f_4749(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4768)
static void C_ccall f_4768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_fcall f_4740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_fcall f_4685(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4645)
static void C_fcall f_4645(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4664)
static void C_fcall f_4664(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_fcall f_4595(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_fcall f_4499(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_fcall f_4301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_fcall f_4403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_fcall f_4178(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4238)
static void C_fcall f_4238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_fcall f_4250(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_fcall f_3999(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_fcall f_4037(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_fcall f_4054(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4073)
static void C_fcall f_4073(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_fcall f_4034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_fcall f_3950(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3779)
static void C_fcall f_3779(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_fcall f_3774(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3681)
static void C_fcall f_3681(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_fcall f_3703(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_fcall f_3649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3600)
static void C_fcall f_3600(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_fcall f_3610(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3582)
static void C_fcall f_3582(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

C_noret_decl(trf_13652)
static void C_fcall trf_13652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13652(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13652(t0,t1,t2);}

C_noret_decl(trf_13190)
static void C_fcall trf_13190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13190(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13190(t0,t1,t2);}

C_noret_decl(trf_13036)
static void C_fcall trf_13036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13036(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13036(t0,t1,t2);}

C_noret_decl(trf_12939)
static void C_fcall trf_12939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12939(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12939(t0,t1,t2);}

C_noret_decl(trf_12806)
static void C_fcall trf_12806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12806(t0,t1);}

C_noret_decl(trf_12822)
static void C_fcall trf_12822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12822(t0,t1);}

C_noret_decl(trf_12638)
static void C_fcall trf_12638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12638(t0,t1,t2);}

C_noret_decl(trf_12369)
static void C_fcall trf_12369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12369(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12369(t0,t1,t2,t3);}

C_noret_decl(trf_12359)
static void C_fcall trf_12359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12359(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12359(t0,t1,t2,t3);}

C_noret_decl(trf_12208)
static void C_fcall trf_12208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12208(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12208(t0,t1,t2);}

C_noret_decl(trf_12058)
static void C_fcall trf_12058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12058(t0,t1,t2);}

C_noret_decl(trf_12048)
static void C_fcall trf_12048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12048(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12048(t0,t1,t2);}

C_noret_decl(trf_11814)
static void C_fcall trf_11814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11814(t0,t1);}

C_noret_decl(trf_11753)
static void C_fcall trf_11753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11753(t0,t1);}

C_noret_decl(trf_11702)
static void C_fcall trf_11702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11702(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11702(t0,t1,t2);}

C_noret_decl(trf_11632)
static void C_fcall trf_11632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11632(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11632(t0,t1,t2);}

C_noret_decl(trf_11500)
static void C_fcall trf_11500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11500(t0,t1,t2);}

C_noret_decl(trf_11551)
static void C_fcall trf_11551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11551(t0,t1);}

C_noret_decl(trf_11563)
static void C_fcall trf_11563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11563(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11563(t0,t1);}

C_noret_decl(trf_11186)
static void C_fcall trf_11186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11186(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11186(t0,t1,t2);}

C_noret_decl(trf_11214)
static void C_fcall trf_11214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11214(t0,t1);}

C_noret_decl(trf_10517)
static void C_fcall trf_10517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10517(t0,t1);}

C_noret_decl(trf_10525)
static void C_fcall trf_10525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10525(t0,t1);}

C_noret_decl(trf_10595)
static void C_fcall trf_10595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10595(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10595(t0,t1,t2);}

C_noret_decl(trf_10422)
static void C_fcall trf_10422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10422(t0,t1);}

C_noret_decl(trf_10441)
static void C_fcall trf_10441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10441(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10441(t0,t1,t2);}

C_noret_decl(trf_10146)
static void C_fcall trf_10146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10146(t0,t1);}

C_noret_decl(trf_10227)
static void C_fcall trf_10227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10227(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10227(t0,t1,t2);}

C_noret_decl(trf_10256)
static void C_fcall trf_10256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10256(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10256(t0,t1,t2);}

C_noret_decl(trf_10204)
static void C_fcall trf_10204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10204(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10204(t0,t1,t2,t3);}

C_noret_decl(trf_10100)
static void C_fcall trf_10100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10100(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10100(t0,t1);}

C_noret_decl(trf_9806)
static void C_fcall trf_9806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9806(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9806(t0,t1,t2,t3);}

C_noret_decl(trf_9575)
static void C_fcall trf_9575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9575(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9575(t0,t1,t2);}

C_noret_decl(trf_9495)
static void C_fcall trf_9495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9495(t0,t1,t2);}

C_noret_decl(trf_9337)
static void C_fcall trf_9337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9337(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9337(t0,t1);}

C_noret_decl(trf_9131)
static void C_fcall trf_9131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9131(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9131(t0,t1);}

C_noret_decl(trf_9068)
static void C_fcall trf_9068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9068(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9068(t0,t1);}

C_noret_decl(trf_9102)
static void C_fcall trf_9102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9102(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9102(t0,t1,t2,t3);}

C_noret_decl(trf_8943)
static void C_fcall trf_8943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8943(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8943(t0,t1,t2);}

C_noret_decl(trf_8837)
static void C_fcall trf_8837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8837(t0,t1);}

C_noret_decl(trf_8548)
static void C_fcall trf_8548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8548(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8548(t0,t1);}

C_noret_decl(trf_8558)
static void C_fcall trf_8558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8558(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8558(t0,t1,t2);}

C_noret_decl(trf_8327)
static void C_fcall trf_8327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8327(t0,t1);}

C_noret_decl(trf_8086)
static void C_fcall trf_8086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8086(t0,t1);}

C_noret_decl(trf_7135)
static void C_fcall trf_7135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7135(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7135(t0,t1,t2);}

C_noret_decl(trf_7154)
static void C_fcall trf_7154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7154(t0,t1);}

C_noret_decl(trf_7374)
static void C_fcall trf_7374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7374(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7374(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7266)
static void C_fcall trf_7266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7266(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7266(t0,t1,t2,t3);}

C_noret_decl(trf_7278)
static void C_fcall trf_7278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7278(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7278(t0,t1,t2,t3);}

C_noret_decl(trf_7186)
static void C_fcall trf_7186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7186(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7186(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7048)
static void C_fcall trf_7048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7048(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7048(t0,t1,t2);}

C_noret_decl(trf_7005)
static void C_fcall trf_7005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7005(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7005(t0,t1,t2);}

C_noret_decl(trf_6854)
static void C_fcall trf_6854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6854(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6854(t0,t1);}

C_noret_decl(trf_6860)
static void C_fcall trf_6860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6860(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6860(t0,t1);}

C_noret_decl(trf_6822)
static void C_fcall trf_6822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6822(t0,t1);}

C_noret_decl(trf_6955)
static void C_fcall trf_6955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6955(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6955(t0,t1,t2,t3);}

C_noret_decl(trf_6639)
static void C_fcall trf_6639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6639(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6639(t0,t1);}

C_noret_decl(trf_6630)
static void C_fcall trf_6630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6630(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6630(t0,t1,t2);}

C_noret_decl(trf_6227)
static void C_fcall trf_6227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6227(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6227(t0,t1,t2,t3);}

C_noret_decl(trf_6358)
static void C_fcall trf_6358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6358(t0,t1);}

C_noret_decl(trf_6363)
static void C_fcall trf_6363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6363(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6363(t0,t1,t2,t3);}

C_noret_decl(trf_6382)
static void C_fcall trf_6382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6382(t0,t1);}

C_noret_decl(trf_6387)
static void C_fcall trf_6387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6387(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6387(t0,t1,t2,t3);}

C_noret_decl(trf_6285)
static void C_fcall trf_6285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6285(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6285(t0,t1,t2);}

C_noret_decl(trf_6230)
static void C_fcall trf_6230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6230(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6230(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6242)
static void C_fcall trf_6242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6242(t0,t1,t2);}

C_noret_decl(trf_6111)
static void C_fcall trf_6111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6111(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6111(t0,t1,t2,t3);}

C_noret_decl(trf_6025)
static void C_fcall trf_6025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6025(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6025(t0,t1,t2,t3);}

C_noret_decl(trf_6028)
static void C_fcall trf_6028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6028(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6028(t0,t1,t2,t3);}

C_noret_decl(trf_5715)
static void C_fcall trf_5715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5715(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5715(t0,t1,t2);}

C_noret_decl(trf_5721)
static void C_fcall trf_5721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5721(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5721(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5743)
static void C_fcall trf_5743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5743(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5743(t0,t1);}

C_noret_decl(trf_5766)
static void C_fcall trf_5766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5766(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5766(t0,t1,t2);}

C_noret_decl(trf_5538)
static void C_fcall trf_5538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5538(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5538(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5548)
static void C_fcall trf_5548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5548(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5548(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5594)
static void C_fcall trf_5594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5594(t0,t1);}

C_noret_decl(trf_5612)
static void C_fcall trf_5612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5612(t0,t1);}

C_noret_decl(trf_5278)
static void C_fcall trf_5278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5278(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5278(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5290)
static void C_fcall trf_5290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5290(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5290(t0,t1,t2,t3);}

C_noret_decl(trf_5313)
static void C_fcall trf_5313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5313(t0,t1);}

C_noret_decl(trf_4719)
static void C_fcall trf_4719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4719(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4719(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5209)
static void C_fcall trf_5209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5209(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5209(t0,t1);}

C_noret_decl(trf_5128)
static void C_fcall trf_5128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5128(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5128(t0,t1);}

C_noret_decl(trf_5082)
static void C_fcall trf_5082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5082(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5082(t0,t1);}

C_noret_decl(trf_5085)
static void C_fcall trf_5085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5085(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5085(t0,t1);}

C_noret_decl(trf_5045)
static void C_fcall trf_5045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5045(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5045(t0,t1);}

C_noret_decl(trf_5007)
static void C_fcall trf_5007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5007(t0,t1);}

C_noret_decl(trf_4941)
static void C_fcall trf_4941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4941(t0,t1);}

C_noret_decl(trf_4737)
static void C_fcall trf_4737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4737(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4737(t0,t1);}

C_noret_decl(trf_4749)
static void C_fcall trf_4749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4749(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4749(t0,t1);}

C_noret_decl(trf_4740)
static void C_fcall trf_4740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4740(t0,t1);}

C_noret_decl(trf_4685)
static void C_fcall trf_4685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4685(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4685(t0,t1,t2);}

C_noret_decl(trf_4645)
static void C_fcall trf_4645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4645(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4645(t0,t1,t2);}

C_noret_decl(trf_4664)
static void C_fcall trf_4664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4664(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4664(t0,t1);}

C_noret_decl(trf_4595)
static void C_fcall trf_4595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4595(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4595(t0,t1,t2);}

C_noret_decl(trf_4499)
static void C_fcall trf_4499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4499(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4499(t0,t1,t2);}

C_noret_decl(trf_4301)
static void C_fcall trf_4301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4301(t0,t1);}

C_noret_decl(trf_4403)
static void C_fcall trf_4403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4403(t0,t1);}

C_noret_decl(trf_4178)
static void C_fcall trf_4178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4178(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4178(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4238)
static void C_fcall trf_4238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4238(t0,t1);}

C_noret_decl(trf_4250)
static void C_fcall trf_4250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4250(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4250(t0,t1);}

C_noret_decl(trf_3999)
static void C_fcall trf_3999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3999(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3999(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4037)
static void C_fcall trf_4037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4037(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4037(t0,t1);}

C_noret_decl(trf_4054)
static void C_fcall trf_4054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4054(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4054(t0,t1,t2);}

C_noret_decl(trf_4073)
static void C_fcall trf_4073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4073(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4073(t0,t1);}

C_noret_decl(trf_4034)
static void C_fcall trf_4034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4034(t0,t1);}

C_noret_decl(trf_3950)
static void C_fcall trf_3950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3950(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3950(t0,t1,t2);}

C_noret_decl(trf_3779)
static void C_fcall trf_3779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3779(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3779(t0,t1);}

C_noret_decl(trf_3774)
static void C_fcall trf_3774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3774(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3774(t0,t1,t2);}

C_noret_decl(trf_3681)
static void C_fcall trf_3681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3681(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3681(t0,t1,t2,t3);}

C_noret_decl(trf_3703)
static void C_fcall trf_3703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3703(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3703(t0,t1);}

C_noret_decl(trf_3649)
static void C_fcall trf_3649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3649(t0,t1);}

C_noret_decl(trf_3600)
static void C_fcall trf_3600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3600(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3600(t0,t1,t2);}

C_noret_decl(trf_3610)
static void C_fcall trf_3610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3610(t0,t1);}

C_noret_decl(trf_3582)
static void C_fcall trf_3582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3582(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3582(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_expand_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("expand_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3764)){
C_save(t1);
C_rereclaim2(3764*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,392);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],12,"\003sysfeatures");
lf[4]=C_h_intern(&lf[4],2,"pp");
lf[5]=C_h_intern(&lf[5],5,"print");
lf[8]=C_h_intern(&lf[8],23,"\003syscurrent-environment");
lf[9]=C_h_intern(&lf[9],28,"\003syscurrent-meta-environment");
lf[11]=C_h_intern(&lf[11],7,"\003sysget");
lf[12]=C_h_intern(&lf[12],16,"\004coremacro-alias");
lf[14]=C_h_intern(&lf[14],7,"<macro>");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\011aliasing ");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\004 to ");
lf[17]=C_h_intern(&lf[17],8,"\003sysput!");
lf[18]=C_h_intern(&lf[18],6,"gensym");
lf[19]=C_h_intern(&lf[19],21,"\003sysqualified-symbol\077");
lf[21]=C_h_intern(&lf[21],7,"\003sysmap");
lf[22]=C_h_intern(&lf[22],16,"\003sysstrip-syntax");
lf[23]=C_h_intern(&lf[23],21,"\003sysalias-global-hook");
lf[24]=C_h_intern(&lf[24],3,"get");
lf[25]=C_h_intern(&lf[25],12,"list->vector");
lf[26]=C_h_intern(&lf[26],12,"vector->list");
lf[27]=C_h_intern(&lf[27],9,"\003syserror");
lf[28]=C_h_intern(&lf[28],12,"strip-syntax");
lf[29]=C_h_intern(&lf[29],21,"\003sysmacro-environment");
lf[30]=C_h_intern(&lf[30],29,"\003syschicken-macro-environment");
lf[31]=C_h_intern(&lf[31],33,"\003syschicken-ffi-macro-environment");
lf[32]=C_h_intern(&lf[32],28,"\003sysextend-macro-environment");
lf[33]=C_h_intern(&lf[33],14,"\003syscopy-macro");
lf[34]=C_h_intern(&lf[34],6,"macro\077");
lf[35]=C_h_intern(&lf[35],20,"\003sysunregister-macro");
lf[36]=C_h_intern(&lf[36],4,"caar");
lf[37]=C_h_intern(&lf[37],15,"undefine-macro!");
lf[38]=C_h_intern(&lf[38],12,"\003sysexpand-0");
lf[39]=C_h_intern(&lf[39],9,"\003sysabort");
lf[40]=C_h_intern(&lf[40],9,"condition");
lf[41]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[42]=C_h_intern(&lf[42],13,"string-append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[45]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[46]=C_h_intern(&lf[46],3,"exn");
lf[47]=C_h_intern(&lf[47],3,"-->");
lf[48]=C_h_intern(&lf[48],22,"with-exception-handler");
lf[49]=C_h_intern(&lf[49],30,"call-with-current-continuation");
lf[50]=C_h_intern(&lf[50],10,"\000STATIC-SE");
lf[51]=C_h_intern(&lf[51],10,"\003sysappend");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020invoking macro: ");
lf[53]=C_h_intern(&lf[53],21,"\003syssyntax-error-hook");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[55]=C_h_intern(&lf[55],7,"\000EXPAND");
lf[56]=C_h_intern(&lf[56],3,"\000SE");
lf[57]=C_h_intern(&lf[57],1,"_");
lf[58]=C_h_intern(&lf[58],3,"let");
lf[59]=C_h_intern(&lf[59],8,"\004corelet");
lf[60]=C_h_intern(&lf[60],16,"\004coreloop-lambda");
lf[61]=C_h_intern(&lf[61],11,"\004coreletrec");
lf[62]=C_h_intern(&lf[62],8,"\004coreapp");
lf[63]=C_h_intern(&lf[63],4,"cadr");
lf[64]=C_h_intern(&lf[64],16,"\003syscheck-syntax");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[66]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[67]=C_h_intern(&lf[67],10,"\003syssetter");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_h_intern(&lf[69],4,"set!");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],9,"\004coreset!");
lf[72]=C_h_intern(&lf[72],25,"\003sysenable-runtime-macros");
lf[73]=C_h_intern(&lf[73],17,"\003sysmodule-rename");
lf[74]=C_h_intern(&lf[74],18,"\003sysstring->symbol");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[77]=C_h_intern(&lf[77],22,"\003sysregister-undefined");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\025(ALIAS) global alias ");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[80]=C_h_intern(&lf[80],18,"\003syscurrent-module");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\023(ALIAS) primitive: ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\020(ALIAS) marked: ");
lf[83]=C_h_intern(&lf[83],14,"\004coreprimitive");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000 (ALIAS) in current environment: ");
lf[85]=C_h_intern(&lf[85],12,"\004corealiased");
lf[86]=C_h_intern(&lf[86],10,"\003sysexpand");
lf[87]=C_h_intern(&lf[87],6,"expand");
lf[88]=C_h_intern(&lf[88],25,"\003sysextended-lambda-list\077");
lf[89]=C_h_intern(&lf[89],6,"#!rest");
lf[90]=C_h_intern(&lf[90],10,"#!optional");
lf[91]=C_h_intern(&lf[91],5,"#!key");
lf[92]=C_h_intern(&lf[92],7,"reverse");
lf[93]=C_h_intern(&lf[93],31,"\003sysexpand-extended-lambda-list");
lf[94]=C_h_intern(&lf[94],5,"cadar");
lf[95]=C_h_intern(&lf[95],5,"quote");
lf[96]=C_h_intern(&lf[96],15,"\003sysget-keyword");
lf[97]=C_h_intern(&lf[97],11,"\004corelambda");
lf[98]=C_h_intern(&lf[98],15,"string->keyword");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[101]=C_h_intern(&lf[101],3,"tmp");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[110]=C_h_intern(&lf[110],14,"let-optionals*");
lf[111]=C_h_intern(&lf[111],13,"let-optionals");
lf[112]=C_h_intern(&lf[112],8,"optional");
lf[113]=C_h_intern(&lf[113],4,"let*");
lf[114]=C_h_intern(&lf[114],3,"map");
lf[115]=C_h_intern(&lf[115],21,"\003syscanonicalize-body");
lf[116]=C_h_intern(&lf[116],5,"begin");
lf[117]=C_h_intern(&lf[117],6,"define");
lf[118]=C_h_intern(&lf[118],13,"define-values");
lf[119]=C_h_intern(&lf[119],5,"\000BODY");
lf[120]=C_h_intern(&lf[120],20,"\003syscall-with-values");
lf[121]=C_h_intern(&lf[121],14,"\004coreundefined");
lf[122]=C_h_intern(&lf[122],3,"cdr");
lf[123]=C_h_intern(&lf[123],13,"letrec-syntax");
lf[124]=C_h_intern(&lf[124],13,"define-syntax");
lf[125]=C_h_intern(&lf[125],5,"cdadr");
lf[126]=C_h_intern(&lf[126],6,"lambda");
lf[127]=C_h_intern(&lf[127],5,"caadr");
lf[128]=C_h_intern(&lf[128],25,"\003sysexpand-curried-define");
lf[129]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[132]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-syntax\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[138]=C_h_intern(&lf[138],24,"\003sysline-number-database");
lf[139]=C_h_intern(&lf[139],24,"\003syssyntax-error-culprit");
lf[140]=C_h_intern(&lf[140],15,"\003syssignal-hook");
lf[141]=C_h_intern(&lf[141],13,"\000syntax-error");
lf[142]=C_h_intern(&lf[142],12,"syntax-error");
lf[143]=C_h_intern(&lf[143],15,"get-line-number");
lf[144]=C_h_intern(&lf[144],18,"\003syshash-table-ref");
lf[145]=C_h_intern(&lf[145],8,"keyword\077");
lf[146]=C_h_intern(&lf[146],14,"symbol->string");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[156]=C_h_intern(&lf[156],4,"pair");
lf[157]=C_h_intern(&lf[157],5,"pair\077");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[159]=C_h_intern(&lf[159],8,"variable");
lf[160]=C_h_intern(&lf[160],7,"symbol\077");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[162]=C_h_intern(&lf[162],6,"symbol");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[164]=C_h_intern(&lf[164],4,"list");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[166]=C_h_intern(&lf[166],6,"number");
lf[167]=C_h_intern(&lf[167],7,"number\077");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[169]=C_h_intern(&lf[169],6,"string");
lf[170]=C_h_intern(&lf[170],7,"string\077");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[172]=C_h_intern(&lf[172],11,"lambda-list");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[177]=C_h_intern(&lf[177],18,"\003syser-transformer");
lf[178]=C_h_intern(&lf[178],12,"\000RENAME/RENV");
lf[179]=C_h_intern(&lf[179],14,"\000RENAME/LOOKUP");
lf[180]=C_h_intern(&lf[180],20,"\000RENAME/LOOKUP/MACRO");
lf[181]=C_h_intern(&lf[181],7,"\000RENAME");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\016  (lookup/DSE ");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\005 --> ");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[186]=C_h_intern(&lf[186],8,"\000COMPARE");
lf[187]=C_h_intern(&lf[187],17,"\003sysexpand-import");
lf[188]=C_h_intern(&lf[188],17,"\003sysstring-append");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[190]=C_h_intern(&lf[190],18,"\003syssymbol->string");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid prefix");
lf[194]=C_h_intern(&lf[194],15,"\003sysfind-module");
lf[195]=C_h_intern(&lf[195],8,"\003sysload");
lf[196]=C_h_intern(&lf[196],16,"\003sysdynamic-wind");
lf[197]=C_h_intern(&lf[197],26,"\003sysmeta-macro-environment");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000$can not import from undefined module");
lf[199]=C_h_intern(&lf[199],18,"\003sysfind-extension");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\007.import");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[204]=C_h_intern(&lf[204],8,"\003syswarn");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\037renamed identifier not imported");
lf[206]=C_h_intern(&lf[206],12,"\003sysfor-each");
lf[207]=C_h_intern(&lf[207],8,"\003sysdelq");
lf[208]=C_h_intern(&lf[208],4,"cdar");
lf[209]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000");
lf[210]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[212]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000$re-importing already imported syntax");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\047re-importing already imported identfier");
lf[215]=C_h_intern(&lf[215],25,"\003sysmark-imported-symbols");
lf[216]=C_h_intern(&lf[216],10,"<toplevel>");
lf[217]=C_h_intern(&lf[217],2,"\000S");
lf[218]=C_h_intern(&lf[218],2,"\000V");
lf[219]=C_h_intern(&lf[219],7,"\000IMPORT");
lf[220]=C_h_intern(&lf[220],6,"module");
lf[221]=C_h_intern(&lf[221],14,"\003sysblock-set!");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[225]=C_h_intern(&lf[225],6,"prefix");
lf[226]=C_h_intern(&lf[226],6,"except");
lf[227]=C_h_intern(&lf[227],6,"rename");
lf[228]=C_h_intern(&lf[228],4,"only");
lf[229]=C_h_intern(&lf[229],29,"\003sysinitial-macro-environment");
lf[230]=C_h_intern(&lf[230],24,"\003sysprocess-syntax-rules");
lf[231]=C_h_intern(&lf[231],7,"\003syscar");
lf[232]=C_h_intern(&lf[232],7,"\003syscdr");
lf[233]=C_h_intern(&lf[233],11,"\003sysvector\077");
lf[234]=C_h_intern(&lf[234],17,"\003sysvector-length");
lf[235]=C_h_intern(&lf[235],14,"\003sysvector-ref");
lf[236]=C_h_intern(&lf[236],16,"\003sysvector->list");
lf[237]=C_h_intern(&lf[237],16,"\003syslist->vector");
lf[238]=C_h_intern(&lf[238],6,"\003sys>=");
lf[239]=C_h_intern(&lf[239],5,"\003sys=");
lf[240]=C_h_intern(&lf[240],5,"\003sys+");
lf[241]=C_h_intern(&lf[241],8,"\003syscons");
lf[242]=C_h_intern(&lf[242],7,"\003syseq\077");
lf[243]=C_h_intern(&lf[243],10,"\003sysequal\077");
lf[244]=C_h_intern(&lf[244],9,"\003syslist\077");
lf[245]=C_h_intern(&lf[245],9,"\003sysmap-n");
lf[246]=C_h_intern(&lf[246],9,"\003sysnull\077");
lf[247]=C_h_intern(&lf[247],9,"\003syspair\077");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\026ill-formed syntax rule");
lf[250]=C_h_intern(&lf[250],6,"syntax");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000,template dimension error (too few ellipses\077)");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\021too many ellipses");
lf[253]=C_h_intern(&lf[253],9,"\003sysapply");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000 segment matching not implemented");
lf[255]=C_h_intern(&lf[255],4,"temp");
lf[256]=C_h_intern(&lf[256],4,"tail");
lf[257]=C_h_intern(&lf[257],2,"or");
lf[258]=C_h_intern(&lf[258],4,"loop");
lf[259]=C_h_intern(&lf[259],1,"l");
lf[260]=C_h_intern(&lf[260],5,"input");
lf[261]=C_h_intern(&lf[261],4,"else");
lf[262]=C_h_intern(&lf[262],4,"cond");
lf[263]=C_h_intern(&lf[263],7,"compare");
lf[264]=C_h_intern(&lf[264],1,"i");
lf[265]=C_h_intern(&lf[265],3,"and");
lf[266]=C_h_intern(&lf[266],29,"\003sysdefault-macro-environment");
lf[272]=C_h_intern(&lf[272],26,"set-module-undefined-list!");
lf[273]=C_h_intern(&lf[273],21,"module-undefined-list");
lf[276]=C_h_intern(&lf[276],16,"\003sysmodule-table");
lf[277]=C_h_intern(&lf[277],5,"error");
lf[278]=C_h_intern(&lf[278],6,"import");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\020module not found");
lf[280]=C_h_intern(&lf[280],28,"\003systoplevel-definition-hook");
lf[281]=C_h_intern(&lf[281],28,"\003sysregister-meta-expression");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\047redefinition of imported syntax binding");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000&redefinition of imported value binding");
lf[285]=C_h_intern(&lf[285],19,"\003sysregister-export");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\011defined: ");
lf[287]=C_h_intern(&lf[287],15,"\003sysfind-export");
lf[288]=C_h_intern(&lf[288],26,"\003sysregister-syntax-export");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\020defined syntax: ");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000!use of syntax precedes definition");
lf[291]=C_h_intern(&lf[291],19,"\003sysregister-module");
lf[292]=C_h_intern(&lf[292],8,"\000MARKING");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\014 in module `");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000!indirect export of syntax binding");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\033indirect reexport of syntax");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\042indirect export of unknown binding");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\024  merged has length ");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\010merging ");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\033 se\047s with total length of ");
lf[303]=C_h_intern(&lf[303],32,"\003syscompiled-module-registration");
lf[304]=C_h_intern(&lf[304],28,"\003sysregister-compiled-module");
lf[305]=C_h_intern(&lf[305],4,"cons");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\022re-exported syntax");
lf[307]=C_h_intern(&lf[307],4,"eval");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\0001can not find implementation of re-exported syntax");
lf[309]=C_h_intern(&lf[309],29,"\003sysregister-primitive-module");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\0001unknown macro referenced while registering module");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\002#%");
lf[312]=C_h_intern(&lf[312],18,"module-exists-list");
lf[313]=C_h_intern(&lf[313],19,"\003sysfinalize-module");
lf[314]=C_h_intern(&lf[314],6,"\000DLIST");
lf[315]=C_h_intern(&lf[315],7,"\000SDLIST");
lf[316]=C_h_intern(&lf[316],9,"\000IEXPORTS");
lf[317]=C_h_intern(&lf[317],9,"\000VEXPORTS");
lf[318]=C_h_intern(&lf[318],9,"\000SEXPORTS");
lf[319]=C_h_intern(&lf[319],8,"\000EXPORTS");
lf[320]=C_h_intern(&lf[320],6,"\000FIXUP");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000$(internal) indirect export not found");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000(reference to possibly unbound identifier");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\015reexporting: ");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000 exported identifier for module `");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026\047 has not been defined");
lf[327]=C_h_intern(&lf[327],16,"\003sysmacro-subset");
lf[328]=C_h_intern(&lf[328],14,"make-parameter");
lf[329]=C_h_intern(&lf[329],12,"syntax-rules");
lf[330]=C_h_intern(&lf[330],3,"...");
lf[331]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[332]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[333]=C_h_intern(&lf[333],6,"export");
lf[334]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000!`export\047 used outside module body");
lf[337]=C_h_intern(&lf[337],16,"begin-for-syntax");
lf[338]=C_h_intern(&lf[338],24,"\004coreelaborationtimeonly");
lf[339]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[340]=C_h_intern(&lf[340],11,"\004coremodule");
lf[341]=C_h_intern(&lf[341],1,"*");
lf[342]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[343]=C_h_intern(&lf[343],17,"require-extension");
lf[344]=C_h_intern(&lf[344],22,"\004corerequire-extension");
lf[345]=C_h_intern(&lf[345],15,"require-library");
lf[346]=C_h_intern(&lf[346],11,"cond-expand");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[348]=C_h_intern(&lf[348],12,"\003sysfeature\077");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[351]=C_h_intern(&lf[351],3,"not");
lf[352]=C_h_intern(&lf[352],5,"delay");
lf[353]=C_h_intern(&lf[353],16,"\003sysmake-promise");
lf[354]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[355]=C_h_intern(&lf[355],10,"quasiquote");
lf[356]=C_h_intern(&lf[356],8,"\003syslist");
lf[357]=C_h_intern(&lf[357],17,"%unquote-splicing");
lf[358]=C_h_intern(&lf[358],1,"a");
lf[359]=C_h_intern(&lf[359],1,"b");
lf[360]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[365]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[366]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[367]=C_h_intern(&lf[367],16,"unquote-splicing");
lf[368]=C_h_intern(&lf[368],7,"unquote");
lf[369]=C_h_intern(&lf[369],2,"do");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[371]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[372]=C_h_intern(&lf[372],2,"if");
lf[373]=C_h_intern(&lf[373],6,"doloop");
lf[374]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001"
"\000\000\000\001");
lf[375]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[376]=C_h_intern(&lf[376],4,"case");
lf[377]=C_h_intern(&lf[377],8,"\003syseqv\077");
lf[378]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[379]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[380]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[381]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[382]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[383]=C_h_intern(&lf[383],2,"=>");
lf[384]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[385]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[386]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[387]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[388]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[389]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[390]=C_h_intern(&lf[390],17,"import-for-syntax");
lf[391]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\020\000hygienic-macros\376\003\000\000\002\376\001\000\000\015\000syntax-rules\376\377\016");
C_register_lf2(lf,392,create_ptable());
t2=C_mutate(&lf[0] /* (set! c152 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3549,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 38   append */
t4=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[391],C_retrieve(lf[2]));}

/* k3547 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3549,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! features ...) */,t1);
t3=C_mutate(&lf[3] /* (set! d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3551,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[6] /* (set! dd ...) */,C_retrieve2(lf[3],"d"));
t5=C_mutate(&lf[7] /* (set! dm ...) */,C_retrieve2(lf[3],"d"));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 66   make-parameter */
t7=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_END_OF_LIST);}

/* k3574 in k3547 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3576,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1 /* (set! current-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3580,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 67   make-parameter */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}

/* k3578 in k3574 in k3547 */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3580,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* (set! current-meta-environment ...) */,t1);
t3=C_mutate(&lf[10] /* (set! lookup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3582,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[13] /* (set! macro-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3600,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[20] /* (set! map-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3649,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[22]+1 /* (set! strip-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[28]+1 /* (set! strip-syntax ...) */,C_retrieve(lf[22]));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 119  make-parameter */
t9=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_END_OF_LIST);}

/* k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3830,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! macro-environment ...) */,t1);
t3=C_set_block_item(lf[30] /* chicken-macro-environment */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[31] /* chicken-ffi-macro-environment */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[32]+1 /* (set! extend-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3834,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[33]+1 /* (set! copy-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3867,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[34]+1 /* (set! macro? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3880,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[35]+1 /* (set! unregister-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3936,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[37]+1 /* (set! undefine-macro! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3987,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[38]+1 /* (set! expand-0 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3996,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(lf[72] /* enable-runtime-macros */,0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[73]+1 /* (set! module-rename ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4478,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[23]+1 /* (set! alias-global-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4496,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[86]+1 /* (set! expand ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4586,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[87]+1 /* (set! expand ...) */,C_retrieve(lf[86]));
t16=C_mutate((C_word*)lf[88]+1 /* (set! extended-lambda-list? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4639,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[92]+1);
t18=C_retrieve(lf[18]);
t19=C_mutate((C_word*)lf[93]+1 /* (set! expand-extended-lambda-list ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4682,a[2]=t17,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[92]+1);
t21=*((C_word*)lf[114]+1);
t22=C_mutate((C_word*)lf[115]+1 /* (set! canonicalize-body ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5272,a[2]=t21,a[3]=t20,a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate(&lf[137] /* (set! match-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6025,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[128]+1 /* (set! expand-curried-define ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6108,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(lf[138] /* line-number-database */,0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[139] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
t27=C_mutate((C_word*)lf[53]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6178,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[142]+1 /* (set! syntax-error ...) */,C_retrieve(lf[53]));
t29=C_mutate((C_word*)lf[143]+1 /* (set! get-line-number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6189,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[42]+1);
t31=C_retrieve(lf[145]);
t32=C_retrieve(lf[143]);
t33=*((C_word*)lf[146]+1);
t34=C_mutate((C_word*)lf[64]+1 /* (set! check-syntax ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6225,a[2]=t31,a[3]=t32,a[4]=t33,a[5]=t30,a[6]=((C_word)li71),tmp=(C_word)a,a+=7,tmp));
t35=C_mutate((C_word*)lf[177]+1 /* (set! er-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6687,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[187]+1 /* (set! expand-import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6981,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7826,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13792,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13794,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 867  ##sys#er-transformer */
t40=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t40))(3,t40,t38,t39);}

/* a13793 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13794(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13794,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
t5=C_retrieve(lf[187]);
((C_proc9)C_retrieve_proc(t5))(9,t5,t1,t2,t3,t4,C_retrieve(lf[8]),C_retrieve(lf[29]),C_SCHEME_FALSE,lf[278]);}

/* k13790 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 865  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[278],C_SCHEME_END_OF_LIST,t1);}

/* k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7829,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13782,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13784,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 873  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13783 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13784,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
t5=C_retrieve(lf[187]);
((C_proc9)C_retrieve_proc(t5))(9,t5,t1,t2,t3,t4,C_retrieve(lf[9]),C_retrieve(lf[197]),C_SCHEME_TRUE,lf[390]);}

/* k13780 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 871  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[390],C_SCHEME_END_OF_LIST,t1);}

/* k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7833,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 877  ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7833,2,t0,t1);}
t2=C_mutate((C_word*)lf[229]+1 /* (set! initial-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13640,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13642,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 882  ##sys#er-transformer */
t6=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13642,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13652,a[2]=t3,a[3]=t7,a[4]=((C_word)li201),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_13652(t9,t1,t5);}

/* loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_13652(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13652,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13708,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 893  ##sys#check-syntax */
t7=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[117],t3,lf[385]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13721,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 897  ##sys#check-syntax */
t7=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[117],t3,lf[387]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13668,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 888  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[117],t3,lf[162]);}}

/* k13666 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 889  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[4],lf[389]);}

/* k13669 in k13666 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13699,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 890  ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k13697 in k13669 in k13666 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 890  ##sys#register-export */
t2=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13672 in k13669 in k13666 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13674,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):lf[388]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k13719 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 898  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[3],lf[386]);}

/* k13722 in k13719 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13770,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 899  ##sys#current-module */
t5=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k13768 in k13722 in k13719 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 899  ##sys#register-export */
t2=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13725 in k13722 in k13719 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13727,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13750,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 902  r */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k13748 in k13725 in k13722 in k13719 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13750,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13762,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13760 in k13748 in k13725 in k13722 in k13719 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13762,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k13706 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 894  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[2],lf[384]);}

/* k13709 in k13706 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13718,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 895  ##sys#expand-curried-define */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13716 in k13709 in k13706 in loop in a13641 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 895  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_13652(t2,((C_word*)t0)[2],t1);}

/* k13638 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 879  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[117],C_SCHEME_END_OF_LIST,t1);}

/* k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7839,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13581,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13583,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 907  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13582 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13583,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13612,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 916  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[372]);}}}

/* k13610 in a13582 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13632,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 916  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k13630 in k13610 in a13582 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13634 in k13630 in k13610 in a13582 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13636,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k13579 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 904  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[265],C_SCHEME_END_OF_LIST,t1);}

/* k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13491,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13493,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 921  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13492 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13493,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13518,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 930  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[101]);}}}

/* k13516 in a13492 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 931  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k13523 in k13516 in a13492 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13525,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 932  r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[372]);}

/* k13543 in k13523 in k13516 in a13492 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 932  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13563 in k13543 in k13523 in k13516 in a13492 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13567 in k13563 in k13543 in k13523 in k13516 in a13492 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13569,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k13489 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 918  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[257],C_SCHEME_END_OF_LIST,t1);}

/* k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13158,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13160,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 937  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13160,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13167,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 940  r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[116]);}

/* k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 941  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 942  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[372]);}

/* k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 943  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[383]);}

/* k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 944  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 945  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 946  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[126]);}

/* k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13185,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_13190,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word)li197),tmp=(C_word)a,a+=13,tmp));
t5=((C_word*)t3)[1];
f_13190(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_13190(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13190,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_13206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=((C_word*)t0)[11],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* expand.scm: 952  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[262],t3,lf[381]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[382]);}}

/* k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_13212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* expand.scm: 953  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k13210 in k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13212,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13219,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13248,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 954  expand */
t5=((C_word*)((C_word*)t0)[9])[1];
f_13190(t5,t4,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_13254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[11]);
/* expand.scm: 955  c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}}

/* k13252 in k13210 in k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13254,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13257,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 956  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13322,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[12]))){
t3=(C_word)C_i_length(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t3,C_fix(4));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* expand.scm: 962  c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,((C_word*)t0)[2],t5);}
else{
t5=t2;
f_13322(2,t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_13322(2,t3,C_SCHEME_FALSE);}}}

/* k13320 in k13252 in k13210 in k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13322,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13325,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 963  r */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13447,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k13445 in k13320 in k13252 in k13210 in k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13447,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13443,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 972  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_13190(t4,t3,((C_word*)t0)[2]);}

/* k13441 in k13445 in k13320 in k13252 in k13210 in k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13443,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k13323 in k13320 in k13252 in k13210 in k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13325,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t10=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[253],t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13380,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t9,a[7]=t13,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 969  expand */
t15=((C_word*)((C_word*)t0)[3])[1];
f_13190(t15,t14,((C_word*)t0)[2]);}

/* k13378 in k13323 in k13320 in k13252 in k13210 in k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13380,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[372],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[120],t10));}

/* k13255 in k13252 in k13210 in k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13257,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13296,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 960  expand */
t10=((C_word*)((C_word*)t0)[3])[1];
f_13190(t10,t9,((C_word*)t0)[2]);}

/* k13294 in k13255 in k13252 in k13210 in k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13296,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k13246 in k13210 in k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13248,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k13217 in k13210 in k13204 in expand in k13183 in k13180 in k13177 in k13174 in k13171 in k13168 in k13165 in a13159 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13219,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k13156 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 934  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[262],C_SCHEME_END_OF_LIST,t1);}

/* k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7848,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12988,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12990,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 977  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12990,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12994,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 979  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[376],t2,lf[380]);}

/* k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12994,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13003,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 982  r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[101]);}

/* k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 983  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 984  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[372]);}

/* k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 985  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 987  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k13013 in k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13015,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13034,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13036,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word)li195),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_13036(t9,t5,((C_word*)t0)[2]);}

/* expand in k13013 in k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_13036(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13036,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 994  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[376],t3,lf[378]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[379]);}}

/* k13050 in expand in k13013 in k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13058,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 995  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k13056 in k13050 in expand in k13013 in k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13058,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13065,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13108,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13112,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13114,a[2]=((C_word*)t0)[2],a[3]=((C_word)li194),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 997  ##sys#map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a13113 in k13056 in k13050 in expand in k13013 in k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13114,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[377],t6));}

/* k13110 in k13056 in k13050 in expand in k13013 in k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k13106 in k13056 in k13050 in expand in k13013 in k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13108,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k13098 in k13106 in k13056 in k13050 in expand in k13013 in k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13100,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13096,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1000 expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_13036(t4,t3,((C_word*)t0)[2]);}

/* k13094 in k13098 in k13106 in k13056 in k13050 in expand in k13013 in k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13096,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k13063 in k13056 in k13050 in expand in k13013 in k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13065,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k13032 in k13013 in k13010 in k13007 in k13004 in k13001 in k12992 in a12989 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_13034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13034,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[58],t3));}

/* k12986 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 974  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[376],C_SCHEME_END_OF_LIST,t1);}

/* k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7851,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12919,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12921,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1005 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12920 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12921,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12925,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1007 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[113],t2,lf[375]);}

/* k12923 in a12920 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12925,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12934,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1010 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[58]);}

/* k12932 in k12923 in a12920 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12934,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12939,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li192),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_12939(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k12932 in k12923 in a12920 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_12939(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12939,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12957,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12976,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1014 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k12974 in expand in k12932 in k12923 in a12920 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12976,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k12955 in expand in k12932 in k12923 in a12920 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12957,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12917 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1002 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[113],C_SCHEME_END_OF_LIST,t1);}

/* k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12737,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12739,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1019 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12739,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12743,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1021 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[369],t2,lf[374]);}

/* k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12743,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12755,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1025 r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[373]);}

/* k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1026 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1027 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[372]);}

/* k12759 in k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12764,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1028 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12762 in k12759 in k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12899,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1029 ##sys#map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a12898 in k12762 in k12759 in k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12899,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k12777 in k12762 in k12759 in k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12779,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_12806(t6,lf[371]);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12897,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,C_SCHEME_END_OF_LIST);}}

/* k12895 in k12777 in k12762 in k12759 in k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12897,2,t0,t1);}
t2=((C_word*)t0)[3];
f_12806(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12804 in k12777 in k12762 in k12759 in k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_12806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12806,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_12822(t4,lf[370]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12887,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k12885 in k12804 in k12777 in k12762 in k12759 in k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12887,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_12822(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12820 in k12804 in k12777 in k12762 in k12759 in k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_12822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12822,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12844,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1040 ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a12843 in k12820 in k12804 in k12777 in k12762 in k12759 in k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12844(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12844,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_car(t2));}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t7));}}

/* k12840 in k12820 in k12804 in k12777 in k12762 in k12759 in k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k12836 in k12820 in k12804 in k12777 in k12762 in k12759 in k12756 in k12753 in k12741 in a12738 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12838,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[62],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k12735 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1016 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[369],C_SCHEME_END_OF_LIST,t1);}

/* k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7857,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12342,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12344,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1049 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12344,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12348,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1051 r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[95]);}

/* k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1052 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[355]);}

/* k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1053 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[368]);}

/* k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1054 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[367]);}

/* k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12357,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12359,a[2]=t5,a[3]=t7,a[4]=((C_word)li185),tmp=(C_word)a,a+=5,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12369,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word)li186),tmp=(C_word)a,a+=9,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12638,a[2]=t7,a[3]=((C_word)li187),tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12726,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1104 ##sys#check-syntax */
t12=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[355],((C_word*)t0)[3],lf[366]);}

/* k12724 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1105 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12359(t3,((C_word*)t0)[2],t2,C_fix(0));}

/* simplify in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_12638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12638,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12642,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1092 match-expression */
f_6025(t3,t2,lf[364],lf[365]);}

/* k12640 in simplify in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12642,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[358],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[356],t4);
/* expand.scm: 1093 simplify */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12638(t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1094 match-expression */
f_6025(t2,((C_word*)t0)[2],lf[362],lf[363]);}}

/* k12665 in k12640 in simplify in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12667,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[359],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_i_assq(lf[358],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12698,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1101 match-expression */
f_6025(t2,((C_word*)t0)[2],lf[360],lf[361]);}}

/* k12711 in k12665 in k12640 in simplify in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[358],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k12696 in k12665 in k12640 in simplify in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12698,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[356],t2);
/* expand.scm: 1098 simplify */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12638(t4,((C_word*)t0)[2],t3);}

/* walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_12369(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12369,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12387,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12391,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1058 vector->list */
t6=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=t3,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1063 c */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t4);}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4));}}}

/* k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12416,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12442,a[2]=t5,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
/* expand.scm: 1069 walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_12359(t8,t6,t2,t7);}}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2));}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1071 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k12461 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12463,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12488,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1074 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_12359(t7,t4,t5,t6);}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12511,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1076 walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_12359(t4,t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12610,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1080 c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12624,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1090 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_12359(t3,t2,((C_word*)t0)[4],((C_word*)t0)[6]);}}}

/* k12622 in k12461 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12632,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1090 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12359(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12630 in k12622 in k12461 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12632,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12608 in k12461 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12610,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12553,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1084 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12359(t6,t5,((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12584,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1086 walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_12359(t7,t5,t3,t6);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12599,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1088 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_12359(t4,t3,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* k12597 in k12608 in k12461 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12607,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1088 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12359(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12605 in k12597 in k12608 in k12461 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12607,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12582 in k12608 in k12461 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12584,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[357],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[356],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12572,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1087 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12359(t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12570 in k12582 in k12608 in k12461 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12572,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12551 in k12608 in k12461 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12553,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[51],t3));}

/* k12509 in k12461 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12511,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[241],((C_word*)t0)[2],t1));}

/* k12486 in k12461 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12488,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[356],t3));}

/* k12440 in k12414 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12442,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[356],((C_word*)t0)[2],t1));}

/* k12389 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1058 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12359(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12385 in walk1 in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12387,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[237],t2));}

/* walk in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_12359(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12359,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12367,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1055 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12369(t5,t4,t2,t3);}

/* k12365 in walk in k12355 in k12352 in k12349 in k12346 in a12343 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1055 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12638(t2,((C_word*)t0)[2],t1);}

/* k12340 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1046 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[355],C_SCHEME_END_OF_LIST,t1);}

/* k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12309,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12311,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1110 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12310 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12311,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12315,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1112 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[352],t2,lf[354]);}

/* k12313 in a12310 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12315,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[126],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[353],t6));}

/* k12307 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1107 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[352],C_SCHEME_END_OF_LIST,t1);}

/* k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12025,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12027,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1118 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12027,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12034,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1121 r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1122 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[351]);}

/* k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1123 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1124 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12046,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1125 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12048,a[2]=((C_word*)t0)[8],a[3]=((C_word)li179),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12058,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=t4,a[7]=t1,a[8]=((C_word)li180),tmp=(C_word)a,a+=9,tmp));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12208,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=((C_word)li182),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_12208(t9,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* expand in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_12208(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12208,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12222,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12224,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12261,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1162 c */
t8=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t6,((C_word*)t0)[3]);}
else{
/* expand.scm: 1160 err */
t6=((C_word*)t0)[2];
f_12048(t6,t1,t4);}}
else{
/* expand.scm: 1155 err */
t4=((C_word*)t0)[2];
f_12048(t4,t1,t2);}}}

/* k12259 in expand in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12261,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[350]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12277,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12283,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1167 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12058(t3,t2,((C_word*)t0)[2]);}}

/* k12281 in k12259 in expand in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12283,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12290,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
/* expand.scm: 1168 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12208(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k12288 in k12281 in k12259 in expand in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12290,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12275 in k12259 in expand in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12277,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a12223 in expand in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12224,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k12220 in expand in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[27]+1),lf[349],t1);}

/* test in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_12058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12058,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 1131 ##sys#feature? */
t3=C_retrieve(lf[348]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12089,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1136 c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],t3);}
else{
/* expand.scm: 1132 err */
t3=((C_word*)t0)[5];
f_12048(t3,t1,t2);}}}

/* k12087 in test in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12089,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12107,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[11]);
/* expand.scm: 1139 test */
t5=((C_word*)((C_word*)t0)[8])[1];
f_12058(t5,t3,t4);}
else{
/* expand.scm: 1141 err */
t3=((C_word*)t0)[7];
f_12048(t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1142 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k12133 in k12087 in test in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12135,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12150,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 1145 test */
t5=((C_word*)((C_word*)t0)[7])[1];
f_12058(t5,t3,t4);}
else{
/* expand.scm: 1147 err */
t3=((C_word*)t0)[6];
f_12048(t3,((C_word*)t0)[9],((C_word*)t0)[5]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12185,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1148 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k12183 in k12133 in k12087 in test in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12185,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12192,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1148 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12058(t4,t2,t3);}
else{
/* expand.scm: 1149 err */
t2=((C_word*)t0)[2];
f_12048(t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k12190 in k12183 in k12133 in k12087 in test in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k12148 in k12133 in k12087 in test in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12150,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12164,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k12162 in k12148 in k12133 in k12087 in test in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12164,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1146 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12058(t3,((C_word*)t0)[2],t2);}

/* k12105 in k12087 in test in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12107,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12116 in k12105 in k12087 in test in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12118,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1140 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12058(t3,((C_word*)t0)[2],t2);}

/* err in k12044 in k12041 in k12038 in k12035 in k12032 in a12026 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_12048(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12048,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[346],((C_word*)t0)[2]);
/* expand.scm: 1127 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[347],t2,t3);}

/* k12023 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1115 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[346],C_SCHEME_END_OF_LIST,t1);}

/* k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12004,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12006,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1173 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12005 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12006,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[344],t7));}

/* k12002 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_12004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1170 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[345],C_SCHEME_END_OF_LIST,t1);}

/* k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7869,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11983,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11985,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1181 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11984 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11985,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[344],t7));}

/* k11981 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1178 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[343],C_SCHEME_END_OF_LIST,t1);}

/* k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7872,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11932,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11934,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1189 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11933 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11934,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11938,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1191 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[220],t2,lf[342]);}

/* k11936 in a11933 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11938,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11968,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11975,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1194 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[341]);}

/* k11973 in k11936 in a11933 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* expand.scm: 1194 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k11966 in k11936 in a11933 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11968,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_TRUE:(C_word)C_i_caddr(((C_word*)t0)[4]));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k11959 in k11966 in k11936 in a11933 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11961,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[340],t3));}

/* k11930 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1186 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[220],C_SCHEME_END_OF_LIST,t1);}

/* k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11878,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11880,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1202 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11879 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11880(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11880,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11884,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1204 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[337],t2,lf[339]);}

/* k11882 in a11879 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1205 ##sys#current-module */
t3=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11885 in k11882 in a11879 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11924,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_11890(2,t3,C_SCHEME_FALSE);}}

/* k11922 in k11885 in k11882 in a11879 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11924,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[116],t1);
/* expand.scm: 1206 ##sys#register-meta-expression */
t3=C_retrieve(lf[281]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k11888 in k11885 in k11882 in a11879 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1207 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k11903 in k11888 in k11885 in k11882 in a11879 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11909,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k11907 in k11903 in k11888 in k11885 in k11882 in a11879 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11909,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[338],t3));}

/* k11876 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1199 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[337],C_SCHEME_END_OF_LIST,t1);}

/* k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11775,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11777,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1212 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11776 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11777,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11784,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1215 ##sys#current-module */
t7=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k11782 in a11776 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11787,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_11787(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1217 syntax-error */
t3=C_retrieve(lf[142]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[333],lf[336]);}}

/* k11785 in k11782 in a11776 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11807,a[2]=((C_word*)t0)[3],a[3]=((C_word)li173),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11806 in k11785 in k11782 in a11776 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11807,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11814,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t3;
f_11814(t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11829,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp);
t5=t3;
f_11814(t5,f_11829(t2));}}

/* loop in a11806 in k11785 in k11782 in a11776 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_11829(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_TRUE);}}
else{
return(C_SCHEME_TRUE);}}}

/* k11812 in a11806 in k11785 in k11782 in a11776 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_11814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=f_9548(((C_word*)t0)[4]);
/* expand.scm: 1226 syntax-error */
t3=C_retrieve(lf[142]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],lf[333],lf[335],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k11788 in k11785 in k11782 in a11776 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11793,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11797,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=f_9566(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11805,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[22]),((C_word*)t0)[2]);}

/* k11803 in k11788 in k11785 in k11782 in a11776 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1230 append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11795 in k11788 in k11785 in k11782 in a11776 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(2),t1);}

/* k11791 in k11788 in k11785 in k11782 in a11776 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[334]);}

/* k11773 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1209 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[333],C_SCHEME_END_OF_LIST,t1);}

/* k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11738,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11740,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11739 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11740,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11744,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[329],t2,lf[332]);}

/* k11742 in a11739 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11744,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[5]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=lf[330];
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t7,a[6]=t9,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t4)[1]))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11762,a[2]=t10,a[3]=t7,a[4]=t4,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t12=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[329],((C_word*)t0)[5],lf[331]);}
else{
t11=t10;
f_11753(t11,C_SCHEME_UNDEFINED);}}

/* k11760 in k11742 in a11739 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_11753(t7,t6);}

/* k11751 in k11742 in a11739 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_11753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#process-syntax-rules */
t2=C_retrieve(lf[230]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11736 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[329],C_SCHEME_END_OF_LIST,t1);}

/* k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7881,2,t0,t1);}
t2=C_mutate((C_word*)lf[230]+1 /* (set! process-syntax-rules ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7883,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9526,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1242 ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9526,2,t0,t1);}
t2=C_mutate((C_word*)lf[266]+1 /* (set! default-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9530,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11734,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1247 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k11732 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1247 make-parameter */
t2=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9530,2,t0,t1);}
t2=C_mutate((C_word*)lf[197]+1 /* (set! meta-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9534,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1248 make-parameter */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9534,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! current-module ...) */,t1);
t3=C_mutate(&lf[76] /* (set! module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9548,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[267] /* (set! module-export-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9566,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[268] /* (set! set-module-defined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9575,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[269] /* (set! module-defined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9584,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[270] /* (set! module-exist-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9602,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[271] /* (set! module-defined-syntax-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9620,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[272]+1 /* (set! set-module-undefined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9629,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[273]+1 /* (set! module-undefined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9638,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[223] /* (set! module-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9656,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[222] /* (set! module-meta-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9674,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[274] /* (set! module-meta-expressions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9692,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[192] /* (set! module-vexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9710,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[193] /* (set! module-sexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9728,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[275] /* (set! make-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9737,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[194]+1 /* (set! find-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9743,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[280]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9783,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[281]+1 /* (set! register-meta-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9786,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[282] /* (set! check-for-redef ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9806,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[285]+1 /* (set! register-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9827,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[288]+1 /* (set! register-syntax-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9916,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[77]+1 /* (set! register-undefined ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9997,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[291]+1 /* (set! register-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10019,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[215]+1 /* (set! mark-imported-symbols ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10087,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate(&lf[293] /* (set! module-indirect-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10146,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate(&lf[299] /* (set! merge-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10422,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[303]+1 /* (set! compiled-module-registration ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10494,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[304]+1 /* (set! register-compiled-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10874,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[309]+1 /* (set! register-primitive-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11082,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[287]+1 /* (set! find-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11173,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[313]+1 /* (set! finalize-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11258,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t33=C_set_block_item(lf[276] /* module-table */,0,C_SCHEME_END_OF_LIST);
t34=C_mutate((C_word*)lf[327]+1 /* (set! macro-subset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11692,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t35=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t35+1)))(2,t35,C_SCHEME_UNDEFINED);}

/* ##sys#macro-subset in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11692,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11700,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1606 ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11698 in ##sys#macro-subset in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11700,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11702,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li169),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11702(t5,((C_word*)t0)[2],t1);}

/* loop in k11698 in ##sys#macro-subset in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_11702(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11702,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,((C_word*)t0)[3]));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11723,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1609 loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* k11721 in loop in k11698 in ##sys#macro-subset in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11723,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11258(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11258,3,t0,t1,t2);}
t3=f_9566(t2);
t4=f_9548(t2);
t5=f_9584(t2);
t6=f_9602(t2);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11274,a[2]=t4,a[3]=t3,a[4]=t6,a[5]=t5,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11673,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
t9=f_9620(t2);
/* map */
t10=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}

/* a11672 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11673,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11685,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1534 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k11683 in a11672 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_11277(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11630,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1539 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k11628 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11630,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11632,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li166),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11632(t5,((C_word*)t0)[2],t1);}

/* loop in k11628 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_11632(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11632,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11645,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11671,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1541 caar */
t5=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k11669 in loop in k11628 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1541 ##sys#find-export */
t2=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11643 in loop in k11628 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11645,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11656,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1542 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11632(t5,t3,t4);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1543 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11632(t3,((C_word*)t0)[3],t2);}}

/* k11654 in k11643 in loop in k11628 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11656,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11280,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t4=(C_truep(t3)?((C_word*)t0)[4]:((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t6,a[5]=t1,a[6]=((C_word)li165),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_11500(t8,t2,t4);}

/* loop in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_11500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11500,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?t3:(C_word)C_i_car(t3));
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[5]))){
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1551 loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}
else{
t6=(C_word)C_i_assq(t5,((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11548,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11551,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_cdr(t6);
t10=t8;
f_11551(t10,(C_word)C_i_symbolp(t9));}
else{
t9=t8;
f_11551(t9,C_SCHEME_FALSE);}}}}

/* k11549 in loop in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_11551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11551,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11548(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1558 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k11602 in k11549 in loop in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11604,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_11563(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_11563(t4,C_SCHEME_FALSE);}}

/* k11561 in k11602 in k11549 in loop in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_11563(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11563,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11566,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 1560 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[323],((C_word*)t0)[4],lf[324],t3);}
else{
if(C_truep(((C_word*)t0)[3])){
/* expand.scm: 1569 ##sys#module-rename */
t2=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11586,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11590,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1566 symbol->string */
t4=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}

/* k11588 in k11561 in k11602 in k11549 in loop in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1564 string-append */
t2=*((C_word*)lf[42]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[325],t1,lf[326]);}

/* k11584 in k11561 in k11602 in k11549 in loop in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1563 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11564 in k11561 in k11602 in k11549 in loop in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_11548(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* k11546 in loop in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11548,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11537,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1570 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11500(t5,t3,t4);}

/* k11535 in k11546 in loop in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11537,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11283,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11480,a[2]=((C_word*)t0)[2],a[3]=((C_word)li164),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11494,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1575 module-undefined-list */
t5=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k11492 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11479 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11480,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1574 ##sys#warn */
t3=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[322],t2);}}

/* k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11442,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11478,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1581 module-indirect-exports */
f_10146(t4,((C_word*)t0)[6]);}

/* k11476 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11441 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11442,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11470,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1579 ##sys#macro-environment */
t6=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}

/* k11468 in a11441 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 1580 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],lf[321],t3);}}

/* k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11436,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1583 ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11434 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11440,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1584 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11438 in k11434 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11440,2,t0,t1);}
/* expand.scm: 1582 merge-se */
f_10422(((C_word*)t0)[4],(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11292,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 1586 ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}

/* k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11394,a[2]=((C_word*)t0)[2],a[3]=((C_word)li162),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a11393 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11394,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11398,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(t2);
/* expand.scm: 1589 merge-se */
f_10422(t3,(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[2]));}

/* k11396 in a11393 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11401,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11424,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11428,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1590 map-se */
f_3649(t5,t1);}

/* k11426 in k11396 in a11393 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11422 in k11396 in a11393 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11424,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[320],t2);
/* expand.scm: 1590 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* k11399 in k11396 in a11393 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_car(t2,((C_word*)t0)[2]));}

/* k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11298,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=f_9548(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k11390 in k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11392,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[314],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11388,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1596 map-se */
f_3649(t4,((C_word*)t0)[2]);}

/* k11386 in k11390 in k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11382 in k11390 in k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11384,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[315],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11380,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1597 map-se */
f_3649(t4,((C_word*)t0)[2]);}

/* k11378 in k11382 in k11390 in k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11374 in k11382 in k11390 in k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11376,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[316],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11368,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11372,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1598 map-se */
f_3649(t4,((C_word*)t0)[2]);}

/* k11370 in k11374 in k11382 in k11390 in k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11366 in k11374 in k11382 in k11390 in k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11368,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[317],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11364,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1599 map-se */
f_3649(t4,((C_word*)t0)[2]);}

/* k11362 in k11366 in k11374 in k11382 in k11390 in k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11358 in k11366 in k11374 in k11382 in k11390 in k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11360,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[318],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[319],t8);
/* expand.scm: 1593 dm */
t10=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t10))(3,t10,((C_word*)t0)[2],t9);}

/* k11296 in k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(10),t4);}

/* k11299 in k11296 in k11293 in k11290 in k11287 in k11284 in k11281 in k11278 in k11275 in k11272 in ##sys#finalize-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(11),t4);}

/* ##sys#find-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11173,5,t0,t1,t2,t3,t4);}
t5=f_9566(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11184,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t5);
if(C_truep(t7)){
/* expand.scm: 1520 module-exists-list */
t8=C_retrieve(lf[312]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t3);}
else{
t8=t6;
f_11184(2,t8,t5);}}

/* k11182 in ##sys#find-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11184,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11186,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li160),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_11186(t5,((C_word*)t0)[2],t1);}

/* loop in k11182 in ##sys#find-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_11186(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11186,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1524 caar */
t7=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1527 loop */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}}

/* k11233 in loop in k11182 in ##sys#find-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11235,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11231,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1525 cdar */
t5=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t4=t3;
f_11214(t4,C_SCHEME_FALSE);}}}

/* k11229 in k11233 in loop in k11182 in ##sys#find-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_11214(t2,(C_word)C_i_memq(((C_word*)t0)[2],t1));}

/* k11212 in k11233 in loop in k11182 in ##sys#find-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_11214(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1526 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11186(t3,((C_word*)t0)[4],t2);}}

/* ##sys#register-primitive-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11082r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11082r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11082r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11086,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11086(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11086(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11084 in ##sys#register-primitive-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11089,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1497 ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11087 in k11084 in ##sys#register-primitive-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11104,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11128,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11127 in k11087 in k11084 in ##sys#register-primitive-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11128,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11138,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11148,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 1504 ##sys#string-append */
t6=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[311],t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11146 in a11127 in k11087 in k11084 in ##sys#register-primitive-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1503 ##sys#string->symbol */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k11136 in a11127 in k11087 in k11084 in ##sys#register-primitive-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11141,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1505 ##sys#put! */
t3=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[83],((C_word*)t0)[2]);}

/* k11139 in k11136 in a11127 in k11087 in k11084 in ##sys#register-primitive-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11141,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k11102 in k11087 in k11084 in ##sys#register-primitive-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11108,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11110,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word)li157),tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11109 in k11102 in k11087 in k11084 in ##sys#register-primitive-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11110,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* expand.scm: 1512 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[310],t2,((C_word*)t0)[2]);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11106 in k11102 in k11087 in k11084 in ##sys#register-primitive-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11108,2,t0,t1);}
t2=f_9737(C_a_i(&a,13),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve(lf[276]));
t5=C_mutate((C_word*)lf[276]+1 /* (set! module-table ...) */,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_10874r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_10874r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_10874r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10878,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t7;
f_10878(2,t8,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_i_cdr(t6);
if(C_truep((C_word)C_i_nullp(t8))){
t9=t7;
f_10878(2,t9,(C_word)C_i_car(t6));}
else{
/* ##sys#error */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}

/* k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10904,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11036,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11035 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11036(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11036,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10901,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1452 ##sys#macro-environment */
t6=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11057,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 1462 ##sys#er-transformer */
t6=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k11055 in a11035 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11057,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10899 in a11035 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* expand.scm: 1455 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],lf[278],lf[308],((C_word*)t0)[3]);}}

/* k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11004,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11003 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11004,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11026,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_caddr(t2);
/* expand.scm: 1467 ##sys#er-transformer */
t8=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k11024 in a11003 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_11026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11026,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10910,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10986,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10985 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10986,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10998,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 1472 ##sys#er-transformer */
t6=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k10996 in a10985 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10998,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10908 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10910,2,t0,t1);}
t2=f_9737(C_a_i(&a,13),((C_word*)t0)[6],C_SCHEME_END_OF_LIST,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10916,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10980,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1476 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k10978 in k10908 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1477 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10982 in k10978 in k10908 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10984,2,t0,t1);}
/* expand.scm: 1475 merge-se */
f_10422(((C_word*)t0)[7],(C_word)C_a_i_list(&a,6,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10914 in k10908 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1479 ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k10917 in k10914 in k10908 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10968,a[2]=((C_word*)t0)[5],a[3]=((C_word)li152),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10967 in k10917 in k10914 in k10908 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10968,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}

/* k10920 in k10917 in k10914 in k10908 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10948,a[2]=((C_word*)t0)[4],a[3]=((C_word)li151),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10947 in k10920 in k10917 in k10914 in k10908 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10948,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_set_car(t4,((C_word*)t0)[2]));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k10923 in k10920 in k10917 in k10914 in k10908 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10928,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10938,a[2]=((C_word*)t0)[3],a[3]=((C_word)li150),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10937 in k10923 in k10920 in k10917 in k10914 in k10908 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10938(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10938,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}

/* k10926 in k10923 in k10920 in k10917 in k10914 in k10908 in k10905 in k10902 in k10876 in ##sys#register-compiled-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10928,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[276]));
t4=C_mutate((C_word*)lf[276]+1 /* (set! module-table ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10494(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10494,3,t0,t1,t2);}
t3=f_9584(t2);
t4=f_9548(t2);
t5=f_9656(t2);
t6=f_9728(t2);
t7=f_9674(t2);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10517,a[2]=t7,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10872,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t10=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t5,C_SCHEME_END_OF_LIST);}
else{
t9=t8;
f_10517(t9,C_SCHEME_END_OF_LIST);}}

/* k10870 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10872,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[278],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[307],t5);
t7=((C_word*)t0)[2];
f_10517(t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_10517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10517,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10521,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10842,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_10525(t4,C_SCHEME_END_OF_LIST);}}

/* k10840 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10842,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[278],t1);
t3=((C_word*)t0)[2];
f_10525(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_10525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10525,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10529,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10824,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=f_9692(((C_word*)t0)[5]);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[22]),t5);}

/* k10822 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1420 reverse */
t2=*((C_word*)lf[92]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10533,2,t0,t1);}
t2=f_9548(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10737,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10739,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10812,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1428 module-indirect-exports */
f_10146(t8,((C_word*)t0)[6]);}

/* k10810 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10738 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10739,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[95],t7));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[95],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[95],t7);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[164],t12));}}

/* k10735 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10733,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=f_9710(((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[95],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10665,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10669,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li147),tmp=(C_word)a,a+=5,tmp);
/* map */
t9=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[4]);}

/* a10670 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10671,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(t3,((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[95],t6);
t8=(C_word)C_i_cdr(t4);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t7,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[305],t10));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10714,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1437 dm */
t6=C_retrieve2(lf[7],"dm");
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[306],t3,((C_word*)t0)[2]);}}

/* k10712 in a10670 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10714,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[95],t2));}

/* k10667 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10663 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10665,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10585,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10589,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=f_9620(((C_word*)t0)[3]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10595,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word)li146),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_10595(t9,t4,t5);}

/* loop in k10663 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_10595(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10595,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10661,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1443 caar */
t4=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k10659 in loop in k10663 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10661,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,((C_word*)t0)[5]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1443 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10595(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1445 caar */
t3=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k10616 in k10659 in loop in k10663 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1446 caar */
t3=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k10655 in k10616 in k10659 in loop in k10663 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10657,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1446 cdar */
t5=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[3]);}

/* k10647 in k10655 in k10616 in k10659 in loop in k10663 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10649,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[305],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10629,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1447 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_10595(t7,t5,t6);}

/* k10627 in k10647 in k10655 in k10616 in k10659 in loop in k10663 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10629,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10587 in k10663 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10583 in k10663 in k10731 in k10531 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10585,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[304],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t10=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,((C_word*)t0)[3],((C_word*)t0)[2],t9);}

/* k10527 in k10523 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10519 in k10515 in ##sys#compiled-module-registration in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* merge-se in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_10422(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10422,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10426,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,*((C_word*)lf[68]+1),t2);}

/* k10424 in merge-se in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10429,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
/* expand.scm: 1403 dm */
t5=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[301],t3,lf[302],t4);}

/* k10427 in k10424 in merge-se in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10432,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10441,a[2]=t4,a[3]=((C_word)li144),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10441(t6,t2,((C_word*)t0)[2]);}

/* loop in k10427 in k10424 in merge-se in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_10441(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10441,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10480,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1407 caar */
t4=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k10478 in loop in k10427 in k10424 in merge-se in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10480,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(t1,t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1407 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10441(t4,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10472,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1408 loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10441(t6,t4,t5);}}

/* k10470 in k10478 in loop in k10427 in k10424 in merge-se in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10472,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10430 in k10427 in k10424 in merge-se in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10435,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(t1);
/* expand.scm: 1409 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[300],t3);}

/* k10433 in k10430 in k10427 in k10424 in merge-se in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_10146(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10146,NULL,2,t1,t2);}
t3=f_9566(t2);
t4=f_9548(t2);
t5=f_9584(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10204,a[2]=t4,a[3]=((C_word)li140),tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t3);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10227,a[2]=t4,a[3]=t5,a[4]=t6,a[5]=t9,a[6]=((C_word)li142),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_10227(t11,t1,t3);}}

/* loop in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_10227(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10227,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_cdr(t2);
/* expand.scm: 1376 loop */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10254,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1378 cdar */
t5=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}}

/* k10252 in loop in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10254,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li141),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_10256(t5,((C_word*)t0)[2],t1);}

/* loop2 in k10252 in loop in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_10256(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10256,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 1379 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_10227(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1380 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k10414 in loop2 in k10252 in loop in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10416,2,t0,t1);}
if(C_truep((C_word)C_i_assq(((C_word*)t0)[8],t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10279,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1381 warn */
t4=((C_word*)t0)[4];
f_10204(t4,t2,lf[296],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_cdr(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10322,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_10322(2,t7,t5);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1388 ##sys#module-rename */
t8=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,((C_word*)t0)[2]);}}
else{
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10404,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1390 ##sys#current-environment */
t6=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}}

/* k10402 in k10414 in loop2 in k10252 in loop in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10404,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10352,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 1393 loop2 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10256(t9,t7,t8);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10367,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1395 warn */
t6=((C_word*)t0)[2];
f_10204(t6,t4,lf[297],t5);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10385,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1398 warn */
t5=((C_word*)t0)[2];
f_10204(t5,t3,lf[298],t4);}}

/* k10383 in k10402 in k10414 in loop2 in k10252 in loop in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1399 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10256(t3,((C_word*)t0)[2],t2);}

/* k10365 in k10402 in k10414 in loop2 in k10252 in loop in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1396 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10256(t3,((C_word*)t0)[2],t2);}

/* k10350 in k10402 in k10414 in loop2 in k10252 in loop in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10352,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10320 in k10414 in loop2 in k10252 in loop in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10322,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10307,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1389 loop2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10256(t5,t3,t4);}

/* k10305 in k10320 in k10414 in loop2 in k10252 in loop in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10307,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10277 in k10414 in loop2 in k10252 in loop in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1382 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10256(t3,((C_word*)t0)[2],t2);}

/* warn in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_10204(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10204,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10212,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10216,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1370 symbol->string */
t6=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k10214 in warn in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1370 string-append */
t2=*((C_word*)lf[42]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[294],t1,lf[295]);}

/* k10210 in warn in module-indirect-exports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1369 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#mark-imported-symbols in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10087(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10087,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10093,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a10092 in ##sys#mark-imported-symbols in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10093,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10100,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_eqp(t5,t6);
t8=t3;
f_10100(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_10100(t5,C_SCHEME_FALSE);}}

/* k10098 in a10092 in ##sys#mark-imported-symbols in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_10100(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10100,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[292],t4);
/* expand.scm: 1354 dm */
t6=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k10101 in k10098 in a10092 in ##sys#mark-imported-symbols in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1355 ##sys#put! */
t3=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t2,lf[85],C_SCHEME_TRUE);}

/* ##sys#register-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+31)){
C_save_and_reclaim((void*)tr4r,(void*)f_10019r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10019r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10019r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(31);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10021,a[2]=t3,a[3]=t2,a[4]=((C_word)li135),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10034,a[2]=t5,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10039,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-vexports29662985 */
t8=t1;
((C_proc2)C_retrieve_proc(t8))(2,t8,f_10039(C_a_i(&a,19),t7));}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-sexports29672981 */
t10=t1;
((C_proc2)C_retrieve_proc(t10))(2,t10,f_10034(C_a_i(&a,19),t6,t8));}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body29642973 */
t12=t1;
((C_proc2)C_retrieve_proc(t12))(2,t12,f_10021(C_a_i(&a,19),t5,t8,t10));}
else{
/* ##sys#error */
t12=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-vexports2966 in ##sys#register-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_10039(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return(f_10034(C_a_i(&a,19),((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* def-sexports2967 in ##sys#register-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_10034(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return(f_10021(C_a_i(&a,19),((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST));}

/* body2964 in ##sys#register-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_10021(C_word *a,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t3=f_9737(C_a_i(&a,13),((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[276]));
t6=C_mutate((C_word*)lf[276]+1 /* (set! module-table ...) */,t5);
return(t3);}

/* ##sys#register-undefined in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9997,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10004,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1341 module-undefined-list */
t5=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k10002 in ##sys#register-undefined in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_10004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10004,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1343 set-module-undefined-list! */
t3=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* ##sys#register-syntax-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9916,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=f_9566(t3);
t6=(C_word)C_eqp(C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9926,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9926(2,t8,t6);}
else{
/* expand.scm: 1323 ##sys#find-export */
t8=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,t2,t3,C_SCHEME_TRUE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k9924 in ##sys#register-syntax-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9929,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1324 module-undefined-list */
t3=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}

/* k9927 in k9924 in ##sys#register-syntax-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9929,2,t0,t1);}
t2=f_9548(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],t1))){
/* expand.scm: 1327 ##sys#warn */
t4=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[290],((C_word*)t0)[5]);}
else{
t4=t3;
f_9935(2,t4,C_SCHEME_UNDEFINED);}}

/* k9933 in k9927 in k9924 in ##sys#register-syntax-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9978,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1328 ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9976 in k9933 in k9927 in k9924 in ##sys#register-syntax-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9982,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1328 ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9980 in k9976 in k9933 in k9927 in k9924 in ##sys#register-syntax-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1328 check-for-redef */
f_9806(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9936 in k9933 in k9927 in k9924 in ##sys#register-syntax-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1329 dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[289],((C_word*)t0)[6]);}

/* k9939 in k9936 in k9933 in k9927 in k9924 in ##sys#register-syntax-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=f_9584(((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
/* expand.scm: 1331 set-module-defined-list! */
f_9575(t2,((C_word*)t0)[4],t5);}
else{
t3=t2;
f_9944(2,t3,C_SCHEME_UNDEFINED);}}

/* k9942 in k9939 in k9936 in k9933 in k9927 in k9924 in ##sys#register-syntax-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9944,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=f_9620(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[3];
t7=(C_word)C_i_check_structure(t6,lf[220]);
/* ##sys#block-set! */
t8=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,t6,C_fix(5),t4);}

/* ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9827,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=f_9566(t3);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9837,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_9837(2,t7,t5);}
else{
/* expand.scm: 1304 ##sys#find-export */
t7=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t2,t3,C_SCHEME_TRUE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k9835 in ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1305 module-undefined-list */
t3=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k9838 in k9835 in ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9843,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9903,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=f_9548(((C_word*)t0)[3]);
/* expand.scm: 1307 ##sys#module-rename */
t5=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[4],t4);}

/* k9901 in k9838 in k9835 in ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1306 ##sys#toplevel-definition-hook */
t2=C_retrieve(lf[280]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9841 in k9838 in k9835 in ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9899,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1310 ##sys#delq */
t4=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_9846(2,t3,C_SCHEME_UNDEFINED);}}

/* k9897 in k9841 in k9838 in k9835 in ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1310 set-module-undefined-list! */
t2=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9844 in k9841 in k9838 in k9835 in ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9885,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1311 ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9883 in k9844 in k9841 in k9838 in k9835 in ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9889,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1311 ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9887 in k9883 in k9844 in k9841 in k9838 in k9835 in ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1311 check-for-redef */
f_9806(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9847 in k9844 in k9841 in k9838 in k9835 in ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=f_9602(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(4),t4);}

/* k9850 in k9847 in k9844 in k9841 in k9838 in k9835 in ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9852,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1314 dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[286],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9856 in k9850 in k9847 in k9844 in k9841 in k9838 in k9835 in ##sys#register-export in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9858,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_FALSE);
t3=f_9584(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* expand.scm: 1315 set-module-defined-list! */
f_9575(((C_word*)t0)[2],((C_word*)t0)[3],t4);}

/* check-for-redef in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_9806(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9806,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(t2,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9813,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
/* expand.scm: 1297 ##sys#warn */
t7=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[284],t2);}
else{
t7=t6;
f_9813(2,t7,C_SCHEME_FALSE);}}

/* k9811 in check-for-redef in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
/* expand.scm: 1299 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[283],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#register-meta-expression in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9786,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9790,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1292 ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9788 in ##sys#register-meta-expression in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9790,2,t0,t1);}
if(C_truep(t1)){
t2=f_9692(t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,C_fix(9),t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#toplevel-definition-hook in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9783,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}

/* ##sys#find-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9743(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_9743r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9743r(t0,t1,t2,t3);}}

static void C_ccall f_9743r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9747,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_9747(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_9747(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k9745 in ##sys#find-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[276]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
if(C_truep(t1)){
/* expand.scm: 1284 error */
t3=*((C_word*)lf[277]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[278],lf[279],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* make-module in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_9737(C_word *a,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_stack_check;
return((C_word)C_a_i_record(&a,12,lf[220],t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,t4));}

/* module-sexports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_9728(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(11)));}

/* module-vexports in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_9710(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(10)));}

/* module-meta-expressions in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_9692(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(9)));}

/* module-meta-import-forms in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_9674(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(8)));}

/* module-import-forms in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_9656(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(7)));}

/* module-undefined-list in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9638,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[220]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* set-module-undefined-list! in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9629,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* module-defined-syntax-list in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_9620(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(5)));}

/* module-exist-list in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_9602(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(4)));}

/* module-defined-list in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_9584(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(3)));}

/* set-module-defined-list! in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_9575(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9575,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* module-export-list in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_9566(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* module-name in k9532 in k9528 in k9524 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_9548(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(1)));}

/* ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word ab[158],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7883,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_SCHEME_UNDEFINED;
t42=(*a=C_VECTOR_TYPE|1,a[1]=t41,tmp=(C_word)a,a+=2,tmp);
t43=C_SCHEME_UNDEFINED;
t44=(*a=C_VECTOR_TYPE|1,a[1]=t43,tmp=(C_word)a,a+=2,tmp);
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_SCHEME_UNDEFINED;
t56=(*a=C_VECTOR_TYPE|1,a[1]=t55,tmp=(C_word)a,a+=2,tmp);
t57=C_SCHEME_UNDEFINED;
t58=(*a=C_VECTOR_TYPE|1,a[1]=t57,tmp=(C_word)a,a+=2,tmp);
t59=C_SCHEME_UNDEFINED;
t60=(*a=C_VECTOR_TYPE|1,a[1]=t59,tmp=(C_word)a,a+=2,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_SCHEME_UNDEFINED;
t64=(*a=C_VECTOR_TYPE|1,a[1]=t63,tmp=(C_word)a,a+=2,tmp);
t65=C_SCHEME_UNDEFINED;
t66=(*a=C_VECTOR_TYPE|1,a[1]=t65,tmp=(C_word)a,a+=2,tmp);
t67=C_SCHEME_UNDEFINED;
t68=(*a=C_VECTOR_TYPE|1,a[1]=t67,tmp=(C_word)a,a+=2,tmp);
t69=C_SCHEME_UNDEFINED;
t70=(*a=C_VECTOR_TYPE|1,a[1]=t69,tmp=(C_word)a,a+=2,tmp);
t71=C_SCHEME_UNDEFINED;
t72=(*a=C_VECTOR_TYPE|1,a[1]=t71,tmp=(C_word)a,a+=2,tmp);
t73=C_SCHEME_UNDEFINED;
t74=(*a=C_VECTOR_TYPE|1,a[1]=t73,tmp=(C_word)a,a+=2,tmp);
t75=C_SCHEME_UNDEFINED;
t76=(*a=C_VECTOR_TYPE|1,a[1]=t75,tmp=(C_word)a,a+=2,tmp);
t77=C_SCHEME_UNDEFINED;
t78=(*a=C_VECTOR_TYPE|1,a[1]=t77,tmp=(C_word)a,a+=2,tmp);
t79=C_SCHEME_UNDEFINED;
t80=(*a=C_VECTOR_TYPE|1,a[1]=t79,tmp=(C_word)a,a+=2,tmp);
t81=C_SCHEME_UNDEFINED;
t82=(*a=C_VECTOR_TYPE|1,a[1]=t81,tmp=(C_word)a,a+=2,tmp);
t83=C_SCHEME_UNDEFINED;
t84=(*a=C_VECTOR_TYPE|1,a[1]=t83,tmp=(C_word)a,a+=2,tmp);
t85=C_SCHEME_UNDEFINED;
t86=(*a=C_VECTOR_TYPE|1,a[1]=t85,tmp=(C_word)a,a+=2,tmp);
t87=C_SCHEME_UNDEFINED;
t88=(*a=C_VECTOR_TYPE|1,a[1]=t87,tmp=(C_word)a,a+=2,tmp);
t89=C_SCHEME_UNDEFINED;
t90=(*a=C_VECTOR_TYPE|1,a[1]=t89,tmp=(C_word)a,a+=2,tmp);
t91=C_SCHEME_UNDEFINED;
t92=(*a=C_VECTOR_TYPE|1,a[1]=t91,tmp=(C_word)a,a+=2,tmp);
t93=C_SCHEME_UNDEFINED;
t94=(*a=C_VECTOR_TYPE|1,a[1]=t93,tmp=(C_word)a,a+=2,tmp);
t95=C_SCHEME_UNDEFINED;
t96=(*a=C_VECTOR_TYPE|1,a[1]=t95,tmp=(C_word)a,a+=2,tmp);
t97=C_SCHEME_UNDEFINED;
t98=(*a=C_VECTOR_TYPE|1,a[1]=t97,tmp=(C_word)a,a+=2,tmp);
t99=C_SCHEME_UNDEFINED;
t100=(*a=C_VECTOR_TYPE|1,a[1]=t99,tmp=(C_word)a,a+=2,tmp);
t101=C_SCHEME_UNDEFINED;
t102=(*a=C_VECTOR_TYPE|1,a[1]=t101,tmp=(C_word)a,a+=2,tmp);
t103=C_SCHEME_UNDEFINED;
t104=(*a=C_VECTOR_TYPE|1,a[1]=t103,tmp=(C_word)a,a+=2,tmp);
t105=C_SCHEME_UNDEFINED;
t106=(*a=C_VECTOR_TYPE|1,a[1]=t105,tmp=(C_word)a,a+=2,tmp);
t107=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7890,a[2]=t2,a[3]=t5,a[4]=t3,a[5]=t1,a[6]=t102,a[7]=t104,a[8]=t98,a[9]=t106,a[10]=t100,a[11]=t90,a[12]=t88,a[13]=t4,a[14]=t86,a[15]=t92,a[16]=t96,a[17]=t94,a[18]=t84,a[19]=t82,a[20]=t6,a[21]=t80,a[22]=t78,a[23]=t76,a[24]=t74,a[25]=t72,a[26]=t70,a[27]=t68,a[28]=t66,a[29]=t64,a[30]=t62,a[31]=t60,a[32]=t58,a[33]=t56,a[34]=t54,a[35]=t52,a[36]=t50,a[37]=t48,a[38]=t46,a[39]=t44,a[40]=t42,a[41]=t40,a[42]=t38,a[43]=t36,a[44]=t34,a[45]=t32,a[46]=t30,a[47]=t28,a[48]=t26,a[49]=t24,a[50]=t22,a[51]=t20,a[52]=t18,a[53]=t16,a[54]=t14,a[55]=t12,a[56]=t10,a[57]=t8,tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t108=t5;
((C_proc3)C_retrieve_proc(t108))(3,t108,t107,lf[265]);}

/* k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[231]);
t4=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[232]);
t5=C_mutate(((C_word *)((C_word*)t0)[54])+1,lf[233]);
t6=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[234]);
t7=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[235]);
t8=C_mutate(((C_word *)((C_word*)t0)[51])+1,lf[236]);
t9=C_mutate(((C_word *)((C_word*)t0)[50])+1,lf[237]);
t10=C_mutate(((C_word *)((C_word*)t0)[49])+1,lf[238]);
t11=C_mutate(((C_word *)((C_word*)t0)[48])+1,lf[239]);
t12=C_mutate(((C_word *)((C_word*)t0)[47])+1,lf[240]);
t13=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[50],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[51],a[12]=((C_word*)t0)[48],a[13]=((C_word*)t0)[53],a[14]=((C_word*)t0)[52],a[15]=((C_word*)t0)[47],a[16]=((C_word*)t0)[49],a[17]=((C_word*)t0)[54],a[18]=((C_word*)t0)[10],a[19]=((C_word*)t0)[11],a[20]=((C_word*)t0)[56],a[21]=((C_word*)t0)[12],a[22]=((C_word*)t0)[13],a[23]=((C_word*)t0)[14],a[24]=((C_word*)t0)[15],a[25]=((C_word*)t0)[16],a[26]=((C_word*)t0)[17],a[27]=((C_word*)t0)[57],a[28]=((C_word*)t0)[18],a[29]=((C_word*)t0)[55],a[30]=((C_word*)t0)[19],a[31]=((C_word*)t0)[20],a[32]=((C_word*)t0)[21],a[33]=((C_word*)t0)[22],a[34]=((C_word*)t0)[23],a[35]=((C_word*)t0)[24],a[36]=((C_word*)t0)[25],a[37]=((C_word*)t0)[26],a[38]=((C_word*)t0)[27],a[39]=((C_word*)t0)[28],a[40]=((C_word*)t0)[29],a[41]=((C_word*)t0)[30],a[42]=((C_word*)t0)[31],a[43]=((C_word*)t0)[32],a[44]=((C_word*)t0)[33],a[45]=((C_word*)t0)[34],a[46]=((C_word*)t0)[35],a[47]=((C_word*)t0)[36],a[48]=((C_word*)t0)[37],a[49]=((C_word*)t0)[38],a[50]=((C_word*)t0)[39],a[51]=((C_word*)t0)[40],a[52]=((C_word*)t0)[41],a[53]=((C_word*)t0)[42],a[54]=((C_word*)t0)[43],a[55]=((C_word*)t0)[44],a[56]=((C_word*)t0)[45],a[57]=((C_word*)t0)[46],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t14=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,lf[264]);}

/* k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7904,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[57],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[263]);}

/* k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7908,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[57],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[262]);}

/* k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7912,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[241]);
t4=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[56],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[57],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],a[57]=((C_word*)t0)[55],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[261]);}

/* k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7917,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[242]);
t4=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[243]);
t5=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[55],a[22]=((C_word*)t0)[56],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[57],a[34]=((C_word*)t0)[31],a[35]=((C_word*)t0)[32],a[36]=((C_word*)t0)[33],a[37]=((C_word*)t0)[34],a[38]=((C_word*)t0)[35],a[39]=((C_word*)t0)[36],a[40]=((C_word*)t0)[37],a[41]=((C_word*)t0)[38],a[42]=((C_word*)t0)[39],a[43]=((C_word*)t0)[40],a[44]=((C_word*)t0)[41],a[45]=((C_word*)t0)[42],a[46]=((C_word*)t0)[43],a[47]=((C_word*)t0)[44],a[48]=((C_word*)t0)[45],a[49]=((C_word*)t0)[46],a[50]=((C_word*)t0)[47],a[51]=((C_word*)t0)[48],a[52]=((C_word*)t0)[49],a[53]=((C_word*)t0)[50],a[54]=((C_word*)t0)[51],a[55]=((C_word*)t0)[52],a[56]=((C_word*)t0)[53],a[57]=((C_word*)t0)[54],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[260]);}

/* k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7923,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[57],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[259]);}

/* k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7927,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[57],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7931,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[57],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[58]);}

/* k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7935,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[57],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[113]);}

/* k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7939,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[244]);
t4=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[56],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[57],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],a[57]=((C_word*)t0)[55],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[164]);}

/* k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],a[55]=((C_word*)t0)[55],a[56]=((C_word*)t0)[56],a[57]=((C_word*)t0)[57],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[258]);}

/* k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7948,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[21]);
t4=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[245]);
t5=C_mutate(((C_word *)((C_word*)t0)[54])+1,lf[246]);
t6=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[55],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[56],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[57],a[23]=((C_word*)t0)[54],a[24]=((C_word*)t0)[20],a[25]=((C_word*)t0)[21],a[26]=((C_word*)t0)[22],a[27]=((C_word*)t0)[23],a[28]=((C_word*)t0)[24],a[29]=((C_word*)t0)[25],a[30]=((C_word*)t0)[26],a[31]=((C_word*)t0)[27],a[32]=((C_word*)t0)[28],a[33]=((C_word*)t0)[29],a[34]=((C_word*)t0)[30],a[35]=((C_word*)t0)[31],a[36]=((C_word*)t0)[32],a[37]=((C_word*)t0)[33],a[38]=((C_word*)t0)[34],a[39]=((C_word*)t0)[35],a[40]=((C_word*)t0)[36],a[41]=((C_word*)t0)[37],a[42]=((C_word*)t0)[38],a[43]=((C_word*)t0)[39],a[44]=((C_word*)t0)[40],a[45]=((C_word*)t0)[41],a[46]=((C_word*)t0)[42],a[47]=((C_word*)t0)[43],a[48]=((C_word*)t0)[44],a[49]=((C_word*)t0)[45],a[50]=((C_word*)t0)[46],a[51]=((C_word*)t0)[47],a[52]=((C_word*)t0)[48],a[53]=((C_word*)t0)[49],a[54]=((C_word*)t0)[50],a[55]=((C_word*)t0)[51],a[56]=((C_word*)t0)[52],a[57]=((C_word*)t0)[53],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7955,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[247]);
t4=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[57],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[56],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],a[57]=((C_word*)t0)[55],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[95]);}

/* k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7960,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[57],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[227]);}

/* k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7964,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[57],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[256]);}

/* k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7968,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[57],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[255]);}

/* k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7972,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[53]);
t4=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_7977,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=((C_word*)t0)[22],a[21]=((C_word*)t0)[23],a[22]=((C_word*)t0)[24],a[23]=((C_word*)t0)[25],a[24]=((C_word*)t0)[26],a[25]=((C_word*)t0)[27],a[26]=((C_word*)t0)[28],a[27]=((C_word*)t0)[29],a[28]=((C_word*)t0)[30],a[29]=((C_word*)t0)[31],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[33],a[32]=((C_word*)t0)[57],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[56],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],a[55]=((C_word*)t0)[55],tmp=(C_word)a,a+=56,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[134],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7977,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[54])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7979,a[2]=((C_word*)t0)[55],a[3]=((C_word*)t0)[53],a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7985,a[2]=((C_word*)t0)[41],a[3]=((C_word*)t0)[42],a[4]=((C_word*)t0)[43],a[5]=((C_word*)t0)[44],a[6]=((C_word*)t0)[45],a[7]=((C_word*)t0)[46],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[48],a[10]=((C_word*)t0)[49],a[11]=((C_word*)t0)[50],a[12]=((C_word*)t0)[51],a[13]=((C_word)li94),tmp=(C_word)a,a+=14,tmp));
t5=C_mutate(((C_word *)((C_word*)t0)[41])+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8079,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[47],a[4]=((C_word*)t0)[36],a[5]=((C_word*)t0)[37],a[6]=((C_word*)t0)[38],a[7]=((C_word*)t0)[39],a[8]=((C_word*)t0)[40],a[9]=((C_word)li96),tmp=(C_word)a,a+=10,tmp));
t6=C_mutate(((C_word *)((C_word*)t0)[35])+1,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8163,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[27],a[4]=((C_word*)t0)[28],a[5]=((C_word*)t0)[29],a[6]=((C_word*)t0)[30],a[7]=((C_word*)t0)[35],a[8]=((C_word*)t0)[48],a[9]=((C_word*)t0)[45],a[10]=((C_word*)t0)[40],a[11]=((C_word*)t0)[31],a[12]=((C_word*)t0)[32],a[13]=((C_word*)t0)[33],a[14]=((C_word*)t0)[51],a[15]=((C_word*)t0)[50],a[16]=((C_word*)t0)[34],a[17]=((C_word)li97),tmp=(C_word)a,a+=18,tmp));
t7=C_mutate(((C_word *)((C_word*)t0)[33])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8384,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[30],a[4]=((C_word*)t0)[45],a[5]=((C_word*)t0)[21],a[6]=((C_word*)t0)[40],a[7]=((C_word*)t0)[22],a[8]=((C_word*)t0)[48],a[9]=((C_word*)t0)[31],a[10]=((C_word*)t0)[23],a[11]=((C_word*)t0)[24],a[12]=((C_word*)t0)[25],a[13]=((C_word)li98),tmp=(C_word)a,a+=14,tmp));
t8=C_mutate(((C_word *)((C_word*)t0)[29])+1,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8502,a[2]=((C_word*)t0)[54],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[35],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[22],a[9]=((C_word*)t0)[21],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[45],a[13]=((C_word*)t0)[40],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[32],a[16]=((C_word)li100),tmp=(C_word)a,a+=17,tmp));
t9=C_mutate(((C_word *)((C_word*)t0)[36])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8790,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[54],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[30],a[7]=((C_word*)t0)[48],a[8]=((C_word*)t0)[36],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[44],a[11]=((C_word*)t0)[32],a[12]=((C_word*)t0)[34],a[13]=((C_word)li103),tmp=(C_word)a,a+=14,tmp));
t10=C_mutate(((C_word *)((C_word*)t0)[38])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8997,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[44],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[38],a[12]=((C_word*)t0)[50],a[13]=((C_word)li105),tmp=(C_word)a,a+=14,tmp));
t11=C_mutate(((C_word *)((C_word*)t0)[37])+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9251,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[37],a[4]=((C_word*)t0)[34],a[5]=((C_word)li106),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9324,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word)li107),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate(((C_word *)((C_word*)t0)[26])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9417,a[2]=((C_word*)t0)[4],a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9439,a[2]=((C_word*)t0)[54],a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate(((C_word *)((C_word*)t0)[8])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9465,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word)li110),tmp=(C_word)a,a+=5,tmp));
t16=C_mutate(((C_word *)((C_word*)t0)[11])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9485,a[2]=((C_word*)t0)[54],a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp));
/* make-transformer2284 */
t17=((C_word*)((C_word*)t0)[52])[1];
((C_proc3)C_retrieve_proc(t17))(3,t17,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_9485 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9485,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9495,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li111),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9495(t7,t1,t3);}

/* loop */
static void C_fcall f_9495(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9495,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9502,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
/* ellipsis?2283 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t4=t3;
f_9502(2,t4,C_SCHEME_FALSE);}}

/* k9500 in loop */
static void C_ccall f_9502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop2615 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9495(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* f_9465 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9465,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9472,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* segment-template?2294 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9470 */
static void C_ccall f_9472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9472,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9479,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* segment-depth2295 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* k9477 in k9470 */
static void C_ccall f_9479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(1),t1));}

/* f_9439 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9439(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9439,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(t2);
/* ellipsis?2283 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_9417 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9417,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9424,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* segment-template?2294 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9422 */
static void C_ccall f_9424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* ##sys#syntax-error-hook */
t4=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[254],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_9324 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9324,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9337,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,t5))){
t7=t6;
f_9337(t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_i_assq(t2,t4);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t7);
t9=t3;
t10=t6;
f_9337(t10,(C_word)C_fixnum_greater_or_equal_p(t8,t9));}
else{
t8=t6;
f_9337(t8,C_SCHEME_FALSE);}}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9366,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* segment-template?2294 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}

/* k9364 */
static void C_ccall f_9366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9366,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9377,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* free-meta-variables2292 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* free-meta-variables2292 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9413 in k9364 */
static void C_ccall f_9415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2292 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9396 in k9364 */
static void C_ccall f_9398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2292 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9375 in k9364 */
static void C_ccall f_9377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2292 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9335 */
static void C_fcall f_9337(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9337,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]):((C_word*)t0)[2]));}

/* f_9251 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_9251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9251,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[4]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t4));}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9277,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* segment-pattern?2293 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k9275 */
static void C_ccall f_9277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9277,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* meta-variables2291 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9305,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* meta-variables2291 */
t5=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9320 in k9275 */
static void C_ccall f_9322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2291 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9303 in k9275 */
static void C_ccall f_9305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2291 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8997 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_8997(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8997,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(C_word)C_i_assq(t2,t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
t7=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
/* ##sys#syntax-error-hook */
t8=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[251],t2);}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[250],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t8));}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t4,a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=t1,a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* segment-template?2294 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k9042 */
static void C_ccall f_9044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9044,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9047,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* segment-depth2295 */
t3=((C_word*)((C_word*)t0)[5])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9205,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* process-template2290 */
t4=((C_word*)((C_word*)t0)[11])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[14],((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9242,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
t4=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}}}}

/* k9240 in k9042 */
static void C_ccall f_9242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2290 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9236 in k9042 */
static void C_ccall f_9238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9238,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k9203 in k9042 */
static void C_ccall f_9205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9213,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* process-template2290 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9211 in k9203 in k9042 */
static void C_ccall f_9213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9213,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t3));}

/* k9045 in k9042 */
static void C_ccall f_9047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9047,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9053,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* free-meta-variables2292 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,t2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k9051 in k9045 in k9042 */
static void C_ccall f_9053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9053,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[252],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* process-template2290 */
t4=((C_word*)((C_word*)t0)[9])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k9063 in k9051 in k9045 in k9042 */
static void C_ccall f_9065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9068,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
if(C_truep((C_word)C_i_symbolp(t1))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_9131(t6,(C_word)C_eqp(t1,t5));}
else{
t5=t3;
f_9131(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_9131(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_9131(t4,C_SCHEME_FALSE);}}

/* k9129 in k9063 in k9051 in k9045 in k9042 */
static void C_fcall f_9131(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9131,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_9068(t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}

/* k9144 in k9129 in k9063 in k9051 in k9045 in k9042 */
static void C_ccall f_9146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9146,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_9068(t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k9066 in k9063 in k9051 in k9045 in k9042 */
static void C_fcall f_9068(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9068,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9102,a[2]=t4,a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9102(t6,t2,((C_word*)t0)[2],t1);}

/* doloop2533 in k9066 in k9063 in k9051 in k9045 in k9042 */
static void C_fcall f_9102(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9102,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[51],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t11=t1;
t12=t6;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k9069 in k9066 in k9063 in k9051 in k9045 in k9042 */
static void C_ccall f_9071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* segment-tail2296 */
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9098 in k9069 in k9066 in k9063 in k9051 in k9045 in k9042 */
static void C_ccall f_9100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9100,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9092,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9096,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* segment-tail2296 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k9094 in k9098 in k9069 in k9066 in k9063 in k9051 in k9045 in k9042 */
static void C_ccall f_9096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2290 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9090 in k9098 in k9069 in k9066 in k9063 in k9051 in k9045 in k9042 */
static void C_ccall f_9092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9092,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[51],t3));}

/* f_8790 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_8790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8790,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[12]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8814,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* mapit2440 */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8820,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=t4,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* segment-pattern?2293 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8818 */
static void C_ccall f_8820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8820,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8829,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word)li101),tmp=(C_word)a,a+=8,tmp);
/* process-pattern2289 */
t4=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[7],t2,((C_word*)((C_word*)t0)[12])[1],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[14]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8880,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[14]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
/* process-pattern2289 */
t6=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[13]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[14]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8920,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(2)))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[14],t4);
/* ellipsis?2283 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t3,t5);}
else{
t4=t3;
f_8920(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}}}

/* k8918 in k8818 */
static void C_ccall f_8920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8920,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8930,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8943,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[3],a[9]=((C_word)li102),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_8943(t5,((C_word*)t0)[6],C_fix(0));}}

/* lp in k8918 in k8818 */
static void C_fcall f_8943(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8943,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[8]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8957,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_vector_ref(((C_word*)t0)[6],t2);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
/* process-pattern2289 */
t9=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,((C_word*)t0)[2]);}}

/* k8955 in lp in k8918 in k8818 */
static void C_ccall f_8957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8961,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2475 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8943(t4,t2,t3);}

/* k8959 in k8955 in lp in k8918 in k8818 */
static void C_ccall f_8961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8928 in k8918 in k8818 */
static void C_ccall f_8930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8930,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
/* process-pattern2289 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k8878 in k8818 */
static void C_ccall f_8880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8884,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
/* process-pattern2289 */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[2]);}

/* k8882 in k8878 in k8818 */
static void C_ccall f_8884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8828 in k8818 */
static void C_ccall f_8829(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8829,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8837,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],t2);
if(C_truep(t4)){
t5=t3;
f_8837(t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=t3;
f_8837(t11,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t10));}}

/* k8835 in a8828 in k8818 */
static void C_fcall f_8837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* mapit2440 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8812 */
static void C_ccall f_8814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8814,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t2));}

/* f_8502 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_8502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8502,4,t0,t1,t2,t3);}
t4=(C_word)C_i_vector_length(t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t4,a[13]=t1,a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t6=(C_word)C_fixnum_difference(t4,C_fix(1));
t7=(C_word)C_i_vector_ref(t3,t6);
/* ellipsis?2283 */
t8=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t8))(3,t8,t5,t7);}
else{
t6=t5;
f_8509(2,t6,C_SCHEME_FALSE);}}

/* k8507 */
static void C_ccall f_8509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8509,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[16])[1],t5);
t7=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8548,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t4,a[16]=((C_word*)t0)[15],a[17]=t6,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t1)){
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_fixnum_difference(((C_word*)t0)[12],C_fix(2));
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=t7;
f_8548(t13,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t12));}
else{
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=t7;
f_8548(t12,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t11));}}

/* k8546 in k8507 */
static void C_fcall f_8548(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8548,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8552,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[17],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8556,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8558,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word)li99),tmp=(C_word)a,a+=17,tmp));
t7=((C_word*)t5)[1];
f_8558(t7,t3,C_fix(0));}

/* lp in k8546 in k8507 */
static void C_fcall f_8558(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8558,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[15]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t5=t2;
t6=(C_word)C_eqp(t5,t4);
t7=(C_truep(t6)?((C_word*)t0)[14]:C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t12);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8618,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t10,a[6]=((C_word*)t0)[10],a[7]=t13,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8622,a[2]=t14,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t17);
t19=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t20=(C_word)C_i_vector_ref(((C_word*)t0)[4],t19);
/* process-match2286 */
t21=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t21))(4,t21,t15,t18,t20);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8689,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t10);
t12=(C_word)C_i_vector_ref(((C_word*)t0)[4],t2);
/* process-match2286 */
t13=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t13))(4,t13,t8,t11,t12);}}}

/* k8687 in lp in k8546 in k8507 */
static void C_ccall f_8689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8693,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2411 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8558(t4,t2,t3);}

/* k8691 in k8687 in lp in k8546 in k8507 */
static void C_ccall f_8693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8620 in lp in k8546 in k8507 */
static void C_ccall f_8622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8622,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k8616 in lp in k8546 in k8507 */
static void C_ccall f_8618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8618,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}

/* k8554 in k8546 in k8507 */
static void C_ccall f_8556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8550 in k8546 in k8507 */
static void C_ccall f_8552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8552,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST));}

/* f_8384 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_8384(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8384,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8388,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
/* process-match2286 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t6,t3);}

/* k8386 */
static void C_ccall f_8388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8388,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t8,t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t6,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t4,t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t21);
t23=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,(C_word)C_a_i_cons(&a,2,t22,C_SCHEME_END_OF_LIST));}}

/* f_8163 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_8163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8163,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_symbolp(t3))){
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[16]))){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[250],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[15])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[14])[1],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}
else{
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8213,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* segment-pattern?2293 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k8211 */
static void C_ccall f_8213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8213,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-segment-match2287 */
t3=((C_word*)((C_word*)t0)[14])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[13],((C_word*)t0)[12],t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8261,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8265,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t9);
t11=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-match2286 */
t12=((C_word*)((C_word*)t0)[6])[1];
((C_proc4)C_retrieve_proc(t12))(4,t12,t8,t10,t11);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[15]))){
/* process-vector-match2288 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[15]);}
else{
t2=(C_word)C_i_nullp(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8327(t4,t2);}
else{
t4=(C_word)C_booleanp(((C_word*)t0)[15]);
t5=t3;
f_8327(t5,(C_truep(t4)?t4:(C_word)C_charp(((C_word*)t0)[15])));}}}}}

/* k8325 in k8211 */
static void C_fcall f_8327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8327,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}}

/* k8263 in k8211 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8269,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8273,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* process-match2286 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t5,t6);}

/* k8271 in k8263 in k8211 */
static void C_ccall f_8273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8267 in k8263 in k8211 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8259 in k8211 */
static void C_ccall f_8261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8261,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* f_8079 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_8079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8079,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=t3;
f_8086(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_8086(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8086(t4,C_SCHEME_FALSE);}}

/* k8084 */
static void C_fcall f_8086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8086,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* cdar */
t3=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[10]);}
else{
/* ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],lf[249],((C_word*)t0)[10]);}}

/* k8087 in k8084 */
static void C_ccall f_8089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8089,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8138,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* process-match2286 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t1);}

/* k8136 in k8087 in k8084 */
static void C_ccall f_8138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8132 in k8087 in k8084 */
static void C_ccall f_8134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8134,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8115,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8129,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* process-pattern2289 */
t5=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],t4);}

/* a8128 in k8132 in k8087 in k8084 */
static void C_ccall f_8129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8129,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8113 in k8132 in k8087 in k8084 */
static void C_ccall f_8115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8123,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8127,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* meta-variables2291 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_SCHEME_END_OF_LIST);}

/* k8125 in k8113 in k8132 in k8087 in k8084 */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2290 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k8121 in k8113 in k8132 in k8087 in k8084 */
static void C_ccall f_8123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8123,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* f_7985 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[38],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7985,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8025,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t10,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8029,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* map */
t13=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)((C_word*)t0)[2])[1],t2);}

/* k8027 */
static void C_ccall f_8029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8029,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[248],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k8023 */
static void C_ccall f_8025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8025,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t7));}

/* f_7979 in k7975 in k7970 in k7966 in k7962 in k7958 in k7953 in k7946 in k7942 in k7937 in k7933 in k7929 in k7925 in k7921 in k7915 in k7910 in k7906 in k7902 in k7888 in ##sys#process-syntax-rules in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in k7837 in k7834 in k7831 in k7827 in k7824 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7979,3,t0,t1,t2);}
/* c2243 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6981,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6985,a[2]=t3,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=t6,a[7]=t1,a[8]=t4,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 726  r */
t10=t3;
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[228]);}

/* k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 727  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[227]);}

/* k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 728  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[226]);}

/* k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 729  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[225]);}

/* k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6996,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7005,a[2]=((C_word*)t0)[11],a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7048,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7135,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[11],a[11]=t4,a[12]=((C_word)li88),tmp=(C_word)a,a+=13,tmp));
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 826  ##sys#check-syntax */
t9=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[11],((C_word*)t0)[3],lf[224]);}

/* k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 827  ##sys#current-module */
t3=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7800,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9674(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 833  append */
t6=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7815,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9656(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 836  append */
t6=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}}
else{
t3=t2;
f_7599(2,t3,C_SCHEME_UNDEFINED);}}

/* k7813 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(7),t1);}

/* k7798 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(8),t1);}

/* k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7602,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7604,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li91),tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7604,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 839  import-spec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7135(t4,t3,t2);}

/* k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7608,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7617,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[219],t5);
/* expand.scm: 842  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t4,t6);}

/* k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_truep(((C_word*)t0)[2])?f_9548(((C_word*)t0)[2]):lf[216]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7775,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 843  map-se */
f_3649(t4,((C_word*)t0)[3]);}

/* k7773 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7775,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[218],t3);
/* expand.scm: 843  dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(((C_word*)t0)[2])?f_9548(((C_word*)t0)[2]):lf[216]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7752,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 844  map-se */
f_3649(t4,((C_word*)t0)[5]);}

/* k7750 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7752,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[217],t3);
/* expand.scm: 844  dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 845  ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7698,a[2]=((C_word*)t0)[3],a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7697 in k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7698,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7732,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 850  import-env */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7730 in a7697 in k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(((C_word*)t0)[3],t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
/* expand.scm: 852  ##sys#warn */
t5=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[2],lf[214],((C_word*)t0)[4]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7627 in k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7656,a[2]=((C_word*)t0)[6],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7655 in k7627 in k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7656,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7696,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 856  macro-env */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7694 in a7655 in k7627 in k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* expand.scm: 858  ##sys#warn */
t7=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],lf[213],t6);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7635,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7650,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7654,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 860  import-env */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7652 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 860  append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7648 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 860  import-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7646,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 861  macro-env */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7644 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 861  append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7640 in k7633 in k7630 in k7627 in k7624 in k7621 in k7618 in k7615 in k7606 in a7603 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 861  macro-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7600 in k7597 in k7594 in k7591 in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[212]);}

/* import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_7135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7135,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 759  import-name */
t3=((C_word*)t0)[11];
f_7048(t3,t1,t2);}
else{
t3=(C_word)C_i_listp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t4)){
t6=t5;
f_7154(t6,t4);}
else{
t6=(C_word)C_i_length(t2);
t7=t5;
f_7154(t7,(C_word)C_fixnum_lessp(t6,C_fix(2)));}}}

/* k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_7154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7154,NULL,2,t0,t1);}
if(C_truep(t1)){
/* expand.scm: 761  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[12],((C_word*)t0)[11],lf[201],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* expand.scm: 764  import-spec */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7135(t5,t3,t4);}}

/* k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7163,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 767  c */
t6=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}

/* k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7175,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7178,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 768  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[9],lf[202]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 779  c */
t4=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7255,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7258,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 780  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[8],lf[203]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* expand.scm: 790  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7362,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7365,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 791  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],lf[209]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7509,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 816  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7507 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7509,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7512,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 817  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[210]);}
else{
/* expand.scm: 825  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[7],((C_word*)t0)[2],lf[211],((C_word*)t0)[4]);}}

/* k7510 in k7507 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7515,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* expand.scm: 818  tostr */
t4=((C_word*)t0)[2];
f_7005(t4,t2,t3);}

/* k7513 in k7510 in k7507 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7517,a[2]=t1,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7548,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k7546 in k7513 in k7510 in k7507 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7552,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7550 in k7546 in k7513 in k7510 in k7507 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7552,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ren in k7513 in k7510 in k7507 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7517(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7517,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7525,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7533,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7537,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* expand.scm: 822  ##sys#symbol->string */
t7=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* k7535 in ren in k7513 in k7510 in k7507 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 822  ##sys#string-append */
t2=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7531 in ren in k7513 in k7510 in k7507 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 821  ##sys#string->symbol */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7523 in ren in k7513 in k7510 in k7507 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7525,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k7363 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7365,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7374,a[2]=t4,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7374(t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in k7363 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_7374(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7374,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7390,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7395,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t9=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7451,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t3,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 800  caar */
t8=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7503,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=t2,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 807  caar */
t8=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}}

/* k7501 in loop in k7363 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7503,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7484,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 810  cdar */
t6=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 813  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7374(t6,((C_word*)t0)[4],t3,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k7482 in k7501 in loop in k7363 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7484,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7472,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 812  ##sys#delq */
t5=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7470 in k7482 in k7501 in loop in k7363 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 809  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7374(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7449 in loop in k7363 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7451,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7432,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 804  cdar */
t6=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 806  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7374(t6,((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2],t5,((C_word*)t0)[8]);}}

/* k7430 in k7449 in loop in k7363 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7432,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7420,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 805  ##sys#delq */
t5=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7418 in k7430 in k7449 in loop in k7363 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 802  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7374(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7394 in loop in k7363 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7395(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7395,3,t0,t1,t2);}
/* expand.scm: 797  ##sys#warn */
t3=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[205],t2);}

/* k7388 in loop in k7363 in k7360 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7390,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k7256 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7261,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7259 in k7256 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7261,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7266,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7266(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k7259 in k7256 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_7266(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7266,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7278,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7278(t7,t1,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7352,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 788  caar */
t5=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7350 in loop in k7259 in k7256 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7352,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 788  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7266(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 789  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7266(t5,((C_word*)t0)[3],t2,t4);}}

/* loop in loop in k7259 in k7256 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_7278(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7278,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7320,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 786  caar */
t5=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7318 in loop in loop in k7259 in k7256 in k7253 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7320,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 786  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7278(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 787  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7278(t5,((C_word*)t0)[3],t2,t4);}}

/* k7176 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7181,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7179 in k7176 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7181,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7186,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7186(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k7179 in k7176 in k7173 in k7161 in k7152 in import-spec in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_7186(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7186,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_assq(t5,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* expand.scm: 774  loop */
t15=t1;
t16=t7;
t17=t8;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_assq(t7,((C_word*)t0)[2]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t8,t4);
/* expand.scm: 777  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t10;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
/* expand.scm: 778  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}}

/* import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_7048(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7048,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7052,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 739  resolve */
t4=((C_word*)t0)[2];
f_6996(3,t4,t3,t2);}

/* k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7055,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 740  ##sys#find-module */
t3=C_retrieve(lf[194]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_SCHEME_FALSE);}

/* k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7055,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7058,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t3)[1])){
t5=t4;
f_7058(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7129,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7133,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 743  symbol->string */
t8=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[3]);}}

/* k7131 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 743  string-append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[200]);}

/* k7127 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 742  ##sys#find-extension */
t2=C_retrieve(lf[199]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7070,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[80]);
t3=C_retrieve(lf[8]);
t4=C_retrieve(lf[9]);
t5=C_retrieve(lf[29]);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7076,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t3,a[8]=t4,a[9]=t5,a[10]=t9,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 747  ##sys#current-meta-environment */
t11=C_retrieve(lf[9]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}
else{
/* expand.scm: 752  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[198],((C_word*)t0)[3]);}}

/* k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7076,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 748  ##sys#meta-macro-environment */
t5=C_retrieve(lf[197]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7079,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7080,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word)li79),tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7118,a[2]=((C_word*)t0)[2],a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t7=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t4,t6,t4);}

/* a7117 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7118,2,t0,t1);}
/* expand.scm: 749  ##sys#load */
t2=C_retrieve(lf[195]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7110 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7116,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 750  ##sys#find-module */
t3=C_retrieve(lf[194]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k7114 in k7110 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7058(2,t3,t2);}

/* swap1402 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* g140514061421 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7082 in swap1402 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7087,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* g140514061421 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[10])[1]);}

/* k7085 in k7082 in swap1402 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7087,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g140714081422 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7089 in k7085 in k7082 in swap1402 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7094,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g140714081422 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k7092 in k7089 in k7085 in k7082 in swap1402 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7094,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g140914101423 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7096 in k7092 in k7089 in k7085 in k7082 in swap1402 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7101,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g140914101423 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k7099 in k7096 in k7092 in k7089 in k7085 in k7082 in swap1402 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7101,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g141114121424 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7103 in k7099 in k7096 in k7092 in k7089 in k7085 in k7082 in swap1402 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7108,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g141114121424 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k7106 in k7103 in k7099 in k7096 in k7092 in k7089 in k7085 in k7082 in swap1402 in k7077 in k7074 in k7068 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7056 in k7053 in k7050 in import-name in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7058,2,t0,t1);}
t2=f_9710(((C_word*)((C_word*)t0)[3])[1]);
t3=f_9728(((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* tostr in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_7005(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7005,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7018,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 734  keyword? */
t4=C_retrieve(lf[145]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k7016 in tostr in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7018,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7025,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 734  ##sys#symbol->string */
t3=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* expand.scm: 735  ##sys#symbol->string */
t2=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
/* expand.scm: 736  number->string */
C_number_to_string(3,0,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* expand.scm: 737  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[191]);}}}}

/* k7023 in k7016 in tostr in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 734  ##sys#string-append */
t2=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[189]);}

/* resolve in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6996,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7000,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 731  lookup */
f_3582(t3,t2,C_SCHEME_END_OF_LIST);}

/* k6998 in resolve in k6992 in k6989 in k6986 in k6983 in ##sys#expand-import in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_7000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##sys#er-transformer in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6687,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6689,a[2]=t2,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));}

/* f_6689 in ##sys#er-transformer in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6689,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6692,a[2]=t3,a[3]=t6,a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6955,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6818,a[2]=t4,a[3]=t8,a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 720  handler */
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t1,t2,t7,t9);}

/* compare */
static void C_ccall f_6818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6818,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6822,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_symbolp(t2);
t6=(C_truep(t5)?(C_word)C_i_symbolp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6851,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 691  ##sys#get */
t8=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t2,lf[12]);}
else{
t7=t4;
f_6822(t7,(C_word)C_eqp(t2,t3));}}

/* k6849 in compare */
static void C_ccall f_6851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6854(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6941,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 692  lookup2 */
f_6955(t3,C_fix(1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k6939 in k6849 in compare */
static void C_ccall f_6941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6854(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6852 in k6849 in compare */
static void C_fcall f_6854(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6854,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 694  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[12]);}

/* k6855 in k6852 in k6849 in compare */
static void C_ccall f_6857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6860,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6860(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6935,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 695  lookup2 */
f_6955(t3,C_fix(2),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6933 in k6855 in k6852 in k6849 in compare */
static void C_ccall f_6935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6860(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6858 in k6855 in k6852 in k6849 in compare */
static void C_fcall f_6860(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6860,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6879,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 699  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[83]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6906,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 701  ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}
else{
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 705  ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_6822(t2,(C_word)C_eqp(((C_word*)t0)[3],t1));}}}

/* k6927 in k6858 in k6855 in k6852 in k6849 in compare */
static void C_ccall f_6929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6822(t4,(C_word)C_eqp(((C_word*)t0)[2],t3));}
else{
t3=((C_word*)t0)[3];
f_6822(t3,C_SCHEME_FALSE);}}

/* k6904 in k6858 in k6855 in k6852 in k6849 in compare */
static void C_ccall f_6906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6822(t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[3];
f_6822(t3,C_SCHEME_FALSE);}}

/* k6877 in k6858 in k6855 in k6852 in k6849 in compare */
static void C_ccall f_6879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6879,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6886,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 700  ##sys#get */
t4=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],lf[83]);}

/* k6884 in k6877 in k6858 in k6855 in k6852 in k6849 in compare */
static void C_ccall f_6886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_6822(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k6820 in compare */
static void C_fcall f_6822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6822,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6825,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[186],t6);
/* expand.scm: 710  dd */
t8=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t8))(3,t8,t2,t7);}

/* k6823 in k6820 in compare */
static void C_ccall f_6825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup2 */
static void C_fcall f_6955(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6955,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6959,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 713  lookup */
f_3582(t5,t3,t4);}

/* k6957 in lookup2 */
static void C_ccall f_6959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6962,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t4=(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE);
t5=(C_truep(t4)?lf[14]:t1);
/* expand.scm: 714  dd */
t6=C_retrieve2(lf[6],"dd");
((C_proc9)C_retrieve_proc(t6))(9,t6,t2,lf[182],t3,lf[183],((C_word*)t0)[2],lf[184],t5,lf[185]);}

/* k6960 in k6957 in lookup2 */
static void C_ccall f_6962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* rename */
static void C_ccall f_6692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6692,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6702,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[47],t6);
t8=(C_word)C_a_i_cons(&a,2,t2,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[178],t8);
/* expand.scm: 671  dd */
t10=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t10))(3,t10,t4,t9);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 673  lookup */
f_3582(t4,t2,((C_word*)t0)[2]);}}

/* k6726 in rename */
static void C_ccall f_6728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6728,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6740,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[179],t5);
/* expand.scm: 676  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6759,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 679  macro-alias */
f_3600(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6789,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 684  macro-alias */
f_3600(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6787 in k6726 in rename */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[181],t5);
/* expand.scm: 685  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}

/* k6790 in k6787 in k6726 in rename */
static void C_ccall f_6792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6792,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6757 in k6726 in rename */
static void C_ccall f_6759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[180],t5);
/* expand.scm: 680  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}

/* k6760 in k6757 in k6726 in rename */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6762,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6738 in k6726 in rename */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6700 in rename */
static void C_ccall f_6702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr5r,(void*)f_6225r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6225r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6225r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6227,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word)li68),tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6630,a[2]=t6,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6639,a[2]=t7,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-culprit10181176 */
t9=t8;
f_6639(t9,t1);}
else{
t9=(C_word)C_i_car(t5);
t10=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-se10191172 */
t11=t7;
f_6630(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body10161025 */
t13=t6;
f_6227(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-culprit1018 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6639,NULL,2,t0,t1);}
/* def-se10191172 */
t2=((C_word*)t0)[2];
f_6630(t2,t1,C_SCHEME_FALSE);}

/* def-se1019 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6630(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6630,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6638,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 585  ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6636 in def-se1019 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body10161025 */
t2=((C_word*)t0)[4];
f_6227(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6227(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6227,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6242,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word)li59),tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6230,a[2]=t4,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6273,a[2]=((C_word*)t0)[3],a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6329,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t3,a[6]=t6,a[7]=t7,a[8]=t5,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t9=C_mutate((C_word*)lf[139]+1 /* (set! syntax-error-culprit ...) */,t2);
t10=t8;
f_6358(t10,t9);}
else{
t9=t8;
f_6358(t9,C_SCHEME_UNDEFINED);}}

/* k6356 in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6358,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6363(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k6356 in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6363,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t3))){
t4=(C_word)C_i_vector_ref(t3,C_fix(0));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6382,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_eqp(t5,C_fix(1));
if(C_truep(t9)){
t10=t8;
f_6382(t10,C_fix(1));}
else{
t10=(C_word)C_fixnum_greaterp(t5,C_fix(2));
t11=t8;
f_6382(t11,(C_truep(t10)?(C_word)C_i_vector_ref(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_immp(t3))){
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 638  err */
t5=((C_word*)t0)[7];
f_6242(t5,t1,lf[155]);}}
else{
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t3;
t5=(C_word)C_eqp(t4,lf[57]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t4,lf[156]);
if(C_truep(t6)){
/* expand.scm: 642  test */
t7=((C_word*)t0)[5];
f_6230(t7,t1,t2,*((C_word*)lf[157]+1),lf[158]);}
else{
t7=(C_word)C_eqp(t4,lf[159]);
if(C_truep(t7)){
/* expand.scm: 643  test */
t8=((C_word*)t0)[5];
f_6230(t8,t1,t2,*((C_word*)lf[160]+1),lf[161]);}
else{
t8=(C_word)C_eqp(t4,lf[162]);
if(C_truep(t8)){
/* expand.scm: 644  test */
t9=((C_word*)t0)[5];
f_6230(t9,t1,t2,*((C_word*)lf[160]+1),lf[163]);}
else{
t9=(C_word)C_eqp(t4,lf[164]);
if(C_truep(t9)){
/* expand.scm: 645  test */
t10=((C_word*)t0)[5];
f_6230(t10,t1,t2,((C_word*)t0)[4],lf[165]);}
else{
t10=(C_word)C_eqp(t4,lf[166]);
if(C_truep(t10)){
/* expand.scm: 646  test */
t11=((C_word*)t0)[5];
f_6230(t11,t1,t2,*((C_word*)lf[167]+1),lf[168]);}
else{
t11=(C_word)C_eqp(t4,lf[169]);
if(C_truep(t11)){
/* expand.scm: 647  test */
t12=((C_word*)t0)[5];
f_6230(t12,t1,t2,*((C_word*)lf[170]+1),lf[171]);}
else{
t12=(C_word)C_eqp(t4,lf[172]);
if(C_truep(t12)){
/* expand.scm: 648  test */
t13=((C_word*)t0)[5];
f_6230(t13,t1,t2,((C_word*)t0)[3],lf[173]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6560,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li66),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 650  test */
t14=((C_word*)t0)[5];
f_6230(t14,t1,t2,t13,lf[174]);}}}}}}}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6601,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 660  walk */
t26=t4;
t27=t5;
t28=t6;
t1=t26;
t2=t27;
t3=t28;
goto loop;}
else{
/* expand.scm: 658  err */
t4=((C_word*)t0)[7];
f_6242(t4,t1,lf[175]);}}
else{
/* expand.scm: 657  err */
t4=((C_word*)t0)[7];
f_6242(t4,t1,lf[176]);}}}}}

/* k6599 in walk in k6356 in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 661  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6363(t4,((C_word*)t0)[2],t2,t3);}

/* a6559 in walk in k6356 in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6560,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6564,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 653  lookup */
f_3582(t3,t2,((C_word*)t0)[2]);}
else{
t4=t3;
f_6564(2,t4,C_SCHEME_FALSE);}}

/* k6562 in a6559 in walk in k6356 in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}

/* k6380 in walk in k6356 in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6382,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li65),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6387(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop1129 in k6380 in walk in k6356 in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6387(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6387,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* expand.scm: 631  err */
t5=((C_word*)t0)[6];
f_6242(t5,t1,lf[152]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6406,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* expand.scm: 633  err */
t6=((C_word*)t0)[6];
f_6242(t6,t5,lf[153]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
/* expand.scm: 636  walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6363(t7,t5,t6,((C_word*)t0)[2]);}
else{
/* expand.scm: 635  err */
t6=((C_word*)t0)[6];
f_6242(t6,t5,lf[154]);}}}}

/* k6404 in doloop1129 in k6380 in walk in k6356 in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6387(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6329(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6329,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6335,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_6335(t2));}

/* loop in proper-list? in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static C_word C_fcall f_6335(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6273(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6273,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6277,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 600  ##sys#extended-lambda-list? */
t4=C_retrieve(lf[88]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6275 in lambda-list? in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6277,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6285,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6285(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k6275 in lambda-list? in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6285(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6285,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6305,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 603  keyword? */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 607  loop */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k6303 in loop in k6275 in lambda-list? in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6230(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6230,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6237,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 588  pred */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k6235 in test in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 588  err */
t2=((C_word*)t0)[3];
f_6242(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6242,NULL,3,t0,t1,t2);}
t3=C_retrieve(lf[139]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 592  get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6244 in err in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6253,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6260,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 595  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6271,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 596  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k6269 in k6244 in err in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 596  string-append */
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[150],t1,lf[151],((C_word*)t0)[2]);}

/* k6258 in k6244 in err in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6264,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 595  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k6262 in k6258 in k6244 in err in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 595  string-append */
t2=((C_word*)t0)[5];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],lf[147],((C_word*)t0)[3],lf[148],t1,lf[149],((C_word*)t0)[2]);}

/* k6251 in k6244 in err in body1016 in ##sys#check-syntax in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 593  ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6189,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[138]))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6211,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 574  ##sys#hash-table-ref */
t5=C_retrieve(lf[144]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[138]),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6209 in get-line-number in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6178r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6178r(t0,t1,t2);}}

static void C_ccall f_6178r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6186,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 565  ##sys#strip-syntax */
t4=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6184 in ##sys#syntax-error-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],C_retrieve(lf[140]),lf[141],t1);}

/* ##sys#expand-curried-define in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6108,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6111,a[2]=t8,a[3]=t6,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6171,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 554  loop */
t11=((C_word*)t8)[1];
f_6111(t11,t10,t2,t3);}

/* k6169 in ##sys#expand-curried-define in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6171,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6111(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6111,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_i_cdr(t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6137,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6164,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t3,C_SCHEME_END_OF_LIST);}}

/* k6162 in loop in ##sys#expand-curried-define in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6164,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* expand.scm: 553  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6111(t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k6135 in loop in ##sys#expand-curried-define in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6137,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[97],t2));}

/* match-expression in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6025(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6025,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6028,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6106,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 541  mwalk */
t11=((C_word*)t8)[1];
f_6028(t11,t10,t2,t3);}

/* k6104 in match-expression in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in match-expression in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_6028(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6028,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6077,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 538  mwalk */
t13=t4;
t14=t5;
t15=t6;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_i_assq(t3,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t2,t5));}
else{
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[2]))){
t5=(C_word)C_a_i_cons(&a,2,t3,t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}}

/* k6075 in mwalk in match-expression in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 539  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6028(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5272(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5272r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5272r(t0,t1,t2,t3);}}

static void C_ccall f_5272r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5276,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 415  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5276(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5276,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5278,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t7,a[6]=((C_word)li46),tmp=(C_word)a,a+=7,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5538,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5715,a[2]=t3,a[3]=t5,a[4]=t1,a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
/* expand.scm: 522  expand */
t11=((C_word*)t7)[1];
f_5715(t11,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5715(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5715,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li50),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5721(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5721,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_i_car(t7):C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5743,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t1,a[7]=t6,a[8]=t5,a[9]=t8,a[10]=((C_word*)t0)[4],a[11]=t4,a[12]=t3,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t10)){
if(C_truep((C_word)C_i_symbolp(t10))){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5985,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 482  lookup */
f_3582(t12,t10,((C_word*)t0)[5]);}
else{
t12=t11;
f_5743(t12,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5743(t12,C_SCHEME_FALSE);}}
else{
/* expand.scm: 476  fini */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5278(t7,t1,t3,t4,t5,t6,t2);}}

/* k5983 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5743(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5743(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5743,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(C_word)C_eqp(lf[117],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5761,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 485  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[117],((C_word*)t0)[5],lf[133],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t3=(C_word)C_eqp(lf[124],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5887,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 507  ##sys#check-syntax */
t5=C_retrieve(lf[64]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[124],((C_word*)t0)[5],lf[134],((C_word*)t0)[13]);}
else{
t4=(C_word)C_eqp(lf[118],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5899,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 510  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[118],((C_word*)t0)[5],lf[135],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t5=(C_word)C_eqp(lf[116],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5927,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 513  ##sys#check-syntax */
t7=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t6,lf[116],((C_word*)t0)[5],lf[136],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t6=(C_word)C_i_memq(t1,((C_word*)t0)[12]);
t7=(C_truep(t6)?t6:(C_word)C_i_memq(t1,((C_word*)t0)[8]));
if(C_truep(t7)){
/* expand.scm: 516  fini */
t8=((C_word*)((C_word*)t0)[2])[1];
f_5278(t8,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5953,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 518  ##sys#expand-0 */
t9=C_retrieve(lf[38]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[5],((C_word*)t0)[13]);}}}}}}
else{
/* expand.scm: 483  fini */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5278(t2,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}}

/* k5951 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5953,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* expand.scm: 520  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_5278(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* expand.scm: 521  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5721(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k5925 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5934,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 514  ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k5932 in k5925 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 514  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5721(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5897 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5899,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* expand.scm: 511  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_5721(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k5885 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 508  fini/syntax */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5538(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5759 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5761,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5766,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li49),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5766(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k5759 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5766(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5766,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5813,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 497  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[117],t2,lf[129],C_SCHEME_FALSE,((C_word*)t0)[8]);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5835,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 501  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[117],t2,lf[130],C_SCHEME_FALSE,((C_word*)t0)[8]);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 489  ##sys#check-syntax */
t5=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t4,lf[117],t2,lf[132],C_SCHEME_FALSE,((C_word*)t0)[8]);}}

/* k5777 in loop2 in k5759 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5779,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[8]):lf[131]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* expand.scm: 490  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_5721(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5833 in loop2 in k5759 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5835,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k5860 in k5833 in loop2 in k5759 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5862,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
/* expand.scm: 502  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5721(t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5811 in loop2 in k5759 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 498  macro-alias */
f_3600(t2,lf[117],((C_word*)t0)[2]);}

/* k5822 in k5811 in loop2 in k5759 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5828,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* expand.scm: 499  ##sys#expand-curried-define */
t4=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5826 in k5822 in k5811 in loop2 in k5759 in k5741 in loop in expand in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5828,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 498  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5766(t3,((C_word*)t0)[2],t2);}

/* fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5538(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5538,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5546,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5548,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5548(t11,t7,t6,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5548(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5548,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5563,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 457  macro-alias */
f_3600(t5,lf[123],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5594,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_length(t7);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_fix(3),t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5697,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 462  caar */
t10=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}
else{
t9=t5;
f_5594(t9,C_SCHEME_FALSE);}}
else{
t7=t5;
f_5594(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 459  loop */
t12=t1;
t13=t2;
t14=t3;
t15=C_SCHEME_TRUE;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}}

/* k5695 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5697,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5693,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 463  caar */
t4=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
f_5594(t2,C_SCHEME_FALSE);}}

/* k5691 in k5695 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 463  lookup */
f_3582(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5681 in k5695 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5686,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5686(2,t3,t1);}
else{
/* expand.scm: 463  caar */
t3=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k5684 in k5681 in k5695 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5594(t2,(C_word)C_eqp(lf[124],t1));}

/* k5592 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5594,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5612,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5626,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 468  caadr */
t7=*((C_word*)lf[127]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=t4;
f_5612(t6,t2);}}
else{
/* expand.scm: 472  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5548(t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_TRUE);}}

/* k5624 in k5592 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 468  macro-alias */
f_3600(t2,lf[126],((C_word*)t0)[2]);}

/* k5636 in k5624 in k5592 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 468  cdadr */
t3=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5644 in k5636 in k5624 in k5592 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5650,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5648 in k5644 in k5636 in k5624 in k5592 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5650,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
f_5612(t6,(C_word)C_a_i_cons(&a,2,lf[124],t5));}

/* k5610 in k5592 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5612,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* expand.scm: 465  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5548(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k5561 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5571,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5579,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 458  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5577 in k5561 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 458  map */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[122]+1),t1);}

/* k5569 in k5561 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5573 in k5569 in k5561 in loop in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5575,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k5544 in fini/syntax in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 454  fini */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5278(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5278(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5278,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5290,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li41),tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_5290(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5389,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 433  reverse */
t10=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}

/* k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5411,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5518,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5530,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[51]+1),t1,((C_word*)t0)[3]);}

/* k5528 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 436  ##sys#map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5517 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5518,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[121]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5415,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5419,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5500,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5516,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 438  reverse */
t6=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5514 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 438  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5499 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5500,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k5417 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5423,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5427,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5433,a[2]=((C_word*)t0)[5],a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 448  reverse */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5492 in k5417 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5498,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 449  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5496 in k5492 in k5417 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 439  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5432 in k5417 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5433,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5437,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 440  ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[18]),t2);}

/* k5435 in a5432 in k5417 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5437,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5464,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5468,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5470,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 445  map */
t8=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a5469 in k5435 in a5432 in k5417 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5470,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k5466 in k5435 in a5432 in k5417 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5462 in k5435 in a5432 in k5417 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5464,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[120],t5));}

/* k5425 in k5417 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5431,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5429 in k5425 in k5417 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5421 in k5417 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5413 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5415,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[59],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5395,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[119],t5);
/* expand.scm: 451  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t4,t6);}

/* k5393 in k5413 in k5409 in k5387 in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5290,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5313,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5379,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 427  lookup */
f_3582(t7,t6,((C_word*)t0)[4]);}
else{
t7=t5;
f_5313(t7,C_SCHEME_FALSE);}}
else{
t6=t5;
f_5313(t6,C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5304,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 421  macro-alias */
f_3600(t4,lf[116],((C_word*)t0)[4]);}}

/* k5302 in loop in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5304,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5377 in loop in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5379,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[117]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_5313(t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5372,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 428  lookup */
f_3582(t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k5370 in k5377 in loop in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_5313(t3,(C_word)C_eqp(t2,lf[118]));}

/* k5311 in loop in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5313,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5320,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 430  macro-alias */
f_3600(t2,lf[116],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]);
/* expand.scm: 432  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5290(t4,((C_word*)t0)[9],t2,t3);}}

/* k5318 in k5311 in loop in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5324,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5328,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 431  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5326 in k5318 in k5311 in loop in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5336,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 431  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5715(t3,t2,((C_word*)t0)[2]);}

/* k5334 in k5326 in k5318 in k5311 in loop in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5336,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* expand.scm: 431  ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5322 in k5318 in k5311 in loop in fini in k5274 in ##sys#canonicalize-body in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4682,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4685,a[2]=t2,a[3]=t4,a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4702,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t10,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 322  macro-alias */
f_3600(t11,lf[113],t5);}

/* k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 324  macro-alias */
f_3600(t2,lf[112],((C_word*)t0)[4]);}

/* k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 325  macro-alias */
f_3600(t2,lf[111],((C_word*)t0)[4]);}

/* k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 326  macro-alias */
f_3600(t2,lf[110],((C_word*)t0)[4]);}

/* k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* expand.scm: 327  macro-alias */
f_3600(t2,lf[58],((C_word*)t0)[4]);}

/* k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4714,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4719,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word)li39),tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_4719(t5,((C_word*)t0)[3],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4719,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t5,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t4,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)((C_word*)t0)[13])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4986,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 335  reverse */
t9=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}
else{
/* expand.scm: 335  reverse */
t8=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* expand.scm: 363  err */
t7=((C_word*)t0)[4];
f_4685(t7,t1,lf[99]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5007,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[13])[1];
if(C_truep(t8)){
t9=t7;
f_5007(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t6);
t10=t7;
f_5007(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5030,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[3],a[11]=t2,a[12]=t6,a[13]=t7,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t7))){
/* expand.scm: 372  lookup */
f_3582(t8,t7,((C_word*)t0)[2]);}
else{
t9=t8;
f_5030(2,t9,C_SCHEME_FALSE);}}
else{
/* expand.scm: 369  err */
t7=((C_word*)t0)[4];
f_4685(t7,t1,lf[109]);}}}}

/* k5028 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[13]);
t3=(C_word)C_i_cdr(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t2,lf[90]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5045,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t6)){
t7=t5;
f_5045(t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5064,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 376  macro-alias */
f_3600(t7,lf[101],((C_word*)t0)[5]);}}
else{
t5=(C_word)C_eqp(t2,lf[89]);
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[11],C_fix(1)))){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5082,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[4],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_5082(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_5082(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 388  err */
t6=((C_word*)t0)[7];
f_4685(t6,((C_word*)t0)[9],lf[103]);}}
else{
t6=(C_word)C_eqp(t2,lf[91]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t8)){
t9=t7;
f_5128(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5147,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 390  macro-alias */
f_3600(t9,lf[101],((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t7=((C_word*)t0)[11];
switch(t7){
case C_fix(0):
t8=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
/* expand.scm: 397  loop */
t9=((C_word*)((C_word*)t0)[10])[1];
f_4719(t9,((C_word*)t0)[9],C_fix(0),t8,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3);
case C_fix(1):
t8=(C_word)C_a_i_list(&a,2,t2,C_SCHEME_FALSE);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[3]);
/* expand.scm: 398  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4719(t10,((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8],t9,C_SCHEME_END_OF_LIST,t3);
case C_fix(2):
/* expand.scm: 399  err */
t8=((C_word*)t0)[7];
f_4685(t8,((C_word*)t0)[9],lf[105]);
default:
t8=(C_word)C_a_i_list(&a,1,t2);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[2]);
/* expand.scm: 400  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4719(t10,((C_word*)t0)[9],C_fix(3),((C_word*)t0)[8],((C_word*)t0)[3],t9,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5209,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t8=(C_word)C_i_length(t2);
t9=t7;
f_5209(t9,(C_word)C_eqp(C_fix(2),t8));}
else{
t8=t7;
f_5209(t8,C_SCHEME_FALSE);}}}}}}

/* k5207 in k5028 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5209(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5209,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* expand.scm: 403  err */
t3=((C_word*)t0)[9];
f_4685(t3,((C_word*)t0)[8],lf[106]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* expand.scm: 404  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4719(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* expand.scm: 405  err */
t3=((C_word*)t0)[9];
f_4685(t3,((C_word*)t0)[8],lf[107]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* expand.scm: 406  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4719(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* expand.scm: 407  err */
t2=((C_word*)t0)[9];
f_4685(t2,((C_word*)t0)[8],lf[108]);}}

/* k5145 in k5028 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5128(t3,t2);}

/* k5126 in k5028 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5128(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* expand.scm: 392  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_4719(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 393  err */
t2=((C_word*)t0)[2];
f_4685(t2,((C_word*)t0)[6],lf[104]);}}

/* k5080 in k5028 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5082(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5082,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5085,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_5085(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_5085(t6,t5);}}
else{
/* expand.scm: 387  err */
t2=((C_word*)t0)[2];
f_4685(t2,((C_word*)t0)[6],lf[102]);}}

/* k5083 in k5080 in k5028 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5085(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 386  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4719(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k5062 in k5028 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5045(t3,t2);}

/* k5043 in k5028 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5045(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* expand.scm: 378  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4719(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 379  err */
t3=((C_word*)t0)[2];
f_4685(t3,((C_word*)t0)[5],lf[100]);}}

/* k5005 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_5007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* expand.scm: 367  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4719(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k4984 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 335  ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4737,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t3=t2;
f_4737(t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4900,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4906,a[2]=((C_word*)t0)[11],a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4979,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 347  reverse */
t6=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}

/* k4977 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4905 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4906,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4975,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* expand.scm: 319  string->keyword */
t6=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k4973 in a4905 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4975,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4941,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4959,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t7=t5;
f_4941(t7,C_SCHEME_END_OF_LIST);}}

/* k4957 in k4973 in a4905 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4959,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=((C_word*)t0)[2];
f_4941(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4939 in k4973 in a4905 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4935 in k4973 in a4905 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4937,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[96],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k4898 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4902 in k4898 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4904,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4737(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4735 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4737(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4737,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4740,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[10]))){
t3=t2;
f_4740(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t4)){
t5=t3;
f_4749(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[10]);
t6=t3;
f_4749(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_4749(t5,C_SCHEME_FALSE);}}}}

/* k4747 in k4735 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4749(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4749,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 352  caar */
t3=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[5]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4821,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 356  reverse */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4852,a[2]=t4,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 359  reverse */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}}

/* k4850 in k4747 in k4735 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4852,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* expand.scm: 359  ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4842 in k4747 in k4735 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4846 in k4842 in k4747 in k4735 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4740(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4819 in k4747 in k4735 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4823 in k4819 in k4747 in k4735 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4825,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4740(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4774 in k4747 in k4735 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 352  cadar */
t3=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4794 in k4774 in k4747 in k4735 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4796,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4768,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4766 in k4794 in k4774 in k4747 in k4735 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4768,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4740(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4738 in k4735 in k4731 in loop in k4712 in k4709 in k4706 in k4703 in k4700 in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 334  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4685(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4685,NULL,3,t0,t1,t2);}
/* expand.scm: 318  errh */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4639,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4645,a[2]=t4,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4645(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4645(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4645,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[89]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4664(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[90]);
t7=t5;
f_4664(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[91])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4662 in loop in ##sys#extended-lambda-list? in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 312  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4645(t3,((C_word*)t0)[4],t2);}}

/* ##sys#expand in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4586r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4586r(t0,t1,t2,t3);}}

static void C_ccall f_4586r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4590,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 285  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4590(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4588 in ##sys#expand in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4590,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4595,a[2]=t3,a[3]=t1,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4595(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4588 in ##sys#expand in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4595(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4595,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[2],a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a4606 in loop in k4588 in ##sys#expand in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4607,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* expand.scm: 289  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4595(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a4600 in loop in k4588 in ##sys#expand in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
/* expand.scm: 287  ##sys#expand-0 */
t2=C_retrieve(lf[38]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4496,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4499,a[2]=t3,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4532,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 265  ##sys#qualified-symbol? */
t6=C_retrieve(lf[19]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k4530 in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4532,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 266  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[83]);}}

/* k4533 in k4530 in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4535,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4541,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 268  dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[81],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 270  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[85]);}}

/* k4545 in k4533 in k4530 in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4547,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 271  dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[82],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4584,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 273  ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k4582 in k4545 in k4533 in k4530 in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4584,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 275  dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[84],((C_word*)t0)[4]);}
else{
/* expand.scm: 280  mrename */
t3=((C_word*)t0)[3];
f_4499(t3,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k4557 in k4582 in k4545 in k4533 in k4530 in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t2))){
/* expand.scm: 278  mrename */
t3=((C_word*)t0)[4];
f_4499(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4574,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 279  ##sys#get */
t4=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[83]);}}

/* k4572 in k4557 in k4582 in k4545 in k4533 in k4530 in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4548 in k4545 in k4533 in k4530 in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4539 in k4533 in k4530 in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* mrename in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4499(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4499,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4503,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 259  ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k4501 in mrename in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4503,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=f_9548(t1);
/* expand.scm: 261  dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[78],((C_word*)t0)[3],lf[79],t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k4507 in k4501 in mrename in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4512(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 262  ##sys#register-undefined */
t3=C_retrieve(lf[77]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k4510 in k4507 in k4501 in mrename in ##sys#alias-global-hook in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_9548(((C_word*)t0)[4]);
/* expand.scm: 263  ##sys#module-rename */
t3=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* ##sys#module-rename in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4478,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4486,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 252  string-append */
t7=*((C_word*)lf[42]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t4,t5,lf[75],t6);}

/* k4484 in ##sys#module-rename in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 251  ##sys#string->symbol */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3996,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3999,a[2]=t3,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4178,a[2]=t4,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4295,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t7,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 217  lookup */
f_3582(t8,t6,t3);}
else{
/* expand.scm: 245  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* expand.scm: 246  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4295,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[7]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4301,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=t5;
f_4301(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4462,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4469,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 219  ##sys#macro-environment */
t8=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}}

/* k4467 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 219  lookup */
f_3582(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4460 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4301(t4,t3);}

/* k4299 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4301,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[58]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4310,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 221  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[58],((C_word*)t0)[7],lf[66],C_SCHEME_FALSE,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t4,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[71]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=t3;
f_4403(t6,(C_word)C_i_pairp(t5));}
else{
t5=t3;
f_4403(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4403(t5,C_SCHEME_FALSE);}}}

/* k4401 in k4299 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4403,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 238  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[69],((C_word*)t0)[8],lf[70],C_SCHEME_FALSE,((C_word*)t0)[6]);}
else{
/* expand.scm: 244  expand */
t2=((C_word*)t0)[5];
f_4178(t2,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4407 in k4401 in k4299 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[67],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* expand.scm: 240  append */
t8=*((C_word*)lf[68]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t2,t5,t6,t7);}

/* k4414 in k4407 in k4401 in k4299 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 239  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k4308 in k4299 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4322,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 224  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[58],((C_word*)t0)[5],lf[65],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
/* expand.scm: 233  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4320 in k4308 in k4299 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4322,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4380,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4390,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a4389 in k4320 in k4308 in k4299 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4390,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k4378 in k4320 in k4308 in k4299 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k4382 in k4378 in k4320 in k4308 in k4299 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4384,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[60],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[61],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[3],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4348,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 231  ##sys#map */
t12=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[63]+1),((C_word*)t0)[2]);}

/* k4346 in k4382 in k4378 in k4320 in k4308 in k4299 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4342 in k4382 in k4378 in k4320 in k4308 in k4299 in k4293 in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[62],t2);
/* expand.scm: 226  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4178(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4178,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4182,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4235,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 198  get */
t7=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,lf[12]);}

/* k4233 in expand in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_symbolp(t1);
t4=t2;
f_4238(t4,(C_truep(t3)?t1:lf[14]));}
else{
t3=t2;
f_4238(t3,lf[57]);}}

/* k4236 in k4233 in expand in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4238,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4260,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4264,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 203  map-se */
f_3649(t4,t5);}
else{
t3=t2;
f_4250(t3,((C_word*)t0)[2]);}}

/* k4262 in k4236 in k4233 in expand in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4258 in k4236 in k4233 in expand in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4260,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4250(t2,(C_word)C_a_i_cons(&a,2,lf[56],t1));}

/* k4248 in k4236 in k4233 in expand in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4250,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[55],t5);
/* expand.scm: 196  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[2],t6);}

/* k4180 in expand in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4182,2,t0,t1);}
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4204,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 210  call-handler */
t5=((C_word*)t0)[3];
f_3999(t5,t2,((C_word*)t0)[2],t3,((C_word*)t0)[6],t4);}
else{
/* expand.scm: 212  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[6],C_SCHEME_FALSE);}}
else{
/* expand.scm: 206  ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[54],((C_word*)t0)[6]);}}

/* k4202 in k4180 in expand in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 208  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_3999(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3999,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 163  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[52],t2);}

/* k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4172,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4176,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 164  map-se */
f_3649(t4,((C_word*)t0)[3]);}

/* k4174 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4170 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4172,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[50],t1);
/* expand.scm: 164  dd */
t3=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[49]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4014,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4020,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4127,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li22),tmp=(C_word)a,a+=9,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4126 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4133,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li19),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[2],a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4153 in a4126 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4154r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4154r(t0,t1,t2);}}

static void C_ccall f_4154r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4160,a[2]=t2,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* k261266 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4159 in a4153 in a4126 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4160,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4132 in a4126 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4137,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 192  handler */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4135 in a4132 in a4126 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4140,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
/* expand.scm: 193  dd */
t6=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}

/* k4138 in k4135 in a4132 in a4126 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4019 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4020,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4026,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
/* k261266 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4025 in a4019 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4034,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[3],lf[40]))){
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=t3;
f_4037(t5,(C_word)C_i_memq(lf[46],t4));}
else{
t4=t3;
f_4037(t4,C_SCHEME_FALSE);}}

/* k4035 in a4025 in a4019 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4037(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4037,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4048,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4054,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4054(t8,t3,t4);}
else{
t2=((C_word*)t0)[3];
f_4034(t2,((C_word*)t0)[4]);}}

/* copy in k4035 in a4025 in a4019 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4054(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4054,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_equalp(lf[45],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=t5;
f_4073(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_4073(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_4073(t6,C_SCHEME_FALSE);}}}

/* k4071 in copy in k4035 in a4025 in a4019 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4073(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4073,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 184  string-append */
t5=*((C_word*)lf[42]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[43],t3,lf[44],t4);}
else{
/* expand.scm: 190  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4054(t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k4082 in k4071 in copy in k4035 in a4025 in a4019 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4084,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[41],t3));}

/* k4046 in k4035 in a4025 in a4019 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=((C_word*)t0)[3];
f_4034(t2,(C_word)C_a_i_record(&a,3,lf[40],((C_word*)t0)[2],t1));}

/* k4032 in a4025 in a4019 in a4013 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_4034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 168  ##sys#abort */
t2=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4010 in k4004 in k4001 in call-handler in ##sys#expand-0 in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3987,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[37]);
/* expand.scm: 156  ##sys#unregister-macro */
t4=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* ##sys#unregister-macro in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3936,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3944,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3948,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 149  ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3946 in ##sys#unregister-macro in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3950,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3950(t5,((C_word*)t0)[2],t1);}

/* loop in k3946 in ##sys#unregister-macro in k3828 in k3578 in k3574 in k3547 */
static void C_fcall f_3950(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3950,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 151  caar */
t4=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k3983 in loop in k3946 in ##sys#unregister-macro in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3977,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 152  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3950(t6,t4,t5);}}

/* k3975 in k3983 in loop in k3946 in ##sys#unregister-macro in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3942 in ##sys#unregister-macro in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 147  ##sys#macro-environment */
t2=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* macro? in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3880r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3880r(t0,t1,t2,t3);}}

static void C_ccall f_3880r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3884,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 138  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3884(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3882 in macro? in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3884,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[3],lf[34]);
t3=(C_word)C_i_check_list_2(t1,lf[34]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 141  lookup */
f_3582(t4,((C_word*)t0)[3],t1);}

/* k3891 in k3882 in macro? in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3893,2,t0,t1);}
t2=(C_word)C_i_pairp(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 143  ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k3910 in k3891 in k3882 in macro? in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 143  lookup */
f_3582(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3900 in k3891 in k3882 in macro? in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE));}

/* ##sys#copy-macro in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3867,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3871,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3878,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 135  ##sys#macro-environment */
t6=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3876 in ##sys#copy-macro in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 135  lookup */
f_3582(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3869 in ##sys#copy-macro in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],C_retrieve(lf[32]),((C_word*)t0)[2],t1);}

/* ##sys#extend-macro-environment in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3834,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3838,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 124  ##sys#macro-environment */
t6=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3836 in ##sys#extend-macro-environment in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3841,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 125  lookup */
f_3582(t2,((C_word*)t0)[2],t1);}

/* k3839 in k3836 in ##sys#extend-macro-environment in k3828 in k3578 in k3574 in k3547 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3841,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_set_car(t1,((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(t1);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[4]));}
else{
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
/* expand.scm: 130  ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}}

/* ##sys#strip-syntax in k3578 in k3574 in k3547 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_3679r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3679r(t0,t1,t2,t3);}}

static void C_ccall f_3679r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3681,a[2]=t2,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3774,a[2]=t4,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3779,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-se102142 */
t7=t6;
f_3779(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-alias103138 */
t9=t5;
f_3774(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body100109 */
t11=t4;
f_3681(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-se102 in ##sys#strip-syntax in k3578 in k3574 in k3547 */
static void C_fcall f_3779(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3779,NULL,2,t0,t1);}
/* def-alias103138 */
t2=((C_word*)t0)[2];
f_3774(t2,t1,C_SCHEME_FALSE);}

/* def-alias103 in ##sys#strip-syntax in k3578 in k3574 in k3547 */
static void C_fcall f_3774(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3774,NULL,3,t0,t1,t2);}
/* body100109 */
t3=((C_word*)t0)[2];
f_3681(t3,t1,t2,C_SCHEME_FALSE);}

/* body100 in ##sys#strip-syntax in k3578 in k3574 in k3547 */
static void C_fcall f_3681(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3681,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3687,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3687(3,t7,t1,((C_word*)t0)[2]);}

/* walk in body100 in ##sys#strip-syntax in k3578 in k3574 in k3547 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3687,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* expand.scm: 100  lookup */
f_3582(t3,t2,((C_word*)t0)[3]);}
else{
/* expand.scm: 101  get */
t4=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[12]);}}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3744,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* expand.scm: 108  walk */
t9=t3;
t10=t4;
t1=t9;
t2=t10;
c=3;
goto loop;}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3769,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3773,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 111  vector->list */
t5=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}}

/* k3771 in walk in body100 in ##sys#strip-syntax in k3578 in k3574 in k3547 */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3767 in walk in body100 in ##sys#strip-syntax in k3578 in k3574 in k3547 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 111  list->vector */
t2=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3742 in walk in body100 in ##sys#strip-syntax in k3578 in k3574 in k3547 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3748,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 109  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3687(3,t4,t2,t3);}

/* k3746 in k3742 in walk in body100 in ##sys#strip-syntax in k3578 in k3574 in k3547 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3748,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3695 in walk in body100 in ##sys#strip-syntax in k3578 in k3574 in k3547 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3703,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[2]);
t4=t2;
f_3703(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3703(t3,C_SCHEME_FALSE);}}

/* k3701 in k3695 in walk in body100 in ##sys#strip-syntax in k3578 in k3574 in k3547 */
static void C_fcall f_3703(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* expand.scm: 103  ##sys#alias-global-hook */
t2=C_retrieve(lf[23]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[2];
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[2]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?((C_word*)t0)[3]:((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}}

/* map-se in k3578 in k3574 in k3547 */
static void C_fcall f_3649(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3649,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3655,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a3654 in map-se in k3578 in k3574 in k3547 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3655,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_symbolp(t4);
t6=(C_truep(t5)?(C_word)C_i_cdr(t2):lf[14]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t3,t6));}

/* macro-alias in k3578 in k3574 in k3547 */
static void C_fcall f_3600(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3600,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3607,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 75   ##sys#qualified-symbol? */
t5=C_retrieve(lf[19]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3605 in macro-alias in k3578 in k3574 in k3547 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3610(t3,t1);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(C_word)C_fixnum_greaterp(t4,C_fix(0));
t6=t2;
f_3610(t6,(C_truep(t5)?(C_word)C_eqp(C_make_character(35),(C_word)C_subchar(t3,C_fix(0))):C_SCHEME_FALSE));}}

/* k3608 in k3605 in macro-alias in k3578 in k3574 in k3547 */
static void C_fcall f_3610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3610,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 81   gensym */
t3=C_retrieve(lf[18]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3611 in k3608 in k3605 in macro-alias in k3578 in k3574 in k3547 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3616,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 82   lookup */
f_3582(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k3614 in k3611 in k3608 in k3605 in macro-alias in k3578 in k3574 in k3547 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3616,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3622,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 83   ##sys#put! */
t4=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[12],t2);}

/* k3620 in k3614 in k3611 in k3608 in k3605 in macro-alias in k3578 in k3574 in k3547 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_pairp(((C_word*)t0)[2]);
t4=(C_truep(t3)?lf[14]:((C_word*)t0)[2]);
/* expand.scm: 84   dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[15],((C_word*)t0)[3],lf[16],t4);}

/* k3623 in k3620 in k3614 in k3611 in k3608 in k3605 in macro-alias in k3578 in k3574 in k3547 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup in k3578 in k3574 in k3547 */
static void C_fcall f_3582(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3582,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cdr(t4));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3595,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 71   ##sys#get */
t6=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[12]);}}

/* k3593 in lookup in k3578 in k3574 in k3547 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:C_SCHEME_FALSE));}

/* d in k3547 */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3551r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3551r(t0,t1,t2,t3);}}

static void C_ccall f_3551r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_fudge(C_fix(13)))){
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 43   pp */
t4=C_retrieve(lf[4]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}
else{
C_apply(5,0,t1,*((C_word*)lf[5]+1),t2,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[871] = {
{"toplevelexpand.scm",(void*)C_expand_toplevel},
{"f_3549expand.scm",(void*)f_3549},
{"f_3576expand.scm",(void*)f_3576},
{"f_3580expand.scm",(void*)f_3580},
{"f_3830expand.scm",(void*)f_3830},
{"f_13794expand.scm",(void*)f_13794},
{"f_13792expand.scm",(void*)f_13792},
{"f_7826expand.scm",(void*)f_7826},
{"f_13784expand.scm",(void*)f_13784},
{"f_13782expand.scm",(void*)f_13782},
{"f_7829expand.scm",(void*)f_7829},
{"f_7833expand.scm",(void*)f_7833},
{"f_13642expand.scm",(void*)f_13642},
{"f_13652expand.scm",(void*)f_13652},
{"f_13668expand.scm",(void*)f_13668},
{"f_13671expand.scm",(void*)f_13671},
{"f_13699expand.scm",(void*)f_13699},
{"f_13674expand.scm",(void*)f_13674},
{"f_13721expand.scm",(void*)f_13721},
{"f_13724expand.scm",(void*)f_13724},
{"f_13770expand.scm",(void*)f_13770},
{"f_13727expand.scm",(void*)f_13727},
{"f_13750expand.scm",(void*)f_13750},
{"f_13762expand.scm",(void*)f_13762},
{"f_13708expand.scm",(void*)f_13708},
{"f_13711expand.scm",(void*)f_13711},
{"f_13718expand.scm",(void*)f_13718},
{"f_13640expand.scm",(void*)f_13640},
{"f_7836expand.scm",(void*)f_7836},
{"f_13583expand.scm",(void*)f_13583},
{"f_13612expand.scm",(void*)f_13612},
{"f_13632expand.scm",(void*)f_13632},
{"f_13636expand.scm",(void*)f_13636},
{"f_13581expand.scm",(void*)f_13581},
{"f_7839expand.scm",(void*)f_7839},
{"f_13493expand.scm",(void*)f_13493},
{"f_13518expand.scm",(void*)f_13518},
{"f_13525expand.scm",(void*)f_13525},
{"f_13545expand.scm",(void*)f_13545},
{"f_13565expand.scm",(void*)f_13565},
{"f_13569expand.scm",(void*)f_13569},
{"f_13491expand.scm",(void*)f_13491},
{"f_7842expand.scm",(void*)f_7842},
{"f_13160expand.scm",(void*)f_13160},
{"f_13167expand.scm",(void*)f_13167},
{"f_13170expand.scm",(void*)f_13170},
{"f_13173expand.scm",(void*)f_13173},
{"f_13176expand.scm",(void*)f_13176},
{"f_13179expand.scm",(void*)f_13179},
{"f_13182expand.scm",(void*)f_13182},
{"f_13185expand.scm",(void*)f_13185},
{"f_13190expand.scm",(void*)f_13190},
{"f_13206expand.scm",(void*)f_13206},
{"f_13212expand.scm",(void*)f_13212},
{"f_13254expand.scm",(void*)f_13254},
{"f_13322expand.scm",(void*)f_13322},
{"f_13447expand.scm",(void*)f_13447},
{"f_13443expand.scm",(void*)f_13443},
{"f_13325expand.scm",(void*)f_13325},
{"f_13380expand.scm",(void*)f_13380},
{"f_13257expand.scm",(void*)f_13257},
{"f_13296expand.scm",(void*)f_13296},
{"f_13248expand.scm",(void*)f_13248},
{"f_13219expand.scm",(void*)f_13219},
{"f_13158expand.scm",(void*)f_13158},
{"f_7845expand.scm",(void*)f_7845},
{"f_12990expand.scm",(void*)f_12990},
{"f_12994expand.scm",(void*)f_12994},
{"f_13003expand.scm",(void*)f_13003},
{"f_13006expand.scm",(void*)f_13006},
{"f_13009expand.scm",(void*)f_13009},
{"f_13012expand.scm",(void*)f_13012},
{"f_13015expand.scm",(void*)f_13015},
{"f_13036expand.scm",(void*)f_13036},
{"f_13052expand.scm",(void*)f_13052},
{"f_13058expand.scm",(void*)f_13058},
{"f_13114expand.scm",(void*)f_13114},
{"f_13112expand.scm",(void*)f_13112},
{"f_13108expand.scm",(void*)f_13108},
{"f_13100expand.scm",(void*)f_13100},
{"f_13096expand.scm",(void*)f_13096},
{"f_13065expand.scm",(void*)f_13065},
{"f_13034expand.scm",(void*)f_13034},
{"f_12988expand.scm",(void*)f_12988},
{"f_7848expand.scm",(void*)f_7848},
{"f_12921expand.scm",(void*)f_12921},
{"f_12925expand.scm",(void*)f_12925},
{"f_12934expand.scm",(void*)f_12934},
{"f_12939expand.scm",(void*)f_12939},
{"f_12976expand.scm",(void*)f_12976},
{"f_12957expand.scm",(void*)f_12957},
{"f_12919expand.scm",(void*)f_12919},
{"f_7851expand.scm",(void*)f_7851},
{"f_12739expand.scm",(void*)f_12739},
{"f_12743expand.scm",(void*)f_12743},
{"f_12755expand.scm",(void*)f_12755},
{"f_12758expand.scm",(void*)f_12758},
{"f_12761expand.scm",(void*)f_12761},
{"f_12764expand.scm",(void*)f_12764},
{"f_12899expand.scm",(void*)f_12899},
{"f_12779expand.scm",(void*)f_12779},
{"f_12897expand.scm",(void*)f_12897},
{"f_12806expand.scm",(void*)f_12806},
{"f_12887expand.scm",(void*)f_12887},
{"f_12822expand.scm",(void*)f_12822},
{"f_12844expand.scm",(void*)f_12844},
{"f_12842expand.scm",(void*)f_12842},
{"f_12838expand.scm",(void*)f_12838},
{"f_12737expand.scm",(void*)f_12737},
{"f_7854expand.scm",(void*)f_7854},
{"f_12344expand.scm",(void*)f_12344},
{"f_12348expand.scm",(void*)f_12348},
{"f_12351expand.scm",(void*)f_12351},
{"f_12354expand.scm",(void*)f_12354},
{"f_12357expand.scm",(void*)f_12357},
{"f_12726expand.scm",(void*)f_12726},
{"f_12638expand.scm",(void*)f_12638},
{"f_12642expand.scm",(void*)f_12642},
{"f_12667expand.scm",(void*)f_12667},
{"f_12713expand.scm",(void*)f_12713},
{"f_12698expand.scm",(void*)f_12698},
{"f_12369expand.scm",(void*)f_12369},
{"f_12416expand.scm",(void*)f_12416},
{"f_12463expand.scm",(void*)f_12463},
{"f_12624expand.scm",(void*)f_12624},
{"f_12632expand.scm",(void*)f_12632},
{"f_12610expand.scm",(void*)f_12610},
{"f_12599expand.scm",(void*)f_12599},
{"f_12607expand.scm",(void*)f_12607},
{"f_12584expand.scm",(void*)f_12584},
{"f_12572expand.scm",(void*)f_12572},
{"f_12553expand.scm",(void*)f_12553},
{"f_12511expand.scm",(void*)f_12511},
{"f_12488expand.scm",(void*)f_12488},
{"f_12442expand.scm",(void*)f_12442},
{"f_12391expand.scm",(void*)f_12391},
{"f_12387expand.scm",(void*)f_12387},
{"f_12359expand.scm",(void*)f_12359},
{"f_12367expand.scm",(void*)f_12367},
{"f_12342expand.scm",(void*)f_12342},
{"f_7857expand.scm",(void*)f_7857},
{"f_12311expand.scm",(void*)f_12311},
{"f_12315expand.scm",(void*)f_12315},
{"f_12309expand.scm",(void*)f_12309},
{"f_7860expand.scm",(void*)f_7860},
{"f_12027expand.scm",(void*)f_12027},
{"f_12034expand.scm",(void*)f_12034},
{"f_12037expand.scm",(void*)f_12037},
{"f_12040expand.scm",(void*)f_12040},
{"f_12043expand.scm",(void*)f_12043},
{"f_12046expand.scm",(void*)f_12046},
{"f_12208expand.scm",(void*)f_12208},
{"f_12261expand.scm",(void*)f_12261},
{"f_12283expand.scm",(void*)f_12283},
{"f_12290expand.scm",(void*)f_12290},
{"f_12277expand.scm",(void*)f_12277},
{"f_12224expand.scm",(void*)f_12224},
{"f_12222expand.scm",(void*)f_12222},
{"f_12058expand.scm",(void*)f_12058},
{"f_12089expand.scm",(void*)f_12089},
{"f_12135expand.scm",(void*)f_12135},
{"f_12185expand.scm",(void*)f_12185},
{"f_12192expand.scm",(void*)f_12192},
{"f_12150expand.scm",(void*)f_12150},
{"f_12164expand.scm",(void*)f_12164},
{"f_12107expand.scm",(void*)f_12107},
{"f_12118expand.scm",(void*)f_12118},
{"f_12048expand.scm",(void*)f_12048},
{"f_12025expand.scm",(void*)f_12025},
{"f_7863expand.scm",(void*)f_7863},
{"f_12006expand.scm",(void*)f_12006},
{"f_12004expand.scm",(void*)f_12004},
{"f_7866expand.scm",(void*)f_7866},
{"f_11985expand.scm",(void*)f_11985},
{"f_11983expand.scm",(void*)f_11983},
{"f_7869expand.scm",(void*)f_7869},
{"f_11934expand.scm",(void*)f_11934},
{"f_11938expand.scm",(void*)f_11938},
{"f_11975expand.scm",(void*)f_11975},
{"f_11968expand.scm",(void*)f_11968},
{"f_11961expand.scm",(void*)f_11961},
{"f_11932expand.scm",(void*)f_11932},
{"f_7872expand.scm",(void*)f_7872},
{"f_11880expand.scm",(void*)f_11880},
{"f_11884expand.scm",(void*)f_11884},
{"f_11887expand.scm",(void*)f_11887},
{"f_11924expand.scm",(void*)f_11924},
{"f_11890expand.scm",(void*)f_11890},
{"f_11905expand.scm",(void*)f_11905},
{"f_11909expand.scm",(void*)f_11909},
{"f_11878expand.scm",(void*)f_11878},
{"f_7875expand.scm",(void*)f_7875},
{"f_11777expand.scm",(void*)f_11777},
{"f_11784expand.scm",(void*)f_11784},
{"f_11787expand.scm",(void*)f_11787},
{"f_11807expand.scm",(void*)f_11807},
{"f_11829expand.scm",(void*)f_11829},
{"f_11814expand.scm",(void*)f_11814},
{"f_11790expand.scm",(void*)f_11790},
{"f_11805expand.scm",(void*)f_11805},
{"f_11797expand.scm",(void*)f_11797},
{"f_11793expand.scm",(void*)f_11793},
{"f_11775expand.scm",(void*)f_11775},
{"f_7878expand.scm",(void*)f_7878},
{"f_11740expand.scm",(void*)f_11740},
{"f_11744expand.scm",(void*)f_11744},
{"f_11762expand.scm",(void*)f_11762},
{"f_11753expand.scm",(void*)f_11753},
{"f_11738expand.scm",(void*)f_11738},
{"f_7881expand.scm",(void*)f_7881},
{"f_9526expand.scm",(void*)f_9526},
{"f_11734expand.scm",(void*)f_11734},
{"f_9530expand.scm",(void*)f_9530},
{"f_9534expand.scm",(void*)f_9534},
{"f_11692expand.scm",(void*)f_11692},
{"f_11700expand.scm",(void*)f_11700},
{"f_11702expand.scm",(void*)f_11702},
{"f_11723expand.scm",(void*)f_11723},
{"f_11258expand.scm",(void*)f_11258},
{"f_11673expand.scm",(void*)f_11673},
{"f_11685expand.scm",(void*)f_11685},
{"f_11274expand.scm",(void*)f_11274},
{"f_11630expand.scm",(void*)f_11630},
{"f_11632expand.scm",(void*)f_11632},
{"f_11671expand.scm",(void*)f_11671},
{"f_11645expand.scm",(void*)f_11645},
{"f_11656expand.scm",(void*)f_11656},
{"f_11277expand.scm",(void*)f_11277},
{"f_11500expand.scm",(void*)f_11500},
{"f_11551expand.scm",(void*)f_11551},
{"f_11604expand.scm",(void*)f_11604},
{"f_11563expand.scm",(void*)f_11563},
{"f_11590expand.scm",(void*)f_11590},
{"f_11586expand.scm",(void*)f_11586},
{"f_11566expand.scm",(void*)f_11566},
{"f_11548expand.scm",(void*)f_11548},
{"f_11537expand.scm",(void*)f_11537},
{"f_11280expand.scm",(void*)f_11280},
{"f_11494expand.scm",(void*)f_11494},
{"f_11480expand.scm",(void*)f_11480},
{"f_11283expand.scm",(void*)f_11283},
{"f_11478expand.scm",(void*)f_11478},
{"f_11442expand.scm",(void*)f_11442},
{"f_11470expand.scm",(void*)f_11470},
{"f_11286expand.scm",(void*)f_11286},
{"f_11436expand.scm",(void*)f_11436},
{"f_11440expand.scm",(void*)f_11440},
{"f_11289expand.scm",(void*)f_11289},
{"f_11292expand.scm",(void*)f_11292},
{"f_11394expand.scm",(void*)f_11394},
{"f_11398expand.scm",(void*)f_11398},
{"f_11428expand.scm",(void*)f_11428},
{"f_11424expand.scm",(void*)f_11424},
{"f_11401expand.scm",(void*)f_11401},
{"f_11295expand.scm",(void*)f_11295},
{"f_11392expand.scm",(void*)f_11392},
{"f_11388expand.scm",(void*)f_11388},
{"f_11384expand.scm",(void*)f_11384},
{"f_11380expand.scm",(void*)f_11380},
{"f_11376expand.scm",(void*)f_11376},
{"f_11372expand.scm",(void*)f_11372},
{"f_11368expand.scm",(void*)f_11368},
{"f_11364expand.scm",(void*)f_11364},
{"f_11360expand.scm",(void*)f_11360},
{"f_11298expand.scm",(void*)f_11298},
{"f_11301expand.scm",(void*)f_11301},
{"f_11173expand.scm",(void*)f_11173},
{"f_11184expand.scm",(void*)f_11184},
{"f_11186expand.scm",(void*)f_11186},
{"f_11235expand.scm",(void*)f_11235},
{"f_11231expand.scm",(void*)f_11231},
{"f_11214expand.scm",(void*)f_11214},
{"f_11082expand.scm",(void*)f_11082},
{"f_11086expand.scm",(void*)f_11086},
{"f_11089expand.scm",(void*)f_11089},
{"f_11128expand.scm",(void*)f_11128},
{"f_11148expand.scm",(void*)f_11148},
{"f_11138expand.scm",(void*)f_11138},
{"f_11141expand.scm",(void*)f_11141},
{"f_11104expand.scm",(void*)f_11104},
{"f_11110expand.scm",(void*)f_11110},
{"f_11108expand.scm",(void*)f_11108},
{"f_10874expand.scm",(void*)f_10874},
{"f_10878expand.scm",(void*)f_10878},
{"f_11036expand.scm",(void*)f_11036},
{"f_11057expand.scm",(void*)f_11057},
{"f_10901expand.scm",(void*)f_10901},
{"f_10904expand.scm",(void*)f_10904},
{"f_11004expand.scm",(void*)f_11004},
{"f_11026expand.scm",(void*)f_11026},
{"f_10907expand.scm",(void*)f_10907},
{"f_10986expand.scm",(void*)f_10986},
{"f_10998expand.scm",(void*)f_10998},
{"f_10910expand.scm",(void*)f_10910},
{"f_10980expand.scm",(void*)f_10980},
{"f_10984expand.scm",(void*)f_10984},
{"f_10916expand.scm",(void*)f_10916},
{"f_10919expand.scm",(void*)f_10919},
{"f_10968expand.scm",(void*)f_10968},
{"f_10922expand.scm",(void*)f_10922},
{"f_10948expand.scm",(void*)f_10948},
{"f_10925expand.scm",(void*)f_10925},
{"f_10938expand.scm",(void*)f_10938},
{"f_10928expand.scm",(void*)f_10928},
{"f_10494expand.scm",(void*)f_10494},
{"f_10872expand.scm",(void*)f_10872},
{"f_10517expand.scm",(void*)f_10517},
{"f_10842expand.scm",(void*)f_10842},
{"f_10525expand.scm",(void*)f_10525},
{"f_10824expand.scm",(void*)f_10824},
{"f_10533expand.scm",(void*)f_10533},
{"f_10812expand.scm",(void*)f_10812},
{"f_10739expand.scm",(void*)f_10739},
{"f_10737expand.scm",(void*)f_10737},
{"f_10733expand.scm",(void*)f_10733},
{"f_10671expand.scm",(void*)f_10671},
{"f_10714expand.scm",(void*)f_10714},
{"f_10669expand.scm",(void*)f_10669},
{"f_10665expand.scm",(void*)f_10665},
{"f_10595expand.scm",(void*)f_10595},
{"f_10661expand.scm",(void*)f_10661},
{"f_10618expand.scm",(void*)f_10618},
{"f_10657expand.scm",(void*)f_10657},
{"f_10649expand.scm",(void*)f_10649},
{"f_10629expand.scm",(void*)f_10629},
{"f_10589expand.scm",(void*)f_10589},
{"f_10585expand.scm",(void*)f_10585},
{"f_10529expand.scm",(void*)f_10529},
{"f_10521expand.scm",(void*)f_10521},
{"f_10422expand.scm",(void*)f_10422},
{"f_10426expand.scm",(void*)f_10426},
{"f_10429expand.scm",(void*)f_10429},
{"f_10441expand.scm",(void*)f_10441},
{"f_10480expand.scm",(void*)f_10480},
{"f_10472expand.scm",(void*)f_10472},
{"f_10432expand.scm",(void*)f_10432},
{"f_10435expand.scm",(void*)f_10435},
{"f_10146expand.scm",(void*)f_10146},
{"f_10227expand.scm",(void*)f_10227},
{"f_10254expand.scm",(void*)f_10254},
{"f_10256expand.scm",(void*)f_10256},
{"f_10416expand.scm",(void*)f_10416},
{"f_10404expand.scm",(void*)f_10404},
{"f_10385expand.scm",(void*)f_10385},
{"f_10367expand.scm",(void*)f_10367},
{"f_10352expand.scm",(void*)f_10352},
{"f_10322expand.scm",(void*)f_10322},
{"f_10307expand.scm",(void*)f_10307},
{"f_10279expand.scm",(void*)f_10279},
{"f_10204expand.scm",(void*)f_10204},
{"f_10216expand.scm",(void*)f_10216},
{"f_10212expand.scm",(void*)f_10212},
{"f_10087expand.scm",(void*)f_10087},
{"f_10093expand.scm",(void*)f_10093},
{"f_10100expand.scm",(void*)f_10100},
{"f_10103expand.scm",(void*)f_10103},
{"f_10019expand.scm",(void*)f_10019},
{"f_10039expand.scm",(void*)f_10039},
{"f_10034expand.scm",(void*)f_10034},
{"f_10021expand.scm",(void*)f_10021},
{"f_9997expand.scm",(void*)f_9997},
{"f_10004expand.scm",(void*)f_10004},
{"f_9916expand.scm",(void*)f_9916},
{"f_9926expand.scm",(void*)f_9926},
{"f_9929expand.scm",(void*)f_9929},
{"f_9935expand.scm",(void*)f_9935},
{"f_9978expand.scm",(void*)f_9978},
{"f_9982expand.scm",(void*)f_9982},
{"f_9938expand.scm",(void*)f_9938},
{"f_9941expand.scm",(void*)f_9941},
{"f_9944expand.scm",(void*)f_9944},
{"f_9827expand.scm",(void*)f_9827},
{"f_9837expand.scm",(void*)f_9837},
{"f_9840expand.scm",(void*)f_9840},
{"f_9903expand.scm",(void*)f_9903},
{"f_9843expand.scm",(void*)f_9843},
{"f_9899expand.scm",(void*)f_9899},
{"f_9846expand.scm",(void*)f_9846},
{"f_9885expand.scm",(void*)f_9885},
{"f_9889expand.scm",(void*)f_9889},
{"f_9849expand.scm",(void*)f_9849},
{"f_9852expand.scm",(void*)f_9852},
{"f_9858expand.scm",(void*)f_9858},
{"f_9806expand.scm",(void*)f_9806},
{"f_9813expand.scm",(void*)f_9813},
{"f_9786expand.scm",(void*)f_9786},
{"f_9790expand.scm",(void*)f_9790},
{"f_9783expand.scm",(void*)f_9783},
{"f_9743expand.scm",(void*)f_9743},
{"f_9747expand.scm",(void*)f_9747},
{"f_9737expand.scm",(void*)f_9737},
{"f_9728expand.scm",(void*)f_9728},
{"f_9710expand.scm",(void*)f_9710},
{"f_9692expand.scm",(void*)f_9692},
{"f_9674expand.scm",(void*)f_9674},
{"f_9656expand.scm",(void*)f_9656},
{"f_9638expand.scm",(void*)f_9638},
{"f_9629expand.scm",(void*)f_9629},
{"f_9620expand.scm",(void*)f_9620},
{"f_9602expand.scm",(void*)f_9602},
{"f_9584expand.scm",(void*)f_9584},
{"f_9575expand.scm",(void*)f_9575},
{"f_9566expand.scm",(void*)f_9566},
{"f_9548expand.scm",(void*)f_9548},
{"f_7883expand.scm",(void*)f_7883},
{"f_7890expand.scm",(void*)f_7890},
{"f_7904expand.scm",(void*)f_7904},
{"f_7908expand.scm",(void*)f_7908},
{"f_7912expand.scm",(void*)f_7912},
{"f_7917expand.scm",(void*)f_7917},
{"f_7923expand.scm",(void*)f_7923},
{"f_7927expand.scm",(void*)f_7927},
{"f_7931expand.scm",(void*)f_7931},
{"f_7935expand.scm",(void*)f_7935},
{"f_7939expand.scm",(void*)f_7939},
{"f_7944expand.scm",(void*)f_7944},
{"f_7948expand.scm",(void*)f_7948},
{"f_7955expand.scm",(void*)f_7955},
{"f_7960expand.scm",(void*)f_7960},
{"f_7964expand.scm",(void*)f_7964},
{"f_7968expand.scm",(void*)f_7968},
{"f_7972expand.scm",(void*)f_7972},
{"f_7977expand.scm",(void*)f_7977},
{"f_9485expand.scm",(void*)f_9485},
{"f_9495expand.scm",(void*)f_9495},
{"f_9502expand.scm",(void*)f_9502},
{"f_9465expand.scm",(void*)f_9465},
{"f_9472expand.scm",(void*)f_9472},
{"f_9479expand.scm",(void*)f_9479},
{"f_9439expand.scm",(void*)f_9439},
{"f_9417expand.scm",(void*)f_9417},
{"f_9424expand.scm",(void*)f_9424},
{"f_9324expand.scm",(void*)f_9324},
{"f_9366expand.scm",(void*)f_9366},
{"f_9415expand.scm",(void*)f_9415},
{"f_9398expand.scm",(void*)f_9398},
{"f_9377expand.scm",(void*)f_9377},
{"f_9337expand.scm",(void*)f_9337},
{"f_9251expand.scm",(void*)f_9251},
{"f_9277expand.scm",(void*)f_9277},
{"f_9322expand.scm",(void*)f_9322},
{"f_9305expand.scm",(void*)f_9305},
{"f_8997expand.scm",(void*)f_8997},
{"f_9044expand.scm",(void*)f_9044},
{"f_9242expand.scm",(void*)f_9242},
{"f_9238expand.scm",(void*)f_9238},
{"f_9205expand.scm",(void*)f_9205},
{"f_9213expand.scm",(void*)f_9213},
{"f_9047expand.scm",(void*)f_9047},
{"f_9053expand.scm",(void*)f_9053},
{"f_9065expand.scm",(void*)f_9065},
{"f_9131expand.scm",(void*)f_9131},
{"f_9146expand.scm",(void*)f_9146},
{"f_9068expand.scm",(void*)f_9068},
{"f_9102expand.scm",(void*)f_9102},
{"f_9071expand.scm",(void*)f_9071},
{"f_9100expand.scm",(void*)f_9100},
{"f_9096expand.scm",(void*)f_9096},
{"f_9092expand.scm",(void*)f_9092},
{"f_8790expand.scm",(void*)f_8790},
{"f_8820expand.scm",(void*)f_8820},
{"f_8920expand.scm",(void*)f_8920},
{"f_8943expand.scm",(void*)f_8943},
{"f_8957expand.scm",(void*)f_8957},
{"f_8961expand.scm",(void*)f_8961},
{"f_8930expand.scm",(void*)f_8930},
{"f_8880expand.scm",(void*)f_8880},
{"f_8884expand.scm",(void*)f_8884},
{"f_8829expand.scm",(void*)f_8829},
{"f_8837expand.scm",(void*)f_8837},
{"f_8814expand.scm",(void*)f_8814},
{"f_8502expand.scm",(void*)f_8502},
{"f_8509expand.scm",(void*)f_8509},
{"f_8548expand.scm",(void*)f_8548},
{"f_8558expand.scm",(void*)f_8558},
{"f_8689expand.scm",(void*)f_8689},
{"f_8693expand.scm",(void*)f_8693},
{"f_8622expand.scm",(void*)f_8622},
{"f_8618expand.scm",(void*)f_8618},
{"f_8556expand.scm",(void*)f_8556},
{"f_8552expand.scm",(void*)f_8552},
{"f_8384expand.scm",(void*)f_8384},
{"f_8388expand.scm",(void*)f_8388},
{"f_8163expand.scm",(void*)f_8163},
{"f_8213expand.scm",(void*)f_8213},
{"f_8327expand.scm",(void*)f_8327},
{"f_8265expand.scm",(void*)f_8265},
{"f_8273expand.scm",(void*)f_8273},
{"f_8269expand.scm",(void*)f_8269},
{"f_8261expand.scm",(void*)f_8261},
{"f_8079expand.scm",(void*)f_8079},
{"f_8086expand.scm",(void*)f_8086},
{"f_8089expand.scm",(void*)f_8089},
{"f_8138expand.scm",(void*)f_8138},
{"f_8134expand.scm",(void*)f_8134},
{"f_8129expand.scm",(void*)f_8129},
{"f_8115expand.scm",(void*)f_8115},
{"f_8127expand.scm",(void*)f_8127},
{"f_8123expand.scm",(void*)f_8123},
{"f_7985expand.scm",(void*)f_7985},
{"f_8029expand.scm",(void*)f_8029},
{"f_8025expand.scm",(void*)f_8025},
{"f_7979expand.scm",(void*)f_7979},
{"f_6981expand.scm",(void*)f_6981},
{"f_6985expand.scm",(void*)f_6985},
{"f_6988expand.scm",(void*)f_6988},
{"f_6991expand.scm",(void*)f_6991},
{"f_6994expand.scm",(void*)f_6994},
{"f_7593expand.scm",(void*)f_7593},
{"f_7596expand.scm",(void*)f_7596},
{"f_7815expand.scm",(void*)f_7815},
{"f_7800expand.scm",(void*)f_7800},
{"f_7599expand.scm",(void*)f_7599},
{"f_7604expand.scm",(void*)f_7604},
{"f_7608expand.scm",(void*)f_7608},
{"f_7617expand.scm",(void*)f_7617},
{"f_7775expand.scm",(void*)f_7775},
{"f_7620expand.scm",(void*)f_7620},
{"f_7752expand.scm",(void*)f_7752},
{"f_7623expand.scm",(void*)f_7623},
{"f_7626expand.scm",(void*)f_7626},
{"f_7698expand.scm",(void*)f_7698},
{"f_7732expand.scm",(void*)f_7732},
{"f_7629expand.scm",(void*)f_7629},
{"f_7656expand.scm",(void*)f_7656},
{"f_7696expand.scm",(void*)f_7696},
{"f_7632expand.scm",(void*)f_7632},
{"f_7654expand.scm",(void*)f_7654},
{"f_7650expand.scm",(void*)f_7650},
{"f_7635expand.scm",(void*)f_7635},
{"f_7646expand.scm",(void*)f_7646},
{"f_7642expand.scm",(void*)f_7642},
{"f_7602expand.scm",(void*)f_7602},
{"f_7135expand.scm",(void*)f_7135},
{"f_7154expand.scm",(void*)f_7154},
{"f_7163expand.scm",(void*)f_7163},
{"f_7175expand.scm",(void*)f_7175},
{"f_7255expand.scm",(void*)f_7255},
{"f_7362expand.scm",(void*)f_7362},
{"f_7509expand.scm",(void*)f_7509},
{"f_7512expand.scm",(void*)f_7512},
{"f_7515expand.scm",(void*)f_7515},
{"f_7548expand.scm",(void*)f_7548},
{"f_7552expand.scm",(void*)f_7552},
{"f_7517expand.scm",(void*)f_7517},
{"f_7537expand.scm",(void*)f_7537},
{"f_7533expand.scm",(void*)f_7533},
{"f_7525expand.scm",(void*)f_7525},
{"f_7365expand.scm",(void*)f_7365},
{"f_7374expand.scm",(void*)f_7374},
{"f_7503expand.scm",(void*)f_7503},
{"f_7484expand.scm",(void*)f_7484},
{"f_7472expand.scm",(void*)f_7472},
{"f_7451expand.scm",(void*)f_7451},
{"f_7432expand.scm",(void*)f_7432},
{"f_7420expand.scm",(void*)f_7420},
{"f_7395expand.scm",(void*)f_7395},
{"f_7390expand.scm",(void*)f_7390},
{"f_7258expand.scm",(void*)f_7258},
{"f_7261expand.scm",(void*)f_7261},
{"f_7266expand.scm",(void*)f_7266},
{"f_7352expand.scm",(void*)f_7352},
{"f_7278expand.scm",(void*)f_7278},
{"f_7320expand.scm",(void*)f_7320},
{"f_7178expand.scm",(void*)f_7178},
{"f_7181expand.scm",(void*)f_7181},
{"f_7186expand.scm",(void*)f_7186},
{"f_7048expand.scm",(void*)f_7048},
{"f_7052expand.scm",(void*)f_7052},
{"f_7055expand.scm",(void*)f_7055},
{"f_7133expand.scm",(void*)f_7133},
{"f_7129expand.scm",(void*)f_7129},
{"f_7070expand.scm",(void*)f_7070},
{"f_7076expand.scm",(void*)f_7076},
{"f_7079expand.scm",(void*)f_7079},
{"f_7118expand.scm",(void*)f_7118},
{"f_7112expand.scm",(void*)f_7112},
{"f_7116expand.scm",(void*)f_7116},
{"f_7080expand.scm",(void*)f_7080},
{"f_7084expand.scm",(void*)f_7084},
{"f_7087expand.scm",(void*)f_7087},
{"f_7091expand.scm",(void*)f_7091},
{"f_7094expand.scm",(void*)f_7094},
{"f_7098expand.scm",(void*)f_7098},
{"f_7101expand.scm",(void*)f_7101},
{"f_7105expand.scm",(void*)f_7105},
{"f_7108expand.scm",(void*)f_7108},
{"f_7058expand.scm",(void*)f_7058},
{"f_7005expand.scm",(void*)f_7005},
{"f_7018expand.scm",(void*)f_7018},
{"f_7025expand.scm",(void*)f_7025},
{"f_6996expand.scm",(void*)f_6996},
{"f_7000expand.scm",(void*)f_7000},
{"f_6687expand.scm",(void*)f_6687},
{"f_6689expand.scm",(void*)f_6689},
{"f_6818expand.scm",(void*)f_6818},
{"f_6851expand.scm",(void*)f_6851},
{"f_6941expand.scm",(void*)f_6941},
{"f_6854expand.scm",(void*)f_6854},
{"f_6857expand.scm",(void*)f_6857},
{"f_6935expand.scm",(void*)f_6935},
{"f_6860expand.scm",(void*)f_6860},
{"f_6929expand.scm",(void*)f_6929},
{"f_6906expand.scm",(void*)f_6906},
{"f_6879expand.scm",(void*)f_6879},
{"f_6886expand.scm",(void*)f_6886},
{"f_6822expand.scm",(void*)f_6822},
{"f_6825expand.scm",(void*)f_6825},
{"f_6955expand.scm",(void*)f_6955},
{"f_6959expand.scm",(void*)f_6959},
{"f_6962expand.scm",(void*)f_6962},
{"f_6692expand.scm",(void*)f_6692},
{"f_6728expand.scm",(void*)f_6728},
{"f_6789expand.scm",(void*)f_6789},
{"f_6792expand.scm",(void*)f_6792},
{"f_6759expand.scm",(void*)f_6759},
{"f_6762expand.scm",(void*)f_6762},
{"f_6740expand.scm",(void*)f_6740},
{"f_6702expand.scm",(void*)f_6702},
{"f_6225expand.scm",(void*)f_6225},
{"f_6639expand.scm",(void*)f_6639},
{"f_6630expand.scm",(void*)f_6630},
{"f_6638expand.scm",(void*)f_6638},
{"f_6227expand.scm",(void*)f_6227},
{"f_6358expand.scm",(void*)f_6358},
{"f_6363expand.scm",(void*)f_6363},
{"f_6601expand.scm",(void*)f_6601},
{"f_6560expand.scm",(void*)f_6560},
{"f_6564expand.scm",(void*)f_6564},
{"f_6382expand.scm",(void*)f_6382},
{"f_6387expand.scm",(void*)f_6387},
{"f_6406expand.scm",(void*)f_6406},
{"f_6329expand.scm",(void*)f_6329},
{"f_6335expand.scm",(void*)f_6335},
{"f_6273expand.scm",(void*)f_6273},
{"f_6277expand.scm",(void*)f_6277},
{"f_6285expand.scm",(void*)f_6285},
{"f_6305expand.scm",(void*)f_6305},
{"f_6230expand.scm",(void*)f_6230},
{"f_6237expand.scm",(void*)f_6237},
{"f_6242expand.scm",(void*)f_6242},
{"f_6246expand.scm",(void*)f_6246},
{"f_6271expand.scm",(void*)f_6271},
{"f_6260expand.scm",(void*)f_6260},
{"f_6264expand.scm",(void*)f_6264},
{"f_6253expand.scm",(void*)f_6253},
{"f_6189expand.scm",(void*)f_6189},
{"f_6211expand.scm",(void*)f_6211},
{"f_6178expand.scm",(void*)f_6178},
{"f_6186expand.scm",(void*)f_6186},
{"f_6108expand.scm",(void*)f_6108},
{"f_6171expand.scm",(void*)f_6171},
{"f_6111expand.scm",(void*)f_6111},
{"f_6164expand.scm",(void*)f_6164},
{"f_6137expand.scm",(void*)f_6137},
{"f_6025expand.scm",(void*)f_6025},
{"f_6106expand.scm",(void*)f_6106},
{"f_6028expand.scm",(void*)f_6028},
{"f_6077expand.scm",(void*)f_6077},
{"f_5272expand.scm",(void*)f_5272},
{"f_5276expand.scm",(void*)f_5276},
{"f_5715expand.scm",(void*)f_5715},
{"f_5721expand.scm",(void*)f_5721},
{"f_5985expand.scm",(void*)f_5985},
{"f_5743expand.scm",(void*)f_5743},
{"f_5953expand.scm",(void*)f_5953},
{"f_5927expand.scm",(void*)f_5927},
{"f_5934expand.scm",(void*)f_5934},
{"f_5899expand.scm",(void*)f_5899},
{"f_5887expand.scm",(void*)f_5887},
{"f_5761expand.scm",(void*)f_5761},
{"f_5766expand.scm",(void*)f_5766},
{"f_5779expand.scm",(void*)f_5779},
{"f_5835expand.scm",(void*)f_5835},
{"f_5862expand.scm",(void*)f_5862},
{"f_5813expand.scm",(void*)f_5813},
{"f_5824expand.scm",(void*)f_5824},
{"f_5828expand.scm",(void*)f_5828},
{"f_5538expand.scm",(void*)f_5538},
{"f_5548expand.scm",(void*)f_5548},
{"f_5697expand.scm",(void*)f_5697},
{"f_5693expand.scm",(void*)f_5693},
{"f_5683expand.scm",(void*)f_5683},
{"f_5686expand.scm",(void*)f_5686},
{"f_5594expand.scm",(void*)f_5594},
{"f_5626expand.scm",(void*)f_5626},
{"f_5638expand.scm",(void*)f_5638},
{"f_5646expand.scm",(void*)f_5646},
{"f_5650expand.scm",(void*)f_5650},
{"f_5612expand.scm",(void*)f_5612},
{"f_5563expand.scm",(void*)f_5563},
{"f_5579expand.scm",(void*)f_5579},
{"f_5571expand.scm",(void*)f_5571},
{"f_5575expand.scm",(void*)f_5575},
{"f_5546expand.scm",(void*)f_5546},
{"f_5278expand.scm",(void*)f_5278},
{"f_5389expand.scm",(void*)f_5389},
{"f_5530expand.scm",(void*)f_5530},
{"f_5518expand.scm",(void*)f_5518},
{"f_5411expand.scm",(void*)f_5411},
{"f_5516expand.scm",(void*)f_5516},
{"f_5500expand.scm",(void*)f_5500},
{"f_5419expand.scm",(void*)f_5419},
{"f_5494expand.scm",(void*)f_5494},
{"f_5498expand.scm",(void*)f_5498},
{"f_5433expand.scm",(void*)f_5433},
{"f_5437expand.scm",(void*)f_5437},
{"f_5470expand.scm",(void*)f_5470},
{"f_5468expand.scm",(void*)f_5468},
{"f_5464expand.scm",(void*)f_5464},
{"f_5427expand.scm",(void*)f_5427},
{"f_5431expand.scm",(void*)f_5431},
{"f_5423expand.scm",(void*)f_5423},
{"f_5415expand.scm",(void*)f_5415},
{"f_5395expand.scm",(void*)f_5395},
{"f_5290expand.scm",(void*)f_5290},
{"f_5304expand.scm",(void*)f_5304},
{"f_5379expand.scm",(void*)f_5379},
{"f_5372expand.scm",(void*)f_5372},
{"f_5313expand.scm",(void*)f_5313},
{"f_5320expand.scm",(void*)f_5320},
{"f_5328expand.scm",(void*)f_5328},
{"f_5336expand.scm",(void*)f_5336},
{"f_5324expand.scm",(void*)f_5324},
{"f_4682expand.scm",(void*)f_4682},
{"f_4702expand.scm",(void*)f_4702},
{"f_4705expand.scm",(void*)f_4705},
{"f_4708expand.scm",(void*)f_4708},
{"f_4711expand.scm",(void*)f_4711},
{"f_4714expand.scm",(void*)f_4714},
{"f_4719expand.scm",(void*)f_4719},
{"f_5030expand.scm",(void*)f_5030},
{"f_5209expand.scm",(void*)f_5209},
{"f_5147expand.scm",(void*)f_5147},
{"f_5128expand.scm",(void*)f_5128},
{"f_5082expand.scm",(void*)f_5082},
{"f_5085expand.scm",(void*)f_5085},
{"f_5064expand.scm",(void*)f_5064},
{"f_5045expand.scm",(void*)f_5045},
{"f_5007expand.scm",(void*)f_5007},
{"f_4986expand.scm",(void*)f_4986},
{"f_4733expand.scm",(void*)f_4733},
{"f_4979expand.scm",(void*)f_4979},
{"f_4906expand.scm",(void*)f_4906},
{"f_4975expand.scm",(void*)f_4975},
{"f_4959expand.scm",(void*)f_4959},
{"f_4941expand.scm",(void*)f_4941},
{"f_4937expand.scm",(void*)f_4937},
{"f_4900expand.scm",(void*)f_4900},
{"f_4904expand.scm",(void*)f_4904},
{"f_4737expand.scm",(void*)f_4737},
{"f_4749expand.scm",(void*)f_4749},
{"f_4852expand.scm",(void*)f_4852},
{"f_4844expand.scm",(void*)f_4844},
{"f_4848expand.scm",(void*)f_4848},
{"f_4821expand.scm",(void*)f_4821},
{"f_4825expand.scm",(void*)f_4825},
{"f_4776expand.scm",(void*)f_4776},
{"f_4796expand.scm",(void*)f_4796},
{"f_4768expand.scm",(void*)f_4768},
{"f_4740expand.scm",(void*)f_4740},
{"f_4685expand.scm",(void*)f_4685},
{"f_4639expand.scm",(void*)f_4639},
{"f_4645expand.scm",(void*)f_4645},
{"f_4664expand.scm",(void*)f_4664},
{"f_4586expand.scm",(void*)f_4586},
{"f_4590expand.scm",(void*)f_4590},
{"f_4595expand.scm",(void*)f_4595},
{"f_4607expand.scm",(void*)f_4607},
{"f_4601expand.scm",(void*)f_4601},
{"f_4496expand.scm",(void*)f_4496},
{"f_4532expand.scm",(void*)f_4532},
{"f_4535expand.scm",(void*)f_4535},
{"f_4547expand.scm",(void*)f_4547},
{"f_4584expand.scm",(void*)f_4584},
{"f_4559expand.scm",(void*)f_4559},
{"f_4574expand.scm",(void*)f_4574},
{"f_4550expand.scm",(void*)f_4550},
{"f_4541expand.scm",(void*)f_4541},
{"f_4499expand.scm",(void*)f_4499},
{"f_4503expand.scm",(void*)f_4503},
{"f_4509expand.scm",(void*)f_4509},
{"f_4512expand.scm",(void*)f_4512},
{"f_4478expand.scm",(void*)f_4478},
{"f_4486expand.scm",(void*)f_4486},
{"f_3996expand.scm",(void*)f_3996},
{"f_4295expand.scm",(void*)f_4295},
{"f_4469expand.scm",(void*)f_4469},
{"f_4462expand.scm",(void*)f_4462},
{"f_4301expand.scm",(void*)f_4301},
{"f_4403expand.scm",(void*)f_4403},
{"f_4409expand.scm",(void*)f_4409},
{"f_4416expand.scm",(void*)f_4416},
{"f_4310expand.scm",(void*)f_4310},
{"f_4322expand.scm",(void*)f_4322},
{"f_4390expand.scm",(void*)f_4390},
{"f_4380expand.scm",(void*)f_4380},
{"f_4384expand.scm",(void*)f_4384},
{"f_4348expand.scm",(void*)f_4348},
{"f_4344expand.scm",(void*)f_4344},
{"f_4178expand.scm",(void*)f_4178},
{"f_4235expand.scm",(void*)f_4235},
{"f_4238expand.scm",(void*)f_4238},
{"f_4264expand.scm",(void*)f_4264},
{"f_4260expand.scm",(void*)f_4260},
{"f_4250expand.scm",(void*)f_4250},
{"f_4182expand.scm",(void*)f_4182},
{"f_4204expand.scm",(void*)f_4204},
{"f_3999expand.scm",(void*)f_3999},
{"f_4003expand.scm",(void*)f_4003},
{"f_4176expand.scm",(void*)f_4176},
{"f_4172expand.scm",(void*)f_4172},
{"f_4006expand.scm",(void*)f_4006},
{"f_4014expand.scm",(void*)f_4014},
{"f_4127expand.scm",(void*)f_4127},
{"f_4154expand.scm",(void*)f_4154},
{"f_4160expand.scm",(void*)f_4160},
{"f_4133expand.scm",(void*)f_4133},
{"f_4137expand.scm",(void*)f_4137},
{"f_4140expand.scm",(void*)f_4140},
{"f_4020expand.scm",(void*)f_4020},
{"f_4026expand.scm",(void*)f_4026},
{"f_4037expand.scm",(void*)f_4037},
{"f_4054expand.scm",(void*)f_4054},
{"f_4073expand.scm",(void*)f_4073},
{"f_4084expand.scm",(void*)f_4084},
{"f_4048expand.scm",(void*)f_4048},
{"f_4034expand.scm",(void*)f_4034},
{"f_4012expand.scm",(void*)f_4012},
{"f_3987expand.scm",(void*)f_3987},
{"f_3936expand.scm",(void*)f_3936},
{"f_3948expand.scm",(void*)f_3948},
{"f_3950expand.scm",(void*)f_3950},
{"f_3985expand.scm",(void*)f_3985},
{"f_3977expand.scm",(void*)f_3977},
{"f_3944expand.scm",(void*)f_3944},
{"f_3880expand.scm",(void*)f_3880},
{"f_3884expand.scm",(void*)f_3884},
{"f_3893expand.scm",(void*)f_3893},
{"f_3912expand.scm",(void*)f_3912},
{"f_3902expand.scm",(void*)f_3902},
{"f_3867expand.scm",(void*)f_3867},
{"f_3878expand.scm",(void*)f_3878},
{"f_3871expand.scm",(void*)f_3871},
{"f_3834expand.scm",(void*)f_3834},
{"f_3838expand.scm",(void*)f_3838},
{"f_3841expand.scm",(void*)f_3841},
{"f_3679expand.scm",(void*)f_3679},
{"f_3779expand.scm",(void*)f_3779},
{"f_3774expand.scm",(void*)f_3774},
{"f_3681expand.scm",(void*)f_3681},
{"f_3687expand.scm",(void*)f_3687},
{"f_3773expand.scm",(void*)f_3773},
{"f_3769expand.scm",(void*)f_3769},
{"f_3744expand.scm",(void*)f_3744},
{"f_3748expand.scm",(void*)f_3748},
{"f_3697expand.scm",(void*)f_3697},
{"f_3703expand.scm",(void*)f_3703},
{"f_3649expand.scm",(void*)f_3649},
{"f_3655expand.scm",(void*)f_3655},
{"f_3600expand.scm",(void*)f_3600},
{"f_3607expand.scm",(void*)f_3607},
{"f_3610expand.scm",(void*)f_3610},
{"f_3613expand.scm",(void*)f_3613},
{"f_3616expand.scm",(void*)f_3616},
{"f_3622expand.scm",(void*)f_3622},
{"f_3625expand.scm",(void*)f_3625},
{"f_3582expand.scm",(void*)f_3582},
{"f_3595expand.scm",(void*)f_3595},
{"f_3551expand.scm",(void*)f_3551},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
