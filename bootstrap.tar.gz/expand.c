/* Generated from expand.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-08 10:27
   Version 4.0.0x4 - SVN rev. 12690
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-12-01 on dill (Linux)
   command line: expand.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file expand.c
   unit: expand
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[401];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,17),40,100,32,97,114,103,49,55,32,46,32,109,111,114,101,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,108,111,111,107,117,112,32,105,100,50,52,32,115,101,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,109,97,99,114,111,45,97,108,105,97,115,32,118,97,114,52,53,32,115,101,52,54,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,11),40,97,51,54,57,54,32,97,56,48,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,13),40,109,97,112,45,115,101,32,115,101,55,56,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,11),40,119,97,108,107,32,120,49,49,53,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,24),40,98,111,100,121,49,48,48,32,115,101,49,49,48,32,97,108,105,97,115,49,49,49,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,97,108,105,97,115,49,48,51,32,37,115,101,57,56,49,51,57,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,11),40,100,101,102,45,115,101,49,48,50,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,115,116,114,105,112,45,115,121,110,116,97,120,32,101,120,112,57,48,32,46,32,116,109,112,56,57,57,49,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,101,120,116,101,110,100,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,110,97,109,101,49,53,57,32,115,101,49,54,48,32,104,97,110,100,108,101,114,49,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,99,111,112,121,45,109,97,99,114,111,32,111,108,100,49,56,49,32,110,101,119,49,56,50,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,27),40,109,97,99,114,111,63,32,115,121,109,49,57,52,32,46,32,116,109,112,49,57,51,49,57,53,41,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,109,101,50,50,56,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,109,97,99,114,111,32,110,97,109,101,50,50,52,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,117,110,100,101,102,105,110,101,45,109,97,99,114,111,33,32,110,97,109,101,50,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,112,115,50,55,53,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,7),40,97,52,48,54,55,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,97,52,48,54,49,32,101,120,50,54,56,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,52,49,55,52,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,52,50,48,49,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,20),40,97,52,49,57,53,32,46,32,97,114,103,115,50,54,50,50,57,53,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,52,49,54,56,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,15),40,97,52,48,53,53,32,107,50,54,49,50,54,54,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,46),40,99,97,108,108,45,104,97,110,100,108,101,114,32,110,97,109,101,50,53,50,32,104,97,110,100,108,101,114,50,53,51,32,101,120,112,50,53,52,32,115,101,50,53,53,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,31),40,101,120,112,97,110,100,32,104,101,97,100,51,48,48,32,101,120,112,51,48,49,32,109,100,101,102,51,48,50,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,12),40,97,52,52,51,49,32,98,51,55,52,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,101,120,112,97,110,100,45,48,32,101,120,112,50,52,55,32,100,115,101,50,52,56,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,109,111,100,117,108,101,45,114,101,110,97,109,101,32,115,121,109,51,57,49,32,112,114,101,102,105,120,51,57,50,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,16),40,109,114,101,110,97,109,101,32,115,121,109,52,48,56,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,97,108,105,97,115,45,103,108,111,98,97,108,45,104,111,111,107,32,115,121,109,51,57,54,32,97,115,115,105,103,110,51,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,52,54,52,50,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,32),40,97,52,54,52,56,32,101,120,112,50,52,55,53,52,55,54,52,56,49,32,109,52,55,55,52,55,56,52,56,50,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,52,55,50,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,101,120,112,97,110,100,32,101,120,112,52,53,55,32,46,32,116,109,112,52,53,54,52,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,108,105,115,116,52,57,54,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,63,32,108,108,105,115,116,52,57,50,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,101,114,114,32,109,115,103,53,51,50,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,97,52,57,52,55,32,107,53,54,53,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,109,111,100,101,53,52,55,32,114,101,113,53,52,56,32,111,112,116,53,52,57,32,107,101,121,53,53,48,32,108,108,105,115,116,53,53,49,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,67),40,35,35,115,121,115,35,101,120,112,97,110,100,45,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,32,108,108,105,115,116,48,53,50,53,32,98,111,100,121,53,50,54,32,101,114,114,104,53,50,55,32,115,101,53,50,56,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,98,111,100,121,50,55,48,51,32,101,120,112,115,55,48,52,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,17),40,97,53,53,49,49,32,118,55,54,48,32,116,55,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,18),40,97,53,52,55,52,32,118,115,55,53,49,32,120,55,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,17),40,97,53,53,52,49,32,118,55,52,52,32,120,55,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,97,53,53,53,57,32,118,55,52,50,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,48),40,102,105,110,105,32,118,97,114,115,54,57,51,32,118,97,108,115,54,57,52,32,109,118,97,114,115,54,57,53,32,109,118,97,108,115,54,57,54,32,98,111,100,121,54,57,55,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,30),40,108,111,111,112,32,98,111,100,121,55,56,50,32,100,101,102,115,55,56,51,32,100,111,110,101,55,56,52,41,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,55),40,102,105,110,105,47,115,121,110,116,97,120,32,118,97,114,115,55,55,52,32,118,97,108,115,55,55,53,32,109,118,97,114,115,55,55,54,32,109,118,97,108,115,55,55,55,32,98,111,100,121,55,55,56,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,50,32,120,56,53,56,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,48),40,108,111,111,112,32,98,111,100,121,56,50,49,32,118,97,114,115,56,50,50,32,118,97,108,115,56,50,51,32,109,118,97,114,115,56,50,52,32,109,118,97,108,115,56,50,53,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,98,111,100,121,56,49,55,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,99,97,110,111,110,105,99,97,108,105,122,101,45,98,111,100,121,32,98,111,100,121,54,55,55,32,46,32,116,109,112,54,55,54,54,55,56,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,17),40,109,119,97,108,107,32,120,57,48,53,32,112,57,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,40),40,109,97,116,99,104,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,56,57,54,32,112,97,116,56,57,55,32,118,97,114,115,56,57,56,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,104,101,97,100,57,52,49,32,98,111,100,121,57,52,50,41,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,51),40,35,35,115,121,115,35,101,120,112,97,110,100,45,99,117,114,114,105,101,100,45,100,101,102,105,110,101,32,104,101,97,100,57,51,52,32,98,111,100,121,57,51,53,32,115,101,57,51,54,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,45,104,111,111,107,32,46,32,97,114,103,115,57,54,48,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,25),40,103,101,116,45,108,105,110,101,45,110,117,109,98,101,114,32,115,101,120,112,57,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,101,114,114,32,109,115,103,49,48,52,49,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,29),40,116,101,115,116,32,120,49,48,51,53,32,112,114,101,100,49,48,51,54,32,109,115,103,49,48,51,55,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,49,48,53,57,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,108,97,109,98,100,97,45,108,105,115,116,63,32,120,49,48,52,57,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,20),40,112,114,111,112,101,114,45,108,105,115,116,63,32,120,49,48,56,48,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,49,50,57,32,120,49,49,51,54,32,110,49,49,51,55,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,13),40,97,54,54,48,49,32,121,49,49,53,55,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,49,48,51,32,112,49,49,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,49,48,49,54,32,99,117,108,112,114,105,116,49,48,50,54,32,115,101,49,48,50,55,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,101,49,48,49,57,32,37,99,117,108,112,114,105,116,49,48,49,52,49,49,55,51,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,99,117,108,112,114,105,116,49,48,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,99,104,101,99,107,45,115,121,110,116,97,120,32,105,100,49,48,48,52,32,101,120,112,49,48,48,53,32,112,97,116,49,48,48,54,32,46,32,116,109,112,49,48,48,51,49,48,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,16),40,114,101,110,97,109,101,32,115,121,109,49,49,57,56,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,31),40,108,111,111,107,117,112,50,32,110,49,51,51,53,32,115,121,109,49,51,51,54,32,100,115,101,49,51,51,55,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,23),40,99,111,109,112,97,114,101,32,115,49,49,50,53,49,32,115,50,49,50,53,50,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,32),40,102,95,54,55,51,49,32,102,111,114,109,49,49,56,57,32,115,101,49,49,57,48,32,100,115,101,49,49,57,49,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,101,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,49,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,17),40,114,101,115,111,108,118,101,32,115,121,109,49,51,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,13),40,116,111,115,116,114,32,120,49,51,55,52,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,10),40,115,119,97,112,49,52,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,7),40,97,55,49,53,57,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,110,97,109,101,32,115,112,101,99,49,51,56,51,41,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,105,100,115,49,52,57,48,32,118,49,52,57,49,32,115,49,52,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,115,49,53,51,49,32,115,49,53,51,50,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,118,49,53,49,57,32,118,49,53,50,48,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,14),40,97,55,52,51,54,32,105,100,49,53,55,48,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,105,109,112,118,49,53,52,56,32,105,109,112,115,49,53,52,57,32,118,49,53,53,48,32,115,49,53,53,49,32,105,100,115,49,53,53,50,41,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,13),40,114,101,110,32,105,109,112,49,53,56,57,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,115,112,101,99,32,115,112,101,99,49,52,53,52,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,15),40,97,55,54,57,55,32,105,109,112,49,54,50,57,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,97,55,55,51,57,32,105,109,112,49,54,49,57,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,16),40,97,55,54,52,53,32,115,112,101,99,49,53,57,55,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,86),40,35,35,115,121,115,35,101,120,112,97,110,100,45,105,109,112,111,114,116,32,120,49,51,52,57,32,114,49,51,53,48,32,99,49,51,53,49,32,105,109,112,111,114,116,45,101,110,118,49,51,53,50,32,109,97,99,114,111,45,101,110,118,49,51,53,51,32,109,101,116,97,63,49,51,53,52,32,108,111,99,49,51,53,53,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,14),40,102,95,56,48,50,49,32,120,50,50,57,56,41,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,18),40,102,95,56,48,50,55,32,114,117,108,101,115,50,51,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,13),40,97,56,49,55,48,32,120,50,51,49,57,41,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,17),40,102,95,56,49,50,49,32,114,117,108,101,50,51,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,30),40,102,95,56,50,48,53,32,105,110,112,117,116,50,51,50,49,32,112,97,116,116,101,114,110,50,51,50,50,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,30),40,102,95,56,52,50,54,32,105,110,112,117,116,50,51,55,49,32,112,97,116,116,101,114,110,50,51,55,50,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,52,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,30),40,102,95,56,53,52,52,32,105,110,112,117,116,50,51,56,56,32,112,97,116,116,101,114,110,50,51,56,57,41,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,13),40,97,56,56,55,48,32,120,50,52,52,57,41,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,52,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,39),40,102,95,56,56,51,50,32,112,97,116,116,101,114,110,50,52,51,56,32,112,97,116,104,50,52,51,57,32,109,97,112,105,116,50,52,52,48,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,50,53,51,51,32,100,50,53,51,57,32,103,101,110,50,53,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,37),40,102,95,57,48,51,57,32,116,101,109,112,108,97,116,101,50,52,57,50,32,100,105,109,50,52,57,51,32,101,110,118,50,52,57,52,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,37),40,102,95,57,50,57,51,32,112,97,116,116,101,114,110,50,53,54,54,32,100,105,109,50,53,54,55,32,118,97,114,115,50,53,54,56,41,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,46),40,102,95,57,51,54,54,32,116,101,109,112,108,97,116,101,50,53,55,55,32,100,105,109,50,53,55,56,32,101,110,118,50,53,55,57,32,102,114,101,101,50,53,56,48,41,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,53,57,32,112,97,116,116,101,114,110,50,53,57,53,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,56,49,32,112,97,116,116,101,114,110,50,54,48,53,41,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,20),40,102,95,57,53,48,55,32,112,97,116,116,101,114,110,50,54,49,49,41,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,97,116,116,101,114,110,50,54,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,20),40,102,95,57,53,50,55,32,112,97,116,116,101,114,110,50,54,49,51,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,79),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,115,121,110,116,97,120,45,114,117,108,101,115,32,101,108,108,105,112,115,105,115,50,50,51,57,32,114,117,108,101,115,50,50,52,48,32,115,117,98,107,101,121,119,111,114,100,115,50,50,52,49,32,114,50,50,52,50,32,99,50,50,52,51,41,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,23),40,109,111,100,117,108,101,45,110,97,109,101,32,120,50,54,56,54,50,55,48,53,41,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,20),40,109,111,100,117,108,101,45,101,120,112,111,114,116,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,46),40,115,101,116,45,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,56,54,50,55,49,55,32,121,50,54,56,55,50,55,49,56,41,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,41,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,19),40,109,111,100,117,108,101,45,101,120,105,115,116,45,108,105,115,116,41,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,28),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,115,121,110,116,97,120,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,48),40,115,101,116,45,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,56,54,50,55,52,49,32,121,50,54,56,55,50,55,52,50,41};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,32,120,50,54,56,54,50,55,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,26),40,109,111,100,117,108,101,45,109,101,116,97,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,25),40,109,111,100,117,108,101,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,118,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,115,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,109,111,100,117,108,101,45,101,120,112,111,114,116,115,32,109,50,56,49,51,41,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,51),40,109,97,107,101,45,109,111,100,117,108,101,32,101,120,112,108,105,115,116,50,56,49,56,32,118,101,120,112,111,114,116,115,50,56,49,57,32,115,101,120,112,111,114,116,115,50,56,50,48,41,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,102,105,110,100,45,109,111,100,117,108,101,32,110,97,109,101,50,56,51,48,32,46,32,116,109,112,50,56,50,57,50,56,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,64),40,35,35,115,121,115,35,116,111,112,108,101,118,101,108,45,100,101,102,105,110,105,116,105,111,110,45,104,111,111,107,32,115,121,109,50,56,53,55,32,109,111,100,50,56,53,56,32,101,120,112,50,56,53,57,32,118,97,108,50,56,54,48,41};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,50,56,54,52,41};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,42),40,99,104,101,99,107,45,102,111,114,45,114,101,100,101,102,32,115,121,109,50,56,55,51,32,101,110,118,50,56,55,52,32,115,101,110,118,50,56,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,101,120,112,111,114,116,32,115,121,109,50,56,57,48,32,109,111,100,50,56,57,49,41,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,115,121,110,116,97,120,45,101,120,112,111,114,116,32,115,121,109,50,57,49,53,32,109,111,100,50,57,49,54,32,118,97,108,50,57,49,55,41,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,117,110,100,101,102,105,110,101,100,32,115,121,109,50,57,52,49,32,109,111,100,50,57,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,50,57,54,57,32,115,101,120,112,111,114,116,115,50,57,56,48,41,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,18),40,100,101,102,45,115,101,120,112,111,114,116,115,50,57,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,58),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,32,110,97,109,101,50,57,53,56,32,101,120,112,108,105,115,116,50,57,53,57,32,46,32,116,109,112,50,57,53,55,50,57,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,16),40,97,49,48,49,53,51,32,105,109,112,51,48,48,52,41};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,109,97,114,107,45,105,109,112,111,114,116,101,100,45,115,121,109,98,111,108,115,32,115,101,51,48,48,50,41,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,21),40,119,97,114,110,32,109,115,103,51,48,52,51,32,105,100,51,48,52,52,41,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,50,32,105,101,120,112,111,114,116,115,51,48,53,57,41,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,101,120,112,111,114,116,115,51,48,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,105,110,100,105,114,101,99,116,45,101,120,112,111,114,116,115,32,109,111,100,51,48,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,101,51,49,49,48,41,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,18),40,109,101,114,103,101,45,115,101,32,115,101,115,51,49,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,100,51,49,56,50,41,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,20),40,97,49,48,55,52,49,32,115,101,120,112,111,114,116,51,49,53,54,41,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,15),40,97,49,48,56,49,51,32,105,101,51,49,52,54,41,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,45,114,101,103,105,115,116,114,97,116,105,111,110,32,109,111,100,51,49,50,54,41,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,17),40,97,49,49,48,49,50,32,110,101,120,112,51,50,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,17),40,97,49,49,48,50,50,32,105,101,120,112,51,50,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,17),40,97,49,49,48,52,50,32,115,101,120,112,51,50,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,15),40,97,49,49,48,54,48,32,110,101,51,50,51,56,41,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,15),40,97,49,49,48,55,56,32,105,101,51,50,51,52,41,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,15),40,97,49,49,49,49,48,32,115,101,51,50,51,48,41,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,94),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,32,110,97,109,101,51,50,48,55,32,105,101,120,112,111,114,116,115,51,50,48,56,32,118,101,120,112,111,114,116,115,51,50,48,57,32,115,101,120,112,111,114,116,115,51,50,49,48,32,46,32,116,109,112,51,50,48,54,51,50,49,49,41,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,15),40,97,49,49,49,56,52,32,115,101,51,50,57,49,41,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,15),40,97,49,49,50,48,50,32,118,101,51,50,56,54,41,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,69),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,105,109,105,116,105,118,101,45,109,111,100,117,108,101,32,110,97,109,101,51,50,54,56,32,118,101,120,112,111,114,116,115,51,50,54,57,32,46,32,116,109,112,51,50,54,55,51,50,55,48,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,51,49,50,41,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,102,105,110,100,45,101,120,112,111,114,116,32,115,121,109,51,51,48,52,32,109,111,100,51,51,48,53,32,105,110,100,105,114,101,99,116,51,51,48,54,41};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,14),40,97,49,49,53,50,52,32,109,51,52,54,51,41,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,16),40,97,49,49,53,55,50,32,101,120,112,51,52,52,52,41};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,51,52,49,55,41,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,14),40,97,49,49,54,51,49,32,117,51,52,50,49,41,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,51,56,48,41,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,51,54,53,41,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,16),40,97,49,49,56,53,57,32,115,121,109,51,51,53,57,41};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,110,97,108,105,122,101,45,109,111,100,117,108,101,32,109,111,100,51,51,52,53,41,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,52,57,49,41,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,109,97,99,114,111,45,115,117,98,115,101,116,32,109,101,48,51,52,56,55,41,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,28),40,97,49,49,57,50,54,32,101,120,112,50,50,50,51,32,114,50,50,50,52,32,99,50,50,50,53,41,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,16),40,97,49,49,57,57,51,32,101,120,112,50,49,57,57,41};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,26),40,97,49,49,57,54,51,32,120,50,49,57,48,32,114,50,49,57,49,32,99,50,49,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,26),40,97,49,50,48,54,54,32,120,50,49,55,48,32,114,50,49,55,49,32,99,50,49,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,26),40,97,49,50,49,50,48,32,120,50,49,54,48,32,114,50,49,54,49,32,99,50,49,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,26),40,97,49,50,49,55,49,32,120,50,49,52,57,32,114,50,49,53,48,32,99,50,49,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,26),40,97,49,50,49,57,50,32,120,50,49,51,56,32,114,50,49,51,57,32,99,50,49,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,11),40,101,114,114,32,120,50,48,53,51,41,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,13),40,116,101,115,116,32,102,120,50,48,53,53,41,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,14),40,97,49,50,52,49,48,32,120,50,49,48,57,41,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,99,108,115,50,49,48,48,41};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,29),40,97,49,50,50,49,51,32,102,111,114,109,50,48,52,48,32,114,50,48,52,49,32,99,50,48,52,50,41,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,29),40,97,49,50,52,57,55,32,102,111,114,109,50,48,51,48,32,114,50,48,51,49,32,99,50,48,51,50,41,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,57,50,50,32,110,49,57,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,19),40,119,97,108,107,49,32,120,49,57,50,53,32,110,49,57,50,54,41,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,16),40,115,105,109,112,108,105,102,121,32,120,49,57,57,48,41};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,29),40,97,49,50,53,51,48,32,102,111,114,109,49,57,49,48,32,114,49,57,49,49,32,99,49,57,49,50,41,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,14),40,97,49,51,48,51,48,32,98,49,57,48,54,41,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,14),40,97,49,51,48,56,53,32,98,49,56,57,52,41,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,29),40,97,49,50,57,50,53,32,102,111,114,109,49,56,55,56,32,114,49,56,55,57,32,99,49,56,56,48,41,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,15),40,101,120,112,97,110,100,32,98,115,49,56,54,52,41,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,29),40,97,49,51,49,48,55,32,102,111,114,109,49,56,53,52,32,114,49,56,53,53,32,99,49,56,53,54,41,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,14),40,97,49,51,51,48,48,32,120,49,56,52,51,41,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,56,51,48,41,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,29),40,97,49,51,49,55,54,32,102,111,114,109,49,56,49,48,32,114,49,56,49,49,32,99,49,56,49,50,41,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,55,54,54,41,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,29),40,97,49,51,51,52,54,32,102,111,114,109,49,55,53,49,32,114,49,55,53,50,32,99,49,55,53,51,41,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,29),40,97,49,51,54,55,57,32,102,111,114,109,49,55,51,53,32,114,49,55,51,54,32,99,49,55,51,55,41,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,29),40,97,49,51,55,54,57,32,102,111,114,109,49,55,50,49,32,114,49,55,50,50,32,99,49,55,50,51,41,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,102,111,114,109,49,54,57,48,41,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,29),40,97,49,51,56,50,56,32,102,111,114,109,49,54,56,52,32,114,49,54,56,53,32,99,49,54,56,54,41,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,50),40,97,49,51,57,55,48,32,103,49,54,55,50,49,54,55,51,49,54,55,56,32,103,49,54,55,52,49,54,55,53,49,54,55,57,32,103,49,54,55,54,49,54,55,55,49,54,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,50),40,97,49,51,57,56,48,32,103,49,54,53,54,49,54,53,55,49,54,54,50,32,103,49,54,53,56,49,54,53,57,49,54,54,51,32,103,49,54,54,48,49,54,54,49,49,54,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_expand_toplevel)
C_externexport void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13981)
static void C_ccall f_13981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13979)
static void C_ccall f_13979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7868)
static void C_ccall f_7868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13971)
static void C_ccall f_13971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13969)
static void C_ccall f_13969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7871)
static void C_ccall f_7871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13829)
static void C_ccall f_13829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13839)
static void C_fcall f_13839(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13855)
static void C_ccall f_13855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13858)
static void C_ccall f_13858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13886)
static void C_ccall f_13886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13861)
static void C_ccall f_13861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13908)
static void C_ccall f_13908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13911)
static void C_ccall f_13911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13957)
static void C_ccall f_13957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13914)
static void C_ccall f_13914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13937)
static void C_ccall f_13937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13949)
static void C_ccall f_13949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13895)
static void C_ccall f_13895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13898)
static void C_ccall f_13898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13905)
static void C_ccall f_13905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13827)
static void C_ccall f_13827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_ccall f_7878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13770)
static void C_ccall f_13770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13799)
static void C_ccall f_13799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13819)
static void C_ccall f_13819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13823)
static void C_ccall f_13823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13768)
static void C_ccall f_13768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13680)
static void C_ccall f_13680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13705)
static void C_ccall f_13705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13712)
static void C_ccall f_13712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13732)
static void C_ccall f_13732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13752)
static void C_ccall f_13752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13756)
static void C_ccall f_13756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13678)
static void C_ccall f_13678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7884)
static void C_ccall f_7884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13347)
static void C_ccall f_13347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13354)
static void C_ccall f_13354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13357)
static void C_ccall f_13357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13360)
static void C_ccall f_13360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13363)
static void C_ccall f_13363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13366)
static void C_ccall f_13366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13369)
static void C_ccall f_13369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13372)
static void C_ccall f_13372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13377)
static void C_fcall f_13377(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13393)
static void C_ccall f_13393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13399)
static void C_ccall f_13399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13441)
static void C_ccall f_13441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13509)
static void C_ccall f_13509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13634)
static void C_ccall f_13634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13630)
static void C_ccall f_13630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13512)
static void C_ccall f_13512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13567)
static void C_ccall f_13567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13444)
static void C_ccall f_13444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13483)
static void C_ccall f_13483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13435)
static void C_ccall f_13435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13406)
static void C_ccall f_13406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13345)
static void C_ccall f_13345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7887)
static void C_ccall f_7887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13177)
static void C_ccall f_13177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13181)
static void C_ccall f_13181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13190)
static void C_ccall f_13190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13193)
static void C_ccall f_13193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13196)
static void C_ccall f_13196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13199)
static void C_ccall f_13199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13202)
static void C_ccall f_13202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13223)
static void C_fcall f_13223(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13239)
static void C_ccall f_13239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13245)
static void C_ccall f_13245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13301)
static void C_ccall f_13301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13299)
static void C_ccall f_13299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13295)
static void C_ccall f_13295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13287)
static void C_ccall f_13287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13283)
static void C_ccall f_13283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13252)
static void C_ccall f_13252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13221)
static void C_ccall f_13221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13175)
static void C_ccall f_13175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13108)
static void C_ccall f_13108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13112)
static void C_ccall f_13112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13121)
static void C_ccall f_13121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13126)
static void C_fcall f_13126(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13163)
static void C_ccall f_13163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13144)
static void C_ccall f_13144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13106)
static void C_ccall f_13106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12926)
static void C_ccall f_12926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12930)
static void C_ccall f_12930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12942)
static void C_ccall f_12942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12945)
static void C_ccall f_12945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12948)
static void C_ccall f_12948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12951)
static void C_ccall f_12951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13086)
static void C_ccall f_13086(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12966)
static void C_ccall f_12966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13084)
static void C_ccall f_13084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12993)
static void C_fcall f_12993(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13074)
static void C_ccall f_13074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13009)
static void C_fcall f_13009(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13031)
static void C_ccall f_13031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13029)
static void C_ccall f_13029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13025)
static void C_ccall f_13025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12924)
static void C_ccall f_12924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12531)
static void C_ccall f_12531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12535)
static void C_ccall f_12535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12538)
static void C_ccall f_12538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12541)
static void C_ccall f_12541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12544)
static void C_ccall f_12544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12913)
static void C_ccall f_12913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12825)
static void C_fcall f_12825(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12829)
static void C_ccall f_12829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12854)
static void C_ccall f_12854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12900)
static void C_ccall f_12900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12885)
static void C_ccall f_12885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12556)
static void C_fcall f_12556(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12603)
static void C_ccall f_12603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12650)
static void C_ccall f_12650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12811)
static void C_ccall f_12811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12819)
static void C_ccall f_12819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12797)
static void C_ccall f_12797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12786)
static void C_ccall f_12786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12794)
static void C_ccall f_12794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12771)
static void C_ccall f_12771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12759)
static void C_ccall f_12759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12740)
static void C_ccall f_12740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12698)
static void C_ccall f_12698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12675)
static void C_ccall f_12675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12629)
static void C_ccall f_12629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12578)
static void C_ccall f_12578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12574)
static void C_ccall f_12574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12546)
static void C_fcall f_12546(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12554)
static void C_ccall f_12554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12529)
static void C_ccall f_12529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_ccall f_7899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12498)
static void C_ccall f_12498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12502)
static void C_ccall f_12502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12496)
static void C_ccall f_12496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7902)
static void C_ccall f_7902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12214)
static void C_ccall f_12214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12221)
static void C_ccall f_12221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12224)
static void C_ccall f_12224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12227)
static void C_ccall f_12227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12230)
static void C_ccall f_12230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12233)
static void C_ccall f_12233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12395)
static void C_fcall f_12395(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12448)
static void C_ccall f_12448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12470)
static void C_ccall f_12470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12477)
static void C_ccall f_12477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12464)
static void C_ccall f_12464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12411)
static void C_ccall f_12411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12409)
static void C_ccall f_12409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12245)
static void C_fcall f_12245(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12276)
static void C_ccall f_12276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12322)
static void C_ccall f_12322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12372)
static void C_ccall f_12372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12379)
static void C_ccall f_12379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12337)
static void C_ccall f_12337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12351)
static void C_ccall f_12351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12294)
static void C_ccall f_12294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12305)
static void C_ccall f_12305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12235)
static void C_fcall f_12235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12212)
static void C_ccall f_12212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7905)
static void C_ccall f_7905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12193)
static void C_ccall f_12193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12191)
static void C_ccall f_12191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7908)
static void C_ccall f_7908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12172)
static void C_ccall f_12172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12170)
static void C_ccall f_12170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7911)
static void C_ccall f_7911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12121)
static void C_ccall f_12121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12125)
static void C_ccall f_12125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12162)
static void C_ccall f_12162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12155)
static void C_ccall f_12155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12148)
static void C_ccall f_12148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12119)
static void C_ccall f_12119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7914)
static void C_ccall f_7914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12067)
static void C_ccall f_12067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12071)
static void C_ccall f_12071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12074)
static void C_ccall f_12074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12111)
static void C_ccall f_12111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12077)
static void C_ccall f_12077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12092)
static void C_ccall f_12092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12096)
static void C_ccall f_12096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12065)
static void C_ccall f_12065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7917)
static void C_ccall f_7917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11964)
static void C_ccall f_11964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11971)
static void C_ccall f_11971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11974)
static void C_ccall f_11974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11994)
static void C_ccall f_11994(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12016)
static C_word C_fcall f_12016(C_word t0);
C_noret_decl(f_12001)
static void C_fcall f_12001(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12008)
static void C_ccall f_12008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11977)
static void C_ccall f_11977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11992)
static void C_ccall f_11992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11984)
static void C_ccall f_11984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11980)
static void C_ccall f_11980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11962)
static void C_ccall f_11962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7920)
static void C_ccall f_7920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11927)
static void C_ccall f_11927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11931)
static void C_ccall f_11931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11949)
static void C_ccall f_11949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11940)
static void C_fcall f_11940(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11925)
static void C_ccall f_11925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7923)
static void C_ccall f_7923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9568)
static void C_ccall f_9568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11921)
static void C_ccall f_11921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9572)
static void C_ccall f_9572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9576)
static void C_ccall f_9576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11879)
static void C_ccall f_11879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11887)
static void C_ccall f_11887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11889)
static void C_fcall f_11889(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11910)
static void C_ccall f_11910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11333)
static void C_ccall f_11333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11340)
static void C_ccall f_11340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11860)
static void C_ccall f_11860(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11872)
static void C_ccall f_11872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11349)
static void C_ccall f_11349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11817)
static void C_ccall f_11817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11819)
static void C_fcall f_11819(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11858)
static void C_ccall f_11858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11832)
static void C_ccall f_11832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11843)
static void C_ccall f_11843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11352)
static void C_ccall f_11352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11686)
static void C_fcall f_11686(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11737)
static void C_fcall f_11737(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11791)
static void C_ccall f_11791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11749)
static void C_fcall f_11749(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11777)
static void C_ccall f_11777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11773)
static void C_ccall f_11773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11769)
static void C_ccall f_11769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11752)
static void C_ccall f_11752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11734)
static void C_ccall f_11734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11723)
static void C_ccall f_11723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11355)
static void C_ccall f_11355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11680)
static void C_ccall f_11680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11632)
static void C_ccall f_11632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11643)
static void C_ccall f_11643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11646)
static void C_ccall f_11646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11658)
static void C_fcall f_11658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11408)
static void C_ccall f_11408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11365)
static void C_ccall f_11365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11375)
static void C_fcall f_11375(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11389)
static void C_ccall f_11389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11393)
static void C_ccall f_11393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11369)
static void C_ccall f_11369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11626)
static void C_ccall f_11626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11630)
static void C_ccall f_11630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11622)
static void C_ccall f_11622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11411)
static void C_ccall f_11411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11414)
static void C_ccall f_11414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11609)
static void C_ccall f_11609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11573)
static void C_ccall f_11573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11601)
static void C_ccall f_11601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11417)
static void C_ccall f_11417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11567)
static void C_ccall f_11567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11571)
static void C_ccall f_11571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11420)
static void C_ccall f_11420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11423)
static void C_ccall f_11423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11525)
static void C_ccall f_11525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11529)
static void C_ccall f_11529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11559)
static void C_ccall f_11559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11555)
static void C_ccall f_11555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11532)
static void C_ccall f_11532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11426)
static void C_ccall f_11426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11447)
static void C_ccall f_11447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11523)
static void C_ccall f_11523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11519)
static void C_ccall f_11519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11515)
static void C_ccall f_11515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11511)
static void C_ccall f_11511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11507)
static void C_ccall f_11507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11503)
static void C_ccall f_11503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11499)
static void C_ccall f_11499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11495)
static void C_ccall f_11495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11491)
static void C_ccall f_11491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11429)
static void C_ccall f_11429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11432)
static void C_ccall f_11432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11248)
static void C_ccall f_11248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11259)
static void C_ccall f_11259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11261)
static void C_fcall f_11261(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11310)
static void C_ccall f_11310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11306)
static void C_ccall f_11306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11289)
static void C_fcall f_11289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11157)
static void C_ccall f_11157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11157)
static void C_ccall f_11157r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11161)
static void C_ccall f_11161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11164)
static void C_ccall f_11164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11203)
static void C_ccall f_11203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11223)
static void C_ccall f_11223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11213)
static void C_ccall f_11213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11216)
static void C_ccall f_11216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11179)
static void C_ccall f_11179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11185)
static void C_ccall f_11185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11183)
static void C_ccall f_11183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10949)
static void C_ccall f_10949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_10949)
static void C_ccall f_10949r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_10953)
static void C_ccall f_10953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11111)
static void C_ccall f_11111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11132)
static void C_ccall f_11132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10976)
static void C_ccall f_10976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10979)
static void C_ccall f_10979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11079)
static void C_ccall f_11079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11101)
static void C_ccall f_11101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10982)
static void C_ccall f_10982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11061)
static void C_ccall f_11061(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11073)
static void C_ccall f_11073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10985)
static void C_ccall f_10985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11055)
static void C_ccall f_11055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11059)
static void C_ccall f_11059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10991)
static void C_ccall f_10991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10994)
static void C_ccall f_10994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11043)
static void C_ccall f_11043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10997)
static void C_ccall f_10997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11023)
static void C_ccall f_11023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11000)
static void C_ccall f_11000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11013)
static void C_ccall f_11013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11003)
static void C_ccall f_11003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10555)
static void C_ccall f_10555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10562)
static void C_ccall f_10562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10947)
static void C_ccall f_10947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10578)
static void C_fcall f_10578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10917)
static void C_ccall f_10917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10586)
static void C_fcall f_10586(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10899)
static void C_ccall f_10899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10594)
static void C_ccall f_10594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10895)
static void C_ccall f_10895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10887)
static void C_ccall f_10887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10814)
static void C_ccall f_10814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10812)
static void C_ccall f_10812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10808)
static void C_ccall f_10808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10742)
static void C_ccall f_10742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10789)
static void C_ccall f_10789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10774)
static void C_ccall f_10774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10740)
static void C_ccall f_10740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10736)
static void C_ccall f_10736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10662)
static void C_fcall f_10662(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10732)
static void C_ccall f_10732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10685)
static void C_ccall f_10685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10728)
static void C_ccall f_10728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10720)
static void C_ccall f_10720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10716)
static void C_ccall f_10716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10696)
static void C_ccall f_10696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10650)
static void C_ccall f_10650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10646)
static void C_ccall f_10646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10590)
static void C_ccall f_10590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10582)
static void C_ccall f_10582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10483)
static void C_fcall f_10483(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10487)
static void C_ccall f_10487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10490)
static void C_ccall f_10490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10502)
static void C_fcall f_10502(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10541)
static void C_ccall f_10541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10533)
static void C_ccall f_10533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10493)
static void C_ccall f_10493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10496)
static void C_ccall f_10496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10207)
static void C_fcall f_10207(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10214)
static void C_ccall f_10214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10288)
static void C_fcall f_10288(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10315)
static void C_ccall f_10315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10317)
static void C_fcall f_10317(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10477)
static void C_ccall f_10477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10465)
static void C_ccall f_10465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10446)
static void C_ccall f_10446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10428)
static void C_ccall f_10428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10413)
static void C_ccall f_10413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10383)
static void C_ccall f_10383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10340)
static void C_ccall f_10340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10265)
static void C_fcall f_10265(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10277)
static void C_ccall f_10277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10273)
static void C_ccall f_10273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10148)
static void C_ccall f_10148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10154)
static void C_ccall f_10154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10161)
static void C_fcall f_10161(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10164)
static void C_ccall f_10164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10080)
static void C_ccall f_10080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10080)
static void C_ccall f_10080r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10100)
static C_word C_fcall f_10100(C_word *a,C_word t0);
C_noret_decl(f_10095)
static C_word C_fcall f_10095(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_10082)
static C_word C_fcall f_10082(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_10058)
static void C_ccall f_10058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10065)
static void C_ccall f_10065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9977)
static void C_ccall f_9977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9987)
static void C_ccall f_9987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9990)
static void C_ccall f_9990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9993)
static void C_ccall f_9993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9996)
static void C_ccall f_9996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10039)
static void C_ccall f_10039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10043)
static void C_ccall f_10043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9999)
static void C_ccall f_9999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10002)
static void C_ccall f_10002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10005)
static void C_ccall f_10005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9888)
static void C_ccall f_9888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9898)
static void C_ccall f_9898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9901)
static void C_ccall f_9901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9968)
static void C_ccall f_9968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9964)
static void C_ccall f_9964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9904)
static void C_ccall f_9904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9960)
static void C_ccall f_9960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9907)
static void C_ccall f_9907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9946)
static void C_ccall f_9946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9950)
static void C_ccall f_9950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9910)
static void C_ccall f_9910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9913)
static void C_ccall f_9913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9919)
static void C_ccall f_9919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9867)
static void C_fcall f_9867(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9874)
static void C_ccall f_9874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9847)
static void C_ccall f_9847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9851)
static void C_ccall f_9851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9844)
static void C_ccall f_9844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9804)
static void C_ccall f_9804(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9804)
static void C_ccall f_9804r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9808)
static void C_ccall f_9808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9798)
static C_word C_fcall f_9798(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3);
C_noret_decl(f_9780)
static void C_ccall f_9780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9770)
static C_word C_fcall f_9770(C_word t0);
C_noret_decl(f_9752)
static C_word C_fcall f_9752(C_word t0);
C_noret_decl(f_9734)
static C_word C_fcall f_9734(C_word t0);
C_noret_decl(f_9716)
static C_word C_fcall f_9716(C_word t0);
C_noret_decl(f_9698)
static C_word C_fcall f_9698(C_word t0);
C_noret_decl(f_9680)
static void C_ccall f_9680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9671)
static void C_ccall f_9671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9662)
static C_word C_fcall f_9662(C_word t0);
C_noret_decl(f_9644)
static C_word C_fcall f_9644(C_word t0);
C_noret_decl(f_9626)
static C_word C_fcall f_9626(C_word t0);
C_noret_decl(f_9617)
static void C_fcall f_9617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9608)
static C_word C_fcall f_9608(C_word t0);
C_noret_decl(f_9590)
static void C_ccall f_9590(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7925)
static void C_ccall f_7925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7932)
static void C_ccall f_7932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7946)
static void C_ccall f_7946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7959)
static void C_ccall f_7959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7965)
static void C_ccall f_7965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7969)
static void C_ccall f_7969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7973)
static void C_ccall f_7973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7977)
static void C_ccall f_7977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7981)
static void C_ccall f_7981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7986)
static void C_ccall f_7986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7997)
static void C_ccall f_7997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8006)
static void C_ccall f_8006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8010)
static void C_ccall f_8010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8014)
static void C_ccall f_8014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8019)
static void C_ccall f_8019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9527)
static void C_ccall f_9527(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9537)
static void C_fcall f_9537(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9544)
static void C_ccall f_9544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9507)
static void C_ccall f_9507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9514)
static void C_ccall f_9514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9521)
static void C_ccall f_9521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9481)
static void C_ccall f_9481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9459)
static void C_ccall f_9459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9466)
static void C_ccall f_9466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9366)
static void C_ccall f_9366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9408)
static void C_ccall f_9408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9457)
static void C_ccall f_9457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9440)
static void C_ccall f_9440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9419)
static void C_ccall f_9419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9379)
static void C_fcall f_9379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9293)
static void C_ccall f_9293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9319)
static void C_ccall f_9319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9364)
static void C_ccall f_9364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9347)
static void C_ccall f_9347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9039)
static void C_ccall f_9039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9284)
static void C_ccall f_9284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9280)
static void C_ccall f_9280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9247)
static void C_ccall f_9247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9255)
static void C_ccall f_9255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9089)
static void C_ccall f_9089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9095)
static void C_ccall f_9095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9107)
static void C_ccall f_9107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9173)
static void C_fcall f_9173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9188)
static void C_ccall f_9188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9110)
static void C_fcall f_9110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9144)
static void C_fcall f_9144(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9113)
static void C_ccall f_9113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9142)
static void C_ccall f_9142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9138)
static void C_ccall f_9138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9134)
static void C_ccall f_9134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8832)
static void C_ccall f_8832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8862)
static void C_ccall f_8862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8962)
static void C_ccall f_8962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8985)
static void C_fcall f_8985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9003)
static void C_ccall f_9003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8972)
static void C_ccall f_8972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8922)
static void C_ccall f_8922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8926)
static void C_ccall f_8926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8871)
static void C_ccall f_8871(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8879)
static void C_fcall f_8879(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8856)
static void C_ccall f_8856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8551)
static void C_ccall f_8551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8590)
static void C_fcall f_8590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8600)
static void C_fcall f_8600(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8731)
static void C_ccall f_8731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8735)
static void C_ccall f_8735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8660)
static void C_ccall f_8660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8598)
static void C_ccall f_8598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8594)
static void C_ccall f_8594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8426)
static void C_ccall f_8426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8255)
static void C_ccall f_8255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8369)
static void C_fcall f_8369(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8307)
static void C_ccall f_8307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8311)
static void C_ccall f_8311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8121)
static void C_ccall f_8121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8128)
static void C_fcall f_8128(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8131)
static void C_ccall f_8131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8180)
static void C_ccall f_8180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8171)
static void C_ccall f_8171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8157)
static void C_ccall f_8157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8165)
static void C_ccall f_8165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8027)
static void C_ccall f_8027(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8071)
static void C_ccall f_8071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8067)
static void C_ccall f_8067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8021)
static void C_ccall f_8021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7036)
static void C_ccall f_7036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7638)
static void C_ccall f_7638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7842)
static void C_ccall f_7842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7659)
static void C_ccall f_7659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7809)
static void C_ccall f_7809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7817)
static void C_ccall f_7817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7662)
static void C_ccall f_7662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_ccall f_7786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7794)
static void C_ccall f_7794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7665)
static void C_ccall f_7665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7668)
static void C_ccall f_7668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7740)
static void C_ccall f_7740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7774)
static void C_ccall f_7774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7671)
static void C_ccall f_7671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7698)
static void C_ccall f_7698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7674)
static void C_ccall f_7674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7692)
static void C_ccall f_7692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7677)
static void C_ccall f_7677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7688)
static void C_ccall f_7688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7684)
static void C_ccall f_7684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7644)
static void C_ccall f_7644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7177)
static void C_fcall f_7177(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7196)
static void C_fcall f_7196(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7297)
static void C_ccall f_7297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7551)
static void C_ccall f_7551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7554)
static void C_ccall f_7554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7557)
static void C_ccall f_7557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7590)
static void C_ccall f_7590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7594)
static void C_ccall f_7594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7559)
static void C_ccall f_7559(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7579)
static void C_ccall f_7579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_ccall f_7575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7567)
static void C_ccall f_7567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7407)
static void C_ccall f_7407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7416)
static void C_fcall f_7416(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7545)
static void C_ccall f_7545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7526)
static void C_ccall f_7526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7514)
static void C_ccall f_7514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7462)
static void C_ccall f_7462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7432)
static void C_ccall f_7432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7300)
static void C_ccall f_7300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7303)
static void C_ccall f_7303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7308)
static void C_fcall f_7308(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7394)
static void C_ccall f_7394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7320)
static void C_fcall f_7320(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7220)
static void C_ccall f_7220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7228)
static void C_fcall f_7228(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7090)
static void C_fcall f_7090(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7097)
static void C_ccall f_7097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7175)
static void C_ccall f_7175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7171)
static void C_ccall f_7171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7154)
static void C_ccall f_7154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7122)
static void C_ccall f_7122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7126)
static void C_ccall f_7126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7129)
static void C_ccall f_7129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7136)
static void C_ccall f_7136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7143)
static void C_ccall f_7143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7150)
static void C_ccall f_7150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7047)
static void C_fcall f_7047(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7060)
static void C_ccall f_7060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7042)
static void C_ccall f_7042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6731)
static void C_ccall f_6731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6860)
static void C_ccall f_6860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6893)
static void C_ccall f_6893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6983)
static void C_ccall f_6983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6896)
static void C_fcall f_6896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6977)
static void C_ccall f_6977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6902)
static void C_fcall f_6902(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6971)
static void C_ccall f_6971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6948)
static void C_ccall f_6948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6921)
static void C_ccall f_6921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6928)
static void C_ccall f_6928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6864)
static void C_fcall f_6864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6997)
static void C_fcall f_6997(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7001)
static void C_ccall f_7001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_ccall f_7004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6734)
static void C_ccall f_6734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6831)
static void C_ccall f_6831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6834)
static void C_ccall f_6834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_ccall f_6801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6804)
static void C_ccall f_6804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6744)
static void C_ccall f_6744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6681)
static void C_fcall f_6681(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6672)
static void C_fcall f_6672(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6680)
static void C_ccall f_6680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6269)
static void C_fcall f_6269(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6400)
static void C_fcall f_6400(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6405)
static void C_fcall f_6405(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6602)
static void C_ccall f_6602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6606)
static void C_ccall f_6606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6424)
static void C_fcall f_6424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6429)
static void C_fcall f_6429(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6371)
static void C_ccall f_6371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6377)
static C_word C_fcall f_6377(C_word t0);
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6319)
static void C_ccall f_6319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_fcall f_6327(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6347)
static void C_ccall f_6347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6272)
static void C_fcall f_6272(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6279)
static void C_ccall f_6279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6284)
static void C_fcall f_6284(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6302)
static void C_ccall f_6302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6295)
static void C_ccall f_6295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6228)
static void C_ccall f_6228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6150)
static void C_ccall f_6150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6153)
static void C_fcall f_6153(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6179)
static void C_ccall f_6179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6067)
static void C_fcall f_6067(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6070)
static void C_fcall f_6070(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5757)
static void C_fcall f_5757(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5763)
static void C_fcall f_5763(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6027)
static void C_ccall f_6027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5785)
static void C_fcall f_5785(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5995)
static void C_ccall f_5995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5808)
static void C_fcall f_5808(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5821)
static void C_ccall f_5821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5904)
static void C_ccall f_5904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5580)
static void C_fcall f_5580(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5590)
static void C_fcall f_5590(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5735)
static void C_ccall f_5735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5636)
static void C_fcall f_5636(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5680)
static void C_ccall f_5680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5654)
static void C_fcall f_5654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5588)
static void C_ccall f_5588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_fcall f_5320(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5431)
static void C_ccall f_5431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5558)
static void C_ccall f_5558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_fcall f_5332(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_fcall f_5355(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_ccall f_4753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4761)
static void C_fcall f_4761(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5072)
static void C_ccall f_5072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5251)
static void C_fcall f_5251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5170)
static void C_fcall f_5170(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5124)
static void C_fcall f_5124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_fcall f_5127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_fcall f_5087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_fcall f_5049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_fcall f_4983(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_fcall f_4779(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_fcall f_4791(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_fcall f_4782(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_fcall f_4727(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4687)
static void C_fcall f_4687(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4706)
static void C_fcall f_4706(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_fcall f_4637(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_fcall f_4541(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4504)
static void C_ccall f_4504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4343)
static void C_fcall f_4343(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_fcall f_4445(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4220)
static void C_fcall f_4220(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_fcall f_4280(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4292)
static void C_fcall f_4292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_fcall f_4041(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_fcall f_4079(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_fcall f_4096(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4115)
static void C_fcall f_4115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_fcall f_4076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_fcall f_3992(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3821)
static void C_fcall f_3821(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_fcall f_3816(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3723)
static void C_fcall f_3723(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3745)
static void C_fcall f_3745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_fcall f_3691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3642)
static void C_fcall f_3642(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_fcall f_3652(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_fcall f_3624(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

C_noret_decl(trf_13839)
static void C_fcall trf_13839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13839(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13839(t0,t1,t2);}

C_noret_decl(trf_13377)
static void C_fcall trf_13377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13377(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13377(t0,t1,t2);}

C_noret_decl(trf_13223)
static void C_fcall trf_13223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13223(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13223(t0,t1,t2);}

C_noret_decl(trf_13126)
static void C_fcall trf_13126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13126(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13126(t0,t1,t2);}

C_noret_decl(trf_12993)
static void C_fcall trf_12993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12993(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12993(t0,t1);}

C_noret_decl(trf_13009)
static void C_fcall trf_13009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13009(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13009(t0,t1);}

C_noret_decl(trf_12825)
static void C_fcall trf_12825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12825(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12825(t0,t1,t2);}

C_noret_decl(trf_12556)
static void C_fcall trf_12556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12556(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12556(t0,t1,t2,t3);}

C_noret_decl(trf_12546)
static void C_fcall trf_12546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12546(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12546(t0,t1,t2,t3);}

C_noret_decl(trf_12395)
static void C_fcall trf_12395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12395(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12395(t0,t1,t2);}

C_noret_decl(trf_12245)
static void C_fcall trf_12245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12245(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12245(t0,t1,t2);}

C_noret_decl(trf_12235)
static void C_fcall trf_12235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12235(t0,t1,t2);}

C_noret_decl(trf_12001)
static void C_fcall trf_12001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12001(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12001(t0,t1);}

C_noret_decl(trf_11940)
static void C_fcall trf_11940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11940(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11940(t0,t1);}

C_noret_decl(trf_11889)
static void C_fcall trf_11889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11889(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11889(t0,t1,t2);}

C_noret_decl(trf_11819)
static void C_fcall trf_11819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11819(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11819(t0,t1,t2);}

C_noret_decl(trf_11686)
static void C_fcall trf_11686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11686(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11686(t0,t1,t2);}

C_noret_decl(trf_11737)
static void C_fcall trf_11737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11737(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11737(t0,t1);}

C_noret_decl(trf_11749)
static void C_fcall trf_11749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11749(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11749(t0,t1);}

C_noret_decl(trf_11658)
static void C_fcall trf_11658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11658(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11658(t0,t1);}

C_noret_decl(trf_11375)
static void C_fcall trf_11375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11375(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11375(t0,t1,t2);}

C_noret_decl(trf_11261)
static void C_fcall trf_11261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11261(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11261(t0,t1,t2);}

C_noret_decl(trf_11289)
static void C_fcall trf_11289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11289(t0,t1);}

C_noret_decl(trf_10578)
static void C_fcall trf_10578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10578(t0,t1);}

C_noret_decl(trf_10586)
static void C_fcall trf_10586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10586(t0,t1);}

C_noret_decl(trf_10662)
static void C_fcall trf_10662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10662(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10662(t0,t1,t2);}

C_noret_decl(trf_10483)
static void C_fcall trf_10483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10483(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10483(t0,t1);}

C_noret_decl(trf_10502)
static void C_fcall trf_10502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10502(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10502(t0,t1,t2);}

C_noret_decl(trf_10207)
static void C_fcall trf_10207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10207(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10207(t0,t1);}

C_noret_decl(trf_10288)
static void C_fcall trf_10288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10288(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10288(t0,t1,t2);}

C_noret_decl(trf_10317)
static void C_fcall trf_10317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10317(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10317(t0,t1,t2);}

C_noret_decl(trf_10265)
static void C_fcall trf_10265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10265(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10265(t0,t1,t2,t3);}

C_noret_decl(trf_10161)
static void C_fcall trf_10161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10161(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10161(t0,t1);}

C_noret_decl(trf_9867)
static void C_fcall trf_9867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9867(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9867(t0,t1,t2,t3);}

C_noret_decl(trf_9617)
static void C_fcall trf_9617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9617(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9617(t0,t1,t2);}

C_noret_decl(trf_9537)
static void C_fcall trf_9537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9537(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9537(t0,t1,t2);}

C_noret_decl(trf_9379)
static void C_fcall trf_9379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9379(t0,t1);}

C_noret_decl(trf_9173)
static void C_fcall trf_9173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9173(t0,t1);}

C_noret_decl(trf_9110)
static void C_fcall trf_9110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9110(t0,t1);}

C_noret_decl(trf_9144)
static void C_fcall trf_9144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9144(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9144(t0,t1,t2,t3);}

C_noret_decl(trf_8985)
static void C_fcall trf_8985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8985(t0,t1,t2);}

C_noret_decl(trf_8879)
static void C_fcall trf_8879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8879(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8879(t0,t1);}

C_noret_decl(trf_8590)
static void C_fcall trf_8590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8590(t0,t1);}

C_noret_decl(trf_8600)
static void C_fcall trf_8600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8600(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8600(t0,t1,t2);}

C_noret_decl(trf_8369)
static void C_fcall trf_8369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8369(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8369(t0,t1);}

C_noret_decl(trf_8128)
static void C_fcall trf_8128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8128(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8128(t0,t1);}

C_noret_decl(trf_7177)
static void C_fcall trf_7177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7177(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7177(t0,t1,t2);}

C_noret_decl(trf_7196)
static void C_fcall trf_7196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7196(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7196(t0,t1);}

C_noret_decl(trf_7416)
static void C_fcall trf_7416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7416(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7416(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7308)
static void C_fcall trf_7308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7308(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7308(t0,t1,t2,t3);}

C_noret_decl(trf_7320)
static void C_fcall trf_7320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7320(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7320(t0,t1,t2,t3);}

C_noret_decl(trf_7228)
static void C_fcall trf_7228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7228(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7228(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7090)
static void C_fcall trf_7090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7090(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7090(t0,t1,t2);}

C_noret_decl(trf_7047)
static void C_fcall trf_7047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7047(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7047(t0,t1,t2);}

C_noret_decl(trf_6896)
static void C_fcall trf_6896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6896(t0,t1);}

C_noret_decl(trf_6902)
static void C_fcall trf_6902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6902(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6902(t0,t1);}

C_noret_decl(trf_6864)
static void C_fcall trf_6864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6864(t0,t1);}

C_noret_decl(trf_6997)
static void C_fcall trf_6997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6997(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6997(t0,t1,t2,t3);}

C_noret_decl(trf_6681)
static void C_fcall trf_6681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6681(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6681(t0,t1);}

C_noret_decl(trf_6672)
static void C_fcall trf_6672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6672(t0,t1,t2);}

C_noret_decl(trf_6269)
static void C_fcall trf_6269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6269(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6269(t0,t1,t2,t3);}

C_noret_decl(trf_6400)
static void C_fcall trf_6400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6400(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6400(t0,t1);}

C_noret_decl(trf_6405)
static void C_fcall trf_6405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6405(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6405(t0,t1,t2,t3);}

C_noret_decl(trf_6424)
static void C_fcall trf_6424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6424(t0,t1);}

C_noret_decl(trf_6429)
static void C_fcall trf_6429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6429(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6429(t0,t1,t2,t3);}

C_noret_decl(trf_6327)
static void C_fcall trf_6327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6327(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6327(t0,t1,t2);}

C_noret_decl(trf_6272)
static void C_fcall trf_6272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6272(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6272(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6284)
static void C_fcall trf_6284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6284(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6284(t0,t1,t2);}

C_noret_decl(trf_6153)
static void C_fcall trf_6153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6153(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6153(t0,t1,t2,t3);}

C_noret_decl(trf_6067)
static void C_fcall trf_6067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6067(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6067(t0,t1,t2,t3);}

C_noret_decl(trf_6070)
static void C_fcall trf_6070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6070(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6070(t0,t1,t2,t3);}

C_noret_decl(trf_5757)
static void C_fcall trf_5757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5757(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5757(t0,t1,t2);}

C_noret_decl(trf_5763)
static void C_fcall trf_5763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5763(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5763(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5785)
static void C_fcall trf_5785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5785(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5785(t0,t1);}

C_noret_decl(trf_5808)
static void C_fcall trf_5808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5808(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5808(t0,t1,t2);}

C_noret_decl(trf_5580)
static void C_fcall trf_5580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5580(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5580(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5590)
static void C_fcall trf_5590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5590(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5590(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5636)
static void C_fcall trf_5636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5636(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5636(t0,t1);}

C_noret_decl(trf_5654)
static void C_fcall trf_5654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5654(t0,t1);}

C_noret_decl(trf_5320)
static void C_fcall trf_5320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5320(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5320(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5332)
static void C_fcall trf_5332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5332(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5332(t0,t1,t2,t3);}

C_noret_decl(trf_5355)
static void C_fcall trf_5355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5355(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5355(t0,t1);}

C_noret_decl(trf_4761)
static void C_fcall trf_4761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4761(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4761(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5251)
static void C_fcall trf_5251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5251(t0,t1);}

C_noret_decl(trf_5170)
static void C_fcall trf_5170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5170(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5170(t0,t1);}

C_noret_decl(trf_5124)
static void C_fcall trf_5124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5124(t0,t1);}

C_noret_decl(trf_5127)
static void C_fcall trf_5127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5127(t0,t1);}

C_noret_decl(trf_5087)
static void C_fcall trf_5087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5087(t0,t1);}

C_noret_decl(trf_5049)
static void C_fcall trf_5049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5049(t0,t1);}

C_noret_decl(trf_4983)
static void C_fcall trf_4983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4983(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4983(t0,t1);}

C_noret_decl(trf_4779)
static void C_fcall trf_4779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4779(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4779(t0,t1);}

C_noret_decl(trf_4791)
static void C_fcall trf_4791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4791(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4791(t0,t1);}

C_noret_decl(trf_4782)
static void C_fcall trf_4782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4782(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4782(t0,t1);}

C_noret_decl(trf_4727)
static void C_fcall trf_4727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4727(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4727(t0,t1,t2);}

C_noret_decl(trf_4687)
static void C_fcall trf_4687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4687(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4687(t0,t1,t2);}

C_noret_decl(trf_4706)
static void C_fcall trf_4706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4706(t0,t1);}

C_noret_decl(trf_4637)
static void C_fcall trf_4637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4637(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4637(t0,t1,t2);}

C_noret_decl(trf_4541)
static void C_fcall trf_4541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4541(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4541(t0,t1,t2);}

C_noret_decl(trf_4343)
static void C_fcall trf_4343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4343(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4343(t0,t1);}

C_noret_decl(trf_4445)
static void C_fcall trf_4445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4445(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4445(t0,t1);}

C_noret_decl(trf_4220)
static void C_fcall trf_4220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4220(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4220(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4280)
static void C_fcall trf_4280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4280(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4280(t0,t1);}

C_noret_decl(trf_4292)
static void C_fcall trf_4292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4292(t0,t1);}

C_noret_decl(trf_4041)
static void C_fcall trf_4041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4041(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4041(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4079)
static void C_fcall trf_4079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4079(t0,t1);}

C_noret_decl(trf_4096)
static void C_fcall trf_4096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4096(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4096(t0,t1,t2);}

C_noret_decl(trf_4115)
static void C_fcall trf_4115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4115(t0,t1);}

C_noret_decl(trf_4076)
static void C_fcall trf_4076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4076(t0,t1);}

C_noret_decl(trf_3992)
static void C_fcall trf_3992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3992(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3992(t0,t1,t2);}

C_noret_decl(trf_3821)
static void C_fcall trf_3821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3821(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3821(t0,t1);}

C_noret_decl(trf_3816)
static void C_fcall trf_3816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3816(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3816(t0,t1,t2);}

C_noret_decl(trf_3723)
static void C_fcall trf_3723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3723(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3723(t0,t1,t2,t3);}

C_noret_decl(trf_3745)
static void C_fcall trf_3745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3745(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3745(t0,t1);}

C_noret_decl(trf_3691)
static void C_fcall trf_3691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3691(t0,t1);}

C_noret_decl(trf_3642)
static void C_fcall trf_3642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3642(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3642(t0,t1,t2);}

C_noret_decl(trf_3652)
static void C_fcall trf_3652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3652(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3652(t0,t1);}

C_noret_decl(trf_3624)
static void C_fcall trf_3624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3624(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3624(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_expand_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("expand_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3794)){
C_save(t1);
C_rereclaim2(3794*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,401);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],12,"\003sysfeatures");
lf[4]=C_h_intern(&lf[4],2,"pp");
lf[5]=C_h_intern(&lf[5],5,"print");
lf[8]=C_h_intern(&lf[8],23,"\003syscurrent-environment");
lf[9]=C_h_intern(&lf[9],28,"\003syscurrent-meta-environment");
lf[11]=C_h_intern(&lf[11],7,"\003sysget");
lf[12]=C_h_intern(&lf[12],16,"\004coremacro-alias");
lf[14]=C_h_intern(&lf[14],7,"<macro>");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\011aliasing ");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\004 to ");
lf[17]=C_h_intern(&lf[17],8,"\003sysput!");
lf[18]=C_h_intern(&lf[18],6,"gensym");
lf[19]=C_h_intern(&lf[19],21,"\003sysqualified-symbol\077");
lf[21]=C_h_intern(&lf[21],7,"\003sysmap");
lf[22]=C_h_intern(&lf[22],16,"\003sysstrip-syntax");
lf[23]=C_h_intern(&lf[23],21,"\003sysalias-global-hook");
lf[24]=C_h_intern(&lf[24],3,"get");
lf[25]=C_h_intern(&lf[25],12,"list->vector");
lf[26]=C_h_intern(&lf[26],12,"vector->list");
lf[27]=C_h_intern(&lf[27],9,"\003syserror");
lf[28]=C_h_intern(&lf[28],12,"strip-syntax");
lf[29]=C_h_intern(&lf[29],21,"\003sysmacro-environment");
lf[30]=C_h_intern(&lf[30],29,"\003syschicken-macro-environment");
lf[31]=C_h_intern(&lf[31],33,"\003syschicken-ffi-macro-environment");
lf[32]=C_h_intern(&lf[32],28,"\003sysextend-macro-environment");
lf[33]=C_h_intern(&lf[33],14,"\003syscopy-macro");
lf[34]=C_h_intern(&lf[34],6,"macro\077");
lf[35]=C_h_intern(&lf[35],20,"\003sysunregister-macro");
lf[36]=C_h_intern(&lf[36],4,"caar");
lf[37]=C_h_intern(&lf[37],15,"undefine-macro!");
lf[38]=C_h_intern(&lf[38],12,"\003sysexpand-0");
lf[39]=C_h_intern(&lf[39],9,"\003sysabort");
lf[40]=C_h_intern(&lf[40],9,"condition");
lf[41]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[42]=C_h_intern(&lf[42],13,"string-append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[45]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[46]=C_h_intern(&lf[46],3,"exn");
lf[47]=C_h_intern(&lf[47],3,"-->");
lf[48]=C_h_intern(&lf[48],22,"with-exception-handler");
lf[49]=C_h_intern(&lf[49],30,"call-with-current-continuation");
lf[50]=C_h_intern(&lf[50],10,"\000STATIC-SE");
lf[51]=C_h_intern(&lf[51],10,"\003sysappend");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020invoking macro: ");
lf[53]=C_h_intern(&lf[53],21,"\003syssyntax-error-hook");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[55]=C_h_intern(&lf[55],7,"\000EXPAND");
lf[56]=C_h_intern(&lf[56],3,"\000SE");
lf[57]=C_h_intern(&lf[57],1,"_");
lf[58]=C_h_intern(&lf[58],3,"let");
lf[59]=C_h_intern(&lf[59],8,"\004corelet");
lf[60]=C_h_intern(&lf[60],16,"\004coreloop-lambda");
lf[61]=C_h_intern(&lf[61],11,"\004coreletrec");
lf[62]=C_h_intern(&lf[62],8,"\004coreapp");
lf[63]=C_h_intern(&lf[63],4,"cadr");
lf[64]=C_h_intern(&lf[64],16,"\003syscheck-syntax");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[66]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[67]=C_h_intern(&lf[67],10,"\003syssetter");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_h_intern(&lf[69],4,"set!");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],9,"\004coreset!");
lf[72]=C_h_intern(&lf[72],25,"\003sysenable-runtime-macros");
lf[73]=C_h_intern(&lf[73],17,"\003sysmodule-rename");
lf[74]=C_h_intern(&lf[74],18,"\003sysstring->symbol");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[77]=C_h_intern(&lf[77],22,"\003sysregister-undefined");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\025(ALIAS) global alias ");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[80]=C_h_intern(&lf[80],18,"\003syscurrent-module");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\023(ALIAS) primitive: ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\020(ALIAS) marked: ");
lf[83]=C_h_intern(&lf[83],14,"\004coreprimitive");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000 (ALIAS) in current environment: ");
lf[85]=C_h_intern(&lf[85],12,"\004corealiased");
lf[86]=C_h_intern(&lf[86],10,"\003sysexpand");
lf[87]=C_h_intern(&lf[87],6,"expand");
lf[88]=C_h_intern(&lf[88],25,"\003sysextended-lambda-list\077");
lf[89]=C_h_intern(&lf[89],6,"#!rest");
lf[90]=C_h_intern(&lf[90],10,"#!optional");
lf[91]=C_h_intern(&lf[91],5,"#!key");
lf[92]=C_h_intern(&lf[92],7,"reverse");
lf[93]=C_h_intern(&lf[93],31,"\003sysexpand-extended-lambda-list");
lf[94]=C_h_intern(&lf[94],5,"cadar");
lf[95]=C_h_intern(&lf[95],5,"quote");
lf[96]=C_h_intern(&lf[96],15,"\003sysget-keyword");
lf[97]=C_h_intern(&lf[97],11,"\004corelambda");
lf[98]=C_h_intern(&lf[98],15,"string->keyword");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[101]=C_h_intern(&lf[101],3,"tmp");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[110]=C_h_intern(&lf[110],14,"let-optionals*");
lf[111]=C_h_intern(&lf[111],13,"let-optionals");
lf[112]=C_h_intern(&lf[112],8,"optional");
lf[113]=C_h_intern(&lf[113],4,"let*");
lf[114]=C_h_intern(&lf[114],3,"map");
lf[115]=C_h_intern(&lf[115],21,"\003syscanonicalize-body");
lf[116]=C_h_intern(&lf[116],5,"begin");
lf[117]=C_h_intern(&lf[117],6,"define");
lf[118]=C_h_intern(&lf[118],13,"define-values");
lf[119]=C_h_intern(&lf[119],5,"\000BODY");
lf[120]=C_h_intern(&lf[120],20,"\003syscall-with-values");
lf[121]=C_h_intern(&lf[121],14,"\004coreundefined");
lf[122]=C_h_intern(&lf[122],3,"cdr");
lf[123]=C_h_intern(&lf[123],13,"letrec-syntax");
lf[124]=C_h_intern(&lf[124],13,"define-syntax");
lf[125]=C_h_intern(&lf[125],5,"cdadr");
lf[126]=C_h_intern(&lf[126],6,"lambda");
lf[127]=C_h_intern(&lf[127],5,"caadr");
lf[128]=C_h_intern(&lf[128],25,"\003sysexpand-curried-define");
lf[129]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[132]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-syntax\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[138]=C_h_intern(&lf[138],24,"\003sysline-number-database");
lf[139]=C_h_intern(&lf[139],24,"\003syssyntax-error-culprit");
lf[140]=C_h_intern(&lf[140],15,"\003syssignal-hook");
lf[141]=C_h_intern(&lf[141],13,"\000syntax-error");
lf[142]=C_h_intern(&lf[142],12,"syntax-error");
lf[143]=C_h_intern(&lf[143],15,"get-line-number");
lf[144]=C_h_intern(&lf[144],18,"\003syshash-table-ref");
lf[145]=C_h_intern(&lf[145],8,"keyword\077");
lf[146]=C_h_intern(&lf[146],14,"symbol->string");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[156]=C_h_intern(&lf[156],4,"pair");
lf[157]=C_h_intern(&lf[157],5,"pair\077");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[159]=C_h_intern(&lf[159],8,"variable");
lf[160]=C_h_intern(&lf[160],7,"symbol\077");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[162]=C_h_intern(&lf[162],6,"symbol");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[164]=C_h_intern(&lf[164],4,"list");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[166]=C_h_intern(&lf[166],6,"number");
lf[167]=C_h_intern(&lf[167],7,"number\077");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[169]=C_h_intern(&lf[169],6,"string");
lf[170]=C_h_intern(&lf[170],7,"string\077");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[172]=C_h_intern(&lf[172],11,"lambda-list");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[177]=C_h_intern(&lf[177],18,"\003syser-transformer");
lf[178]=C_h_intern(&lf[178],12,"\000RENAME/RENV");
lf[179]=C_h_intern(&lf[179],14,"\000RENAME/LOOKUP");
lf[180]=C_h_intern(&lf[180],20,"\000RENAME/LOOKUP/MACRO");
lf[181]=C_h_intern(&lf[181],7,"\000RENAME");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\016  (lookup/DSE ");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\005 --> ");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[186]=C_h_intern(&lf[186],8,"\000COMPARE");
lf[187]=C_h_intern(&lf[187],17,"\003sysexpand-import");
lf[188]=C_h_intern(&lf[188],17,"\003sysstring-append");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[190]=C_h_intern(&lf[190],18,"\003syssymbol->string");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid prefix");
lf[194]=C_h_intern(&lf[194],15,"\003sysfind-module");
lf[195]=C_h_intern(&lf[195],8,"\003sysload");
lf[196]=C_h_intern(&lf[196],16,"\003sysdynamic-wind");
lf[197]=C_h_intern(&lf[197],26,"\003sysmeta-macro-environment");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000$can not import from undefined module");
lf[199]=C_h_intern(&lf[199],18,"\003sysfind-extension");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\007.import");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[204]=C_h_intern(&lf[204],8,"\003syswarn");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\037renamed identifier not imported");
lf[206]=C_h_intern(&lf[206],12,"\003sysfor-each");
lf[207]=C_h_intern(&lf[207],8,"\003sysdelq");
lf[208]=C_h_intern(&lf[208],4,"cdar");
lf[209]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000");
lf[210]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[212]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000$re-importing already imported syntax");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\047re-importing already imported identfier");
lf[215]=C_h_intern(&lf[215],25,"\003sysmark-imported-symbols");
lf[216]=C_h_intern(&lf[216],2,"\000S");
lf[217]=C_h_intern(&lf[217],10,"<toplevel>");
lf[218]=C_h_intern(&lf[218],2,"\000V");
lf[219]=C_h_intern(&lf[219],7,"\000IMPORT");
lf[220]=C_h_intern(&lf[220],6,"module");
lf[221]=C_h_intern(&lf[221],14,"\003sysblock-set!");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[225]=C_h_intern(&lf[225],6,"prefix");
lf[226]=C_h_intern(&lf[226],6,"except");
lf[227]=C_h_intern(&lf[227],6,"rename");
lf[228]=C_h_intern(&lf[228],4,"only");
lf[229]=C_h_intern(&lf[229],29,"\003sysinitial-macro-environment");
lf[230]=C_h_intern(&lf[230],24,"\003sysprocess-syntax-rules");
lf[231]=C_h_intern(&lf[231],7,"\003syscar");
lf[232]=C_h_intern(&lf[232],7,"\003syscdr");
lf[233]=C_h_intern(&lf[233],11,"\003sysvector\077");
lf[234]=C_h_intern(&lf[234],17,"\003sysvector-length");
lf[235]=C_h_intern(&lf[235],14,"\003sysvector-ref");
lf[236]=C_h_intern(&lf[236],16,"\003sysvector->list");
lf[237]=C_h_intern(&lf[237],16,"\003syslist->vector");
lf[238]=C_h_intern(&lf[238],6,"\003sys>=");
lf[239]=C_h_intern(&lf[239],5,"\003sys=");
lf[240]=C_h_intern(&lf[240],5,"\003sys+");
lf[241]=C_h_intern(&lf[241],8,"\003syscons");
lf[242]=C_h_intern(&lf[242],7,"\003syseq\077");
lf[243]=C_h_intern(&lf[243],10,"\003sysequal\077");
lf[244]=C_h_intern(&lf[244],9,"\003syslist\077");
lf[245]=C_h_intern(&lf[245],9,"\003sysmap-n");
lf[246]=C_h_intern(&lf[246],9,"\003sysnull\077");
lf[247]=C_h_intern(&lf[247],9,"\003syspair\077");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\026ill-formed syntax rule");
lf[250]=C_h_intern(&lf[250],6,"syntax");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000,template dimension error (too few ellipses\077)");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\021too many ellipses");
lf[253]=C_h_intern(&lf[253],9,"\003sysapply");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000 segment matching not implemented");
lf[255]=C_h_intern(&lf[255],4,"temp");
lf[256]=C_h_intern(&lf[256],4,"tail");
lf[257]=C_h_intern(&lf[257],2,"or");
lf[258]=C_h_intern(&lf[258],4,"loop");
lf[259]=C_h_intern(&lf[259],1,"l");
lf[260]=C_h_intern(&lf[260],5,"input");
lf[261]=C_h_intern(&lf[261],4,"else");
lf[262]=C_h_intern(&lf[262],4,"cond");
lf[263]=C_h_intern(&lf[263],7,"compare");
lf[264]=C_h_intern(&lf[264],1,"i");
lf[265]=C_h_intern(&lf[265],3,"and");
lf[266]=C_h_intern(&lf[266],29,"\003sysdefault-macro-environment");
lf[272]=C_h_intern(&lf[272],26,"set-module-undefined-list!");
lf[273]=C_h_intern(&lf[273],21,"module-undefined-list");
lf[275]=C_h_intern(&lf[275],15,"\003sysmodule-name");
lf[276]=C_h_intern(&lf[276],18,"\003sysmodule-exports");
lf[278]=C_h_intern(&lf[278],16,"\003sysmodule-table");
lf[279]=C_h_intern(&lf[279],5,"error");
lf[280]=C_h_intern(&lf[280],6,"import");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\020module not found");
lf[282]=C_h_intern(&lf[282],28,"\003systoplevel-definition-hook");
lf[283]=C_h_intern(&lf[283],28,"\003sysregister-meta-expression");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\047redefinition of imported syntax binding");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000&redefinition of imported value binding");
lf[287]=C_h_intern(&lf[287],19,"\003sysregister-export");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\011defined: ");
lf[289]=C_h_intern(&lf[289],15,"\003sysfind-export");
lf[290]=C_h_intern(&lf[290],26,"\003sysregister-syntax-export");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\020defined syntax: ");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000!use of syntax precedes definition");
lf[293]=C_h_intern(&lf[293],19,"\003sysregister-module");
lf[294]=C_h_intern(&lf[294],8,"\000MARKING");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\014 in module `");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000!indirect export of syntax binding");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\033indirect reexport of syntax");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\042indirect export of unknown binding");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\024  merged has length ");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\010merging ");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\033 se\047s with total length of ");
lf[305]=C_h_intern(&lf[305],32,"\003syscompiled-module-registration");
lf[306]=C_h_intern(&lf[306],28,"\003sysregister-compiled-module");
lf[307]=C_h_intern(&lf[307],4,"cons");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\022re-exported syntax");
lf[309]=C_h_intern(&lf[309],4,"eval");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\0001can not find implementation of re-exported syntax");
lf[311]=C_h_intern(&lf[311],29,"\003sysregister-primitive-module");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\0001unknown macro referenced while registering module");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\002#%");
lf[314]=C_h_intern(&lf[314],18,"module-exists-list");
lf[315]=C_h_intern(&lf[315],19,"\003sysfinalize-module");
lf[316]=C_h_intern(&lf[316],6,"\000DLIST");
lf[317]=C_h_intern(&lf[317],7,"\000SDLIST");
lf[318]=C_h_intern(&lf[318],9,"\000IEXPORTS");
lf[319]=C_h_intern(&lf[319],9,"\000VEXPORTS");
lf[320]=C_h_intern(&lf[320],9,"\000SEXPORTS");
lf[321]=C_h_intern(&lf[321],8,"\000EXPORTS");
lf[322]=C_h_intern(&lf[322],6,"\000FIXUP");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000$(internal) indirect export not found");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\021module unresolved");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\033suggesting to add `(import ");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\016)\047 to module `");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[330]=C_h_intern(&lf[330],7,"\004coredb");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000(reference to possibly unbound identifier");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\015reexporting: ");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000 exported identifier for module `");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\026\047 has not been defined");
lf[336]=C_h_intern(&lf[336],16,"\003sysmacro-subset");
lf[337]=C_h_intern(&lf[337],14,"make-parameter");
lf[338]=C_h_intern(&lf[338],12,"syntax-rules");
lf[339]=C_h_intern(&lf[339],3,"...");
lf[340]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[341]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[342]=C_h_intern(&lf[342],6,"export");
lf[343]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000!`export\047 used outside module body");
lf[346]=C_h_intern(&lf[346],16,"begin-for-syntax");
lf[347]=C_h_intern(&lf[347],24,"\004coreelaborationtimeonly");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[349]=C_h_intern(&lf[349],11,"\004coremodule");
lf[350]=C_h_intern(&lf[350],1,"*");
lf[351]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[352]=C_h_intern(&lf[352],17,"require-extension");
lf[353]=C_h_intern(&lf[353],22,"\004corerequire-extension");
lf[354]=C_h_intern(&lf[354],15,"require-library");
lf[355]=C_h_intern(&lf[355],11,"cond-expand");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[357]=C_h_intern(&lf[357],12,"\003sysfeature\077");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[359]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[360]=C_h_intern(&lf[360],3,"not");
lf[361]=C_h_intern(&lf[361],5,"delay");
lf[362]=C_h_intern(&lf[362],16,"\003sysmake-promise");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[364]=C_h_intern(&lf[364],10,"quasiquote");
lf[365]=C_h_intern(&lf[365],8,"\003syslist");
lf[366]=C_h_intern(&lf[366],17,"%unquote-splicing");
lf[367]=C_h_intern(&lf[367],1,"a");
lf[368]=C_h_intern(&lf[368],1,"b");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[371]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[372]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[373]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[374]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[375]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[376]=C_h_intern(&lf[376],16,"unquote-splicing");
lf[377]=C_h_intern(&lf[377],7,"unquote");
lf[378]=C_h_intern(&lf[378],2,"do");
lf[379]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[380]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[381]=C_h_intern(&lf[381],2,"if");
lf[382]=C_h_intern(&lf[382],6,"doloop");
lf[383]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001"
"\000\000\000\001");
lf[384]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[385]=C_h_intern(&lf[385],4,"case");
lf[386]=C_h_intern(&lf[386],8,"\003syseqv\077");
lf[387]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[388]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[389]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[390]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[391]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[392]=C_h_intern(&lf[392],2,"=>");
lf[393]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[394]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[395]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[396]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[397]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[398]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[399]=C_h_intern(&lf[399],17,"import-for-syntax");
lf[400]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\020\000hygienic-macros\376\003\000\000\002\376\001\000\000\015\000syntax-rules\376\377\016");
C_register_lf2(lf,401,create_ptable());
t2=C_mutate(&lf[0] /* (set! c152 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3591,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 38   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),t3,lf[400],C_retrieve(lf[2]));}

/* k3589 */
static void C_ccall f_3591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3591,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! features ...) */,t1);
t3=C_mutate(&lf[3] /* (set! d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3593,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[6] /* (set! dd ...) */,C_retrieve2(lf[3],"d"));
t5=C_mutate(&lf[7] /* (set! dm ...) */,C_retrieve2(lf[3],"d"));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 69   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[337]))(3,*((C_word*)lf[337]+1),t6,C_SCHEME_END_OF_LIST);}

/* k3616 in k3589 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1 /* (set! current-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 70   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[337]))(3,*((C_word*)lf[337]+1),t3,C_SCHEME_END_OF_LIST);}

/* k3620 in k3616 in k3589 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3622,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* (set! current-meta-environment ...) */,t1);
t3=C_mutate(&lf[10] /* (set! lookup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3624,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[13] /* (set! macro-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3642,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[20] /* (set! map-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3691,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[22]+1 /* (set! strip-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[28]+1 /* (set! strip-syntax ...) */,C_retrieve(lf[22]));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3872,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 122  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[337]))(3,*((C_word*)lf[337]+1),t8,C_SCHEME_END_OF_LIST);}

/* k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3872,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! macro-environment ...) */,t1);
t3=C_set_block_item(lf[30] /* chicken-macro-environment */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[31] /* chicken-ffi-macro-environment */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[32]+1 /* (set! extend-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3876,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[33]+1 /* (set! copy-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3909,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[34]+1 /* (set! macro? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3922,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[35]+1 /* (set! unregister-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3978,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[37]+1 /* (set! undefine-macro! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4029,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[38]+1 /* (set! expand-0 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(lf[72] /* enable-runtime-macros */,0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[73]+1 /* (set! module-rename ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4520,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[23]+1 /* (set! alias-global-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4538,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[86]+1 /* (set! expand ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4628,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[87]+1 /* (set! expand ...) */,C_retrieve(lf[86]));
t16=C_mutate((C_word*)lf[88]+1 /* (set! extended-lambda-list? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4681,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[92]+1);
t18=C_retrieve(lf[18]);
t19=C_mutate((C_word*)lf[93]+1 /* (set! expand-extended-lambda-list ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4724,a[2]=t17,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[92]+1);
t21=*((C_word*)lf[114]+1);
t22=C_mutate((C_word*)lf[115]+1 /* (set! canonicalize-body ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5314,a[2]=t21,a[3]=t20,a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate(&lf[137] /* (set! match-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6067,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[128]+1 /* (set! expand-curried-define ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6150,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(lf[138] /* line-number-database */,0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[139] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
t27=C_mutate((C_word*)lf[53]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6220,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[142]+1 /* (set! syntax-error ...) */,C_retrieve(lf[53]));
t29=C_mutate((C_word*)lf[143]+1 /* (set! get-line-number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6231,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[42]+1);
t31=C_retrieve(lf[145]);
t32=C_retrieve(lf[143]);
t33=*((C_word*)lf[146]+1);
t34=C_mutate((C_word*)lf[64]+1 /* (set! check-syntax ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6267,a[2]=t31,a[3]=t32,a[4]=t33,a[5]=t30,a[6]=((C_word)li71),tmp=(C_word)a,a+=7,tmp));
t35=C_mutate((C_word*)lf[177]+1 /* (set! er-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6729,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[187]+1 /* (set! expand-import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7023,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13979,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13981,a[2]=((C_word)li206),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 870  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t38,t39);}

/* a13980 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13981,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
((C_proc9)C_retrieve_symbol_proc(lf[187]))(9,*((C_word*)lf[187]+1),t1,t2,t3,t4,C_retrieve(lf[8]),C_retrieve(lf[29]),C_SCHEME_FALSE,lf[280]);}

/* k13977 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 868  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[280],C_SCHEME_END_OF_LIST,t1);}

/* k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7871,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13969,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13971,a[2]=((C_word)li205),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 876  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13970 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13971,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
((C_proc9)C_retrieve_symbol_proc(lf[187]))(9,*((C_word*)lf[187]+1),t1,t2,t3,t4,C_retrieve(lf[9]),C_retrieve(lf[197]),C_SCHEME_TRUE,lf[399]);}

/* k13967 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 874  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[399],C_SCHEME_END_OF_LIST,t1);}

/* k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 880  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}

/* k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
t2=C_mutate((C_word*)lf[229]+1 /* (set! initial-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13827,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13829,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 885  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t4,t5);}

/* a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13829,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13839,a[2]=t3,a[3]=t7,a[4]=((C_word)li203),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_13839(t9,t1,t5);}

/* loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_13839(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13839,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13895,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 896  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t6,lf[117],t3,lf[394]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13908,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 900  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t6,lf[117],t3,lf[396]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13855,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 891  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[117],t3,lf[162]);}}

/* k13853 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 892  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,lf[117],((C_word*)t0)[4],lf[398]);}

/* k13856 in k13853 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13886,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 893  ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t3);}

/* k13884 in k13856 in k13853 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 893  ##sys#register-export */
((C_proc4)C_retrieve_symbol_proc(lf[287]))(4,*((C_word*)lf[287]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13859 in k13856 in k13853 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13861,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):lf[397]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k13906 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 901  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,lf[117],((C_word*)t0)[3],lf[395]);}

/* k13909 in k13906 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13957,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 902  ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t4);}

/* k13955 in k13909 in k13906 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 902  ##sys#register-export */
((C_proc4)C_retrieve_symbol_proc(lf[287]))(4,*((C_word*)lf[287]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13912 in k13909 in k13906 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13914,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 905  r */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k13935 in k13912 in k13909 in k13906 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13937,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13949,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13947 in k13935 in k13912 in k13909 in k13906 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13949,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k13893 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 897  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,lf[117],((C_word*)t0)[2],lf[393]);}

/* k13896 in k13893 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13905,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 898  ##sys#expand-curried-define */
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13903 in k13896 in k13893 in loop in a13828 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 898  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_13839(t2,((C_word*)t0)[2],t1);}

/* k13825 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 882  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[117],C_SCHEME_END_OF_LIST,t1);}

/* k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13768,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13770,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 910  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13769 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13770,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13799,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 919  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[381]);}}}

/* k13797 in a13769 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13819,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 919  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k13817 in k13797 in a13769 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13821 in k13817 in k13797 in a13769 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13823,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k13766 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 907  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[265],C_SCHEME_END_OF_LIST,t1);}

/* k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13678,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13680,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 924  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13679 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13680,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13705,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 933  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[101]);}}}

/* k13703 in a13679 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 934  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k13710 in k13703 in a13679 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13712,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 935  r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[381]);}

/* k13730 in k13710 in k13703 in a13679 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 935  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13750 in k13730 in k13710 in k13703 in a13679 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13756,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13754 in k13750 in k13730 in k13710 in k13703 in a13679 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13756,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k13676 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 921  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[257],C_SCHEME_END_OF_LIST,t1);}

/* k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13345,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13347,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 940  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13347,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13354,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 943  r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[116]);}

/* k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 944  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 945  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[381]);}

/* k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 946  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[392]);}

/* k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 947  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 948  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 949  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[126]);}

/* k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13372,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_13377,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word)li199),tmp=(C_word)a,a+=13,tmp));
t5=((C_word*)t3)[1];
f_13377(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_13377(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13377,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_13393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=((C_word*)t0)[11],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* expand.scm: 955  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[262],t3,lf[390]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[391]);}}

/* k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_13399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* expand.scm: 956  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k13397 in k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13399,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13406,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13435,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 957  expand */
t5=((C_word*)((C_word*)t0)[9])[1];
f_13377(t5,t4,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_13441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[11]);
/* expand.scm: 958  c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}}

/* k13439 in k13397 in k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13441,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13444,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 959  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13509,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[12]))){
t3=(C_word)C_i_length(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t3,C_fix(4));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* expand.scm: 965  c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,((C_word*)t0)[2],t5);}
else{
t5=t2;
f_13509(2,t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_13509(2,t3,C_SCHEME_FALSE);}}}

/* k13507 in k13439 in k13397 in k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13509,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13512,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 966  r */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13634,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k13632 in k13507 in k13439 in k13397 in k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13634,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13630,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 975  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_13377(t4,t3,((C_word*)t0)[2]);}

/* k13628 in k13632 in k13507 in k13439 in k13397 in k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13630,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k13510 in k13507 in k13439 in k13397 in k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13512,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t10=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[253],t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13567,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t9,a[7]=t13,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 972  expand */
t15=((C_word*)((C_word*)t0)[3])[1];
f_13377(t15,t14,((C_word*)t0)[2]);}

/* k13565 in k13510 in k13507 in k13439 in k13397 in k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13567,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[381],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[120],t10));}

/* k13442 in k13439 in k13397 in k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13444,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13483,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 963  expand */
t10=((C_word*)((C_word*)t0)[3])[1];
f_13377(t10,t9,((C_word*)t0)[2]);}

/* k13481 in k13442 in k13439 in k13397 in k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13483,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k13433 in k13397 in k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13435,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k13404 in k13397 in k13391 in expand in k13370 in k13367 in k13364 in k13361 in k13358 in k13355 in k13352 in a13346 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13406,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k13343 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 937  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[262],C_SCHEME_END_OF_LIST,t1);}

/* k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13175,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13177,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 980  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13177,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13181,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 982  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[385],t2,lf[389]);}

/* k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13181,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13190,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 985  r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[101]);}

/* k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 986  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 987  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[381]);}

/* k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 988  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 990  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k13200 in k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13202,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13221,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13223,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word)li197),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_13223(t9,t5,((C_word*)t0)[2]);}

/* expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_13223(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13223,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 997  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[385],t3,lf[387]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[388]);}}

/* k13237 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13245,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 998  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k13243 in k13237 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13245,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13252,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13295,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13299,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13301,a[2]=((C_word*)t0)[2],a[3]=((C_word)li196),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1000 ##sys#map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a13300 in k13243 in k13237 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13301,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[386],t6));}

/* k13297 in k13243 in k13237 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k13293 in k13243 in k13237 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13295,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13287,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k13285 in k13293 in k13243 in k13237 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13287,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13283,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1003 expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_13223(t4,t3,((C_word*)t0)[2]);}

/* k13281 in k13285 in k13293 in k13243 in k13237 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13283,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k13250 in k13243 in k13237 in expand in k13200 in k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13252,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k13219 in k13200 in k13197 in k13194 in k13191 in k13188 in k13179 in a13176 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13221,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[58],t3));}

/* k13173 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 977  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[385],C_SCHEME_END_OF_LIST,t1);}

/* k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13106,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13108,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1008 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13107 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13108,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13112,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1010 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[113],t2,lf[384]);}

/* k13110 in a13107 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13112,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13121,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1013 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[58]);}

/* k13119 in k13110 in a13107 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13121,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13126,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li194),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_13126(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k13119 in k13110 in a13107 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_13126(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_13126,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13144,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13163,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1017 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k13161 in expand in k13119 in k13110 in a13107 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13163,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k13142 in expand in k13119 in k13110 in a13107 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13144,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k13104 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1005 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[113],C_SCHEME_END_OF_LIST,t1);}

/* k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7896,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12924,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12926,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1022 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12926,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12930,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1024 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[378],t2,lf[383]);}

/* k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12930,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12942,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1028 r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[382]);}

/* k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1029 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1030 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[381]);}

/* k12946 in k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1031 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12949 in k12946 in k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13086,a[2]=((C_word)li192),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1032 ##sys#map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a13085 in k12949 in k12946 in k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13086(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13086,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k12964 in k12949 in k12946 in k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12966,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_12993(t6,lf[380]);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13084,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,C_SCHEME_END_OF_LIST);}}

/* k13082 in k12964 in k12949 in k12946 in k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13084,2,t0,t1);}
t2=((C_word*)t0)[3];
f_12993(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12991 in k12964 in k12949 in k12946 in k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_12993(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12993,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_13009(t4,lf[379]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13074,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k13072 in k12991 in k12964 in k12949 in k12946 in k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13074,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_13009(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k13007 in k12991 in k12964 in k12949 in k12946 in k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_13009(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13009,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13029,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13031,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1043 ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a13030 in k13007 in k12991 in k12964 in k12949 in k12946 in k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13031,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_car(t2));}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t7));}}

/* k13027 in k13007 in k12991 in k12964 in k12949 in k12946 in k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k13023 in k13007 in k12991 in k12964 in k12949 in k12946 in k12943 in k12940 in k12928 in a12925 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_13025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13025,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[62],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k12922 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1019 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[378],C_SCHEME_END_OF_LIST,t1);}

/* k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7899,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12529,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12531,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1052 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12531,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12535,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1054 r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[95]);}

/* k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1055 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[364]);}

/* k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1056 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[377]);}

/* k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1057 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[376]);}

/* k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12544,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12546,a[2]=t5,a[3]=t7,a[4]=((C_word)li187),tmp=(C_word)a,a+=5,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12556,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word)li188),tmp=(C_word)a,a+=9,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12825,a[2]=t7,a[3]=((C_word)li189),tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12913,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1107 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t11,lf[364],((C_word*)t0)[3],lf[375]);}

/* k12911 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1108 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12546(t3,((C_word*)t0)[2],t2,C_fix(0));}

/* simplify in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_12825(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12825,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12829,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1095 match-expression */
f_6067(t3,t2,lf[373],lf[374]);}

/* k12827 in simplify in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12829,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[367],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[365],t4);
/* expand.scm: 1096 simplify */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12825(t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1097 match-expression */
f_6067(t2,((C_word*)t0)[2],lf[371],lf[372]);}}

/* k12852 in k12827 in simplify in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12854,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[368],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_i_assq(lf[367],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1104 match-expression */
f_6067(t2,((C_word*)t0)[2],lf[369],lf[370]);}}

/* k12898 in k12852 in k12827 in simplify in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[367],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k12883 in k12852 in k12827 in simplify in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12885,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[365],t2);
/* expand.scm: 1101 simplify */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12825(t4,((C_word*)t0)[2],t3);}

/* walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_12556(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12556,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12574,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12578,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1061 vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t5,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=t3,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1066 c */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t4);}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4));}}}

/* k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12603,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12629,a[2]=t5,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
/* expand.scm: 1072 walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_12546(t8,t6,t2,t7);}}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2));}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1074 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k12648 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12650,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12675,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1077 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_12546(t7,t4,t5,t6);}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12698,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1079 walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_12546(t4,t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12797,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1083 c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12811,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1093 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_12546(t3,t2,((C_word*)t0)[4],((C_word*)t0)[6]);}}}

/* k12809 in k12648 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12819,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1093 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12546(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12817 in k12809 in k12648 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12819,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12795 in k12648 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12797,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12740,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1087 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12546(t6,t5,((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12771,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1089 walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_12546(t7,t5,t3,t6);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12786,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1091 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_12546(t4,t3,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* k12784 in k12795 in k12648 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12794,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1091 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12546(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12792 in k12784 in k12795 in k12648 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12794,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12769 in k12795 in k12648 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12771,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[366],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[365],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12759,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1090 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12546(t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12757 in k12769 in k12795 in k12648 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12759,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12738 in k12795 in k12648 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12740,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[51],t3));}

/* k12696 in k12648 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12698,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[241],((C_word*)t0)[2],t1));}

/* k12673 in k12648 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12675,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[365],t3));}

/* k12627 in k12601 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12629,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[365],((C_word*)t0)[2],t1));}

/* k12576 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1061 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12546(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12572 in walk1 in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12574,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[237],t2));}

/* walk in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_12546(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12546,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12554,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1058 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12556(t5,t4,t2,t3);}

/* k12552 in walk in k12542 in k12539 in k12536 in k12533 in a12530 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1058 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12825(t2,((C_word*)t0)[2],t1);}

/* k12527 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1049 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[364],C_SCHEME_END_OF_LIST,t1);}

/* k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7902,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12496,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12498,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1113 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12497 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12498,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12502,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1115 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[361],t2,lf[363]);}

/* k12500 in a12497 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12502,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[126],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[362],t6));}

/* k12494 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1110 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[361],C_SCHEME_END_OF_LIST,t1);}

/* k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12212,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12214,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1121 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12214,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12221,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1124 r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1125 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[360]);}

/* k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1126 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1127 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1128 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12235,a[2]=((C_word*)t0)[8],a[3]=((C_word)li181),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12245,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=t4,a[7]=t1,a[8]=((C_word)li182),tmp=(C_word)a,a+=9,tmp));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12395,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=((C_word)li184),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_12395(t9,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* expand in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_12395(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12395,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12409,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12411,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12448,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1165 c */
t8=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t6,((C_word*)t0)[3]);}
else{
/* expand.scm: 1163 err */
t6=((C_word*)t0)[2];
f_12235(t6,t1,t4);}}
else{
/* expand.scm: 1158 err */
t4=((C_word*)t0)[2];
f_12235(t4,t1,t2);}}}

/* k12446 in expand in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12448,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[359]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12464,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12470,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1170 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12245(t3,t2,((C_word*)t0)[2]);}}

/* k12468 in k12446 in expand in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12470,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12477,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
/* expand.scm: 1171 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12395(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k12475 in k12468 in k12446 in expand in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12477,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12462 in k12446 in expand in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12464,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a12410 in expand in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12411,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k12407 in expand in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[27]+1),lf[358],t1);}

/* test in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_12245(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12245,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 1134 ##sys#feature? */
((C_proc3)C_retrieve_symbol_proc(lf[357]))(3,*((C_word*)lf[357]+1),t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12276,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1139 c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],t3);}
else{
/* expand.scm: 1135 err */
t3=((C_word*)t0)[5];
f_12235(t3,t1,t2);}}}

/* k12274 in test in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12276,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12294,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[11]);
/* expand.scm: 1142 test */
t5=((C_word*)((C_word*)t0)[8])[1];
f_12245(t5,t3,t4);}
else{
/* expand.scm: 1144 err */
t3=((C_word*)t0)[7];
f_12235(t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1145 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k12320 in k12274 in test in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12322,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12337,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 1148 test */
t5=((C_word*)((C_word*)t0)[7])[1];
f_12245(t5,t3,t4);}
else{
/* expand.scm: 1150 err */
t3=((C_word*)t0)[6];
f_12235(t3,((C_word*)t0)[9],((C_word*)t0)[5]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12372,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1151 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k12370 in k12320 in k12274 in test in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12372,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12379,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1151 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12245(t4,t2,t3);}
else{
/* expand.scm: 1152 err */
t2=((C_word*)t0)[2];
f_12235(t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k12377 in k12370 in k12320 in k12274 in test in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k12335 in k12320 in k12274 in test in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12337,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12351,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k12349 in k12335 in k12320 in k12274 in test in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12351,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1149 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12245(t3,((C_word*)t0)[2],t2);}

/* k12292 in k12274 in test in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12294,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12305,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12303 in k12292 in k12274 in test in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12305,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1143 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12245(t3,((C_word*)t0)[2],t2);}

/* err in k12231 in k12228 in k12225 in k12222 in k12219 in a12213 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_12235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12235,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[355],((C_word*)t0)[2]);
/* expand.scm: 1130 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[356],t2,t3);}

/* k12210 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1118 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[355],C_SCHEME_END_OF_LIST,t1);}

/* k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12191,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12193,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1176 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12192 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12193,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[353],t7));}

/* k12189 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1173 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[354],C_SCHEME_END_OF_LIST,t1);}

/* k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12170,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12172,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1184 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12171 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12172,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[353],t7));}

/* k12168 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1181 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[352],C_SCHEME_END_OF_LIST,t1);}

/* k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7914,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12119,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12121,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1192 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12120 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12121,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12125,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1194 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[220],t2,lf[351]);}

/* k12123 in a12120 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12125,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12155,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12162,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1197 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[350]);}

/* k12160 in k12123 in a12120 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* expand.scm: 1197 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k12153 in k12123 in a12120 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12155,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_TRUE:(C_word)C_i_caddr(((C_word*)t0)[4]));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k12146 in k12153 in k12123 in a12120 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12148,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[349],t3));}

/* k12117 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1189 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[220],C_SCHEME_END_OF_LIST,t1);}

/* k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12065,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12067,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1205 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12066 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12067,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12071,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1207 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[346],t2,lf[348]);}

/* k12069 in a12066 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1208 ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t2);}

/* k12072 in k12069 in a12066 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12111,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_12077(2,t3,C_SCHEME_FALSE);}}

/* k12109 in k12072 in k12069 in a12066 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12111,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[116],t1);
/* expand.scm: 1209 ##sys#register-meta-expression */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),((C_word*)t0)[2],t2);}

/* k12075 in k12072 in k12069 in a12066 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12092,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1210 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12090 in k12075 in k12072 in k12069 in a12066 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12096,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k12094 in k12090 in k12075 in k12072 in k12069 in a12066 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12096,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[347],t3));}

/* k12063 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1202 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[346],C_SCHEME_END_OF_LIST,t1);}

/* k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11962,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11964,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1215 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a11963 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11964,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11971,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1218 ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t6);}

/* k11969 in a11963 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11974,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_11974(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1220 syntax-error */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),t2,lf[342],lf[345]);}}

/* k11972 in k11969 in a11963 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11994,a[2]=((C_word*)t0)[3],a[3]=((C_word)li175),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11993 in k11972 in k11969 in a11963 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11994(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11994,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12001,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t3;
f_12001(t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12016,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
t5=t3;
f_12001(t5,f_12016(t2));}}

/* loop in a11993 in k11972 in k11969 in a11963 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_12016(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_TRUE);}}
else{
return(C_SCHEME_TRUE);}}}

/* k11999 in a11993 in k11972 in k11969 in a11963 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_12001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12001,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1229 module-name */
t3=C_retrieve2(lf[76],"module-name");
f_9590(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k12006 in k11999 in a11993 in k11972 in k11969 in a11963 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_12008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1229 syntax-error */
((C_proc6)C_retrieve_symbol_proc(lf[142]))(6,*((C_word*)lf[142]+1),((C_word*)t0)[3],lf[342],lf[344],((C_word*)t0)[2],t1);}

/* k11975 in k11972 in k11969 in a11963 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11980,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11984,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=f_9608(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11992,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[22]),((C_word*)t0)[2]);}

/* k11990 in k11975 in k11972 in k11969 in a11963 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1233 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11982 in k11975 in k11972 in k11969 in a11963 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(2),t1);}

/* k11978 in k11975 in k11972 in k11969 in a11963 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[343]);}

/* k11960 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1212 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[342],C_SCHEME_END_OF_LIST,t1);}

/* k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7923,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11925,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11927,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a11926 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11927,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11931,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[338],t2,lf[341]);}

/* k11929 in a11926 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11931,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[5]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=lf[339];
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t7,a[6]=t9,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t4)[1]))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11949,a[2]=t10,a[3]=t7,a[4]=t4,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t11,lf[338],((C_word*)t0)[5],lf[340]);}
else{
t11=t10;
f_11940(t11,C_SCHEME_UNDEFINED);}}

/* k11947 in k11929 in a11926 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_11940(t7,t6);}

/* k11938 in k11929 in a11926 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_11940(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#process-syntax-rules */
((C_proc7)C_retrieve_symbol_proc(lf[230]))(7,*((C_word*)lf[230]+1),((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11923 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[338],C_SCHEME_END_OF_LIST,t1);}

/* k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7923,2,t0,t1);}
t2=C_mutate((C_word*)lf[230]+1 /* (set! process-syntax-rules ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7925,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9568,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1245 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t3);}

/* k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9568,2,t0,t1);}
t2=C_mutate((C_word*)lf[266]+1 /* (set! default-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9572,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11921,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1250 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}

/* k11919 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1250 make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[337]))(3,*((C_word*)lf[337]+1),((C_word*)t0)[2],t1);}

/* k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9572,2,t0,t1);}
t2=C_mutate((C_word*)lf[197]+1 /* (set! meta-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1251 make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[337]))(3,*((C_word*)lf[337]+1),t3,C_SCHEME_FALSE);}

/* k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9576,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! current-module ...) */,t1);
t3=C_mutate(&lf[76] /* (set! module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9590,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[267] /* (set! module-export-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9608,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[268] /* (set! set-module-defined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9617,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[269] /* (set! module-defined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9626,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[270] /* (set! module-exist-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9644,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[271] /* (set! module-defined-syntax-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9662,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[272]+1 /* (set! set-module-undefined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9671,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[273]+1 /* (set! module-undefined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9680,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[223] /* (set! module-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9698,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[222] /* (set! module-meta-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9716,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[274] /* (set! module-meta-expressions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9734,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[192] /* (set! module-vexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9752,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[193] /* (set! module-sexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9770,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[275]+1 /* (set! module-name ...) */,C_retrieve2(lf[76],"module-name"));
t17=C_mutate((C_word*)lf[276]+1 /* (set! module-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9780,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate(&lf[277] /* (set! make-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9798,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[194]+1 /* (set! find-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9804,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[282]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9844,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[283]+1 /* (set! register-meta-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9847,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate(&lf[284] /* (set! check-for-redef ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9867,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[287]+1 /* (set! register-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9888,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[290]+1 /* (set! register-syntax-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9977,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[77]+1 /* (set! register-undefined ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10058,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[293]+1 /* (set! register-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10080,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[215]+1 /* (set! mark-imported-symbols ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10148,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate(&lf[295] /* (set! module-indirect-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10207,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate(&lf[301] /* (set! merge-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10483,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[305]+1 /* (set! compiled-module-registration ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10555,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[306]+1 /* (set! register-compiled-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10949,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[311]+1 /* (set! register-primitive-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11157,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[289]+1 /* (set! find-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11248,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[315]+1 /* (set! finalize-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11333,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(lf[278] /* module-table */,0,C_SCHEME_END_OF_LIST);
t36=C_mutate((C_word*)lf[336]+1 /* (set! macro-subset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11879,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t37=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t37+1)))(2,t37,C_SCHEME_UNDEFINED);}

/* ##sys#macro-subset in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11879,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11887,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1645 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t3);}

/* k11885 in ##sys#macro-subset in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11887,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11889,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li171),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11889(t5,((C_word*)t0)[2],t1);}

/* loop in k11885 in ##sys#macro-subset in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_11889(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11889,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,((C_word*)t0)[3]));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11910,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1648 loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* k11908 in loop in k11885 in ##sys#macro-subset in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11910,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11333,3,t0,t1,t2);}
t3=f_9608(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11340,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1544 module-name */
t5=C_retrieve2(lf[76],"module-name");
f_9590(3,t5,t4,t2);}

/* k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11340,2,t0,t1);}
t2=f_9626(((C_word*)t0)[4]);
t3=f_9644(((C_word*)t0)[4]);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11349,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11860,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
t8=f_9662(((C_word*)t0)[4]);
/* map */
t9=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}

/* a11859 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11860(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11860,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11872,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1548 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}

/* k11870 in a11859 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_11352(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11817,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1553 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}}

/* k11815 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11817,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11819,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li168),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11819(t5,((C_word*)t0)[2],t1);}

/* loop in k11815 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_11819(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11819,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11832,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11858,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1555 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,t2);}}

/* k11856 in loop in k11815 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1555 ##sys#find-export */
((C_proc5)C_retrieve_symbol_proc(lf[289]))(5,*((C_word*)lf[289]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11830 in loop in k11815 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11832,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11843,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1556 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11819(t5,t3,t4);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1557 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11819(t3,((C_word*)t0)[3],t2);}}

/* k11841 in k11830 in loop in k11815 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11843,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[3]:((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11686,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t6,a[6]=t1,a[7]=((C_word)li167),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_11686(t8,t2,t4);}

/* loop in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_11686(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11686,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?t3:(C_word)C_i_car(t3));
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[6]))){
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1565 loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}
else{
t6=(C_word)C_i_assq(t5,((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11734,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t6,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_cdr(t6);
t10=t8;
f_11737(t10,(C_word)C_i_symbolp(t9));}
else{
t9=t8;
f_11737(t9,C_SCHEME_FALSE);}}}}

/* k11735 in loop in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_11737(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11737,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_11734(2,t2,(C_word)C_i_cdr(((C_word*)t0)[5]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1572 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t2);}}

/* k11789 in k11735 in loop in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11791,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_11749(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_11749(t4,C_SCHEME_FALSE);}}

/* k11747 in k11789 in k11735 in loop in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_11749(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11749,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11752,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* expand.scm: 1574 dm */
((C_proc6)C_retrieve2_symbol_proc(lf[7],"dm"))(6,lf[7],t2,lf[332],((C_word*)t0)[5],lf[333],t3);}
else{
if(C_truep(((C_word*)t0)[4])){
/* expand.scm: 1585 ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11769,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11773,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11777,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1581 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t5,((C_word*)t0)[3]);}}}

/* k11775 in k11747 in k11789 in k11735 in loop in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1579 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[334],t1,lf[335]);}

/* k11771 in k11747 in k11789 in k11735 in loop in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1578 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11767 in k11747 in k11789 in k11735 in loop in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_11734(2,t2,C_SCHEME_FALSE);}

/* k11750 in k11747 in k11789 in k11735 in loop in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_11734(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* k11732 in loop in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11734,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11723,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1586 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11686(t5,t3,t4);}

/* k11721 in k11732 in loop in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11723,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11355,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11408,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11632,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word)li166),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11680,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1604 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[273]))(3,*((C_word*)lf[273]+1),t6,((C_word*)t0)[8]);}

/* k11678 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11631 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11632,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11643,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1599 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),t4,lf[331],t2);}}

/* k11641 in a11631 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11646,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1600 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t2,((C_word*)t0)[2],lf[330]);}

/* k11644 in k11641 in a11631 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11646,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t4,C_fix(2));
if(C_truep(t5)){
t6=(C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]);
t7=t3;
f_11658(t7,(C_word)C_i_not(t6));}
else{
t6=t3;
f_11658(t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11656 in k11644 in k11641 in a11631 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_11658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11658,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11622,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11626,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)((C_word*)t0)[2])[1];
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11365,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_car(t5);
/* expand.scm: 1590 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t6,t7);}
else{
t3=t2;
f_11411(2,t3,C_SCHEME_UNDEFINED);}}

/* k11363 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11369,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11375,a[2]=t5,a[3]=((C_word)li165),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_11375(t7,t2,t3);}

/* loop in k11363 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_11375(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11375,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[328]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11389,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* expand.scm: 1594 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t3,t4);}}

/* k11387 in loop in k11363 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11393,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1594 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_11375(t4,t2,t3);}

/* k11391 in k11387 in loop in k11363 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1594 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),((C_word*)t0)[3],lf[329],((C_word*)t0)[2],t1);}

/* k11367 in k11363 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1589 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11624 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11630,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1611 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t2,((C_word*)t0)[2]);}

/* k11628 in k11624 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1607 string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[42]+1)))(7,*((C_word*)lf[42]+1),((C_word*)t0)[3],lf[325],((C_word*)t0)[2],lf[326],t1,lf[327]);}

/* k11620 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1606 ##sys#warn */
((C_proc3)C_retrieve_symbol_proc(lf[204]))(3,*((C_word*)lf[204]+1),((C_word*)t0)[2],t1);}

/* k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11414,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
/* expand.scm: 1614 ##sys#error */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[324],((C_word*)t0)[2]);}
else{
t3=t2;
f_11414(2,t3,C_SCHEME_UNDEFINED);}}

/* k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11573,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11609,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1620 module-indirect-exports */
f_10207(t4,((C_word*)t0)[6]);}

/* k11607 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11572 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11573,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11601,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1618 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t5);}}

/* k11599 in a11572 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 1619 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],lf[323],t3);}}

/* k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11567,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1622 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t3);}

/* k11565 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11571,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1623 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t2);}

/* k11569 in k11565 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11571,2,t0,t1);}
/* expand.scm: 1621 merge-se */
f_10483(((C_word*)t0)[4],(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11423,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 1625 ##sys#mark-imported-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),t2,((C_word*)t0)[4]);}

/* k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11426,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11525,a[2]=((C_word*)t0)[2],a[3]=((C_word)li163),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a11524 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11525,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11529,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(t2);
/* expand.scm: 1628 merge-se */
f_10483(t3,(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[2]));}

/* k11527 in a11524 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11532,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11555,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11559,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1629 map-se */
f_3691(t5,t1);}

/* k11557 in k11527 in a11524 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11553 in k11527 in a11524 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11555,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[322],t2);
/* expand.scm: 1629 dm */
((C_proc3)C_retrieve2_symbol_proc(lf[7],"dm"))(3,lf[7],((C_word*)t0)[2],t3);}

/* k11530 in k11527 in a11524 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_car(t2,((C_word*)t0)[2]));}

/* k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11429,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1633 module-name */
t4=C_retrieve2(lf[76],"module-name");
f_9590(3,t4,t3,((C_word*)t0)[7]);}

/* k11445 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11523,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k11521 in k11445 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11523,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[316],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11519,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1635 map-se */
f_3691(t4,((C_word*)t0)[2]);}

/* k11517 in k11521 in k11445 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11513 in k11521 in k11445 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11515,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[317],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11511,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1636 map-se */
f_3691(t4,((C_word*)t0)[2]);}

/* k11509 in k11513 in k11521 in k11445 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11505 in k11513 in k11521 in k11445 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11507,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[318],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11499,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11503,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1637 map-se */
f_3691(t4,((C_word*)t0)[2]);}

/* k11501 in k11505 in k11513 in k11521 in k11445 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11497 in k11505 in k11513 in k11521 in k11445 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11499,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[319],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11495,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1638 map-se */
f_3691(t4,((C_word*)t0)[2]);}

/* k11493 in k11497 in k11505 in k11513 in k11521 in k11445 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11489 in k11497 in k11505 in k11513 in k11521 in k11445 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11491,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[320],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[321],t8);
/* expand.scm: 1632 dm */
((C_proc3)C_retrieve2_symbol_proc(lf[7],"dm"))(3,lf[7],((C_word*)t0)[2],t9);}

/* k11427 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(10),t4);}

/* k11430 in k11427 in k11424 in k11421 in k11418 in k11415 in k11412 in k11409 in k11406 in k11353 in k11350 in k11347 in k11338 in ##sys#finalize-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(11),t4);}

/* ##sys#find-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11248,5,t0,t1,t2,t3,t4);}
t5=f_9608(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11259,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t5);
if(C_truep(t7)){
/* expand.scm: 1533 module-exists-list */
((C_proc3)C_retrieve_symbol_proc(lf[314]))(3,*((C_word*)lf[314]+1),t6,t3);}
else{
t8=t6;
f_11259(2,t8,t5);}}

/* k11257 in ##sys#find-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11259,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11261,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li161),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_11261(t5,((C_word*)t0)[2],t1);}

/* loop in k11257 in ##sys#find-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_11261(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11261,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1537 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t6,t2);}
else{
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1540 loop */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}}

/* k11308 in loop in k11257 in ##sys#find-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11310,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11289,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11306,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1538 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t4,((C_word*)t0)[4]);}
else{
t4=t3;
f_11289(t4,C_SCHEME_FALSE);}}}

/* k11304 in k11308 in loop in k11257 in ##sys#find-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_11289(t2,(C_word)C_i_memq(((C_word*)t0)[2],t1));}

/* k11287 in k11308 in loop in k11257 in ##sys#find-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_11289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1539 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11261(t3,((C_word*)t0)[4],t2);}}

/* ##sys#register-primitive-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11157r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11157r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11157r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11161,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11161(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11161(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11159 in ##sys#register-primitive-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11164,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1510 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}

/* k11162 in k11159 in ##sys#register-primitive-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11179,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11203,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11202 in k11162 in k11159 in ##sys#register-primitive-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11203,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11213,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11223,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 1517 ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[188]))(4,*((C_word*)lf[188]+1),t4,lf[313],t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11221 in a11202 in k11162 in k11159 in ##sys#register-primitive-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1516 ##sys#string->symbol */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),((C_word*)t0)[2],t1);}

/* k11211 in a11202 in k11162 in k11159 in ##sys#register-primitive-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11216,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1518 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[17]))(5,*((C_word*)lf[17]+1),t2,t1,lf[83],((C_word*)t0)[2]);}

/* k11214 in k11211 in a11202 in k11162 in k11159 in ##sys#register-primitive-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11216,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k11177 in k11162 in k11159 in ##sys#register-primitive-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11183,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11185,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word)li158),tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11184 in k11177 in k11162 in k11159 in ##sys#register-primitive-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11185,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* expand.scm: 1525 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[312],t2,((C_word*)t0)[2]);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11181 in k11177 in k11162 in k11159 in ##sys#register-primitive-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11183,2,t0,t1);}
t2=f_9798(C_a_i(&a,13),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve(lf[278]));
t5=C_mutate((C_word*)lf[278]+1 /* (set! module-table ...) */,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_10949r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_10949r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_10949r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10953,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t7;
f_10953(2,t8,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_i_cdr(t6);
if(C_truep((C_word)C_i_nullp(t8))){
t9=t7;
f_10953(2,t9,(C_word)C_i_car(t6));}
else{
/* ##sys#error */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}

/* k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10979,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11111,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11110 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11111,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10976,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1465 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t5);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11132,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 1475 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t4,t5);}}

/* k11130 in a11110 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11132,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10974 in a11110 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* expand.scm: 1468 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],lf[280],lf[310],((C_word*)t0)[3]);}}

/* k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11079,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11078 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11079,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11101,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_caddr(t2);
/* expand.scm: 1480 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t6,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k11099 in a11078 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11101,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10985,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11061,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11060 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11061(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11061,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11073,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 1485 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t4,t5);}

/* k11071 in a11060 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11073,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10983 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10985,2,t0,t1);}
t2=f_9798(C_a_i(&a,13),((C_word*)t0)[6],C_SCHEME_END_OF_LIST,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10991,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11055,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1489 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}

/* k11053 in k10983 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1490 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t2);}

/* k11057 in k11053 in k10983 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11059,2,t0,t1);}
/* expand.scm: 1488 merge-se */
f_10483(((C_word*)t0)[7],(C_word)C_a_i_list(&a,6,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10989 in k10983 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1492 ##sys#mark-imported-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),t2,((C_word*)t0)[3]);}

/* k10992 in k10989 in k10983 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10997,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11043,a[2]=((C_word*)t0)[5],a[3]=((C_word)li153),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11042 in k10992 in k10989 in k10983 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11043,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}

/* k10995 in k10992 in k10989 in k10983 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11023,a[2]=((C_word*)t0)[4],a[3]=((C_word)li152),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11022 in k10995 in k10992 in k10989 in k10983 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11023,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_set_car(t4,((C_word*)t0)[2]));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k10998 in k10995 in k10992 in k10989 in k10983 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11003,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11013,a[2]=((C_word*)t0)[3],a[3]=((C_word)li151),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11012 in k10998 in k10995 in k10992 in k10989 in k10983 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11013,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}

/* k11001 in k10998 in k10995 in k10992 in k10989 in k10983 in k10980 in k10977 in k10951 in ##sys#register-compiled-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_11003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11003,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[278]));
t4=C_mutate((C_word*)lf[278]+1 /* (set! module-table ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10555,3,t0,t1,t2);}
t3=f_9626(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10562,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1425 module-name */
t5=C_retrieve2(lf[76],"module-name");
f_9590(3,t5,t4,t2);}

/* k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10562,2,t0,t1);}
t2=f_9698(((C_word*)t0)[4]);
t3=f_9770(((C_word*)t0)[4]);
t4=f_9716(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10578,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10947,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,C_SCHEME_END_OF_LIST);}
else{
t6=t5;
f_10578(t6,C_SCHEME_END_OF_LIST);}}

/* k10945 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10947,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[280],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[309],t5);
t7=((C_word*)t0)[2];
f_10578(t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_10578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10578,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10582,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10917,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_10586(t4,C_SCHEME_END_OF_LIST);}}

/* k10915 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10917,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[280],t1);
t3=((C_word*)t0)[2];
f_10586(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_10586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10586,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10590,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10899,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=f_9734(((C_word*)t0)[5]);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[22]),t5);}

/* k10897 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1431 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[92]+1)))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t1);}

/* k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1433 module-name */
t3=C_retrieve2(lf[76],"module-name");
f_9590(3,t3,t2,((C_word*)t0)[6]);}

/* k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10895,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10812,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10814,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10887,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1439 module-indirect-exports */
f_10207(t7,((C_word*)t0)[7]);}

/* k10885 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10813 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10814,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[95],t7));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[95],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[95],t7);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[164],t12));}}

/* k10810 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10808,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=f_9752(((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[95],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10736,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10740,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li148),tmp=(C_word)a,a+=5,tmp);
/* map */
t9=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[4]);}

/* a10741 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10742,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(t3,((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[95],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10774,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(t4);
/* expand.scm: 1446 ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),t8,t9);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10789,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1448 dm */
((C_proc5)C_retrieve2_symbol_proc(lf[7],"dm"))(5,lf[7],t5,lf[308],t3,((C_word*)t0)[2]);}}

/* k10787 in a10741 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10789,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[95],t2));}

/* k10772 in a10741 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10774,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[307],t3));}

/* k10738 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10734 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10736,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10646,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10650,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t5=t4;
f_10650(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=f_9662(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10662,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=((C_word)li147),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_10662(t9,t4,t5);}}

/* loop in k10734 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_10662(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10662,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10732,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1456 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,t2);}}

/* k10730 in loop in k10734 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10732,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,((C_word*)t0)[5]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1456 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10662(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1458 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[4]);}}

/* k10683 in k10730 in loop in k10734 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1459 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[3]);}

/* k10726 in k10683 in k10730 in loop in k10734 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10728,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10720,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1459 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t5,((C_word*)t0)[3]);}

/* k10718 in k10726 in k10683 in k10730 in loop in k10734 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1459 ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[2],t1);}

/* k10714 in k10726 in k10683 in k10730 in loop in k10734 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10716,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[307],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10696,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1460 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_10662(t7,t5,t6);}

/* k10694 in k10714 in k10726 in k10683 in k10730 in loop in k10734 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10696,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10648 in k10734 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10644 in k10734 in k10806 in k10893 in k10592 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10646,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[306],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t10=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,((C_word*)t0)[3],((C_word*)t0)[2],t9);}

/* k10588 in k10584 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10580 in k10576 in k10560 in ##sys#compiled-module-registration in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* merge-se in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_10483(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10483,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10487,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,*((C_word*)lf[68]+1),t2);}

/* k10485 in merge-se in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10490,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
/* expand.scm: 1414 dm */
((C_proc6)C_retrieve2_symbol_proc(lf[7],"dm"))(6,lf[7],t2,lf[303],t3,lf[304],t4);}

/* k10488 in k10485 in merge-se in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10493,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10502,a[2]=t4,a[3]=((C_word)li145),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10502(t6,t2,((C_word*)t0)[2]);}

/* loop in k10488 in k10485 in merge-se in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_10502(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10502,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10541,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1418 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,t2);}}

/* k10539 in loop in k10488 in k10485 in merge-se in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10541,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(t1,t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1418 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10502(t4,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10533,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1419 loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10502(t6,t4,t5);}}

/* k10531 in k10539 in loop in k10488 in k10485 in merge-se in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10533,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10491 in k10488 in k10485 in merge-se in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10496,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(t1);
/* expand.scm: 1420 dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t2,lf[302],t3);}

/* k10494 in k10491 in k10488 in k10485 in merge-se in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_10207(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10207,NULL,2,t1,t2);}
t3=f_9608(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10214,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1371 module-name */
t5=C_retrieve2(lf[76],"module-name");
f_9590(3,t5,t4,t2);}

/* k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10214,2,t0,t1);}
t2=f_9626(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10265,a[2]=t1,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10288,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=((C_word)li143),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_10288(t8,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* loop in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_10288(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10288,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_cdr(t2);
/* expand.scm: 1387 loop */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10315,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1389 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t4,t2);}}}

/* k10313 in loop in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10315,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li142),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_10317(t5,((C_word*)t0)[2],t1);}

/* loop2 in k10313 in loop in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_10317(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10317,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 1390 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_10288(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1391 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}}

/* k10475 in loop2 in k10313 in loop in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10477,2,t0,t1);}
if(C_truep((C_word)C_i_assq(((C_word*)t0)[8],t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10340,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1392 warn */
t4=((C_word*)t0)[4];
f_10265(t4,t2,lf[298],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_cdr(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10383,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_10383(2,t7,t5);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1399 ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t6,t7,((C_word*)t0)[2]);}}
else{
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10465,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1401 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t5);}}}

/* k10463 in k10475 in loop2 in k10313 in loop in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10465,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10413,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 1404 loop2 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10317(t9,t7,t8);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10428,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1406 warn */
t6=((C_word*)t0)[2];
f_10265(t6,t4,lf[299],t5);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10446,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1409 warn */
t5=((C_word*)t0)[2];
f_10265(t5,t3,lf[300],t4);}}

/* k10444 in k10463 in k10475 in loop2 in k10313 in loop in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1410 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10317(t3,((C_word*)t0)[2],t2);}

/* k10426 in k10463 in k10475 in loop2 in k10313 in loop in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1407 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10317(t3,((C_word*)t0)[2],t2);}

/* k10411 in k10463 in k10475 in loop2 in k10313 in loop in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10413,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10381 in k10475 in loop2 in k10313 in loop in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10383,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10368,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1400 loop2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10317(t5,t3,t4);}

/* k10366 in k10381 in k10475 in loop2 in k10313 in loop in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10368,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10338 in k10475 in loop2 in k10313 in loop in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1393 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10317(t3,((C_word*)t0)[2],t2);}

/* warn in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_10265(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10265,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10273,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10277,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1381 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t5,((C_word*)t0)[2]);}

/* k10275 in warn in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1381 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[42]+1)))(6,*((C_word*)lf[42]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[296],t1,lf[297]);}

/* k10271 in warn in k10212 in module-indirect-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1380 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#mark-imported-symbols in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10148,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10154,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a10153 in ##sys#mark-imported-symbols in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10154,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10161,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_eqp(t5,t6);
t8=t3;
f_10161(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_10161(t5,C_SCHEME_FALSE);}}

/* k10159 in a10153 in ##sys#mark-imported-symbols in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_10161(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10161,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[294],t4);
/* expand.scm: 1365 dm */
((C_proc3)C_retrieve2_symbol_proc(lf[7],"dm"))(3,lf[7],t2,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k10162 in k10159 in a10153 in ##sys#mark-imported-symbols in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1366 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[17]))(5,*((C_word*)lf[17]+1),((C_word*)t0)[2],t2,lf[85],C_SCHEME_TRUE);}

/* ##sys#register-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+31)){
C_save_and_reclaim((void*)tr4r,(void*)f_10080r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10080r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10080r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(31);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10082,a[2]=t3,a[3]=t2,a[4]=((C_word)li136),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10095,a[2]=t5,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10100,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-vexports29712990 */
t8=t1;
((C_proc2)C_retrieve_proc(t8))(2,t8,f_10100(C_a_i(&a,19),t7));}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-sexports29722986 */
t10=t1;
((C_proc2)C_retrieve_proc(t10))(2,t10,f_10095(C_a_i(&a,19),t6,t8));}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body29692978 */
t12=t1;
((C_proc2)C_retrieve_proc(t12))(2,t12,f_10082(C_a_i(&a,19),t5,t8,t10));}
else{
/* ##sys#error */
t12=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-vexports2971 in ##sys#register-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_10100(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return(f_10095(C_a_i(&a,19),((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* def-sexports2972 in ##sys#register-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_10095(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return(f_10082(C_a_i(&a,19),((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST));}

/* body2969 in ##sys#register-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_10082(C_word *a,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t3=f_9798(C_a_i(&a,13),((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[278]));
t6=C_mutate((C_word*)lf[278]+1 /* (set! module-table ...) */,t5);
return(t3);}

/* ##sys#register-undefined in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10058,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10065,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1352 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[273]))(3,*((C_word*)lf[273]+1),t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k10063 in ##sys#register-undefined in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10065,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1354 set-module-undefined-list! */
((C_proc4)C_retrieve_symbol_proc(lf[272]))(4,*((C_word*)lf[272]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* ##sys#register-syntax-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9977,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=f_9608(t3);
t6=(C_word)C_eqp(C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9987,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9987(2,t8,t6);}
else{
/* expand.scm: 1334 ##sys#find-export */
((C_proc5)C_retrieve_symbol_proc(lf[289]))(5,*((C_word*)lf[289]+1),t7,t2,t3,C_SCHEME_TRUE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k9985 in ##sys#register-syntax-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9990,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1335 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[273]))(3,*((C_word*)lf[273]+1),t2,((C_word*)t0)[3]);}

/* k9988 in k9985 in ##sys#register-syntax-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9993,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1336 module-name */
t3=C_retrieve2(lf[76],"module-name");
f_9590(3,t3,t2,((C_word*)t0)[4]);}

/* k9991 in k9988 in k9985 in ##sys#register-syntax-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[2]))){
/* expand.scm: 1338 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),t2,lf[292],((C_word*)t0)[7]);}
else{
t3=t2;
f_9996(2,t3,C_SCHEME_UNDEFINED);}}

/* k9994 in k9991 in k9988 in k9985 in ##sys#register-syntax-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10039,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1339 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t3);}

/* k10037 in k9994 in k9991 in k9988 in k9985 in ##sys#register-syntax-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10043,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1339 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}

/* k10041 in k10037 in k9994 in k9991 in k9988 in k9985 in ##sys#register-syntax-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1339 check-for-redef */
f_9867(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9997 in k9994 in k9991 in k9988 in k9985 in ##sys#register-syntax-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1340 dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t2,lf[291],((C_word*)t0)[6]);}

/* k10000 in k9997 in k9994 in k9991 in k9988 in k9985 in ##sys#register-syntax-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=f_9626(((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
/* expand.scm: 1342 set-module-defined-list! */
f_9617(t2,((C_word*)t0)[4],t5);}
else{
t3=t2;
f_10005(2,t3,C_SCHEME_UNDEFINED);}}

/* k10003 in k10000 in k9997 in k9994 in k9991 in k9988 in k9985 in ##sys#register-syntax-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_10005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10005,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=f_9662(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[3];
t7=(C_word)C_i_check_structure(t6,lf[220]);
/* ##sys#block-set! */
t8=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,t6,C_fix(5),t4);}

/* ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9888,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=f_9608(t3);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9898,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_9898(2,t7,t5);}
else{
/* expand.scm: 1315 ##sys#find-export */
((C_proc5)C_retrieve_symbol_proc(lf[289]))(5,*((C_word*)lf[289]+1),t6,t2,t3,C_SCHEME_TRUE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1316 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[273]))(3,*((C_word*)lf[273]+1),t2,((C_word*)t0)[3]);}

/* k9899 in k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9904,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9964,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9968,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1318 module-name */
t5=C_retrieve2(lf[76],"module-name");
f_9590(3,t5,t4,((C_word*)t0)[3]);}

/* k9966 in k9899 in k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1318 ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9962 in k9899 in k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1317 ##sys#toplevel-definition-hook */
((C_proc6)C_retrieve_symbol_proc(lf[282]))(6,*((C_word*)lf[282]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9902 in k9899 in k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9960,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1321 ##sys#delq */
((C_proc4)C_retrieve_symbol_proc(lf[207]))(4,*((C_word*)lf[207]+1),t3,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_9907(2,t3,C_SCHEME_UNDEFINED);}}

/* k9958 in k9902 in k9899 in k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1321 set-module-undefined-list! */
((C_proc4)C_retrieve_symbol_proc(lf[272]))(4,*((C_word*)lf[272]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9905 in k9902 in k9899 in k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9946,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1322 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t3);}

/* k9944 in k9905 in k9902 in k9899 in k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9950,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1322 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}

/* k9948 in k9944 in k9905 in k9902 in k9899 in k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1322 check-for-redef */
f_9867(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9908 in k9905 in k9902 in k9899 in k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=f_9644(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(4),t4);}

/* k9911 in k9908 in k9905 in k9902 in k9899 in k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9913,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1325 dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t2,lf[288],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9917 in k9911 in k9908 in k9905 in k9902 in k9899 in k9896 in ##sys#register-export in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9919,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_FALSE);
t3=f_9626(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* expand.scm: 1326 set-module-defined-list! */
f_9617(((C_word*)t0)[2],((C_word*)t0)[3],t4);}

/* check-for-redef in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_9867(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9867,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(t2,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9874,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
/* expand.scm: 1308 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),t6,lf[286],t2);}
else{
t7=t6;
f_9874(2,t7,C_SCHEME_FALSE);}}

/* k9872 in check-for-redef in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
/* expand.scm: 1310 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),((C_word*)t0)[2],lf[285],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#register-meta-expression in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9847,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9851,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1303 ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t3);}

/* k9849 in ##sys#register-meta-expression in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9851,2,t0,t1);}
if(C_truep(t1)){
t2=f_9734(t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,C_fix(9),t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#toplevel-definition-hook in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9844,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}

/* ##sys#find-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9804(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_9804r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9804r(t0,t1,t2,t3);}}

static void C_ccall f_9804r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9808,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_9808(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_9808(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k9806 in ##sys#find-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[278]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
if(C_truep(t1)){
/* expand.scm: 1295 error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[279]+1)))(5,*((C_word*)lf[279]+1),((C_word*)t0)[2],lf[280],lf[281],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* make-module in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_9798(C_word *a,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_stack_check;
return((C_word)C_a_i_record(&a,12,lf[220],t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,t4));}

/* ##sys#module-exports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9780,3,t0,t1,t2);}
t3=f_9608(t2);
t4=f_9752(t2);
t5=f_9770(t2);
/* expand.scm: 1285 values */
C_values(5,0,t1,t3,t4,t5);}

/* module-sexports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_9770(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(11)));}

/* module-vexports in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_9752(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(10)));}

/* module-meta-expressions in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_9734(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(9)));}

/* module-meta-import-forms in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_9716(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(8)));}

/* module-import-forms in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_9698(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(7)));}

/* module-undefined-list in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9680,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[220]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* set-module-undefined-list! in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9671,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* module-defined-syntax-list in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_9662(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(5)));}

/* module-exist-list in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_9644(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(4)));}

/* module-defined-list in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_9626(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(3)));}

/* set-module-defined-list! in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_9617(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9617,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* module-export-list in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_9608(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* module-name in k9574 in k9570 in k9566 in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9590(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9590,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[220]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word ab[158],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7925,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_SCHEME_UNDEFINED;
t42=(*a=C_VECTOR_TYPE|1,a[1]=t41,tmp=(C_word)a,a+=2,tmp);
t43=C_SCHEME_UNDEFINED;
t44=(*a=C_VECTOR_TYPE|1,a[1]=t43,tmp=(C_word)a,a+=2,tmp);
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_SCHEME_UNDEFINED;
t56=(*a=C_VECTOR_TYPE|1,a[1]=t55,tmp=(C_word)a,a+=2,tmp);
t57=C_SCHEME_UNDEFINED;
t58=(*a=C_VECTOR_TYPE|1,a[1]=t57,tmp=(C_word)a,a+=2,tmp);
t59=C_SCHEME_UNDEFINED;
t60=(*a=C_VECTOR_TYPE|1,a[1]=t59,tmp=(C_word)a,a+=2,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_SCHEME_UNDEFINED;
t64=(*a=C_VECTOR_TYPE|1,a[1]=t63,tmp=(C_word)a,a+=2,tmp);
t65=C_SCHEME_UNDEFINED;
t66=(*a=C_VECTOR_TYPE|1,a[1]=t65,tmp=(C_word)a,a+=2,tmp);
t67=C_SCHEME_UNDEFINED;
t68=(*a=C_VECTOR_TYPE|1,a[1]=t67,tmp=(C_word)a,a+=2,tmp);
t69=C_SCHEME_UNDEFINED;
t70=(*a=C_VECTOR_TYPE|1,a[1]=t69,tmp=(C_word)a,a+=2,tmp);
t71=C_SCHEME_UNDEFINED;
t72=(*a=C_VECTOR_TYPE|1,a[1]=t71,tmp=(C_word)a,a+=2,tmp);
t73=C_SCHEME_UNDEFINED;
t74=(*a=C_VECTOR_TYPE|1,a[1]=t73,tmp=(C_word)a,a+=2,tmp);
t75=C_SCHEME_UNDEFINED;
t76=(*a=C_VECTOR_TYPE|1,a[1]=t75,tmp=(C_word)a,a+=2,tmp);
t77=C_SCHEME_UNDEFINED;
t78=(*a=C_VECTOR_TYPE|1,a[1]=t77,tmp=(C_word)a,a+=2,tmp);
t79=C_SCHEME_UNDEFINED;
t80=(*a=C_VECTOR_TYPE|1,a[1]=t79,tmp=(C_word)a,a+=2,tmp);
t81=C_SCHEME_UNDEFINED;
t82=(*a=C_VECTOR_TYPE|1,a[1]=t81,tmp=(C_word)a,a+=2,tmp);
t83=C_SCHEME_UNDEFINED;
t84=(*a=C_VECTOR_TYPE|1,a[1]=t83,tmp=(C_word)a,a+=2,tmp);
t85=C_SCHEME_UNDEFINED;
t86=(*a=C_VECTOR_TYPE|1,a[1]=t85,tmp=(C_word)a,a+=2,tmp);
t87=C_SCHEME_UNDEFINED;
t88=(*a=C_VECTOR_TYPE|1,a[1]=t87,tmp=(C_word)a,a+=2,tmp);
t89=C_SCHEME_UNDEFINED;
t90=(*a=C_VECTOR_TYPE|1,a[1]=t89,tmp=(C_word)a,a+=2,tmp);
t91=C_SCHEME_UNDEFINED;
t92=(*a=C_VECTOR_TYPE|1,a[1]=t91,tmp=(C_word)a,a+=2,tmp);
t93=C_SCHEME_UNDEFINED;
t94=(*a=C_VECTOR_TYPE|1,a[1]=t93,tmp=(C_word)a,a+=2,tmp);
t95=C_SCHEME_UNDEFINED;
t96=(*a=C_VECTOR_TYPE|1,a[1]=t95,tmp=(C_word)a,a+=2,tmp);
t97=C_SCHEME_UNDEFINED;
t98=(*a=C_VECTOR_TYPE|1,a[1]=t97,tmp=(C_word)a,a+=2,tmp);
t99=C_SCHEME_UNDEFINED;
t100=(*a=C_VECTOR_TYPE|1,a[1]=t99,tmp=(C_word)a,a+=2,tmp);
t101=C_SCHEME_UNDEFINED;
t102=(*a=C_VECTOR_TYPE|1,a[1]=t101,tmp=(C_word)a,a+=2,tmp);
t103=C_SCHEME_UNDEFINED;
t104=(*a=C_VECTOR_TYPE|1,a[1]=t103,tmp=(C_word)a,a+=2,tmp);
t105=C_SCHEME_UNDEFINED;
t106=(*a=C_VECTOR_TYPE|1,a[1]=t105,tmp=(C_word)a,a+=2,tmp);
t107=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7932,a[2]=t2,a[3]=t5,a[4]=t3,a[5]=t1,a[6]=t102,a[7]=t104,a[8]=t98,a[9]=t106,a[10]=t100,a[11]=t90,a[12]=t88,a[13]=t4,a[14]=t86,a[15]=t92,a[16]=t96,a[17]=t94,a[18]=t84,a[19]=t82,a[20]=t6,a[21]=t80,a[22]=t78,a[23]=t76,a[24]=t74,a[25]=t72,a[26]=t70,a[27]=t68,a[28]=t66,a[29]=t64,a[30]=t62,a[31]=t60,a[32]=t58,a[33]=t56,a[34]=t54,a[35]=t52,a[36]=t50,a[37]=t48,a[38]=t46,a[39]=t44,a[40]=t42,a[41]=t40,a[42]=t38,a[43]=t36,a[44]=t34,a[45]=t32,a[46]=t30,a[47]=t28,a[48]=t26,a[49]=t24,a[50]=t22,a[51]=t20,a[52]=t18,a[53]=t16,a[54]=t14,a[55]=t12,a[56]=t10,a[57]=t8,tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t108=t5;
((C_proc3)C_retrieve_proc(t108))(3,t108,t107,lf[265]);}

/* k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7932,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[231]);
t4=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[232]);
t5=C_mutate(((C_word *)((C_word*)t0)[54])+1,lf[233]);
t6=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[234]);
t7=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[235]);
t8=C_mutate(((C_word *)((C_word*)t0)[51])+1,lf[236]);
t9=C_mutate(((C_word *)((C_word*)t0)[50])+1,lf[237]);
t10=C_mutate(((C_word *)((C_word*)t0)[49])+1,lf[238]);
t11=C_mutate(((C_word *)((C_word*)t0)[48])+1,lf[239]);
t12=C_mutate(((C_word *)((C_word*)t0)[47])+1,lf[240]);
t13=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[50],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[51],a[12]=((C_word*)t0)[48],a[13]=((C_word*)t0)[53],a[14]=((C_word*)t0)[52],a[15]=((C_word*)t0)[47],a[16]=((C_word*)t0)[49],a[17]=((C_word*)t0)[54],a[18]=((C_word*)t0)[10],a[19]=((C_word*)t0)[11],a[20]=((C_word*)t0)[56],a[21]=((C_word*)t0)[12],a[22]=((C_word*)t0)[13],a[23]=((C_word*)t0)[14],a[24]=((C_word*)t0)[15],a[25]=((C_word*)t0)[16],a[26]=((C_word*)t0)[17],a[27]=((C_word*)t0)[57],a[28]=((C_word*)t0)[18],a[29]=((C_word*)t0)[55],a[30]=((C_word*)t0)[19],a[31]=((C_word*)t0)[20],a[32]=((C_word*)t0)[21],a[33]=((C_word*)t0)[22],a[34]=((C_word*)t0)[23],a[35]=((C_word*)t0)[24],a[36]=((C_word*)t0)[25],a[37]=((C_word*)t0)[26],a[38]=((C_word*)t0)[27],a[39]=((C_word*)t0)[28],a[40]=((C_word*)t0)[29],a[41]=((C_word*)t0)[30],a[42]=((C_word*)t0)[31],a[43]=((C_word*)t0)[32],a[44]=((C_word*)t0)[33],a[45]=((C_word*)t0)[34],a[46]=((C_word*)t0)[35],a[47]=((C_word*)t0)[36],a[48]=((C_word*)t0)[37],a[49]=((C_word*)t0)[38],a[50]=((C_word*)t0)[39],a[51]=((C_word*)t0)[40],a[52]=((C_word*)t0)[41],a[53]=((C_word*)t0)[42],a[54]=((C_word*)t0)[43],a[55]=((C_word*)t0)[44],a[56]=((C_word*)t0)[45],a[57]=((C_word*)t0)[46],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t14=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,lf[264]);}

/* k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7946,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[57],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[263]);}

/* k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7950,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[57],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[262]);}

/* k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7954,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[241]);
t4=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[56],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[57],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],a[57]=((C_word*)t0)[55],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[261]);}

/* k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7959,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[242]);
t4=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[243]);
t5=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[55],a[22]=((C_word*)t0)[56],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[57],a[34]=((C_word*)t0)[31],a[35]=((C_word*)t0)[32],a[36]=((C_word*)t0)[33],a[37]=((C_word*)t0)[34],a[38]=((C_word*)t0)[35],a[39]=((C_word*)t0)[36],a[40]=((C_word*)t0)[37],a[41]=((C_word*)t0)[38],a[42]=((C_word*)t0)[39],a[43]=((C_word*)t0)[40],a[44]=((C_word*)t0)[41],a[45]=((C_word*)t0)[42],a[46]=((C_word*)t0)[43],a[47]=((C_word*)t0)[44],a[48]=((C_word*)t0)[45],a[49]=((C_word*)t0)[46],a[50]=((C_word*)t0)[47],a[51]=((C_word*)t0)[48],a[52]=((C_word*)t0)[49],a[53]=((C_word*)t0)[50],a[54]=((C_word*)t0)[51],a[55]=((C_word*)t0)[52],a[56]=((C_word*)t0)[53],a[57]=((C_word*)t0)[54],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[260]);}

/* k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7965,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[57],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[259]);}

/* k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7969,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[57],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7973,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[57],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[58]);}

/* k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7977,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[57],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[113]);}

/* k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7981,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[244]);
t4=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[56],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[57],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],a[57]=((C_word*)t0)[55],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[164]);}

/* k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],a[55]=((C_word*)t0)[55],a[56]=((C_word*)t0)[56],a[57]=((C_word*)t0)[57],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[258]);}

/* k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7990,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[21]);
t4=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[245]);
t5=C_mutate(((C_word *)((C_word*)t0)[54])+1,lf[246]);
t6=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[55],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[56],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[57],a[23]=((C_word*)t0)[54],a[24]=((C_word*)t0)[20],a[25]=((C_word*)t0)[21],a[26]=((C_word*)t0)[22],a[27]=((C_word*)t0)[23],a[28]=((C_word*)t0)[24],a[29]=((C_word*)t0)[25],a[30]=((C_word*)t0)[26],a[31]=((C_word*)t0)[27],a[32]=((C_word*)t0)[28],a[33]=((C_word*)t0)[29],a[34]=((C_word*)t0)[30],a[35]=((C_word*)t0)[31],a[36]=((C_word*)t0)[32],a[37]=((C_word*)t0)[33],a[38]=((C_word*)t0)[34],a[39]=((C_word*)t0)[35],a[40]=((C_word*)t0)[36],a[41]=((C_word*)t0)[37],a[42]=((C_word*)t0)[38],a[43]=((C_word*)t0)[39],a[44]=((C_word*)t0)[40],a[45]=((C_word*)t0)[41],a[46]=((C_word*)t0)[42],a[47]=((C_word*)t0)[43],a[48]=((C_word*)t0)[44],a[49]=((C_word*)t0)[45],a[50]=((C_word*)t0)[46],a[51]=((C_word*)t0)[47],a[52]=((C_word*)t0)[48],a[53]=((C_word*)t0)[49],a[54]=((C_word*)t0)[50],a[55]=((C_word*)t0)[51],a[56]=((C_word*)t0)[52],a[57]=((C_word*)t0)[53],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7997,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[247]);
t4=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_8002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[57],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[56],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],a[57]=((C_word*)t0)[55],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[95]);}

/* k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8002,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_8006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[57],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[227]);}

/* k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8006,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_8010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[57],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[256]);}

/* k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8010,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_8014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[57],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[255]);}

/* k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8014,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[53]);
t4=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_8019,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=((C_word*)t0)[22],a[21]=((C_word*)t0)[23],a[22]=((C_word*)t0)[24],a[23]=((C_word*)t0)[25],a[24]=((C_word*)t0)[26],a[25]=((C_word*)t0)[27],a[26]=((C_word*)t0)[28],a[27]=((C_word*)t0)[29],a[28]=((C_word*)t0)[30],a[29]=((C_word*)t0)[31],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[33],a[32]=((C_word*)t0)[57],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[56],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],a[55]=((C_word*)t0)[55],tmp=(C_word)a,a+=56,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[134],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8019,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[54])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8021,a[2]=((C_word*)t0)[55],a[3]=((C_word*)t0)[53],a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8027,a[2]=((C_word*)t0)[41],a[3]=((C_word*)t0)[42],a[4]=((C_word*)t0)[43],a[5]=((C_word*)t0)[44],a[6]=((C_word*)t0)[45],a[7]=((C_word*)t0)[46],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[48],a[10]=((C_word*)t0)[49],a[11]=((C_word*)t0)[50],a[12]=((C_word*)t0)[51],a[13]=((C_word)li94),tmp=(C_word)a,a+=14,tmp));
t5=C_mutate(((C_word *)((C_word*)t0)[41])+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8121,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[47],a[4]=((C_word*)t0)[36],a[5]=((C_word*)t0)[37],a[6]=((C_word*)t0)[38],a[7]=((C_word*)t0)[39],a[8]=((C_word*)t0)[40],a[9]=((C_word)li96),tmp=(C_word)a,a+=10,tmp));
t6=C_mutate(((C_word *)((C_word*)t0)[35])+1,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8205,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[27],a[4]=((C_word*)t0)[28],a[5]=((C_word*)t0)[29],a[6]=((C_word*)t0)[30],a[7]=((C_word*)t0)[35],a[8]=((C_word*)t0)[48],a[9]=((C_word*)t0)[45],a[10]=((C_word*)t0)[40],a[11]=((C_word*)t0)[31],a[12]=((C_word*)t0)[32],a[13]=((C_word*)t0)[33],a[14]=((C_word*)t0)[51],a[15]=((C_word*)t0)[50],a[16]=((C_word*)t0)[34],a[17]=((C_word)li97),tmp=(C_word)a,a+=18,tmp));
t7=C_mutate(((C_word *)((C_word*)t0)[33])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8426,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[30],a[4]=((C_word*)t0)[45],a[5]=((C_word*)t0)[21],a[6]=((C_word*)t0)[40],a[7]=((C_word*)t0)[22],a[8]=((C_word*)t0)[48],a[9]=((C_word*)t0)[31],a[10]=((C_word*)t0)[23],a[11]=((C_word*)t0)[24],a[12]=((C_word*)t0)[25],a[13]=((C_word)li98),tmp=(C_word)a,a+=14,tmp));
t8=C_mutate(((C_word *)((C_word*)t0)[29])+1,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8544,a[2]=((C_word*)t0)[54],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[35],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[22],a[9]=((C_word*)t0)[21],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[45],a[13]=((C_word*)t0)[40],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[32],a[16]=((C_word)li100),tmp=(C_word)a,a+=17,tmp));
t9=C_mutate(((C_word *)((C_word*)t0)[36])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8832,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[54],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[30],a[7]=((C_word*)t0)[48],a[8]=((C_word*)t0)[36],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[44],a[11]=((C_word*)t0)[32],a[12]=((C_word*)t0)[34],a[13]=((C_word)li103),tmp=(C_word)a,a+=14,tmp));
t10=C_mutate(((C_word *)((C_word*)t0)[38])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9039,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[44],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[38],a[12]=((C_word*)t0)[50],a[13]=((C_word)li105),tmp=(C_word)a,a+=14,tmp));
t11=C_mutate(((C_word *)((C_word*)t0)[37])+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9293,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[37],a[4]=((C_word*)t0)[34],a[5]=((C_word)li106),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9366,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word)li107),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate(((C_word *)((C_word*)t0)[26])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9459,a[2]=((C_word*)t0)[4],a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9481,a[2]=((C_word*)t0)[54],a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate(((C_word *)((C_word*)t0)[8])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9507,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word)li110),tmp=(C_word)a,a+=5,tmp));
t16=C_mutate(((C_word *)((C_word*)t0)[11])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9527,a[2]=((C_word*)t0)[54],a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp));
/* make-transformer2284 */
t17=((C_word*)((C_word*)t0)[52])[1];
((C_proc3)C_retrieve_proc(t17))(3,t17,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_9527 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9527(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9527,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9537,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li111),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9537(t7,t1,t3);}

/* loop */
static void C_fcall f_9537(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9537,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9544,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
/* ellipsis?2283 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t4=t3;
f_9544(2,t4,C_SCHEME_FALSE);}}

/* k9542 in loop */
static void C_ccall f_9544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop2615 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9537(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* f_9507 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9507,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9514,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* segment-template?2294 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9512 */
static void C_ccall f_9514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9514,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9521,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* segment-depth2295 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* k9519 in k9512 */
static void C_ccall f_9521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(1),t1));}

/* f_9481 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9481,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(t2);
/* ellipsis?2283 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_9459 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9459,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9466,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* segment-template?2294 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9464 */
static void C_ccall f_9466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),((C_word*)t0)[2],lf[254],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_9366 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9366,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9379,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,t5))){
t7=t6;
f_9379(t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_i_assq(t2,t4);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t7);
t9=t3;
t10=t6;
f_9379(t10,(C_word)C_fixnum_greater_or_equal_p(t8,t9));}
else{
t8=t6;
f_9379(t8,C_SCHEME_FALSE);}}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9408,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* segment-template?2294 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}

/* k9406 */
static void C_ccall f_9408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9408,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9419,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* free-meta-variables2292 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9440,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* free-meta-variables2292 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9455 in k9406 */
static void C_ccall f_9457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2292 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9438 in k9406 */
static void C_ccall f_9440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2292 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9417 in k9406 */
static void C_ccall f_9419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2292 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9377 */
static void C_fcall f_9379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9379,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]):((C_word*)t0)[2]));}

/* f_9293 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9293,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[4]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t4));}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9319,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* segment-pattern?2293 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k9317 */
static void C_ccall f_9319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9319,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* meta-variables2291 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9347,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* meta-variables2291 */
t5=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t2,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9362 in k9317 */
static void C_ccall f_9364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2291 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9345 in k9317 */
static void C_ccall f_9347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2291 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_9039 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_9039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9039,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(C_word)C_i_assq(t2,t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
t7=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),t1,lf[251],t2);}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[250],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t8));}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t4,a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=t1,a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* segment-template?2294 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k9084 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9086,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9089,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* segment-depth2295 */
t3=((C_word*)((C_word*)t0)[5])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9247,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* process-template2290 */
t4=((C_word*)((C_word*)t0)[11])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[14],((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9284,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t3,((C_word*)t0)[12]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}}}}

/* k9282 in k9084 */
static void C_ccall f_9284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2290 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9278 in k9084 */
static void C_ccall f_9280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9280,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k9245 in k9084 */
static void C_ccall f_9247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9255,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* process-template2290 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9253 in k9245 in k9084 */
static void C_ccall f_9255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9255,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t3));}

/* k9087 in k9084 */
static void C_ccall f_9089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9089,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9095,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* free-meta-variables2292 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,t2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k9093 in k9087 in k9084 */
static void C_ccall f_9095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9095,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),((C_word*)t0)[11],lf[252],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* process-template2290 */
t4=((C_word*)((C_word*)t0)[9])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k9105 in k9093 in k9087 in k9084 */
static void C_ccall f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9110,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
if(C_truep((C_word)C_i_symbolp(t1))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_9173(t6,(C_word)C_eqp(t1,t5));}
else{
t5=t3;
f_9173(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_9173(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_9173(t4,C_SCHEME_FALSE);}}

/* k9171 in k9105 in k9093 in k9087 in k9084 */
static void C_fcall f_9173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9173,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_9110(t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}

/* k9186 in k9171 in k9105 in k9093 in k9087 in k9084 */
static void C_ccall f_9188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9188,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_9110(t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k9108 in k9105 in k9093 in k9087 in k9084 */
static void C_fcall f_9110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9110,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9144,a[2]=t4,a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9144(t6,t2,((C_word*)t0)[2],t1);}

/* doloop2533 in k9108 in k9105 in k9093 in k9087 in k9084 */
static void C_fcall f_9144(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9144,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[51],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t11=t1;
t12=t6;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k9111 in k9108 in k9105 in k9093 in k9087 in k9084 */
static void C_ccall f_9113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* segment-tail2296 */
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9140 in k9111 in k9108 in k9105 in k9093 in k9087 in k9084 */
static void C_ccall f_9142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9142,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9134,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9138,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* segment-tail2296 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k9136 in k9140 in k9111 in k9108 in k9105 in k9093 in k9087 in k9084 */
static void C_ccall f_9138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2290 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9132 in k9140 in k9111 in k9108 in k9105 in k9093 in k9087 in k9084 */
static void C_ccall f_9134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9134,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[51],t3));}

/* f_8832 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8832,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[12]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8856,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* mapit2440 */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8862,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=t4,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* segment-pattern?2293 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8860 */
static void C_ccall f_8862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8862,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8871,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word)li101),tmp=(C_word)a,a+=8,tmp);
/* process-pattern2289 */
t4=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[7],t2,((C_word*)((C_word*)t0)[12])[1],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[14]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8922,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[14]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
/* process-pattern2289 */
t6=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[13]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[14]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8962,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(2)))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[14],t4);
/* ellipsis?2283 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t3,t5);}
else{
t4=t3;
f_8962(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}}}

/* k8960 in k8860 */
static void C_ccall f_8962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8962,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8972,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t2,((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8985,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[3],a[9]=((C_word)li102),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_8985(t5,((C_word*)t0)[6],C_fix(0));}}

/* lp in k8960 in k8860 */
static void C_fcall f_8985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8985,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[8]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8999,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_vector_ref(((C_word*)t0)[6],t2);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
/* process-pattern2289 */
t9=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,((C_word*)t0)[2]);}}

/* k8997 in lp in k8960 in k8860 */
static void C_ccall f_8999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9003,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2475 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8985(t4,t2,t3);}

/* k9001 in k8997 in lp in k8960 in k8860 */
static void C_ccall f_9003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8970 in k8960 in k8860 */
static void C_ccall f_8972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8972,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
/* process-pattern2289 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k8920 in k8860 */
static void C_ccall f_8922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8926,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
/* process-pattern2289 */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[2]);}

/* k8924 in k8920 in k8860 */
static void C_ccall f_8926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8870 in k8860 */
static void C_ccall f_8871(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8871,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8879,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],t2);
if(C_truep(t4)){
t5=t3;
f_8879(t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=t3;
f_8879(t11,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t10));}}

/* k8877 in a8870 in k8860 */
static void C_fcall f_8879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* mapit2440 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8854 */
static void C_ccall f_8856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8856,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t2));}

/* f_8544 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8544,4,t0,t1,t2,t3);}
t4=(C_word)C_i_vector_length(t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8551,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t4,a[13]=t1,a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t6=(C_word)C_fixnum_difference(t4,C_fix(1));
t7=(C_word)C_i_vector_ref(t3,t6);
/* ellipsis?2283 */
t8=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t8))(3,t8,t5,t7);}
else{
t6=t5;
f_8551(2,t6,C_SCHEME_FALSE);}}

/* k8549 */
static void C_ccall f_8551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8551,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[16])[1],t5);
t7=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8590,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t4,a[16]=((C_word*)t0)[15],a[17]=t6,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t1)){
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_fixnum_difference(((C_word*)t0)[12],C_fix(2));
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=t7;
f_8590(t13,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t12));}
else{
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=t7;
f_8590(t12,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t11));}}

/* k8588 in k8549 */
static void C_fcall f_8590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8590,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8594,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[17],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8598,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8600,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word)li99),tmp=(C_word)a,a+=17,tmp));
t7=((C_word*)t5)[1];
f_8600(t7,t3,C_fix(0));}

/* lp in k8588 in k8549 */
static void C_fcall f_8600(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8600,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[15]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t5=t2;
t6=(C_word)C_eqp(t5,t4);
t7=(C_truep(t6)?((C_word*)t0)[14]:C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t12);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8660,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t10,a[6]=((C_word*)t0)[10],a[7]=t13,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8664,a[2]=t14,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t17);
t19=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t20=(C_word)C_i_vector_ref(((C_word*)t0)[4],t19);
/* process-match2286 */
t21=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t21))(4,t21,t15,t18,t20);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8731,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t10);
t12=(C_word)C_i_vector_ref(((C_word*)t0)[4],t2);
/* process-match2286 */
t13=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t13))(4,t13,t8,t11,t12);}}}

/* k8729 in lp in k8588 in k8549 */
static void C_ccall f_8731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8735,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2411 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8600(t4,t2,t3);}

/* k8733 in k8729 in lp in k8588 in k8549 */
static void C_ccall f_8735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8662 in lp in k8588 in k8549 */
static void C_ccall f_8664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8664,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k8658 in lp in k8588 in k8549 */
static void C_ccall f_8660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8660,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}

/* k8596 in k8588 in k8549 */
static void C_ccall f_8598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8592 in k8588 in k8549 */
static void C_ccall f_8594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8594,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST));}

/* f_8426 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8426,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8430,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
/* process-match2286 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t6,t3);}

/* k8428 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8430,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t8,t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t6,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t4,t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t21);
t23=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,(C_word)C_a_i_cons(&a,2,t22,C_SCHEME_END_OF_LIST));}}

/* f_8205 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8205,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_symbolp(t3))){
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[16]))){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[250],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[15])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[14])[1],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}
else{
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* segment-pattern?2293 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k8253 */
static void C_ccall f_8255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8255,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-segment-match2287 */
t3=((C_word*)((C_word*)t0)[14])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[13],((C_word*)t0)[12],t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8303,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8307,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t9);
t11=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-match2286 */
t12=((C_word*)((C_word*)t0)[6])[1];
((C_proc4)C_retrieve_proc(t12))(4,t12,t8,t10,t11);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[15]))){
/* process-vector-match2288 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[15]);}
else{
t2=(C_word)C_i_nullp(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8369(t4,t2);}
else{
t4=(C_word)C_booleanp(((C_word*)t0)[15]);
t5=t3;
f_8369(t5,(C_truep(t4)?t4:(C_word)C_charp(((C_word*)t0)[15])));}}}}}

/* k8367 in k8253 */
static void C_fcall f_8369(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8369,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}}

/* k8305 in k8253 */
static void C_ccall f_8307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8311,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8315,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* process-match2286 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t5,t6);}

/* k8313 in k8305 in k8253 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8309 in k8305 in k8253 */
static void C_ccall f_8311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8301 in k8253 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8303,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* f_8121 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8121,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=t3;
f_8128(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_8128(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8128(t4,C_SCHEME_FALSE);}}

/* k8126 */
static void C_fcall f_8128(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8128,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t2,((C_word*)t0)[10]);}
else{
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),((C_word*)t0)[7],lf[249],((C_word*)t0)[10]);}}

/* k8129 in k8126 */
static void C_ccall f_8131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8131,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8180,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* process-match2286 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t1);}

/* k8178 in k8129 in k8126 */
static void C_ccall f_8180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8174 in k8129 in k8126 */
static void C_ccall f_8176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8176,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8157,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8171,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* process-pattern2289 */
t5=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],t4);}

/* a8170 in k8174 in k8129 in k8126 */
static void C_ccall f_8171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8171,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8155 in k8174 in k8129 in k8126 */
static void C_ccall f_8157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8165,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8169,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* meta-variables2291 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_SCHEME_END_OF_LIST);}

/* k8167 in k8155 in k8174 in k8129 in k8126 */
static void C_ccall f_8169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2290 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k8163 in k8155 in k8174 in k8129 in k8126 */
static void C_ccall f_8165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8165,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* f_8027 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8027(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[38],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8027,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8067,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t10,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8071,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* map */
t13=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)((C_word*)t0)[2])[1],t2);}

/* k8069 */
static void C_ccall f_8071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8071,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[248],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k8065 */
static void C_ccall f_8067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8067,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t7));}

/* f_8021 in k8017 in k8012 in k8008 in k8004 in k8000 in k7995 in k7988 in k7984 in k7979 in k7975 in k7971 in k7967 in k7963 in k7957 in k7952 in k7948 in k7944 in k7930 in ##sys#process-syntax-rules in k7921 in k7918 in k7915 in k7912 in k7909 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7869 in k7866 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_8021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8021,3,t0,t1,t2);}
/* c2243 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7023,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7027,a[2]=t3,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=t6,a[7]=t1,a[8]=t4,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 729  r */
t10=t3;
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[228]);}

/* k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 730  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[227]);}

/* k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 731  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[226]);}

/* k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 732  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[225]);}

/* k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7038,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7047,a[2]=((C_word*)t0)[11],a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7090,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7177,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[11],a[11]=t4,a[12]=((C_word)li88),tmp=(C_word)a,a+=13,tmp));
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 829  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t8,((C_word*)t0)[11],((C_word*)t0)[3],lf[224]);}

/* k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 830  ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t2);}

/* k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7842,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9716(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 836  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),t3,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7857,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9698(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 839  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),t3,t4,t5);}}
else{
t3=t2;
f_7641(2,t3,C_SCHEME_UNDEFINED);}}

/* k7855 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(7),t1);}

/* k7840 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(8),t1);}

/* k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7644,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7646,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li91),tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7646,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7650,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 842  import-spec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7177(t4,t3,t2);}

/* k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7650,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7659,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[219],t5);
/* expand.scm: 845  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t4,t6);}

/* k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7809,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* expand.scm: 846  module-name */
t4=C_retrieve2(lf[76],"module-name");
f_9590(3,t4,t3,((C_word*)t0)[2]);}
else{
t4=t3;
f_7809(2,t4,lf[217]);}}

/* k7807 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7817,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 846  map-se */
f_3691(t2,((C_word*)t0)[2]);}

/* k7815 in k7807 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7817,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[218],t3);
/* expand.scm: 846  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],((C_word*)t0)[2],t4);}

/* k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7665,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7786,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* expand.scm: 847  module-name */
t4=C_retrieve2(lf[76],"module-name");
f_9590(3,t4,t3,((C_word*)t0)[2]);}
else{
t4=t3;
f_7786(2,t4,lf[217]);}}

/* k7784 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7794,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 847  map-se */
f_3691(t2,((C_word*)t0)[2]);}

/* k7792 in k7784 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7794,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[216],t3);
/* expand.scm: 847  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],((C_word*)t0)[2],t4);}

/* k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 848  ##sys#mark-imported-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),t2,((C_word*)t0)[2]);}

/* k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7740,a[2]=((C_word*)t0)[3],a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7739 in k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7740,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7774,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 853  import-env */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7772 in a7739 in k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(((C_word*)t0)[3],t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
/* expand.scm: 855  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),((C_word*)t0)[2],lf[214],((C_word*)t0)[4]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7669 in k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7698,a[2]=((C_word*)t0)[6],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7697 in k7669 in k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7698,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7738,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 859  macro-env */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7736 in a7697 in k7669 in k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* expand.scm: 861  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),((C_word*)t0)[2],lf[213],t6);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7672 in k7669 in k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7677,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7692,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7696,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 863  import-env */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7694 in k7672 in k7669 in k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 863  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7690 in k7672 in k7669 in k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 863  import-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7675 in k7672 in k7669 in k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7688,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 864  macro-env */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7686 in k7675 in k7672 in k7669 in k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 864  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7682 in k7675 in k7672 in k7669 in k7666 in k7663 in k7660 in k7657 in k7648 in a7645 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 864  macro-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7642 in k7639 in k7636 in k7633 in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[212]);}

/* import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_7177(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7177,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 762  import-name */
t3=((C_word*)t0)[11];
f_7090(t3,t1,t2);}
else{
t3=(C_word)C_i_listp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t4)){
t6=t5;
f_7196(t6,t4);}
else{
t6=(C_word)C_i_length(t2);
t7=t5;
f_7196(t7,(C_word)C_fixnum_lessp(t6,C_fix(2)));}}}

/* k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_7196(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7196,NULL,2,t0,t1);}
if(C_truep(t1)){
/* expand.scm: 764  syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[142]))(5,*((C_word*)lf[142]+1),((C_word*)t0)[12],((C_word*)t0)[11],lf[201],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7205,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* expand.scm: 767  import-spec */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7177(t5,t3,t4);}}

/* k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7205,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 770  c */
t6=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}

/* k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7217,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7220,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 771  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[7],((C_word*)t0)[9],lf[202]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 782  c */
t4=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7297,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7300,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 783  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[6],((C_word*)t0)[8],lf[203]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7404,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* expand.scm: 793  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7404,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7407,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 794  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[5],((C_word*)t0)[9],lf[209]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7551,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 819  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7549 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7551,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 820  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[210]);}
else{
/* expand.scm: 828  syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[142]))(5,*((C_word*)lf[142]+1),((C_word*)t0)[7],((C_word*)t0)[2],lf[211],((C_word*)t0)[4]);}}

/* k7552 in k7549 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7557,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* expand.scm: 821  tostr */
t4=((C_word*)t0)[2];
f_7047(t4,t2,t3);}

/* k7555 in k7552 in k7549 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7559,a[2]=t1,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7590,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k7588 in k7555 in k7552 in k7549 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7594,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7592 in k7588 in k7555 in k7552 in k7549 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7594,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ren in k7555 in k7552 in k7549 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7559(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7559,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7567,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7575,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7579,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* expand.scm: 825  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[190]))(3,*((C_word*)lf[190]+1),t5,t6);}

/* k7577 in ren in k7555 in k7552 in k7549 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 825  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[188]))(4,*((C_word*)lf[188]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7573 in ren in k7555 in k7552 in k7549 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 824  ##sys#string->symbol */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),((C_word*)t0)[2],t1);}

/* k7565 in ren in k7555 in k7552 in k7549 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7567,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k7405 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7407,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7416,a[2]=t4,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7416(t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in k7405 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_7416(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7416,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7432,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7437,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t9=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7493,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t3,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 803  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t7,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7545,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=t2,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 810  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t7,t2);}}

/* k7543 in loop in k7405 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7545,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7526,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 813  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 816  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7416(t6,((C_word*)t0)[4],t3,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k7524 in k7543 in loop in k7405 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7526,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7514,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 815  ##sys#delq */
((C_proc4)C_retrieve_symbol_proc(lf[207]))(4,*((C_word*)lf[207]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7512 in k7524 in k7543 in loop in k7405 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 812  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7416(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7491 in loop in k7405 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7493,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7474,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 807  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 809  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7416(t6,((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2],t5,((C_word*)t0)[8]);}}

/* k7472 in k7491 in loop in k7405 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7474,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7462,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 808  ##sys#delq */
((C_proc4)C_retrieve_symbol_proc(lf[207]))(4,*((C_word*)lf[207]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7460 in k7472 in k7491 in loop in k7405 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 805  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7416(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7436 in loop in k7405 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7437,3,t0,t1,t2);}
/* expand.scm: 800  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),t1,lf[205],t2);}

/* k7430 in loop in k7405 in k7402 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7432,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k7298 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7303,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7301 in k7298 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7303,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7308,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7308(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k7301 in k7298 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_7308(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7308,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7320,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7320(t7,t1,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7394,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 791  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,t2);}}

/* k7392 in loop in k7301 in k7298 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7394,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 791  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7308(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 792  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7308(t5,((C_word*)t0)[3],t2,t4);}}

/* loop in loop in k7301 in k7298 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_7320(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7320,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7362,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 789  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,t2);}}

/* k7360 in loop in loop in k7301 in k7298 in k7295 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7362,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 789  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7320(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 790  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7320(t5,((C_word*)t0)[3],t2,t4);}}

/* k7218 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7223,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7221 in k7218 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7223,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7228,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7228(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k7221 in k7218 in k7215 in k7203 in k7194 in import-spec in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_7228(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7228,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_assq(t5,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* expand.scm: 777  loop */
t15=t1;
t16=t7;
t17=t8;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_assq(t7,((C_word*)t0)[2]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t8,t4);
/* expand.scm: 780  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t10;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
/* expand.scm: 781  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}}

/* import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_7090(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7090,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7094,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 742  resolve */
t4=((C_word*)t0)[2];
f_7038(3,t4,t3,t2);}

/* k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7097,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 743  ##sys#find-module */
((C_proc4)C_retrieve_symbol_proc(lf[194]))(4,*((C_word*)lf[194]+1),t2,t1,C_SCHEME_FALSE);}

/* k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7097,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7100,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t3)[1])){
t5=t4;
f_7100(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7171,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7175,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 746  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t7,((C_word*)t0)[3]);}}

/* k7173 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 746  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),((C_word*)t0)[2],t1,lf[200]);}

/* k7169 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 745  ##sys#find-extension */
((C_proc4)C_retrieve_symbol_proc(lf[199]))(4,*((C_word*)lf[199]+1),((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7112,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[80]);
t3=C_retrieve(lf[8]);
t4=C_retrieve(lf[9]);
t5=C_retrieve(lf[29]);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7118,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t3,a[8]=t4,a[9]=t5,a[10]=t9,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 750  ##sys#current-meta-environment */
((C_proc2)C_retrieve_symbol_proc(lf[9]))(2,*((C_word*)lf[9]+1),t10);}
else{
/* expand.scm: 755  syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[142]))(5,*((C_word*)lf[142]+1),((C_word*)t0)[4],((C_word*)t0)[2],lf[198],((C_word*)t0)[3]);}}

/* k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7118,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 751  ##sys#meta-macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[197]))(2,*((C_word*)lf[197]+1),t4);}

/* k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7121,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7122,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word)li79),tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7160,a[2]=((C_word*)t0)[2],a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t7=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t4,t6,t4);}

/* a7159 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7160,2,t0,t1);}
/* expand.scm: 752  ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[195]))(5,*((C_word*)lf[195]+1),t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7152 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7158,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 753  ##sys#find-module */
((C_proc3)C_retrieve_symbol_proc(lf[194]))(3,*((C_word*)lf[194]+1),t2,((C_word*)t0)[2]);}

/* k7156 in k7152 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7100(2,t3,t2);}

/* swap1402 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* g140514061421 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7124 in swap1402 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* g140514061421 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[10])[1]);}

/* k7127 in k7124 in swap1402 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7129,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g140714081422 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7131 in k7127 in k7124 in swap1402 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7136,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g140714081422 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k7134 in k7131 in k7127 in k7124 in swap1402 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7136,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g140914101423 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7138 in k7134 in k7131 in k7127 in k7124 in swap1402 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g140914101423 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k7141 in k7138 in k7134 in k7131 in k7127 in k7124 in swap1402 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7143,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g141114121424 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7145 in k7141 in k7138 in k7134 in k7131 in k7127 in k7124 in swap1402 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7150,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g141114121424 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k7148 in k7145 in k7141 in k7138 in k7134 in k7131 in k7127 in k7124 in swap1402 in k7119 in k7116 in k7110 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7098 in k7095 in k7092 in import-name in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7100,2,t0,t1);}
t2=f_9752(((C_word*)((C_word*)t0)[3])[1]);
t3=f_9770(((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* tostr in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_7047(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7047,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7060,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 737  keyword? */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,t2);}}

/* k7058 in tostr in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7060,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7067,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 737  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[190]))(3,*((C_word*)lf[190]+1),t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* expand.scm: 738  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[190]))(3,*((C_word*)lf[190]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
/* expand.scm: 739  number->string */
C_number_to_string(3,0,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* expand.scm: 740  syntax-error */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),((C_word*)t0)[4],((C_word*)t0)[2],lf[191]);}}}}

/* k7065 in k7058 in tostr in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 737  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[188]))(4,*((C_word*)lf[188]+1),((C_word*)t0)[2],t1,lf[189]);}

/* resolve in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7038,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7042,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 734  lookup */
f_3624(t3,t2,C_SCHEME_END_OF_LIST);}

/* k7040 in resolve in k7034 in k7031 in k7028 in k7025 in ##sys#expand-import in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_7042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##sys#er-transformer in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6729,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6731,a[2]=t2,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));}

/* f_6731 in ##sys#er-transformer in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6731,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6734,a[2]=t3,a[3]=t6,a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6997,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6860,a[2]=t4,a[3]=t8,a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 723  handler */
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t1,t2,t7,t9);}

/* compare */
static void C_ccall f_6860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6860,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6864,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_symbolp(t2);
t6=(C_truep(t5)?(C_word)C_i_symbolp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6893,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 694  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t7,t2,lf[12]);}
else{
t7=t4;
f_6864(t7,(C_word)C_eqp(t2,t3));}}

/* k6891 in compare */
static void C_ccall f_6893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6896(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6983,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 695  lookup2 */
f_6997(t3,C_fix(1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k6981 in k6891 in compare */
static void C_ccall f_6983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6896(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6894 in k6891 in compare */
static void C_fcall f_6896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6896,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 697  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t2,((C_word*)t0)[4],lf[12]);}

/* k6897 in k6894 in k6891 in compare */
static void C_ccall f_6899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6902,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6902(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6977,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 698  lookup2 */
f_6997(t3,C_fix(2),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6975 in k6897 in k6894 in k6891 in compare */
static void C_ccall f_6977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6902(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6900 in k6897 in k6894 in k6891 in compare */
static void C_fcall f_6902(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6902,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6921,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 702  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t2,((C_word*)t0)[3],lf[83]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6948,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 704  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}}
else{
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 708  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_6864(t2,(C_word)C_eqp(((C_word*)t0)[3],t1));}}}

/* k6969 in k6900 in k6897 in k6894 in k6891 in compare */
static void C_ccall f_6971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6864(t4,(C_word)C_eqp(((C_word*)t0)[2],t3));}
else{
t3=((C_word*)t0)[3];
f_6864(t3,C_SCHEME_FALSE);}}

/* k6946 in k6900 in k6897 in k6894 in k6891 in compare */
static void C_ccall f_6948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6864(t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[3];
f_6864(t3,C_SCHEME_FALSE);}}

/* k6919 in k6900 in k6897 in k6894 in k6891 in compare */
static void C_ccall f_6921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6921,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6928,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 703  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t3,((C_word*)t0)[3],lf[83]);}

/* k6926 in k6919 in k6900 in k6897 in k6894 in k6891 in compare */
static void C_ccall f_6928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_6864(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k6862 in compare */
static void C_fcall f_6864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6864,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6867,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[186],t6);
/* expand.scm: 713  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t2,t7);}

/* k6865 in k6862 in compare */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup2 */
static void C_fcall f_6997(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6997,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7001,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 716  lookup */
f_3624(t5,t3,t4);}

/* k6999 in lookup2 */
static void C_ccall f_7001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7004,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t4=(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE);
t5=(C_truep(t4)?lf[14]:t1);
/* expand.scm: 717  dd */
((C_proc9)C_retrieve2_symbol_proc(lf[6],"dd"))(9,lf[6],t2,lf[182],t3,lf[183],((C_word*)t0)[2],lf[184],t5,lf[185]);}

/* k7002 in k6999 in lookup2 */
static void C_ccall f_7004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* rename */
static void C_ccall f_6734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6734,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6744,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[47],t6);
t8=(C_word)C_a_i_cons(&a,2,t2,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[178],t8);
/* expand.scm: 674  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t4,t9);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 676  lookup */
f_3624(t4,t2,((C_word*)t0)[2]);}}

/* k6768 in rename */
static void C_ccall f_6770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6770,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6782,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[179],t5);
/* expand.scm: 679  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t2,t6);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6801,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 682  macro-alias */
f_3642(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6831,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 687  macro-alias */
f_3642(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6829 in k6768 in rename */
static void C_ccall f_6831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[181],t5);
/* expand.scm: 688  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t2,t6);}

/* k6832 in k6829 in k6768 in rename */
static void C_ccall f_6834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6834,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6799 in k6768 in rename */
static void C_ccall f_6801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[180],t5);
/* expand.scm: 683  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t2,t6);}

/* k6802 in k6799 in k6768 in rename */
static void C_ccall f_6804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6804,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6780 in k6768 in rename */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6742 in rename */
static void C_ccall f_6744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr5r,(void*)f_6267r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6267r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6267r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6269,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word)li68),tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6672,a[2]=t6,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6681,a[2]=t7,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-culprit10181176 */
t9=t8;
f_6681(t9,t1);}
else{
t9=(C_word)C_i_car(t5);
t10=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-se10191172 */
t11=t7;
f_6672(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body10161025 */
t13=t6;
f_6269(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-culprit1018 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6681(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6681,NULL,2,t0,t1);}
/* def-se10191172 */
t2=((C_word*)t0)[2];
f_6672(t2,t1,C_SCHEME_FALSE);}

/* def-se1019 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6672,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6680,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 588  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t3);}

/* k6678 in def-se1019 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body10161025 */
t2=((C_word*)t0)[4];
f_6269(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6269(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6269,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6284,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word)li59),tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6272,a[2]=t4,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6315,a[2]=((C_word*)t0)[3],a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6371,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t3,a[6]=t6,a[7]=t7,a[8]=t5,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t9=C_mutate((C_word*)lf[139]+1 /* (set! syntax-error-culprit ...) */,t2);
t10=t8;
f_6400(t10,t9);}
else{
t9=t8;
f_6400(t9,C_SCHEME_UNDEFINED);}}

/* k6398 in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6400(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6400,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6405(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k6398 in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6405(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6405,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t3))){
t4=(C_word)C_i_vector_ref(t3,C_fix(0));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6424,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_eqp(t5,C_fix(1));
if(C_truep(t9)){
t10=t8;
f_6424(t10,C_fix(1));}
else{
t10=(C_word)C_fixnum_greaterp(t5,C_fix(2));
t11=t8;
f_6424(t11,(C_truep(t10)?(C_word)C_i_vector_ref(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_immp(t3))){
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 641  err */
t5=((C_word*)t0)[7];
f_6284(t5,t1,lf[155]);}}
else{
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t3;
t5=(C_word)C_eqp(t4,lf[57]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t4,lf[156]);
if(C_truep(t6)){
/* expand.scm: 645  test */
t7=((C_word*)t0)[5];
f_6272(t7,t1,t2,*((C_word*)lf[157]+1),lf[158]);}
else{
t7=(C_word)C_eqp(t4,lf[159]);
if(C_truep(t7)){
/* expand.scm: 646  test */
t8=((C_word*)t0)[5];
f_6272(t8,t1,t2,*((C_word*)lf[160]+1),lf[161]);}
else{
t8=(C_word)C_eqp(t4,lf[162]);
if(C_truep(t8)){
/* expand.scm: 647  test */
t9=((C_word*)t0)[5];
f_6272(t9,t1,t2,*((C_word*)lf[160]+1),lf[163]);}
else{
t9=(C_word)C_eqp(t4,lf[164]);
if(C_truep(t9)){
/* expand.scm: 648  test */
t10=((C_word*)t0)[5];
f_6272(t10,t1,t2,((C_word*)t0)[4],lf[165]);}
else{
t10=(C_word)C_eqp(t4,lf[166]);
if(C_truep(t10)){
/* expand.scm: 649  test */
t11=((C_word*)t0)[5];
f_6272(t11,t1,t2,*((C_word*)lf[167]+1),lf[168]);}
else{
t11=(C_word)C_eqp(t4,lf[169]);
if(C_truep(t11)){
/* expand.scm: 650  test */
t12=((C_word*)t0)[5];
f_6272(t12,t1,t2,*((C_word*)lf[170]+1),lf[171]);}
else{
t12=(C_word)C_eqp(t4,lf[172]);
if(C_truep(t12)){
/* expand.scm: 651  test */
t13=((C_word*)t0)[5];
f_6272(t13,t1,t2,((C_word*)t0)[3],lf[173]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6602,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li66),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 653  test */
t14=((C_word*)t0)[5];
f_6272(t14,t1,t2,t13,lf[174]);}}}}}}}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6643,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 663  walk */
t26=t4;
t27=t5;
t28=t6;
t1=t26;
t2=t27;
t3=t28;
goto loop;}
else{
/* expand.scm: 661  err */
t4=((C_word*)t0)[7];
f_6284(t4,t1,lf[175]);}}
else{
/* expand.scm: 660  err */
t4=((C_word*)t0)[7];
f_6284(t4,t1,lf[176]);}}}}}

/* k6641 in walk in k6398 in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 664  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6405(t4,((C_word*)t0)[2],t2,t3);}

/* a6601 in walk in k6398 in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6602,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6606,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 656  lookup */
f_3624(t3,t2,((C_word*)t0)[2]);}
else{
t4=t3;
f_6606(2,t4,C_SCHEME_FALSE);}}

/* k6604 in a6601 in walk in k6398 in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}

/* k6422 in walk in k6398 in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6424,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6429,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li65),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6429(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop1129 in k6422 in walk in k6398 in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6429(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6429,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* expand.scm: 634  err */
t5=((C_word*)t0)[6];
f_6284(t5,t1,lf[152]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6448,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* expand.scm: 636  err */
t6=((C_word*)t0)[6];
f_6284(t6,t5,lf[153]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
/* expand.scm: 639  walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6405(t7,t5,t6,((C_word*)t0)[2]);}
else{
/* expand.scm: 638  err */
t6=((C_word*)t0)[6];
f_6284(t6,t5,lf[154]);}}}}

/* k6446 in doloop1129 in k6422 in walk in k6398 in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6429(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6371,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6377,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_6377(t2));}

/* loop in proper-list? in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static C_word C_fcall f_6377(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6315,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6319,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 603  ##sys#extended-lambda-list? */
((C_proc3)C_retrieve_symbol_proc(lf[88]))(3,*((C_word*)lf[88]+1),t3,t2);}

/* k6317 in lambda-list? in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6319,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6327,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6327(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k6317 in lambda-list? in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6327(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6327,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6347,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 606  keyword? */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 610  loop */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k6345 in loop in k6317 in lambda-list? in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6272(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6272,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6279,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 591  pred */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k6277 in test in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 591  err */
t2=((C_word*)t0)[3];
f_6284(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6284(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6284,NULL,3,t0,t1,t2);}
t3=C_retrieve(lf[139]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6288,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 595  get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6286 in err in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6295,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6302,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 598  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6313,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 599  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k6311 in k6286 in err in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 599  string-append */
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[150],t1,lf[151],((C_word*)t0)[2]);}

/* k6300 in k6286 in err in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6306,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 598  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k6304 in k6300 in k6286 in err in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 598  string-append */
t2=((C_word*)t0)[5];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],lf[147],((C_word*)t0)[3],lf[148],t1,lf[149],((C_word*)t0)[2]);}

/* k6293 in k6286 in err in body1016 in ##sys#check-syntax in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 596  ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6231,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[138]))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6253,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 577  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[144]))(4,*((C_word*)lf[144]+1),t4,C_retrieve(lf[138]),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6251 in get-line-number in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6220r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6220r(t0,t1,t2);}}

static void C_ccall f_6220r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6228,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 568  ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),t3,t2);}

/* k6226 in ##sys#syntax-error-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],C_retrieve(lf[140]),lf[141],t1);}

/* ##sys#expand-curried-define in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6150,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6153,a[2]=t8,a[3]=t6,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6213,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 557  loop */
t11=((C_word*)t8)[1];
f_6153(t11,t10,t2,t3);}

/* k6211 in ##sys#expand-curried-define in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6213,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6153(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6153,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_i_cdr(t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6179,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6206,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t3,C_SCHEME_END_OF_LIST);}}

/* k6204 in loop in ##sys#expand-curried-define in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6206,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* expand.scm: 556  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6153(t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k6177 in loop in ##sys#expand-curried-define in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6179,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[97],t2));}

/* match-expression in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6067(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6067,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6070,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6148,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 544  mwalk */
t11=((C_word*)t8)[1];
f_6070(t11,t10,t2,t3);}

/* k6146 in match-expression in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in match-expression in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_6070(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6070,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6119,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 541  mwalk */
t13=t4;
t14=t5;
t15=t6;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_i_assq(t3,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t2,t5));}
else{
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[2]))){
t5=(C_word)C_a_i_cons(&a,2,t3,t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}}

/* k6117 in mwalk in match-expression in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 542  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6070(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5314r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5314r(t0,t1,t2,t3);}}

static void C_ccall f_5314r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5318,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 418  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5318(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5318,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5320,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t7,a[6]=((C_word)li46),tmp=(C_word)a,a+=7,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5580,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5757,a[2]=t3,a[3]=t5,a[4]=t1,a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
/* expand.scm: 525  expand */
t11=((C_word*)t7)[1];
f_5757(t11,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5757(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5757,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li50),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5763(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5763(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5763,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_i_car(t7):C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5785,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t1,a[7]=t6,a[8]=t5,a[9]=t8,a[10]=((C_word*)t0)[4],a[11]=t4,a[12]=t3,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t10)){
if(C_truep((C_word)C_i_symbolp(t10))){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6027,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 485  lookup */
f_3624(t12,t10,((C_word*)t0)[5]);}
else{
t12=t11;
f_5785(t12,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5785(t12,C_SCHEME_FALSE);}}
else{
/* expand.scm: 479  fini */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5320(t7,t1,t3,t4,t5,t6,t2);}}

/* k6025 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_6027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5785(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5785(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5785,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(C_word)C_eqp(lf[117],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5803,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 488  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t3,lf[117],((C_word*)t0)[5],lf[133],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t3=(C_word)C_eqp(lf[124],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 510  ##sys#check-syntax */
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),t4,lf[124],((C_word*)t0)[5],lf[134],((C_word*)t0)[13]);}
else{
t4=(C_word)C_eqp(lf[118],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5941,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 513  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t5,lf[118],((C_word*)t0)[5],lf[135],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t5=(C_word)C_eqp(lf[116],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5969,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 516  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t6,lf[116],((C_word*)t0)[5],lf[136],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t6=(C_word)C_i_memq(t1,((C_word*)t0)[12]);
t7=(C_truep(t6)?t6:(C_word)C_i_memq(t1,((C_word*)t0)[8]));
if(C_truep(t7)){
/* expand.scm: 519  fini */
t8=((C_word*)((C_word*)t0)[2])[1];
f_5320(t8,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5995,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 521  ##sys#expand-0 */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),t8,((C_word*)t0)[5],((C_word*)t0)[13]);}}}}}}
else{
/* expand.scm: 486  fini */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5320(t2,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}}

/* k5993 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5995,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* expand.scm: 523  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_5320(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* expand.scm: 524  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5763(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k5967 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5976,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 517  ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k5974 in k5967 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 517  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5763(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5939 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5941,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* expand.scm: 514  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_5763(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k5927 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 511  fini/syntax */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5580(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5801 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5803,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5808,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li49),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5808(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k5801 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5808(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5808,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5855,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 500  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t5,lf[117],t2,lf[129],C_SCHEME_FALSE,((C_word*)t0)[8]);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5877,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 504  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t5,lf[117],t2,lf[130],C_SCHEME_FALSE,((C_word*)t0)[8]);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 492  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t4,lf[117],t2,lf[132],C_SCHEME_FALSE,((C_word*)t0)[8]);}}

/* k5819 in loop2 in k5801 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5821,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[8]):lf[131]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* expand.scm: 493  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_5763(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5875 in loop2 in k5801 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5877,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k5902 in k5875 in loop2 in k5801 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5904,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
/* expand.scm: 505  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5763(t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5853 in loop2 in k5801 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 501  macro-alias */
f_3642(t2,lf[117],((C_word*)t0)[2]);}

/* k5864 in k5853 in loop2 in k5801 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5870,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* expand.scm: 502  ##sys#expand-curried-define */
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t2,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5868 in k5864 in k5853 in loop2 in k5801 in k5783 in loop in expand in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5870,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 501  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5808(t3,((C_word*)t0)[2],t2);}

/* fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5580(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5580,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5588,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5590,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5590(t11,t7,t6,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5590(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5590,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5605,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 460  macro-alias */
f_3642(t5,lf[123],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_length(t7);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_fix(3),t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5739,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 465  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t9,t2);}
else{
t9=t5;
f_5636(t9,C_SCHEME_FALSE);}}
else{
t7=t5;
f_5636(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 462  loop */
t12=t1;
t13=t2;
t14=t3;
t15=C_SCHEME_TRUE;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}}

/* k5737 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5739,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5725,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5735,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 466  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
f_5636(t2,C_SCHEME_FALSE);}}

/* k5733 in k5737 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 466  lookup */
f_3624(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5723 in k5737 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5728,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5728(2,t3,t1);}
else{
/* expand.scm: 466  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[2]);}}

/* k5726 in k5723 in k5737 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5636(t2,(C_word)C_eqp(lf[124],t1));}

/* k5634 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5636(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5636,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5654,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5668,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 471  caadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t6,t2);}
else{
t6=t4;
f_5654(t6,t2);}}
else{
/* expand.scm: 475  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5590(t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_TRUE);}}

/* k5666 in k5634 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5680,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 471  macro-alias */
f_3642(t2,lf[126],((C_word*)t0)[2]);}

/* k5678 in k5666 in k5634 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 471  cdadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t2,((C_word*)t0)[2]);}

/* k5686 in k5678 in k5666 in k5634 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5692,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5690 in k5686 in k5678 in k5666 in k5634 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5692,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
f_5654(t6,(C_word)C_a_i_cons(&a,2,lf[124],t5));}

/* k5652 in k5634 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5654,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* expand.scm: 468  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5590(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k5603 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5613,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5621,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 461  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5619 in k5603 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 461  map */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[122]+1),t1);}

/* k5611 in k5603 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5615 in k5611 in k5603 in loop in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5617,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k5586 in fini/syntax in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 457  fini */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5320(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5320(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5320,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5332,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li41),tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_5332(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5431,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 436  reverse */
t10=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}

/* k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5453,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5560,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5572,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[51]+1),t1,((C_word*)t0)[3]);}

/* k5570 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 439  ##sys#map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5559 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5560,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[121]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5457,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5542,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5558,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 441  reverse */
t6=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5556 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 441  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5541 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5542,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k5459 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5465,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5469,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5475,a[2]=((C_word*)t0)[5],a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 451  reverse */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5534 in k5459 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5540,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 452  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5538 in k5534 in k5459 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 442  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5474 in k5459 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5475,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5479,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 443  ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[18]),t2);}

/* k5477 in a5474 in k5459 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5479,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5506,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5510,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5512,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 448  map */
t8=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a5511 in k5477 in a5474 in k5459 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5512,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k5508 in k5477 in a5474 in k5459 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5504 in k5477 in a5474 in k5459 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[120],t5));}

/* k5467 in k5459 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5473,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5471 in k5467 in k5459 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5463 in k5459 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5455 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5457,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[59],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5437,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[119],t5);
/* expand.scm: 454  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t4,t6);}

/* k5435 in k5455 in k5451 in k5429 in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5332(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5332,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 430  lookup */
f_3624(t7,t6,((C_word*)t0)[4]);}
else{
t7=t5;
f_5355(t7,C_SCHEME_FALSE);}}
else{
t6=t5;
f_5355(t6,C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 424  macro-alias */
f_3642(t4,lf[116],((C_word*)t0)[4]);}}

/* k5344 in loop in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5346,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5419 in loop in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5421,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[117]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_5355(t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5414,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 431  lookup */
f_3624(t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k5412 in k5419 in loop in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_5355(t3,(C_word)C_eqp(t2,lf[118]));}

/* k5353 in loop in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5355(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5355,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5362,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 433  macro-alias */
f_3642(t2,lf[116],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]);
/* expand.scm: 435  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5332(t4,((C_word*)t0)[9],t2,t3);}}

/* k5360 in k5353 in loop in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5366,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5370,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 434  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5368 in k5360 in k5353 in loop in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5378,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 434  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5757(t3,t2,((C_word*)t0)[2]);}

/* k5376 in k5368 in k5360 in k5353 in loop in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5378,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* expand.scm: 434  ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5364 in k5360 in k5353 in loop in fini in k5316 in ##sys#canonicalize-body in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5366,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4724,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4727,a[2]=t2,a[3]=t4,a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4744,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t10,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 325  macro-alias */
f_3642(t11,lf[113],t5);}

/* k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 327  macro-alias */
f_3642(t2,lf[112],((C_word*)t0)[4]);}

/* k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 328  macro-alias */
f_3642(t2,lf[111],((C_word*)t0)[4]);}

/* k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 329  macro-alias */
f_3642(t2,lf[110],((C_word*)t0)[4]);}

/* k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* expand.scm: 330  macro-alias */
f_3642(t2,lf[58],((C_word*)t0)[4]);}

/* k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4756,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4761,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word)li39),tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_4761(t5,((C_word*)t0)[3],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4761(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4761,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4775,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t5,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t4,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)((C_word*)t0)[13])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5028,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 338  reverse */
t9=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}
else{
/* expand.scm: 338  reverse */
t8=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* expand.scm: 366  err */
t7=((C_word*)t0)[4];
f_4727(t7,t1,lf[99]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5049,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[13])[1];
if(C_truep(t8)){
t9=t7;
f_5049(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t6);
t10=t7;
f_5049(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5072,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[3],a[11]=t2,a[12]=t6,a[13]=t7,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t7))){
/* expand.scm: 375  lookup */
f_3624(t8,t7,((C_word*)t0)[2]);}
else{
t9=t8;
f_5072(2,t9,C_SCHEME_FALSE);}}
else{
/* expand.scm: 372  err */
t7=((C_word*)t0)[4];
f_4727(t7,t1,lf[109]);}}}}

/* k5070 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5072,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[13]);
t3=(C_word)C_i_cdr(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t2,lf[90]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5087,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t6)){
t7=t5;
f_5087(t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5106,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 379  macro-alias */
f_3642(t7,lf[101],((C_word*)t0)[5]);}}
else{
t5=(C_word)C_eqp(t2,lf[89]);
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[11],C_fix(1)))){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5124,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[4],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_5124(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_5124(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 391  err */
t6=((C_word*)t0)[7];
f_4727(t6,((C_word*)t0)[9],lf[103]);}}
else{
t6=(C_word)C_eqp(t2,lf[91]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5170,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t8)){
t9=t7;
f_5170(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5189,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 393  macro-alias */
f_3642(t9,lf[101],((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t7=((C_word*)t0)[11];
switch(t7){
case C_fix(0):
t8=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
/* expand.scm: 400  loop */
t9=((C_word*)((C_word*)t0)[10])[1];
f_4761(t9,((C_word*)t0)[9],C_fix(0),t8,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3);
case C_fix(1):
t8=(C_word)C_a_i_list(&a,2,t2,C_SCHEME_FALSE);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[3]);
/* expand.scm: 401  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4761(t10,((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8],t9,C_SCHEME_END_OF_LIST,t3);
case C_fix(2):
/* expand.scm: 402  err */
t8=((C_word*)t0)[7];
f_4727(t8,((C_word*)t0)[9],lf[105]);
default:
t8=(C_word)C_a_i_list(&a,1,t2);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[2]);
/* expand.scm: 403  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4761(t10,((C_word*)t0)[9],C_fix(3),((C_word*)t0)[8],((C_word*)t0)[3],t9,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5251,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t8=(C_word)C_i_length(t2);
t9=t7;
f_5251(t9,(C_word)C_eqp(C_fix(2),t8));}
else{
t8=t7;
f_5251(t8,C_SCHEME_FALSE);}}}}}}

/* k5249 in k5070 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5251,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* expand.scm: 406  err */
t3=((C_word*)t0)[9];
f_4727(t3,((C_word*)t0)[8],lf[106]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* expand.scm: 407  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4761(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* expand.scm: 408  err */
t3=((C_word*)t0)[9];
f_4727(t3,((C_word*)t0)[8],lf[107]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* expand.scm: 409  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4761(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* expand.scm: 410  err */
t2=((C_word*)t0)[9];
f_4727(t2,((C_word*)t0)[8],lf[108]);}}

/* k5187 in k5070 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5170(t3,t2);}

/* k5168 in k5070 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5170(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* expand.scm: 395  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_4761(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 396  err */
t2=((C_word*)t0)[2];
f_4727(t2,((C_word*)t0)[6],lf[104]);}}

/* k5122 in k5070 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5124,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5127,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_5127(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_5127(t6,t5);}}
else{
/* expand.scm: 390  err */
t2=((C_word*)t0)[2];
f_4727(t2,((C_word*)t0)[6],lf[102]);}}

/* k5125 in k5122 in k5070 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 389  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4761(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k5104 in k5070 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5087(t3,t2);}

/* k5085 in k5070 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* expand.scm: 381  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4761(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 382  err */
t3=((C_word*)t0)[2];
f_4727(t3,((C_word*)t0)[5],lf[100]);}}

/* k5047 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_5049(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* expand.scm: 370  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4761(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k5026 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 338  ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t3=t2;
f_4779(t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4948,a[2]=((C_word*)t0)[11],a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5021,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 350  reverse */
t6=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}

/* k5019 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4947 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4948,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5017,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* expand.scm: 322  string->keyword */
((C_proc3)C_retrieve_symbol_proc(lf[98]))(3,*((C_word*)lf[98]+1),t4,t5);}

/* k5015 in a4947 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5017,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4983,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5001,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t7=t5;
f_4983(t7,C_SCHEME_END_OF_LIST);}}

/* k4999 in k5015 in a4947 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5001,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=((C_word*)t0)[2];
f_4983(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4981 in k5015 in a4947 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4983(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4977 in k5015 in a4947 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4979,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[96],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k4940 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4944 in k4940 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4946,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4779(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4777 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4779(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4779,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[10]))){
t3=t2;
f_4782(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t4)){
t5=t3;
f_4791(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[10]);
t6=t3;
f_4791(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_4791(t5,C_SCHEME_FALSE);}}}}

/* k4789 in k4777 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4791(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4791,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4818,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 355  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[5]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4863,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 359  reverse */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4894,a[2]=t4,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 362  reverse */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}}

/* k4892 in k4789 in k4777 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4894,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* expand.scm: 362  ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4884 in k4789 in k4777 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4888 in k4884 in k4789 in k4777 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4890,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4782(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4861 in k4789 in k4777 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4865 in k4861 in k4789 in k4777 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4867,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4782(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4816 in k4789 in k4777 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 355  cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[94]+1)))(3,*((C_word*)lf[94]+1),t2,((C_word*)t0)[2]);}

/* k4836 in k4816 in k4789 in k4777 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4838,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4808 in k4836 in k4816 in k4789 in k4777 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4782(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4780 in k4777 in k4773 in loop in k4754 in k4751 in k4748 in k4745 in k4742 in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4782(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 337  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4727(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4727,NULL,3,t0,t1,t2);}
/* expand.scm: 321  errh */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4681,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4687,a[2]=t4,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4687(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4687(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4687,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[89]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4706(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[90]);
t7=t5;
f_4706(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[91])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4704 in loop in ##sys#extended-lambda-list? in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 315  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4687(t3,((C_word*)t0)[4],t2);}}

/* ##sys#expand in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4628r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4628r(t0,t1,t2,t3);}}

static void C_ccall f_4628r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4632,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 288  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4632(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4630 in ##sys#expand in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4632,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4637,a[2]=t3,a[3]=t1,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4637(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4630 in ##sys#expand in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4637(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4637,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4643,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4649,a[2]=((C_word*)t0)[2],a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a4648 in loop in k4630 in ##sys#expand in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4649,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* expand.scm: 292  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4637(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a4642 in loop in k4630 in ##sys#expand in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4643,2,t0,t1);}
/* expand.scm: 290  ##sys#expand-0 */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4538,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4541,a[2]=t3,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4574,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 268  ##sys#qualified-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t5,t2);}

/* k4572 in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4574,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 269  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t2,((C_word*)t0)[3],lf[83]);}}

/* k4575 in k4572 in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4577,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4583,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 271  dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t2,lf[81],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 273  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t2,((C_word*)t0)[3],lf[85]);}}

/* k4587 in k4575 in k4572 in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 274  dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t2,lf[82],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 276  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t2);}}

/* k4624 in k4587 in k4575 in k4572 in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4626,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 278  dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t3,lf[84],((C_word*)t0)[4]);}
else{
/* expand.scm: 283  mrename */
t3=((C_word*)t0)[3];
f_4541(t3,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k4599 in k4624 in k4587 in k4575 in k4572 in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t2))){
/* expand.scm: 281  mrename */
t3=((C_word*)t0)[4];
f_4541(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4616,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 282  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t3,t2,lf[83]);}}

/* k4614 in k4599 in k4624 in k4587 in k4575 in k4572 in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4590 in k4587 in k4575 in k4572 in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4581 in k4575 in k4572 in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* mrename in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4541(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4541,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4545,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 262  ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t3);}

/* k4543 in mrename in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4545,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4551,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 264  module-name */
t4=C_retrieve2(lf[76],"module-name");
f_9590(3,t4,t3,t1);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k4566 in k4543 in mrename in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 264  dm */
((C_proc6)C_retrieve2_symbol_proc(lf[7],"dm"))(6,lf[7],((C_word*)t0)[3],lf[78],((C_word*)t0)[2],lf[79],t1);}

/* k4549 in k4543 in mrename in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4554(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 265  ##sys#register-undefined */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k4552 in k4549 in k4543 in mrename in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 266  module-name */
t3=C_retrieve2(lf[76],"module-name");
f_9590(3,t3,t2,((C_word*)t0)[2]);}

/* k4559 in k4552 in k4549 in k4543 in mrename in ##sys#alias-global-hook in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 266  ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#module-rename in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4520,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4528,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 255  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),t4,t5,lf[75],t6);}

/* k4526 in ##sys#module-rename in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 254  ##sys#string->symbol */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),((C_word*)t0)[2],t1);}

/* ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4038,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4041,a[2]=t3,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4220,a[2]=t4,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4337,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t7,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 220  lookup */
f_3624(t8,t6,t3);}
else{
/* expand.scm: 248  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* expand.scm: 249  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4337,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[7]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=t5;
f_4343(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4504,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4511,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 222  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t7);}}

/* k4509 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 222  lookup */
f_3624(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4502 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4343(t4,t3);}

/* k4341 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4343(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4343,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[58]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4352,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 224  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t3,lf[58],((C_word*)t0)[7],lf[66],C_SCHEME_FALSE,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t4,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[71]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=t3;
f_4445(t6,(C_word)C_i_pairp(t5));}
else{
t5=t3;
f_4445(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4445(t5,C_SCHEME_FALSE);}}}

/* k4443 in k4341 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4445,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 241  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t3,lf[69],((C_word*)t0)[8],lf[70],C_SCHEME_FALSE,((C_word*)t0)[6]);}
else{
/* expand.scm: 247  expand */
t2=((C_word*)t0)[5];
f_4220(t2,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4449 in k4443 in k4341 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[67],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* expand.scm: 243  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[68]+1)))(5,*((C_word*)lf[68]+1),t2,t5,t6,t7);}

/* k4456 in k4449 in k4443 in k4341 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 242  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k4350 in k4341 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4352,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 227  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t3,lf[58],((C_word*)t0)[5],lf[65],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
/* expand.scm: 236  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4362 in k4350 in k4341 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4422,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4432,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a4431 in k4362 in k4350 in k4341 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4432,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k4420 in k4362 in k4350 in k4341 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4426,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k4424 in k4420 in k4362 in k4350 in k4341 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4426,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[60],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[61],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4386,a[2]=((C_word*)t0)[3],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4390,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 234  ##sys#map */
t12=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[63]+1),((C_word*)t0)[2]);}

/* k4388 in k4424 in k4420 in k4362 in k4350 in k4341 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4384 in k4424 in k4420 in k4362 in k4350 in k4341 in k4335 in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4386,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[62],t2);
/* expand.scm: 229  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4220(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4220,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4224,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4277,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 201  get */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t6,t2,lf[12]);}

/* k4275 in expand in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_symbolp(t1);
t4=t2;
f_4280(t4,(C_truep(t3)?t1:lf[14]));}
else{
t3=t2;
f_4280(t3,lf[57]);}}

/* k4278 in k4275 in expand in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4280,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4302,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4306,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 206  map-se */
f_3691(t4,t5);}
else{
t3=t2;
f_4292(t3,((C_word*)t0)[2]);}}

/* k4304 in k4278 in k4275 in expand in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4300 in k4278 in k4275 in expand in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4302,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4292(t2,(C_word)C_a_i_cons(&a,2,lf[56],t1));}

/* k4290 in k4278 in k4275 in expand in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4292,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[55],t5);
/* expand.scm: 199  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],((C_word*)t0)[2],t6);}

/* k4222 in expand in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4224,2,t0,t1);}
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4246,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 213  call-handler */
t5=((C_word*)t0)[3];
f_4041(t5,t2,((C_word*)t0)[2],t3,((C_word*)t0)[6],t4);}
else{
/* expand.scm: 215  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[6],C_SCHEME_FALSE);}}
else{
/* expand.scm: 209  ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),((C_word*)t0)[4],lf[54],((C_word*)t0)[6]);}}

/* k4244 in k4222 in expand in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 211  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4041(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4041,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4045,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 166  dd */
((C_proc4)C_retrieve2_symbol_proc(lf[6],"dd"))(4,lf[6],t6,lf[52],t2);}

/* k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4214,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4218,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 167  map-se */
f_3691(t4,((C_word*)t0)[3]);}

/* k4216 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4212 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4214,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[50],t1);
/* expand.scm: 167  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],((C_word*)t0)[2],t2);}

/* k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[49]+1)))(3,*((C_word*)lf[49]+1),t2,t3);}

/* a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4056,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4062,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4169,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li22),tmp=(C_word)a,a+=9,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[48]))(4,*((C_word*)lf[48]+1),t1,t3,t4);}

/* a4168 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li19),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4196,a[2]=((C_word*)t0)[2],a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4195 in a4168 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4196r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4196r(t0,t1,t2);}}

static void C_ccall f_4196r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4202,a[2]=t2,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* k261266 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4201 in a4195 in a4168 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4202,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4174 in a4168 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4179,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 195  handler */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4177 in a4174 in a4168 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4182,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
/* expand.scm: 196  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t2,t5);}

/* k4180 in k4177 in a4174 in a4168 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4061 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4062,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4068,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
/* k261266 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4067 in a4061 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4076,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[3],lf[40]))){
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=t3;
f_4079(t5,(C_word)C_i_memq(lf[46],t4));}
else{
t4=t3;
f_4079(t4,C_SCHEME_FALSE);}}

/* k4077 in a4067 in a4061 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4079(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4079,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4090,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4096,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4096(t8,t3,t4);}
else{
t2=((C_word*)t0)[3];
f_4076(t2,((C_word*)t0)[4]);}}

/* copy in k4077 in a4067 in a4061 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4096(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4096,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_equalp(lf[45],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=t5;
f_4115(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_4115(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_4115(t6,C_SCHEME_FALSE);}}}

/* k4113 in copy in k4077 in a4067 in a4061 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4115,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4126,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 187  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[42]+1)))(6,*((C_word*)lf[42]+1),t2,lf[43],t3,lf[44],t4);}
else{
/* expand.scm: 193  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4096(t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k4124 in k4113 in copy in k4077 in a4067 in a4061 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4126,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[41],t3));}

/* k4088 in k4077 in a4067 in a4061 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4090,2,t0,t1);}
t2=((C_word*)t0)[3];
f_4076(t2,(C_word)C_a_i_record(&a,3,lf[40],((C_word*)t0)[2],t1));}

/* k4074 in a4067 in a4061 in a4055 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_4076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 171  ##sys#abort */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t1);}

/* k4052 in k4046 in k4043 in call-handler in ##sys#expand-0 in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4029,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[37]);
/* expand.scm: 159  ##sys#unregister-macro */
((C_proc3)C_retrieve_symbol_proc(lf[35]))(3,*((C_word*)lf[35]+1),t1,t2);}

/* ##sys#unregister-macro in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3978,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3986,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3990,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 152  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}

/* k3988 in ##sys#unregister-macro in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3992,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3992(t5,((C_word*)t0)[2],t1);}

/* loop in k3988 in ##sys#unregister-macro in k3870 in k3620 in k3616 in k3589 */
static void C_fcall f_3992(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3992,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4027,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 154  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,t2);}}

/* k4025 in loop in k3988 in ##sys#unregister-macro in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4027,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4019,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 155  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3992(t6,t4,t5);}}

/* k4017 in k4025 in loop in k3988 in ##sys#unregister-macro in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3984 in ##sys#unregister-macro in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 150  ##sys#macro-environment */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),((C_word*)t0)[2],t1);}

/* macro? in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3922r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3922r(t0,t1,t2,t3);}}

static void C_ccall f_3922r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3926,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 141  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3926(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3924 in macro? in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3926,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[3],lf[34]);
t3=(C_word)C_i_check_list_2(t1,lf[34]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 144  lookup */
f_3624(t4,((C_word*)t0)[3],t1);}

/* k3933 in k3924 in macro? in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3935,2,t0,t1);}
t2=(C_word)C_i_pairp(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 146  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}}

/* k3952 in k3933 in k3924 in macro? in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 146  lookup */
f_3624(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3942 in k3933 in k3924 in macro? in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE));}

/* ##sys#copy-macro in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3909,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3913,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3920,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 138  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t5);}

/* k3918 in ##sys#copy-macro in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 138  lookup */
f_3624(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3911 in ##sys#copy-macro in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],C_retrieve(lf[32]),((C_word*)t0)[2],t1);}

/* ##sys#extend-macro-environment in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3876,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3880,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 127  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t5);}

/* k3878 in ##sys#extend-macro-environment in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3883,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 128  lookup */
f_3624(t2,((C_word*)t0)[2],t1);}

/* k3881 in k3878 in ##sys#extend-macro-environment in k3870 in k3620 in k3616 in k3589 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_set_car(t1,((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(t1);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[4]));}
else{
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
/* expand.scm: 133  ##sys#macro-environment */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),((C_word*)t0)[5],t3);}}

/* ##sys#strip-syntax in k3620 in k3616 in k3589 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_3721r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3721r(t0,t1,t2,t3);}}

static void C_ccall f_3721r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3723,a[2]=t2,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3816,a[2]=t4,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3821,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-se102142 */
t7=t6;
f_3821(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-alias103138 */
t9=t5;
f_3816(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body100109 */
t11=t4;
f_3723(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-se102 in ##sys#strip-syntax in k3620 in k3616 in k3589 */
static void C_fcall f_3821(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3821,NULL,2,t0,t1);}
/* def-alias103138 */
t2=((C_word*)t0)[2];
f_3816(t2,t1,C_SCHEME_FALSE);}

/* def-alias103 in ##sys#strip-syntax in k3620 in k3616 in k3589 */
static void C_fcall f_3816(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3816,NULL,3,t0,t1,t2);}
/* body100109 */
t3=((C_word*)t0)[2];
f_3723(t3,t1,t2,C_SCHEME_FALSE);}

/* body100 in ##sys#strip-syntax in k3620 in k3616 in k3589 */
static void C_fcall f_3723(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3723,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3729,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3729(3,t7,t1,((C_word*)t0)[2]);}

/* walk in body100 in ##sys#strip-syntax in k3620 in k3616 in k3589 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3729,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* expand.scm: 103  lookup */
f_3624(t3,t2,((C_word*)t0)[3]);}
else{
/* expand.scm: 104  get */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t3,t2,lf[12]);}}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3786,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* expand.scm: 111  walk */
t9=t3;
t10=t4;
t1=t9;
t2=t10;
c=3;
goto loop;}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3811,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 114  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t4,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}}

/* k3813 in walk in body100 in ##sys#strip-syntax in k3620 in k3616 in k3589 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3809 in walk in body100 in ##sys#strip-syntax in k3620 in k3616 in k3589 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 114  list->vector */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3784 in walk in body100 in ##sys#strip-syntax in k3620 in k3616 in k3589 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3790,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 112  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3729(3,t4,t2,t3);}

/* k3788 in k3784 in walk in body100 in ##sys#strip-syntax in k3620 in k3616 in k3589 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3737 in walk in body100 in ##sys#strip-syntax in k3620 in k3616 in k3589 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3745,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[2]);
t4=t2;
f_3745(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3745(t3,C_SCHEME_FALSE);}}

/* k3743 in k3737 in walk in body100 in ##sys#strip-syntax in k3620 in k3616 in k3589 */
static void C_fcall f_3745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* expand.scm: 106  ##sys#alias-global-hook */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[2];
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[2]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?((C_word*)t0)[3]:((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}}

/* map-se in k3620 in k3616 in k3589 */
static void C_fcall f_3691(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3691,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3697,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a3696 in map-se in k3620 in k3616 in k3589 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3697,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_symbolp(t4);
t6=(C_truep(t5)?(C_word)C_i_cdr(t2):lf[14]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t3,t6));}

/* macro-alias in k3620 in k3616 in k3589 */
static void C_fcall f_3642(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3642,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3649,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 78   ##sys#qualified-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t4,t2);}

/* k3647 in macro-alias in k3620 in k3616 in k3589 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3652(t3,t1);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(C_word)C_fixnum_greaterp(t4,C_fix(0));
t6=t2;
f_3652(t6,(C_truep(t5)?(C_word)C_eqp(C_make_character(35),(C_word)C_subchar(t3,C_fix(0))):C_SCHEME_FALSE));}}

/* k3650 in k3647 in macro-alias in k3620 in k3616 in k3589 */
static void C_fcall f_3652(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3652,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 84   gensym */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[3]);}}

/* k3653 in k3650 in k3647 in macro-alias in k3620 in k3616 in k3589 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3658,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 85   lookup */
f_3624(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k3656 in k3653 in k3650 in k3647 in macro-alias in k3620 in k3616 in k3589 */
static void C_ccall f_3658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3658,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3664,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 86   ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[17]))(5,*((C_word*)lf[17]+1),t3,((C_word*)t0)[2],lf[12],t2);}

/* k3662 in k3656 in k3653 in k3650 in k3647 in macro-alias in k3620 in k3616 in k3589 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_pairp(((C_word*)t0)[2]);
t4=(C_truep(t3)?lf[14]:((C_word*)t0)[2]);
/* expand.scm: 87   dd */
((C_proc6)C_retrieve2_symbol_proc(lf[6],"dd"))(6,lf[6],t2,lf[15],((C_word*)t0)[3],lf[16],t4);}

/* k3665 in k3662 in k3656 in k3653 in k3650 in k3647 in macro-alias in k3620 in k3616 in k3589 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup in k3620 in k3616 in k3589 */
static void C_fcall f_3624(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3624,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cdr(t4));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3637,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 74   ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t5,t2,lf[12]);}}

/* k3635 in lookup in k3620 in k3616 in k3589 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:C_SCHEME_FALSE));}

/* d in k3589 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3593r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3593r(t0,t1,t2,t3);}}

static void C_ccall f_3593r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_fudge(C_fix(13)))){
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 43   pp */
((C_proc3)C_retrieve_symbol_proc(lf[4]))(3,*((C_word*)lf[4]+1),t1,t2);}
else{
C_apply(5,0,t1,*((C_word*)lf[5]+1),t2,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[900] = {
{"toplevel:expand_scm",(void*)C_expand_toplevel},
{"f_3591:expand_scm",(void*)f_3591},
{"f_3618:expand_scm",(void*)f_3618},
{"f_3622:expand_scm",(void*)f_3622},
{"f_3872:expand_scm",(void*)f_3872},
{"f_13981:expand_scm",(void*)f_13981},
{"f_13979:expand_scm",(void*)f_13979},
{"f_7868:expand_scm",(void*)f_7868},
{"f_13971:expand_scm",(void*)f_13971},
{"f_13969:expand_scm",(void*)f_13969},
{"f_7871:expand_scm",(void*)f_7871},
{"f_7875:expand_scm",(void*)f_7875},
{"f_13829:expand_scm",(void*)f_13829},
{"f_13839:expand_scm",(void*)f_13839},
{"f_13855:expand_scm",(void*)f_13855},
{"f_13858:expand_scm",(void*)f_13858},
{"f_13886:expand_scm",(void*)f_13886},
{"f_13861:expand_scm",(void*)f_13861},
{"f_13908:expand_scm",(void*)f_13908},
{"f_13911:expand_scm",(void*)f_13911},
{"f_13957:expand_scm",(void*)f_13957},
{"f_13914:expand_scm",(void*)f_13914},
{"f_13937:expand_scm",(void*)f_13937},
{"f_13949:expand_scm",(void*)f_13949},
{"f_13895:expand_scm",(void*)f_13895},
{"f_13898:expand_scm",(void*)f_13898},
{"f_13905:expand_scm",(void*)f_13905},
{"f_13827:expand_scm",(void*)f_13827},
{"f_7878:expand_scm",(void*)f_7878},
{"f_13770:expand_scm",(void*)f_13770},
{"f_13799:expand_scm",(void*)f_13799},
{"f_13819:expand_scm",(void*)f_13819},
{"f_13823:expand_scm",(void*)f_13823},
{"f_13768:expand_scm",(void*)f_13768},
{"f_7881:expand_scm",(void*)f_7881},
{"f_13680:expand_scm",(void*)f_13680},
{"f_13705:expand_scm",(void*)f_13705},
{"f_13712:expand_scm",(void*)f_13712},
{"f_13732:expand_scm",(void*)f_13732},
{"f_13752:expand_scm",(void*)f_13752},
{"f_13756:expand_scm",(void*)f_13756},
{"f_13678:expand_scm",(void*)f_13678},
{"f_7884:expand_scm",(void*)f_7884},
{"f_13347:expand_scm",(void*)f_13347},
{"f_13354:expand_scm",(void*)f_13354},
{"f_13357:expand_scm",(void*)f_13357},
{"f_13360:expand_scm",(void*)f_13360},
{"f_13363:expand_scm",(void*)f_13363},
{"f_13366:expand_scm",(void*)f_13366},
{"f_13369:expand_scm",(void*)f_13369},
{"f_13372:expand_scm",(void*)f_13372},
{"f_13377:expand_scm",(void*)f_13377},
{"f_13393:expand_scm",(void*)f_13393},
{"f_13399:expand_scm",(void*)f_13399},
{"f_13441:expand_scm",(void*)f_13441},
{"f_13509:expand_scm",(void*)f_13509},
{"f_13634:expand_scm",(void*)f_13634},
{"f_13630:expand_scm",(void*)f_13630},
{"f_13512:expand_scm",(void*)f_13512},
{"f_13567:expand_scm",(void*)f_13567},
{"f_13444:expand_scm",(void*)f_13444},
{"f_13483:expand_scm",(void*)f_13483},
{"f_13435:expand_scm",(void*)f_13435},
{"f_13406:expand_scm",(void*)f_13406},
{"f_13345:expand_scm",(void*)f_13345},
{"f_7887:expand_scm",(void*)f_7887},
{"f_13177:expand_scm",(void*)f_13177},
{"f_13181:expand_scm",(void*)f_13181},
{"f_13190:expand_scm",(void*)f_13190},
{"f_13193:expand_scm",(void*)f_13193},
{"f_13196:expand_scm",(void*)f_13196},
{"f_13199:expand_scm",(void*)f_13199},
{"f_13202:expand_scm",(void*)f_13202},
{"f_13223:expand_scm",(void*)f_13223},
{"f_13239:expand_scm",(void*)f_13239},
{"f_13245:expand_scm",(void*)f_13245},
{"f_13301:expand_scm",(void*)f_13301},
{"f_13299:expand_scm",(void*)f_13299},
{"f_13295:expand_scm",(void*)f_13295},
{"f_13287:expand_scm",(void*)f_13287},
{"f_13283:expand_scm",(void*)f_13283},
{"f_13252:expand_scm",(void*)f_13252},
{"f_13221:expand_scm",(void*)f_13221},
{"f_13175:expand_scm",(void*)f_13175},
{"f_7890:expand_scm",(void*)f_7890},
{"f_13108:expand_scm",(void*)f_13108},
{"f_13112:expand_scm",(void*)f_13112},
{"f_13121:expand_scm",(void*)f_13121},
{"f_13126:expand_scm",(void*)f_13126},
{"f_13163:expand_scm",(void*)f_13163},
{"f_13144:expand_scm",(void*)f_13144},
{"f_13106:expand_scm",(void*)f_13106},
{"f_7893:expand_scm",(void*)f_7893},
{"f_12926:expand_scm",(void*)f_12926},
{"f_12930:expand_scm",(void*)f_12930},
{"f_12942:expand_scm",(void*)f_12942},
{"f_12945:expand_scm",(void*)f_12945},
{"f_12948:expand_scm",(void*)f_12948},
{"f_12951:expand_scm",(void*)f_12951},
{"f_13086:expand_scm",(void*)f_13086},
{"f_12966:expand_scm",(void*)f_12966},
{"f_13084:expand_scm",(void*)f_13084},
{"f_12993:expand_scm",(void*)f_12993},
{"f_13074:expand_scm",(void*)f_13074},
{"f_13009:expand_scm",(void*)f_13009},
{"f_13031:expand_scm",(void*)f_13031},
{"f_13029:expand_scm",(void*)f_13029},
{"f_13025:expand_scm",(void*)f_13025},
{"f_12924:expand_scm",(void*)f_12924},
{"f_7896:expand_scm",(void*)f_7896},
{"f_12531:expand_scm",(void*)f_12531},
{"f_12535:expand_scm",(void*)f_12535},
{"f_12538:expand_scm",(void*)f_12538},
{"f_12541:expand_scm",(void*)f_12541},
{"f_12544:expand_scm",(void*)f_12544},
{"f_12913:expand_scm",(void*)f_12913},
{"f_12825:expand_scm",(void*)f_12825},
{"f_12829:expand_scm",(void*)f_12829},
{"f_12854:expand_scm",(void*)f_12854},
{"f_12900:expand_scm",(void*)f_12900},
{"f_12885:expand_scm",(void*)f_12885},
{"f_12556:expand_scm",(void*)f_12556},
{"f_12603:expand_scm",(void*)f_12603},
{"f_12650:expand_scm",(void*)f_12650},
{"f_12811:expand_scm",(void*)f_12811},
{"f_12819:expand_scm",(void*)f_12819},
{"f_12797:expand_scm",(void*)f_12797},
{"f_12786:expand_scm",(void*)f_12786},
{"f_12794:expand_scm",(void*)f_12794},
{"f_12771:expand_scm",(void*)f_12771},
{"f_12759:expand_scm",(void*)f_12759},
{"f_12740:expand_scm",(void*)f_12740},
{"f_12698:expand_scm",(void*)f_12698},
{"f_12675:expand_scm",(void*)f_12675},
{"f_12629:expand_scm",(void*)f_12629},
{"f_12578:expand_scm",(void*)f_12578},
{"f_12574:expand_scm",(void*)f_12574},
{"f_12546:expand_scm",(void*)f_12546},
{"f_12554:expand_scm",(void*)f_12554},
{"f_12529:expand_scm",(void*)f_12529},
{"f_7899:expand_scm",(void*)f_7899},
{"f_12498:expand_scm",(void*)f_12498},
{"f_12502:expand_scm",(void*)f_12502},
{"f_12496:expand_scm",(void*)f_12496},
{"f_7902:expand_scm",(void*)f_7902},
{"f_12214:expand_scm",(void*)f_12214},
{"f_12221:expand_scm",(void*)f_12221},
{"f_12224:expand_scm",(void*)f_12224},
{"f_12227:expand_scm",(void*)f_12227},
{"f_12230:expand_scm",(void*)f_12230},
{"f_12233:expand_scm",(void*)f_12233},
{"f_12395:expand_scm",(void*)f_12395},
{"f_12448:expand_scm",(void*)f_12448},
{"f_12470:expand_scm",(void*)f_12470},
{"f_12477:expand_scm",(void*)f_12477},
{"f_12464:expand_scm",(void*)f_12464},
{"f_12411:expand_scm",(void*)f_12411},
{"f_12409:expand_scm",(void*)f_12409},
{"f_12245:expand_scm",(void*)f_12245},
{"f_12276:expand_scm",(void*)f_12276},
{"f_12322:expand_scm",(void*)f_12322},
{"f_12372:expand_scm",(void*)f_12372},
{"f_12379:expand_scm",(void*)f_12379},
{"f_12337:expand_scm",(void*)f_12337},
{"f_12351:expand_scm",(void*)f_12351},
{"f_12294:expand_scm",(void*)f_12294},
{"f_12305:expand_scm",(void*)f_12305},
{"f_12235:expand_scm",(void*)f_12235},
{"f_12212:expand_scm",(void*)f_12212},
{"f_7905:expand_scm",(void*)f_7905},
{"f_12193:expand_scm",(void*)f_12193},
{"f_12191:expand_scm",(void*)f_12191},
{"f_7908:expand_scm",(void*)f_7908},
{"f_12172:expand_scm",(void*)f_12172},
{"f_12170:expand_scm",(void*)f_12170},
{"f_7911:expand_scm",(void*)f_7911},
{"f_12121:expand_scm",(void*)f_12121},
{"f_12125:expand_scm",(void*)f_12125},
{"f_12162:expand_scm",(void*)f_12162},
{"f_12155:expand_scm",(void*)f_12155},
{"f_12148:expand_scm",(void*)f_12148},
{"f_12119:expand_scm",(void*)f_12119},
{"f_7914:expand_scm",(void*)f_7914},
{"f_12067:expand_scm",(void*)f_12067},
{"f_12071:expand_scm",(void*)f_12071},
{"f_12074:expand_scm",(void*)f_12074},
{"f_12111:expand_scm",(void*)f_12111},
{"f_12077:expand_scm",(void*)f_12077},
{"f_12092:expand_scm",(void*)f_12092},
{"f_12096:expand_scm",(void*)f_12096},
{"f_12065:expand_scm",(void*)f_12065},
{"f_7917:expand_scm",(void*)f_7917},
{"f_11964:expand_scm",(void*)f_11964},
{"f_11971:expand_scm",(void*)f_11971},
{"f_11974:expand_scm",(void*)f_11974},
{"f_11994:expand_scm",(void*)f_11994},
{"f_12016:expand_scm",(void*)f_12016},
{"f_12001:expand_scm",(void*)f_12001},
{"f_12008:expand_scm",(void*)f_12008},
{"f_11977:expand_scm",(void*)f_11977},
{"f_11992:expand_scm",(void*)f_11992},
{"f_11984:expand_scm",(void*)f_11984},
{"f_11980:expand_scm",(void*)f_11980},
{"f_11962:expand_scm",(void*)f_11962},
{"f_7920:expand_scm",(void*)f_7920},
{"f_11927:expand_scm",(void*)f_11927},
{"f_11931:expand_scm",(void*)f_11931},
{"f_11949:expand_scm",(void*)f_11949},
{"f_11940:expand_scm",(void*)f_11940},
{"f_11925:expand_scm",(void*)f_11925},
{"f_7923:expand_scm",(void*)f_7923},
{"f_9568:expand_scm",(void*)f_9568},
{"f_11921:expand_scm",(void*)f_11921},
{"f_9572:expand_scm",(void*)f_9572},
{"f_9576:expand_scm",(void*)f_9576},
{"f_11879:expand_scm",(void*)f_11879},
{"f_11887:expand_scm",(void*)f_11887},
{"f_11889:expand_scm",(void*)f_11889},
{"f_11910:expand_scm",(void*)f_11910},
{"f_11333:expand_scm",(void*)f_11333},
{"f_11340:expand_scm",(void*)f_11340},
{"f_11860:expand_scm",(void*)f_11860},
{"f_11872:expand_scm",(void*)f_11872},
{"f_11349:expand_scm",(void*)f_11349},
{"f_11817:expand_scm",(void*)f_11817},
{"f_11819:expand_scm",(void*)f_11819},
{"f_11858:expand_scm",(void*)f_11858},
{"f_11832:expand_scm",(void*)f_11832},
{"f_11843:expand_scm",(void*)f_11843},
{"f_11352:expand_scm",(void*)f_11352},
{"f_11686:expand_scm",(void*)f_11686},
{"f_11737:expand_scm",(void*)f_11737},
{"f_11791:expand_scm",(void*)f_11791},
{"f_11749:expand_scm",(void*)f_11749},
{"f_11777:expand_scm",(void*)f_11777},
{"f_11773:expand_scm",(void*)f_11773},
{"f_11769:expand_scm",(void*)f_11769},
{"f_11752:expand_scm",(void*)f_11752},
{"f_11734:expand_scm",(void*)f_11734},
{"f_11723:expand_scm",(void*)f_11723},
{"f_11355:expand_scm",(void*)f_11355},
{"f_11680:expand_scm",(void*)f_11680},
{"f_11632:expand_scm",(void*)f_11632},
{"f_11643:expand_scm",(void*)f_11643},
{"f_11646:expand_scm",(void*)f_11646},
{"f_11658:expand_scm",(void*)f_11658},
{"f_11408:expand_scm",(void*)f_11408},
{"f_11365:expand_scm",(void*)f_11365},
{"f_11375:expand_scm",(void*)f_11375},
{"f_11389:expand_scm",(void*)f_11389},
{"f_11393:expand_scm",(void*)f_11393},
{"f_11369:expand_scm",(void*)f_11369},
{"f_11626:expand_scm",(void*)f_11626},
{"f_11630:expand_scm",(void*)f_11630},
{"f_11622:expand_scm",(void*)f_11622},
{"f_11411:expand_scm",(void*)f_11411},
{"f_11414:expand_scm",(void*)f_11414},
{"f_11609:expand_scm",(void*)f_11609},
{"f_11573:expand_scm",(void*)f_11573},
{"f_11601:expand_scm",(void*)f_11601},
{"f_11417:expand_scm",(void*)f_11417},
{"f_11567:expand_scm",(void*)f_11567},
{"f_11571:expand_scm",(void*)f_11571},
{"f_11420:expand_scm",(void*)f_11420},
{"f_11423:expand_scm",(void*)f_11423},
{"f_11525:expand_scm",(void*)f_11525},
{"f_11529:expand_scm",(void*)f_11529},
{"f_11559:expand_scm",(void*)f_11559},
{"f_11555:expand_scm",(void*)f_11555},
{"f_11532:expand_scm",(void*)f_11532},
{"f_11426:expand_scm",(void*)f_11426},
{"f_11447:expand_scm",(void*)f_11447},
{"f_11523:expand_scm",(void*)f_11523},
{"f_11519:expand_scm",(void*)f_11519},
{"f_11515:expand_scm",(void*)f_11515},
{"f_11511:expand_scm",(void*)f_11511},
{"f_11507:expand_scm",(void*)f_11507},
{"f_11503:expand_scm",(void*)f_11503},
{"f_11499:expand_scm",(void*)f_11499},
{"f_11495:expand_scm",(void*)f_11495},
{"f_11491:expand_scm",(void*)f_11491},
{"f_11429:expand_scm",(void*)f_11429},
{"f_11432:expand_scm",(void*)f_11432},
{"f_11248:expand_scm",(void*)f_11248},
{"f_11259:expand_scm",(void*)f_11259},
{"f_11261:expand_scm",(void*)f_11261},
{"f_11310:expand_scm",(void*)f_11310},
{"f_11306:expand_scm",(void*)f_11306},
{"f_11289:expand_scm",(void*)f_11289},
{"f_11157:expand_scm",(void*)f_11157},
{"f_11161:expand_scm",(void*)f_11161},
{"f_11164:expand_scm",(void*)f_11164},
{"f_11203:expand_scm",(void*)f_11203},
{"f_11223:expand_scm",(void*)f_11223},
{"f_11213:expand_scm",(void*)f_11213},
{"f_11216:expand_scm",(void*)f_11216},
{"f_11179:expand_scm",(void*)f_11179},
{"f_11185:expand_scm",(void*)f_11185},
{"f_11183:expand_scm",(void*)f_11183},
{"f_10949:expand_scm",(void*)f_10949},
{"f_10953:expand_scm",(void*)f_10953},
{"f_11111:expand_scm",(void*)f_11111},
{"f_11132:expand_scm",(void*)f_11132},
{"f_10976:expand_scm",(void*)f_10976},
{"f_10979:expand_scm",(void*)f_10979},
{"f_11079:expand_scm",(void*)f_11079},
{"f_11101:expand_scm",(void*)f_11101},
{"f_10982:expand_scm",(void*)f_10982},
{"f_11061:expand_scm",(void*)f_11061},
{"f_11073:expand_scm",(void*)f_11073},
{"f_10985:expand_scm",(void*)f_10985},
{"f_11055:expand_scm",(void*)f_11055},
{"f_11059:expand_scm",(void*)f_11059},
{"f_10991:expand_scm",(void*)f_10991},
{"f_10994:expand_scm",(void*)f_10994},
{"f_11043:expand_scm",(void*)f_11043},
{"f_10997:expand_scm",(void*)f_10997},
{"f_11023:expand_scm",(void*)f_11023},
{"f_11000:expand_scm",(void*)f_11000},
{"f_11013:expand_scm",(void*)f_11013},
{"f_11003:expand_scm",(void*)f_11003},
{"f_10555:expand_scm",(void*)f_10555},
{"f_10562:expand_scm",(void*)f_10562},
{"f_10947:expand_scm",(void*)f_10947},
{"f_10578:expand_scm",(void*)f_10578},
{"f_10917:expand_scm",(void*)f_10917},
{"f_10586:expand_scm",(void*)f_10586},
{"f_10899:expand_scm",(void*)f_10899},
{"f_10594:expand_scm",(void*)f_10594},
{"f_10895:expand_scm",(void*)f_10895},
{"f_10887:expand_scm",(void*)f_10887},
{"f_10814:expand_scm",(void*)f_10814},
{"f_10812:expand_scm",(void*)f_10812},
{"f_10808:expand_scm",(void*)f_10808},
{"f_10742:expand_scm",(void*)f_10742},
{"f_10789:expand_scm",(void*)f_10789},
{"f_10774:expand_scm",(void*)f_10774},
{"f_10740:expand_scm",(void*)f_10740},
{"f_10736:expand_scm",(void*)f_10736},
{"f_10662:expand_scm",(void*)f_10662},
{"f_10732:expand_scm",(void*)f_10732},
{"f_10685:expand_scm",(void*)f_10685},
{"f_10728:expand_scm",(void*)f_10728},
{"f_10720:expand_scm",(void*)f_10720},
{"f_10716:expand_scm",(void*)f_10716},
{"f_10696:expand_scm",(void*)f_10696},
{"f_10650:expand_scm",(void*)f_10650},
{"f_10646:expand_scm",(void*)f_10646},
{"f_10590:expand_scm",(void*)f_10590},
{"f_10582:expand_scm",(void*)f_10582},
{"f_10483:expand_scm",(void*)f_10483},
{"f_10487:expand_scm",(void*)f_10487},
{"f_10490:expand_scm",(void*)f_10490},
{"f_10502:expand_scm",(void*)f_10502},
{"f_10541:expand_scm",(void*)f_10541},
{"f_10533:expand_scm",(void*)f_10533},
{"f_10493:expand_scm",(void*)f_10493},
{"f_10496:expand_scm",(void*)f_10496},
{"f_10207:expand_scm",(void*)f_10207},
{"f_10214:expand_scm",(void*)f_10214},
{"f_10288:expand_scm",(void*)f_10288},
{"f_10315:expand_scm",(void*)f_10315},
{"f_10317:expand_scm",(void*)f_10317},
{"f_10477:expand_scm",(void*)f_10477},
{"f_10465:expand_scm",(void*)f_10465},
{"f_10446:expand_scm",(void*)f_10446},
{"f_10428:expand_scm",(void*)f_10428},
{"f_10413:expand_scm",(void*)f_10413},
{"f_10383:expand_scm",(void*)f_10383},
{"f_10368:expand_scm",(void*)f_10368},
{"f_10340:expand_scm",(void*)f_10340},
{"f_10265:expand_scm",(void*)f_10265},
{"f_10277:expand_scm",(void*)f_10277},
{"f_10273:expand_scm",(void*)f_10273},
{"f_10148:expand_scm",(void*)f_10148},
{"f_10154:expand_scm",(void*)f_10154},
{"f_10161:expand_scm",(void*)f_10161},
{"f_10164:expand_scm",(void*)f_10164},
{"f_10080:expand_scm",(void*)f_10080},
{"f_10100:expand_scm",(void*)f_10100},
{"f_10095:expand_scm",(void*)f_10095},
{"f_10082:expand_scm",(void*)f_10082},
{"f_10058:expand_scm",(void*)f_10058},
{"f_10065:expand_scm",(void*)f_10065},
{"f_9977:expand_scm",(void*)f_9977},
{"f_9987:expand_scm",(void*)f_9987},
{"f_9990:expand_scm",(void*)f_9990},
{"f_9993:expand_scm",(void*)f_9993},
{"f_9996:expand_scm",(void*)f_9996},
{"f_10039:expand_scm",(void*)f_10039},
{"f_10043:expand_scm",(void*)f_10043},
{"f_9999:expand_scm",(void*)f_9999},
{"f_10002:expand_scm",(void*)f_10002},
{"f_10005:expand_scm",(void*)f_10005},
{"f_9888:expand_scm",(void*)f_9888},
{"f_9898:expand_scm",(void*)f_9898},
{"f_9901:expand_scm",(void*)f_9901},
{"f_9968:expand_scm",(void*)f_9968},
{"f_9964:expand_scm",(void*)f_9964},
{"f_9904:expand_scm",(void*)f_9904},
{"f_9960:expand_scm",(void*)f_9960},
{"f_9907:expand_scm",(void*)f_9907},
{"f_9946:expand_scm",(void*)f_9946},
{"f_9950:expand_scm",(void*)f_9950},
{"f_9910:expand_scm",(void*)f_9910},
{"f_9913:expand_scm",(void*)f_9913},
{"f_9919:expand_scm",(void*)f_9919},
{"f_9867:expand_scm",(void*)f_9867},
{"f_9874:expand_scm",(void*)f_9874},
{"f_9847:expand_scm",(void*)f_9847},
{"f_9851:expand_scm",(void*)f_9851},
{"f_9844:expand_scm",(void*)f_9844},
{"f_9804:expand_scm",(void*)f_9804},
{"f_9808:expand_scm",(void*)f_9808},
{"f_9798:expand_scm",(void*)f_9798},
{"f_9780:expand_scm",(void*)f_9780},
{"f_9770:expand_scm",(void*)f_9770},
{"f_9752:expand_scm",(void*)f_9752},
{"f_9734:expand_scm",(void*)f_9734},
{"f_9716:expand_scm",(void*)f_9716},
{"f_9698:expand_scm",(void*)f_9698},
{"f_9680:expand_scm",(void*)f_9680},
{"f_9671:expand_scm",(void*)f_9671},
{"f_9662:expand_scm",(void*)f_9662},
{"f_9644:expand_scm",(void*)f_9644},
{"f_9626:expand_scm",(void*)f_9626},
{"f_9617:expand_scm",(void*)f_9617},
{"f_9608:expand_scm",(void*)f_9608},
{"f_9590:expand_scm",(void*)f_9590},
{"f_7925:expand_scm",(void*)f_7925},
{"f_7932:expand_scm",(void*)f_7932},
{"f_7946:expand_scm",(void*)f_7946},
{"f_7950:expand_scm",(void*)f_7950},
{"f_7954:expand_scm",(void*)f_7954},
{"f_7959:expand_scm",(void*)f_7959},
{"f_7965:expand_scm",(void*)f_7965},
{"f_7969:expand_scm",(void*)f_7969},
{"f_7973:expand_scm",(void*)f_7973},
{"f_7977:expand_scm",(void*)f_7977},
{"f_7981:expand_scm",(void*)f_7981},
{"f_7986:expand_scm",(void*)f_7986},
{"f_7990:expand_scm",(void*)f_7990},
{"f_7997:expand_scm",(void*)f_7997},
{"f_8002:expand_scm",(void*)f_8002},
{"f_8006:expand_scm",(void*)f_8006},
{"f_8010:expand_scm",(void*)f_8010},
{"f_8014:expand_scm",(void*)f_8014},
{"f_8019:expand_scm",(void*)f_8019},
{"f_9527:expand_scm",(void*)f_9527},
{"f_9537:expand_scm",(void*)f_9537},
{"f_9544:expand_scm",(void*)f_9544},
{"f_9507:expand_scm",(void*)f_9507},
{"f_9514:expand_scm",(void*)f_9514},
{"f_9521:expand_scm",(void*)f_9521},
{"f_9481:expand_scm",(void*)f_9481},
{"f_9459:expand_scm",(void*)f_9459},
{"f_9466:expand_scm",(void*)f_9466},
{"f_9366:expand_scm",(void*)f_9366},
{"f_9408:expand_scm",(void*)f_9408},
{"f_9457:expand_scm",(void*)f_9457},
{"f_9440:expand_scm",(void*)f_9440},
{"f_9419:expand_scm",(void*)f_9419},
{"f_9379:expand_scm",(void*)f_9379},
{"f_9293:expand_scm",(void*)f_9293},
{"f_9319:expand_scm",(void*)f_9319},
{"f_9364:expand_scm",(void*)f_9364},
{"f_9347:expand_scm",(void*)f_9347},
{"f_9039:expand_scm",(void*)f_9039},
{"f_9086:expand_scm",(void*)f_9086},
{"f_9284:expand_scm",(void*)f_9284},
{"f_9280:expand_scm",(void*)f_9280},
{"f_9247:expand_scm",(void*)f_9247},
{"f_9255:expand_scm",(void*)f_9255},
{"f_9089:expand_scm",(void*)f_9089},
{"f_9095:expand_scm",(void*)f_9095},
{"f_9107:expand_scm",(void*)f_9107},
{"f_9173:expand_scm",(void*)f_9173},
{"f_9188:expand_scm",(void*)f_9188},
{"f_9110:expand_scm",(void*)f_9110},
{"f_9144:expand_scm",(void*)f_9144},
{"f_9113:expand_scm",(void*)f_9113},
{"f_9142:expand_scm",(void*)f_9142},
{"f_9138:expand_scm",(void*)f_9138},
{"f_9134:expand_scm",(void*)f_9134},
{"f_8832:expand_scm",(void*)f_8832},
{"f_8862:expand_scm",(void*)f_8862},
{"f_8962:expand_scm",(void*)f_8962},
{"f_8985:expand_scm",(void*)f_8985},
{"f_8999:expand_scm",(void*)f_8999},
{"f_9003:expand_scm",(void*)f_9003},
{"f_8972:expand_scm",(void*)f_8972},
{"f_8922:expand_scm",(void*)f_8922},
{"f_8926:expand_scm",(void*)f_8926},
{"f_8871:expand_scm",(void*)f_8871},
{"f_8879:expand_scm",(void*)f_8879},
{"f_8856:expand_scm",(void*)f_8856},
{"f_8544:expand_scm",(void*)f_8544},
{"f_8551:expand_scm",(void*)f_8551},
{"f_8590:expand_scm",(void*)f_8590},
{"f_8600:expand_scm",(void*)f_8600},
{"f_8731:expand_scm",(void*)f_8731},
{"f_8735:expand_scm",(void*)f_8735},
{"f_8664:expand_scm",(void*)f_8664},
{"f_8660:expand_scm",(void*)f_8660},
{"f_8598:expand_scm",(void*)f_8598},
{"f_8594:expand_scm",(void*)f_8594},
{"f_8426:expand_scm",(void*)f_8426},
{"f_8430:expand_scm",(void*)f_8430},
{"f_8205:expand_scm",(void*)f_8205},
{"f_8255:expand_scm",(void*)f_8255},
{"f_8369:expand_scm",(void*)f_8369},
{"f_8307:expand_scm",(void*)f_8307},
{"f_8315:expand_scm",(void*)f_8315},
{"f_8311:expand_scm",(void*)f_8311},
{"f_8303:expand_scm",(void*)f_8303},
{"f_8121:expand_scm",(void*)f_8121},
{"f_8128:expand_scm",(void*)f_8128},
{"f_8131:expand_scm",(void*)f_8131},
{"f_8180:expand_scm",(void*)f_8180},
{"f_8176:expand_scm",(void*)f_8176},
{"f_8171:expand_scm",(void*)f_8171},
{"f_8157:expand_scm",(void*)f_8157},
{"f_8169:expand_scm",(void*)f_8169},
{"f_8165:expand_scm",(void*)f_8165},
{"f_8027:expand_scm",(void*)f_8027},
{"f_8071:expand_scm",(void*)f_8071},
{"f_8067:expand_scm",(void*)f_8067},
{"f_8021:expand_scm",(void*)f_8021},
{"f_7023:expand_scm",(void*)f_7023},
{"f_7027:expand_scm",(void*)f_7027},
{"f_7030:expand_scm",(void*)f_7030},
{"f_7033:expand_scm",(void*)f_7033},
{"f_7036:expand_scm",(void*)f_7036},
{"f_7635:expand_scm",(void*)f_7635},
{"f_7638:expand_scm",(void*)f_7638},
{"f_7857:expand_scm",(void*)f_7857},
{"f_7842:expand_scm",(void*)f_7842},
{"f_7641:expand_scm",(void*)f_7641},
{"f_7646:expand_scm",(void*)f_7646},
{"f_7650:expand_scm",(void*)f_7650},
{"f_7659:expand_scm",(void*)f_7659},
{"f_7809:expand_scm",(void*)f_7809},
{"f_7817:expand_scm",(void*)f_7817},
{"f_7662:expand_scm",(void*)f_7662},
{"f_7786:expand_scm",(void*)f_7786},
{"f_7794:expand_scm",(void*)f_7794},
{"f_7665:expand_scm",(void*)f_7665},
{"f_7668:expand_scm",(void*)f_7668},
{"f_7740:expand_scm",(void*)f_7740},
{"f_7774:expand_scm",(void*)f_7774},
{"f_7671:expand_scm",(void*)f_7671},
{"f_7698:expand_scm",(void*)f_7698},
{"f_7738:expand_scm",(void*)f_7738},
{"f_7674:expand_scm",(void*)f_7674},
{"f_7696:expand_scm",(void*)f_7696},
{"f_7692:expand_scm",(void*)f_7692},
{"f_7677:expand_scm",(void*)f_7677},
{"f_7688:expand_scm",(void*)f_7688},
{"f_7684:expand_scm",(void*)f_7684},
{"f_7644:expand_scm",(void*)f_7644},
{"f_7177:expand_scm",(void*)f_7177},
{"f_7196:expand_scm",(void*)f_7196},
{"f_7205:expand_scm",(void*)f_7205},
{"f_7217:expand_scm",(void*)f_7217},
{"f_7297:expand_scm",(void*)f_7297},
{"f_7404:expand_scm",(void*)f_7404},
{"f_7551:expand_scm",(void*)f_7551},
{"f_7554:expand_scm",(void*)f_7554},
{"f_7557:expand_scm",(void*)f_7557},
{"f_7590:expand_scm",(void*)f_7590},
{"f_7594:expand_scm",(void*)f_7594},
{"f_7559:expand_scm",(void*)f_7559},
{"f_7579:expand_scm",(void*)f_7579},
{"f_7575:expand_scm",(void*)f_7575},
{"f_7567:expand_scm",(void*)f_7567},
{"f_7407:expand_scm",(void*)f_7407},
{"f_7416:expand_scm",(void*)f_7416},
{"f_7545:expand_scm",(void*)f_7545},
{"f_7526:expand_scm",(void*)f_7526},
{"f_7514:expand_scm",(void*)f_7514},
{"f_7493:expand_scm",(void*)f_7493},
{"f_7474:expand_scm",(void*)f_7474},
{"f_7462:expand_scm",(void*)f_7462},
{"f_7437:expand_scm",(void*)f_7437},
{"f_7432:expand_scm",(void*)f_7432},
{"f_7300:expand_scm",(void*)f_7300},
{"f_7303:expand_scm",(void*)f_7303},
{"f_7308:expand_scm",(void*)f_7308},
{"f_7394:expand_scm",(void*)f_7394},
{"f_7320:expand_scm",(void*)f_7320},
{"f_7362:expand_scm",(void*)f_7362},
{"f_7220:expand_scm",(void*)f_7220},
{"f_7223:expand_scm",(void*)f_7223},
{"f_7228:expand_scm",(void*)f_7228},
{"f_7090:expand_scm",(void*)f_7090},
{"f_7094:expand_scm",(void*)f_7094},
{"f_7097:expand_scm",(void*)f_7097},
{"f_7175:expand_scm",(void*)f_7175},
{"f_7171:expand_scm",(void*)f_7171},
{"f_7112:expand_scm",(void*)f_7112},
{"f_7118:expand_scm",(void*)f_7118},
{"f_7121:expand_scm",(void*)f_7121},
{"f_7160:expand_scm",(void*)f_7160},
{"f_7154:expand_scm",(void*)f_7154},
{"f_7158:expand_scm",(void*)f_7158},
{"f_7122:expand_scm",(void*)f_7122},
{"f_7126:expand_scm",(void*)f_7126},
{"f_7129:expand_scm",(void*)f_7129},
{"f_7133:expand_scm",(void*)f_7133},
{"f_7136:expand_scm",(void*)f_7136},
{"f_7140:expand_scm",(void*)f_7140},
{"f_7143:expand_scm",(void*)f_7143},
{"f_7147:expand_scm",(void*)f_7147},
{"f_7150:expand_scm",(void*)f_7150},
{"f_7100:expand_scm",(void*)f_7100},
{"f_7047:expand_scm",(void*)f_7047},
{"f_7060:expand_scm",(void*)f_7060},
{"f_7067:expand_scm",(void*)f_7067},
{"f_7038:expand_scm",(void*)f_7038},
{"f_7042:expand_scm",(void*)f_7042},
{"f_6729:expand_scm",(void*)f_6729},
{"f_6731:expand_scm",(void*)f_6731},
{"f_6860:expand_scm",(void*)f_6860},
{"f_6893:expand_scm",(void*)f_6893},
{"f_6983:expand_scm",(void*)f_6983},
{"f_6896:expand_scm",(void*)f_6896},
{"f_6899:expand_scm",(void*)f_6899},
{"f_6977:expand_scm",(void*)f_6977},
{"f_6902:expand_scm",(void*)f_6902},
{"f_6971:expand_scm",(void*)f_6971},
{"f_6948:expand_scm",(void*)f_6948},
{"f_6921:expand_scm",(void*)f_6921},
{"f_6928:expand_scm",(void*)f_6928},
{"f_6864:expand_scm",(void*)f_6864},
{"f_6867:expand_scm",(void*)f_6867},
{"f_6997:expand_scm",(void*)f_6997},
{"f_7001:expand_scm",(void*)f_7001},
{"f_7004:expand_scm",(void*)f_7004},
{"f_6734:expand_scm",(void*)f_6734},
{"f_6770:expand_scm",(void*)f_6770},
{"f_6831:expand_scm",(void*)f_6831},
{"f_6834:expand_scm",(void*)f_6834},
{"f_6801:expand_scm",(void*)f_6801},
{"f_6804:expand_scm",(void*)f_6804},
{"f_6782:expand_scm",(void*)f_6782},
{"f_6744:expand_scm",(void*)f_6744},
{"f_6267:expand_scm",(void*)f_6267},
{"f_6681:expand_scm",(void*)f_6681},
{"f_6672:expand_scm",(void*)f_6672},
{"f_6680:expand_scm",(void*)f_6680},
{"f_6269:expand_scm",(void*)f_6269},
{"f_6400:expand_scm",(void*)f_6400},
{"f_6405:expand_scm",(void*)f_6405},
{"f_6643:expand_scm",(void*)f_6643},
{"f_6602:expand_scm",(void*)f_6602},
{"f_6606:expand_scm",(void*)f_6606},
{"f_6424:expand_scm",(void*)f_6424},
{"f_6429:expand_scm",(void*)f_6429},
{"f_6448:expand_scm",(void*)f_6448},
{"f_6371:expand_scm",(void*)f_6371},
{"f_6377:expand_scm",(void*)f_6377},
{"f_6315:expand_scm",(void*)f_6315},
{"f_6319:expand_scm",(void*)f_6319},
{"f_6327:expand_scm",(void*)f_6327},
{"f_6347:expand_scm",(void*)f_6347},
{"f_6272:expand_scm",(void*)f_6272},
{"f_6279:expand_scm",(void*)f_6279},
{"f_6284:expand_scm",(void*)f_6284},
{"f_6288:expand_scm",(void*)f_6288},
{"f_6313:expand_scm",(void*)f_6313},
{"f_6302:expand_scm",(void*)f_6302},
{"f_6306:expand_scm",(void*)f_6306},
{"f_6295:expand_scm",(void*)f_6295},
{"f_6231:expand_scm",(void*)f_6231},
{"f_6253:expand_scm",(void*)f_6253},
{"f_6220:expand_scm",(void*)f_6220},
{"f_6228:expand_scm",(void*)f_6228},
{"f_6150:expand_scm",(void*)f_6150},
{"f_6213:expand_scm",(void*)f_6213},
{"f_6153:expand_scm",(void*)f_6153},
{"f_6206:expand_scm",(void*)f_6206},
{"f_6179:expand_scm",(void*)f_6179},
{"f_6067:expand_scm",(void*)f_6067},
{"f_6148:expand_scm",(void*)f_6148},
{"f_6070:expand_scm",(void*)f_6070},
{"f_6119:expand_scm",(void*)f_6119},
{"f_5314:expand_scm",(void*)f_5314},
{"f_5318:expand_scm",(void*)f_5318},
{"f_5757:expand_scm",(void*)f_5757},
{"f_5763:expand_scm",(void*)f_5763},
{"f_6027:expand_scm",(void*)f_6027},
{"f_5785:expand_scm",(void*)f_5785},
{"f_5995:expand_scm",(void*)f_5995},
{"f_5969:expand_scm",(void*)f_5969},
{"f_5976:expand_scm",(void*)f_5976},
{"f_5941:expand_scm",(void*)f_5941},
{"f_5929:expand_scm",(void*)f_5929},
{"f_5803:expand_scm",(void*)f_5803},
{"f_5808:expand_scm",(void*)f_5808},
{"f_5821:expand_scm",(void*)f_5821},
{"f_5877:expand_scm",(void*)f_5877},
{"f_5904:expand_scm",(void*)f_5904},
{"f_5855:expand_scm",(void*)f_5855},
{"f_5866:expand_scm",(void*)f_5866},
{"f_5870:expand_scm",(void*)f_5870},
{"f_5580:expand_scm",(void*)f_5580},
{"f_5590:expand_scm",(void*)f_5590},
{"f_5739:expand_scm",(void*)f_5739},
{"f_5735:expand_scm",(void*)f_5735},
{"f_5725:expand_scm",(void*)f_5725},
{"f_5728:expand_scm",(void*)f_5728},
{"f_5636:expand_scm",(void*)f_5636},
{"f_5668:expand_scm",(void*)f_5668},
{"f_5680:expand_scm",(void*)f_5680},
{"f_5688:expand_scm",(void*)f_5688},
{"f_5692:expand_scm",(void*)f_5692},
{"f_5654:expand_scm",(void*)f_5654},
{"f_5605:expand_scm",(void*)f_5605},
{"f_5621:expand_scm",(void*)f_5621},
{"f_5613:expand_scm",(void*)f_5613},
{"f_5617:expand_scm",(void*)f_5617},
{"f_5588:expand_scm",(void*)f_5588},
{"f_5320:expand_scm",(void*)f_5320},
{"f_5431:expand_scm",(void*)f_5431},
{"f_5572:expand_scm",(void*)f_5572},
{"f_5560:expand_scm",(void*)f_5560},
{"f_5453:expand_scm",(void*)f_5453},
{"f_5558:expand_scm",(void*)f_5558},
{"f_5542:expand_scm",(void*)f_5542},
{"f_5461:expand_scm",(void*)f_5461},
{"f_5536:expand_scm",(void*)f_5536},
{"f_5540:expand_scm",(void*)f_5540},
{"f_5475:expand_scm",(void*)f_5475},
{"f_5479:expand_scm",(void*)f_5479},
{"f_5512:expand_scm",(void*)f_5512},
{"f_5510:expand_scm",(void*)f_5510},
{"f_5506:expand_scm",(void*)f_5506},
{"f_5469:expand_scm",(void*)f_5469},
{"f_5473:expand_scm",(void*)f_5473},
{"f_5465:expand_scm",(void*)f_5465},
{"f_5457:expand_scm",(void*)f_5457},
{"f_5437:expand_scm",(void*)f_5437},
{"f_5332:expand_scm",(void*)f_5332},
{"f_5346:expand_scm",(void*)f_5346},
{"f_5421:expand_scm",(void*)f_5421},
{"f_5414:expand_scm",(void*)f_5414},
{"f_5355:expand_scm",(void*)f_5355},
{"f_5362:expand_scm",(void*)f_5362},
{"f_5370:expand_scm",(void*)f_5370},
{"f_5378:expand_scm",(void*)f_5378},
{"f_5366:expand_scm",(void*)f_5366},
{"f_4724:expand_scm",(void*)f_4724},
{"f_4744:expand_scm",(void*)f_4744},
{"f_4747:expand_scm",(void*)f_4747},
{"f_4750:expand_scm",(void*)f_4750},
{"f_4753:expand_scm",(void*)f_4753},
{"f_4756:expand_scm",(void*)f_4756},
{"f_4761:expand_scm",(void*)f_4761},
{"f_5072:expand_scm",(void*)f_5072},
{"f_5251:expand_scm",(void*)f_5251},
{"f_5189:expand_scm",(void*)f_5189},
{"f_5170:expand_scm",(void*)f_5170},
{"f_5124:expand_scm",(void*)f_5124},
{"f_5127:expand_scm",(void*)f_5127},
{"f_5106:expand_scm",(void*)f_5106},
{"f_5087:expand_scm",(void*)f_5087},
{"f_5049:expand_scm",(void*)f_5049},
{"f_5028:expand_scm",(void*)f_5028},
{"f_4775:expand_scm",(void*)f_4775},
{"f_5021:expand_scm",(void*)f_5021},
{"f_4948:expand_scm",(void*)f_4948},
{"f_5017:expand_scm",(void*)f_5017},
{"f_5001:expand_scm",(void*)f_5001},
{"f_4983:expand_scm",(void*)f_4983},
{"f_4979:expand_scm",(void*)f_4979},
{"f_4942:expand_scm",(void*)f_4942},
{"f_4946:expand_scm",(void*)f_4946},
{"f_4779:expand_scm",(void*)f_4779},
{"f_4791:expand_scm",(void*)f_4791},
{"f_4894:expand_scm",(void*)f_4894},
{"f_4886:expand_scm",(void*)f_4886},
{"f_4890:expand_scm",(void*)f_4890},
{"f_4863:expand_scm",(void*)f_4863},
{"f_4867:expand_scm",(void*)f_4867},
{"f_4818:expand_scm",(void*)f_4818},
{"f_4838:expand_scm",(void*)f_4838},
{"f_4810:expand_scm",(void*)f_4810},
{"f_4782:expand_scm",(void*)f_4782},
{"f_4727:expand_scm",(void*)f_4727},
{"f_4681:expand_scm",(void*)f_4681},
{"f_4687:expand_scm",(void*)f_4687},
{"f_4706:expand_scm",(void*)f_4706},
{"f_4628:expand_scm",(void*)f_4628},
{"f_4632:expand_scm",(void*)f_4632},
{"f_4637:expand_scm",(void*)f_4637},
{"f_4649:expand_scm",(void*)f_4649},
{"f_4643:expand_scm",(void*)f_4643},
{"f_4538:expand_scm",(void*)f_4538},
{"f_4574:expand_scm",(void*)f_4574},
{"f_4577:expand_scm",(void*)f_4577},
{"f_4589:expand_scm",(void*)f_4589},
{"f_4626:expand_scm",(void*)f_4626},
{"f_4601:expand_scm",(void*)f_4601},
{"f_4616:expand_scm",(void*)f_4616},
{"f_4592:expand_scm",(void*)f_4592},
{"f_4583:expand_scm",(void*)f_4583},
{"f_4541:expand_scm",(void*)f_4541},
{"f_4545:expand_scm",(void*)f_4545},
{"f_4568:expand_scm",(void*)f_4568},
{"f_4551:expand_scm",(void*)f_4551},
{"f_4554:expand_scm",(void*)f_4554},
{"f_4561:expand_scm",(void*)f_4561},
{"f_4520:expand_scm",(void*)f_4520},
{"f_4528:expand_scm",(void*)f_4528},
{"f_4038:expand_scm",(void*)f_4038},
{"f_4337:expand_scm",(void*)f_4337},
{"f_4511:expand_scm",(void*)f_4511},
{"f_4504:expand_scm",(void*)f_4504},
{"f_4343:expand_scm",(void*)f_4343},
{"f_4445:expand_scm",(void*)f_4445},
{"f_4451:expand_scm",(void*)f_4451},
{"f_4458:expand_scm",(void*)f_4458},
{"f_4352:expand_scm",(void*)f_4352},
{"f_4364:expand_scm",(void*)f_4364},
{"f_4432:expand_scm",(void*)f_4432},
{"f_4422:expand_scm",(void*)f_4422},
{"f_4426:expand_scm",(void*)f_4426},
{"f_4390:expand_scm",(void*)f_4390},
{"f_4386:expand_scm",(void*)f_4386},
{"f_4220:expand_scm",(void*)f_4220},
{"f_4277:expand_scm",(void*)f_4277},
{"f_4280:expand_scm",(void*)f_4280},
{"f_4306:expand_scm",(void*)f_4306},
{"f_4302:expand_scm",(void*)f_4302},
{"f_4292:expand_scm",(void*)f_4292},
{"f_4224:expand_scm",(void*)f_4224},
{"f_4246:expand_scm",(void*)f_4246},
{"f_4041:expand_scm",(void*)f_4041},
{"f_4045:expand_scm",(void*)f_4045},
{"f_4218:expand_scm",(void*)f_4218},
{"f_4214:expand_scm",(void*)f_4214},
{"f_4048:expand_scm",(void*)f_4048},
{"f_4056:expand_scm",(void*)f_4056},
{"f_4169:expand_scm",(void*)f_4169},
{"f_4196:expand_scm",(void*)f_4196},
{"f_4202:expand_scm",(void*)f_4202},
{"f_4175:expand_scm",(void*)f_4175},
{"f_4179:expand_scm",(void*)f_4179},
{"f_4182:expand_scm",(void*)f_4182},
{"f_4062:expand_scm",(void*)f_4062},
{"f_4068:expand_scm",(void*)f_4068},
{"f_4079:expand_scm",(void*)f_4079},
{"f_4096:expand_scm",(void*)f_4096},
{"f_4115:expand_scm",(void*)f_4115},
{"f_4126:expand_scm",(void*)f_4126},
{"f_4090:expand_scm",(void*)f_4090},
{"f_4076:expand_scm",(void*)f_4076},
{"f_4054:expand_scm",(void*)f_4054},
{"f_4029:expand_scm",(void*)f_4029},
{"f_3978:expand_scm",(void*)f_3978},
{"f_3990:expand_scm",(void*)f_3990},
{"f_3992:expand_scm",(void*)f_3992},
{"f_4027:expand_scm",(void*)f_4027},
{"f_4019:expand_scm",(void*)f_4019},
{"f_3986:expand_scm",(void*)f_3986},
{"f_3922:expand_scm",(void*)f_3922},
{"f_3926:expand_scm",(void*)f_3926},
{"f_3935:expand_scm",(void*)f_3935},
{"f_3954:expand_scm",(void*)f_3954},
{"f_3944:expand_scm",(void*)f_3944},
{"f_3909:expand_scm",(void*)f_3909},
{"f_3920:expand_scm",(void*)f_3920},
{"f_3913:expand_scm",(void*)f_3913},
{"f_3876:expand_scm",(void*)f_3876},
{"f_3880:expand_scm",(void*)f_3880},
{"f_3883:expand_scm",(void*)f_3883},
{"f_3721:expand_scm",(void*)f_3721},
{"f_3821:expand_scm",(void*)f_3821},
{"f_3816:expand_scm",(void*)f_3816},
{"f_3723:expand_scm",(void*)f_3723},
{"f_3729:expand_scm",(void*)f_3729},
{"f_3815:expand_scm",(void*)f_3815},
{"f_3811:expand_scm",(void*)f_3811},
{"f_3786:expand_scm",(void*)f_3786},
{"f_3790:expand_scm",(void*)f_3790},
{"f_3739:expand_scm",(void*)f_3739},
{"f_3745:expand_scm",(void*)f_3745},
{"f_3691:expand_scm",(void*)f_3691},
{"f_3697:expand_scm",(void*)f_3697},
{"f_3642:expand_scm",(void*)f_3642},
{"f_3649:expand_scm",(void*)f_3649},
{"f_3652:expand_scm",(void*)f_3652},
{"f_3655:expand_scm",(void*)f_3655},
{"f_3658:expand_scm",(void*)f_3658},
{"f_3664:expand_scm",(void*)f_3664},
{"f_3667:expand_scm",(void*)f_3667},
{"f_3624:expand_scm",(void*)f_3624},
{"f_3637:expand_scm",(void*)f_3637},
{"f_3593:expand_scm",(void*)f_3593},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
