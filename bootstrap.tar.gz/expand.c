/* Generated from expand.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-11-03 03:25
   Version 4.0.0x - linux-unix-gnu-x86	[ ptables applyhook ]
   SVN rev. 12299	compiled 2008-10-29 on dill (Linux)
   command line: expand.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -debug i -output-file expand.c
   unit: expand
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[391];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,17),40,100,32,97,114,103,49,55,32,46,32,109,111,114,101,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,108,111,111,107,117,112,32,105,100,50,52,32,115,101,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,109,97,99,114,111,45,97,108,105,97,115,32,118,97,114,52,53,32,115,101,52,54,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,11),40,97,51,53,57,49,32,97,56,48,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,13),40,109,97,112,45,115,101,32,115,101,55,56,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,11),40,119,97,108,107,32,120,49,49,53,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,24),40,98,111,100,121,49,48,48,32,115,101,49,49,48,32,97,108,105,97,115,49,49,49,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,97,108,105,97,115,49,48,51,32,37,115,101,57,56,49,51,57,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,11),40,100,101,102,45,115,101,49,48,50,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,115,116,114,105,112,45,115,121,110,116,97,120,32,101,120,112,57,48,32,46,32,116,109,112,56,57,57,49,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,101,120,116,101,110,100,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,110,97,109,101,49,53,57,32,115,101,49,54,48,32,104,97,110,100,108,101,114,49,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,99,111,112,121,45,109,97,99,114,111,32,111,108,100,49,56,49,32,110,101,119,49,56,50,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,27),40,109,97,99,114,111,63,32,115,121,109,49,57,52,32,46,32,116,109,112,49,57,51,49,57,53,41,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,109,101,50,50,56,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,109,97,99,114,111,32,110,97,109,101,50,50,52,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,117,110,100,101,102,105,110,101,45,109,97,99,114,111,33,32,110,97,109,101,50,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,112,115,50,55,53,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,7),40,97,51,57,54,50,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,97,51,57,53,54,32,101,120,50,54,56,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,52,48,54,57,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,52,48,57,54,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,20),40,97,52,48,57,48,32,46,32,97,114,103,115,50,54,50,50,57,53,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,52,48,54,51,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,15),40,97,51,57,53,48,32,107,50,54,49,50,54,54,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,46),40,99,97,108,108,45,104,97,110,100,108,101,114,32,110,97,109,101,50,53,50,32,104,97,110,100,108,101,114,50,53,51,32,101,120,112,50,53,52,32,115,101,50,53,53,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,31),40,101,120,112,97,110,100,32,104,101,97,100,51,48,48,32,101,120,112,51,48,49,32,109,100,101,102,51,48,50,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,12),40,97,52,51,50,54,32,98,51,55,52,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,101,120,112,97,110,100,45,48,32,101,120,112,50,52,55,32,100,115,101,50,52,56,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,109,111,100,117,108,101,45,114,101,110,97,109,101,32,115,121,109,51,57,49,32,112,114,101,102,105,120,51,57,50,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,16),40,109,114,101,110,97,109,101,32,115,121,109,52,48,56,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,97,108,105,97,115,45,103,108,111,98,97,108,45,104,111,111,107,32,115,121,109,51,57,54,32,97,115,115,105,103,110,51,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,52,53,51,55,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,32),40,97,52,53,52,51,32,101,120,112,50,52,55,53,52,55,54,52,56,49,32,109,52,55,55,52,55,56,52,56,50,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,52,55,50,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,101,120,112,97,110,100,32,101,120,112,52,53,55,32,46,32,116,109,112,52,53,54,52,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,108,105,115,116,52,57,54,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,63,32,108,108,105,115,116,52,57,50,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,101,114,114,32,109,115,103,53,51,50,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,97,52,56,52,50,32,107,53,54,53,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,109,111,100,101,53,52,55,32,114,101,113,53,52,56,32,111,112,116,53,52,57,32,107,101,121,53,53,48,32,108,108,105,115,116,53,53,49,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,67),40,35,35,115,121,115,35,101,120,112,97,110,100,45,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,32,108,108,105,115,116,48,53,50,53,32,98,111,100,121,53,50,54,32,101,114,114,104,53,50,55,32,115,101,53,50,56,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,98,111,100,121,50,55,48,51,32,101,120,112,115,55,48,52,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,17),40,97,53,52,48,54,32,118,55,54,48,32,116,55,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,18),40,97,53,51,54,57,32,118,115,55,53,49,32,120,55,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,17),40,97,53,52,51,54,32,118,55,52,52,32,120,55,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,97,53,52,53,52,32,118,55,52,50,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,48),40,102,105,110,105,32,118,97,114,115,54,57,51,32,118,97,108,115,54,57,52,32,109,118,97,114,115,54,57,53,32,109,118,97,108,115,54,57,54,32,98,111,100,121,54,57,55,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,30),40,108,111,111,112,32,98,111,100,121,55,56,50,32,100,101,102,115,55,56,51,32,100,111,110,101,55,56,52,41,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,55),40,102,105,110,105,47,115,121,110,116,97,120,32,118,97,114,115,55,55,52,32,118,97,108,115,55,55,53,32,109,118,97,114,115,55,55,54,32,109,118,97,108,115,55,55,55,32,98,111,100,121,55,55,56,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,50,32,120,56,53,56,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,48),40,108,111,111,112,32,98,111,100,121,56,50,49,32,118,97,114,115,56,50,50,32,118,97,108,115,56,50,51,32,109,118,97,114,115,56,50,52,32,109,118,97,108,115,56,50,53,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,98,111,100,121,56,49,55,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,99,97,110,111,110,105,99,97,108,105,122,101,45,98,111,100,121,32,98,111,100,121,54,55,55,32,46,32,116,109,112,54,55,54,54,55,56,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,17),40,109,119,97,108,107,32,120,57,48,53,32,112,57,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,40),40,109,97,116,99,104,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,56,57,54,32,112,97,116,56,57,55,32,118,97,114,115,56,57,56,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,104,101,97,100,57,52,49,32,98,111,100,121,57,52,50,41,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,51),40,35,35,115,121,115,35,101,120,112,97,110,100,45,99,117,114,114,105,101,100,45,100,101,102,105,110,101,32,104,101,97,100,57,51,52,32,98,111,100,121,57,51,53,32,115,101,57,51,54,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,45,104,111,111,107,32,46,32,97,114,103,115,57,54,48,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,25),40,103,101,116,45,108,105,110,101,45,110,117,109,98,101,114,32,115,101,120,112,57,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,101,114,114,32,109,115,103,49,48,52,49,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,29),40,116,101,115,116,32,120,49,48,51,53,32,112,114,101,100,49,48,51,54,32,109,115,103,49,48,51,55,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,49,48,53,57,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,108,97,109,98,100,97,45,108,105,115,116,63,32,120,49,48,52,57,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,20),40,112,114,111,112,101,114,45,108,105,115,116,63,32,120,49,48,56,48,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,49,50,57,32,120,49,49,51,54,32,110,49,49,51,55,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,13),40,97,54,52,57,54,32,121,49,49,53,55,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,49,48,51,32,112,49,49,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,49,48,49,54,32,99,117,108,112,114,105,116,49,48,50,54,32,115,101,49,48,50,55,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,101,49,48,49,57,32,37,99,117,108,112,114,105,116,49,48,49,52,49,49,55,51,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,99,117,108,112,114,105,116,49,48,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,99,104,101,99,107,45,115,121,110,116,97,120,32,105,100,49,48,48,52,32,101,120,112,49,48,48,53,32,112,97,116,49,48,48,54,32,46,32,116,109,112,49,48,48,51,49,48,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,16),40,114,101,110,97,109,101,32,115,121,109,49,49,57,56,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,31),40,108,111,111,107,117,112,50,32,110,49,51,51,53,32,115,121,109,49,51,51,54,32,100,115,101,49,51,51,55,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,23),40,99,111,109,112,97,114,101,32,115,49,49,50,53,49,32,115,50,49,50,53,50,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,32),40,102,95,54,54,50,54,32,102,111,114,109,49,49,56,57,32,115,101,49,49,57,48,32,100,115,101,49,49,57,49,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,101,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,49,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,17),40,114,101,115,111,108,118,101,32,115,121,109,49,51,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,13),40,116,111,115,116,114,32,120,49,51,55,52,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,10),40,115,119,97,112,49,52,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,7),40,97,55,48,53,52,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,110,97,109,101,32,115,112,101,99,49,51,56,51,41,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,105,100,115,49,52,57,48,32,118,49,52,57,49,32,115,49,52,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,115,49,53,51,49,32,115,49,53,51,50,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,118,49,53,49,57,32,118,49,53,50,48,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,14),40,97,55,51,51,49,32,105,100,49,53,55,48,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,105,109,112,118,49,53,52,56,32,105,109,112,115,49,53,52,57,32,118,49,53,53,48,32,115,49,53,53,49,32,105,100,115,49,53,53,50,41,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,13),40,114,101,110,32,105,109,112,49,53,56,57,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,115,112,101,99,32,115,112,101,99,49,52,53,52,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,15),40,97,55,53,57,50,32,105,109,112,49,54,50,57,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,97,55,54,51,52,32,105,109,112,49,54,49,57,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,16),40,97,55,53,52,48,32,115,112,101,99,49,53,57,55,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,86),40,35,35,115,121,115,35,101,120,112,97,110,100,45,105,109,112,111,114,116,32,120,49,51,52,57,32,114,49,51,53,48,32,99,49,51,53,49,32,105,109,112,111,114,116,45,101,110,118,49,51,53,50,32,109,97,99,114,111,45,101,110,118,49,51,53,51,32,109,101,116,97,63,49,51,53,52,32,108,111,99,49,51,53,53,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,18),40,102,95,55,57,49,50,32,114,117,108,101,115,50,50,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,13),40,97,56,48,53,53,32,120,50,51,49,53,41,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,17),40,102,95,56,48,48,54,32,114,117,108,101,50,51,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,30),40,102,95,56,48,57,48,32,105,110,112,117,116,50,51,49,55,32,112,97,116,116,101,114,110,50,51,49,56,41,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,30),40,102,95,56,51,49,49,32,105,110,112,117,116,50,51,54,55,32,112,97,116,116,101,114,110,50,51,54,56,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,52,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,30),40,102,95,56,52,50,57,32,105,110,112,117,116,50,51,56,52,32,112,97,116,116,101,114,110,50,51,56,53,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,13),40,97,56,55,53,53,32,120,50,52,52,53,41,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,52,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,39),40,102,95,56,55,49,55,32,112,97,116,116,101,114,110,50,52,51,52,32,112,97,116,104,50,52,51,53,32,109,97,112,105,116,50,52,51,54,41,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,50,53,50,57,32,100,50,53,51,53,32,103,101,110,50,53,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,37),40,102,95,56,57,50,52,32,116,101,109,112,108,97,116,101,50,52,56,56,32,100,105,109,50,52,56,57,32,101,110,118,50,52,57,48,41,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,37),40,102,95,57,49,55,56,32,112,97,116,116,101,114,110,50,53,54,50,32,100,105,109,50,53,54,51,32,118,97,114,115,50,53,54,52,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,46),40,102,95,57,50,53,49,32,116,101,109,112,108,97,116,101,50,53,55,51,32,100,105,109,50,53,55,52,32,101,110,118,50,53,55,53,32,102,114,101,101,50,53,55,54,41,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,52,52,32,112,97,116,116,101,114,110,50,53,57,49,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,54,54,32,112,97,116,116,101,114,110,50,54,48,49,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,57,50,32,112,97,116,116,101,114,110,50,54,48,55,41,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,97,116,116,101,114,110,50,54,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,49,50,32,112,97,116,116,101,114,110,50,54,48,57,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,79),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,115,121,110,116,97,120,45,114,117,108,101,115,32,101,108,108,105,112,115,105,115,50,50,51,57,32,114,117,108,101,115,50,50,52,48,32,115,117,98,107,101,121,119,111,114,100,115,50,50,52,49,32,114,50,50,52,50,32,99,50,50,52,51,41,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,13),40,109,111,100,117,108,101,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,20),40,109,111,100,117,108,101,45,101,120,112,111,114,116,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,46),40,115,101,116,45,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,56,48,50,55,49,49,32,121,50,54,56,49,50,55,49,50,41,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,41,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,19),40,109,111,100,117,108,101,45,101,120,105,115,116,45,108,105,115,116,41,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,28),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,115,121,110,116,97,120,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,48),40,115,101,116,45,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,56,48,50,55,51,53,32,121,50,54,56,49,50,55,51,54,41};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,32,120,50,54,56,48,50,55,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,26),40,109,111,100,117,108,101,45,109,101,116,97,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,25),40,109,111,100,117,108,101,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,118,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,115,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,51),40,109,97,107,101,45,109,111,100,117,108,101,32,101,120,112,108,105,115,116,50,56,48,55,32,118,101,120,112,111,114,116,115,50,56,48,56,32,115,101,120,112,111,114,116,115,50,56,48,57,41,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,102,105,110,100,45,109,111,100,117,108,101,32,110,97,109,101,50,56,49,57,32,46,32,116,109,112,50,56,49,56,50,56,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,64),40,35,35,115,121,115,35,116,111,112,108,101,118,101,108,45,100,101,102,105,110,105,116,105,111,110,45,104,111,111,107,32,115,121,109,50,56,52,54,32,109,111,100,50,56,52,55,32,101,120,112,50,56,52,56,32,118,97,108,50,56,52,57,41};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,50,56,53,51,41};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,42),40,99,104,101,99,107,45,102,111,114,45,114,101,100,101,102,32,115,121,109,50,56,54,50,32,101,110,118,50,56,54,51,32,115,101,110,118,50,56,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,101,120,112,111,114,116,32,115,121,109,50,56,55,57,32,109,111,100,50,56,56,48,41,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,115,121,110,116,97,120,45,101,120,112,111,114,116,32,115,121,109,50,57,48,52,32,109,111,100,50,57,48,53,32,118,97,108,50,57,48,54,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,117,110,100,101,102,105,110,101,100,32,115,121,109,50,57,51,48,32,109,111,100,50,57,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,50,57,53,56,32,115,101,120,112,111,114,116,115,50,57,54,57,41,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,18),40,100,101,102,45,115,101,120,112,111,114,116,115,50,57,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,58),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,32,110,97,109,101,50,57,52,55,32,101,120,112,108,105,115,116,50,57,52,56,32,46,32,116,109,112,50,57,52,54,50,57,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,16),40,97,49,48,48,49,53,32,105,109,112,50,57,57,51,41};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,109,97,114,107,45,105,109,112,111,114,116,101,100,45,115,121,109,98,111,108,115,32,115,101,50,57,57,49,41,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,21),40,119,97,114,110,32,109,115,103,51,48,51,50,32,105,100,51,48,51,51,41,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,50,32,105,101,120,112,111,114,116,115,51,48,52,56,41,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,101,120,112,111,114,116,115,51,48,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,105,110,100,105,114,101,99,116,45,101,120,112,111,114,116,115,32,109,111,100,51,48,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,101,51,48,57,57,41,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,18),40,109,101,114,103,101,45,115,101,32,115,101,115,51,48,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,20),40,97,49,48,53,48,50,32,115,101,120,112,111,114,116,51,49,52,52,41,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,15),40,97,49,48,53,54,55,32,105,101,51,49,51,52,41,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,45,114,101,103,105,115,116,114,97,116,105,111,110,32,109,111,100,51,49,49,53,41,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,17),40,97,49,48,55,51,52,32,105,101,120,112,51,49,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,17),40,97,49,48,55,53,52,32,115,101,120,112,51,49,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,55,50,32,105,101,51,49,55,50,41,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,15),40,97,49,48,56,48,52,32,115,101,51,49,54,56,41,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,80),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,32,110,97,109,101,51,49,54,49,32,105,101,120,112,111,114,116,115,51,49,54,50,32,118,101,120,112,111,114,116,115,51,49,54,51,32,115,101,120,112,111,114,116,115,51,49,54,52,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,15),40,97,49,48,56,53,48,32,115,101,51,50,50,49,41,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,15),40,97,49,48,56,54,56,32,118,101,51,50,49,54,41,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,69),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,105,109,105,116,105,118,101,45,109,111,100,117,108,101,32,110,97,109,101,51,49,57,56,32,118,101,120,112,111,114,116,115,51,49,57,57,32,46,32,116,109,112,51,49,57,55,51,50,48,48,41,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,50,52,50,41,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,102,105,110,100,45,101,120,112,111,114,116,32,115,121,109,51,50,51,52,32,109,111,100,51,50,51,53,32,105,110,100,105,114,101,99,116,51,50,51,54,41};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,14),40,97,49,49,49,51,52,32,109,51,51,54,51,41,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,16),40,97,49,49,49,56,50,32,101,120,112,51,51,52,52,41};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,14),40,97,49,49,50,50,48,32,117,51,51,51,56,41,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,51,49,48,41,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,15),40,97,49,49,51,54,56,32,115,100,51,50,57,49,41,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,50,57,53,41,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,16),40,97,49,49,52,51,48,32,115,121,109,51,50,56,55,41};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,110,97,108,105,122,101,45,109,111,100,117,108,101,32,109,111,100,51,50,55,53,41,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,51,56,56,41,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,109,97,99,114,111,45,115,117,98,115,101,116,32,109,101,48,51,51,56,52,41,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,28),40,97,49,49,52,57,51,32,101,120,112,50,50,50,51,32,114,50,50,50,52,32,99,50,50,50,53,41,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,16),40,97,49,49,53,54,48,32,101,120,112,50,49,57,57,41};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,51,48,32,120,50,49,57,48,32,114,50,49,57,49,32,99,50,49,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,26),40,97,49,49,54,51,51,32,120,50,49,55,48,32,114,50,49,55,49,32,99,50,49,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,26),40,97,49,49,54,56,55,32,120,50,49,54,48,32,114,50,49,54,49,32,99,50,49,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,51,56,32,120,50,49,52,57,32,114,50,49,53,48,32,99,50,49,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,53,57,32,120,50,49,51,56,32,114,50,49,51,57,32,99,50,49,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,11),40,101,114,114,32,120,50,48,53,51,41,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,13),40,116,101,115,116,32,102,120,50,48,53,53,41,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,14),40,97,49,49,57,55,55,32,120,50,49,48,57,41,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,99,108,115,50,49,48,48,41};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,29),40,97,49,49,55,56,48,32,102,111,114,109,50,48,52,48,32,114,50,48,52,49,32,99,50,48,52,50,41,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,29),40,97,49,50,48,54,52,32,102,111,114,109,50,48,51,48,32,114,50,48,51,49,32,99,50,48,51,50,41,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,57,50,50,32,110,49,57,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,19),40,119,97,108,107,49,32,120,49,57,50,53,32,110,49,57,50,54,41,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,16),40,115,105,109,112,108,105,102,121,32,120,49,57,57,48,41};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,29),40,97,49,50,48,57,55,32,102,111,114,109,49,57,49,48,32,114,49,57,49,49,32,99,49,57,49,50,41,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,14),40,97,49,50,53,57,55,32,98,49,57,48,54,41,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,14),40,97,49,50,54,53,50,32,98,49,56,57,52,41,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,29),40,97,49,50,52,57,50,32,102,111,114,109,49,56,55,56,32,114,49,56,55,57,32,99,49,56,56,48,41,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,15),40,101,120,112,97,110,100,32,98,115,49,56,54,52,41,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,29),40,97,49,50,54,55,52,32,102,111,114,109,49,56,53,52,32,114,49,56,53,53,32,99,49,56,53,54,41,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,14),40,97,49,50,56,54,55,32,120,49,56,52,51,41,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,56,51,48,41,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,29),40,97,49,50,55,52,51,32,102,111,114,109,49,56,49,48,32,114,49,56,49,49,32,99,49,56,49,50,41,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,55,54,54,41,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,29),40,97,49,50,57,49,51,32,102,111,114,109,49,55,53,49,32,114,49,55,53,50,32,99,49,55,53,51,41,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,29),40,97,49,51,50,52,54,32,102,111,114,109,49,55,51,53,32,114,49,55,51,54,32,99,49,55,51,55,41,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,29),40,97,49,51,51,51,54,32,102,111,114,109,49,55,50,49,32,114,49,55,50,50,32,99,49,55,50,51,41,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,102,111,114,109,49,54,57,48,41,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,29),40,97,49,51,51,57,53,32,102,111,114,109,49,54,56,52,32,114,49,54,56,53,32,99,49,54,56,54,41,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,50),40,97,49,51,53,51,55,32,103,49,54,55,50,49,54,55,51,49,54,55,56,32,103,49,54,55,52,49,54,55,53,49,54,55,57,32,103,49,54,55,54,49,54,55,55,49,54,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,50),40,97,49,51,53,52,55,32,103,49,54,53,54,49,54,53,55,49,54,54,50,32,103,49,54,53,56,49,54,53,57,49,54,54,51,32,103,49,54,54,48,49,54,54,49,49,54,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_expand_toplevel)
C_externexport void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_ccall f_3513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13548)
static void C_ccall f_13548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13546)
static void C_ccall f_13546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7763)
static void C_ccall f_7763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13538)
static void C_ccall f_13538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13536)
static void C_ccall f_13536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7766)
static void C_ccall f_7766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7770)
static void C_ccall f_7770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13396)
static void C_ccall f_13396(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13406)
static void C_fcall f_13406(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13422)
static void C_ccall f_13422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13425)
static void C_ccall f_13425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13453)
static void C_ccall f_13453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13428)
static void C_ccall f_13428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13475)
static void C_ccall f_13475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13478)
static void C_ccall f_13478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13524)
static void C_ccall f_13524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13481)
static void C_ccall f_13481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13504)
static void C_ccall f_13504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13516)
static void C_ccall f_13516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13462)
static void C_ccall f_13462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13465)
static void C_ccall f_13465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13472)
static void C_ccall f_13472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13394)
static void C_ccall f_13394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7773)
static void C_ccall f_7773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13337)
static void C_ccall f_13337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13366)
static void C_ccall f_13366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13386)
static void C_ccall f_13386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13390)
static void C_ccall f_13390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13335)
static void C_ccall f_13335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7776)
static void C_ccall f_7776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13247)
static void C_ccall f_13247(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13272)
static void C_ccall f_13272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13279)
static void C_ccall f_13279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13299)
static void C_ccall f_13299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13319)
static void C_ccall f_13319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13323)
static void C_ccall f_13323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13245)
static void C_ccall f_13245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7779)
static void C_ccall f_7779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12914)
static void C_ccall f_12914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12921)
static void C_ccall f_12921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12924)
static void C_ccall f_12924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12927)
static void C_ccall f_12927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12930)
static void C_ccall f_12930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12933)
static void C_ccall f_12933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12936)
static void C_ccall f_12936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12939)
static void C_ccall f_12939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12944)
static void C_fcall f_12944(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12960)
static void C_ccall f_12960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12966)
static void C_ccall f_12966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13008)
static void C_ccall f_13008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13076)
static void C_ccall f_13076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13201)
static void C_ccall f_13201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13197)
static void C_ccall f_13197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13079)
static void C_ccall f_13079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13134)
static void C_ccall f_13134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13011)
static void C_ccall f_13011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13050)
static void C_ccall f_13050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13002)
static void C_ccall f_13002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12973)
static void C_ccall f_12973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12912)
static void C_ccall f_12912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7782)
static void C_ccall f_7782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12744)
static void C_ccall f_12744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12748)
static void C_ccall f_12748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12757)
static void C_ccall f_12757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12760)
static void C_ccall f_12760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12763)
static void C_ccall f_12763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12766)
static void C_ccall f_12766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12769)
static void C_ccall f_12769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12790)
static void C_fcall f_12790(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12806)
static void C_ccall f_12806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12812)
static void C_ccall f_12812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12868)
static void C_ccall f_12868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12866)
static void C_ccall f_12866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12862)
static void C_ccall f_12862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12854)
static void C_ccall f_12854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12850)
static void C_ccall f_12850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12819)
static void C_ccall f_12819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12788)
static void C_ccall f_12788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12742)
static void C_ccall f_12742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7785)
static void C_ccall f_7785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12675)
static void C_ccall f_12675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12679)
static void C_ccall f_12679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12688)
static void C_ccall f_12688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12693)
static void C_fcall f_12693(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12730)
static void C_ccall f_12730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12711)
static void C_ccall f_12711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12673)
static void C_ccall f_12673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7788)
static void C_ccall f_7788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12493)
static void C_ccall f_12493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12497)
static void C_ccall f_12497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12509)
static void C_ccall f_12509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12512)
static void C_ccall f_12512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12515)
static void C_ccall f_12515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12518)
static void C_ccall f_12518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12653)
static void C_ccall f_12653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12533)
static void C_ccall f_12533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12651)
static void C_ccall f_12651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12560)
static void C_fcall f_12560(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12641)
static void C_ccall f_12641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12576)
static void C_fcall f_12576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12598)
static void C_ccall f_12598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12596)
static void C_ccall f_12596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12592)
static void C_ccall f_12592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12491)
static void C_ccall f_12491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12098)
static void C_ccall f_12098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12102)
static void C_ccall f_12102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12105)
static void C_ccall f_12105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12108)
static void C_ccall f_12108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12111)
static void C_ccall f_12111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12480)
static void C_ccall f_12480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12392)
static void C_fcall f_12392(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12396)
static void C_ccall f_12396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12421)
static void C_ccall f_12421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12467)
static void C_ccall f_12467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12452)
static void C_ccall f_12452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12123)
static void C_fcall f_12123(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12170)
static void C_ccall f_12170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12217)
static void C_ccall f_12217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12378)
static void C_ccall f_12378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12386)
static void C_ccall f_12386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12364)
static void C_ccall f_12364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12353)
static void C_ccall f_12353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12361)
static void C_ccall f_12361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12338)
static void C_ccall f_12338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12326)
static void C_ccall f_12326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12307)
static void C_ccall f_12307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12265)
static void C_ccall f_12265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12242)
static void C_ccall f_12242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12196)
static void C_ccall f_12196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12145)
static void C_ccall f_12145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12141)
static void C_ccall f_12141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12113)
static void C_fcall f_12113(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12121)
static void C_ccall f_12121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12096)
static void C_ccall f_12096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7794)
static void C_ccall f_7794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12065)
static void C_ccall f_12065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12069)
static void C_ccall f_12069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12063)
static void C_ccall f_12063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7797)
static void C_ccall f_7797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11781)
static void C_ccall f_11781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11788)
static void C_ccall f_11788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11791)
static void C_ccall f_11791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11794)
static void C_ccall f_11794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11797)
static void C_ccall f_11797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11800)
static void C_ccall f_11800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11962)
static void C_fcall f_11962(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12015)
static void C_ccall f_12015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12037)
static void C_ccall f_12037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12044)
static void C_ccall f_12044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12031)
static void C_ccall f_12031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11978)
static void C_ccall f_11978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11976)
static void C_ccall f_11976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11812)
static void C_fcall f_11812(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11843)
static void C_ccall f_11843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11889)
static void C_ccall f_11889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11939)
static void C_ccall f_11939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11946)
static void C_ccall f_11946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11904)
static void C_ccall f_11904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11918)
static void C_ccall f_11918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11861)
static void C_ccall f_11861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11872)
static void C_ccall f_11872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11802)
static void C_fcall f_11802(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11779)
static void C_ccall f_11779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7800)
static void C_ccall f_7800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11760)
static void C_ccall f_11760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11758)
static void C_ccall f_11758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7803)
static void C_ccall f_7803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11739)
static void C_ccall f_11739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11737)
static void C_ccall f_11737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7806)
static void C_ccall f_7806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11688)
static void C_ccall f_11688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11692)
static void C_ccall f_11692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11729)
static void C_ccall f_11729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11722)
static void C_ccall f_11722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11715)
static void C_ccall f_11715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11686)
static void C_ccall f_11686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7809)
static void C_ccall f_7809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11634)
static void C_ccall f_11634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11638)
static void C_ccall f_11638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11641)
static void C_ccall f_11641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11678)
static void C_ccall f_11678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11644)
static void C_ccall f_11644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11659)
static void C_ccall f_11659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11663)
static void C_ccall f_11663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11632)
static void C_ccall f_11632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7812)
static void C_ccall f_7812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11531)
static void C_ccall f_11531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11538)
static void C_ccall f_11538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11541)
static void C_ccall f_11541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11561)
static void C_ccall f_11561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11583)
static C_word C_fcall f_11583(C_word t0);
C_noret_decl(f_11568)
static void C_fcall f_11568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11544)
static void C_ccall f_11544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11559)
static void C_ccall f_11559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11551)
static void C_ccall f_11551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11547)
static void C_ccall f_11547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11529)
static void C_ccall f_11529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7815)
static void C_ccall f_7815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11494)
static void C_ccall f_11494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11498)
static void C_ccall f_11498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11516)
static void C_ccall f_11516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11507)
static void C_fcall f_11507(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11492)
static void C_ccall f_11492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7818)
static void C_ccall f_7818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9453)
static void C_ccall f_9453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11488)
static void C_ccall f_11488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9457)
static void C_ccall f_9457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9461)
static void C_ccall f_9461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11446)
static void C_ccall f_11446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11454)
static void C_ccall f_11454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11456)
static void C_fcall f_11456(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11477)
static void C_ccall f_11477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10999)
static void C_ccall f_10999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11431)
static void C_ccall f_11431(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11439)
static void C_ccall f_11439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11015)
static void C_ccall f_11015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11388)
static void C_ccall f_11388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11390)
static void C_fcall f_11390(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11429)
static void C_ccall f_11429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11403)
static void C_ccall f_11403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11414)
static void C_ccall f_11414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11369)
static void C_ccall f_11369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11381)
static void C_ccall f_11381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11018)
static void C_ccall f_11018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11241)
static void C_fcall f_11241(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11292)
static void C_fcall f_11292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11345)
static void C_ccall f_11345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11304)
static void C_fcall f_11304(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11331)
static void C_ccall f_11331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11327)
static void C_ccall f_11327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11307)
static void C_ccall f_11307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11289)
static void C_ccall f_11289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11278)
static void C_ccall f_11278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11021)
static void C_ccall f_11021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11235)
static void C_ccall f_11235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11221)
static void C_ccall f_11221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11024)
static void C_ccall f_11024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11219)
static void C_ccall f_11219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11183)
static void C_ccall f_11183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11211)
static void C_ccall f_11211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11027)
static void C_ccall f_11027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11177)
static void C_ccall f_11177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11181)
static void C_ccall f_11181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11030)
static void C_ccall f_11030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11033)
static void C_ccall f_11033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11135)
static void C_ccall f_11135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11139)
static void C_ccall f_11139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11169)
static void C_ccall f_11169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11165)
static void C_ccall f_11165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11142)
static void C_ccall f_11142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11036)
static void C_ccall f_11036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11133)
static void C_ccall f_11133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11129)
static void C_ccall f_11129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11125)
static void C_ccall f_11125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11121)
static void C_ccall f_11121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11117)
static void C_ccall f_11117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11113)
static void C_ccall f_11113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11109)
static void C_ccall f_11109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11105)
static void C_ccall f_11105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11101)
static void C_ccall f_11101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11039)
static void C_ccall f_11039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11042)
static void C_ccall f_11042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10914)
static void C_ccall f_10914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10925)
static void C_ccall f_10925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10927)
static void C_fcall f_10927(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10976)
static void C_ccall f_10976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10972)
static void C_ccall f_10972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10955)
static void C_fcall f_10955(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10823)
static void C_ccall f_10823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10823)
static void C_ccall f_10823r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10827)
static void C_ccall f_10827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10830)
static void C_ccall f_10830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10869)
static void C_ccall f_10869(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10889)
static void C_ccall f_10889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10879)
static void C_ccall f_10879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10882)
static void C_ccall f_10882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10845)
static void C_ccall f_10845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10851)
static void C_ccall f_10851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10849)
static void C_ccall f_10849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10703)
static void C_ccall f_10703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10805)
static void C_ccall f_10805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10817)
static void C_ccall f_10817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10707)
static void C_ccall f_10707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10773)
static void C_ccall f_10773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10795)
static void C_ccall f_10795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10710)
static void C_ccall f_10710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10767)
static void C_ccall f_10767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10771)
static void C_ccall f_10771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10716)
static void C_ccall f_10716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10719)
static void C_ccall f_10719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10755)
static void C_ccall f_10755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10722)
static void C_ccall f_10722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10735)
static void C_ccall f_10735(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10725)
static void C_ccall f_10725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10417)
static void C_ccall f_10417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10701)
static void C_ccall f_10701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10437)
static void C_fcall f_10437(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10671)
static void C_ccall f_10671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10445)
static void C_fcall f_10445(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10653)
static void C_ccall f_10653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10453)
static void C_ccall f_10453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10641)
static void C_ccall f_10641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10568)
static void C_ccall f_10568(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10566)
static void C_ccall f_10566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10562)
static void C_ccall f_10562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10503)
static void C_ccall f_10503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10513)
static void C_ccall f_10513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10501)
static void C_ccall f_10501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10497)
static void C_ccall f_10497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10449)
static void C_ccall f_10449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10441)
static void C_ccall f_10441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10345)
static void C_fcall f_10345(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10349)
static void C_ccall f_10349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10352)
static void C_ccall f_10352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10364)
static void C_fcall f_10364(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10403)
static void C_ccall f_10403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10395)
static void C_ccall f_10395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10355)
static void C_ccall f_10355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10358)
static void C_ccall f_10358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10069)
static void C_fcall f_10069(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10150)
static void C_fcall f_10150(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10177)
static void C_ccall f_10177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10179)
static void C_fcall f_10179(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10339)
static void C_ccall f_10339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10327)
static void C_ccall f_10327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10308)
static void C_ccall f_10308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10290)
static void C_ccall f_10290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10275)
static void C_ccall f_10275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10245)
static void C_ccall f_10245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10230)
static void C_ccall f_10230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10202)
static void C_ccall f_10202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10127)
static void C_fcall f_10127(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10139)
static void C_ccall f_10139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10135)
static void C_ccall f_10135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10010)
static void C_ccall f_10010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10016)
static void C_ccall f_10016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10023)
static void C_fcall f_10023(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10026)
static void C_ccall f_10026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9942)
static void C_ccall f_9942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9942)
static void C_ccall f_9942r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9962)
static C_word C_fcall f_9962(C_word *a,C_word t0);
C_noret_decl(f_9957)
static C_word C_fcall f_9957(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_9944)
static C_word C_fcall f_9944(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9920)
static void C_ccall f_9920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9927)
static void C_ccall f_9927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9843)
static void C_ccall f_9843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9853)
static void C_ccall f_9853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9856)
static void C_ccall f_9856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9862)
static void C_ccall f_9862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9901)
static void C_ccall f_9901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9905)
static void C_ccall f_9905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9865)
static void C_ccall f_9865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9868)
static void C_ccall f_9868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9871)
static void C_ccall f_9871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9754)
static void C_ccall f_9754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9764)
static void C_ccall f_9764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9767)
static void C_ccall f_9767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9830)
static void C_ccall f_9830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9770)
static void C_ccall f_9770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9826)
static void C_ccall f_9826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9773)
static void C_ccall f_9773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9812)
static void C_ccall f_9812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9816)
static void C_ccall f_9816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9776)
static void C_ccall f_9776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9779)
static void C_ccall f_9779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9785)
static void C_ccall f_9785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9733)
static void C_fcall f_9733(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9740)
static void C_ccall f_9740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9717)
static void C_ccall f_9717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9710)
static void C_ccall f_9710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9670)
static void C_ccall f_9670(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9670)
static void C_ccall f_9670r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9674)
static void C_ccall f_9674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9664)
static C_word C_fcall f_9664(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3);
C_noret_decl(f_9655)
static C_word C_fcall f_9655(C_word t0);
C_noret_decl(f_9637)
static C_word C_fcall f_9637(C_word t0);
C_noret_decl(f_9619)
static C_word C_fcall f_9619(C_word t0);
C_noret_decl(f_9601)
static C_word C_fcall f_9601(C_word t0);
C_noret_decl(f_9583)
static C_word C_fcall f_9583(C_word t0);
C_noret_decl(f_9565)
static void C_ccall f_9565(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9556)
static void C_ccall f_9556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9547)
static C_word C_fcall f_9547(C_word t0);
C_noret_decl(f_9529)
static C_word C_fcall f_9529(C_word t0);
C_noret_decl(f_9511)
static C_word C_fcall f_9511(C_word t0);
C_noret_decl(f_9502)
static void C_fcall f_9502(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9493)
static C_word C_fcall f_9493(C_word t0);
C_noret_decl(f_9475)
static C_word C_fcall f_9475(C_word t0);
C_noret_decl(f_7820)
static void C_ccall f_7820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7827)
static void C_ccall f_7827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7841)
static void C_ccall f_7841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7849)
static void C_ccall f_7849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7864)
static void C_ccall f_7864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7868)
static void C_ccall f_7868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7892)
static void C_ccall f_7892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7897)
static void C_ccall f_7897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7901)
static void C_ccall f_7901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7905)
static void C_ccall f_7905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9412)
static void C_ccall f_9412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9422)
static void C_fcall f_9422(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9429)
static void C_fcall f_9429(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9392)
static void C_ccall f_9392(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9399)
static void C_ccall f_9399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9406)
static void C_ccall f_9406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9366)
static void C_ccall f_9366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9344)
static void C_ccall f_9344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9351)
static void C_ccall f_9351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9251)
static void C_ccall f_9251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9293)
static void C_ccall f_9293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9342)
static void C_ccall f_9342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9325)
static void C_ccall f_9325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9304)
static void C_ccall f_9304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9264)
static void C_fcall f_9264(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9178)
static void C_ccall f_9178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9204)
static void C_ccall f_9204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9249)
static void C_ccall f_9249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9232)
static void C_ccall f_9232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8924)
static void C_ccall f_8924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8971)
static void C_ccall f_8971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9169)
static void C_ccall f_9169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9165)
static void C_ccall f_9165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9132)
static void C_ccall f_9132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8974)
static void C_ccall f_8974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8992)
static void C_ccall f_8992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9058)
static void C_fcall f_9058(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9073)
static void C_ccall f_9073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_fcall f_8995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9029)
static void C_fcall f_9029(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8998)
static void C_ccall f_8998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9027)
static void C_ccall f_9027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9023)
static void C_ccall f_9023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9019)
static void C_ccall f_9019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8717)
static void C_ccall f_8717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8747)
static void C_ccall f_8747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8847)
static void C_fcall f_8847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8870)
static void C_fcall f_8870(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8884)
static void C_ccall f_8884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8888)
static void C_ccall f_8888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8857)
static void C_ccall f_8857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8807)
static void C_ccall f_8807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8811)
static void C_ccall f_8811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8756)
static void C_ccall f_8756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8764)
static void C_fcall f_8764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8741)
static void C_ccall f_8741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8429)
static void C_ccall f_8429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8436)
static void C_fcall f_8436(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8475)
static void C_fcall f_8475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8485)
static void C_fcall f_8485(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8616)
static void C_ccall f_8616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8620)
static void C_ccall f_8620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8549)
static void C_ccall f_8549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8545)
static void C_ccall f_8545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8483)
static void C_ccall f_8483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8479)
static void C_ccall f_8479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8311)
static void C_ccall f_8311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8140)
static void C_ccall f_8140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_fcall f_8254(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8192)
static void C_ccall f_8192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8200)
static void C_ccall f_8200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8196)
static void C_ccall f_8196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8188)
static void C_ccall f_8188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8006)
static void C_ccall f_8006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8013)
static void C_fcall f_8013(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8016)
static void C_ccall f_8016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8065)
static void C_ccall f_8065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8061)
static void C_ccall f_8061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8056)
static void C_ccall f_8056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8042)
static void C_ccall f_8042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8054)
static void C_ccall f_8054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8050)
static void C_ccall f_8050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7952)
static void C_ccall f_7952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6918)
static void C_ccall f_6918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6922)
static void C_ccall f_6922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6925)
static void C_ccall f_6925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6928)
static void C_ccall f_6928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7737)
static void C_ccall f_7737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static void C_ccall f_7536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7541)
static void C_ccall f_7541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7545)
static void C_ccall f_7545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7554)
static void C_ccall f_7554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7712)
static void C_ccall f_7712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7557)
static void C_ccall f_7557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7689)
static void C_ccall f_7689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7560)
static void C_ccall f_7560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7669)
static void C_ccall f_7669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7593)
static void C_ccall f_7593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7633)
static void C_ccall f_7633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7591)
static void C_ccall f_7591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7572)
static void C_ccall f_7572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7583)
static void C_ccall f_7583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7579)
static void C_ccall f_7579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7072)
static void C_fcall f_7072(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7091)
static void C_fcall f_7091(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7192)
static void C_ccall f_7192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7299)
static void C_ccall f_7299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7446)
static void C_ccall f_7446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7449)
static void C_ccall f_7449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7452)
static void C_ccall f_7452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7454)
static void C_ccall f_7454(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_ccall f_7470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7462)
static void C_ccall f_7462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7302)
static void C_ccall f_7302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7311)
static void C_fcall f_7311(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7421)
static void C_ccall f_7421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7409)
static void C_ccall f_7409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7388)
static void C_ccall f_7388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7369)
static void C_ccall f_7369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7357)
static void C_ccall f_7357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7332)
static void C_ccall f_7332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7327)
static void C_ccall f_7327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7198)
static void C_ccall f_7198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7203)
static void C_fcall f_7203(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7289)
static void C_ccall f_7289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7215)
static void C_fcall f_7215(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7257)
static void C_ccall f_7257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7115)
static void C_ccall f_7115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7123)
static void C_fcall f_7123(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6985)
static void C_fcall f_6985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6992)
static void C_ccall f_6992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7066)
static void C_ccall f_7066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7007)
static void C_ccall f_7007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7013)
static void C_ccall f_7013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7053)
static void C_ccall f_7053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7028)
static void C_ccall f_7028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7042)
static void C_ccall f_7042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7045)
static void C_ccall f_7045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_ccall f_6995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6942)
static void C_fcall f_6942(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6937)
static void C_ccall f_6937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6878)
static void C_ccall f_6878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6791)
static void C_fcall f_6791(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6797)
static void C_fcall f_6797(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6866)
static void C_ccall f_6866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6843)
static void C_ccall f_6843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6816)
static void C_ccall f_6816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6823)
static void C_ccall f_6823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_fcall f_6759(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_fcall f_6892(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6629)
static void C_ccall f_6629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6726)
static void C_ccall f_6726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6696)
static void C_ccall f_6696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6699)
static void C_ccall f_6699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6677)
static void C_ccall f_6677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6576)
static void C_fcall f_6576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6567)
static void C_fcall f_6567(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6575)
static void C_ccall f_6575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6164)
static void C_fcall f_6164(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6295)
static void C_fcall f_6295(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6300)
static void C_fcall f_6300(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6538)
static void C_ccall f_6538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6501)
static void C_ccall f_6501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6319)
static void C_fcall f_6319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_fcall f_6324(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6266)
static void C_ccall f_6266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6272)
static C_word C_fcall f_6272(C_word t0);
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6214)
static void C_ccall f_6214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6222)
static void C_fcall f_6222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6242)
static void C_ccall f_6242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6167)
static void C_fcall f_6167(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6179)
static void C_fcall f_6179(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6197)
static void C_ccall f_6197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6201)
static void C_ccall f_6201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6126)
static void C_ccall f_6126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6045)
static void C_ccall f_6045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6108)
static void C_ccall f_6108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6048)
static void C_fcall f_6048(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5962)
static void C_fcall f_5962(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6043)
static void C_ccall f_6043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_fcall f_5965(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5213)
static void C_ccall f_5213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_fcall f_5652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5658)
static void C_fcall f_5658(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5680)
static void C_fcall f_5680(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5703)
static void C_fcall f_5703(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5772)
static void C_ccall f_5772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_fcall f_5475(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5485)
static void C_fcall f_5485(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5531)
static void C_fcall f_5531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5583)
static void C_ccall f_5583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5549)
static void C_fcall f_5549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5508)
static void C_ccall f_5508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5483)
static void C_ccall f_5483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5215)
static void C_fcall f_5215(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5348)
static void C_ccall f_5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_ccall f_5431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5374)
static void C_ccall f_5374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5364)
static void C_ccall f_5364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5227)
static void C_fcall f_5227(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5316)
static void C_ccall f_5316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_fcall f_5250(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_fcall f_4656(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5146)
static void C_fcall f_5146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5065)
static void C_fcall f_5065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5019)
static void C_fcall f_5019(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_fcall f_5022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_fcall f_4982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4944)
static void C_fcall f_4944(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4878)
static void C_fcall f_4878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_fcall f_4674(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_fcall f_4686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_ccall f_4705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_fcall f_4677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_fcall f_4622(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4582)
static void C_fcall f_4582(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4601)
static void C_fcall f_4601(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_fcall f_4532(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4544)
static void C_ccall f_4544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_fcall f_4436(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4423)
static void C_ccall f_4423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4238)
static void C_fcall f_4238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4340)
static void C_fcall f_4340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_fcall f_4115(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4175)
static void C_fcall f_4175(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_fcall f_4187(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_ccall f_4119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_fcall f_3936(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3943)
static void C_ccall f_3943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_fcall f_3974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_fcall f_3991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4010)
static void C_fcall f_4010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_fcall f_3971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_fcall f_3887(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3914)
static void C_ccall f_3914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3716)
static void C_fcall f_3716(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3711)
static void C_fcall f_3711(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3618)
static void C_fcall f_3618(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_fcall f_3640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3586)
static void C_fcall f_3586(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3537)
static void C_fcall f_3537(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3547)
static void C_fcall f_3547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3519)
static void C_fcall f_3519(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

C_noret_decl(trf_13406)
static void C_fcall trf_13406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13406(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13406(t0,t1,t2);}

C_noret_decl(trf_12944)
static void C_fcall trf_12944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12944(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12944(t0,t1,t2);}

C_noret_decl(trf_12790)
static void C_fcall trf_12790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12790(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12790(t0,t1,t2);}

C_noret_decl(trf_12693)
static void C_fcall trf_12693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12693(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12693(t0,t1,t2);}

C_noret_decl(trf_12560)
static void C_fcall trf_12560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12560(t0,t1);}

C_noret_decl(trf_12576)
static void C_fcall trf_12576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12576(t0,t1);}

C_noret_decl(trf_12392)
static void C_fcall trf_12392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12392(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12392(t0,t1,t2);}

C_noret_decl(trf_12123)
static void C_fcall trf_12123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12123(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12123(t0,t1,t2,t3);}

C_noret_decl(trf_12113)
static void C_fcall trf_12113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12113(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12113(t0,t1,t2,t3);}

C_noret_decl(trf_11962)
static void C_fcall trf_11962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11962(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11962(t0,t1,t2);}

C_noret_decl(trf_11812)
static void C_fcall trf_11812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11812(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11812(t0,t1,t2);}

C_noret_decl(trf_11802)
static void C_fcall trf_11802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11802(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11802(t0,t1,t2);}

C_noret_decl(trf_11568)
static void C_fcall trf_11568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11568(t0,t1);}

C_noret_decl(trf_11507)
static void C_fcall trf_11507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11507(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11507(t0,t1);}

C_noret_decl(trf_11456)
static void C_fcall trf_11456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11456(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11456(t0,t1,t2);}

C_noret_decl(trf_11390)
static void C_fcall trf_11390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11390(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11390(t0,t1,t2);}

C_noret_decl(trf_11241)
static void C_fcall trf_11241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11241(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11241(t0,t1,t2);}

C_noret_decl(trf_11292)
static void C_fcall trf_11292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11292(t0,t1);}

C_noret_decl(trf_11304)
static void C_fcall trf_11304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11304(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11304(t0,t1);}

C_noret_decl(trf_10927)
static void C_fcall trf_10927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10927(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10927(t0,t1,t2);}

C_noret_decl(trf_10955)
static void C_fcall trf_10955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10955(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10955(t0,t1);}

C_noret_decl(trf_10437)
static void C_fcall trf_10437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10437(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10437(t0,t1);}

C_noret_decl(trf_10445)
static void C_fcall trf_10445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10445(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10445(t0,t1);}

C_noret_decl(trf_10345)
static void C_fcall trf_10345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10345(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10345(t0,t1);}

C_noret_decl(trf_10364)
static void C_fcall trf_10364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10364(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10364(t0,t1,t2);}

C_noret_decl(trf_10069)
static void C_fcall trf_10069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10069(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10069(t0,t1);}

C_noret_decl(trf_10150)
static void C_fcall trf_10150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10150(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10150(t0,t1,t2);}

C_noret_decl(trf_10179)
static void C_fcall trf_10179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10179(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10179(t0,t1,t2);}

C_noret_decl(trf_10127)
static void C_fcall trf_10127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10127(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10127(t0,t1,t2,t3);}

C_noret_decl(trf_10023)
static void C_fcall trf_10023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10023(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10023(t0,t1);}

C_noret_decl(trf_9733)
static void C_fcall trf_9733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9733(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9733(t0,t1,t2,t3);}

C_noret_decl(trf_9502)
static void C_fcall trf_9502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9502(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9502(t0,t1,t2);}

C_noret_decl(trf_9422)
static void C_fcall trf_9422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9422(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9422(t0,t1,t2);}

C_noret_decl(trf_9429)
static void C_fcall trf_9429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9429(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9429(t0,t1);}

C_noret_decl(trf_9264)
static void C_fcall trf_9264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9264(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9264(t0,t1);}

C_noret_decl(trf_9058)
static void C_fcall trf_9058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9058(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9058(t0,t1);}

C_noret_decl(trf_8995)
static void C_fcall trf_8995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8995(t0,t1);}

C_noret_decl(trf_9029)
static void C_fcall trf_9029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9029(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9029(t0,t1,t2,t3);}

C_noret_decl(trf_8847)
static void C_fcall trf_8847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8847(t0,t1);}

C_noret_decl(trf_8870)
static void C_fcall trf_8870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8870(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8870(t0,t1,t2);}

C_noret_decl(trf_8764)
static void C_fcall trf_8764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8764(t0,t1);}

C_noret_decl(trf_8436)
static void C_fcall trf_8436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8436(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8436(t0,t1);}

C_noret_decl(trf_8475)
static void C_fcall trf_8475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8475(t0,t1);}

C_noret_decl(trf_8485)
static void C_fcall trf_8485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8485(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8485(t0,t1,t2);}

C_noret_decl(trf_8254)
static void C_fcall trf_8254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8254(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8254(t0,t1);}

C_noret_decl(trf_8013)
static void C_fcall trf_8013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8013(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8013(t0,t1);}

C_noret_decl(trf_7072)
static void C_fcall trf_7072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7072(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7072(t0,t1,t2);}

C_noret_decl(trf_7091)
static void C_fcall trf_7091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7091(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7091(t0,t1);}

C_noret_decl(trf_7311)
static void C_fcall trf_7311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7311(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7311(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7203)
static void C_fcall trf_7203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7203(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7203(t0,t1,t2,t3);}

C_noret_decl(trf_7215)
static void C_fcall trf_7215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7215(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7215(t0,t1,t2,t3);}

C_noret_decl(trf_7123)
static void C_fcall trf_7123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7123(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7123(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6985)
static void C_fcall trf_6985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6985(t0,t1,t2);}

C_noret_decl(trf_6942)
static void C_fcall trf_6942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6942(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6942(t0,t1,t2);}

C_noret_decl(trf_6791)
static void C_fcall trf_6791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6791(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6791(t0,t1);}

C_noret_decl(trf_6797)
static void C_fcall trf_6797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6797(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6797(t0,t1);}

C_noret_decl(trf_6759)
static void C_fcall trf_6759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6759(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6759(t0,t1);}

C_noret_decl(trf_6892)
static void C_fcall trf_6892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6892(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6892(t0,t1,t2,t3);}

C_noret_decl(trf_6576)
static void C_fcall trf_6576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6576(t0,t1);}

C_noret_decl(trf_6567)
static void C_fcall trf_6567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6567(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6567(t0,t1,t2);}

C_noret_decl(trf_6164)
static void C_fcall trf_6164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6164(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6164(t0,t1,t2,t3);}

C_noret_decl(trf_6295)
static void C_fcall trf_6295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6295(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6295(t0,t1);}

C_noret_decl(trf_6300)
static void C_fcall trf_6300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6300(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6300(t0,t1,t2,t3);}

C_noret_decl(trf_6319)
static void C_fcall trf_6319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6319(t0,t1);}

C_noret_decl(trf_6324)
static void C_fcall trf_6324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6324(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6324(t0,t1,t2,t3);}

C_noret_decl(trf_6222)
static void C_fcall trf_6222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6222(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6222(t0,t1,t2);}

C_noret_decl(trf_6167)
static void C_fcall trf_6167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6167(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6167(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6179)
static void C_fcall trf_6179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6179(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6179(t0,t1,t2);}

C_noret_decl(trf_6048)
static void C_fcall trf_6048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6048(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6048(t0,t1,t2,t3);}

C_noret_decl(trf_5962)
static void C_fcall trf_5962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5962(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5962(t0,t1,t2,t3);}

C_noret_decl(trf_5965)
static void C_fcall trf_5965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5965(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5965(t0,t1,t2,t3);}

C_noret_decl(trf_5652)
static void C_fcall trf_5652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5652(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5652(t0,t1,t2);}

C_noret_decl(trf_5658)
static void C_fcall trf_5658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5658(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5658(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5680)
static void C_fcall trf_5680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5680(t0,t1);}

C_noret_decl(trf_5703)
static void C_fcall trf_5703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5703(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5703(t0,t1,t2);}

C_noret_decl(trf_5475)
static void C_fcall trf_5475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5475(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5475(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5485)
static void C_fcall trf_5485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5485(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5485(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5531)
static void C_fcall trf_5531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5531(t0,t1);}

C_noret_decl(trf_5549)
static void C_fcall trf_5549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5549(t0,t1);}

C_noret_decl(trf_5215)
static void C_fcall trf_5215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5215(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5215(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5227)
static void C_fcall trf_5227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5227(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5227(t0,t1,t2,t3);}

C_noret_decl(trf_5250)
static void C_fcall trf_5250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5250(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5250(t0,t1);}

C_noret_decl(trf_4656)
static void C_fcall trf_4656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4656(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4656(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5146)
static void C_fcall trf_5146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5146(t0,t1);}

C_noret_decl(trf_5065)
static void C_fcall trf_5065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5065(t0,t1);}

C_noret_decl(trf_5019)
static void C_fcall trf_5019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5019(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5019(t0,t1);}

C_noret_decl(trf_5022)
static void C_fcall trf_5022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5022(t0,t1);}

C_noret_decl(trf_4982)
static void C_fcall trf_4982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4982(t0,t1);}

C_noret_decl(trf_4944)
static void C_fcall trf_4944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4944(t0,t1);}

C_noret_decl(trf_4878)
static void C_fcall trf_4878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4878(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4878(t0,t1);}

C_noret_decl(trf_4674)
static void C_fcall trf_4674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4674(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4674(t0,t1);}

C_noret_decl(trf_4686)
static void C_fcall trf_4686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4686(t0,t1);}

C_noret_decl(trf_4677)
static void C_fcall trf_4677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4677(t0,t1);}

C_noret_decl(trf_4622)
static void C_fcall trf_4622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4622(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4622(t0,t1,t2);}

C_noret_decl(trf_4582)
static void C_fcall trf_4582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4582(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4582(t0,t1,t2);}

C_noret_decl(trf_4601)
static void C_fcall trf_4601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4601(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4601(t0,t1);}

C_noret_decl(trf_4532)
static void C_fcall trf_4532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4532(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4532(t0,t1,t2);}

C_noret_decl(trf_4436)
static void C_fcall trf_4436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4436(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4436(t0,t1,t2);}

C_noret_decl(trf_4238)
static void C_fcall trf_4238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4238(t0,t1);}

C_noret_decl(trf_4340)
static void C_fcall trf_4340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4340(t0,t1);}

C_noret_decl(trf_4115)
static void C_fcall trf_4115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4115(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4115(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4175)
static void C_fcall trf_4175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4175(t0,t1);}

C_noret_decl(trf_4187)
static void C_fcall trf_4187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4187(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4187(t0,t1);}

C_noret_decl(trf_3936)
static void C_fcall trf_3936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3936(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3936(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3974)
static void C_fcall trf_3974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3974(t0,t1);}

C_noret_decl(trf_3991)
static void C_fcall trf_3991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3991(t0,t1,t2);}

C_noret_decl(trf_4010)
static void C_fcall trf_4010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4010(t0,t1);}

C_noret_decl(trf_3971)
static void C_fcall trf_3971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3971(t0,t1);}

C_noret_decl(trf_3887)
static void C_fcall trf_3887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3887(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3887(t0,t1,t2);}

C_noret_decl(trf_3716)
static void C_fcall trf_3716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3716(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3716(t0,t1);}

C_noret_decl(trf_3711)
static void C_fcall trf_3711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3711(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3711(t0,t1,t2);}

C_noret_decl(trf_3618)
static void C_fcall trf_3618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3618(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3618(t0,t1,t2,t3);}

C_noret_decl(trf_3640)
static void C_fcall trf_3640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3640(t0,t1);}

C_noret_decl(trf_3586)
static void C_fcall trf_3586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3586(t0,t1);}

C_noret_decl(trf_3537)
static void C_fcall trf_3537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3537(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3537(t0,t1,t2);}

C_noret_decl(trf_3547)
static void C_fcall trf_3547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3547(t0,t1);}

C_noret_decl(trf_3519)
static void C_fcall trf_3519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3519(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3519(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_expand_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("expand_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3764)){
C_save(t1);
C_rereclaim2(3764*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,391);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],12,"\003sysfeatures");
lf[4]=C_h_intern(&lf[4],2,"pp");
lf[5]=C_h_intern(&lf[5],5,"print");
lf[8]=C_h_intern(&lf[8],23,"\003syscurrent-environment");
lf[9]=C_h_intern(&lf[9],28,"\003syscurrent-meta-environment");
lf[11]=C_h_intern(&lf[11],7,"\003sysget");
lf[12]=C_h_intern(&lf[12],16,"\004coremacro-alias");
lf[14]=C_h_intern(&lf[14],7,"<macro>");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\011aliasing ");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\004 to ");
lf[17]=C_h_intern(&lf[17],8,"\003sysput!");
lf[18]=C_h_intern(&lf[18],6,"gensym");
lf[19]=C_h_intern(&lf[19],21,"\003sysqualified-symbol\077");
lf[21]=C_h_intern(&lf[21],7,"\003sysmap");
lf[22]=C_h_intern(&lf[22],16,"\003sysstrip-syntax");
lf[23]=C_h_intern(&lf[23],21,"\003sysalias-global-hook");
lf[24]=C_h_intern(&lf[24],3,"get");
lf[25]=C_h_intern(&lf[25],12,"list->vector");
lf[26]=C_h_intern(&lf[26],12,"vector->list");
lf[27]=C_h_intern(&lf[27],9,"\003syserror");
lf[28]=C_h_intern(&lf[28],12,"strip-syntax");
lf[29]=C_h_intern(&lf[29],21,"\003sysmacro-environment");
lf[30]=C_h_intern(&lf[30],29,"\003syschicken-macro-environment");
lf[31]=C_h_intern(&lf[31],33,"\003syschicken-ffi-macro-environment");
lf[32]=C_h_intern(&lf[32],28,"\003sysextend-macro-environment");
lf[33]=C_h_intern(&lf[33],14,"\003syscopy-macro");
lf[34]=C_h_intern(&lf[34],6,"macro\077");
lf[35]=C_h_intern(&lf[35],20,"\003sysunregister-macro");
lf[36]=C_h_intern(&lf[36],4,"caar");
lf[37]=C_h_intern(&lf[37],15,"undefine-macro!");
lf[38]=C_h_intern(&lf[38],12,"\003sysexpand-0");
lf[39]=C_h_intern(&lf[39],9,"\003sysabort");
lf[40]=C_h_intern(&lf[40],9,"condition");
lf[41]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[42]=C_h_intern(&lf[42],13,"string-append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[45]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[46]=C_h_intern(&lf[46],3,"exn");
lf[47]=C_h_intern(&lf[47],3,"-->");
lf[48]=C_h_intern(&lf[48],22,"with-exception-handler");
lf[49]=C_h_intern(&lf[49],30,"call-with-current-continuation");
lf[50]=C_h_intern(&lf[50],10,"\000STATIC-SE");
lf[51]=C_h_intern(&lf[51],10,"\003sysappend");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020invoking macro: ");
lf[53]=C_h_intern(&lf[53],21,"\003syssyntax-error-hook");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[55]=C_h_intern(&lf[55],7,"\000EXPAND");
lf[56]=C_h_intern(&lf[56],3,"\000SE");
lf[57]=C_h_intern(&lf[57],1,"_");
lf[58]=C_h_intern(&lf[58],3,"let");
lf[59]=C_h_intern(&lf[59],8,"\004corelet");
lf[60]=C_h_intern(&lf[60],16,"\004coreloop-lambda");
lf[61]=C_h_intern(&lf[61],11,"\004coreletrec");
lf[62]=C_h_intern(&lf[62],8,"\004coreapp");
lf[63]=C_h_intern(&lf[63],4,"cadr");
lf[64]=C_h_intern(&lf[64],16,"\003syscheck-syntax");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[66]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[67]=C_h_intern(&lf[67],10,"\003syssetter");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_h_intern(&lf[69],4,"set!");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],9,"\004coreset!");
lf[72]=C_h_intern(&lf[72],25,"\003sysenable-runtime-macros");
lf[73]=C_h_intern(&lf[73],17,"\003sysmodule-rename");
lf[74]=C_h_intern(&lf[74],18,"\003sysstring->symbol");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[77]=C_h_intern(&lf[77],22,"\003sysregister-undefined");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\025(ALIAS) global alias ");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[80]=C_h_intern(&lf[80],18,"\003syscurrent-module");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\023(ALIAS) primitive: ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\020(ALIAS) marked: ");
lf[83]=C_h_intern(&lf[83],14,"\004coreprimitive");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000 (ALIAS) in current environment: ");
lf[85]=C_h_intern(&lf[85],12,"\004corealiased");
lf[86]=C_h_intern(&lf[86],10,"\003sysexpand");
lf[87]=C_h_intern(&lf[87],6,"expand");
lf[88]=C_h_intern(&lf[88],25,"\003sysextended-lambda-list\077");
lf[89]=C_h_intern(&lf[89],6,"#!rest");
lf[90]=C_h_intern(&lf[90],10,"#!optional");
lf[91]=C_h_intern(&lf[91],5,"#!key");
lf[92]=C_h_intern(&lf[92],7,"reverse");
lf[93]=C_h_intern(&lf[93],31,"\003sysexpand-extended-lambda-list");
lf[94]=C_h_intern(&lf[94],5,"cadar");
lf[95]=C_h_intern(&lf[95],5,"quote");
lf[96]=C_h_intern(&lf[96],15,"\003sysget-keyword");
lf[97]=C_h_intern(&lf[97],11,"\004corelambda");
lf[98]=C_h_intern(&lf[98],15,"string->keyword");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[101]=C_h_intern(&lf[101],3,"tmp");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[110]=C_h_intern(&lf[110],14,"let-optionals*");
lf[111]=C_h_intern(&lf[111],13,"let-optionals");
lf[112]=C_h_intern(&lf[112],8,"optional");
lf[113]=C_h_intern(&lf[113],4,"let*");
lf[114]=C_h_intern(&lf[114],3,"map");
lf[115]=C_h_intern(&lf[115],21,"\003syscanonicalize-body");
lf[116]=C_h_intern(&lf[116],5,"begin");
lf[117]=C_h_intern(&lf[117],6,"define");
lf[118]=C_h_intern(&lf[118],13,"define-values");
lf[119]=C_h_intern(&lf[119],5,"\000BODY");
lf[120]=C_h_intern(&lf[120],20,"\003syscall-with-values");
lf[121]=C_h_intern(&lf[121],14,"\004coreundefined");
lf[122]=C_h_intern(&lf[122],3,"cdr");
lf[123]=C_h_intern(&lf[123],13,"letrec-syntax");
lf[124]=C_h_intern(&lf[124],13,"define-syntax");
lf[125]=C_h_intern(&lf[125],5,"cdadr");
lf[126]=C_h_intern(&lf[126],6,"lambda");
lf[127]=C_h_intern(&lf[127],5,"caadr");
lf[128]=C_h_intern(&lf[128],25,"\003sysexpand-curried-define");
lf[129]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[132]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-syntax\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[138]=C_h_intern(&lf[138],24,"\003sysline-number-database");
lf[139]=C_h_intern(&lf[139],24,"\003syssyntax-error-culprit");
lf[140]=C_h_intern(&lf[140],15,"\003syssignal-hook");
lf[141]=C_h_intern(&lf[141],13,"\000syntax-error");
lf[142]=C_h_intern(&lf[142],12,"syntax-error");
lf[143]=C_h_intern(&lf[143],15,"get-line-number");
lf[144]=C_h_intern(&lf[144],18,"\003syshash-table-ref");
lf[145]=C_h_intern(&lf[145],8,"keyword\077");
lf[146]=C_h_intern(&lf[146],14,"symbol->string");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[156]=C_h_intern(&lf[156],4,"pair");
lf[157]=C_h_intern(&lf[157],5,"pair\077");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[159]=C_h_intern(&lf[159],8,"variable");
lf[160]=C_h_intern(&lf[160],7,"symbol\077");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[162]=C_h_intern(&lf[162],6,"symbol");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[164]=C_h_intern(&lf[164],4,"list");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[166]=C_h_intern(&lf[166],6,"number");
lf[167]=C_h_intern(&lf[167],7,"number\077");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[169]=C_h_intern(&lf[169],6,"string");
lf[170]=C_h_intern(&lf[170],7,"string\077");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[172]=C_h_intern(&lf[172],11,"lambda-list");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[177]=C_h_intern(&lf[177],18,"\003syser-transformer");
lf[178]=C_h_intern(&lf[178],12,"\000RENAME/RENV");
lf[179]=C_h_intern(&lf[179],14,"\000RENAME/LOOKUP");
lf[180]=C_h_intern(&lf[180],20,"\000RENAME/LOOKUP/MACRO");
lf[181]=C_h_intern(&lf[181],7,"\000RENAME");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\016  (lookup/DSE ");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\005 --> ");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[186]=C_h_intern(&lf[186],8,"\000COMPARE");
lf[187]=C_h_intern(&lf[187],17,"\003sysexpand-import");
lf[188]=C_h_intern(&lf[188],17,"\003sysstring-append");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[190]=C_h_intern(&lf[190],18,"\003syssymbol->string");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid prefix");
lf[194]=C_h_intern(&lf[194],15,"\003sysfind-module");
lf[195]=C_h_intern(&lf[195],8,"\003sysload");
lf[196]=C_h_intern(&lf[196],16,"\003sysdynamic-wind");
lf[197]=C_h_intern(&lf[197],26,"\003sysmeta-macro-environment");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000$can not import from undefined module");
lf[199]=C_h_intern(&lf[199],18,"\003sysfind-extension");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\007.import");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[204]=C_h_intern(&lf[204],8,"\003syswarn");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\037renamed identifier not imported");
lf[206]=C_h_intern(&lf[206],12,"\003sysfor-each");
lf[207]=C_h_intern(&lf[207],8,"\003sysdelq");
lf[208]=C_h_intern(&lf[208],4,"cdar");
lf[209]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000");
lf[210]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[212]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000$re-importing already imported syntax");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\047re-importing already imported identfier");
lf[215]=C_h_intern(&lf[215],25,"\003sysmark-imported-symbols");
lf[216]=C_h_intern(&lf[216],10,"<toplevel>");
lf[217]=C_h_intern(&lf[217],2,"\000S");
lf[218]=C_h_intern(&lf[218],2,"\000V");
lf[219]=C_h_intern(&lf[219],7,"\000IMPORT");
lf[220]=C_h_intern(&lf[220],6,"module");
lf[221]=C_h_intern(&lf[221],14,"\003sysblock-set!");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[225]=C_h_intern(&lf[225],6,"prefix");
lf[226]=C_h_intern(&lf[226],6,"except");
lf[227]=C_h_intern(&lf[227],6,"rename");
lf[228]=C_h_intern(&lf[228],4,"only");
lf[229]=C_h_intern(&lf[229],29,"\003sysinitial-macro-environment");
lf[230]=C_h_intern(&lf[230],24,"\003sysprocess-syntax-rules");
lf[231]=C_h_intern(&lf[231],7,"\003syscar");
lf[232]=C_h_intern(&lf[232],7,"\003syscdr");
lf[233]=C_h_intern(&lf[233],11,"\003sysvector\077");
lf[234]=C_h_intern(&lf[234],17,"\003sysvector-length");
lf[235]=C_h_intern(&lf[235],14,"\003sysvector-ref");
lf[236]=C_h_intern(&lf[236],16,"\003sysvector->list");
lf[237]=C_h_intern(&lf[237],16,"\003syslist->vector");
lf[238]=C_h_intern(&lf[238],6,"\003sys>=");
lf[239]=C_h_intern(&lf[239],5,"\003sys=");
lf[240]=C_h_intern(&lf[240],5,"\003sys+");
lf[241]=C_h_intern(&lf[241],8,"\003syscons");
lf[242]=C_h_intern(&lf[242],7,"\003syseq\077");
lf[243]=C_h_intern(&lf[243],10,"\003sysequal\077");
lf[244]=C_h_intern(&lf[244],9,"\003syslist\077");
lf[245]=C_h_intern(&lf[245],9,"\003sysmap-n");
lf[246]=C_h_intern(&lf[246],9,"\003sysnull\077");
lf[247]=C_h_intern(&lf[247],9,"\003syspair\077");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\026ill-formed syntax rule");
lf[250]=C_h_intern(&lf[250],6,"syntax");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000,template dimension error (too few ellipses\077)");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\021too many ellipses");
lf[253]=C_h_intern(&lf[253],9,"\003sysapply");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000 segment matching not implemented");
lf[255]=C_h_intern(&lf[255],4,"temp");
lf[256]=C_h_intern(&lf[256],4,"tail");
lf[257]=C_h_intern(&lf[257],2,"or");
lf[258]=C_h_intern(&lf[258],4,"loop");
lf[259]=C_h_intern(&lf[259],1,"l");
lf[260]=C_h_intern(&lf[260],5,"input");
lf[261]=C_h_intern(&lf[261],4,"else");
lf[262]=C_h_intern(&lf[262],4,"cond");
lf[263]=C_h_intern(&lf[263],7,"compare");
lf[264]=C_h_intern(&lf[264],1,"i");
lf[265]=C_h_intern(&lf[265],3,"and");
lf[266]=C_h_intern(&lf[266],29,"\003sysdefault-macro-environment");
lf[272]=C_h_intern(&lf[272],26,"set-module-undefined-list!");
lf[273]=C_h_intern(&lf[273],21,"module-undefined-list");
lf[276]=C_h_intern(&lf[276],16,"\003sysmodule-table");
lf[277]=C_h_intern(&lf[277],5,"error");
lf[278]=C_h_intern(&lf[278],6,"import");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\020module not found");
lf[280]=C_h_intern(&lf[280],28,"\003systoplevel-definition-hook");
lf[281]=C_h_intern(&lf[281],28,"\003sysregister-meta-expression");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\047redefinition of imported syntax binding");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000&redefinition of imported value binding");
lf[285]=C_h_intern(&lf[285],19,"\003sysregister-export");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\011defined: ");
lf[287]=C_h_intern(&lf[287],15,"\003sysfind-export");
lf[288]=C_h_intern(&lf[288],26,"\003sysregister-syntax-export");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\020defined syntax: ");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000!use of syntax precedes definition");
lf[291]=C_h_intern(&lf[291],19,"\003sysregister-module");
lf[292]=C_h_intern(&lf[292],8,"\000MARKING");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\014 in module `");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000!indirect export of syntax binding");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\033indirect reexport of syntax");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\042indirect export of unknown binding");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\024  merged has length ");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\010merging ");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\033 se\047s with total length of ");
lf[303]=C_h_intern(&lf[303],32,"\003syscompiled-module-registration");
lf[304]=C_h_intern(&lf[304],28,"\003sysregister-compiled-module");
lf[305]=C_h_intern(&lf[305],4,"cons");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000((internal) exported syntax has no source");
lf[307]=C_h_intern(&lf[307],4,"eval");
lf[308]=C_h_intern(&lf[308],29,"\003sysregister-primitive-module");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\0001unknown macro referenced while registering module");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\002#%");
lf[311]=C_h_intern(&lf[311],18,"module-exists-list");
lf[312]=C_h_intern(&lf[312],19,"\003sysfinalize-module");
lf[313]=C_h_intern(&lf[313],6,"\000DLIST");
lf[314]=C_h_intern(&lf[314],7,"\000SDLIST");
lf[315]=C_h_intern(&lf[315],9,"\000IEXPORTS");
lf[316]=C_h_intern(&lf[316],9,"\000VEXPORTS");
lf[317]=C_h_intern(&lf[317],9,"\000SEXPORTS");
lf[318]=C_h_intern(&lf[318],8,"\000EXPORTS");
lf[319]=C_h_intern(&lf[319],6,"\000FIXUP");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000$(internal) indirect export not found");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000(reference to possibly unbound identifier");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\015reexporting: ");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000 exported identifier for module `");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\026\047 has not been defined");
lf[326]=C_h_intern(&lf[326],16,"\003sysmacro-subset");
lf[327]=C_h_intern(&lf[327],14,"make-parameter");
lf[328]=C_h_intern(&lf[328],12,"syntax-rules");
lf[329]=C_h_intern(&lf[329],3,"...");
lf[330]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[331]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[332]=C_h_intern(&lf[332],6,"export");
lf[333]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000!`export\047 used outside module body");
lf[336]=C_h_intern(&lf[336],16,"begin-for-syntax");
lf[337]=C_h_intern(&lf[337],24,"\004coreelaborationtimeonly");
lf[338]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[339]=C_h_intern(&lf[339],11,"\004coremodule");
lf[340]=C_h_intern(&lf[340],1,"*");
lf[341]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[342]=C_h_intern(&lf[342],17,"require-extension");
lf[343]=C_h_intern(&lf[343],22,"\004corerequire-extension");
lf[344]=C_h_intern(&lf[344],15,"require-library");
lf[345]=C_h_intern(&lf[345],11,"cond-expand");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[347]=C_h_intern(&lf[347],12,"\003sysfeature\077");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[350]=C_h_intern(&lf[350],3,"not");
lf[351]=C_h_intern(&lf[351],5,"delay");
lf[352]=C_h_intern(&lf[352],16,"\003sysmake-promise");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[354]=C_h_intern(&lf[354],10,"quasiquote");
lf[355]=C_h_intern(&lf[355],8,"\003syslist");
lf[356]=C_h_intern(&lf[356],17,"%unquote-splicing");
lf[357]=C_h_intern(&lf[357],1,"a");
lf[358]=C_h_intern(&lf[358],1,"b");
lf[359]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[360]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[365]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[366]=C_h_intern(&lf[366],16,"unquote-splicing");
lf[367]=C_h_intern(&lf[367],7,"unquote");
lf[368]=C_h_intern(&lf[368],2,"do");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[371]=C_h_intern(&lf[371],2,"if");
lf[372]=C_h_intern(&lf[372],6,"doloop");
lf[373]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001"
"\000\000\000\001");
lf[374]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[375]=C_h_intern(&lf[375],4,"case");
lf[376]=C_h_intern(&lf[376],8,"\003syseqv\077");
lf[377]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[378]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[379]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[380]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[381]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[382]=C_h_intern(&lf[382],2,"=>");
lf[383]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[384]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[385]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[386]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[387]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[388]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[389]=C_h_intern(&lf[389],17,"import-for-syntax");
lf[390]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\020\000hygienic-macros\376\003\000\000\002\376\001\000\000\015\000syntax-rules\376\377\016");
C_register_lf2(lf,391,create_ptable());
t2=C_mutate(&lf[0] /* (set! c152 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3486,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 38   append */
t4=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[390],C_retrieve(lf[2]));}

/* k3484 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3486,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! features ...) */,t1);
t3=C_mutate(&lf[3] /* (set! d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3488,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[6] /* (set! dd ...) */,C_retrieve2(lf[3],"d"));
t5=C_mutate(&lf[7] /* (set! dm ...) */,C_retrieve2(lf[3],"d"));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3513,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 66   make-parameter */
t7=C_retrieve(lf[327]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_END_OF_LIST);}

/* k3511 in k3484 */
static void C_ccall f_3513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3513,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1 /* (set! current-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 67   make-parameter */
t4=C_retrieve(lf[327]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}

/* k3515 in k3511 in k3484 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3517,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* (set! current-meta-environment ...) */,t1);
t3=C_mutate(&lf[10] /* (set! lookup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3519,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[13] /* (set! macro-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3537,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[20] /* (set! map-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3586,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[22]+1 /* (set! strip-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3616,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[28]+1 /* (set! strip-syntax ...) */,C_retrieve(lf[22]));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3767,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 119  make-parameter */
t9=C_retrieve(lf[327]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_END_OF_LIST);}

/* k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3767,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! macro-environment ...) */,t1);
t3=C_set_block_item(lf[30] /* chicken-macro-environment */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[31] /* chicken-ffi-macro-environment */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[32]+1 /* (set! extend-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3771,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[33]+1 /* (set! copy-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3804,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[34]+1 /* (set! macro? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3817,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[35]+1 /* (set! unregister-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3873,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[37]+1 /* (set! undefine-macro! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3924,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[38]+1 /* (set! expand-0 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3933,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(lf[72] /* enable-runtime-macros */,0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[73]+1 /* (set! module-rename ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4415,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[23]+1 /* (set! alias-global-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4433,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[86]+1 /* (set! expand ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4523,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[87]+1 /* (set! expand ...) */,C_retrieve(lf[86]));
t16=C_mutate((C_word*)lf[88]+1 /* (set! extended-lambda-list? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4576,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[92]+1);
t18=C_retrieve(lf[18]);
t19=C_mutate((C_word*)lf[93]+1 /* (set! expand-extended-lambda-list ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4619,a[2]=t17,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[92]+1);
t21=*((C_word*)lf[114]+1);
t22=C_mutate((C_word*)lf[115]+1 /* (set! canonicalize-body ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5209,a[2]=t21,a[3]=t20,a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate(&lf[137] /* (set! match-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5962,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[128]+1 /* (set! expand-curried-define ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6045,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(lf[138] /* line-number-database */,0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[139] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
t27=C_mutate((C_word*)lf[53]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6115,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[142]+1 /* (set! syntax-error ...) */,C_retrieve(lf[53]));
t29=C_mutate((C_word*)lf[143]+1 /* (set! get-line-number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6126,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[42]+1);
t31=C_retrieve(lf[145]);
t32=C_retrieve(lf[143]);
t33=*((C_word*)lf[146]+1);
t34=C_mutate((C_word*)lf[64]+1 /* (set! check-syntax ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6162,a[2]=t31,a[3]=t32,a[4]=t33,a[5]=t30,a[6]=((C_word)li71),tmp=(C_word)a,a+=7,tmp));
t35=C_mutate((C_word*)lf[177]+1 /* (set! er-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6624,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[187]+1 /* (set! expand-import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6918,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7763,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13546,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13548,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 867  ##sys#er-transformer */
t40=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t40))(3,t40,t38,t39);}

/* a13547 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13548,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
t5=C_retrieve(lf[187]);
((C_proc9)C_retrieve_proc(t5))(9,t5,t1,t2,t3,t4,C_retrieve(lf[8]),C_retrieve(lf[29]),C_SCHEME_FALSE,lf[278]);}

/* k13544 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 865  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[278],C_SCHEME_END_OF_LIST,t1);}

/* k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7766,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13536,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13538,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 873  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13537 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13538,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
t5=C_retrieve(lf[187]);
((C_proc9)C_retrieve_proc(t5))(9,t5,t1,t2,t3,t4,C_retrieve(lf[9]),C_retrieve(lf[197]),C_SCHEME_TRUE,lf[389]);}

/* k13534 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 871  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[389],C_SCHEME_END_OF_LIST,t1);}

/* k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7770,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 877  ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7770,2,t0,t1);}
t2=C_mutate((C_word*)lf[229]+1 /* (set! initial-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7773,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13394,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13396,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 882  ##sys#er-transformer */
t6=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13396(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13396,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13406,a[2]=t3,a[3]=t7,a[4]=((C_word)li198),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_13406(t9,t1,t5);}

/* loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_13406(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13406,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13462,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 893  ##sys#check-syntax */
t7=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[117],t3,lf[384]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13475,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 897  ##sys#check-syntax */
t7=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[117],t3,lf[386]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13422,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 888  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[117],t3,lf[162]);}}

/* k13420 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 889  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[4],lf[388]);}

/* k13423 in k13420 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13453,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 890  ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k13451 in k13423 in k13420 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 890  ##sys#register-export */
t2=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13426 in k13423 in k13420 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13428,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):lf[387]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k13473 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 898  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[3],lf[385]);}

/* k13476 in k13473 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13524,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 899  ##sys#current-module */
t5=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k13522 in k13476 in k13473 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 899  ##sys#register-export */
t2=C_retrieve(lf[285]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13479 in k13476 in k13473 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13481,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13504,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 902  r */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k13502 in k13479 in k13476 in k13473 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13504,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13516,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13514 in k13502 in k13479 in k13476 in k13473 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13516,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k13460 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 894  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[2],lf[383]);}

/* k13463 in k13460 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13472,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 895  ##sys#expand-curried-define */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13470 in k13463 in k13460 in loop in a13395 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 895  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_13406(t2,((C_word*)t0)[2],t1);}

/* k13392 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 879  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[117],C_SCHEME_END_OF_LIST,t1);}

/* k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13335,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13337,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 907  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13336 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13337,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13366,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 916  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[371]);}}}

/* k13364 in a13336 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13386,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 916  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k13384 in k13364 in a13336 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13388 in k13384 in k13364 in a13336 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13390,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k13333 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 904  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[265],C_SCHEME_END_OF_LIST,t1);}

/* k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13245,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13247,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 921  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13246 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13247(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13247,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13272,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 930  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[101]);}}}

/* k13270 in a13246 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 931  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k13277 in k13270 in a13246 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13279,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 932  r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[371]);}

/* k13297 in k13277 in k13270 in a13246 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 932  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13317 in k13297 in k13277 in k13270 in a13246 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13323,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13321 in k13317 in k13297 in k13277 in k13270 in a13246 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13323,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k13243 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 918  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[257],C_SCHEME_END_OF_LIST,t1);}

/* k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12912,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12914,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 937  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12914,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12921,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 940  r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[116]);}

/* k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 941  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 942  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[371]);}

/* k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 943  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[382]);}

/* k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 944  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 945  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 946  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[126]);}

/* k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12939,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12944,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word)li194),tmp=(C_word)a,a+=13,tmp));
t5=((C_word*)t3)[1];
f_12944(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_12944(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12944,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_12960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=((C_word*)t0)[11],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* expand.scm: 952  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[262],t3,lf[380]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[381]);}}

/* k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_12966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* expand.scm: 953  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k12964 in k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12966,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12973,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13002,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 954  expand */
t5=((C_word*)((C_word*)t0)[9])[1];
f_12944(t5,t4,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_13008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[11]);
/* expand.scm: 955  c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}}

/* k13006 in k12964 in k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13008,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13011,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 956  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13076,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[12]))){
t3=(C_word)C_i_length(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t3,C_fix(4));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* expand.scm: 962  c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,((C_word*)t0)[2],t5);}
else{
t5=t2;
f_13076(2,t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_13076(2,t3,C_SCHEME_FALSE);}}}

/* k13074 in k13006 in k12964 in k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13076,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13079,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 963  r */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13201,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k13199 in k13074 in k13006 in k12964 in k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13201,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13197,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 972  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12944(t4,t3,((C_word*)t0)[2]);}

/* k13195 in k13199 in k13074 in k13006 in k12964 in k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13197,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k13077 in k13074 in k13006 in k12964 in k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13079,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t10=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[253],t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13134,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t9,a[7]=t13,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 969  expand */
t15=((C_word*)((C_word*)t0)[3])[1];
f_12944(t15,t14,((C_word*)t0)[2]);}

/* k13132 in k13077 in k13074 in k13006 in k12964 in k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13134,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[371],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[120],t10));}

/* k13009 in k13006 in k12964 in k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13011,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13050,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 960  expand */
t10=((C_word*)((C_word*)t0)[3])[1];
f_12944(t10,t9,((C_word*)t0)[2]);}

/* k13048 in k13009 in k13006 in k12964 in k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13050,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k13000 in k12964 in k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_13002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13002,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k12971 in k12964 in k12958 in expand in k12937 in k12934 in k12931 in k12928 in k12925 in k12922 in k12919 in a12913 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12973,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12910 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 934  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[262],C_SCHEME_END_OF_LIST,t1);}

/* k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12742,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12744,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 977  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12744,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12748,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 979  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[375],t2,lf[379]);}

/* k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12748,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12757,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 982  r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[101]);}

/* k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 983  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 984  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[371]);}

/* k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 985  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 987  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k12767 in k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12769,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12788,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12790,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word)li192),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_12790(t9,t5,((C_word*)t0)[2]);}

/* expand in k12767 in k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_12790(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12790,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 994  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[375],t3,lf[377]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[378]);}}

/* k12804 in expand in k12767 in k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12812,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 995  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k12810 in k12804 in expand in k12767 in k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12812,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12819,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12862,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12866,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12868,a[2]=((C_word*)t0)[2],a[3]=((C_word)li191),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 997  ##sys#map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a12867 in k12810 in k12804 in expand in k12767 in k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12868,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[376],t6));}

/* k12864 in k12810 in k12804 in expand in k12767 in k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k12860 in k12810 in k12804 in expand in k12767 in k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12862,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k12852 in k12860 in k12810 in k12804 in expand in k12767 in k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12854,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12850,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1000 expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12790(t4,t3,((C_word*)t0)[2]);}

/* k12848 in k12852 in k12860 in k12810 in k12804 in expand in k12767 in k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12850,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k12817 in k12810 in k12804 in expand in k12767 in k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12819,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12786 in k12767 in k12764 in k12761 in k12758 in k12755 in k12746 in a12743 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12788,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[58],t3));}

/* k12740 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 974  ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[375],C_SCHEME_END_OF_LIST,t1);}

/* k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12673,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12675,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1005 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12674 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12675,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12679,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1007 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[113],t2,lf[374]);}

/* k12677 in a12674 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12679,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12688,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1010 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[58]);}

/* k12686 in k12677 in a12674 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12688,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12693,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li189),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_12693(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k12686 in k12677 in a12674 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_12693(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12693,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12711,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12730,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1014 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k12728 in expand in k12686 in k12677 in a12674 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12730,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k12709 in expand in k12686 in k12677 in a12674 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12711,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12671 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1002 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[113],C_SCHEME_END_OF_LIST,t1);}

/* k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12491,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12493,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1019 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12493,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12497,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1021 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[368],t2,lf[373]);}

/* k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12497,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12509,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1025 r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[372]);}

/* k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1026 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1027 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[371]);}

/* k12513 in k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12518,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1028 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12516 in k12513 in k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12653,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1029 ##sys#map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a12652 in k12516 in k12513 in k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12653,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k12531 in k12516 in k12513 in k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12533,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_12560(t6,lf[370]);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12651,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,C_SCHEME_END_OF_LIST);}}

/* k12649 in k12531 in k12516 in k12513 in k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12651,2,t0,t1);}
t2=((C_word*)t0)[3];
f_12560(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12558 in k12531 in k12516 in k12513 in k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_12560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12560,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_12576(t4,lf[369]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12641,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k12639 in k12558 in k12531 in k12516 in k12513 in k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12641,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_12576(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12574 in k12558 in k12531 in k12516 in k12513 in k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_12576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12576,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12596,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12598,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1040 ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a12597 in k12574 in k12558 in k12531 in k12516 in k12513 in k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12598,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_car(t2));}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t7));}}

/* k12594 in k12574 in k12558 in k12531 in k12516 in k12513 in k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k12590 in k12574 in k12558 in k12531 in k12516 in k12513 in k12510 in k12507 in k12495 in a12492 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12592,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[62],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k12489 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1016 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[368],C_SCHEME_END_OF_LIST,t1);}

/* k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7794,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12096,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12098,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1049 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12098,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12102,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1051 r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[95]);}

/* k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1052 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[354]);}

/* k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1053 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[367]);}

/* k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12111,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1054 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[366]);}

/* k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12111,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12113,a[2]=t5,a[3]=t7,a[4]=((C_word)li182),tmp=(C_word)a,a+=5,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12123,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word)li183),tmp=(C_word)a,a+=9,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12392,a[2]=t7,a[3]=((C_word)li184),tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12480,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1104 ##sys#check-syntax */
t12=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[354],((C_word*)t0)[3],lf[365]);}

/* k12478 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1105 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12113(t3,((C_word*)t0)[2],t2,C_fix(0));}

/* simplify in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_12392(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12392,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12396,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1092 match-expression */
f_5962(t3,t2,lf[363],lf[364]);}

/* k12394 in simplify in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12396,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[357],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[355],t4);
/* expand.scm: 1093 simplify */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12392(t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1094 match-expression */
f_5962(t2,((C_word*)t0)[2],lf[361],lf[362]);}}

/* k12419 in k12394 in simplify in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12421,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[358],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_i_assq(lf[357],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1101 match-expression */
f_5962(t2,((C_word*)t0)[2],lf[359],lf[360]);}}

/* k12465 in k12419 in k12394 in simplify in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[357],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k12450 in k12419 in k12394 in simplify in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12452,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[355],t2);
/* expand.scm: 1098 simplify */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12392(t4,((C_word*)t0)[2],t3);}

/* walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_12123(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12123,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12141,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12145,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1058 vector->list */
t6=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=t3,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1063 c */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t4);}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4));}}}

/* k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12170,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12196,a[2]=t5,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
/* expand.scm: 1069 walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_12113(t8,t6,t2,t7);}}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2));}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1071 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k12215 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12217,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12242,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1074 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_12113(t7,t4,t5,t6);}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12265,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1076 walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_12113(t4,t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12364,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1080 c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12378,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1090 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_12113(t3,t2,((C_word*)t0)[4],((C_word*)t0)[6]);}}}

/* k12376 in k12215 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12386,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1090 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12113(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12384 in k12376 in k12215 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12386,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12362 in k12215 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12364,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12307,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1084 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12113(t6,t5,((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12338,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1086 walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_12113(t7,t5,t3,t6);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12353,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1088 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_12113(t4,t3,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* k12351 in k12362 in k12215 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12361,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1088 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12113(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12359 in k12351 in k12362 in k12215 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12361,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12336 in k12362 in k12215 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12338,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[356],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[355],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12326,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1087 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12113(t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12324 in k12336 in k12362 in k12215 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12326,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12305 in k12362 in k12215 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12307,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[51],t3));}

/* k12263 in k12215 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12265,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[241],((C_word*)t0)[2],t1));}

/* k12240 in k12215 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12242,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[355],t3));}

/* k12194 in k12168 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12196,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[355],((C_word*)t0)[2],t1));}

/* k12143 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1058 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12113(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12139 in walk1 in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12141,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[237],t2));}

/* walk in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_12113(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12113,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12121,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1055 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12123(t5,t4,t2,t3);}

/* k12119 in walk in k12109 in k12106 in k12103 in k12100 in a12097 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1055 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12392(t2,((C_word*)t0)[2],t1);}

/* k12094 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1046 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[354],C_SCHEME_END_OF_LIST,t1);}

/* k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12063,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12065,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1110 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12064 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12065,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12069,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1112 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[351],t2,lf[353]);}

/* k12067 in a12064 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12069,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[126],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[352],t6));}

/* k12061 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1107 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[351],C_SCHEME_END_OF_LIST,t1);}

/* k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7800,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11779,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11781,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1118 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11781,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11788,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1121 r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1122 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[350]);}

/* k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1123 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1124 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1125 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11802,a[2]=((C_word*)t0)[8],a[3]=((C_word)li176),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11812,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=t4,a[7]=t1,a[8]=((C_word)li177),tmp=(C_word)a,a+=9,tmp));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11962,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=((C_word)li179),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_11962(t9,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* expand in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_11962(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11962,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11976,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11978,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12015,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1162 c */
t8=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t6,((C_word*)t0)[3]);}
else{
/* expand.scm: 1160 err */
t6=((C_word*)t0)[2];
f_11802(t6,t1,t4);}}
else{
/* expand.scm: 1155 err */
t4=((C_word*)t0)[2];
f_11802(t4,t1,t2);}}}

/* k12013 in expand in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12015,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[349]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12031,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12037,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1167 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11812(t3,t2,((C_word*)t0)[2]);}}

/* k12035 in k12013 in expand in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12037,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12044,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
/* expand.scm: 1168 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11962(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k12042 in k12035 in k12013 in expand in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12044,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12029 in k12013 in expand in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_12031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12031,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a11977 in expand in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11978,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k11974 in expand in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[27]+1),lf[348],t1);}

/* test in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_11812(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11812,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 1131 ##sys#feature? */
t3=C_retrieve(lf[347]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11843,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1136 c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],t3);}
else{
/* expand.scm: 1132 err */
t3=((C_word*)t0)[5];
f_11802(t3,t1,t2);}}}

/* k11841 in test in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11843,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11861,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[11]);
/* expand.scm: 1139 test */
t5=((C_word*)((C_word*)t0)[8])[1];
f_11812(t5,t3,t4);}
else{
/* expand.scm: 1141 err */
t3=((C_word*)t0)[7];
f_11802(t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1142 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k11887 in k11841 in test in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11889,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11904,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 1145 test */
t5=((C_word*)((C_word*)t0)[7])[1];
f_11812(t5,t3,t4);}
else{
/* expand.scm: 1147 err */
t3=((C_word*)t0)[6];
f_11802(t3,((C_word*)t0)[9],((C_word*)t0)[5]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11939,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1148 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11937 in k11887 in k11841 in test in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11939,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11946,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1148 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11812(t4,t2,t3);}
else{
/* expand.scm: 1149 err */
t2=((C_word*)t0)[2];
f_11802(t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k11944 in k11937 in k11887 in k11841 in test in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k11902 in k11887 in k11841 in test in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11904,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11918,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k11916 in k11902 in k11887 in k11841 in test in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11918,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1146 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11812(t3,((C_word*)t0)[2],t2);}

/* k11859 in k11841 in test in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11861,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11870 in k11859 in k11841 in test in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11872,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1140 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11812(t3,((C_word*)t0)[2],t2);}

/* err in k11798 in k11795 in k11792 in k11789 in k11786 in a11780 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_11802(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11802,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[345],((C_word*)t0)[2]);
/* expand.scm: 1127 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[346],t2,t3);}

/* k11777 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1115 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[345],C_SCHEME_END_OF_LIST,t1);}

/* k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7803,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11758,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11760,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1173 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11759 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11760,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[343],t7));}

/* k11756 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1170 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[344],C_SCHEME_END_OF_LIST,t1);}

/* k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11737,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11739,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1181 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11738 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11739,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[343],t7));}

/* k11735 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1178 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[342],C_SCHEME_END_OF_LIST,t1);}

/* k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11686,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11688,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1189 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11687 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11688,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11692,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1191 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[220],t2,lf[341]);}

/* k11690 in a11687 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11692,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11722,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11729,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1194 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[340]);}

/* k11727 in k11690 in a11687 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* expand.scm: 1194 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k11720 in k11690 in a11687 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11722,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_TRUE:(C_word)C_i_caddr(((C_word*)t0)[4]));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k11713 in k11720 in k11690 in a11687 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11715,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[339],t3));}

/* k11684 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1186 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[220],C_SCHEME_END_OF_LIST,t1);}

/* k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7812,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11632,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11634,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1202 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11633 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11634,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11638,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1204 ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[336],t2,lf[338]);}

/* k11636 in a11633 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1205 ##sys#current-module */
t3=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11639 in k11636 in a11633 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11678,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_11644(2,t3,C_SCHEME_FALSE);}}

/* k11676 in k11639 in k11636 in a11633 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11678,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[116],t1);
/* expand.scm: 1206 ##sys#register-meta-expression */
t3=C_retrieve(lf[281]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k11642 in k11639 in k11636 in a11633 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11659,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1207 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k11657 in k11642 in k11639 in k11636 in a11633 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11663,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k11661 in k11657 in k11642 in k11639 in k11636 in a11633 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11663,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[337],t3));}

/* k11630 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1199 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[336],C_SCHEME_END_OF_LIST,t1);}

/* k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11529,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11531,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1212 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11530 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11531,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11538,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1215 ##sys#current-module */
t7=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k11536 in a11530 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11541,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_11541(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1217 syntax-error */
t3=C_retrieve(lf[142]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[332],lf[335]);}}

/* k11539 in k11536 in a11530 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11561,a[2]=((C_word*)t0)[3],a[3]=((C_word)li170),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11560 in k11539 in k11536 in a11530 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11561,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11568,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t3;
f_11568(t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11583,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
t5=t3;
f_11568(t5,f_11583(t2));}}

/* loop in a11560 in k11539 in k11536 in a11530 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_11583(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_TRUE);}}
else{
return(C_SCHEME_TRUE);}}}

/* k11566 in a11560 in k11539 in k11536 in a11530 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_11568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=f_9475(((C_word*)t0)[4]);
/* expand.scm: 1226 syntax-error */
t3=C_retrieve(lf[142]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],lf[332],lf[334],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k11542 in k11539 in k11536 in a11530 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11547,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11551,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=f_9493(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11559,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[22]),((C_word*)t0)[2]);}

/* k11557 in k11542 in k11539 in k11536 in a11530 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1230 append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11549 in k11542 in k11539 in k11536 in a11530 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(2),t1);}

/* k11545 in k11542 in k11539 in k11536 in a11530 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[333]);}

/* k11527 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1209 ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[332],C_SCHEME_END_OF_LIST,t1);}

/* k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11492,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11494,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11493 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11494,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11498,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[328],t2,lf[331]);}

/* k11496 in a11493 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11498,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[5]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=lf[329];
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t7,a[6]=t9,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t4)[1]))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11516,a[2]=t10,a[3]=t7,a[4]=t4,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t12=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[328],((C_word*)t0)[5],lf[330]);}
else{
t11=t10;
f_11507(t11,C_SCHEME_UNDEFINED);}}

/* k11514 in k11496 in a11493 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_11507(t7,t6);}

/* k11505 in k11496 in a11493 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_11507(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#process-syntax-rules */
t2=C_retrieve(lf[230]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11490 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[328],C_SCHEME_END_OF_LIST,t1);}

/* k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7818,2,t0,t1);}
t2=C_mutate((C_word*)lf[230]+1 /* (set! process-syntax-rules ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7820,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9453,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1242 ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9453,2,t0,t1);}
t2=C_mutate((C_word*)lf[266]+1 /* (set! default-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11488,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1247 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k11486 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1247 make-parameter */
t2=C_retrieve(lf[327]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9457,2,t0,t1);}
t2=C_mutate((C_word*)lf[197]+1 /* (set! meta-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9461,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1248 make-parameter */
t4=C_retrieve(lf[327]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9461,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! current-module ...) */,t1);
t3=C_mutate(&lf[76] /* (set! module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9475,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[267] /* (set! module-export-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9493,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[268] /* (set! set-module-defined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9502,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[269] /* (set! module-defined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9511,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[270] /* (set! module-exist-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9529,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[271] /* (set! module-defined-syntax-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9547,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[272]+1 /* (set! set-module-undefined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9556,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[273]+1 /* (set! module-undefined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9565,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[223] /* (set! module-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9583,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[222] /* (set! module-meta-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9601,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[274] /* (set! module-meta-expressions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9619,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[192] /* (set! module-vexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9637,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[193] /* (set! module-sexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9655,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[275] /* (set! make-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9664,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[194]+1 /* (set! find-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9670,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[280]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9710,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[281]+1 /* (set! register-meta-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9713,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[282] /* (set! check-for-redef ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9733,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[285]+1 /* (set! register-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9754,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[288]+1 /* (set! register-syntax-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9843,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[77]+1 /* (set! register-undefined ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9920,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[291]+1 /* (set! register-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9942,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[215]+1 /* (set! mark-imported-symbols ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10010,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate(&lf[293] /* (set! module-indirect-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10069,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate(&lf[299] /* (set! merge-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10345,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[303]+1 /* (set! compiled-module-registration ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10417,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[304]+1 /* (set! register-compiled-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10703,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[308]+1 /* (set! register-primitive-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10823,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[287]+1 /* (set! find-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10914,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[312]+1 /* (set! finalize-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10999,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t33=C_set_block_item(lf[276] /* module-table */,0,C_SCHEME_END_OF_LIST);
t34=C_mutate((C_word*)lf[326]+1 /* (set! macro-subset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11446,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t35=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t35+1)))(2,t35,C_SCHEME_UNDEFINED);}

/* ##sys#macro-subset in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11446,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11454,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1578 ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11452 in ##sys#macro-subset in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11454,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11456,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li166),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11456(t5,((C_word*)t0)[2],t1);}

/* loop in k11452 in ##sys#macro-subset in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_11456(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11456,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,((C_word*)t0)[3]));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11477,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1581 loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* k11475 in loop in k11452 in ##sys#macro-subset in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11477,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10999,3,t0,t1,t2);}
t3=f_9493(t2);
t4=f_9475(t2);
t5=f_9511(t2);
t6=f_9529(t2);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11015,a[2]=t4,a[3]=t3,a[4]=t6,a[5]=t5,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11431,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
t9=f_9547(t2);
/* map */
t10=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}

/* a11430 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11431(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11431,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11439,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1505 ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11437 in a11430 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11369,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11388,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1511 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k11386 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11388,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11390,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li163),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11390(t5,((C_word*)t0)[2],t1);}

/* loop in k11386 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_11390(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11390,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11403,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11429,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1513 caar */
t5=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k11427 in loop in k11386 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1513 ##sys#find-export */
t2=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11401 in loop in k11386 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11403,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11414,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1514 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11390(t5,t3,t4);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1515 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11390(t3,((C_word*)t0)[3],t2);}}

/* k11412 in k11401 in loop in k11386 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11414,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a11368 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11369,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11381,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1509 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k11379 in a11368 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11021,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t4=(C_truep(t3)?((C_word*)t0)[4]:((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t6,a[5]=t1,a[6]=((C_word)li161),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_11241(t8,t2,t4);}

/* loop in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_11241(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11241,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?t3:(C_word)C_i_car(t3));
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[5]))){
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1523 loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}
else{
t6=(C_word)C_i_assq(t5,((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11289,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11292,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_cdr(t6);
t10=t8;
f_11292(t10,(C_word)C_i_symbolp(t9));}
else{
t9=t8;
f_11292(t9,C_SCHEME_FALSE);}}}}

/* k11290 in loop in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_11292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11292,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11289(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1530 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k11343 in k11290 in loop in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11345,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_11304(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_11304(t4,C_SCHEME_FALSE);}}

/* k11302 in k11343 in k11290 in loop in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_11304(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11304,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11307,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 1532 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[322],((C_word*)t0)[4],lf[323],t3);}
else{
if(C_truep(((C_word*)t0)[3])){
/* expand.scm: 1541 ##sys#module-rename */
t2=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11327,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11331,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1538 symbol->string */
t4=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}

/* k11329 in k11302 in k11343 in k11290 in loop in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1536 string-append */
t2=*((C_word*)lf[42]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[324],t1,lf[325]);}

/* k11325 in k11302 in k11343 in k11290 in loop in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1535 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11305 in k11302 in k11343 in k11290 in loop in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_11289(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* k11287 in loop in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11289,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11278,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1542 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11241(t5,t3,t4);}

/* k11276 in k11287 in loop in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11278,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11221,a[2]=((C_word*)t0)[2],a[3]=((C_word)li160),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11235,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1547 module-undefined-list */
t5=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k11233 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11220 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11221,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1546 ##sys#warn */
t3=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[321],t2);}}

/* k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11183,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11219,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1553 module-indirect-exports */
f_10069(t4,((C_word*)t0)[6]);}

/* k11217 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11182 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11183,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11211,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1551 ##sys#macro-environment */
t6=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}

/* k11209 in a11182 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 1552 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],lf[320],t3);}}

/* k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11177,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1555 ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11175 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11181,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1556 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11179 in k11175 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11181,2,t0,t1);}
/* expand.scm: 1554 merge-se */
f_10345(((C_word*)t0)[4],(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11033,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 1558 ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}

/* k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11135,a[2]=((C_word*)t0)[2],a[3]=((C_word)li158),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a11134 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11135,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11139,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(t2);
/* expand.scm: 1561 merge-se */
f_10345(t3,(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[2]));}

/* k11137 in a11134 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11142,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11165,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11169,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1562 map-se */
f_3586(t5,t1);}

/* k11167 in k11137 in a11134 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11163 in k11137 in a11134 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11165,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[319],t2);
/* expand.scm: 1562 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* k11140 in k11137 in a11134 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_car(t2,((C_word*)t0)[2]));}

/* k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11039,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=f_9475(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11133,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k11131 in k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11133,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[313],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11129,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1568 map-se */
f_3586(t4,((C_word*)t0)[2]);}

/* k11127 in k11131 in k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11123 in k11131 in k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11125,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[314],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11121,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1569 map-se */
f_3586(t4,((C_word*)t0)[2]);}

/* k11119 in k11123 in k11131 in k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11115 in k11123 in k11131 in k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11117,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[315],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11109,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11113,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1570 map-se */
f_3586(t4,((C_word*)t0)[2]);}

/* k11111 in k11115 in k11123 in k11131 in k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11107 in k11115 in k11123 in k11131 in k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11109,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[316],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11101,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11105,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1571 map-se */
f_3586(t4,((C_word*)t0)[2]);}

/* k11103 in k11107 in k11115 in k11123 in k11131 in k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11099 in k11107 in k11115 in k11123 in k11131 in k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11101,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[317],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[318],t8);
/* expand.scm: 1565 dm */
t10=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t10))(3,t10,((C_word*)t0)[2],t9);}

/* k11037 in k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11042,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(10),t4);}

/* k11040 in k11037 in k11034 in k11031 in k11028 in k11025 in k11022 in k11019 in k11016 in k11013 in ##sys#finalize-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_11042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(11),t4);}

/* ##sys#find-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10914(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10914,5,t0,t1,t2,t3,t4);}
t5=f_9493(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10925,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t5);
if(C_truep(t7)){
/* expand.scm: 1491 module-exists-list */
t8=C_retrieve(lf[311]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t3);}
else{
t8=t6;
f_10925(2,t8,t5);}}

/* k10923 in ##sys#find-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10925,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10927,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li156),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_10927(t5,((C_word*)t0)[2],t1);}

/* loop in k10923 in ##sys#find-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_10927(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10927,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1495 caar */
t7=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1498 loop */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}}

/* k10974 in loop in k10923 in ##sys#find-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10976,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10955,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10972,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1496 cdar */
t5=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t4=t3;
f_10955(t4,C_SCHEME_FALSE);}}}

/* k10970 in k10974 in loop in k10923 in ##sys#find-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_10955(t2,(C_word)C_i_memq(((C_word*)t0)[2],t1));}

/* k10953 in k10974 in loop in k10923 in ##sys#find-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_10955(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1497 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10927(t3,((C_word*)t0)[4],t2);}}

/* ##sys#register-primitive-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_10823r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10823r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10823r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10827,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_10827(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_10827(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k10825 in ##sys#register-primitive-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10830,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1468 ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10828 in k10825 in ##sys#register-primitive-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10845,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10869,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10868 in k10828 in k10825 in ##sys#register-primitive-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10869(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10869,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10879,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10889,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 1475 ##sys#string-append */
t6=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[310],t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10887 in a10868 in k10828 in k10825 in ##sys#register-primitive-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1474 ##sys#string->symbol */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10877 in a10868 in k10828 in k10825 in ##sys#register-primitive-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10882,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1476 ##sys#put! */
t3=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[83],((C_word*)t0)[2]);}

/* k10880 in k10877 in a10868 in k10828 in k10825 in ##sys#register-primitive-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10882,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10843 in k10828 in k10825 in ##sys#register-primitive-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10849,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10851,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word)li153),tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10850 in k10843 in k10828 in k10825 in ##sys#register-primitive-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10851,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* expand.scm: 1483 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[309],t2,((C_word*)t0)[2]);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10847 in k10843 in k10828 in k10825 in ##sys#register-primitive-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10849,2,t0,t1);}
t2=f_9664(C_a_i(&a,13),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve(lf[276]));
t5=C_mutate((C_word*)lf[276]+1 /* (set! module-table ...) */,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_10703,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10707,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10805,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t5);}

/* a10804 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10805,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10817,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 1441 ##sys#er-transformer */
t6=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k10815 in a10804 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10817,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10710,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10773,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10772 in k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10773,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10795,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_caddr(t2);
/* expand.scm: 1446 ##sys#er-transformer */
t8=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k10793 in a10772 in k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10795,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10708 in k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10710,2,t0,t1);}
t2=f_9664(C_a_i(&a,13),((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10716,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1451 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k10765 in k10708 in k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1452 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10769 in k10765 in k10708 in k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10771,2,t0,t1);}
/* expand.scm: 1450 merge-se */
f_10345(((C_word*)t0)[6],(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10714 in k10708 in k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1454 ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k10717 in k10714 in k10708 in k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10755,a[2]=((C_word*)t0)[4],a[3]=((C_word)li149),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10754 in k10717 in k10714 in k10708 in k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10755,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}

/* k10720 in k10717 in k10714 in k10708 in k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10725,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10735,a[2]=((C_word*)t0)[3],a[3]=((C_word)li148),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10734 in k10720 in k10717 in k10714 in k10708 in k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10735(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10735,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_set_car(t4,((C_word*)t0)[2]));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k10723 in k10720 in k10717 in k10714 in k10708 in k10705 in ##sys#register-compiled-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10725,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[276]));
t4=C_mutate((C_word*)lf[276]+1 /* (set! module-table ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10417,3,t0,t1,t2);}
t3=f_9511(t2);
t4=f_9475(t2);
t5=f_9583(t2);
t6=f_9601(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10437,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10701,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t5,C_SCHEME_END_OF_LIST);}
else{
t8=t7;
f_10437(t8,C_SCHEME_END_OF_LIST);}}

/* k10699 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10701,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[278],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[307],t5);
t7=((C_word*)t0)[2];
f_10437(t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_10437(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10437,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10441,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10671,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_10445(t4,C_SCHEME_END_OF_LIST);}}

/* k10669 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10671,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[278],t1);
t3=((C_word*)t0)[2];
f_10445(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_10445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10445,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10449,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10653,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=f_9619(((C_word*)t0)[4]);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[22]),t5);}

/* k10651 in k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1419 reverse */
t2=*((C_word*)lf[92]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10451 in k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10453,2,t0,t1);}
t2=f_9475(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10566,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10568,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10641,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1427 module-indirect-exports */
f_10069(t8,((C_word*)t0)[5]);}

/* k10639 in k10451 in k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10567 in k10451 in k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10568(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[33],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10568,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[95],t7));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[95],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[95],t7);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[164],t12));}}

/* k10564 in k10451 in k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10560 in k10451 in k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10562,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=f_9637(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[95],t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10497,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10501,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li145),tmp=(C_word)a,a+=5,tmp);
t9=f_9655(((C_word*)t0)[7]);
/* map */
t10=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}

/* a10502 in k10560 in k10451 in k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10503,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(t3,((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10513,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=t5;
f_10513(2,t6,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1434 error */
t6=*((C_word*)lf[277]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,lf[220],lf[306],t3,((C_word*)t0)[2]);}}

/* k10511 in a10502 in k10560 in k10451 in k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10513,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t4,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[305],t7));}

/* k10499 in k10560 in k10451 in k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10495 in k10560 in k10451 in k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10497,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[304],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k10447 in k10443 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10439 in k10435 in ##sys#compiled-module-registration in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* merge-se in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_10345(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10345,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10349,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,*((C_word*)lf[68]+1),t2);}

/* k10347 in merge-se in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10352,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
/* expand.scm: 1403 dm */
t5=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[301],t3,lf[302],t4);}

/* k10350 in k10347 in merge-se in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10355,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10364,a[2]=t4,a[3]=((C_word)li143),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10364(t6,t2,((C_word*)t0)[2]);}

/* loop in k10350 in k10347 in merge-se in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_10364(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10364,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10403,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1407 caar */
t4=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k10401 in loop in k10350 in k10347 in merge-se in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10403,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(t1,t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1407 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10364(t4,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10395,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1408 loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10364(t6,t4,t5);}}

/* k10393 in k10401 in loop in k10350 in k10347 in merge-se in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10395,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10353 in k10350 in k10347 in merge-se in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10358,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(t1);
/* expand.scm: 1409 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[300],t3);}

/* k10356 in k10353 in k10350 in k10347 in merge-se in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_10069(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10069,NULL,2,t1,t2);}
t3=f_9493(t2);
t4=f_9475(t2);
t5=f_9511(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10127,a[2]=t4,a[3]=((C_word)li139),tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t3);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10150,a[2]=t4,a[3]=t5,a[4]=t6,a[5]=t9,a[6]=((C_word)li141),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_10150(t11,t1,t3);}}

/* loop in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_10150(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10150,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_cdr(t2);
/* expand.scm: 1376 loop */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10177,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1378 cdar */
t5=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}}

/* k10175 in loop in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10177,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li140),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_10179(t5,((C_word*)t0)[2],t1);}

/* loop2 in k10175 in loop in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_10179(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10179,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 1379 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_10150(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1380 ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k10337 in loop2 in k10175 in loop in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10339,2,t0,t1);}
if(C_truep((C_word)C_i_assq(((C_word*)t0)[8],t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10202,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1381 warn */
t4=((C_word*)t0)[4];
f_10127(t4,t2,lf[296],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_cdr(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10245,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_10245(2,t7,t5);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1388 ##sys#module-rename */
t8=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,((C_word*)t0)[2]);}}
else{
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10327,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1390 ##sys#current-environment */
t6=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}}

/* k10325 in k10337 in loop2 in k10175 in loop in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10327,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10275,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 1393 loop2 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10179(t9,t7,t8);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10290,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1395 warn */
t6=((C_word*)t0)[2];
f_10127(t6,t4,lf[297],t5);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10308,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1398 warn */
t5=((C_word*)t0)[2];
f_10127(t5,t3,lf[298],t4);}}

/* k10306 in k10325 in k10337 in loop2 in k10175 in loop in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1399 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10179(t3,((C_word*)t0)[2],t2);}

/* k10288 in k10325 in k10337 in loop2 in k10175 in loop in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1396 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10179(t3,((C_word*)t0)[2],t2);}

/* k10273 in k10325 in k10337 in loop2 in k10175 in loop in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10275,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10243 in k10337 in loop2 in k10175 in loop in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10245,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10230,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1389 loop2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10179(t5,t3,t4);}

/* k10228 in k10243 in k10337 in loop2 in k10175 in loop in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10230,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10200 in k10337 in loop2 in k10175 in loop in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1382 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10179(t3,((C_word*)t0)[2],t2);}

/* warn in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_10127(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10127,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10135,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10139,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1370 symbol->string */
t6=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k10137 in warn in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1370 string-append */
t2=*((C_word*)lf[42]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[294],t1,lf[295]);}

/* k10133 in warn in module-indirect-exports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1369 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#mark-imported-symbols in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10010,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10016,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a10015 in ##sys#mark-imported-symbols in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10016,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10023,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_eqp(t5,t6);
t8=t3;
f_10023(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_10023(t5,C_SCHEME_FALSE);}}

/* k10021 in a10015 in ##sys#mark-imported-symbols in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_10023(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10023,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[292],t4);
/* expand.scm: 1354 dm */
t6=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k10024 in k10021 in a10015 in ##sys#mark-imported-symbols in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_10026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1355 ##sys#put! */
t3=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t2,lf[85],C_SCHEME_TRUE);}

/* ##sys#register-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+69)){
C_save_and_reclaim((void*)tr4r,(void*)f_9942r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_9942r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9942r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(69);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9944,a[2]=t3,a[3]=t2,a[4]=((C_word)li134),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9957,a[2]=t5,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9962,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-vexports29602979 */
t8=t1;
((C_proc2)C_retrieve_proc(t8))(2,t8,f_9962(C_a_i(&a,19),t7));}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-sexports29612975 */
t10=t1;
((C_proc2)C_retrieve_proc(t10))(2,t10,f_9957(C_a_i(&a,19),t6,t8));}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body29582967 */
t12=t1;
((C_proc2)C_retrieve_proc(t12))(2,t12,f_9944(C_a_i(&a,19),t5,t8,t10));}
else{
/* ##sys#error */
t12=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-vexports2960 in ##sys#register-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9962(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return(f_9957(C_a_i(&a,19),((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* def-sexports2961 in ##sys#register-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9957(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return(f_9944(C_a_i(&a,19),((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST));}

/* body2958 in ##sys#register-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9944(C_word *a,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t3=f_9664(C_a_i(&a,13),((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[276]));
t6=C_mutate((C_word*)lf[276]+1 /* (set! module-table ...) */,t5);
return(t3);}

/* ##sys#register-undefined in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9920,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9927,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1341 module-undefined-list */
t5=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k9925 in ##sys#register-undefined in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9927,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1343 set-module-undefined-list! */
t3=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* ##sys#register-syntax-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9843,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=f_9493(t3);
t6=(C_word)C_eqp(C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9853,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9853(2,t8,t6);}
else{
/* expand.scm: 1323 ##sys#find-export */
t8=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,t2,t3,C_SCHEME_TRUE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k9851 in ##sys#register-syntax-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9856,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1324 module-undefined-list */
t3=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}

/* k9854 in k9851 in ##sys#register-syntax-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9856,2,t0,t1);}
t2=f_9475(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],t1))){
/* expand.scm: 1327 ##sys#warn */
t4=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[290],((C_word*)t0)[5]);}
else{
t4=t3;
f_9862(2,t4,C_SCHEME_UNDEFINED);}}

/* k9860 in k9854 in k9851 in ##sys#register-syntax-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9901,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1328 ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9899 in k9860 in k9854 in k9851 in ##sys#register-syntax-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9905,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1328 ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9903 in k9899 in k9860 in k9854 in k9851 in ##sys#register-syntax-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1328 check-for-redef */
f_9733(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9863 in k9860 in k9854 in k9851 in ##sys#register-syntax-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1329 dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[289],((C_word*)t0)[5]);}

/* k9866 in k9863 in k9860 in k9854 in k9851 in ##sys#register-syntax-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9871,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]);
t4=f_9511(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
/* expand.scm: 1331 set-module-defined-list! */
f_9502(t2,((C_word*)t0)[6],t5);}
else{
t3=t2;
f_9871(2,t3,C_SCHEME_UNDEFINED);}}

/* k9869 in k9866 in k9863 in k9860 in k9854 in k9851 in ##sys#register-syntax-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9871,2,t0,t1);}
t2=f_9547(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[4];
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,C_fix(5),t3);}

/* ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9754,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=f_9493(t3);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9764,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_9764(2,t7,t5);}
else{
/* expand.scm: 1304 ##sys#find-export */
t7=C_retrieve(lf[287]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t2,t3,C_SCHEME_TRUE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k9762 in ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1305 module-undefined-list */
t3=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k9765 in k9762 in ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9770,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9830,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=f_9475(((C_word*)t0)[3]);
/* expand.scm: 1307 ##sys#module-rename */
t5=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[4],t4);}

/* k9828 in k9765 in k9762 in ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1306 ##sys#toplevel-definition-hook */
t2=C_retrieve(lf[280]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9768 in k9765 in k9762 in ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9773,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9826,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1310 ##sys#delq */
t4=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_9773(2,t3,C_SCHEME_UNDEFINED);}}

/* k9824 in k9768 in k9765 in k9762 in ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1310 set-module-undefined-list! */
t2=C_retrieve(lf[272]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9771 in k9768 in k9765 in k9762 in ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9812,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1311 ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9810 in k9771 in k9768 in k9765 in k9762 in ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9816,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1311 ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9814 in k9810 in k9771 in k9768 in k9765 in k9762 in ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1311 check-for-redef */
f_9733(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9774 in k9771 in k9768 in k9765 in k9762 in ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=f_9529(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(4),t4);}

/* k9777 in k9774 in k9771 in k9768 in k9765 in k9762 in ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9779,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1314 dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[286],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9783 in k9777 in k9774 in k9771 in k9768 in k9765 in k9762 in ##sys#register-export in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9785,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_FALSE);
t3=f_9511(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* expand.scm: 1315 set-module-defined-list! */
f_9502(((C_word*)t0)[2],((C_word*)t0)[3],t4);}

/* check-for-redef in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_9733(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9733,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(t2,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9740,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
/* expand.scm: 1297 ##sys#warn */
t7=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[284],t2);}
else{
t7=t6;
f_9740(2,t7,C_SCHEME_FALSE);}}

/* k9738 in check-for-redef in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
/* expand.scm: 1299 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[283],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#register-meta-expression in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9713,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9717,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1292 ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9715 in ##sys#register-meta-expression in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9717,2,t0,t1);}
if(C_truep(t1)){
t2=f_9619(t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,C_fix(9),t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#toplevel-definition-hook in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9710,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}

/* ##sys#find-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9670(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_9670r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9670r(t0,t1,t2,t3);}}

static void C_ccall f_9670r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9674,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_9674(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_9674(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k9672 in ##sys#find-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[276]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
if(C_truep(t1)){
/* expand.scm: 1284 error */
t3=*((C_word*)lf[277]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[278],lf[279],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* make-module in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9664(C_word *a,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_stack_check;
return((C_word)C_a_i_record(&a,12,lf[220],t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,t4));}

/* module-sexports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9655(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(11)));}

/* module-vexports in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9637(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(10)));}

/* module-meta-expressions in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9619(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(9)));}

/* module-meta-import-forms in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9601(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(8)));}

/* module-import-forms in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9583(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(7)));}

/* module-undefined-list in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9565(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9565,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[220]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* set-module-undefined-list! in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9556,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* module-defined-syntax-list in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9547(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(5)));}

/* module-exist-list in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9529(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(4)));}

/* module-defined-list in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9511(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(3)));}

/* set-module-defined-list! in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_9502(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9502,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* module-export-list in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9493(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* module-name in k9459 in k9455 in k9451 in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_9475(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(1)));}

/* ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7820(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word ab[151],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7820,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_SCHEME_UNDEFINED;
t42=(*a=C_VECTOR_TYPE|1,a[1]=t41,tmp=(C_word)a,a+=2,tmp);
t43=C_SCHEME_UNDEFINED;
t44=(*a=C_VECTOR_TYPE|1,a[1]=t43,tmp=(C_word)a,a+=2,tmp);
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_SCHEME_UNDEFINED;
t56=(*a=C_VECTOR_TYPE|1,a[1]=t55,tmp=(C_word)a,a+=2,tmp);
t57=C_SCHEME_UNDEFINED;
t58=(*a=C_VECTOR_TYPE|1,a[1]=t57,tmp=(C_word)a,a+=2,tmp);
t59=C_SCHEME_UNDEFINED;
t60=(*a=C_VECTOR_TYPE|1,a[1]=t59,tmp=(C_word)a,a+=2,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_SCHEME_UNDEFINED;
t64=(*a=C_VECTOR_TYPE|1,a[1]=t63,tmp=(C_word)a,a+=2,tmp);
t65=C_SCHEME_UNDEFINED;
t66=(*a=C_VECTOR_TYPE|1,a[1]=t65,tmp=(C_word)a,a+=2,tmp);
t67=C_SCHEME_UNDEFINED;
t68=(*a=C_VECTOR_TYPE|1,a[1]=t67,tmp=(C_word)a,a+=2,tmp);
t69=C_SCHEME_UNDEFINED;
t70=(*a=C_VECTOR_TYPE|1,a[1]=t69,tmp=(C_word)a,a+=2,tmp);
t71=C_SCHEME_UNDEFINED;
t72=(*a=C_VECTOR_TYPE|1,a[1]=t71,tmp=(C_word)a,a+=2,tmp);
t73=C_SCHEME_UNDEFINED;
t74=(*a=C_VECTOR_TYPE|1,a[1]=t73,tmp=(C_word)a,a+=2,tmp);
t75=C_SCHEME_UNDEFINED;
t76=(*a=C_VECTOR_TYPE|1,a[1]=t75,tmp=(C_word)a,a+=2,tmp);
t77=C_SCHEME_UNDEFINED;
t78=(*a=C_VECTOR_TYPE|1,a[1]=t77,tmp=(C_word)a,a+=2,tmp);
t79=C_SCHEME_UNDEFINED;
t80=(*a=C_VECTOR_TYPE|1,a[1]=t79,tmp=(C_word)a,a+=2,tmp);
t81=C_SCHEME_UNDEFINED;
t82=(*a=C_VECTOR_TYPE|1,a[1]=t81,tmp=(C_word)a,a+=2,tmp);
t83=C_SCHEME_UNDEFINED;
t84=(*a=C_VECTOR_TYPE|1,a[1]=t83,tmp=(C_word)a,a+=2,tmp);
t85=C_SCHEME_UNDEFINED;
t86=(*a=C_VECTOR_TYPE|1,a[1]=t85,tmp=(C_word)a,a+=2,tmp);
t87=C_SCHEME_UNDEFINED;
t88=(*a=C_VECTOR_TYPE|1,a[1]=t87,tmp=(C_word)a,a+=2,tmp);
t89=C_SCHEME_UNDEFINED;
t90=(*a=C_VECTOR_TYPE|1,a[1]=t89,tmp=(C_word)a,a+=2,tmp);
t91=C_SCHEME_UNDEFINED;
t92=(*a=C_VECTOR_TYPE|1,a[1]=t91,tmp=(C_word)a,a+=2,tmp);
t93=C_SCHEME_UNDEFINED;
t94=(*a=C_VECTOR_TYPE|1,a[1]=t93,tmp=(C_word)a,a+=2,tmp);
t95=C_SCHEME_UNDEFINED;
t96=(*a=C_VECTOR_TYPE|1,a[1]=t95,tmp=(C_word)a,a+=2,tmp);
t97=C_SCHEME_UNDEFINED;
t98=(*a=C_VECTOR_TYPE|1,a[1]=t97,tmp=(C_word)a,a+=2,tmp);
t99=C_SCHEME_UNDEFINED;
t100=(*a=C_VECTOR_TYPE|1,a[1]=t99,tmp=(C_word)a,a+=2,tmp);
t101=C_SCHEME_UNDEFINED;
t102=(*a=C_VECTOR_TYPE|1,a[1]=t101,tmp=(C_word)a,a+=2,tmp);
t103=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7827,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=t98,a[6]=t100,a[7]=t94,a[8]=t102,a[9]=t2,a[10]=t96,a[11]=t86,a[12]=t84,a[13]=t4,a[14]=t82,a[15]=t88,a[16]=t92,a[17]=t90,a[18]=t80,a[19]=t78,a[20]=t76,a[21]=t74,a[22]=t72,a[23]=t70,a[24]=t68,a[25]=t66,a[26]=t64,a[27]=t62,a[28]=t60,a[29]=t58,a[30]=t56,a[31]=t54,a[32]=t52,a[33]=t50,a[34]=t48,a[35]=t46,a[36]=t44,a[37]=t42,a[38]=t40,a[39]=t38,a[40]=t36,a[41]=t34,a[42]=t32,a[43]=t30,a[44]=t28,a[45]=t26,a[46]=t24,a[47]=t22,a[48]=t20,a[49]=t18,a[50]=t16,a[51]=t14,a[52]=t12,a[53]=t10,a[54]=t8,tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t104=t5;
((C_proc3)C_retrieve_proc(t104))(3,t104,t103,lf[265]);}

/* k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7827,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[231]);
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[232]);
t5=C_mutate(((C_word *)((C_word*)t0)[51])+1,lf[233]);
t6=C_mutate(((C_word *)((C_word*)t0)[50])+1,lf[234]);
t7=C_mutate(((C_word *)((C_word*)t0)[49])+1,lf[235]);
t8=C_mutate(((C_word *)((C_word*)t0)[48])+1,lf[236]);
t9=C_mutate(((C_word *)((C_word*)t0)[47])+1,lf[237]);
t10=C_mutate(((C_word *)((C_word*)t0)[46])+1,lf[238]);
t11=C_mutate(((C_word *)((C_word*)t0)[45])+1,lf[239]);
t12=C_mutate(((C_word *)((C_word*)t0)[44])+1,lf[240]);
t13=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[47],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[48],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[45],a[13]=((C_word*)t0)[50],a[14]=((C_word*)t0)[49],a[15]=((C_word*)t0)[44],a[16]=((C_word*)t0)[46],a[17]=((C_word*)t0)[51],a[18]=((C_word*)t0)[10],a[19]=((C_word*)t0)[11],a[20]=((C_word*)t0)[53],a[21]=((C_word*)t0)[12],a[22]=((C_word*)t0)[13],a[23]=((C_word*)t0)[14],a[24]=((C_word*)t0)[15],a[25]=((C_word*)t0)[16],a[26]=((C_word*)t0)[17],a[27]=((C_word*)t0)[54],a[28]=((C_word*)t0)[18],a[29]=((C_word*)t0)[52],a[30]=((C_word*)t0)[19],a[31]=((C_word*)t0)[20],a[32]=((C_word*)t0)[21],a[33]=((C_word*)t0)[22],a[34]=((C_word*)t0)[23],a[35]=((C_word*)t0)[24],a[36]=((C_word*)t0)[25],a[37]=((C_word*)t0)[26],a[38]=((C_word*)t0)[27],a[39]=((C_word*)t0)[28],a[40]=((C_word*)t0)[29],a[41]=((C_word*)t0)[30],a[42]=((C_word*)t0)[31],a[43]=((C_word*)t0)[32],a[44]=((C_word*)t0)[33],a[45]=((C_word*)t0)[34],a[46]=((C_word*)t0)[35],a[47]=((C_word*)t0)[36],a[48]=((C_word*)t0)[37],a[49]=((C_word*)t0)[38],a[50]=((C_word*)t0)[39],a[51]=((C_word*)t0)[40],a[52]=((C_word*)t0)[41],a[53]=((C_word*)t0)[42],a[54]=((C_word*)t0)[43],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t14=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,lf[264]);}

/* k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7841,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[54],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[263]);}

/* k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7845,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[54],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[262]);}

/* k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7849,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[241]);
t4=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[53],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[54],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[261]);}

/* k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7854,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[242]);
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[243]);
t5=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[52],a[22]=((C_word*)t0)[53],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[54],a[34]=((C_word*)t0)[31],a[35]=((C_word*)t0)[32],a[36]=((C_word*)t0)[33],a[37]=((C_word*)t0)[34],a[38]=((C_word*)t0)[35],a[39]=((C_word*)t0)[36],a[40]=((C_word*)t0)[37],a[41]=((C_word*)t0)[38],a[42]=((C_word*)t0)[39],a[43]=((C_word*)t0)[40],a[44]=((C_word*)t0)[41],a[45]=((C_word*)t0)[42],a[46]=((C_word*)t0)[43],a[47]=((C_word*)t0)[44],a[48]=((C_word*)t0)[45],a[49]=((C_word*)t0)[46],a[50]=((C_word*)t0)[47],a[51]=((C_word*)t0)[48],a[52]=((C_word*)t0)[49],a[53]=((C_word*)t0)[50],a[54]=((C_word*)t0)[51],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[260]);}

/* k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[54],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[259]);}

/* k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7864,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[54],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7868,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[54],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[58]);}

/* k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7872,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[54],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[113]);}

/* k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7876,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[244]);
t4=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[53],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[54],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[164]);}

/* k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[258]);}

/* k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7885,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[21]);
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[245]);
t5=C_mutate(((C_word *)((C_word*)t0)[51])+1,lf[246]);
t6=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[52],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[53],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[54],a[23]=((C_word*)t0)[51],a[24]=((C_word*)t0)[20],a[25]=((C_word*)t0)[21],a[26]=((C_word*)t0)[22],a[27]=((C_word*)t0)[23],a[28]=((C_word*)t0)[24],a[29]=((C_word*)t0)[25],a[30]=((C_word*)t0)[26],a[31]=((C_word*)t0)[27],a[32]=((C_word*)t0)[28],a[33]=((C_word*)t0)[29],a[34]=((C_word*)t0)[30],a[35]=((C_word*)t0)[31],a[36]=((C_word*)t0)[32],a[37]=((C_word*)t0)[33],a[38]=((C_word*)t0)[34],a[39]=((C_word*)t0)[35],a[40]=((C_word*)t0)[36],a[41]=((C_word*)t0)[37],a[42]=((C_word*)t0)[38],a[43]=((C_word*)t0)[39],a[44]=((C_word*)t0)[40],a[45]=((C_word*)t0)[41],a[46]=((C_word*)t0)[42],a[47]=((C_word*)t0)[43],a[48]=((C_word*)t0)[44],a[49]=((C_word*)t0)[45],a[50]=((C_word*)t0)[46],a[51]=((C_word*)t0)[47],a[52]=((C_word*)t0)[48],a[53]=((C_word*)t0)[49],a[54]=((C_word*)t0)[50],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7892,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[247]);
t4=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[54],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[53],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[95]);}

/* k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7897,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[54],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[227]);}

/* k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7901,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[54],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[256]);}

/* k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7905,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|53,a[1]=(C_word)f_7909,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[44],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[54],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],tmp=(C_word)a,a+=54,tmp);
/* r2242 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[255]);}

/* k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[129],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7909,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[53])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[53]);
t4=C_mutate(((C_word *)((C_word*)t0)[51])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7912,a[2]=((C_word*)t0)[41],a[3]=((C_word*)t0)[42],a[4]=((C_word*)t0)[52],a[5]=((C_word*)t0)[43],a[6]=((C_word*)t0)[44],a[7]=((C_word*)t0)[45],a[8]=((C_word*)t0)[46],a[9]=((C_word*)t0)[47],a[10]=((C_word*)t0)[48],a[11]=((C_word*)t0)[49],a[12]=((C_word*)t0)[50],a[13]=((C_word)li93),tmp=(C_word)a,a+=14,tmp));
t5=C_mutate(((C_word *)((C_word*)t0)[41])+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8006,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[46],a[4]=((C_word*)t0)[36],a[5]=((C_word*)t0)[37],a[6]=((C_word*)t0)[38],a[7]=((C_word*)t0)[39],a[8]=((C_word*)t0)[40],a[9]=((C_word)li95),tmp=(C_word)a,a+=10,tmp));
t6=C_mutate(((C_word *)((C_word*)t0)[35])+1,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8090,a[2]=((C_word*)t0)[27],a[3]=((C_word*)t0)[28],a[4]=((C_word*)t0)[29],a[5]=((C_word*)t0)[30],a[6]=((C_word*)t0)[31],a[7]=((C_word*)t0)[35],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[44],a[10]=((C_word*)t0)[40],a[11]=((C_word*)t0)[32],a[12]=((C_word*)t0)[53],a[13]=((C_word*)t0)[33],a[14]=((C_word*)t0)[50],a[15]=((C_word*)t0)[49],a[16]=((C_word*)t0)[34],a[17]=((C_word)li96),tmp=(C_word)a,a+=18,tmp));
t7=C_mutate(((C_word *)((C_word*)t0)[33])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8311,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[31],a[4]=((C_word*)t0)[44],a[5]=((C_word*)t0)[22],a[6]=((C_word*)t0)[40],a[7]=((C_word*)t0)[23],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[32],a[10]=((C_word*)t0)[24],a[11]=((C_word*)t0)[25],a[12]=((C_word*)t0)[26],a[13]=((C_word)li97),tmp=(C_word)a,a+=14,tmp));
t8=C_mutate(((C_word *)((C_word*)t0)[30])+1,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8429,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[35],a[6]=((C_word*)t0)[17],a[7]=((C_word*)t0)[18],a[8]=((C_word*)t0)[23],a[9]=((C_word*)t0)[22],a[10]=((C_word*)t0)[19],a[11]=((C_word*)t0)[20],a[12]=((C_word*)t0)[44],a[13]=((C_word*)t0)[40],a[14]=((C_word*)t0)[21],a[15]=((C_word*)t0)[53],a[16]=((C_word)li99),tmp=(C_word)a,a+=17,tmp));
t9=C_mutate(((C_word *)((C_word*)t0)[36])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8717,a[2]=((C_word*)t0)[27],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[31],a[7]=((C_word*)t0)[47],a[8]=((C_word*)t0)[36],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[43],a[11]=((C_word*)t0)[53],a[12]=((C_word*)t0)[34],a[13]=((C_word)li102),tmp=(C_word)a,a+=14,tmp));
t10=C_mutate(((C_word *)((C_word*)t0)[38])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8924,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[43],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[38],a[12]=((C_word*)t0)[49],a[13]=((C_word)li104),tmp=(C_word)a,a+=14,tmp));
t11=C_mutate(((C_word *)((C_word*)t0)[37])+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9178,a[2]=((C_word*)t0)[27],a[3]=((C_word*)t0)[37],a[4]=((C_word*)t0)[34],a[5]=((C_word)li105),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9251,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate(((C_word *)((C_word*)t0)[27])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9344,a[2]=((C_word*)t0)[4],a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9366,a[2]=((C_word*)t0)[14],a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate(((C_word *)((C_word*)t0)[8])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9392,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp));
t16=C_mutate(((C_word *)((C_word*)t0)[11])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9412,a[2]=((C_word*)t0)[14],a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp));
/* make-transformer2282 */
t17=((C_word*)((C_word*)t0)[51])[1];
((C_proc3)C_retrieve_proc(t17))(3,t17,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_9412 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9412,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9422,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li110),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9422(t7,t1,t3);}

/* loop */
static void C_fcall f_9422(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9422,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9429,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_9429(t5,(C_word)C_eqp(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_9429(t4,C_SCHEME_FALSE);}}

/* k9427 in loop */
static void C_fcall f_9429(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop2611 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9422(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* f_9392 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9392(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9392,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9399,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* segment-template?2292 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9397 */
static void C_ccall f_9399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9399,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9406,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* segment-depth2293 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* k9404 in k9397 */
static void C_ccall f_9406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(1),t1));}

/* f_9366 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9366,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t4,((C_word*)t0)[2]));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_9344 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9344,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9351,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* segment-template?2292 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9349 */
static void C_ccall f_9351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* ##sys#syntax-error-hook */
t4=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[254],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_9251 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9251,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9264,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,t5))){
t7=t6;
f_9264(t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_i_assq(t2,t4);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t7);
t9=t3;
t10=t6;
f_9264(t10,(C_word)C_fixnum_greater_or_equal_p(t8,t9));}
else{
t8=t6;
f_9264(t8,C_SCHEME_FALSE);}}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9293,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* segment-template?2292 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}

/* k9291 */
static void C_ccall f_9293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9293,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9304,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* free-meta-variables2290 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9325,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* free-meta-variables2290 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9340 in k9291 */
static void C_ccall f_9342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2290 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9323 in k9291 */
static void C_ccall f_9325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2290 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9302 in k9291 */
static void C_ccall f_9304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2290 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9262 */
static void C_fcall f_9264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9264,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]):((C_word*)t0)[2]));}

/* f_9178 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_9178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9178,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[4]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t4));}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9204,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* segment-pattern?2291 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k9202 */
static void C_ccall f_9204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9204,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* meta-variables2289 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9232,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* meta-variables2289 */
t5=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9247 in k9202 */
static void C_ccall f_9249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2289 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9230 in k9202 */
static void C_ccall f_9232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2289 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8924 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_8924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8924,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(C_word)C_i_assq(t2,t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
t7=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
/* ##sys#syntax-error-hook */
t8=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[251],t2);}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[250],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t8));}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t4,a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=t1,a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* segment-template?2292 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8969 */
static void C_ccall f_8971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8971,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8974,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* segment-depth2293 */
t3=((C_word*)((C_word*)t0)[5])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9132,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* process-template2288 */
t4=((C_word*)((C_word*)t0)[11])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[14],((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9169,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
t4=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}}}}

/* k9167 in k8969 */
static void C_ccall f_9169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2288 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9163 in k8969 */
static void C_ccall f_9165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9165,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k9130 in k8969 */
static void C_ccall f_9132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9140,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* process-template2288 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9138 in k9130 in k8969 */
static void C_ccall f_9140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9140,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t3));}

/* k8972 in k8969 */
static void C_ccall f_8974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8974,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8980,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* free-meta-variables2290 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,t2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k8978 in k8972 in k8969 */
static void C_ccall f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8980,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[252],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* process-template2288 */
t4=((C_word*)((C_word*)t0)[9])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k8990 in k8978 in k8972 in k8969 */
static void C_ccall f_8992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8995,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
if(C_truep((C_word)C_i_symbolp(t1))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_9058(t6,(C_word)C_eqp(t1,t5));}
else{
t5=t3;
f_9058(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_9058(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_9058(t4,C_SCHEME_FALSE);}}

/* k9056 in k8990 in k8978 in k8972 in k8969 */
static void C_fcall f_9058(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9058,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8995(t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}

/* k9071 in k9056 in k8990 in k8978 in k8972 in k8969 */
static void C_ccall f_9073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9073,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_8995(t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k8993 in k8990 in k8978 in k8972 in k8969 */
static void C_fcall f_8995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8995,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9029,a[2]=t4,a[3]=((C_word)li103),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9029(t6,t2,((C_word*)t0)[2],t1);}

/* doloop2529 in k8993 in k8990 in k8978 in k8972 in k8969 */
static void C_fcall f_9029(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9029,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[51],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t11=t1;
t12=t6;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k8996 in k8993 in k8990 in k8978 in k8972 in k8969 */
static void C_ccall f_8998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* segment-tail2294 */
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9025 in k8996 in k8993 in k8990 in k8978 in k8972 in k8969 */
static void C_ccall f_9027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9027,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9019,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9023,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* segment-tail2294 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k9021 in k9025 in k8996 in k8993 in k8990 in k8978 in k8972 in k8969 */
static void C_ccall f_9023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2288 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9017 in k9025 in k8996 in k8993 in k8990 in k8978 in k8972 in k8969 */
static void C_ccall f_9019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9019,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[51],t3));}

/* f_8717 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_8717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8717,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[12]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8741,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* mapit2436 */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8747,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=t4,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* segment-pattern?2291 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8745 */
static void C_ccall f_8747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8747,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8756,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word)li100),tmp=(C_word)a,a+=8,tmp);
/* process-pattern2287 */
t4=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[7],t2,((C_word*)((C_word*)t0)[12])[1],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[14]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8807,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[14]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
/* process-pattern2287 */
t6=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[13]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[14]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8847,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(2)))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[14],t4);
t6=t3;
f_8847(t6,(C_word)C_eqp(t5,((C_word*)t0)[2]));}
else{
t4=t3;
f_8847(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}}}

/* k8845 in k8745 */
static void C_fcall f_8847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8847,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8857,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8870,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[3],a[9]=((C_word)li101),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_8870(t5,((C_word*)t0)[6],C_fix(0));}}

/* lp in k8845 in k8745 */
static void C_fcall f_8870(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8870,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[8]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8884,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_vector_ref(((C_word*)t0)[6],t2);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
/* process-pattern2287 */
t9=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,((C_word*)t0)[2]);}}

/* k8882 in lp in k8845 in k8745 */
static void C_ccall f_8884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8888,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2471 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8870(t4,t2,t3);}

/* k8886 in k8882 in lp in k8845 in k8745 */
static void C_ccall f_8888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8855 in k8845 in k8745 */
static void C_ccall f_8857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8857,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
/* process-pattern2287 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k8805 in k8745 */
static void C_ccall f_8807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8811,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
/* process-pattern2287 */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[2]);}

/* k8809 in k8805 in k8745 */
static void C_ccall f_8811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8755 in k8745 */
static void C_ccall f_8756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8756,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8764,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],t2);
if(C_truep(t4)){
t5=t3;
f_8764(t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=t3;
f_8764(t11,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t10));}}

/* k8762 in a8755 in k8745 */
static void C_fcall f_8764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* mapit2436 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8739 */
static void C_ccall f_8741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8741,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t2));}

/* f_8429 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_8429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8429,4,t0,t1,t2,t3);}
t4=(C_word)C_i_vector_length(t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t4,a[13]=t1,a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t6=(C_word)C_fixnum_difference(t4,C_fix(1));
t7=(C_word)C_i_vector_ref(t3,t6);
t8=t5;
f_8436(t8,(C_word)C_eqp(t7,((C_word*)t0)[2]));}
else{
t6=t5;
f_8436(t6,C_SCHEME_FALSE);}}

/* k8434 */
static void C_fcall f_8436(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8436,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[16])[1],t5);
t7=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8475,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t4,a[16]=((C_word*)t0)[15],a[17]=t6,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t1)){
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_fixnum_difference(((C_word*)t0)[12],C_fix(2));
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=t7;
f_8475(t13,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t12));}
else{
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=t7;
f_8475(t12,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t11));}}

/* k8473 in k8434 */
static void C_fcall f_8475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8475,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8479,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[17],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8483,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8485,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word)li98),tmp=(C_word)a,a+=17,tmp));
t7=((C_word*)t5)[1];
f_8485(t7,t3,C_fix(0));}

/* lp in k8473 in k8434 */
static void C_fcall f_8485(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8485,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[15]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t5=t2;
t6=(C_word)C_eqp(t5,t4);
t7=(C_truep(t6)?((C_word*)t0)[14]:C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t12);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8545,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t10,a[6]=((C_word*)t0)[10],a[7]=t13,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8549,a[2]=t14,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t17);
t19=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t20=(C_word)C_i_vector_ref(((C_word*)t0)[4],t19);
/* process-match2284 */
t21=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t21))(4,t21,t15,t18,t20);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8616,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t10);
t12=(C_word)C_i_vector_ref(((C_word*)t0)[4],t2);
/* process-match2284 */
t13=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t13))(4,t13,t8,t11,t12);}}}

/* k8614 in lp in k8473 in k8434 */
static void C_ccall f_8616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8620,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2407 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8485(t4,t2,t3);}

/* k8618 in k8614 in lp in k8473 in k8434 */
static void C_ccall f_8620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8547 in lp in k8473 in k8434 */
static void C_ccall f_8549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8549,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k8543 in lp in k8473 in k8434 */
static void C_ccall f_8545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8545,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}

/* k8481 in k8473 in k8434 */
static void C_ccall f_8483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8477 in k8473 in k8434 */
static void C_ccall f_8479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8479,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST));}

/* f_8311 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_8311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8311,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8315,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
/* process-match2284 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t6,t3);}

/* k8313 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[75],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8315,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t8,t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t6,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t4,t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t21);
t23=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,(C_word)C_a_i_cons(&a,2,t22,C_SCHEME_END_OF_LIST));}}

/* f_8090 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_8090(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[40],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8090,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_symbolp(t3))){
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[16]))){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[250],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[15])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[14])[1],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}
else{
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8140,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* segment-pattern?2291 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k8138 */
static void C_ccall f_8140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8140,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-segment-match2285 */
t3=((C_word*)((C_word*)t0)[14])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[13],((C_word*)t0)[12],t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8188,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8192,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t9);
t11=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-match2284 */
t12=((C_word*)((C_word*)t0)[6])[1];
((C_proc4)C_retrieve_proc(t12))(4,t12,t8,t10,t11);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[15]))){
/* process-vector-match2286 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[15]);}
else{
t2=(C_word)C_i_nullp(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8254(t4,t2);}
else{
t4=(C_word)C_booleanp(((C_word*)t0)[15]);
t5=t3;
f_8254(t5,(C_truep(t4)?t4:(C_word)C_charp(((C_word*)t0)[15])));}}}}}

/* k8252 in k8138 */
static void C_fcall f_8254(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8254,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}}

/* k8190 in k8138 */
static void C_ccall f_8192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8196,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8200,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* process-match2284 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t5,t6);}

/* k8198 in k8190 in k8138 */
static void C_ccall f_8200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8194 in k8190 in k8138 */
static void C_ccall f_8196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8186 in k8138 */
static void C_ccall f_8188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8188,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* f_8006 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_8006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8006,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=t3;
f_8013(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_8013(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8013(t4,C_SCHEME_FALSE);}}

/* k8011 */
static void C_fcall f_8013(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8013,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* cdar */
t3=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[10]);}
else{
/* ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],lf[249],((C_word*)t0)[10]);}}

/* k8014 in k8011 */
static void C_ccall f_8016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8016,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8065,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* process-match2284 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t1);}

/* k8063 in k8014 in k8011 */
static void C_ccall f_8065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8059 in k8014 in k8011 */
static void C_ccall f_8061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8061,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8042,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8056,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* process-pattern2287 */
t5=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],t4);}

/* a8055 in k8059 in k8014 in k8011 */
static void C_ccall f_8056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8056,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8040 in k8059 in k8014 in k8011 */
static void C_ccall f_8042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8050,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8054,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* meta-variables2289 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_SCHEME_END_OF_LIST);}

/* k8052 in k8040 in k8059 in k8014 in k8011 */
static void C_ccall f_8054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2288 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k8048 in k8040 in k8059 in k8014 in k8011 */
static void C_ccall f_8050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8050,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* f_7912 in k7907 in k7903 in k7899 in k7895 in k7890 in k7883 in k7879 in k7874 in k7870 in k7866 in k7862 in k7858 in k7852 in k7847 in k7843 in k7839 in k7825 in ##sys#process-syntax-rules in k7816 in k7813 in k7810 in k7807 in k7804 in k7801 in k7798 in k7795 in k7792 in k7789 in k7786 in k7783 in k7780 in k7777 in k7774 in k7771 in k7768 in k7764 in k7761 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[38],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7912,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7952,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t10,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7956,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* map */
t13=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)((C_word*)t0)[2])[1],t2);}

/* k7954 */
static void C_ccall f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7956,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[248],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k7950 */
static void C_ccall f_7952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7952,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t7));}

/* ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6918,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6922,a[2]=t3,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=t6,a[7]=t1,a[8]=t4,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 726  r */
t10=t3;
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[228]);}

/* k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 727  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[227]);}

/* k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 728  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[226]);}

/* k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 729  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[225]);}

/* k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6933,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6942,a[2]=((C_word*)t0)[11],a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6985,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7072,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[11],a[11]=t4,a[12]=((C_word)li88),tmp=(C_word)a,a+=13,tmp));
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 826  ##sys#check-syntax */
t9=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[11],((C_word*)t0)[3],lf[224]);}

/* k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 827  ##sys#current-module */
t3=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7737,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9601(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 833  append */
t6=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7752,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9583(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 836  append */
t6=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}}
else{
t3=t2;
f_7536(2,t3,C_SCHEME_UNDEFINED);}}

/* k7750 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(7),t1);}

/* k7735 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(8),t1);}

/* k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7539,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7541,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li91),tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7541,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7545,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 839  import-spec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7072(t4,t3,t2);}

/* k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7545,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7554,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[219],t5);
/* expand.scm: 842  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t4,t6);}

/* k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_truep(((C_word*)t0)[2])?f_9475(((C_word*)t0)[2]):lf[216]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7712,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 843  map-se */
f_3586(t4,((C_word*)t0)[3]);}

/* k7710 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7712,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[218],t3);
/* expand.scm: 843  dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(((C_word*)t0)[2])?f_9475(((C_word*)t0)[2]):lf[216]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7689,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 844  map-se */
f_3586(t4,((C_word*)t0)[5]);}

/* k7687 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7689,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[217],t3);
/* expand.scm: 844  dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 845  ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7635,a[2]=((C_word*)t0)[3],a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7634 in k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7635,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7669,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 850  import-env */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7667 in a7634 in k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(((C_word*)t0)[3],t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
/* expand.scm: 852  ##sys#warn */
t5=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[2],lf[214],((C_word*)t0)[4]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7564 in k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7593,a[2]=((C_word*)t0)[6],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7592 in k7564 in k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7593,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7633,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 856  macro-env */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7631 in a7592 in k7564 in k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* expand.scm: 858  ##sys#warn */
t7=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],lf[213],t6);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7567 in k7564 in k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7572,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7587,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7591,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 860  import-env */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7589 in k7567 in k7564 in k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 860  append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7585 in k7567 in k7564 in k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 860  import-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7570 in k7567 in k7564 in k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7583,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 861  macro-env */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7581 in k7570 in k7567 in k7564 in k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 861  append */
t2=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7577 in k7570 in k7567 in k7564 in k7561 in k7558 in k7555 in k7552 in k7543 in a7540 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 861  macro-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7537 in k7534 in k7531 in k7528 in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[212]);}

/* import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_7072(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7072,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 759  import-name */
t3=((C_word*)t0)[11];
f_6985(t3,t1,t2);}
else{
t3=(C_word)C_i_listp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t4)){
t6=t5;
f_7091(t6,t4);}
else{
t6=(C_word)C_i_length(t2);
t7=t5;
f_7091(t7,(C_word)C_fixnum_lessp(t6,C_fix(2)));}}}

/* k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_7091(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7091,NULL,2,t0,t1);}
if(C_truep(t1)){
/* expand.scm: 761  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[12],((C_word*)t0)[11],lf[201],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* expand.scm: 764  import-spec */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7072(t5,t3,t4);}}

/* k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7100,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 767  c */
t6=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}

/* k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7112,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7115,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 768  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[9],lf[202]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7192,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 779  c */
t4=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7192,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7195,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 780  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[8],lf[203]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7299,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* expand.scm: 790  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7299,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7302,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 791  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],lf[209]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7446,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 816  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7444 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7446,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7449,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 817  ##sys#check-syntax */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[210]);}
else{
/* expand.scm: 825  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[7],((C_word*)t0)[2],lf[211],((C_word*)t0)[4]);}}

/* k7447 in k7444 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7452,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* expand.scm: 818  tostr */
t4=((C_word*)t0)[2];
f_6942(t4,t2,t3);}

/* k7450 in k7447 in k7444 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7454,a[2]=t1,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7485,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k7483 in k7450 in k7447 in k7444 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7489,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7487 in k7483 in k7450 in k7447 in k7444 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7489,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ren in k7450 in k7447 in k7444 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7454(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7454,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7462,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7470,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7474,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* expand.scm: 822  ##sys#symbol->string */
t7=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* k7472 in ren in k7450 in k7447 in k7444 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 822  ##sys#string-append */
t2=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7468 in ren in k7450 in k7447 in k7444 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 821  ##sys#string->symbol */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7460 in ren in k7450 in k7447 in k7444 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7462,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k7300 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7302,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7311,a[2]=t4,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7311(t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in k7300 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_7311(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7311,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7327,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7332,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t9=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7388,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t3,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 800  caar */
t8=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7440,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=t2,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 807  caar */
t8=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}}

/* k7438 in loop in k7300 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7440,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7421,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 810  cdar */
t6=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 813  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7311(t6,((C_word*)t0)[4],t3,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k7419 in k7438 in loop in k7300 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7421,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7409,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 812  ##sys#delq */
t5=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7407 in k7419 in k7438 in loop in k7300 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 809  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7311(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7386 in loop in k7300 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7388,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7369,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 804  cdar */
t6=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 806  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7311(t6,((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2],t5,((C_word*)t0)[8]);}}

/* k7367 in k7386 in loop in k7300 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7369,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7357,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 805  ##sys#delq */
t5=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7355 in k7367 in k7386 in loop in k7300 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 802  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7311(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7331 in loop in k7300 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7332,3,t0,t1,t2);}
/* expand.scm: 797  ##sys#warn */
t3=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[205],t2);}

/* k7325 in loop in k7300 in k7297 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7327,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k7193 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7198,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7196 in k7193 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7198,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7203,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7203(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k7196 in k7193 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_7203(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7203,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7215,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7215(t7,t1,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7289,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 788  caar */
t5=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7287 in loop in k7196 in k7193 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7289,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 788  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7203(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 789  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7203(t5,((C_word*)t0)[3],t2,t4);}}

/* loop in loop in k7196 in k7193 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_7215(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7215,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7257,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 786  caar */
t5=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7255 in loop in loop in k7196 in k7193 in k7190 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7257,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 786  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7215(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 787  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7215(t5,((C_word*)t0)[3],t2,t4);}}

/* k7113 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7118,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7116 in k7113 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7118,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7123,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7123(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k7116 in k7113 in k7110 in k7098 in k7089 in import-spec in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_7123(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7123,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_assq(t5,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* expand.scm: 774  loop */
t15=t1;
t16=t7;
t17=t8;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_assq(t7,((C_word*)t0)[2]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t8,t4);
/* expand.scm: 777  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t10;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
/* expand.scm: 778  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}}

/* import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6985,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6989,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 739  resolve */
t4=((C_word*)t0)[2];
f_6933(3,t4,t3,t2);}

/* k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6992,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 740  ##sys#find-module */
t3=C_retrieve(lf[194]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_SCHEME_FALSE);}

/* k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6992,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6995,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t3)[1])){
t5=t4;
f_6995(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7066,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7070,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 743  symbol->string */
t8=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[3]);}}

/* k7068 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 743  string-append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[200]);}

/* k7064 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 742  ##sys#find-extension */
t2=C_retrieve(lf[199]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7007,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[80]);
t3=C_retrieve(lf[8]);
t4=C_retrieve(lf[9]);
t5=C_retrieve(lf[29]);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7013,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t3,a[8]=t4,a[9]=t5,a[10]=t9,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 747  ##sys#current-meta-environment */
t11=C_retrieve(lf[9]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}
else{
/* expand.scm: 752  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[198],((C_word*)t0)[3]);}}

/* k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7013,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 748  ##sys#meta-macro-environment */
t5=C_retrieve(lf[197]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7016,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7017,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word)li79),tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7055,a[2]=((C_word*)t0)[2],a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t7=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t4,t6,t4);}

/* a7054 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7055,2,t0,t1);}
/* expand.scm: 749  ##sys#load */
t2=C_retrieve(lf[195]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7047 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7053,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 750  ##sys#find-module */
t3=C_retrieve(lf[194]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k7051 in k7047 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6995(2,t3,t2);}

/* swap1402 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* g140514061421 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7019 in swap1402 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* g140514061421 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[10])[1]);}

/* k7022 in k7019 in swap1402 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7024,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g140714081422 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7026 in k7022 in k7019 in swap1402 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7031,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g140714081422 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k7029 in k7026 in k7022 in k7019 in swap1402 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7031,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g140914101423 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7033 in k7029 in k7026 in k7022 in k7019 in swap1402 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7038,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g140914101423 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k7036 in k7033 in k7029 in k7026 in k7022 in k7019 in swap1402 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7038,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g141114121424 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7040 in k7036 in k7033 in k7029 in k7026 in k7022 in k7019 in swap1402 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7045,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g141114121424 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k7043 in k7040 in k7036 in k7033 in k7029 in k7026 in k7022 in k7019 in swap1402 in k7014 in k7011 in k7005 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_7045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6993 in k6990 in k6987 in import-name in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6995,2,t0,t1);}
t2=f_9637(((C_word*)((C_word*)t0)[3])[1]);
t3=f_9655(((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* tostr in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6942(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6942,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6955,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 734  keyword? */
t4=C_retrieve(lf[145]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k6953 in tostr in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6955,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6962,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 734  ##sys#symbol->string */
t3=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* expand.scm: 735  ##sys#symbol->string */
t2=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
/* expand.scm: 736  number->string */
C_number_to_string(3,0,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* expand.scm: 737  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[191]);}}}}

/* k6960 in k6953 in tostr in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 734  ##sys#string-append */
t2=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[189]);}

/* resolve in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6933,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6937,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 731  lookup */
f_3519(t3,t2,C_SCHEME_END_OF_LIST);}

/* k6935 in resolve in k6929 in k6926 in k6923 in k6920 in ##sys#expand-import in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##sys#er-transformer in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6624,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6626,a[2]=t2,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));}

/* f_6626 in ##sys#er-transformer in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6626,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6629,a[2]=t3,a[3]=t6,a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6892,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6755,a[2]=t4,a[3]=t8,a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 720  handler */
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t1,t2,t7,t9);}

/* compare */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6755,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6759,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_symbolp(t2);
t6=(C_truep(t5)?(C_word)C_i_symbolp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6788,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 691  ##sys#get */
t8=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t2,lf[12]);}
else{
t7=t4;
f_6759(t7,(C_word)C_eqp(t2,t3));}}

/* k6786 in compare */
static void C_ccall f_6788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6791(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6878,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 692  lookup2 */
f_6892(t3,C_fix(1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k6876 in k6786 in compare */
static void C_ccall f_6878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6791(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6789 in k6786 in compare */
static void C_fcall f_6791(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6791,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 694  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[12]);}

/* k6792 in k6789 in k6786 in compare */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6797,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6797(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6872,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 695  lookup2 */
f_6892(t3,C_fix(2),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6870 in k6792 in k6789 in k6786 in compare */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6797(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6795 in k6792 in k6789 in k6786 in compare */
static void C_fcall f_6797(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6797,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6816,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 699  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[83]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6843,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 701  ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}
else{
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 705  ##sys#macro-environment */
t3=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_6759(t2,(C_word)C_eqp(((C_word*)t0)[3],t1));}}}

/* k6864 in k6795 in k6792 in k6789 in k6786 in compare */
static void C_ccall f_6866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6759(t4,(C_word)C_eqp(((C_word*)t0)[2],t3));}
else{
t3=((C_word*)t0)[3];
f_6759(t3,C_SCHEME_FALSE);}}

/* k6841 in k6795 in k6792 in k6789 in k6786 in compare */
static void C_ccall f_6843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6759(t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[3];
f_6759(t3,C_SCHEME_FALSE);}}

/* k6814 in k6795 in k6792 in k6789 in k6786 in compare */
static void C_ccall f_6816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6816,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6823,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 700  ##sys#get */
t4=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],lf[83]);}

/* k6821 in k6814 in k6795 in k6792 in k6789 in k6786 in compare */
static void C_ccall f_6823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_6759(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k6757 in compare */
static void C_fcall f_6759(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6759,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6762,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[186],t6);
/* expand.scm: 710  dd */
t8=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t8))(3,t8,t2,t7);}

/* k6760 in k6757 in compare */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup2 */
static void C_fcall f_6892(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6892,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6896,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 713  lookup */
f_3519(t5,t3,t4);}

/* k6894 in lookup2 */
static void C_ccall f_6896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6899,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t4=(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE);
t5=(C_truep(t4)?lf[14]:t1);
/* expand.scm: 714  dd */
t6=C_retrieve2(lf[6],"dd");
((C_proc9)C_retrieve_proc(t6))(9,t6,t2,lf[182],t3,lf[183],((C_word*)t0)[2],lf[184],t5,lf[185]);}

/* k6897 in k6894 in lookup2 */
static void C_ccall f_6899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* rename */
static void C_ccall f_6629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6629,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6639,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[47],t6);
t8=(C_word)C_a_i_cons(&a,2,t2,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[178],t8);
/* expand.scm: 671  dd */
t10=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t10))(3,t10,t4,t9);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 673  lookup */
f_3519(t4,t2,((C_word*)t0)[2]);}}

/* k6663 in rename */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6665,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6677,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[179],t5);
/* expand.scm: 676  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6696,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 679  macro-alias */
f_3537(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6726,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 684  macro-alias */
f_3537(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6724 in k6663 in rename */
static void C_ccall f_6726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[181],t5);
/* expand.scm: 685  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}

/* k6727 in k6724 in k6663 in rename */
static void C_ccall f_6729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6729,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6694 in k6663 in rename */
static void C_ccall f_6696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[180],t5);
/* expand.scm: 680  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}

/* k6697 in k6694 in k6663 in rename */
static void C_ccall f_6699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6699,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6675 in k6663 in rename */
static void C_ccall f_6677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6637 in rename */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr5r,(void*)f_6162r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6162r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6162r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6164,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word)li68),tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6567,a[2]=t6,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6576,a[2]=t7,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-culprit10181176 */
t9=t8;
f_6576(t9,t1);}
else{
t9=(C_word)C_i_car(t5);
t10=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-se10191172 */
t11=t7;
f_6567(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body10161025 */
t13=t6;
f_6164(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-culprit1018 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6576,NULL,2,t0,t1);}
/* def-se10191172 */
t2=((C_word*)t0)[2];
f_6567(t2,t1,C_SCHEME_FALSE);}

/* def-se1019 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6567(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6567,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6575,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 585  ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6573 in def-se1019 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body10161025 */
t2=((C_word*)t0)[4];
f_6164(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6164(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6164,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6179,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word)li59),tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6167,a[2]=t4,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6210,a[2]=((C_word*)t0)[3],a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6266,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t3,a[6]=t6,a[7]=t7,a[8]=t5,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t9=C_mutate((C_word*)lf[139]+1 /* (set! syntax-error-culprit ...) */,t2);
t10=t8;
f_6295(t10,t9);}
else{
t9=t8;
f_6295(t9,C_SCHEME_UNDEFINED);}}

/* k6293 in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6295(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6295,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6300,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6300(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k6293 in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6300(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a;
loop:
a=C_alloc(19);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6300,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t3))){
t4=(C_word)C_i_vector_ref(t3,C_fix(0));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6319,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_eqp(t5,C_fix(1));
if(C_truep(t9)){
t10=t8;
f_6319(t10,C_fix(1));}
else{
t10=(C_word)C_fixnum_greaterp(t5,C_fix(2));
t11=t8;
f_6319(t11,(C_truep(t10)?(C_word)C_i_vector_ref(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_immp(t3))){
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 638  err */
t5=((C_word*)t0)[7];
f_6179(t5,t1,lf[155]);}}
else{
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t3;
t5=(C_word)C_eqp(t4,lf[57]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t4,lf[156]);
if(C_truep(t6)){
/* expand.scm: 642  test */
t7=((C_word*)t0)[5];
f_6167(t7,t1,t2,*((C_word*)lf[157]+1),lf[158]);}
else{
t7=(C_word)C_eqp(t4,lf[159]);
if(C_truep(t7)){
/* expand.scm: 643  test */
t8=((C_word*)t0)[5];
f_6167(t8,t1,t2,*((C_word*)lf[160]+1),lf[161]);}
else{
t8=(C_word)C_eqp(t4,lf[162]);
if(C_truep(t8)){
/* expand.scm: 644  test */
t9=((C_word*)t0)[5];
f_6167(t9,t1,t2,*((C_word*)lf[160]+1),lf[163]);}
else{
t9=(C_word)C_eqp(t4,lf[164]);
if(C_truep(t9)){
/* expand.scm: 645  test */
t10=((C_word*)t0)[5];
f_6167(t10,t1,t2,((C_word*)t0)[4],lf[165]);}
else{
t10=(C_word)C_eqp(t4,lf[166]);
if(C_truep(t10)){
/* expand.scm: 646  test */
t11=((C_word*)t0)[5];
f_6167(t11,t1,t2,*((C_word*)lf[167]+1),lf[168]);}
else{
t11=(C_word)C_eqp(t4,lf[169]);
if(C_truep(t11)){
/* expand.scm: 647  test */
t12=((C_word*)t0)[5];
f_6167(t12,t1,t2,*((C_word*)lf[170]+1),lf[171]);}
else{
t12=(C_word)C_eqp(t4,lf[172]);
if(C_truep(t12)){
/* expand.scm: 648  test */
t13=((C_word*)t0)[5];
f_6167(t13,t1,t2,((C_word*)t0)[3],lf[173]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6497,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li66),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 650  test */
t14=((C_word*)t0)[5];
f_6167(t14,t1,t2,t13,lf[174]);}}}}}}}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6538,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 660  walk */
t26=t4;
t27=t5;
t28=t6;
t1=t26;
t2=t27;
t3=t28;
goto loop;}
else{
/* expand.scm: 658  err */
t4=((C_word*)t0)[7];
f_6179(t4,t1,lf[175]);}}
else{
/* expand.scm: 657  err */
t4=((C_word*)t0)[7];
f_6179(t4,t1,lf[176]);}}}}}

/* k6536 in walk in k6293 in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 661  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6300(t4,((C_word*)t0)[2],t2,t3);}

/* a6496 in walk in k6293 in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6497,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6501,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 653  lookup */
f_3519(t3,t2,((C_word*)t0)[2]);}
else{
t4=t3;
f_6501(2,t4,C_SCHEME_FALSE);}}

/* k6499 in a6496 in walk in k6293 in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}

/* k6317 in walk in k6293 in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6319,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li65),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6324(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop1129 in k6317 in walk in k6293 in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6324(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6324,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* expand.scm: 631  err */
t5=((C_word*)t0)[6];
f_6179(t5,t1,lf[152]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6343,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* expand.scm: 633  err */
t6=((C_word*)t0)[6];
f_6179(t6,t5,lf[153]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
/* expand.scm: 636  walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6300(t7,t5,t6,((C_word*)t0)[2]);}
else{
/* expand.scm: 635  err */
t6=((C_word*)t0)[6];
f_6179(t6,t5,lf[154]);}}}}

/* k6341 in doloop1129 in k6317 in walk in k6293 in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6324(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6266,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6272,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_6272(t2));}

/* loop in proper-list? in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static C_word C_fcall f_6272(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6210,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6214,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 600  ##sys#extended-lambda-list? */
t4=C_retrieve(lf[88]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6212 in lambda-list? in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6214,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6222,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6222(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k6212 in lambda-list? in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6222,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6242,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 603  keyword? */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 607  loop */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k6240 in loop in k6212 in lambda-list? in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6167(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6167,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6174,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 588  pred */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k6172 in test in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 588  err */
t2=((C_word*)t0)[3];
f_6179(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6179(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6179,NULL,3,t0,t1,t2);}
t3=C_retrieve(lf[139]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 592  get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6181 in err in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6190,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6197,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 595  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6208,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 596  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k6206 in k6181 in err in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 596  string-append */
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[150],t1,lf[151],((C_word*)t0)[2]);}

/* k6195 in k6181 in err in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6201,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 595  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k6199 in k6195 in k6181 in err in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 595  string-append */
t2=((C_word*)t0)[5];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],lf[147],((C_word*)t0)[3],lf[148],t1,lf[149],((C_word*)t0)[2]);}

/* k6188 in k6181 in err in body1016 in ##sys#check-syntax in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 593  ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6126,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[138]))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6148,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 574  ##sys#hash-table-ref */
t5=C_retrieve(lf[144]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[138]),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6146 in get-line-number in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6115r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6115r(t0,t1,t2);}}

static void C_ccall f_6115r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6123,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 565  ##sys#strip-syntax */
t4=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6121 in ##sys#syntax-error-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],C_retrieve(lf[140]),lf[141],t1);}

/* ##sys#expand-curried-define in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6045,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6048,a[2]=t8,a[3]=t6,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6108,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 554  loop */
t11=((C_word*)t8)[1];
f_6048(t11,t10,t2,t3);}

/* k6106 in ##sys#expand-curried-define in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6108,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_6048(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6048,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_i_cdr(t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6074,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6101,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t3,C_SCHEME_END_OF_LIST);}}

/* k6099 in loop in ##sys#expand-curried-define in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6101,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* expand.scm: 553  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6048(t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k6072 in loop in ##sys#expand-curried-define in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6074,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[97],t2));}

/* match-expression in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5962(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5962,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5965,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6043,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 541  mwalk */
t11=((C_word*)t8)[1];
f_5965(t11,t10,t2,t3);}

/* k6041 in match-expression in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in match-expression in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5965(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5965,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6014,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 538  mwalk */
t13=t4;
t14=t5;
t15=t6;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_i_assq(t3,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t2,t5));}
else{
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[2]))){
t5=(C_word)C_a_i_cons(&a,2,t3,t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}}

/* k6012 in mwalk in match-expression in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 539  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5965(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5209(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5209r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5209r(t0,t1,t2,t3);}}

static void C_ccall f_5209r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5213,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 415  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5213(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5213,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5215,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t7,a[6]=((C_word)li46),tmp=(C_word)a,a+=7,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5475,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5652,a[2]=t3,a[3]=t5,a[4]=t1,a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
/* expand.scm: 522  expand */
t11=((C_word*)t7)[1];
f_5652(t11,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5652(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5652,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li50),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5658(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5658(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5658,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_i_car(t7):C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5680,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t1,a[7]=t6,a[8]=t5,a[9]=t8,a[10]=((C_word*)t0)[4],a[11]=t4,a[12]=t3,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t10)){
if(C_truep((C_word)C_i_symbolp(t10))){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5922,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 482  lookup */
f_3519(t12,t10,((C_word*)t0)[5]);}
else{
t12=t11;
f_5680(t12,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5680(t12,C_SCHEME_FALSE);}}
else{
/* expand.scm: 476  fini */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5215(t7,t1,t3,t4,t5,t6,t2);}}

/* k5920 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5680(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5680,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(C_word)C_eqp(lf[117],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5698,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 485  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[117],((C_word*)t0)[5],lf[133],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t3=(C_word)C_eqp(lf[124],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 507  ##sys#check-syntax */
t5=C_retrieve(lf[64]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[124],((C_word*)t0)[5],lf[134],((C_word*)t0)[13]);}
else{
t4=(C_word)C_eqp(lf[118],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5836,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 510  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[118],((C_word*)t0)[5],lf[135],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t5=(C_word)C_eqp(lf[116],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 513  ##sys#check-syntax */
t7=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t6,lf[116],((C_word*)t0)[5],lf[136],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t6=(C_word)C_i_memq(t1,((C_word*)t0)[12]);
t7=(C_truep(t6)?t6:(C_word)C_i_memq(t1,((C_word*)t0)[8]));
if(C_truep(t7)){
/* expand.scm: 516  fini */
t8=((C_word*)((C_word*)t0)[2])[1];
f_5215(t8,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5890,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 518  ##sys#expand-0 */
t9=C_retrieve(lf[38]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[5],((C_word*)t0)[13]);}}}}}}
else{
/* expand.scm: 483  fini */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5215(t2,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}}

/* k5888 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5890,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* expand.scm: 520  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_5215(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* expand.scm: 521  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5658(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k5862 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5871,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 514  ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k5869 in k5862 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 514  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5658(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5834 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5836,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* expand.scm: 511  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_5658(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k5822 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 508  fini/syntax */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5475(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5696 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5698,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5703,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li49),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5703(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k5696 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5703(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5703,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5750,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 497  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[117],t2,lf[129],C_SCHEME_FALSE,((C_word*)t0)[8]);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5772,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 501  ##sys#check-syntax */
t6=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[117],t2,lf[130],C_SCHEME_FALSE,((C_word*)t0)[8]);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 489  ##sys#check-syntax */
t5=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t4,lf[117],t2,lf[132],C_SCHEME_FALSE,((C_word*)t0)[8]);}}

/* k5714 in loop2 in k5696 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5716,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[8]):lf[131]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* expand.scm: 490  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_5658(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5770 in loop2 in k5696 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5772,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k5797 in k5770 in loop2 in k5696 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5799,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
/* expand.scm: 502  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5658(t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5748 in loop2 in k5696 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 498  macro-alias */
f_3537(t2,lf[117],((C_word*)t0)[2]);}

/* k5759 in k5748 in loop2 in k5696 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5765,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* expand.scm: 499  ##sys#expand-curried-define */
t4=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5763 in k5759 in k5748 in loop2 in k5696 in k5678 in loop in expand in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5765,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 498  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5703(t3,((C_word*)t0)[2],t2);}

/* fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5475(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5475,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5483,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5485,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5485(t11,t7,t6,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5485(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(19);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5485,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5500,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 457  macro-alias */
f_3537(t5,lf[123],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5531,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_length(t7);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_fix(3),t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5634,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 462  caar */
t10=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}
else{
t9=t5;
f_5531(t9,C_SCHEME_FALSE);}}
else{
t7=t5;
f_5531(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 459  loop */
t12=t1;
t13=t2;
t14=t3;
t15=C_SCHEME_TRUE;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}}

/* k5632 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5634,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 463  caar */
t4=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
f_5531(t2,C_SCHEME_FALSE);}}

/* k5628 in k5632 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 463  lookup */
f_3519(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5618 in k5632 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5623(2,t3,t1);}
else{
/* expand.scm: 463  caar */
t3=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k5621 in k5618 in k5632 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5531(t2,(C_word)C_eqp(lf[124],t1));}

/* k5529 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5531,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5549,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5563,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 468  caadr */
t7=*((C_word*)lf[127]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=t4;
f_5549(t6,t2);}}
else{
/* expand.scm: 472  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5485(t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_TRUE);}}

/* k5561 in k5529 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 468  macro-alias */
f_3537(t2,lf[126],((C_word*)t0)[2]);}

/* k5573 in k5561 in k5529 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 468  cdadr */
t3=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5581 in k5573 in k5561 in k5529 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5585 in k5581 in k5573 in k5561 in k5529 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5587,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
f_5549(t6,(C_word)C_a_i_cons(&a,2,lf[124],t5));}

/* k5547 in k5529 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5549,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* expand.scm: 465  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5485(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k5498 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5508,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5516,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 458  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5514 in k5498 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 458  map */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[122]+1),t1);}

/* k5506 in k5498 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5512,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5510 in k5506 in k5498 in loop in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5512,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k5481 in fini/syntax in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 454  fini */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5215(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5215(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5215,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5227,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li41),tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_5227(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5326,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 433  reverse */
t10=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}

/* k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5348,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5455,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5467,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[51]+1),t1,((C_word*)t0)[3]);}

/* k5465 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 436  ##sys#map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5454 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5455,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[121]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5352,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5356,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5437,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5453,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 438  reverse */
t6=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5451 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 438  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5436 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5437,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k5354 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5360,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5364,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5370,a[2]=((C_word*)t0)[5],a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 448  reverse */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5429 in k5354 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5435,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 449  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5433 in k5429 in k5354 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 439  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5369 in k5354 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5370,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5374,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 440  ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[18]),t2);}

/* k5372 in a5369 in k5354 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5374,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5401,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5405,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5407,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 445  map */
t8=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a5406 in k5372 in a5369 in k5354 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5407,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k5403 in k5372 in a5369 in k5354 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5399 in k5372 in a5369 in k5354 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5401,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[120],t5));}

/* k5362 in k5354 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5368,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5366 in k5362 in k5354 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5358 in k5354 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5350 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5352,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[59],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5332,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[119],t5);
/* expand.scm: 451  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t4,t6);}

/* k5330 in k5350 in k5346 in k5324 in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5227(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5227,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5316,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 427  lookup */
f_3519(t7,t6,((C_word*)t0)[4]);}
else{
t7=t5;
f_5250(t7,C_SCHEME_FALSE);}}
else{
t6=t5;
f_5250(t6,C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 421  macro-alias */
f_3537(t4,lf[116],((C_word*)t0)[4]);}}

/* k5239 in loop in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5241,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5314 in loop in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5316,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[117]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_5250(t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 428  lookup */
f_3519(t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k5307 in k5314 in loop in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_5250(t3,(C_word)C_eqp(t2,lf[118]));}

/* k5248 in loop in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5250,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5257,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 430  macro-alias */
f_3537(t2,lf[116],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]);
/* expand.scm: 432  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5227(t4,((C_word*)t0)[9],t2,t3);}}

/* k5255 in k5248 in loop in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5261,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 431  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5263 in k5255 in k5248 in loop in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5273,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 431  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5652(t3,t2,((C_word*)t0)[2]);}

/* k5271 in k5263 in k5255 in k5248 in loop in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5273,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* expand.scm: 431  ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5259 in k5255 in k5248 in loop in fini in k5211 in ##sys#canonicalize-body in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5261,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4619,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4622,a[2]=t2,a[3]=t4,a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4639,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t10,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 322  macro-alias */
f_3537(t11,lf[113],t5);}

/* k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 324  macro-alias */
f_3537(t2,lf[112],((C_word*)t0)[4]);}

/* k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 325  macro-alias */
f_3537(t2,lf[111],((C_word*)t0)[4]);}

/* k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 326  macro-alias */
f_3537(t2,lf[110],((C_word*)t0)[4]);}

/* k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* expand.scm: 327  macro-alias */
f_3537(t2,lf[58],((C_word*)t0)[4]);}

/* k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4656,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word)li39),tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_4656(t5,((C_word*)t0)[3],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4656(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4656,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t5,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t4,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)((C_word*)t0)[13])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4923,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 335  reverse */
t9=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}
else{
/* expand.scm: 335  reverse */
t8=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* expand.scm: 363  err */
t7=((C_word*)t0)[4];
f_4622(t7,t1,lf[99]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4944,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[13])[1];
if(C_truep(t8)){
t9=t7;
f_4944(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t6);
t10=t7;
f_4944(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4967,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[3],a[11]=t2,a[12]=t6,a[13]=t7,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t7))){
/* expand.scm: 372  lookup */
f_3519(t8,t7,((C_word*)t0)[2]);}
else{
t9=t8;
f_4967(2,t9,C_SCHEME_FALSE);}}
else{
/* expand.scm: 369  err */
t7=((C_word*)t0)[4];
f_4622(t7,t1,lf[109]);}}}}

/* k4965 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[64],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4967,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[13]);
t3=(C_word)C_i_cdr(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t2,lf[90]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t6)){
t7=t5;
f_4982(t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5001,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 376  macro-alias */
f_3537(t7,lf[101],((C_word*)t0)[5]);}}
else{
t5=(C_word)C_eqp(t2,lf[89]);
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[11],C_fix(1)))){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5019,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[4],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_5019(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_5019(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 388  err */
t6=((C_word*)t0)[7];
f_4622(t6,((C_word*)t0)[9],lf[103]);}}
else{
t6=(C_word)C_eqp(t2,lf[91]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5065,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t8)){
t9=t7;
f_5065(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5084,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 390  macro-alias */
f_3537(t9,lf[101],((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t7=((C_word*)t0)[11];
switch(t7){
case C_fix(0):
t8=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
/* expand.scm: 397  loop */
t9=((C_word*)((C_word*)t0)[10])[1];
f_4656(t9,((C_word*)t0)[9],C_fix(0),t8,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3);
case C_fix(1):
t8=(C_word)C_a_i_list(&a,2,t2,C_SCHEME_FALSE);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[3]);
/* expand.scm: 398  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4656(t10,((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8],t9,C_SCHEME_END_OF_LIST,t3);
case C_fix(2):
/* expand.scm: 399  err */
t8=((C_word*)t0)[7];
f_4622(t8,((C_word*)t0)[9],lf[105]);
default:
t8=(C_word)C_a_i_list(&a,1,t2);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[2]);
/* expand.scm: 400  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4656(t10,((C_word*)t0)[9],C_fix(3),((C_word*)t0)[8],((C_word*)t0)[3],t9,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5146,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t8=(C_word)C_i_length(t2);
t9=t7;
f_5146(t9,(C_word)C_eqp(C_fix(2),t8));}
else{
t8=t7;
f_5146(t8,C_SCHEME_FALSE);}}}}}}

/* k5144 in k4965 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5146,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* expand.scm: 403  err */
t3=((C_word*)t0)[9];
f_4622(t3,((C_word*)t0)[8],lf[106]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* expand.scm: 404  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4656(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* expand.scm: 405  err */
t3=((C_word*)t0)[9];
f_4622(t3,((C_word*)t0)[8],lf[107]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* expand.scm: 406  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4656(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* expand.scm: 407  err */
t2=((C_word*)t0)[9];
f_4622(t2,((C_word*)t0)[8],lf[108]);}}

/* k5082 in k4965 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5065(t3,t2);}

/* k5063 in k4965 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* expand.scm: 392  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_4656(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 393  err */
t2=((C_word*)t0)[2];
f_4622(t2,((C_word*)t0)[6],lf[104]);}}

/* k5017 in k4965 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5019(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5019,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_5022(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_5022(t6,t5);}}
else{
/* expand.scm: 387  err */
t2=((C_word*)t0)[2];
f_4622(t2,((C_word*)t0)[6],lf[102]);}}

/* k5020 in k5017 in k4965 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_5022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 386  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4656(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k4999 in k4965 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4982(t3,t2);}

/* k4980 in k4965 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* expand.scm: 378  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4656(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 379  err */
t3=((C_word*)t0)[2];
f_4622(t3,((C_word*)t0)[5],lf[100]);}}

/* k4942 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* expand.scm: 367  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4656(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k4921 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 335  ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t3=t2;
f_4674(t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4837,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4843,a[2]=((C_word*)t0)[11],a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4916,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 347  reverse */
t6=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}

/* k4914 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4842 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4843,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4912,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* expand.scm: 319  string->keyword */
t6=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k4910 in a4842 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4912,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4878,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4896,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t7=t5;
f_4878(t7,C_SCHEME_END_OF_LIST);}}

/* k4894 in k4910 in a4842 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=((C_word*)t0)[2];
f_4878(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4876 in k4910 in a4842 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4872 in k4910 in a4842 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[96],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k4835 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4839 in k4835 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4841,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4674(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4672 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4674(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4674,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4677,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[10]))){
t3=t2;
f_4677(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t4)){
t5=t3;
f_4686(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[10]);
t6=t3;
f_4686(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_4686(t5,C_SCHEME_FALSE);}}}}

/* k4684 in k4672 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4686,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4713,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 352  caar */
t3=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[5]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 356  reverse */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4789,a[2]=t4,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 359  reverse */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}}

/* k4787 in k4684 in k4672 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4789,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* expand.scm: 359  ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4779 in k4684 in k4672 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4785,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4783 in k4779 in k4684 in k4672 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4785,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4677(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4756 in k4684 in k4672 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4762,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4760 in k4756 in k4684 in k4672 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4762,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4677(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4711 in k4684 in k4672 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 352  cadar */
t3=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4731 in k4711 in k4684 in k4672 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4733,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4705,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4703 in k4731 in k4711 in k4684 in k4672 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4705,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4677(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4675 in k4672 in k4668 in loop in k4649 in k4646 in k4643 in k4640 in k4637 in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 334  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4622(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4622,NULL,3,t0,t1,t2);}
/* expand.scm: 318  errh */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4576,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4582,a[2]=t4,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4582(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4582(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4582,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[89]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4601(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[90]);
t7=t5;
f_4601(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[91])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4599 in loop in ##sys#extended-lambda-list? in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4601(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 312  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4582(t3,((C_word*)t0)[4],t2);}}

/* ##sys#expand in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4523r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4523r(t0,t1,t2,t3);}}

static void C_ccall f_4523r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4527,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 285  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4527(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4525 in ##sys#expand in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4527,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4532,a[2]=t3,a[3]=t1,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4532(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4525 in ##sys#expand in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4532(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4532,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4538,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4544,a[2]=((C_word*)t0)[2],a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a4543 in loop in k4525 in ##sys#expand in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4544,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* expand.scm: 289  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4532(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a4537 in loop in k4525 in ##sys#expand in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4538,2,t0,t1);}
/* expand.scm: 287  ##sys#expand-0 */
t2=C_retrieve(lf[38]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4433,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4436,a[2]=t3,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4469,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 265  ##sys#qualified-symbol? */
t6=C_retrieve(lf[19]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k4467 in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4469,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 266  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[83]);}}

/* k4470 in k4467 in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4472,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4478,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 268  dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[81],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 270  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[85]);}}

/* k4482 in k4470 in k4467 in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4484,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 271  dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[82],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 273  ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k4519 in k4482 in k4470 in k4467 in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4521,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4496,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 275  dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[84],((C_word*)t0)[4]);}
else{
/* expand.scm: 280  mrename */
t3=((C_word*)t0)[3];
f_4436(t3,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k4494 in k4519 in k4482 in k4470 in k4467 in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4496,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t2))){
/* expand.scm: 278  mrename */
t3=((C_word*)t0)[4];
f_4436(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4511,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 279  ##sys#get */
t4=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[83]);}}

/* k4509 in k4494 in k4519 in k4482 in k4470 in k4467 in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4485 in k4482 in k4470 in k4467 in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4476 in k4470 in k4467 in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* mrename in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4436(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4436,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 259  ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k4438 in mrename in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=f_9475(t1);
/* expand.scm: 261  dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[78],((C_word*)t0)[3],lf[79],t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k4444 in k4438 in mrename in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4449,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4449(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 262  ##sys#register-undefined */
t3=C_retrieve(lf[77]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k4447 in k4444 in k4438 in mrename in ##sys#alias-global-hook in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_9475(((C_word*)t0)[4]);
/* expand.scm: 263  ##sys#module-rename */
t3=C_retrieve(lf[73]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* ##sys#module-rename in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4415,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4423,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 252  string-append */
t7=*((C_word*)lf[42]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t4,t5,lf[75],t6);}

/* k4421 in ##sys#module-rename in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 251  ##sys#string->symbol */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3933,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3936,a[2]=t3,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4115,a[2]=t4,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4232,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t7,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 217  lookup */
f_3519(t8,t6,t3);}
else{
/* expand.scm: 245  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* expand.scm: 246  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4232,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[7]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4238,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=t5;
f_4238(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4399,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4406,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 219  ##sys#macro-environment */
t8=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}}

/* k4404 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 219  lookup */
f_3519(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4397 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4238(t4,t3);}

/* k4236 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4238,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[58]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4247,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 221  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[58],((C_word*)t0)[7],lf[66],C_SCHEME_FALSE,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4340,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t4,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[71]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=t3;
f_4340(t6,(C_word)C_i_pairp(t5));}
else{
t5=t3;
f_4340(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4340(t5,C_SCHEME_FALSE);}}}

/* k4338 in k4236 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4340(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4340,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 238  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[69],((C_word*)t0)[8],lf[70],C_SCHEME_FALSE,((C_word*)t0)[6]);}
else{
/* expand.scm: 244  expand */
t2=((C_word*)t0)[5];
f_4115(t2,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4344 in k4338 in k4236 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4353,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[67],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* expand.scm: 240  append */
t8=*((C_word*)lf[68]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t2,t5,t6,t7);}

/* k4351 in k4344 in k4338 in k4236 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 239  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k4245 in k4236 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4247,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 224  ##sys#check-syntax */
t4=C_retrieve(lf[64]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[58],((C_word*)t0)[5],lf[65],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
/* expand.scm: 233  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4257 in k4245 in k4236 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4259,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4327,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a4326 in k4257 in k4245 in k4236 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4327,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k4315 in k4257 in k4245 in k4236 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4321,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k4319 in k4315 in k4257 in k4245 in k4236 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4321,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[60],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[61],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4281,a[2]=((C_word*)t0)[3],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4285,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 231  ##sys#map */
t12=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[63]+1),((C_word*)t0)[2]);}

/* k4283 in k4319 in k4315 in k4257 in k4245 in k4236 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4279 in k4319 in k4315 in k4257 in k4245 in k4236 in k4230 in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4281,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[62],t2);
/* expand.scm: 226  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4115(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4115,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4119,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4172,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 198  get */
t7=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,lf[12]);}

/* k4170 in expand in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_symbolp(t1);
t4=t2;
f_4175(t4,(C_truep(t3)?t1:lf[14]));}
else{
t3=t2;
f_4175(t3,lf[57]);}}

/* k4173 in k4170 in expand in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4175(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4175,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4187,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4197,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4201,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 203  map-se */
f_3586(t4,t5);}
else{
t3=t2;
f_4187(t3,((C_word*)t0)[2]);}}

/* k4199 in k4173 in k4170 in expand in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4195 in k4173 in k4170 in expand in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4197,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4187(t2,(C_word)C_a_i_cons(&a,2,lf[56],t1));}

/* k4185 in k4173 in k4170 in expand in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4187(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4187,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[55],t5);
/* expand.scm: 196  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[2],t6);}

/* k4117 in expand in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4119,2,t0,t1);}
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4141,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 210  call-handler */
t5=((C_word*)t0)[3];
f_3936(t5,t2,((C_word*)t0)[2],t3,((C_word*)t0)[6],t4);}
else{
/* expand.scm: 212  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[6],C_SCHEME_FALSE);}}
else{
/* expand.scm: 206  ##sys#syntax-error-hook */
t2=C_retrieve(lf[53]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[54],((C_word*)t0)[6]);}}

/* k4139 in k4117 in expand in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 208  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_3936(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3936,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 163  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[52],t2);}

/* k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4109,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4113,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 164  map-se */
f_3586(t4,((C_word*)t0)[3]);}

/* k4111 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4107 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4109,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[50],t1);
/* expand.scm: 164  dd */
t3=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3949,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[49]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3951,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3957,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4064,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li22),tmp=(C_word)a,a+=9,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a4063 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li19),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4091,a[2]=((C_word*)t0)[2],a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4090 in a4063 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4091r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4091r(t0,t1,t2);}}

static void C_ccall f_4091r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4097,a[2]=t2,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* k261266 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4096 in a4090 in a4063 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4097,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4069 in a4063 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4074,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 192  handler */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4072 in a4069 in a4063 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4077,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
/* expand.scm: 193  dd */
t6=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}

/* k4075 in k4072 in a4069 in a4063 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3956 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3957,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
/* k261266 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3962 in a3956 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3971,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[3],lf[40]))){
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=t3;
f_3974(t5,(C_word)C_i_memq(lf[46],t4));}
else{
t4=t3;
f_3974(t4,C_SCHEME_FALSE);}}

/* k3972 in a3962 in a3956 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_3974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3974,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3985,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3991,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3991(t8,t3,t4);}
else{
t2=((C_word*)t0)[3];
f_3971(t2,((C_word*)t0)[4]);}}

/* copy in k3972 in a3962 in a3956 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_3991(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3991,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_equalp(lf[45],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=t5;
f_4010(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_4010(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_4010(t6,C_SCHEME_FALSE);}}}

/* k4008 in copy in k3972 in a3962 in a3956 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_4010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4010,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 184  string-append */
t5=*((C_word*)lf[42]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[43],t3,lf[44],t4);}
else{
/* expand.scm: 190  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3991(t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k4019 in k4008 in copy in k3972 in a3962 in a3956 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4021,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[41],t3));}

/* k3983 in k3972 in a3962 in a3956 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
t2=((C_word*)t0)[3];
f_3971(t2,(C_word)C_a_i_record(&a,3,lf[40],((C_word*)t0)[2],t1));}

/* k3969 in a3962 in a3956 in a3950 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_3971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 168  ##sys#abort */
t2=C_retrieve(lf[39]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3947 in k3941 in k3938 in call-handler in ##sys#expand-0 in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3924,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[37]);
/* expand.scm: 156  ##sys#unregister-macro */
t4=C_retrieve(lf[35]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* ##sys#unregister-macro in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3873,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3881,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3885,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 149  ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3883 in ##sys#unregister-macro in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3885,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3887,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3887(t5,((C_word*)t0)[2],t1);}

/* loop in k3883 in ##sys#unregister-macro in k3765 in k3515 in k3511 in k3484 */
static void C_fcall f_3887(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3887,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3922,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 151  caar */
t4=*((C_word*)lf[36]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k3920 in loop in k3883 in ##sys#unregister-macro in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3922,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3914,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 152  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3887(t6,t4,t5);}}

/* k3912 in k3920 in loop in k3883 in ##sys#unregister-macro in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3914,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3879 in ##sys#unregister-macro in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 147  ##sys#macro-environment */
t2=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* macro? in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3817r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3817r(t0,t1,t2,t3);}}

static void C_ccall f_3817r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3821,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 138  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3821(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3819 in macro? in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3821,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[3],lf[34]);
t3=(C_word)C_i_check_list_2(t1,lf[34]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3830,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 141  lookup */
f_3519(t4,((C_word*)t0)[3],t1);}

/* k3828 in k3819 in macro? in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3830,2,t0,t1);}
t2=(C_word)C_i_pairp(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 143  ##sys#macro-environment */
t5=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k3847 in k3828 in k3819 in macro? in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 143  lookup */
f_3519(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3837 in k3828 in k3819 in macro? in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE));}

/* ##sys#copy-macro in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3804,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3808,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3815,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 135  ##sys#macro-environment */
t6=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3813 in ##sys#copy-macro in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 135  lookup */
f_3519(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3806 in ##sys#copy-macro in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],C_retrieve(lf[32]),((C_word*)t0)[2],t1);}

/* ##sys#extend-macro-environment in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3771,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3775,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 124  ##sys#macro-environment */
t6=C_retrieve(lf[29]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3773 in ##sys#extend-macro-environment in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3778,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 125  lookup */
f_3519(t2,((C_word*)t0)[2],t1);}

/* k3776 in k3773 in ##sys#extend-macro-environment in k3765 in k3515 in k3511 in k3484 */
static void C_ccall f_3778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3778,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_set_car(t1,((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(t1);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[4]));}
else{
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
/* expand.scm: 130  ##sys#macro-environment */
t4=C_retrieve(lf[29]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}}

/* ##sys#strip-syntax in k3515 in k3511 in k3484 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_3616r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3616r(t0,t1,t2,t3);}}

static void C_ccall f_3616r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3618,a[2]=t2,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3711,a[2]=t4,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3716,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-se102142 */
t7=t6;
f_3716(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-alias103138 */
t9=t5;
f_3711(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body100109 */
t11=t4;
f_3618(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-se102 in ##sys#strip-syntax in k3515 in k3511 in k3484 */
static void C_fcall f_3716(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3716,NULL,2,t0,t1);}
/* def-alias103138 */
t2=((C_word*)t0)[2];
f_3711(t2,t1,C_SCHEME_FALSE);}

/* def-alias103 in ##sys#strip-syntax in k3515 in k3511 in k3484 */
static void C_fcall f_3711(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3711,NULL,3,t0,t1,t2);}
/* body100109 */
t3=((C_word*)t0)[2];
f_3618(t3,t1,t2,C_SCHEME_FALSE);}

/* body100 in ##sys#strip-syntax in k3515 in k3511 in k3484 */
static void C_fcall f_3618(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3618,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3624,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3624(3,t7,t1,((C_word*)t0)[2]);}

/* walk in body100 in ##sys#strip-syntax in k3515 in k3511 in k3484 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(18);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3624,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* expand.scm: 100  lookup */
f_3519(t3,t2,((C_word*)t0)[3]);}
else{
/* expand.scm: 101  get */
t4=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[12]);}}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* expand.scm: 108  walk */
t9=t3;
t10=t4;
t1=t9;
t2=t10;
c=3;
goto loop;}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3706,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3710,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 111  vector->list */
t5=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}}

/* k3708 in walk in body100 in ##sys#strip-syntax in k3515 in k3511 in k3484 */
static void C_ccall f_3710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3704 in walk in body100 in ##sys#strip-syntax in k3515 in k3511 in k3484 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 111  list->vector */
t2=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3679 in walk in body100 in ##sys#strip-syntax in k3515 in k3511 in k3484 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3685,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 109  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3624(3,t4,t2,t3);}

/* k3683 in k3679 in walk in body100 in ##sys#strip-syntax in k3515 in k3511 in k3484 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3632 in walk in body100 in ##sys#strip-syntax in k3515 in k3511 in k3484 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3640,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[2]);
t4=t2;
f_3640(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3640(t3,C_SCHEME_FALSE);}}

/* k3638 in k3632 in walk in body100 in ##sys#strip-syntax in k3515 in k3511 in k3484 */
static void C_fcall f_3640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* expand.scm: 103  ##sys#alias-global-hook */
t2=C_retrieve(lf[23]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[2];
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[2]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?((C_word*)t0)[3]:((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}}

/* map-se in k3515 in k3511 in k3484 */
static void C_fcall f_3586(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3586,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a3591 in map-se in k3515 in k3511 in k3484 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3592,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_symbolp(t4);
t6=(C_truep(t5)?(C_word)C_i_cdr(t2):lf[14]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t3,t6));}

/* macro-alias in k3515 in k3511 in k3484 */
static void C_fcall f_3537(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3537,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3544,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 75   ##sys#qualified-symbol? */
t5=C_retrieve(lf[19]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3542 in macro-alias in k3515 in k3511 in k3484 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3547(t3,t1);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(C_word)C_fixnum_greaterp(t4,C_fix(0));
t6=t2;
f_3547(t6,(C_truep(t5)?(C_word)C_eqp(C_make_character(35),(C_word)C_subchar(t3,C_fix(0))):C_SCHEME_FALSE));}}

/* k3545 in k3542 in macro-alias in k3515 in k3511 in k3484 */
static void C_fcall f_3547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3547,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 81   gensym */
t3=C_retrieve(lf[18]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3548 in k3545 in k3542 in macro-alias in k3515 in k3511 in k3484 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3553,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 82   lookup */
f_3519(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k3551 in k3548 in k3545 in k3542 in macro-alias in k3515 in k3511 in k3484 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3559,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 83   ##sys#put! */
t4=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[12],t2);}

/* k3557 in k3551 in k3548 in k3545 in k3542 in macro-alias in k3515 in k3511 in k3484 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_pairp(((C_word*)t0)[2]);
t4=(C_truep(t3)?lf[14]:((C_word*)t0)[2]);
/* expand.scm: 84   dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[15],((C_word*)t0)[3],lf[16],t4);}

/* k3560 in k3557 in k3551 in k3548 in k3545 in k3542 in macro-alias in k3515 in k3511 in k3484 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup in k3515 in k3511 in k3484 */
static void C_fcall f_3519(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3519,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cdr(t4));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3532,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 71   ##sys#get */
t6=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[12]);}}

/* k3530 in lookup in k3515 in k3511 in k3484 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:C_SCHEME_FALSE));}

/* d in k3484 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3488r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3488r(t0,t1,t2,t3);}}

static void C_ccall f_3488r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_fudge(C_fix(13)))){
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 43   pp */
t4=C_retrieve(lf[4]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}
else{
C_apply(5,0,t1,*((C_word*)lf[5]+1),t2,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[856] = {
{"toplevelexpand.scm",(void*)C_expand_toplevel},
{"f_3486expand.scm",(void*)f_3486},
{"f_3513expand.scm",(void*)f_3513},
{"f_3517expand.scm",(void*)f_3517},
{"f_3767expand.scm",(void*)f_3767},
{"f_13548expand.scm",(void*)f_13548},
{"f_13546expand.scm",(void*)f_13546},
{"f_7763expand.scm",(void*)f_7763},
{"f_13538expand.scm",(void*)f_13538},
{"f_13536expand.scm",(void*)f_13536},
{"f_7766expand.scm",(void*)f_7766},
{"f_7770expand.scm",(void*)f_7770},
{"f_13396expand.scm",(void*)f_13396},
{"f_13406expand.scm",(void*)f_13406},
{"f_13422expand.scm",(void*)f_13422},
{"f_13425expand.scm",(void*)f_13425},
{"f_13453expand.scm",(void*)f_13453},
{"f_13428expand.scm",(void*)f_13428},
{"f_13475expand.scm",(void*)f_13475},
{"f_13478expand.scm",(void*)f_13478},
{"f_13524expand.scm",(void*)f_13524},
{"f_13481expand.scm",(void*)f_13481},
{"f_13504expand.scm",(void*)f_13504},
{"f_13516expand.scm",(void*)f_13516},
{"f_13462expand.scm",(void*)f_13462},
{"f_13465expand.scm",(void*)f_13465},
{"f_13472expand.scm",(void*)f_13472},
{"f_13394expand.scm",(void*)f_13394},
{"f_7773expand.scm",(void*)f_7773},
{"f_13337expand.scm",(void*)f_13337},
{"f_13366expand.scm",(void*)f_13366},
{"f_13386expand.scm",(void*)f_13386},
{"f_13390expand.scm",(void*)f_13390},
{"f_13335expand.scm",(void*)f_13335},
{"f_7776expand.scm",(void*)f_7776},
{"f_13247expand.scm",(void*)f_13247},
{"f_13272expand.scm",(void*)f_13272},
{"f_13279expand.scm",(void*)f_13279},
{"f_13299expand.scm",(void*)f_13299},
{"f_13319expand.scm",(void*)f_13319},
{"f_13323expand.scm",(void*)f_13323},
{"f_13245expand.scm",(void*)f_13245},
{"f_7779expand.scm",(void*)f_7779},
{"f_12914expand.scm",(void*)f_12914},
{"f_12921expand.scm",(void*)f_12921},
{"f_12924expand.scm",(void*)f_12924},
{"f_12927expand.scm",(void*)f_12927},
{"f_12930expand.scm",(void*)f_12930},
{"f_12933expand.scm",(void*)f_12933},
{"f_12936expand.scm",(void*)f_12936},
{"f_12939expand.scm",(void*)f_12939},
{"f_12944expand.scm",(void*)f_12944},
{"f_12960expand.scm",(void*)f_12960},
{"f_12966expand.scm",(void*)f_12966},
{"f_13008expand.scm",(void*)f_13008},
{"f_13076expand.scm",(void*)f_13076},
{"f_13201expand.scm",(void*)f_13201},
{"f_13197expand.scm",(void*)f_13197},
{"f_13079expand.scm",(void*)f_13079},
{"f_13134expand.scm",(void*)f_13134},
{"f_13011expand.scm",(void*)f_13011},
{"f_13050expand.scm",(void*)f_13050},
{"f_13002expand.scm",(void*)f_13002},
{"f_12973expand.scm",(void*)f_12973},
{"f_12912expand.scm",(void*)f_12912},
{"f_7782expand.scm",(void*)f_7782},
{"f_12744expand.scm",(void*)f_12744},
{"f_12748expand.scm",(void*)f_12748},
{"f_12757expand.scm",(void*)f_12757},
{"f_12760expand.scm",(void*)f_12760},
{"f_12763expand.scm",(void*)f_12763},
{"f_12766expand.scm",(void*)f_12766},
{"f_12769expand.scm",(void*)f_12769},
{"f_12790expand.scm",(void*)f_12790},
{"f_12806expand.scm",(void*)f_12806},
{"f_12812expand.scm",(void*)f_12812},
{"f_12868expand.scm",(void*)f_12868},
{"f_12866expand.scm",(void*)f_12866},
{"f_12862expand.scm",(void*)f_12862},
{"f_12854expand.scm",(void*)f_12854},
{"f_12850expand.scm",(void*)f_12850},
{"f_12819expand.scm",(void*)f_12819},
{"f_12788expand.scm",(void*)f_12788},
{"f_12742expand.scm",(void*)f_12742},
{"f_7785expand.scm",(void*)f_7785},
{"f_12675expand.scm",(void*)f_12675},
{"f_12679expand.scm",(void*)f_12679},
{"f_12688expand.scm",(void*)f_12688},
{"f_12693expand.scm",(void*)f_12693},
{"f_12730expand.scm",(void*)f_12730},
{"f_12711expand.scm",(void*)f_12711},
{"f_12673expand.scm",(void*)f_12673},
{"f_7788expand.scm",(void*)f_7788},
{"f_12493expand.scm",(void*)f_12493},
{"f_12497expand.scm",(void*)f_12497},
{"f_12509expand.scm",(void*)f_12509},
{"f_12512expand.scm",(void*)f_12512},
{"f_12515expand.scm",(void*)f_12515},
{"f_12518expand.scm",(void*)f_12518},
{"f_12653expand.scm",(void*)f_12653},
{"f_12533expand.scm",(void*)f_12533},
{"f_12651expand.scm",(void*)f_12651},
{"f_12560expand.scm",(void*)f_12560},
{"f_12641expand.scm",(void*)f_12641},
{"f_12576expand.scm",(void*)f_12576},
{"f_12598expand.scm",(void*)f_12598},
{"f_12596expand.scm",(void*)f_12596},
{"f_12592expand.scm",(void*)f_12592},
{"f_12491expand.scm",(void*)f_12491},
{"f_7791expand.scm",(void*)f_7791},
{"f_12098expand.scm",(void*)f_12098},
{"f_12102expand.scm",(void*)f_12102},
{"f_12105expand.scm",(void*)f_12105},
{"f_12108expand.scm",(void*)f_12108},
{"f_12111expand.scm",(void*)f_12111},
{"f_12480expand.scm",(void*)f_12480},
{"f_12392expand.scm",(void*)f_12392},
{"f_12396expand.scm",(void*)f_12396},
{"f_12421expand.scm",(void*)f_12421},
{"f_12467expand.scm",(void*)f_12467},
{"f_12452expand.scm",(void*)f_12452},
{"f_12123expand.scm",(void*)f_12123},
{"f_12170expand.scm",(void*)f_12170},
{"f_12217expand.scm",(void*)f_12217},
{"f_12378expand.scm",(void*)f_12378},
{"f_12386expand.scm",(void*)f_12386},
{"f_12364expand.scm",(void*)f_12364},
{"f_12353expand.scm",(void*)f_12353},
{"f_12361expand.scm",(void*)f_12361},
{"f_12338expand.scm",(void*)f_12338},
{"f_12326expand.scm",(void*)f_12326},
{"f_12307expand.scm",(void*)f_12307},
{"f_12265expand.scm",(void*)f_12265},
{"f_12242expand.scm",(void*)f_12242},
{"f_12196expand.scm",(void*)f_12196},
{"f_12145expand.scm",(void*)f_12145},
{"f_12141expand.scm",(void*)f_12141},
{"f_12113expand.scm",(void*)f_12113},
{"f_12121expand.scm",(void*)f_12121},
{"f_12096expand.scm",(void*)f_12096},
{"f_7794expand.scm",(void*)f_7794},
{"f_12065expand.scm",(void*)f_12065},
{"f_12069expand.scm",(void*)f_12069},
{"f_12063expand.scm",(void*)f_12063},
{"f_7797expand.scm",(void*)f_7797},
{"f_11781expand.scm",(void*)f_11781},
{"f_11788expand.scm",(void*)f_11788},
{"f_11791expand.scm",(void*)f_11791},
{"f_11794expand.scm",(void*)f_11794},
{"f_11797expand.scm",(void*)f_11797},
{"f_11800expand.scm",(void*)f_11800},
{"f_11962expand.scm",(void*)f_11962},
{"f_12015expand.scm",(void*)f_12015},
{"f_12037expand.scm",(void*)f_12037},
{"f_12044expand.scm",(void*)f_12044},
{"f_12031expand.scm",(void*)f_12031},
{"f_11978expand.scm",(void*)f_11978},
{"f_11976expand.scm",(void*)f_11976},
{"f_11812expand.scm",(void*)f_11812},
{"f_11843expand.scm",(void*)f_11843},
{"f_11889expand.scm",(void*)f_11889},
{"f_11939expand.scm",(void*)f_11939},
{"f_11946expand.scm",(void*)f_11946},
{"f_11904expand.scm",(void*)f_11904},
{"f_11918expand.scm",(void*)f_11918},
{"f_11861expand.scm",(void*)f_11861},
{"f_11872expand.scm",(void*)f_11872},
{"f_11802expand.scm",(void*)f_11802},
{"f_11779expand.scm",(void*)f_11779},
{"f_7800expand.scm",(void*)f_7800},
{"f_11760expand.scm",(void*)f_11760},
{"f_11758expand.scm",(void*)f_11758},
{"f_7803expand.scm",(void*)f_7803},
{"f_11739expand.scm",(void*)f_11739},
{"f_11737expand.scm",(void*)f_11737},
{"f_7806expand.scm",(void*)f_7806},
{"f_11688expand.scm",(void*)f_11688},
{"f_11692expand.scm",(void*)f_11692},
{"f_11729expand.scm",(void*)f_11729},
{"f_11722expand.scm",(void*)f_11722},
{"f_11715expand.scm",(void*)f_11715},
{"f_11686expand.scm",(void*)f_11686},
{"f_7809expand.scm",(void*)f_7809},
{"f_11634expand.scm",(void*)f_11634},
{"f_11638expand.scm",(void*)f_11638},
{"f_11641expand.scm",(void*)f_11641},
{"f_11678expand.scm",(void*)f_11678},
{"f_11644expand.scm",(void*)f_11644},
{"f_11659expand.scm",(void*)f_11659},
{"f_11663expand.scm",(void*)f_11663},
{"f_11632expand.scm",(void*)f_11632},
{"f_7812expand.scm",(void*)f_7812},
{"f_11531expand.scm",(void*)f_11531},
{"f_11538expand.scm",(void*)f_11538},
{"f_11541expand.scm",(void*)f_11541},
{"f_11561expand.scm",(void*)f_11561},
{"f_11583expand.scm",(void*)f_11583},
{"f_11568expand.scm",(void*)f_11568},
{"f_11544expand.scm",(void*)f_11544},
{"f_11559expand.scm",(void*)f_11559},
{"f_11551expand.scm",(void*)f_11551},
{"f_11547expand.scm",(void*)f_11547},
{"f_11529expand.scm",(void*)f_11529},
{"f_7815expand.scm",(void*)f_7815},
{"f_11494expand.scm",(void*)f_11494},
{"f_11498expand.scm",(void*)f_11498},
{"f_11516expand.scm",(void*)f_11516},
{"f_11507expand.scm",(void*)f_11507},
{"f_11492expand.scm",(void*)f_11492},
{"f_7818expand.scm",(void*)f_7818},
{"f_9453expand.scm",(void*)f_9453},
{"f_11488expand.scm",(void*)f_11488},
{"f_9457expand.scm",(void*)f_9457},
{"f_9461expand.scm",(void*)f_9461},
{"f_11446expand.scm",(void*)f_11446},
{"f_11454expand.scm",(void*)f_11454},
{"f_11456expand.scm",(void*)f_11456},
{"f_11477expand.scm",(void*)f_11477},
{"f_10999expand.scm",(void*)f_10999},
{"f_11431expand.scm",(void*)f_11431},
{"f_11439expand.scm",(void*)f_11439},
{"f_11015expand.scm",(void*)f_11015},
{"f_11388expand.scm",(void*)f_11388},
{"f_11390expand.scm",(void*)f_11390},
{"f_11429expand.scm",(void*)f_11429},
{"f_11403expand.scm",(void*)f_11403},
{"f_11414expand.scm",(void*)f_11414},
{"f_11369expand.scm",(void*)f_11369},
{"f_11381expand.scm",(void*)f_11381},
{"f_11018expand.scm",(void*)f_11018},
{"f_11241expand.scm",(void*)f_11241},
{"f_11292expand.scm",(void*)f_11292},
{"f_11345expand.scm",(void*)f_11345},
{"f_11304expand.scm",(void*)f_11304},
{"f_11331expand.scm",(void*)f_11331},
{"f_11327expand.scm",(void*)f_11327},
{"f_11307expand.scm",(void*)f_11307},
{"f_11289expand.scm",(void*)f_11289},
{"f_11278expand.scm",(void*)f_11278},
{"f_11021expand.scm",(void*)f_11021},
{"f_11235expand.scm",(void*)f_11235},
{"f_11221expand.scm",(void*)f_11221},
{"f_11024expand.scm",(void*)f_11024},
{"f_11219expand.scm",(void*)f_11219},
{"f_11183expand.scm",(void*)f_11183},
{"f_11211expand.scm",(void*)f_11211},
{"f_11027expand.scm",(void*)f_11027},
{"f_11177expand.scm",(void*)f_11177},
{"f_11181expand.scm",(void*)f_11181},
{"f_11030expand.scm",(void*)f_11030},
{"f_11033expand.scm",(void*)f_11033},
{"f_11135expand.scm",(void*)f_11135},
{"f_11139expand.scm",(void*)f_11139},
{"f_11169expand.scm",(void*)f_11169},
{"f_11165expand.scm",(void*)f_11165},
{"f_11142expand.scm",(void*)f_11142},
{"f_11036expand.scm",(void*)f_11036},
{"f_11133expand.scm",(void*)f_11133},
{"f_11129expand.scm",(void*)f_11129},
{"f_11125expand.scm",(void*)f_11125},
{"f_11121expand.scm",(void*)f_11121},
{"f_11117expand.scm",(void*)f_11117},
{"f_11113expand.scm",(void*)f_11113},
{"f_11109expand.scm",(void*)f_11109},
{"f_11105expand.scm",(void*)f_11105},
{"f_11101expand.scm",(void*)f_11101},
{"f_11039expand.scm",(void*)f_11039},
{"f_11042expand.scm",(void*)f_11042},
{"f_10914expand.scm",(void*)f_10914},
{"f_10925expand.scm",(void*)f_10925},
{"f_10927expand.scm",(void*)f_10927},
{"f_10976expand.scm",(void*)f_10976},
{"f_10972expand.scm",(void*)f_10972},
{"f_10955expand.scm",(void*)f_10955},
{"f_10823expand.scm",(void*)f_10823},
{"f_10827expand.scm",(void*)f_10827},
{"f_10830expand.scm",(void*)f_10830},
{"f_10869expand.scm",(void*)f_10869},
{"f_10889expand.scm",(void*)f_10889},
{"f_10879expand.scm",(void*)f_10879},
{"f_10882expand.scm",(void*)f_10882},
{"f_10845expand.scm",(void*)f_10845},
{"f_10851expand.scm",(void*)f_10851},
{"f_10849expand.scm",(void*)f_10849},
{"f_10703expand.scm",(void*)f_10703},
{"f_10805expand.scm",(void*)f_10805},
{"f_10817expand.scm",(void*)f_10817},
{"f_10707expand.scm",(void*)f_10707},
{"f_10773expand.scm",(void*)f_10773},
{"f_10795expand.scm",(void*)f_10795},
{"f_10710expand.scm",(void*)f_10710},
{"f_10767expand.scm",(void*)f_10767},
{"f_10771expand.scm",(void*)f_10771},
{"f_10716expand.scm",(void*)f_10716},
{"f_10719expand.scm",(void*)f_10719},
{"f_10755expand.scm",(void*)f_10755},
{"f_10722expand.scm",(void*)f_10722},
{"f_10735expand.scm",(void*)f_10735},
{"f_10725expand.scm",(void*)f_10725},
{"f_10417expand.scm",(void*)f_10417},
{"f_10701expand.scm",(void*)f_10701},
{"f_10437expand.scm",(void*)f_10437},
{"f_10671expand.scm",(void*)f_10671},
{"f_10445expand.scm",(void*)f_10445},
{"f_10653expand.scm",(void*)f_10653},
{"f_10453expand.scm",(void*)f_10453},
{"f_10641expand.scm",(void*)f_10641},
{"f_10568expand.scm",(void*)f_10568},
{"f_10566expand.scm",(void*)f_10566},
{"f_10562expand.scm",(void*)f_10562},
{"f_10503expand.scm",(void*)f_10503},
{"f_10513expand.scm",(void*)f_10513},
{"f_10501expand.scm",(void*)f_10501},
{"f_10497expand.scm",(void*)f_10497},
{"f_10449expand.scm",(void*)f_10449},
{"f_10441expand.scm",(void*)f_10441},
{"f_10345expand.scm",(void*)f_10345},
{"f_10349expand.scm",(void*)f_10349},
{"f_10352expand.scm",(void*)f_10352},
{"f_10364expand.scm",(void*)f_10364},
{"f_10403expand.scm",(void*)f_10403},
{"f_10395expand.scm",(void*)f_10395},
{"f_10355expand.scm",(void*)f_10355},
{"f_10358expand.scm",(void*)f_10358},
{"f_10069expand.scm",(void*)f_10069},
{"f_10150expand.scm",(void*)f_10150},
{"f_10177expand.scm",(void*)f_10177},
{"f_10179expand.scm",(void*)f_10179},
{"f_10339expand.scm",(void*)f_10339},
{"f_10327expand.scm",(void*)f_10327},
{"f_10308expand.scm",(void*)f_10308},
{"f_10290expand.scm",(void*)f_10290},
{"f_10275expand.scm",(void*)f_10275},
{"f_10245expand.scm",(void*)f_10245},
{"f_10230expand.scm",(void*)f_10230},
{"f_10202expand.scm",(void*)f_10202},
{"f_10127expand.scm",(void*)f_10127},
{"f_10139expand.scm",(void*)f_10139},
{"f_10135expand.scm",(void*)f_10135},
{"f_10010expand.scm",(void*)f_10010},
{"f_10016expand.scm",(void*)f_10016},
{"f_10023expand.scm",(void*)f_10023},
{"f_10026expand.scm",(void*)f_10026},
{"f_9942expand.scm",(void*)f_9942},
{"f_9962expand.scm",(void*)f_9962},
{"f_9957expand.scm",(void*)f_9957},
{"f_9944expand.scm",(void*)f_9944},
{"f_9920expand.scm",(void*)f_9920},
{"f_9927expand.scm",(void*)f_9927},
{"f_9843expand.scm",(void*)f_9843},
{"f_9853expand.scm",(void*)f_9853},
{"f_9856expand.scm",(void*)f_9856},
{"f_9862expand.scm",(void*)f_9862},
{"f_9901expand.scm",(void*)f_9901},
{"f_9905expand.scm",(void*)f_9905},
{"f_9865expand.scm",(void*)f_9865},
{"f_9868expand.scm",(void*)f_9868},
{"f_9871expand.scm",(void*)f_9871},
{"f_9754expand.scm",(void*)f_9754},
{"f_9764expand.scm",(void*)f_9764},
{"f_9767expand.scm",(void*)f_9767},
{"f_9830expand.scm",(void*)f_9830},
{"f_9770expand.scm",(void*)f_9770},
{"f_9826expand.scm",(void*)f_9826},
{"f_9773expand.scm",(void*)f_9773},
{"f_9812expand.scm",(void*)f_9812},
{"f_9816expand.scm",(void*)f_9816},
{"f_9776expand.scm",(void*)f_9776},
{"f_9779expand.scm",(void*)f_9779},
{"f_9785expand.scm",(void*)f_9785},
{"f_9733expand.scm",(void*)f_9733},
{"f_9740expand.scm",(void*)f_9740},
{"f_9713expand.scm",(void*)f_9713},
{"f_9717expand.scm",(void*)f_9717},
{"f_9710expand.scm",(void*)f_9710},
{"f_9670expand.scm",(void*)f_9670},
{"f_9674expand.scm",(void*)f_9674},
{"f_9664expand.scm",(void*)f_9664},
{"f_9655expand.scm",(void*)f_9655},
{"f_9637expand.scm",(void*)f_9637},
{"f_9619expand.scm",(void*)f_9619},
{"f_9601expand.scm",(void*)f_9601},
{"f_9583expand.scm",(void*)f_9583},
{"f_9565expand.scm",(void*)f_9565},
{"f_9556expand.scm",(void*)f_9556},
{"f_9547expand.scm",(void*)f_9547},
{"f_9529expand.scm",(void*)f_9529},
{"f_9511expand.scm",(void*)f_9511},
{"f_9502expand.scm",(void*)f_9502},
{"f_9493expand.scm",(void*)f_9493},
{"f_9475expand.scm",(void*)f_9475},
{"f_7820expand.scm",(void*)f_7820},
{"f_7827expand.scm",(void*)f_7827},
{"f_7841expand.scm",(void*)f_7841},
{"f_7845expand.scm",(void*)f_7845},
{"f_7849expand.scm",(void*)f_7849},
{"f_7854expand.scm",(void*)f_7854},
{"f_7860expand.scm",(void*)f_7860},
{"f_7864expand.scm",(void*)f_7864},
{"f_7868expand.scm",(void*)f_7868},
{"f_7872expand.scm",(void*)f_7872},
{"f_7876expand.scm",(void*)f_7876},
{"f_7881expand.scm",(void*)f_7881},
{"f_7885expand.scm",(void*)f_7885},
{"f_7892expand.scm",(void*)f_7892},
{"f_7897expand.scm",(void*)f_7897},
{"f_7901expand.scm",(void*)f_7901},
{"f_7905expand.scm",(void*)f_7905},
{"f_7909expand.scm",(void*)f_7909},
{"f_9412expand.scm",(void*)f_9412},
{"f_9422expand.scm",(void*)f_9422},
{"f_9429expand.scm",(void*)f_9429},
{"f_9392expand.scm",(void*)f_9392},
{"f_9399expand.scm",(void*)f_9399},
{"f_9406expand.scm",(void*)f_9406},
{"f_9366expand.scm",(void*)f_9366},
{"f_9344expand.scm",(void*)f_9344},
{"f_9351expand.scm",(void*)f_9351},
{"f_9251expand.scm",(void*)f_9251},
{"f_9293expand.scm",(void*)f_9293},
{"f_9342expand.scm",(void*)f_9342},
{"f_9325expand.scm",(void*)f_9325},
{"f_9304expand.scm",(void*)f_9304},
{"f_9264expand.scm",(void*)f_9264},
{"f_9178expand.scm",(void*)f_9178},
{"f_9204expand.scm",(void*)f_9204},
{"f_9249expand.scm",(void*)f_9249},
{"f_9232expand.scm",(void*)f_9232},
{"f_8924expand.scm",(void*)f_8924},
{"f_8971expand.scm",(void*)f_8971},
{"f_9169expand.scm",(void*)f_9169},
{"f_9165expand.scm",(void*)f_9165},
{"f_9132expand.scm",(void*)f_9132},
{"f_9140expand.scm",(void*)f_9140},
{"f_8974expand.scm",(void*)f_8974},
{"f_8980expand.scm",(void*)f_8980},
{"f_8992expand.scm",(void*)f_8992},
{"f_9058expand.scm",(void*)f_9058},
{"f_9073expand.scm",(void*)f_9073},
{"f_8995expand.scm",(void*)f_8995},
{"f_9029expand.scm",(void*)f_9029},
{"f_8998expand.scm",(void*)f_8998},
{"f_9027expand.scm",(void*)f_9027},
{"f_9023expand.scm",(void*)f_9023},
{"f_9019expand.scm",(void*)f_9019},
{"f_8717expand.scm",(void*)f_8717},
{"f_8747expand.scm",(void*)f_8747},
{"f_8847expand.scm",(void*)f_8847},
{"f_8870expand.scm",(void*)f_8870},
{"f_8884expand.scm",(void*)f_8884},
{"f_8888expand.scm",(void*)f_8888},
{"f_8857expand.scm",(void*)f_8857},
{"f_8807expand.scm",(void*)f_8807},
{"f_8811expand.scm",(void*)f_8811},
{"f_8756expand.scm",(void*)f_8756},
{"f_8764expand.scm",(void*)f_8764},
{"f_8741expand.scm",(void*)f_8741},
{"f_8429expand.scm",(void*)f_8429},
{"f_8436expand.scm",(void*)f_8436},
{"f_8475expand.scm",(void*)f_8475},
{"f_8485expand.scm",(void*)f_8485},
{"f_8616expand.scm",(void*)f_8616},
{"f_8620expand.scm",(void*)f_8620},
{"f_8549expand.scm",(void*)f_8549},
{"f_8545expand.scm",(void*)f_8545},
{"f_8483expand.scm",(void*)f_8483},
{"f_8479expand.scm",(void*)f_8479},
{"f_8311expand.scm",(void*)f_8311},
{"f_8315expand.scm",(void*)f_8315},
{"f_8090expand.scm",(void*)f_8090},
{"f_8140expand.scm",(void*)f_8140},
{"f_8254expand.scm",(void*)f_8254},
{"f_8192expand.scm",(void*)f_8192},
{"f_8200expand.scm",(void*)f_8200},
{"f_8196expand.scm",(void*)f_8196},
{"f_8188expand.scm",(void*)f_8188},
{"f_8006expand.scm",(void*)f_8006},
{"f_8013expand.scm",(void*)f_8013},
{"f_8016expand.scm",(void*)f_8016},
{"f_8065expand.scm",(void*)f_8065},
{"f_8061expand.scm",(void*)f_8061},
{"f_8056expand.scm",(void*)f_8056},
{"f_8042expand.scm",(void*)f_8042},
{"f_8054expand.scm",(void*)f_8054},
{"f_8050expand.scm",(void*)f_8050},
{"f_7912expand.scm",(void*)f_7912},
{"f_7956expand.scm",(void*)f_7956},
{"f_7952expand.scm",(void*)f_7952},
{"f_6918expand.scm",(void*)f_6918},
{"f_6922expand.scm",(void*)f_6922},
{"f_6925expand.scm",(void*)f_6925},
{"f_6928expand.scm",(void*)f_6928},
{"f_6931expand.scm",(void*)f_6931},
{"f_7530expand.scm",(void*)f_7530},
{"f_7533expand.scm",(void*)f_7533},
{"f_7752expand.scm",(void*)f_7752},
{"f_7737expand.scm",(void*)f_7737},
{"f_7536expand.scm",(void*)f_7536},
{"f_7541expand.scm",(void*)f_7541},
{"f_7545expand.scm",(void*)f_7545},
{"f_7554expand.scm",(void*)f_7554},
{"f_7712expand.scm",(void*)f_7712},
{"f_7557expand.scm",(void*)f_7557},
{"f_7689expand.scm",(void*)f_7689},
{"f_7560expand.scm",(void*)f_7560},
{"f_7563expand.scm",(void*)f_7563},
{"f_7635expand.scm",(void*)f_7635},
{"f_7669expand.scm",(void*)f_7669},
{"f_7566expand.scm",(void*)f_7566},
{"f_7593expand.scm",(void*)f_7593},
{"f_7633expand.scm",(void*)f_7633},
{"f_7569expand.scm",(void*)f_7569},
{"f_7591expand.scm",(void*)f_7591},
{"f_7587expand.scm",(void*)f_7587},
{"f_7572expand.scm",(void*)f_7572},
{"f_7583expand.scm",(void*)f_7583},
{"f_7579expand.scm",(void*)f_7579},
{"f_7539expand.scm",(void*)f_7539},
{"f_7072expand.scm",(void*)f_7072},
{"f_7091expand.scm",(void*)f_7091},
{"f_7100expand.scm",(void*)f_7100},
{"f_7112expand.scm",(void*)f_7112},
{"f_7192expand.scm",(void*)f_7192},
{"f_7299expand.scm",(void*)f_7299},
{"f_7446expand.scm",(void*)f_7446},
{"f_7449expand.scm",(void*)f_7449},
{"f_7452expand.scm",(void*)f_7452},
{"f_7485expand.scm",(void*)f_7485},
{"f_7489expand.scm",(void*)f_7489},
{"f_7454expand.scm",(void*)f_7454},
{"f_7474expand.scm",(void*)f_7474},
{"f_7470expand.scm",(void*)f_7470},
{"f_7462expand.scm",(void*)f_7462},
{"f_7302expand.scm",(void*)f_7302},
{"f_7311expand.scm",(void*)f_7311},
{"f_7440expand.scm",(void*)f_7440},
{"f_7421expand.scm",(void*)f_7421},
{"f_7409expand.scm",(void*)f_7409},
{"f_7388expand.scm",(void*)f_7388},
{"f_7369expand.scm",(void*)f_7369},
{"f_7357expand.scm",(void*)f_7357},
{"f_7332expand.scm",(void*)f_7332},
{"f_7327expand.scm",(void*)f_7327},
{"f_7195expand.scm",(void*)f_7195},
{"f_7198expand.scm",(void*)f_7198},
{"f_7203expand.scm",(void*)f_7203},
{"f_7289expand.scm",(void*)f_7289},
{"f_7215expand.scm",(void*)f_7215},
{"f_7257expand.scm",(void*)f_7257},
{"f_7115expand.scm",(void*)f_7115},
{"f_7118expand.scm",(void*)f_7118},
{"f_7123expand.scm",(void*)f_7123},
{"f_6985expand.scm",(void*)f_6985},
{"f_6989expand.scm",(void*)f_6989},
{"f_6992expand.scm",(void*)f_6992},
{"f_7070expand.scm",(void*)f_7070},
{"f_7066expand.scm",(void*)f_7066},
{"f_7007expand.scm",(void*)f_7007},
{"f_7013expand.scm",(void*)f_7013},
{"f_7016expand.scm",(void*)f_7016},
{"f_7055expand.scm",(void*)f_7055},
{"f_7049expand.scm",(void*)f_7049},
{"f_7053expand.scm",(void*)f_7053},
{"f_7017expand.scm",(void*)f_7017},
{"f_7021expand.scm",(void*)f_7021},
{"f_7024expand.scm",(void*)f_7024},
{"f_7028expand.scm",(void*)f_7028},
{"f_7031expand.scm",(void*)f_7031},
{"f_7035expand.scm",(void*)f_7035},
{"f_7038expand.scm",(void*)f_7038},
{"f_7042expand.scm",(void*)f_7042},
{"f_7045expand.scm",(void*)f_7045},
{"f_6995expand.scm",(void*)f_6995},
{"f_6942expand.scm",(void*)f_6942},
{"f_6955expand.scm",(void*)f_6955},
{"f_6962expand.scm",(void*)f_6962},
{"f_6933expand.scm",(void*)f_6933},
{"f_6937expand.scm",(void*)f_6937},
{"f_6624expand.scm",(void*)f_6624},
{"f_6626expand.scm",(void*)f_6626},
{"f_6755expand.scm",(void*)f_6755},
{"f_6788expand.scm",(void*)f_6788},
{"f_6878expand.scm",(void*)f_6878},
{"f_6791expand.scm",(void*)f_6791},
{"f_6794expand.scm",(void*)f_6794},
{"f_6872expand.scm",(void*)f_6872},
{"f_6797expand.scm",(void*)f_6797},
{"f_6866expand.scm",(void*)f_6866},
{"f_6843expand.scm",(void*)f_6843},
{"f_6816expand.scm",(void*)f_6816},
{"f_6823expand.scm",(void*)f_6823},
{"f_6759expand.scm",(void*)f_6759},
{"f_6762expand.scm",(void*)f_6762},
{"f_6892expand.scm",(void*)f_6892},
{"f_6896expand.scm",(void*)f_6896},
{"f_6899expand.scm",(void*)f_6899},
{"f_6629expand.scm",(void*)f_6629},
{"f_6665expand.scm",(void*)f_6665},
{"f_6726expand.scm",(void*)f_6726},
{"f_6729expand.scm",(void*)f_6729},
{"f_6696expand.scm",(void*)f_6696},
{"f_6699expand.scm",(void*)f_6699},
{"f_6677expand.scm",(void*)f_6677},
{"f_6639expand.scm",(void*)f_6639},
{"f_6162expand.scm",(void*)f_6162},
{"f_6576expand.scm",(void*)f_6576},
{"f_6567expand.scm",(void*)f_6567},
{"f_6575expand.scm",(void*)f_6575},
{"f_6164expand.scm",(void*)f_6164},
{"f_6295expand.scm",(void*)f_6295},
{"f_6300expand.scm",(void*)f_6300},
{"f_6538expand.scm",(void*)f_6538},
{"f_6497expand.scm",(void*)f_6497},
{"f_6501expand.scm",(void*)f_6501},
{"f_6319expand.scm",(void*)f_6319},
{"f_6324expand.scm",(void*)f_6324},
{"f_6343expand.scm",(void*)f_6343},
{"f_6266expand.scm",(void*)f_6266},
{"f_6272expand.scm",(void*)f_6272},
{"f_6210expand.scm",(void*)f_6210},
{"f_6214expand.scm",(void*)f_6214},
{"f_6222expand.scm",(void*)f_6222},
{"f_6242expand.scm",(void*)f_6242},
{"f_6167expand.scm",(void*)f_6167},
{"f_6174expand.scm",(void*)f_6174},
{"f_6179expand.scm",(void*)f_6179},
{"f_6183expand.scm",(void*)f_6183},
{"f_6208expand.scm",(void*)f_6208},
{"f_6197expand.scm",(void*)f_6197},
{"f_6201expand.scm",(void*)f_6201},
{"f_6190expand.scm",(void*)f_6190},
{"f_6126expand.scm",(void*)f_6126},
{"f_6148expand.scm",(void*)f_6148},
{"f_6115expand.scm",(void*)f_6115},
{"f_6123expand.scm",(void*)f_6123},
{"f_6045expand.scm",(void*)f_6045},
{"f_6108expand.scm",(void*)f_6108},
{"f_6048expand.scm",(void*)f_6048},
{"f_6101expand.scm",(void*)f_6101},
{"f_6074expand.scm",(void*)f_6074},
{"f_5962expand.scm",(void*)f_5962},
{"f_6043expand.scm",(void*)f_6043},
{"f_5965expand.scm",(void*)f_5965},
{"f_6014expand.scm",(void*)f_6014},
{"f_5209expand.scm",(void*)f_5209},
{"f_5213expand.scm",(void*)f_5213},
{"f_5652expand.scm",(void*)f_5652},
{"f_5658expand.scm",(void*)f_5658},
{"f_5922expand.scm",(void*)f_5922},
{"f_5680expand.scm",(void*)f_5680},
{"f_5890expand.scm",(void*)f_5890},
{"f_5864expand.scm",(void*)f_5864},
{"f_5871expand.scm",(void*)f_5871},
{"f_5836expand.scm",(void*)f_5836},
{"f_5824expand.scm",(void*)f_5824},
{"f_5698expand.scm",(void*)f_5698},
{"f_5703expand.scm",(void*)f_5703},
{"f_5716expand.scm",(void*)f_5716},
{"f_5772expand.scm",(void*)f_5772},
{"f_5799expand.scm",(void*)f_5799},
{"f_5750expand.scm",(void*)f_5750},
{"f_5761expand.scm",(void*)f_5761},
{"f_5765expand.scm",(void*)f_5765},
{"f_5475expand.scm",(void*)f_5475},
{"f_5485expand.scm",(void*)f_5485},
{"f_5634expand.scm",(void*)f_5634},
{"f_5630expand.scm",(void*)f_5630},
{"f_5620expand.scm",(void*)f_5620},
{"f_5623expand.scm",(void*)f_5623},
{"f_5531expand.scm",(void*)f_5531},
{"f_5563expand.scm",(void*)f_5563},
{"f_5575expand.scm",(void*)f_5575},
{"f_5583expand.scm",(void*)f_5583},
{"f_5587expand.scm",(void*)f_5587},
{"f_5549expand.scm",(void*)f_5549},
{"f_5500expand.scm",(void*)f_5500},
{"f_5516expand.scm",(void*)f_5516},
{"f_5508expand.scm",(void*)f_5508},
{"f_5512expand.scm",(void*)f_5512},
{"f_5483expand.scm",(void*)f_5483},
{"f_5215expand.scm",(void*)f_5215},
{"f_5326expand.scm",(void*)f_5326},
{"f_5467expand.scm",(void*)f_5467},
{"f_5455expand.scm",(void*)f_5455},
{"f_5348expand.scm",(void*)f_5348},
{"f_5453expand.scm",(void*)f_5453},
{"f_5437expand.scm",(void*)f_5437},
{"f_5356expand.scm",(void*)f_5356},
{"f_5431expand.scm",(void*)f_5431},
{"f_5435expand.scm",(void*)f_5435},
{"f_5370expand.scm",(void*)f_5370},
{"f_5374expand.scm",(void*)f_5374},
{"f_5407expand.scm",(void*)f_5407},
{"f_5405expand.scm",(void*)f_5405},
{"f_5401expand.scm",(void*)f_5401},
{"f_5364expand.scm",(void*)f_5364},
{"f_5368expand.scm",(void*)f_5368},
{"f_5360expand.scm",(void*)f_5360},
{"f_5352expand.scm",(void*)f_5352},
{"f_5332expand.scm",(void*)f_5332},
{"f_5227expand.scm",(void*)f_5227},
{"f_5241expand.scm",(void*)f_5241},
{"f_5316expand.scm",(void*)f_5316},
{"f_5309expand.scm",(void*)f_5309},
{"f_5250expand.scm",(void*)f_5250},
{"f_5257expand.scm",(void*)f_5257},
{"f_5265expand.scm",(void*)f_5265},
{"f_5273expand.scm",(void*)f_5273},
{"f_5261expand.scm",(void*)f_5261},
{"f_4619expand.scm",(void*)f_4619},
{"f_4639expand.scm",(void*)f_4639},
{"f_4642expand.scm",(void*)f_4642},
{"f_4645expand.scm",(void*)f_4645},
{"f_4648expand.scm",(void*)f_4648},
{"f_4651expand.scm",(void*)f_4651},
{"f_4656expand.scm",(void*)f_4656},
{"f_4967expand.scm",(void*)f_4967},
{"f_5146expand.scm",(void*)f_5146},
{"f_5084expand.scm",(void*)f_5084},
{"f_5065expand.scm",(void*)f_5065},
{"f_5019expand.scm",(void*)f_5019},
{"f_5022expand.scm",(void*)f_5022},
{"f_5001expand.scm",(void*)f_5001},
{"f_4982expand.scm",(void*)f_4982},
{"f_4944expand.scm",(void*)f_4944},
{"f_4923expand.scm",(void*)f_4923},
{"f_4670expand.scm",(void*)f_4670},
{"f_4916expand.scm",(void*)f_4916},
{"f_4843expand.scm",(void*)f_4843},
{"f_4912expand.scm",(void*)f_4912},
{"f_4896expand.scm",(void*)f_4896},
{"f_4878expand.scm",(void*)f_4878},
{"f_4874expand.scm",(void*)f_4874},
{"f_4837expand.scm",(void*)f_4837},
{"f_4841expand.scm",(void*)f_4841},
{"f_4674expand.scm",(void*)f_4674},
{"f_4686expand.scm",(void*)f_4686},
{"f_4789expand.scm",(void*)f_4789},
{"f_4781expand.scm",(void*)f_4781},
{"f_4785expand.scm",(void*)f_4785},
{"f_4758expand.scm",(void*)f_4758},
{"f_4762expand.scm",(void*)f_4762},
{"f_4713expand.scm",(void*)f_4713},
{"f_4733expand.scm",(void*)f_4733},
{"f_4705expand.scm",(void*)f_4705},
{"f_4677expand.scm",(void*)f_4677},
{"f_4622expand.scm",(void*)f_4622},
{"f_4576expand.scm",(void*)f_4576},
{"f_4582expand.scm",(void*)f_4582},
{"f_4601expand.scm",(void*)f_4601},
{"f_4523expand.scm",(void*)f_4523},
{"f_4527expand.scm",(void*)f_4527},
{"f_4532expand.scm",(void*)f_4532},
{"f_4544expand.scm",(void*)f_4544},
{"f_4538expand.scm",(void*)f_4538},
{"f_4433expand.scm",(void*)f_4433},
{"f_4469expand.scm",(void*)f_4469},
{"f_4472expand.scm",(void*)f_4472},
{"f_4484expand.scm",(void*)f_4484},
{"f_4521expand.scm",(void*)f_4521},
{"f_4496expand.scm",(void*)f_4496},
{"f_4511expand.scm",(void*)f_4511},
{"f_4487expand.scm",(void*)f_4487},
{"f_4478expand.scm",(void*)f_4478},
{"f_4436expand.scm",(void*)f_4436},
{"f_4440expand.scm",(void*)f_4440},
{"f_4446expand.scm",(void*)f_4446},
{"f_4449expand.scm",(void*)f_4449},
{"f_4415expand.scm",(void*)f_4415},
{"f_4423expand.scm",(void*)f_4423},
{"f_3933expand.scm",(void*)f_3933},
{"f_4232expand.scm",(void*)f_4232},
{"f_4406expand.scm",(void*)f_4406},
{"f_4399expand.scm",(void*)f_4399},
{"f_4238expand.scm",(void*)f_4238},
{"f_4340expand.scm",(void*)f_4340},
{"f_4346expand.scm",(void*)f_4346},
{"f_4353expand.scm",(void*)f_4353},
{"f_4247expand.scm",(void*)f_4247},
{"f_4259expand.scm",(void*)f_4259},
{"f_4327expand.scm",(void*)f_4327},
{"f_4317expand.scm",(void*)f_4317},
{"f_4321expand.scm",(void*)f_4321},
{"f_4285expand.scm",(void*)f_4285},
{"f_4281expand.scm",(void*)f_4281},
{"f_4115expand.scm",(void*)f_4115},
{"f_4172expand.scm",(void*)f_4172},
{"f_4175expand.scm",(void*)f_4175},
{"f_4201expand.scm",(void*)f_4201},
{"f_4197expand.scm",(void*)f_4197},
{"f_4187expand.scm",(void*)f_4187},
{"f_4119expand.scm",(void*)f_4119},
{"f_4141expand.scm",(void*)f_4141},
{"f_3936expand.scm",(void*)f_3936},
{"f_3940expand.scm",(void*)f_3940},
{"f_4113expand.scm",(void*)f_4113},
{"f_4109expand.scm",(void*)f_4109},
{"f_3943expand.scm",(void*)f_3943},
{"f_3951expand.scm",(void*)f_3951},
{"f_4064expand.scm",(void*)f_4064},
{"f_4091expand.scm",(void*)f_4091},
{"f_4097expand.scm",(void*)f_4097},
{"f_4070expand.scm",(void*)f_4070},
{"f_4074expand.scm",(void*)f_4074},
{"f_4077expand.scm",(void*)f_4077},
{"f_3957expand.scm",(void*)f_3957},
{"f_3963expand.scm",(void*)f_3963},
{"f_3974expand.scm",(void*)f_3974},
{"f_3991expand.scm",(void*)f_3991},
{"f_4010expand.scm",(void*)f_4010},
{"f_4021expand.scm",(void*)f_4021},
{"f_3985expand.scm",(void*)f_3985},
{"f_3971expand.scm",(void*)f_3971},
{"f_3949expand.scm",(void*)f_3949},
{"f_3924expand.scm",(void*)f_3924},
{"f_3873expand.scm",(void*)f_3873},
{"f_3885expand.scm",(void*)f_3885},
{"f_3887expand.scm",(void*)f_3887},
{"f_3922expand.scm",(void*)f_3922},
{"f_3914expand.scm",(void*)f_3914},
{"f_3881expand.scm",(void*)f_3881},
{"f_3817expand.scm",(void*)f_3817},
{"f_3821expand.scm",(void*)f_3821},
{"f_3830expand.scm",(void*)f_3830},
{"f_3849expand.scm",(void*)f_3849},
{"f_3839expand.scm",(void*)f_3839},
{"f_3804expand.scm",(void*)f_3804},
{"f_3815expand.scm",(void*)f_3815},
{"f_3808expand.scm",(void*)f_3808},
{"f_3771expand.scm",(void*)f_3771},
{"f_3775expand.scm",(void*)f_3775},
{"f_3778expand.scm",(void*)f_3778},
{"f_3616expand.scm",(void*)f_3616},
{"f_3716expand.scm",(void*)f_3716},
{"f_3711expand.scm",(void*)f_3711},
{"f_3618expand.scm",(void*)f_3618},
{"f_3624expand.scm",(void*)f_3624},
{"f_3710expand.scm",(void*)f_3710},
{"f_3706expand.scm",(void*)f_3706},
{"f_3681expand.scm",(void*)f_3681},
{"f_3685expand.scm",(void*)f_3685},
{"f_3634expand.scm",(void*)f_3634},
{"f_3640expand.scm",(void*)f_3640},
{"f_3586expand.scm",(void*)f_3586},
{"f_3592expand.scm",(void*)f_3592},
{"f_3537expand.scm",(void*)f_3537},
{"f_3544expand.scm",(void*)f_3544},
{"f_3547expand.scm",(void*)f_3547},
{"f_3550expand.scm",(void*)f_3550},
{"f_3553expand.scm",(void*)f_3553},
{"f_3559expand.scm",(void*)f_3559},
{"f_3562expand.scm",(void*)f_3562},
{"f_3519expand.scm",(void*)f_3519},
{"f_3532expand.scm",(void*)f_3532},
{"f_3488expand.scm",(void*)f_3488},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
