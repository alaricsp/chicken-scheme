/* Generated from expand.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-01 13:56
   Version 4.0.0x - linux-unix-gnu-x86	[ dload ptables applyhook lockts ]
   SVN rev. 11775	compiled 2008-08-28 on dill (Linux)
   command line: expand.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file expand.c
   unit: expand
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[392];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,17),40,100,32,97,114,103,49,55,32,46,32,109,111,114,101,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,108,111,111,107,117,112,32,105,100,50,52,32,115,101,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,109,97,99,114,111,45,97,108,105,97,115,32,118,97,114,52,53,32,115,101,52,54,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,11),40,97,51,53,54,50,32,97,56,48,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,13),40,109,97,112,45,115,101,32,115,101,55,56,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,11),40,119,97,108,107,32,120,49,48,54,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,115,116,114,105,112,45,115,121,110,116,97,120,32,101,120,112,57,48,32,46,32,116,109,112,56,57,57,49,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,101,120,116,101,110,100,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,110,97,109,101,49,51,50,32,115,101,49,51,51,32,104,97,110,100,108,101,114,49,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,99,111,112,121,45,109,97,99,114,111,32,111,108,100,49,53,52,32,110,101,119,49,53,53,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,27),40,109,97,99,114,111,63,32,115,121,109,49,54,55,32,46,32,116,109,112,49,54,54,49,54,56,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,109,101,50,48,49,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,109,97,99,114,111,32,110,97,109,101,49,57,55,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,25),40,117,110,100,101,102,105,110,101,45,109,97,99,114,111,33,32,110,97,109,101,50,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,112,115,50,52,56,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,51,56,56,53,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,51,56,55,57,32,101,120,50,52,49,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,7),40,97,51,57,57,50,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,7),40,97,52,48,49,57,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,20),40,97,52,48,49,51,32,46,32,97,114,103,115,50,51,53,50,54,56,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,51,57,56,54,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,15),40,97,51,56,55,51,32,107,50,51,52,50,51,57,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,46),40,99,97,108,108,45,104,97,110,100,108,101,114,32,110,97,109,101,50,50,53,32,104,97,110,100,108,101,114,50,50,54,32,101,120,112,50,50,55,32,115,101,50,50,56,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,31),40,101,120,112,97,110,100,32,104,101,97,100,50,55,51,32,101,120,112,50,55,52,32,109,100,101,102,50,55,53,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,52,50,52,57,32,98,51,52,55,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,101,120,112,97,110,100,45,48,32,101,120,112,50,50,48,32,100,115,101,50,50,49,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,109,111,100,117,108,101,45,114,101,110,97,109,101,32,115,121,109,51,54,52,32,112,114,101,102,105,120,51,54,53,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,16),40,109,114,101,110,97,109,101,32,115,121,109,51,56,49,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,97,108,105,97,115,45,103,108,111,98,97,108,45,104,111,111,107,32,115,121,109,51,54,57,32,97,115,115,105,103,110,51,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,7),40,97,52,52,54,48,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,32),40,97,52,52,54,54,32,101,120,112,50,52,52,56,52,52,57,52,53,52,32,109,52,53,48,52,53,49,52,53,53,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,52,52,53,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,101,120,112,97,110,100,32,101,120,112,52,51,48,32,46,32,116,109,112,52,50,57,52,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,108,105,115,116,52,54,57,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,63,32,108,108,105,115,116,52,54,53,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,12),40,101,114,114,32,109,115,103,53,48,53,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,12),40,97,52,55,54,53,32,107,53,51,56,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,109,111,100,101,53,50,48,32,114,101,113,53,50,49,32,111,112,116,53,50,50,32,107,101,121,53,50,51,32,108,108,105,115,116,53,50,52,41,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,67),40,35,35,115,121,115,35,101,120,112,97,110,100,45,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,32,108,108,105,115,116,48,52,57,56,32,98,111,100,121,52,57,57,32,101,114,114,104,53,48,48,32,115,101,53,48,49,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,98,111,100,121,50,54,55,54,32,101,120,112,115,54,55,55,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,17),40,97,53,51,50,57,32,118,55,51,51,32,116,55,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,18),40,97,53,50,57,50,32,118,115,55,50,52,32,120,55,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,17),40,97,53,51,53,57,32,118,55,49,55,32,120,55,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,12),40,97,53,51,55,55,32,118,55,49,53,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,48),40,102,105,110,105,32,118,97,114,115,54,54,54,32,118,97,108,115,54,54,55,32,109,118,97,114,115,54,54,56,32,109,118,97,108,115,54,54,57,32,98,111,100,121,54,55,48,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,30),40,108,111,111,112,32,98,111,100,121,55,53,53,32,100,101,102,115,55,53,54,32,100,111,110,101,55,53,55,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,55),40,102,105,110,105,47,115,121,110,116,97,120,32,118,97,114,115,55,52,55,32,118,97,108,115,55,52,56,32,109,118,97,114,115,55,52,57,32,109,118,97,108,115,55,53,48,32,98,111,100,121,55,53,49,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,50,32,120,56,51,49,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,48),40,108,111,111,112,32,98,111,100,121,55,57,52,32,118,97,114,115,55,57,53,32,118,97,108,115,55,57,54,32,109,118,97,114,115,55,57,55,32,109,118,97,108,115,55,57,56,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,98,111,100,121,55,57,48,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,99,97,110,111,110,105,99,97,108,105,122,101,45,98,111,100,121,32,98,111,100,121,54,53,48,32,46,32,116,109,112,54,52,57,54,53,49,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,17),40,109,119,97,108,107,32,120,56,55,56,32,112,56,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,40),40,109,97,116,99,104,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,56,54,57,32,112,97,116,56,55,48,32,118,97,114,115,56,55,49,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,104,101,97,100,57,49,52,32,98,111,100,121,57,49,53,41,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,51),40,35,35,115,121,115,35,101,120,112,97,110,100,45,99,117,114,114,105,101,100,45,100,101,102,105,110,101,32,104,101,97,100,57,48,55,32,98,111,100,121,57,48,56,32,115,101,57,48,57,41,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,45,104,111,111,107,32,46,32,97,114,103,115,57,51,51,41,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,25),40,103,101,116,45,108,105,110,101,45,110,117,109,98,101,114,32,115,101,120,112,57,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,13),40,101,114,114,32,109,115,103,49,48,49,52,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,29),40,116,101,115,116,32,120,49,48,48,56,32,112,114,101,100,49,48,48,57,32,109,115,103,49,48,49,48,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,49,48,51,50,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,20),40,108,97,109,98,100,97,45,108,105,115,116,63,32,120,49,48,50,50,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,20),40,112,114,111,112,101,114,45,108,105,115,116,63,32,120,49,48,53,51,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,49,48,50,32,120,49,49,48,57,32,110,49,49,49,48,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,13),40,97,54,52,49,57,32,121,49,49,51,48,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,48,55,54,32,112,49,48,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,57,56,57,32,99,117,108,112,114,105,116,57,57,57,32,115,101,49,48,48,48,41,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,115,101,57,57,50,32,37,99,117,108,112,114,105,116,57,56,55,49,49,52,54,41,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,99,117,108,112,114,105,116,57,57,49,41};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,52),40,35,35,115,121,115,35,99,104,101,99,107,45,115,121,110,116,97,120,32,105,100,57,55,55,32,101,120,112,57,55,56,32,112,97,116,57,55,57,32,46,32,116,109,112,57,55,54,57,56,48,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,16),40,114,101,110,97,109,101,32,115,121,109,49,49,55,49,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,31),40,108,111,111,107,117,112,50,32,110,49,51,48,56,32,115,121,109,49,51,48,57,32,100,115,101,49,51,49,48,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,23),40,99,111,109,112,97,114,101,32,115,49,49,50,50,52,32,115,50,49,50,50,53,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,32),40,102,95,54,53,52,57,32,102,111,114,109,49,49,54,50,32,115,101,49,49,54,51,32,100,115,101,49,49,54,52,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,101,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,49,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,17),40,114,101,115,111,108,118,101,32,115,121,109,49,51,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,13),40,116,111,115,116,114,32,120,49,51,52,55,41,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,10),40,115,119,97,112,49,51,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,7),40,97,54,57,55,55,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,110,97,109,101,32,115,112,101,99,49,51,53,54,41,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,105,100,115,49,52,54,51,32,118,49,52,54,52,32,115,49,52,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,115,49,53,48,52,32,115,49,53,48,53,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,118,49,52,57,50,32,118,49,52,57,51,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,14),40,97,55,50,53,52,32,105,100,49,53,52,51,41,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,105,109,112,118,49,53,50,49,32,105,109,112,115,49,53,50,50,32,118,49,53,50,51,32,115,49,53,50,52,32,105,100,115,49,53,50,53,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,13),40,114,101,110,32,105,109,112,49,53,54,50,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,115,112,101,99,32,115,112,101,99,49,52,50,55,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,15),40,97,55,53,49,53,32,105,109,112,49,54,48,50,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,15),40,97,55,53,53,55,32,105,109,112,49,53,57,50,41,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,16),40,97,55,52,54,51,32,115,112,101,99,49,53,55,48,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,86),40,35,35,115,121,115,35,101,120,112,97,110,100,45,105,109,112,111,114,116,32,120,49,51,50,50,32,114,49,51,50,51,32,99,49,51,50,52,32,105,109,112,111,114,116,45,101,110,118,49,51,50,53,32,109,97,99,114,111,45,101,110,118,49,51,50,54,32,109,101,116,97,63,49,51,50,55,32,108,111,99,49,51,50,56,41,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,18),40,102,95,55,56,51,53,32,114,117,108,101,115,50,50,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,13),40,97,55,57,55,56,32,120,50,50,56,56,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,17),40,102,95,55,57,50,57,32,114,117,108,101,50,50,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,30),40,102,95,56,48,49,51,32,105,110,112,117,116,50,50,57,48,32,112,97,116,116,101,114,110,50,50,57,49,41,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,30),40,102,95,56,50,51,52,32,105,110,112,117,116,50,51,52,48,32,112,97,116,116,101,114,110,50,51,52,49,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,51,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,30),40,102,95,56,51,53,50,32,105,110,112,117,116,50,51,53,55,32,112,97,116,116,101,114,110,50,51,53,56,41,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,13),40,97,56,54,55,56,32,120,50,52,49,56,41,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,52,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,39),40,102,95,56,54,52,48,32,112,97,116,116,101,114,110,50,52,48,55,32,112,97,116,104,50,52,48,56,32,109,97,112,105,116,50,52,48,57,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,50,53,48,50,32,100,50,53,48,56,32,103,101,110,50,53,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,37),40,102,95,56,56,52,55,32,116,101,109,112,108,97,116,101,50,52,54,49,32,100,105,109,50,52,54,50,32,101,110,118,50,52,54,51,41,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,37),40,102,95,57,49,48,49,32,112,97,116,116,101,114,110,50,53,51,53,32,100,105,109,50,53,51,54,32,118,97,114,115,50,53,51,55,41,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,46),40,102,95,57,49,55,52,32,116,101,109,112,108,97,116,101,50,53,52,54,32,100,105,109,50,53,52,55,32,101,110,118,50,53,52,56,32,102,114,101,101,50,53,52,57,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,20),40,102,95,57,50,54,55,32,112,97,116,116,101,114,110,50,53,54,52,41,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,20),40,102,95,57,50,56,57,32,112,97,116,116,101,114,110,50,53,55,52,41,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,49,53,32,112,97,116,116,101,114,110,50,53,56,48,41,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,97,116,116,101,114,110,50,53,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,51,53,32,112,97,116,116,101,114,110,50,53,56,50,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,79),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,115,121,110,116,97,120,45,114,117,108,101,115,32,101,108,108,105,112,115,105,115,50,50,49,50,32,114,117,108,101,115,50,50,49,51,32,115,117,98,107,101,121,119,111,114,100,115,50,50,49,52,32,114,50,50,49,53,32,99,50,50,49,54,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,19),40,109,111,100,117,108,101,63,32,120,50,54,53,51,50,54,55,48,41,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,13),40,109,111,100,117,108,101,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,20),40,109,111,100,117,108,101,45,101,120,112,111,114,116,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,46),40,115,101,116,45,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,53,51,50,54,56,52,32,121,50,54,53,52,50,54,56,53,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,41,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,19),40,109,111,100,117,108,101,45,101,120,105,115,116,45,108,105,115,116,41,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,28),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,115,121,110,116,97,120,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,48),40,115,101,116,45,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,53,51,50,55,48,56,32,121,50,54,53,52,50,55,48,57,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,32,120,50,54,53,51,50,55,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,26),40,109,111,100,117,108,101,45,109,101,116,97,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,25),40,109,111,100,117,108,101,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,118,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,115,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,51),40,109,97,107,101,45,109,111,100,117,108,101,32,101,120,112,108,105,115,116,50,55,56,48,32,118,101,120,112,111,114,116,115,50,55,56,49,32,115,101,120,112,111,114,116,115,50,55,56,50,41,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,102,105,110,100,45,109,111,100,117,108,101,32,110,97,109,101,50,55,57,50,32,46,32,116,109,112,50,55,57,49,50,55,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,64),40,35,35,115,121,115,35,116,111,112,108,101,118,101,108,45,100,101,102,105,110,105,116,105,111,110,45,104,111,111,107,32,115,121,109,50,56,49,55,32,109,111,100,50,56,49,56,32,101,120,112,50,56,49,57,32,118,97,108,50,56,50,48,41};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,50,56,50,52,41};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,42),40,99,104,101,99,107,45,102,111,114,45,114,101,100,101,102,32,115,121,109,50,56,51,51,32,101,110,118,50,56,51,52,32,115,101,110,118,50,56,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,101,120,112,111,114,116,32,115,121,109,50,56,53,48,32,109,111,100,50,56,53,49,41,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,115,121,110,116,97,120,45,101,120,112,111,114,116,32,115,121,109,50,56,55,53,32,109,111,100,50,56,55,54,32,118,97,108,50,56,55,55,41,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,117,110,100,101,102,105,110,101,100,32,115,121,109,50,57,48,49,32,109,111,100,50,57,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,50,57,50,57,32,115,101,120,112,111,114,116,115,50,57,52,48,41,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,18),40,100,101,102,45,115,101,120,112,111,114,116,115,50,57,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,58),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,32,110,97,109,101,50,57,49,56,32,101,120,112,108,105,115,116,50,57,49,57,32,46,32,116,109,112,50,57,49,55,50,57,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,15),40,97,57,57,51,56,32,105,109,112,50,57,54,52,41,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,109,97,114,107,45,105,109,112,111,114,116,101,100,45,115,121,109,98,111,108,115,32,115,101,50,57,54,50,41,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,21),40,119,97,114,110,32,109,115,103,51,48,48,51,32,105,100,51,48,48,52,41,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,50,32,105,101,120,112,111,114,116,115,51,48,49,57,41,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,101,120,112,111,114,116,115,51,48,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,105,110,100,105,114,101,99,116,45,101,120,112,111,114,116,115,32,109,111,100,50,57,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,101,51,48,55,48,41,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,18),40,109,101,114,103,101,45,115,101,32,115,101,115,51,48,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,20),40,97,49,48,52,50,53,32,115,101,120,112,111,114,116,51,49,49,53,41,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,15),40,97,49,48,52,57,48,32,105,101,51,49,48,53,41,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,45,114,101,103,105,115,116,114,97,116,105,111,110,32,109,111,100,51,48,56,54,41,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,17),40,97,49,48,54,53,55,32,105,101,120,112,51,49,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,17),40,97,49,48,54,55,55,32,115,101,120,112,51,49,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,15),40,97,49,48,54,57,53,32,105,101,51,49,52,51,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,50,55,32,115,101,51,49,51,57,41,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,80),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,32,110,97,109,101,51,49,51,50,32,105,101,120,112,111,114,116,115,51,49,51,51,32,118,101,120,112,111,114,116,115,51,49,51,52,32,115,101,120,112,111,114,116,115,51,49,51,53,41};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,55,51,32,115,101,51,49,57,50,41,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,57,49,32,118,101,51,49,56,55,41,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,69),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,105,109,105,116,105,118,101,45,109,111,100,117,108,101,32,110,97,109,101,51,49,54,57,32,118,101,120,112,111,114,116,115,51,49,55,48,32,46,32,116,109,112,51,49,54,56,51,49,55,49,41,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,50,49,51,41,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,102,105,110,100,45,101,120,112,111,114,116,32,115,121,109,51,50,48,53,32,109,111,100,51,50,48,54,32,105,110,100,105,114,101,99,116,51,50,48,55,41};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,14),40,97,49,49,48,53,55,32,109,51,51,51,52,41,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,16),40,97,49,49,49,48,53,32,101,120,112,51,51,49,53,41};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,14),40,97,49,49,49,52,51,32,117,51,51,48,57,41,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,50,56,49,41,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,15),40,97,49,49,50,57,49,32,115,100,51,50,54,50,41,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,50,54,54,41,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,16),40,97,49,49,51,53,51,32,115,121,109,51,50,53,56,41};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,110,97,108,105,122,101,45,109,111,100,117,108,101,32,109,111,100,51,50,52,54,41,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,51,53,57,41,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,109,97,99,114,111,45,115,117,98,115,101,116,32,109,101,48,51,51,53,53,41,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,28),40,97,49,49,52,49,54,32,101,120,112,50,49,57,54,32,114,50,49,57,55,32,99,50,49,57,56,41,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,16),40,97,49,49,52,56,51,32,101,120,112,50,49,55,50,41};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,26),40,97,49,49,52,53,51,32,120,50,49,54,51,32,114,50,49,54,52,32,99,50,49,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,53,54,32,120,50,49,52,51,32,114,50,49,52,52,32,99,50,49,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,26),40,97,49,49,54,49,48,32,120,50,49,51,51,32,114,50,49,51,52,32,99,50,49,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,26),40,97,49,49,54,54,49,32,120,50,49,50,50,32,114,50,49,50,51,32,99,50,49,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,26),40,97,49,49,54,56,50,32,120,50,49,49,49,32,114,50,49,49,50,32,99,50,49,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,11),40,101,114,114,32,120,50,48,50,54,41,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,13),40,116,101,115,116,32,102,120,50,48,50,56,41,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,14),40,97,49,49,57,48,48,32,120,50,48,56,50,41,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,99,108,115,50,48,55,51,41};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,29),40,97,49,49,55,48,51,32,102,111,114,109,50,48,49,51,32,114,50,48,49,52,32,99,50,48,49,53,41,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,29),40,97,49,49,57,56,55,32,102,111,114,109,50,48,48,51,32,114,50,48,48,52,32,99,50,48,48,53,41,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,56,57,53,32,110,49,56,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,19),40,119,97,108,107,49,32,120,49,56,57,56,32,110,49,56,57,57,41,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,16),40,115,105,109,112,108,105,102,121,32,120,49,57,54,51,41};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,29),40,97,49,50,48,50,48,32,102,111,114,109,49,56,56,51,32,114,49,56,56,52,32,99,49,56,56,53,41,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,14),40,97,49,50,53,50,48,32,98,49,56,55,57,41,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,14),40,97,49,50,53,55,53,32,98,49,56,54,55,41,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,29),40,97,49,50,52,49,53,32,102,111,114,109,49,56,53,49,32,114,49,56,53,50,32,99,49,56,53,51,41,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,15),40,101,120,112,97,110,100,32,98,115,49,56,51,55,41,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,29),40,97,49,50,53,57,55,32,102,111,114,109,49,56,50,55,32,114,49,56,50,56,32,99,49,56,50,57,41,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,14),40,97,49,50,55,57,48,32,120,49,56,49,54,41,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,56,48,51,41,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,29),40,97,49,50,54,54,54,32,102,111,114,109,49,55,56,51,32,114,49,55,56,52,32,99,49,55,56,53,41,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,55,51,57,41,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,29),40,97,49,50,56,51,54,32,102,111,114,109,49,55,50,52,32,114,49,55,50,53,32,99,49,55,50,54,41,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,29),40,97,49,51,49,54,57,32,102,111,114,109,49,55,48,56,32,114,49,55,48,57,32,99,49,55,49,48,41,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,29),40,97,49,51,50,53,57,32,102,111,114,109,49,54,57,52,32,114,49,54,57,53,32,99,49,54,57,54,41,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,102,111,114,109,49,54,54,51,41,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,29),40,97,49,51,51,49,56,32,102,111,114,109,49,54,53,55,32,114,49,54,53,56,32,99,49,54,53,57,41,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,50),40,97,49,51,52,54,48,32,103,49,54,52,53,49,54,52,54,49,54,53,49,32,103,49,54,52,55,49,54,52,56,49,54,53,50,32,103,49,54,52,57,49,54,53,48,49,54,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,50),40,97,49,51,52,55,48,32,103,49,54,50,57,49,54,51,48,49,54,51,53,32,103,49,54,51,49,49,54,51,50,49,54,51,54,32,103,49,54,51,51,49,54,51,52,49,54,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_expand_toplevel)
C_externexport void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13471)
static void C_ccall f_13471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13469)
static void C_ccall f_13469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7686)
static void C_ccall f_7686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13461)
static void C_ccall f_13461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13459)
static void C_ccall f_13459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7689)
static void C_ccall f_7689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7693)
static void C_ccall f_7693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13319)
static void C_ccall f_13319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13329)
static void C_fcall f_13329(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13345)
static void C_ccall f_13345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13348)
static void C_ccall f_13348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13376)
static void C_ccall f_13376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13351)
static void C_ccall f_13351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13398)
static void C_ccall f_13398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13401)
static void C_ccall f_13401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13447)
static void C_ccall f_13447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13404)
static void C_ccall f_13404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13427)
static void C_ccall f_13427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13439)
static void C_ccall f_13439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13385)
static void C_ccall f_13385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13388)
static void C_ccall f_13388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13395)
static void C_ccall f_13395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13317)
static void C_ccall f_13317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13260)
static void C_ccall f_13260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13289)
static void C_ccall f_13289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13309)
static void C_ccall f_13309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13313)
static void C_ccall f_13313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13258)
static void C_ccall f_13258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7699)
static void C_ccall f_7699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13170)
static void C_ccall f_13170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13195)
static void C_ccall f_13195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13202)
static void C_ccall f_13202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13222)
static void C_ccall f_13222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13242)
static void C_ccall f_13242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13246)
static void C_ccall f_13246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13168)
static void C_ccall f_13168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7702)
static void C_ccall f_7702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12837)
static void C_ccall f_12837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12844)
static void C_ccall f_12844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12847)
static void C_ccall f_12847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12850)
static void C_ccall f_12850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12853)
static void C_ccall f_12853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12856)
static void C_ccall f_12856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12859)
static void C_ccall f_12859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12862)
static void C_ccall f_12862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12867)
static void C_fcall f_12867(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12883)
static void C_ccall f_12883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12889)
static void C_ccall f_12889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12931)
static void C_ccall f_12931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12999)
static void C_ccall f_12999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13124)
static void C_ccall f_13124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13120)
static void C_ccall f_13120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13002)
static void C_ccall f_13002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13057)
static void C_ccall f_13057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12934)
static void C_ccall f_12934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12973)
static void C_ccall f_12973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12925)
static void C_ccall f_12925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12896)
static void C_ccall f_12896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12835)
static void C_ccall f_12835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7705)
static void C_ccall f_7705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12667)
static void C_ccall f_12667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12671)
static void C_ccall f_12671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12680)
static void C_ccall f_12680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12683)
static void C_ccall f_12683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12686)
static void C_ccall f_12686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12689)
static void C_ccall f_12689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12692)
static void C_ccall f_12692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12713)
static void C_fcall f_12713(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12729)
static void C_ccall f_12729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12735)
static void C_ccall f_12735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12791)
static void C_ccall f_12791(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12789)
static void C_ccall f_12789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12785)
static void C_ccall f_12785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12777)
static void C_ccall f_12777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12773)
static void C_ccall f_12773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12742)
static void C_ccall f_12742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12711)
static void C_ccall f_12711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12665)
static void C_ccall f_12665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7708)
static void C_ccall f_7708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12598)
static void C_ccall f_12598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12602)
static void C_ccall f_12602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12611)
static void C_ccall f_12611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12616)
static void C_fcall f_12616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12653)
static void C_ccall f_12653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12634)
static void C_ccall f_12634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12596)
static void C_ccall f_12596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12416)
static void C_ccall f_12416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12420)
static void C_ccall f_12420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12432)
static void C_ccall f_12432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12435)
static void C_ccall f_12435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12438)
static void C_ccall f_12438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12441)
static void C_ccall f_12441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12576)
static void C_ccall f_12576(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12456)
static void C_ccall f_12456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12574)
static void C_ccall f_12574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12483)
static void C_fcall f_12483(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12564)
static void C_ccall f_12564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12499)
static void C_fcall f_12499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12521)
static void C_ccall f_12521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12519)
static void C_ccall f_12519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12515)
static void C_ccall f_12515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12414)
static void C_ccall f_12414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7714)
static void C_ccall f_7714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12021)
static void C_ccall f_12021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12025)
static void C_ccall f_12025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12028)
static void C_ccall f_12028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12031)
static void C_ccall f_12031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12034)
static void C_ccall f_12034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12403)
static void C_ccall f_12403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12315)
static void C_fcall f_12315(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12319)
static void C_ccall f_12319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12344)
static void C_ccall f_12344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12390)
static void C_ccall f_12390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12375)
static void C_ccall f_12375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12046)
static void C_fcall f_12046(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12093)
static void C_ccall f_12093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12140)
static void C_ccall f_12140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12301)
static void C_ccall f_12301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12309)
static void C_ccall f_12309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12287)
static void C_ccall f_12287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12276)
static void C_ccall f_12276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12284)
static void C_ccall f_12284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12261)
static void C_ccall f_12261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12249)
static void C_ccall f_12249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12230)
static void C_ccall f_12230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12188)
static void C_ccall f_12188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12165)
static void C_ccall f_12165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12119)
static void C_ccall f_12119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12068)
static void C_ccall f_12068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12064)
static void C_ccall f_12064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12036)
static void C_fcall f_12036(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12044)
static void C_ccall f_12044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12019)
static void C_ccall f_12019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11988)
static void C_ccall f_11988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11992)
static void C_ccall f_11992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11986)
static void C_ccall f_11986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7720)
static void C_ccall f_7720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11704)
static void C_ccall f_11704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11711)
static void C_ccall f_11711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11714)
static void C_ccall f_11714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11717)
static void C_ccall f_11717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11720)
static void C_ccall f_11720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11723)
static void C_ccall f_11723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11885)
static void C_fcall f_11885(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11938)
static void C_ccall f_11938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11960)
static void C_ccall f_11960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11967)
static void C_ccall f_11967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11954)
static void C_ccall f_11954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11901)
static void C_ccall f_11901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11899)
static void C_ccall f_11899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11735)
static void C_fcall f_11735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11766)
static void C_ccall f_11766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11812)
static void C_ccall f_11812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11862)
static void C_ccall f_11862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11869)
static void C_ccall f_11869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11827)
static void C_ccall f_11827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11841)
static void C_ccall f_11841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11784)
static void C_ccall f_11784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11795)
static void C_ccall f_11795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11725)
static void C_fcall f_11725(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11702)
static void C_ccall f_11702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7723)
static void C_ccall f_7723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11683)
static void C_ccall f_11683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11681)
static void C_ccall f_11681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7726)
static void C_ccall f_7726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11662)
static void C_ccall f_11662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11660)
static void C_ccall f_11660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7729)
static void C_ccall f_7729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11611)
static void C_ccall f_11611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11615)
static void C_ccall f_11615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11652)
static void C_ccall f_11652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11645)
static void C_ccall f_11645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11638)
static void C_ccall f_11638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11609)
static void C_ccall f_11609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11557)
static void C_ccall f_11557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11561)
static void C_ccall f_11561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11564)
static void C_ccall f_11564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11601)
static void C_ccall f_11601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11567)
static void C_ccall f_11567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11582)
static void C_ccall f_11582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11586)
static void C_ccall f_11586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11555)
static void C_ccall f_11555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11454)
static void C_ccall f_11454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11461)
static void C_ccall f_11461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11464)
static void C_ccall f_11464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11484)
static void C_ccall f_11484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11506)
static C_word C_fcall f_11506(C_word t0);
C_noret_decl(f_11491)
static void C_fcall f_11491(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11467)
static void C_ccall f_11467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11482)
static void C_ccall f_11482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11474)
static void C_ccall f_11474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11470)
static void C_ccall f_11470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11452)
static void C_ccall f_11452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11417)
static void C_ccall f_11417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11421)
static void C_ccall f_11421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11439)
static void C_ccall f_11439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11430)
static void C_fcall f_11430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11415)
static void C_ccall f_11415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7741)
static void C_ccall f_7741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9376)
static void C_ccall f_9376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11411)
static void C_ccall f_11411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9380)
static void C_ccall f_9380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9384)
static void C_ccall f_9384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11369)
static void C_ccall f_11369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11377)
static void C_ccall f_11377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11379)
static void C_fcall f_11379(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11400)
static void C_ccall f_11400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10922)
static void C_ccall f_10922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11354)
static void C_ccall f_11354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11362)
static void C_ccall f_11362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10938)
static void C_ccall f_10938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11311)
static void C_ccall f_11311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11313)
static void C_fcall f_11313(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11352)
static void C_ccall f_11352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11326)
static void C_ccall f_11326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11337)
static void C_ccall f_11337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11292)
static void C_ccall f_11292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11304)
static void C_ccall f_11304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10941)
static void C_ccall f_10941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11164)
static void C_fcall f_11164(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11215)
static void C_fcall f_11215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11268)
static void C_ccall f_11268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11227)
static void C_fcall f_11227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11254)
static void C_ccall f_11254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11250)
static void C_ccall f_11250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11230)
static void C_ccall f_11230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11212)
static void C_ccall f_11212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11201)
static void C_ccall f_11201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10944)
static void C_ccall f_10944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11158)
static void C_ccall f_11158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11144)
static void C_ccall f_11144(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10947)
static void C_ccall f_10947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11142)
static void C_ccall f_11142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11106)
static void C_ccall f_11106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11134)
static void C_ccall f_11134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10950)
static void C_ccall f_10950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11100)
static void C_ccall f_11100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11104)
static void C_ccall f_11104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10953)
static void C_ccall f_10953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10956)
static void C_ccall f_10956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11058)
static void C_ccall f_11058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11062)
static void C_ccall f_11062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11092)
static void C_ccall f_11092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11088)
static void C_ccall f_11088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11065)
static void C_ccall f_11065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10959)
static void C_ccall f_10959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11056)
static void C_ccall f_11056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11052)
static void C_ccall f_11052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11048)
static void C_ccall f_11048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11044)
static void C_ccall f_11044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11040)
static void C_ccall f_11040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11036)
static void C_ccall f_11036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11032)
static void C_ccall f_11032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11028)
static void C_ccall f_11028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11024)
static void C_ccall f_11024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10962)
static void C_ccall f_10962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10965)
static void C_ccall f_10965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10837)
static void C_ccall f_10837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10848)
static void C_ccall f_10848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10850)
static void C_fcall f_10850(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10899)
static void C_ccall f_10899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10895)
static void C_ccall f_10895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10878)
static void C_fcall f_10878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10746)
static void C_ccall f_10746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10746)
static void C_ccall f_10746r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10750)
static void C_ccall f_10750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10753)
static void C_ccall f_10753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10792)
static void C_ccall f_10792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10812)
static void C_ccall f_10812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10802)
static void C_ccall f_10802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10805)
static void C_ccall f_10805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10768)
static void C_ccall f_10768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10774)
static void C_ccall f_10774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10772)
static void C_ccall f_10772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10626)
static void C_ccall f_10626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10728)
static void C_ccall f_10728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10740)
static void C_ccall f_10740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10630)
static void C_ccall f_10630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10696)
static void C_ccall f_10696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10718)
static void C_ccall f_10718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10633)
static void C_ccall f_10633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10690)
static void C_ccall f_10690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10694)
static void C_ccall f_10694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10639)
static void C_ccall f_10639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10642)
static void C_ccall f_10642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10678)
static void C_ccall f_10678(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10645)
static void C_ccall f_10645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10658)
static void C_ccall f_10658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10648)
static void C_ccall f_10648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10340)
static void C_ccall f_10340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10624)
static void C_ccall f_10624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10360)
static void C_fcall f_10360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10594)
static void C_ccall f_10594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_fcall f_10368(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10576)
static void C_ccall f_10576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10376)
static void C_ccall f_10376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10564)
static void C_ccall f_10564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10491)
static void C_ccall f_10491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10489)
static void C_ccall f_10489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10485)
static void C_ccall f_10485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10426)
static void C_ccall f_10426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10436)
static void C_ccall f_10436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10424)
static void C_ccall f_10424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10420)
static void C_ccall f_10420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10372)
static void C_ccall f_10372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10364)
static void C_ccall f_10364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10268)
static void C_fcall f_10268(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10272)
static void C_ccall f_10272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10275)
static void C_ccall f_10275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10287)
static void C_fcall f_10287(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10326)
static void C_ccall f_10326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10318)
static void C_ccall f_10318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10278)
static void C_ccall f_10278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10281)
static void C_ccall f_10281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9992)
static void C_fcall f_9992(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10073)
static void C_fcall f_10073(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10100)
static void C_ccall f_10100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10102)
static void C_fcall f_10102(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10262)
static void C_ccall f_10262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10250)
static void C_ccall f_10250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10231)
static void C_ccall f_10231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10213)
static void C_ccall f_10213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10198)
static void C_ccall f_10198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10168)
static void C_ccall f_10168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10153)
static void C_ccall f_10153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10125)
static void C_ccall f_10125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10050)
static void C_fcall f_10050(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10062)
static void C_ccall f_10062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10058)
static void C_ccall f_10058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9933)
static void C_ccall f_9933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9939)
static void C_ccall f_9939(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9946)
static void C_fcall f_9946(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9949)
static void C_ccall f_9949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9865)
static void C_ccall f_9865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9865)
static void C_ccall f_9865r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9885)
static C_word C_fcall f_9885(C_word *a,C_word t0);
C_noret_decl(f_9880)
static C_word C_fcall f_9880(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_9867)
static C_word C_fcall f_9867(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9843)
static void C_ccall f_9843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9850)
static void C_ccall f_9850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9766)
static void C_ccall f_9766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9776)
static void C_ccall f_9776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9779)
static void C_ccall f_9779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9785)
static void C_ccall f_9785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9824)
static void C_ccall f_9824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9828)
static void C_ccall f_9828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9788)
static void C_ccall f_9788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9791)
static void C_ccall f_9791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9794)
static void C_ccall f_9794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9677)
static void C_ccall f_9677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9687)
static void C_ccall f_9687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9690)
static void C_ccall f_9690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9753)
static void C_ccall f_9753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9693)
static void C_ccall f_9693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9749)
static void C_ccall f_9749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9696)
static void C_ccall f_9696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9735)
static void C_ccall f_9735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9739)
static void C_ccall f_9739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9699)
static void C_ccall f_9699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9702)
static void C_ccall f_9702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9708)
static void C_ccall f_9708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9656)
static void C_fcall f_9656(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9663)
static void C_ccall f_9663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9636)
static void C_ccall f_9636(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9640)
static void C_ccall f_9640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9633)
static void C_ccall f_9633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9593)
static void C_ccall f_9593(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9593)
static void C_ccall f_9593r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9597)
static void C_ccall f_9597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9587)
static C_word C_fcall f_9587(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3);
C_noret_decl(f_9578)
static C_word C_fcall f_9578(C_word t0);
C_noret_decl(f_9560)
static C_word C_fcall f_9560(C_word t0);
C_noret_decl(f_9542)
static C_word C_fcall f_9542(C_word t0);
C_noret_decl(f_9524)
static C_word C_fcall f_9524(C_word t0);
C_noret_decl(f_9506)
static C_word C_fcall f_9506(C_word t0);
C_noret_decl(f_9488)
static void C_ccall f_9488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9479)
static void C_ccall f_9479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9470)
static C_word C_fcall f_9470(C_word t0);
C_noret_decl(f_9452)
static C_word C_fcall f_9452(C_word t0);
C_noret_decl(f_9434)
static C_word C_fcall f_9434(C_word t0);
C_noret_decl(f_9425)
static void C_fcall f_9425(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9416)
static C_word C_fcall f_9416(C_word t0);
C_noret_decl(f_9398)
static C_word C_fcall f_9398(C_word t0);
C_noret_decl(f_9392)
static void C_ccall f_9392(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7743)
static void C_ccall f_7743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7764)
static void C_ccall f_7764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7768)
static void C_ccall f_7768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7772)
static void C_ccall f_7772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7777)
static void C_ccall f_7777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7795)
static void C_ccall f_7795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7799)
static void C_ccall f_7799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7804)
static void C_ccall f_7804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7815)
static void C_ccall f_7815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7820)
static void C_ccall f_7820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7824)
static void C_ccall f_7824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7828)
static void C_ccall f_7828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7832)
static void C_ccall f_7832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9335)
static void C_ccall f_9335(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9345)
static void C_fcall f_9345(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9352)
static void C_fcall f_9352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9315)
static void C_ccall f_9315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9322)
static void C_ccall f_9322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9329)
static void C_ccall f_9329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9289)
static void C_ccall f_9289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9267)
static void C_ccall f_9267(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9274)
static void C_ccall f_9274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9174)
static void C_ccall f_9174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9216)
static void C_ccall f_9216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9265)
static void C_ccall f_9265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9248)
static void C_ccall f_9248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9227)
static void C_ccall f_9227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9187)
static void C_fcall f_9187(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9101)
static void C_ccall f_9101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9127)
static void C_ccall f_9127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9172)
static void C_ccall f_9172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9155)
static void C_ccall f_9155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8847)
static void C_ccall f_8847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8894)
static void C_ccall f_8894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9092)
static void C_ccall f_9092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9088)
static void C_ccall f_9088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9055)
static void C_ccall f_9055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9063)
static void C_ccall f_9063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8897)
static void C_ccall f_8897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8903)
static void C_ccall f_8903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8915)
static void C_ccall f_8915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8981)
static void C_fcall f_8981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8996)
static void C_ccall f_8996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8918)
static void C_fcall f_8918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8952)
static void C_fcall f_8952(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8921)
static void C_ccall f_8921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8950)
static void C_ccall f_8950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8946)
static void C_ccall f_8946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8640)
static void C_ccall f_8640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8670)
static void C_ccall f_8670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8770)
static void C_fcall f_8770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8793)
static void C_fcall f_8793(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8807)
static void C_ccall f_8807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8811)
static void C_ccall f_8811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8780)
static void C_ccall f_8780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8730)
static void C_ccall f_8730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8734)
static void C_ccall f_8734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8687)
static void C_fcall f_8687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8352)
static void C_ccall f_8352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8359)
static void C_fcall f_8359(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8398)
static void C_fcall f_8398(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8408)
static void C_fcall f_8408(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8539)
static void C_ccall f_8539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8543)
static void C_ccall f_8543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8472)
static void C_ccall f_8472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8468)
static void C_ccall f_8468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8406)
static void C_ccall f_8406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8402)
static void C_ccall f_8402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8234)
static void C_ccall f_8234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8238)
static void C_ccall f_8238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8063)
static void C_ccall f_8063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8177)
static void C_fcall f_8177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8115)
static void C_ccall f_8115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8123)
static void C_ccall f_8123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8119)
static void C_ccall f_8119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8111)
static void C_ccall f_8111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7929)
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7936)
static void C_fcall f_7936(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7988)
static void C_ccall f_7988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7979)
static void C_ccall f_7979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7965)
static void C_ccall f_7965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7977)
static void C_ccall f_7977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7973)
static void C_ccall f_7973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7879)
static void C_ccall f_7879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6841)
static void C_ccall f_6841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6854)
static void C_ccall f_6854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7453)
static void C_ccall f_7453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7675)
static void C_ccall f_7675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7660)
static void C_ccall f_7660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7459)
static void C_ccall f_7459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7464)
static void C_ccall f_7464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7480)
static void C_ccall f_7480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7612)
static void C_ccall f_7612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7483)
static void C_ccall f_7483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7486)
static void C_ccall f_7486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7592)
static void C_ccall f_7592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7516)
static void C_ccall f_7516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7556)
static void C_ccall f_7556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7492)
static void C_ccall f_7492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7514)
static void C_ccall f_7514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7510)
static void C_ccall f_7510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7495)
static void C_ccall f_7495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7506)
static void C_ccall f_7506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7502)
static void C_ccall f_7502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7462)
static void C_ccall f_7462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_fcall f_6995(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7014)
static void C_fcall f_7014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7115)
static void C_ccall f_7115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7222)
static void C_ccall f_7222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7369)
static void C_ccall f_7369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7372)
static void C_ccall f_7372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7375)
static void C_ccall f_7375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7412)
static void C_ccall f_7412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7397)
static void C_ccall f_7397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7393)
static void C_ccall f_7393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7385)
static void C_ccall f_7385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7225)
static void C_ccall f_7225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7234)
static void C_fcall f_7234(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7363)
static void C_ccall f_7363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7332)
static void C_ccall f_7332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7311)
static void C_ccall f_7311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7292)
static void C_ccall f_7292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7280)
static void C_ccall f_7280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7255)
static void C_ccall f_7255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7250)
static void C_ccall f_7250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7126)
static void C_fcall f_7126(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7212)
static void C_ccall f_7212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7138)
static void C_fcall f_7138(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7180)
static void C_ccall f_7180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7041)
static void C_ccall f_7041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_fcall f_7046(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6908)
static void C_fcall f_6908(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6936)
static void C_ccall f_6936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6939)
static void C_ccall f_6939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6978)
static void C_ccall f_6978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6940)
static void C_ccall f_6940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6944)
static void C_ccall f_6944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6947)
static void C_ccall f_6947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6951)
static void C_ccall f_6951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6954)
static void C_ccall f_6954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6958)
static void C_ccall f_6958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6965)
static void C_ccall f_6965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6918)
static void C_ccall f_6918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6865)
static void C_fcall f_6865(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6878)
static void C_ccall f_6878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6885)
static void C_ccall f_6885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6856)
static void C_ccall f_6856(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6860)
static void C_ccall f_6860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6549)
static void C_ccall f_6549(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6801)
static void C_ccall f_6801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_fcall f_6714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6795)
static void C_ccall f_6795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6720)
static void C_fcall f_6720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6766)
static void C_ccall f_6766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6739)
static void C_ccall f_6739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6682)
static void C_fcall f_6682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6685)
static void C_ccall f_6685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6815)
static void C_fcall f_6815(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6819)
static void C_ccall f_6819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_ccall f_6822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6588)
static void C_ccall f_6588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6652)
static void C_ccall f_6652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6619)
static void C_ccall f_6619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6562)
static void C_ccall f_6562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6499)
static void C_fcall f_6499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6490)
static void C_fcall f_6490(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6087)
static void C_fcall f_6087(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6218)
static void C_fcall f_6218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6223)
static void C_fcall f_6223(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6461)
static void C_ccall f_6461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6424)
static void C_ccall f_6424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6242)
static void C_fcall f_6242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6247)
static void C_fcall f_6247(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6266)
static void C_ccall f_6266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6189)
static void C_ccall f_6189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6195)
static C_word C_fcall f_6195(C_word t0);
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6145)
static void C_fcall f_6145(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6165)
static void C_ccall f_6165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_fcall f_6090(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6097)
static void C_ccall f_6097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6102)
static void C_fcall f_6102(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static void C_ccall f_6131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6120)
static void C_ccall f_6120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6124)
static void C_ccall f_6124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6046)
static void C_ccall f_6046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6031)
static void C_ccall f_6031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_fcall f_5971(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_fcall f_5885(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5966)
static void C_ccall f_5966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5888)
static void C_fcall f_5888(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_fcall f_5575(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5581)
static void C_fcall f_5581(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_fcall f_5603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5747)
static void C_ccall f_5747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_fcall f_5626(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5722)
static void C_ccall f_5722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5684)
static void C_ccall f_5684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5398)
static void C_fcall f_5398(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5408)
static void C_fcall f_5408(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5454)
static void C_fcall f_5454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5472)
static void C_fcall f_5472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_ccall f_5431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_fcall f_5138(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5376)
static void C_ccall f_5376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5150)
static void C_fcall f_5150(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5239)
static void C_ccall f_5239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5232)
static void C_ccall f_5232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5173)
static void C_fcall f_5173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5184)
static void C_ccall f_5184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_fcall f_4579(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_fcall f_5069(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_fcall f_4988(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_fcall f_4942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_fcall f_4945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4905)
static void C_fcall f_4905(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_fcall f_4867(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_fcall f_4801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_fcall f_4597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4609)
static void C_fcall f_4609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4600)
static void C_fcall f_4600(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_fcall f_4545(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4505)
static void C_fcall f_4505(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4524)
static void C_fcall f_4524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_fcall f_4455(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4359)
static void C_fcall f_4359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_fcall f_4161(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4263)
static void C_fcall f_4263(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4269)
static void C_ccall f_4269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_fcall f_4038(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_fcall f_4098(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_fcall f_4110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_fcall f_3859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_fcall f_3897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3914)
static void C_fcall f_3914(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3933)
static void C_fcall f_3933(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_fcall f_3894(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3810)
static void C_fcall f_3810(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3772)
static void C_ccall f_3772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_fcall f_3557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3508)
static void C_fcall f_3508(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_fcall f_3518(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_fcall f_3490(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

C_noret_decl(trf_13329)
static void C_fcall trf_13329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13329(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13329(t0,t1,t2);}

C_noret_decl(trf_12867)
static void C_fcall trf_12867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12867(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12867(t0,t1,t2);}

C_noret_decl(trf_12713)
static void C_fcall trf_12713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12713(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12713(t0,t1,t2);}

C_noret_decl(trf_12616)
static void C_fcall trf_12616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12616(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12616(t0,t1,t2);}

C_noret_decl(trf_12483)
static void C_fcall trf_12483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12483(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12483(t0,t1);}

C_noret_decl(trf_12499)
static void C_fcall trf_12499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12499(t0,t1);}

C_noret_decl(trf_12315)
static void C_fcall trf_12315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12315(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12315(t0,t1,t2);}

C_noret_decl(trf_12046)
static void C_fcall trf_12046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12046(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12046(t0,t1,t2,t3);}

C_noret_decl(trf_12036)
static void C_fcall trf_12036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12036(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12036(t0,t1,t2,t3);}

C_noret_decl(trf_11885)
static void C_fcall trf_11885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11885(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11885(t0,t1,t2);}

C_noret_decl(trf_11735)
static void C_fcall trf_11735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11735(t0,t1,t2);}

C_noret_decl(trf_11725)
static void C_fcall trf_11725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11725(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11725(t0,t1,t2);}

C_noret_decl(trf_11491)
static void C_fcall trf_11491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11491(t0,t1);}

C_noret_decl(trf_11430)
static void C_fcall trf_11430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11430(t0,t1);}

C_noret_decl(trf_11379)
static void C_fcall trf_11379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11379(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11379(t0,t1,t2);}

C_noret_decl(trf_11313)
static void C_fcall trf_11313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11313(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11313(t0,t1,t2);}

C_noret_decl(trf_11164)
static void C_fcall trf_11164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11164(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11164(t0,t1,t2);}

C_noret_decl(trf_11215)
static void C_fcall trf_11215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11215(t0,t1);}

C_noret_decl(trf_11227)
static void C_fcall trf_11227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11227(t0,t1);}

C_noret_decl(trf_10850)
static void C_fcall trf_10850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10850(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10850(t0,t1,t2);}

C_noret_decl(trf_10878)
static void C_fcall trf_10878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10878(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10878(t0,t1);}

C_noret_decl(trf_10360)
static void C_fcall trf_10360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10360(t0,t1);}

C_noret_decl(trf_10368)
static void C_fcall trf_10368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10368(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10368(t0,t1);}

C_noret_decl(trf_10268)
static void C_fcall trf_10268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10268(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10268(t0,t1);}

C_noret_decl(trf_10287)
static void C_fcall trf_10287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10287(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10287(t0,t1,t2);}

C_noret_decl(trf_9992)
static void C_fcall trf_9992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9992(t0,t1);}

C_noret_decl(trf_10073)
static void C_fcall trf_10073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10073(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10073(t0,t1,t2);}

C_noret_decl(trf_10102)
static void C_fcall trf_10102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10102(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10102(t0,t1,t2);}

C_noret_decl(trf_10050)
static void C_fcall trf_10050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10050(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10050(t0,t1,t2,t3);}

C_noret_decl(trf_9946)
static void C_fcall trf_9946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9946(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9946(t0,t1);}

C_noret_decl(trf_9656)
static void C_fcall trf_9656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9656(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9656(t0,t1,t2,t3);}

C_noret_decl(trf_9425)
static void C_fcall trf_9425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9425(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9425(t0,t1,t2);}

C_noret_decl(trf_9345)
static void C_fcall trf_9345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9345(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9345(t0,t1,t2);}

C_noret_decl(trf_9352)
static void C_fcall trf_9352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9352(t0,t1);}

C_noret_decl(trf_9187)
static void C_fcall trf_9187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9187(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9187(t0,t1);}

C_noret_decl(trf_8981)
static void C_fcall trf_8981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8981(t0,t1);}

C_noret_decl(trf_8918)
static void C_fcall trf_8918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8918(t0,t1);}

C_noret_decl(trf_8952)
static void C_fcall trf_8952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8952(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8952(t0,t1,t2,t3);}

C_noret_decl(trf_8770)
static void C_fcall trf_8770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8770(t0,t1);}

C_noret_decl(trf_8793)
static void C_fcall trf_8793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8793(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8793(t0,t1,t2);}

C_noret_decl(trf_8687)
static void C_fcall trf_8687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8687(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8687(t0,t1);}

C_noret_decl(trf_8359)
static void C_fcall trf_8359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8359(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8359(t0,t1);}

C_noret_decl(trf_8398)
static void C_fcall trf_8398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8398(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8398(t0,t1);}

C_noret_decl(trf_8408)
static void C_fcall trf_8408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8408(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8408(t0,t1,t2);}

C_noret_decl(trf_8177)
static void C_fcall trf_8177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8177(t0,t1);}

C_noret_decl(trf_7936)
static void C_fcall trf_7936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7936(t0,t1);}

C_noret_decl(trf_6995)
static void C_fcall trf_6995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6995(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6995(t0,t1,t2);}

C_noret_decl(trf_7014)
static void C_fcall trf_7014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7014(t0,t1);}

C_noret_decl(trf_7234)
static void C_fcall trf_7234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7234(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7234(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7126)
static void C_fcall trf_7126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7126(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7126(t0,t1,t2,t3);}

C_noret_decl(trf_7138)
static void C_fcall trf_7138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7138(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7138(t0,t1,t2,t3);}

C_noret_decl(trf_7046)
static void C_fcall trf_7046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7046(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7046(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6908)
static void C_fcall trf_6908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6908(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6908(t0,t1,t2);}

C_noret_decl(trf_6865)
static void C_fcall trf_6865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6865(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6865(t0,t1,t2);}

C_noret_decl(trf_6714)
static void C_fcall trf_6714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6714(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6714(t0,t1);}

C_noret_decl(trf_6720)
static void C_fcall trf_6720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6720(t0,t1);}

C_noret_decl(trf_6682)
static void C_fcall trf_6682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6682(t0,t1);}

C_noret_decl(trf_6815)
static void C_fcall trf_6815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6815(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6815(t0,t1,t2,t3);}

C_noret_decl(trf_6499)
static void C_fcall trf_6499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6499(t0,t1);}

C_noret_decl(trf_6490)
static void C_fcall trf_6490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6490(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6490(t0,t1,t2);}

C_noret_decl(trf_6087)
static void C_fcall trf_6087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6087(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6087(t0,t1,t2,t3);}

C_noret_decl(trf_6218)
static void C_fcall trf_6218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6218(t0,t1);}

C_noret_decl(trf_6223)
static void C_fcall trf_6223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6223(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6223(t0,t1,t2,t3);}

C_noret_decl(trf_6242)
static void C_fcall trf_6242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6242(t0,t1);}

C_noret_decl(trf_6247)
static void C_fcall trf_6247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6247(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6247(t0,t1,t2,t3);}

C_noret_decl(trf_6145)
static void C_fcall trf_6145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6145(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6145(t0,t1,t2);}

C_noret_decl(trf_6090)
static void C_fcall trf_6090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6090(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6090(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6102)
static void C_fcall trf_6102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6102(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6102(t0,t1,t2);}

C_noret_decl(trf_5971)
static void C_fcall trf_5971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5971(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5971(t0,t1,t2,t3);}

C_noret_decl(trf_5885)
static void C_fcall trf_5885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5885(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5885(t0,t1,t2,t3);}

C_noret_decl(trf_5888)
static void C_fcall trf_5888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5888(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5888(t0,t1,t2,t3);}

C_noret_decl(trf_5575)
static void C_fcall trf_5575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5575(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5575(t0,t1,t2);}

C_noret_decl(trf_5581)
static void C_fcall trf_5581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5581(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5581(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5603)
static void C_fcall trf_5603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5603(t0,t1);}

C_noret_decl(trf_5626)
static void C_fcall trf_5626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5626(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5626(t0,t1,t2);}

C_noret_decl(trf_5398)
static void C_fcall trf_5398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5398(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5398(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5408)
static void C_fcall trf_5408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5408(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5408(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5454)
static void C_fcall trf_5454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5454(t0,t1);}

C_noret_decl(trf_5472)
static void C_fcall trf_5472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5472(t0,t1);}

C_noret_decl(trf_5138)
static void C_fcall trf_5138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5138(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5138(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5150)
static void C_fcall trf_5150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5150(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5150(t0,t1,t2,t3);}

C_noret_decl(trf_5173)
static void C_fcall trf_5173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5173(t0,t1);}

C_noret_decl(trf_4579)
static void C_fcall trf_4579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4579(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4579(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5069)
static void C_fcall trf_5069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5069(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5069(t0,t1);}

C_noret_decl(trf_4988)
static void C_fcall trf_4988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4988(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4988(t0,t1);}

C_noret_decl(trf_4942)
static void C_fcall trf_4942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4942(t0,t1);}

C_noret_decl(trf_4945)
static void C_fcall trf_4945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4945(t0,t1);}

C_noret_decl(trf_4905)
static void C_fcall trf_4905(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4905(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4905(t0,t1);}

C_noret_decl(trf_4867)
static void C_fcall trf_4867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4867(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4867(t0,t1);}

C_noret_decl(trf_4801)
static void C_fcall trf_4801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4801(t0,t1);}

C_noret_decl(trf_4597)
static void C_fcall trf_4597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4597(t0,t1);}

C_noret_decl(trf_4609)
static void C_fcall trf_4609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4609(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4609(t0,t1);}

C_noret_decl(trf_4600)
static void C_fcall trf_4600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4600(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4600(t0,t1);}

C_noret_decl(trf_4545)
static void C_fcall trf_4545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4545(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4545(t0,t1,t2);}

C_noret_decl(trf_4505)
static void C_fcall trf_4505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4505(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4505(t0,t1,t2);}

C_noret_decl(trf_4524)
static void C_fcall trf_4524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4524(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4524(t0,t1);}

C_noret_decl(trf_4455)
static void C_fcall trf_4455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4455(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4455(t0,t1,t2);}

C_noret_decl(trf_4359)
static void C_fcall trf_4359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4359(t0,t1,t2);}

C_noret_decl(trf_4161)
static void C_fcall trf_4161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4161(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4161(t0,t1);}

C_noret_decl(trf_4263)
static void C_fcall trf_4263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4263(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4263(t0,t1);}

C_noret_decl(trf_4038)
static void C_fcall trf_4038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4038(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4038(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4098)
static void C_fcall trf_4098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4098(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4098(t0,t1);}

C_noret_decl(trf_4110)
static void C_fcall trf_4110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4110(t0,t1);}

C_noret_decl(trf_3859)
static void C_fcall trf_3859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3859(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3859(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3897)
static void C_fcall trf_3897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3897(t0,t1);}

C_noret_decl(trf_3914)
static void C_fcall trf_3914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3914(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3914(t0,t1,t2);}

C_noret_decl(trf_3933)
static void C_fcall trf_3933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3933(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3933(t0,t1);}

C_noret_decl(trf_3894)
static void C_fcall trf_3894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3894(t0,t1);}

C_noret_decl(trf_3810)
static void C_fcall trf_3810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3810(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3810(t0,t1,t2);}

C_noret_decl(trf_3557)
static void C_fcall trf_3557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3557(t0,t1);}

C_noret_decl(trf_3508)
static void C_fcall trf_3508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3508(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3508(t0,t1,t2);}

C_noret_decl(trf_3518)
static void C_fcall trf_3518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3518(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3518(t0,t1);}

C_noret_decl(trf_3490)
static void C_fcall trf_3490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3490(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3490(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_expand_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("expand_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3764)){
C_save(t1);
C_rereclaim2(3764*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,392);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],12,"\003sysfeatures");
lf[4]=C_h_intern(&lf[4],2,"pp");
lf[5]=C_h_intern(&lf[5],5,"print");
lf[8]=C_h_intern(&lf[8],23,"\003syscurrent-environment");
lf[9]=C_h_intern(&lf[9],28,"\003syscurrent-meta-environment");
lf[11]=C_h_intern(&lf[11],7,"\003sysget");
lf[12]=C_h_intern(&lf[12],16,"\004coremacro-alias");
lf[14]=C_h_intern(&lf[14],7,"<macro>");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\011aliasing ");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\004 to ");
lf[17]=C_h_intern(&lf[17],8,"\003sysput!");
lf[18]=C_h_intern(&lf[18],6,"gensym");
lf[19]=C_h_intern(&lf[19],21,"\003sysqualified-symbol\077");
lf[21]=C_h_intern(&lf[21],7,"\003sysmap");
lf[22]=C_h_intern(&lf[22],16,"\003sysstrip-syntax");
lf[23]=C_h_intern(&lf[23],3,"get");
lf[24]=C_h_intern(&lf[24],12,"list->vector");
lf[25]=C_h_intern(&lf[25],12,"vector->list");
lf[26]=C_h_intern(&lf[26],9,"\003syserror");
lf[27]=C_h_intern(&lf[27],12,"strip-syntax");
lf[28]=C_h_intern(&lf[28],21,"\003sysmacro-environment");
lf[29]=C_h_intern(&lf[29],29,"\003syschicken-macro-environment");
lf[30]=C_h_intern(&lf[30],33,"\003syschicken-ffi-macro-environment");
lf[31]=C_h_intern(&lf[31],28,"\003sysextend-macro-environment");
lf[32]=C_h_intern(&lf[32],14,"\003syscopy-macro");
lf[33]=C_h_intern(&lf[33],6,"macro\077");
lf[34]=C_h_intern(&lf[34],20,"\003sysunregister-macro");
lf[35]=C_h_intern(&lf[35],4,"caar");
lf[36]=C_h_intern(&lf[36],15,"undefine-macro!");
lf[37]=C_h_intern(&lf[37],12,"\003sysexpand-0");
lf[38]=C_h_intern(&lf[38],9,"\003sysabort");
lf[39]=C_h_intern(&lf[39],9,"condition");
lf[40]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[41]=C_h_intern(&lf[41],13,"string-append");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[44]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[45]=C_h_intern(&lf[45],3,"exn");
lf[46]=C_h_intern(&lf[46],3,"-->");
lf[47]=C_h_intern(&lf[47],22,"with-exception-handler");
lf[48]=C_h_intern(&lf[48],30,"call-with-current-continuation");
lf[49]=C_h_intern(&lf[49],10,"\000STATIC-SE");
lf[50]=C_h_intern(&lf[50],10,"\003sysappend");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\020invoking macro: ");
lf[52]=C_h_intern(&lf[52],21,"\003syssyntax-error-hook");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[54]=C_h_intern(&lf[54],7,"\000EXPAND");
lf[55]=C_h_intern(&lf[55],3,"\000SE");
lf[56]=C_h_intern(&lf[56],1,"_");
lf[57]=C_h_intern(&lf[57],3,"let");
lf[58]=C_h_intern(&lf[58],8,"\004corelet");
lf[59]=C_h_intern(&lf[59],16,"\004coreloop-lambda");
lf[60]=C_h_intern(&lf[60],11,"\004coreletrec");
lf[61]=C_h_intern(&lf[61],8,"\004coreapp");
lf[62]=C_h_intern(&lf[62],4,"cadr");
lf[63]=C_h_intern(&lf[63],16,"\003syscheck-syntax");
lf[64]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[65]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[66]=C_h_intern(&lf[66],10,"\003syssetter");
lf[67]=C_h_intern(&lf[67],6,"append");
lf[68]=C_h_intern(&lf[68],4,"set!");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[70]=C_h_intern(&lf[70],9,"\004coreset!");
lf[71]=C_h_intern(&lf[71],25,"\003sysenable-runtime-macros");
lf[72]=C_h_intern(&lf[72],17,"\003sysmodule-rename");
lf[73]=C_h_intern(&lf[73],18,"\003sysstring->symbol");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[75]=C_h_intern(&lf[75],21,"\003sysalias-global-hook");
lf[77]=C_h_intern(&lf[77],22,"\003sysregister-undefined");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\025(ALIAS) global alias ");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[80]=C_h_intern(&lf[80],18,"\003syscurrent-module");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\023(ALIAS) primitive: ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\020(ALIAS) marked: ");
lf[83]=C_h_intern(&lf[83],14,"\004coreprimitive");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000 (ALIAS) in current environment: ");
lf[85]=C_h_intern(&lf[85],12,"\004corealiased");
lf[86]=C_h_intern(&lf[86],10,"\003sysexpand");
lf[87]=C_h_intern(&lf[87],6,"expand");
lf[88]=C_h_intern(&lf[88],25,"\003sysextended-lambda-list\077");
lf[89]=C_h_intern(&lf[89],6,"#!rest");
lf[90]=C_h_intern(&lf[90],10,"#!optional");
lf[91]=C_h_intern(&lf[91],5,"#!key");
lf[92]=C_h_intern(&lf[92],7,"reverse");
lf[93]=C_h_intern(&lf[93],31,"\003sysexpand-extended-lambda-list");
lf[94]=C_h_intern(&lf[94],5,"cadar");
lf[95]=C_h_intern(&lf[95],5,"quote");
lf[96]=C_h_intern(&lf[96],15,"\003sysget-keyword");
lf[97]=C_h_intern(&lf[97],11,"\004corelambda");
lf[98]=C_h_intern(&lf[98],15,"string->keyword");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[101]=C_h_intern(&lf[101],3,"tmp");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[110]=C_h_intern(&lf[110],14,"let-optionals*");
lf[111]=C_h_intern(&lf[111],13,"let-optionals");
lf[112]=C_h_intern(&lf[112],8,"optional");
lf[113]=C_h_intern(&lf[113],4,"let*");
lf[114]=C_h_intern(&lf[114],3,"map");
lf[115]=C_h_intern(&lf[115],21,"\003syscanonicalize-body");
lf[116]=C_h_intern(&lf[116],5,"begin");
lf[117]=C_h_intern(&lf[117],6,"define");
lf[118]=C_h_intern(&lf[118],13,"define-values");
lf[119]=C_h_intern(&lf[119],5,"\000BODY");
lf[120]=C_h_intern(&lf[120],20,"\003syscall-with-values");
lf[121]=C_h_intern(&lf[121],14,"\004coreundefined");
lf[122]=C_h_intern(&lf[122],3,"cdr");
lf[123]=C_h_intern(&lf[123],13,"letrec-syntax");
lf[124]=C_h_intern(&lf[124],13,"define-syntax");
lf[125]=C_h_intern(&lf[125],5,"cdadr");
lf[126]=C_h_intern(&lf[126],6,"lambda");
lf[127]=C_h_intern(&lf[127],5,"caadr");
lf[128]=C_h_intern(&lf[128],25,"\003sysexpand-curried-define");
lf[129]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[132]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-syntax\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[138]=C_h_intern(&lf[138],24,"\003sysline-number-database");
lf[139]=C_h_intern(&lf[139],24,"\003syssyntax-error-culprit");
lf[140]=C_h_intern(&lf[140],15,"\003syssignal-hook");
lf[141]=C_h_intern(&lf[141],13,"\000syntax-error");
lf[142]=C_h_intern(&lf[142],12,"syntax-error");
lf[143]=C_h_intern(&lf[143],15,"get-line-number");
lf[144]=C_h_intern(&lf[144],18,"\003syshash-table-ref");
lf[145]=C_h_intern(&lf[145],8,"keyword\077");
lf[146]=C_h_intern(&lf[146],14,"symbol->string");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[156]=C_h_intern(&lf[156],4,"pair");
lf[157]=C_h_intern(&lf[157],5,"pair\077");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[159]=C_h_intern(&lf[159],8,"variable");
lf[160]=C_h_intern(&lf[160],7,"symbol\077");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[162]=C_h_intern(&lf[162],6,"symbol");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[164]=C_h_intern(&lf[164],4,"list");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[166]=C_h_intern(&lf[166],6,"number");
lf[167]=C_h_intern(&lf[167],7,"number\077");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[169]=C_h_intern(&lf[169],6,"string");
lf[170]=C_h_intern(&lf[170],7,"string\077");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[172]=C_h_intern(&lf[172],11,"lambda-list");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[177]=C_h_intern(&lf[177],18,"\003syser-transformer");
lf[178]=C_h_intern(&lf[178],12,"\000RENAME/RENV");
lf[179]=C_h_intern(&lf[179],14,"\000RENAME/LOOKUP");
lf[180]=C_h_intern(&lf[180],20,"\000RENAME/LOOKUP/MACRO");
lf[181]=C_h_intern(&lf[181],7,"\000RENAME");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\016  (lookup/DSE ");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\005 --> ");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[186]=C_h_intern(&lf[186],8,"\000COMPARE");
lf[187]=C_h_intern(&lf[187],17,"\003sysexpand-import");
lf[188]=C_h_intern(&lf[188],17,"\003sysstring-append");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[190]=C_h_intern(&lf[190],18,"\003syssymbol->string");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid prefix");
lf[194]=C_h_intern(&lf[194],15,"\003sysfind-module");
lf[195]=C_h_intern(&lf[195],8,"\003sysload");
lf[196]=C_h_intern(&lf[196],16,"\003sysdynamic-wind");
lf[197]=C_h_intern(&lf[197],26,"\003sysmeta-macro-environment");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000$can not import from undefined module");
lf[199]=C_h_intern(&lf[199],18,"\003sysfind-extension");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\007.import");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[204]=C_h_intern(&lf[204],8,"\003syswarn");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\037renamed identifier not imported");
lf[206]=C_h_intern(&lf[206],12,"\003sysfor-each");
lf[207]=C_h_intern(&lf[207],8,"\003sysdelq");
lf[208]=C_h_intern(&lf[208],4,"cdar");
lf[209]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000");
lf[210]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[212]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000&re-importing already imported syntax: ");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000)re-importing already imported identfier: ");
lf[215]=C_h_intern(&lf[215],25,"\003sysmark-imported-symbols");
lf[216]=C_h_intern(&lf[216],10,"<toplevel>");
lf[217]=C_h_intern(&lf[217],2,"\000S");
lf[218]=C_h_intern(&lf[218],2,"\000V");
lf[219]=C_h_intern(&lf[219],7,"\000IMPORT");
lf[220]=C_h_intern(&lf[220],6,"module");
lf[221]=C_h_intern(&lf[221],14,"\003sysblock-set!");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[225]=C_h_intern(&lf[225],6,"prefix");
lf[226]=C_h_intern(&lf[226],6,"except");
lf[227]=C_h_intern(&lf[227],6,"rename");
lf[228]=C_h_intern(&lf[228],4,"only");
lf[229]=C_h_intern(&lf[229],29,"\003sysinitial-macro-environment");
lf[230]=C_h_intern(&lf[230],24,"\003sysprocess-syntax-rules");
lf[231]=C_h_intern(&lf[231],7,"\003syscar");
lf[232]=C_h_intern(&lf[232],7,"\003syscdr");
lf[233]=C_h_intern(&lf[233],11,"\003sysvector\077");
lf[234]=C_h_intern(&lf[234],17,"\003sysvector-length");
lf[235]=C_h_intern(&lf[235],14,"\003sysvector-ref");
lf[236]=C_h_intern(&lf[236],16,"\003sysvector->list");
lf[237]=C_h_intern(&lf[237],16,"\003syslist->vector");
lf[238]=C_h_intern(&lf[238],6,"\003sys>=");
lf[239]=C_h_intern(&lf[239],5,"\003sys=");
lf[240]=C_h_intern(&lf[240],5,"\003sys+");
lf[241]=C_h_intern(&lf[241],8,"\003syscons");
lf[242]=C_h_intern(&lf[242],7,"\003syseq\077");
lf[243]=C_h_intern(&lf[243],10,"\003sysequal\077");
lf[244]=C_h_intern(&lf[244],9,"\003syslist\077");
lf[245]=C_h_intern(&lf[245],9,"\003sysmap-n");
lf[246]=C_h_intern(&lf[246],9,"\003sysnull\077");
lf[247]=C_h_intern(&lf[247],9,"\003syspair\077");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\026ill-formed syntax rule");
lf[250]=C_h_intern(&lf[250],6,"syntax");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000,template dimension error (too few ellipses\077)");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\021too many ellipses");
lf[253]=C_h_intern(&lf[253],9,"\003sysapply");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000 segment matching not implemented");
lf[255]=C_h_intern(&lf[255],4,"temp");
lf[256]=C_h_intern(&lf[256],4,"tail");
lf[257]=C_h_intern(&lf[257],2,"or");
lf[258]=C_h_intern(&lf[258],4,"loop");
lf[259]=C_h_intern(&lf[259],1,"l");
lf[260]=C_h_intern(&lf[260],5,"input");
lf[261]=C_h_intern(&lf[261],4,"else");
lf[262]=C_h_intern(&lf[262],4,"cond");
lf[263]=C_h_intern(&lf[263],7,"compare");
lf[264]=C_h_intern(&lf[264],1,"i");
lf[265]=C_h_intern(&lf[265],3,"and");
lf[266]=C_h_intern(&lf[266],29,"\003sysdefault-macro-environment");
lf[273]=C_h_intern(&lf[273],26,"set-module-undefined-list!");
lf[274]=C_h_intern(&lf[274],21,"module-undefined-list");
lf[277]=C_h_intern(&lf[277],16,"\003sysmodule-table");
lf[278]=C_h_intern(&lf[278],5,"error");
lf[279]=C_h_intern(&lf[279],6,"import");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\020module not found");
lf[281]=C_h_intern(&lf[281],28,"\003systoplevel-definition-hook");
lf[282]=C_h_intern(&lf[282],28,"\003sysregister-meta-expression");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\047redefinition of imported syntax binding");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000&redefinition of imported value binding");
lf[286]=C_h_intern(&lf[286],19,"\003sysregister-export");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\011defined: ");
lf[288]=C_h_intern(&lf[288],15,"\003sysfind-export");
lf[289]=C_h_intern(&lf[289],26,"\003sysregister-syntax-export");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\020defined syntax: ");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000!use of syntax precedes definition");
lf[292]=C_h_intern(&lf[292],19,"\003sysregister-module");
lf[293]=C_h_intern(&lf[293],8,"\000MARKING");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\014 in module `");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000!indirect export of syntax binding");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\033indirect reexport of syntax");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\042indirect export of unknown binding");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\024  merged has length ");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\010merging ");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\033 se\047s with total length of ");
lf[304]=C_h_intern(&lf[304],32,"\003syscompiled-module-registration");
lf[305]=C_h_intern(&lf[305],28,"\003sysregister-compiled-module");
lf[306]=C_h_intern(&lf[306],4,"cons");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000((internal) exported syntax has no source");
lf[308]=C_h_intern(&lf[308],4,"eval");
lf[309]=C_h_intern(&lf[309],29,"\003sysregister-primitive-module");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\0001unknown macro referenced while registering module");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\002#%");
lf[312]=C_h_intern(&lf[312],18,"module-exists-list");
lf[313]=C_h_intern(&lf[313],19,"\003sysfinalize-module");
lf[314]=C_h_intern(&lf[314],6,"\000DLIST");
lf[315]=C_h_intern(&lf[315],7,"\000SDLIST");
lf[316]=C_h_intern(&lf[316],9,"\000IEXPORTS");
lf[317]=C_h_intern(&lf[317],9,"\000VEXPORTS");
lf[318]=C_h_intern(&lf[318],9,"\000SEXPORTS");
lf[319]=C_h_intern(&lf[319],8,"\000EXPORTS");
lf[320]=C_h_intern(&lf[320],6,"\000FIXUP");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000$(internal) indirect export not found");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000(reference to possibly unbound identifier");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\015reexporting: ");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000 exported identifier for module `");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026\047 has not been defined");
lf[327]=C_h_intern(&lf[327],16,"\003sysmacro-subset");
lf[328]=C_h_intern(&lf[328],14,"make-parameter");
lf[329]=C_h_intern(&lf[329],12,"syntax-rules");
lf[330]=C_h_intern(&lf[330],3,"...");
lf[331]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[332]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[333]=C_h_intern(&lf[333],6,"export");
lf[334]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000!`export\047 used outside module body");
lf[337]=C_h_intern(&lf[337],16,"begin-for-syntax");
lf[338]=C_h_intern(&lf[338],24,"\004coreelaborationtimeonly");
lf[339]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[340]=C_h_intern(&lf[340],11,"\004coremodule");
lf[341]=C_h_intern(&lf[341],1,"*");
lf[342]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[343]=C_h_intern(&lf[343],17,"require-extension");
lf[344]=C_h_intern(&lf[344],22,"\004corerequire-extension");
lf[345]=C_h_intern(&lf[345],15,"require-library");
lf[346]=C_h_intern(&lf[346],11,"cond-expand");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[348]=C_h_intern(&lf[348],12,"\003sysfeature\077");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[351]=C_h_intern(&lf[351],3,"not");
lf[352]=C_h_intern(&lf[352],5,"delay");
lf[353]=C_h_intern(&lf[353],16,"\003sysmake-promise");
lf[354]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[355]=C_h_intern(&lf[355],10,"quasiquote");
lf[356]=C_h_intern(&lf[356],8,"\003syslist");
lf[357]=C_h_intern(&lf[357],17,"%unquote-splicing");
lf[358]=C_h_intern(&lf[358],1,"a");
lf[359]=C_h_intern(&lf[359],1,"b");
lf[360]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[365]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[366]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[367]=C_h_intern(&lf[367],16,"unquote-splicing");
lf[368]=C_h_intern(&lf[368],7,"unquote");
lf[369]=C_h_intern(&lf[369],2,"do");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[371]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[372]=C_h_intern(&lf[372],2,"if");
lf[373]=C_h_intern(&lf[373],6,"doloop");
lf[374]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001"
"\000\000\000\001");
lf[375]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[376]=C_h_intern(&lf[376],4,"case");
lf[377]=C_h_intern(&lf[377],8,"\003syseqv\077");
lf[378]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[379]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[380]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[381]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[382]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[383]=C_h_intern(&lf[383],2,"=>");
lf[384]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[385]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[386]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[387]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[388]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[389]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[390]=C_h_intern(&lf[390],17,"import-for-syntax");
lf[391]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\020\000hygienic-macros\376\003\000\000\002\376\001\000\000\015\000syntax-rules\376\377\016");
C_register_lf2(lf,392,create_ptable());
t2=C_mutate(&lf[0] /* (set! c102 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3457,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 38   append */
t4=*((C_word*)lf[67]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[391],*((C_word*)lf[2]+1));}

/* k3455 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! features ...) */,t1);
t3=C_mutate(&lf[3] /* (set! d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3459,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[6] /* (set! dd ...) */,C_retrieve2(lf[3],"d"));
t5=C_mutate(&lf[7] /* (set! dm ...) */,C_retrieve2(lf[3],"d"));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 66   make-parameter */
t7=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_END_OF_LIST);}

/* k3482 in k3455 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3484,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1 /* (set! current-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3488,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 67   make-parameter */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_END_OF_LIST);}

/* k3486 in k3482 in k3455 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* (set! current-meta-environment ...) */,t1);
t3=C_mutate(&lf[10] /* (set! lookup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3490,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[13] /* (set! macro-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3508,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[20] /* (set! map-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3557,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[22]+1 /* (set! strip-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3587,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[27]+1 /* (set! strip-syntax ...) */,C_retrieve(lf[22]));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3690,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 117  make-parameter */
t9=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_END_OF_LIST);}

/* k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3690,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! macro-environment ...) */,t1);
t3=C_set_block_item(lf[29] /* chicken-macro-environment */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[30] /* chicken-ffi-macro-environment */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[31]+1 /* (set! extend-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3694,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[32]+1 /* (set! copy-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3727,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[33]+1 /* (set! macro? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3740,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[34]+1 /* (set! unregister-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3796,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[36]+1 /* (set! undefine-macro! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3847,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[37]+1 /* (set! expand-0 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3856,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(lf[71] /* enable-runtime-macros */,0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[72]+1 /* (set! module-rename ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4338,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[75]+1 /* (set! alias-global-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4356,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[86]+1 /* (set! expand ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4446,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[87]+1 /* (set! expand ...) */,C_retrieve(lf[86]));
t16=C_mutate((C_word*)lf[88]+1 /* (set! extended-lambda-list? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4499,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[92]+1);
t18=C_retrieve(lf[18]);
t19=C_mutate((C_word*)lf[93]+1 /* (set! expand-extended-lambda-list ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4542,a[2]=t17,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[92]+1);
t21=*((C_word*)lf[114]+1);
t22=C_mutate((C_word*)lf[115]+1 /* (set! canonicalize-body ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5132,a[2]=t21,a[3]=t20,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate(&lf[137] /* (set! match-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5885,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[128]+1 /* (set! expand-curried-define ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5968,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(lf[138] /* line-number-database */,0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[139] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
t27=C_mutate((C_word*)lf[52]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6038,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[142]+1 /* (set! syntax-error ...) */,C_retrieve(lf[52]));
t29=C_mutate((C_word*)lf[143]+1 /* (set! get-line-number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6049,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[41]+1);
t31=C_retrieve(lf[145]);
t32=C_retrieve(lf[143]);
t33=*((C_word*)lf[146]+1);
t34=C_mutate((C_word*)lf[63]+1 /* (set! check-syntax ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6085,a[2]=t31,a[3]=t32,a[4]=t33,a[5]=t30,a[6]=((C_word)li68),tmp=(C_word)a,a+=7,tmp));
t35=C_mutate((C_word*)lf[177]+1 /* (set! er-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6547,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[187]+1 /* (set! expand-import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6841,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7686,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13469,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13471,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 865  ##sys#er-transformer */
t40=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t40))(3,t40,t38,t39);}

/* a13470 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13471,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
t5=C_retrieve(lf[187]);
((C_proc9)C_retrieve_proc(t5))(9,t5,t1,t2,t3,t4,C_retrieve(lf[8]),C_retrieve(lf[28]),C_SCHEME_FALSE,lf[279]);}

/* k13467 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 863  ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[279],C_SCHEME_END_OF_LIST,t1);}

/* k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7689,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13459,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13461,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 871  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13460 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13461,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
t5=C_retrieve(lf[187]);
((C_proc9)C_retrieve_proc(t5))(9,t5,t1,t2,t3,t4,C_retrieve(lf[9]),C_retrieve(lf[197]),C_SCHEME_TRUE,lf[390]);}

/* k13457 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 869  ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[390],C_SCHEME_END_OF_LIST,t1);}

/* k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7693,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 875  ##sys#macro-environment */
t3=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7693,2,t0,t1);}
t2=C_mutate((C_word*)lf[229]+1 /* (set! initial-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13317,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13319,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 880  ##sys#er-transformer */
t6=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13319,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13329,a[2]=t3,a[3]=t7,a[4]=((C_word)li196),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_13329(t9,t1,t5);}

/* loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_13329(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13329,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13385,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 891  ##sys#check-syntax */
t7=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[117],t3,lf[385]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13398,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 895  ##sys#check-syntax */
t7=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[117],t3,lf[387]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13345,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 886  ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[117],t3,lf[162]);}}

/* k13343 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 887  ##sys#check-syntax */
t3=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[4],lf[389]);}

/* k13346 in k13343 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13376,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 888  ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k13374 in k13346 in k13343 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 888  ##sys#register-export */
t2=C_retrieve(lf[286]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13349 in k13346 in k13343 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13351,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):lf[388]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[70],t5));}

/* k13396 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 896  ##sys#check-syntax */
t3=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[3],lf[386]);}

/* k13399 in k13396 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13447,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 897  ##sys#current-module */
t5=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k13445 in k13399 in k13396 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 897  ##sys#register-export */
t2=C_retrieve(lf[286]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13402 in k13399 in k13396 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13404,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 900  r */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k13425 in k13402 in k13399 in k13396 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13427,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13437 in k13425 in k13402 in k13399 in k13396 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13439,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[70],t5));}

/* k13383 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 892  ##sys#check-syntax */
t3=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[117],((C_word*)t0)[2],lf[384]);}

/* k13386 in k13383 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13395,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 893  ##sys#expand-curried-define */
t3=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13393 in k13386 in k13383 in loop in a13318 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 893  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_13329(t2,((C_word*)t0)[2],t1);}

/* k13315 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 877  ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[117],C_SCHEME_END_OF_LIST,t1);}

/* k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7699,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13258,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13260,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 905  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13259 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13260,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13289,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 914  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[372]);}}}

/* k13287 in a13259 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13309,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 914  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k13307 in k13287 in a13259 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13311 in k13307 in k13287 in a13259 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13313,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k13256 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 902  ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[265],C_SCHEME_END_OF_LIST,t1);}

/* k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7702,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13168,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13170,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 919  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a13169 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13170,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13195,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 928  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[101]);}}}

/* k13193 in a13169 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 929  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[57]);}

/* k13200 in k13193 in a13169 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13202,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 930  r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[372]);}

/* k13220 in k13200 in k13193 in a13169 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13242,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 930  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13240 in k13220 in k13200 in k13193 in a13169 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13244 in k13240 in k13220 in k13200 in k13193 in a13169 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13246,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k13166 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 916  ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[257],C_SCHEME_END_OF_LIST,t1);}

/* k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7705,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12835,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12837,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 935  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12837,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12844,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 938  r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[116]);}

/* k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 939  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[57]);}

/* k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 940  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[372]);}

/* k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 941  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[383]);}

/* k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 942  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 943  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 944  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[126]);}

/* k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12862,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12867,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word)li192),tmp=(C_word)a,a+=13,tmp));
t5=((C_word*)t3)[1];
f_12867(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_12867(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12867,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_12883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=((C_word*)t0)[11],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* expand.scm: 950  ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[262],t3,lf[381]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[382]);}}

/* k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_12889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* expand.scm: 951  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k12887 in k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12889,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12896,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12925,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 952  expand */
t5=((C_word*)((C_word*)t0)[9])[1];
f_12867(t5,t4,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[11]);
/* expand.scm: 953  c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}}

/* k12929 in k12887 in k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12931,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12934,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 954  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12999,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[12]))){
t3=(C_word)C_i_length(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t3,C_fix(4));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* expand.scm: 960  c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,((C_word*)t0)[2],t5);}
else{
t5=t2;
f_12999(2,t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_12999(2,t3,C_SCHEME_FALSE);}}}

/* k12997 in k12929 in k12887 in k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12999,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13002,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 961  r */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13124,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k13122 in k12997 in k12929 in k12887 in k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13124,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13120,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 970  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12867(t4,t3,((C_word*)t0)[2]);}

/* k13118 in k13122 in k12997 in k12929 in k12887 in k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13120,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k13000 in k12997 in k12929 in k12887 in k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13002,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t10=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[253],t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13057,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t9,a[7]=t13,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 967  expand */
t15=((C_word*)((C_word*)t0)[3])[1];
f_12867(t15,t14,((C_word*)t0)[2]);}

/* k13055 in k13000 in k12997 in k12929 in k12887 in k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_13057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13057,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[372],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[120],t10));}

/* k12932 in k12929 in k12887 in k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12934,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12973,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 958  expand */
t10=((C_word*)((C_word*)t0)[3])[1];
f_12867(t10,t9,((C_word*)t0)[2]);}

/* k12971 in k12932 in k12929 in k12887 in k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12973,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k12923 in k12887 in k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12925,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k12894 in k12887 in k12881 in expand in k12860 in k12857 in k12854 in k12851 in k12848 in k12845 in k12842 in a12836 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12896,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12833 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 932  ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[262],C_SCHEME_END_OF_LIST,t1);}

/* k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7708,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12665,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12667,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 975  ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12667,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12671,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 977  ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[376],t2,lf[380]);}

/* k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12671,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12680,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 980  r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[101]);}

/* k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 981  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 982  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[372]);}

/* k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 983  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12692,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 985  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k12690 in k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12692,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12711,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12713,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word)li190),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_12713(t9,t5,((C_word*)t0)[2]);}

/* expand in k12690 in k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_12713(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12713,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 992  ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[376],t3,lf[378]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[379]);}}

/* k12727 in expand in k12690 in k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12735,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 993  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k12733 in k12727 in expand in k12690 in k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12735,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12742,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12785,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12789,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12791,a[2]=((C_word*)t0)[2],a[3]=((C_word)li189),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 995  ##sys#map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a12790 in k12733 in k12727 in expand in k12690 in k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12791(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12791,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[377],t6));}

/* k12787 in k12733 in k12727 in expand in k12690 in k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k12783 in k12733 in k12727 in expand in k12690 in k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12785,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k12775 in k12783 in k12733 in k12727 in expand in k12690 in k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12777,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12773,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 998  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12713(t4,t3,((C_word*)t0)[2]);}

/* k12771 in k12775 in k12783 in k12733 in k12727 in expand in k12690 in k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12773,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k12740 in k12733 in k12727 in expand in k12690 in k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12742,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12709 in k12690 in k12687 in k12684 in k12681 in k12678 in k12669 in a12666 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12711,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[57],t3));}

/* k12663 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 972  ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[376],C_SCHEME_END_OF_LIST,t1);}

/* k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7711,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12596,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12598,a[2]=((C_word)li188),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1003 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12597 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12598,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12602,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1005 ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[113],t2,lf[375]);}

/* k12600 in a12597 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12602,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12611,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1008 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[57]);}

/* k12609 in k12600 in a12597 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12611,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12616,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li187),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_12616(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k12609 in k12600 in a12597 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_12616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12616,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12634,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12653,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1012 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k12651 in expand in k12609 in k12600 in a12597 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12653,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k12632 in expand in k12609 in k12600 in a12597 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12634,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12594 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1000 ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[113],C_SCHEME_END_OF_LIST,t1);}

/* k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7714,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12414,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12416,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1017 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12416,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12420,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1019 ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[369],t2,lf[374]);}

/* k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12420,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12432,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1023 r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[373]);}

/* k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1024 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[57]);}

/* k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1025 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[372]);}

/* k12436 in k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12441,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1026 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12439 in k12436 in k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12576,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1027 ##sys#map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a12575 in k12439 in k12436 in k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12576(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12576,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k12454 in k12439 in k12436 in k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12456,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_12483(t6,lf[371]);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12574,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,C_SCHEME_END_OF_LIST);}}

/* k12572 in k12454 in k12439 in k12436 in k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12574,2,t0,t1);}
t2=((C_word*)t0)[3];
f_12483(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12481 in k12454 in k12439 in k12436 in k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_12483(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12483,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12499,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_12499(t4,lf[370]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12564,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k12562 in k12481 in k12454 in k12439 in k12436 in k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12564,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_12499(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12497 in k12481 in k12454 in k12439 in k12436 in k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_12499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12499,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12519,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12521,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1038 ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a12520 in k12497 in k12481 in k12454 in k12439 in k12436 in k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12521,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_car(t2));}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t7));}}

/* k12517 in k12497 in k12481 in k12454 in k12439 in k12436 in k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k12513 in k12497 in k12481 in k12454 in k12439 in k12436 in k12433 in k12430 in k12418 in a12415 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12515,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k12412 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1014 ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[369],C_SCHEME_END_OF_LIST,t1);}

/* k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7717,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12019,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12021,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1047 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12021,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12025,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1049 r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[95]);}

/* k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1050 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[355]);}

/* k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1051 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[368]);}

/* k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1052 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[367]);}

/* k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12034,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12036,a[2]=t5,a[3]=t7,a[4]=((C_word)li180),tmp=(C_word)a,a+=5,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12046,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word)li181),tmp=(C_word)a,a+=9,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12315,a[2]=t7,a[3]=((C_word)li182),tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12403,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1102 ##sys#check-syntax */
t12=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[355],((C_word*)t0)[3],lf[366]);}

/* k12401 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1103 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12036(t3,((C_word*)t0)[2],t2,C_fix(0));}

/* simplify in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_12315(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12315,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12319,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1090 match-expression */
f_5885(t3,t2,lf[364],lf[365]);}

/* k12317 in simplify in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12319,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[358],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[356],t4);
/* expand.scm: 1091 simplify */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12315(t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1092 match-expression */
f_5885(t2,((C_word*)t0)[2],lf[362],lf[363]);}}

/* k12342 in k12317 in simplify in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12344,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[359],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_i_assq(lf[358],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12375,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* ##sys#append */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1099 match-expression */
f_5885(t2,((C_word*)t0)[2],lf[360],lf[361]);}}

/* k12388 in k12342 in k12317 in simplify in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[358],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k12373 in k12342 in k12317 in simplify in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12375,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[356],t2);
/* expand.scm: 1096 simplify */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12315(t4,((C_word*)t0)[2],t3);}

/* walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_12046(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12046,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12064,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12068,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1056 vector->list */
t6=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=t3,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1061 c */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t4);}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4));}}}

/* k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12093,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12119,a[2]=t5,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
/* expand.scm: 1067 walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_12036(t8,t6,t2,t7);}}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2));}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1069 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k12138 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12140,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12165,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1072 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_12036(t7,t4,t5,t6);}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12188,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1074 walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_12036(t4,t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12287,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1078 c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12301,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1088 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_12036(t3,t2,((C_word*)t0)[4],((C_word*)t0)[6]);}}}

/* k12299 in k12138 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12309,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1088 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12036(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12307 in k12299 in k12138 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12309,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12285 in k12138 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12287,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12230,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1082 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12036(t6,t5,((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12261,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1084 walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_12036(t7,t5,t3,t6);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12276,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1086 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_12036(t4,t3,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* k12274 in k12285 in k12138 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12284,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1086 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12036(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12282 in k12274 in k12285 in k12138 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12284,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12259 in k12285 in k12138 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12261,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[357],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[356],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12249,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1085 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12036(t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12247 in k12259 in k12285 in k12138 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12249,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12228 in k12285 in k12138 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12230,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[50],t3));}

/* k12186 in k12138 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12188,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[241],((C_word*)t0)[2],t1));}

/* k12163 in k12138 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12165,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[356],t3));}

/* k12117 in k12091 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12119,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[356],((C_word*)t0)[2],t1));}

/* k12066 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1056 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12036(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12062 in walk1 in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12064,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[237],t2));}

/* walk in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_12036(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12036,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12044,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1053 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12046(t5,t4,t2,t3);}

/* k12042 in walk in k12032 in k12029 in k12026 in k12023 in a12020 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1053 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12315(t2,((C_word*)t0)[2],t1);}

/* k12017 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_12019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1044 ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[355],C_SCHEME_END_OF_LIST,t1);}

/* k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7720,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11986,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11988,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1108 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11987 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11988,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11992,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1110 ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[352],t2,lf[354]);}

/* k11990 in a11987 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11992,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[126],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[353],t6));}

/* k11984 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1105 ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[352],C_SCHEME_END_OF_LIST,t1);}

/* k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7723,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11702,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11704,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1116 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11704,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11711,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1119 r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1120 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[351]);}

/* k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1121 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1122 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11723,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1123 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11725,a[2]=((C_word*)t0)[8],a[3]=((C_word)li174),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11735,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=t4,a[7]=t1,a[8]=((C_word)li175),tmp=(C_word)a,a+=9,tmp));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11885,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=((C_word)li177),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_11885(t9,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* expand in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_11885(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11885,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11899,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11901,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11938,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1160 c */
t8=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t6,((C_word*)t0)[3]);}
else{
/* expand.scm: 1158 err */
t6=((C_word*)t0)[2];
f_11725(t6,t1,t4);}}
else{
/* expand.scm: 1153 err */
t4=((C_word*)t0)[2];
f_11725(t4,t1,t2);}}}

/* k11936 in expand in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11938,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[350]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11954,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11960,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1165 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11735(t3,t2,((C_word*)t0)[2]);}}

/* k11958 in k11936 in expand in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11960,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11967,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
/* expand.scm: 1166 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_11885(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k11965 in k11958 in k11936 in expand in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11967,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11952 in k11936 in expand in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11954,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a11900 in expand in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11901,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k11897 in expand in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[26]+1),lf[349],t1);}

/* test in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_11735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11735,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 1129 ##sys#feature? */
t3=C_retrieve(lf[348]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11766,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1134 c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],t3);}
else{
/* expand.scm: 1130 err */
t3=((C_word*)t0)[5];
f_11725(t3,t1,t2);}}}

/* k11764 in test in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11766,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11784,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[11]);
/* expand.scm: 1137 test */
t5=((C_word*)((C_word*)t0)[8])[1];
f_11735(t5,t3,t4);}
else{
/* expand.scm: 1139 err */
t3=((C_word*)t0)[7];
f_11725(t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1140 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k11810 in k11764 in test in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11812,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11827,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 1143 test */
t5=((C_word*)((C_word*)t0)[7])[1];
f_11735(t5,t3,t4);}
else{
/* expand.scm: 1145 err */
t3=((C_word*)t0)[6];
f_11725(t3,((C_word*)t0)[9],((C_word*)t0)[5]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11862,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1146 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11860 in k11810 in k11764 in test in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11862,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11869,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1146 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11735(t4,t2,t3);}
else{
/* expand.scm: 1147 err */
t2=((C_word*)t0)[2];
f_11725(t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k11867 in k11860 in k11810 in k11764 in test in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k11825 in k11810 in k11764 in test in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11827,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11841,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k11839 in k11825 in k11810 in k11764 in test in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11841,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1144 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11735(t3,((C_word*)t0)[2],t2);}

/* k11782 in k11764 in test in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11784,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11793 in k11782 in k11764 in test in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11795,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1138 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11735(t3,((C_word*)t0)[2],t2);}

/* err in k11721 in k11718 in k11715 in k11712 in k11709 in a11703 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_11725(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11725,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[346],((C_word*)t0)[2]);
/* expand.scm: 1125 ##sys#error */
t4=*((C_word*)lf[26]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[347],t2,t3);}

/* k11700 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1113 ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[346],C_SCHEME_END_OF_LIST,t1);}

/* k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7726,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11681,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11683,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1171 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11682 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11683,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[344],t7));}

/* k11679 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1168 ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[345],C_SCHEME_END_OF_LIST,t1);}

/* k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7729,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11660,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11662,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1179 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11661 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11662,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[344],t7));}

/* k11658 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1176 ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[343],C_SCHEME_END_OF_LIST,t1);}

/* k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7732,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11609,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11611,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1187 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11610 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11611,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11615,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1189 ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[220],t2,lf[342]);}

/* k11613 in a11610 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11615,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11645,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11652,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1192 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[341]);}

/* k11650 in k11613 in a11610 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* expand.scm: 1192 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k11643 in k11613 in a11610 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11645,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_TRUE:(C_word)C_i_caddr(((C_word*)t0)[4]));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k11636 in k11643 in k11613 in a11610 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11638,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[340],t3));}

/* k11607 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1184 ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[220],C_SCHEME_END_OF_LIST,t1);}

/* k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7735,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11555,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11557,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1200 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11556 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11557,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11561,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1202 ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[337],t2,lf[339]);}

/* k11559 in a11556 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1203 ##sys#current-module */
t3=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11562 in k11559 in a11556 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11601,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_11567(2,t3,C_SCHEME_FALSE);}}

/* k11599 in k11562 in k11559 in a11556 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11601,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[116],t1);
/* expand.scm: 1204 ##sys#register-meta-expression */
t3=C_retrieve(lf[282]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k11565 in k11562 in k11559 in a11556 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1205 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k11580 in k11565 in k11562 in k11559 in a11556 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11586,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k11584 in k11580 in k11565 in k11562 in k11559 in a11556 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11586,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[338],t3));}

/* k11553 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1197 ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[337],C_SCHEME_END_OF_LIST,t1);}

/* k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7738,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11452,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11454,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1210 ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11453 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11454,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11461,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1213 ##sys#current-module */
t7=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k11459 in a11453 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11464,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_11464(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1215 syntax-error */
t3=C_retrieve(lf[142]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[333],lf[336]);}}

/* k11462 in k11459 in a11453 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11484,a[2]=((C_word*)t0)[3],a[3]=((C_word)li168),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11483 in k11462 in k11459 in a11453 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11484,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11491,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t3;
f_11491(t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11506,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
t5=t3;
f_11491(t5,f_11506(t2));}}

/* loop in a11483 in k11462 in k11459 in a11453 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_11506(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_TRUE);}}
else{
return(C_SCHEME_TRUE);}}}

/* k11489 in a11483 in k11462 in k11459 in a11453 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_11491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=f_9398(((C_word*)t0)[4]);
/* expand.scm: 1224 syntax-error */
t3=C_retrieve(lf[142]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],lf[333],lf[335],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k11465 in k11462 in k11459 in a11453 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11470,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11474,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=f_9416(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11482,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[22]),((C_word*)t0)[2]);}

/* k11480 in k11465 in k11462 in k11459 in a11453 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1228 append */
t2=*((C_word*)lf[67]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11472 in k11465 in k11462 in k11459 in a11453 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(2),t1);}

/* k11468 in k11465 in k11462 in k11459 in a11453 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[334]);}

/* k11450 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1207 ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[333],C_SCHEME_END_OF_LIST,t1);}

/* k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7741,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11415,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11417,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp);
/* ##sys#er-transformer */
t5=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a11416 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11417,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11421,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[329],t2,lf[332]);}

/* k11419 in a11416 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11421,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[5]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=lf[330];
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t7,a[6]=t9,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t4)[1]))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11439,a[2]=t10,a[3]=t7,a[4]=t4,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
t12=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[329],((C_word*)t0)[5],lf[331]);}
else{
t11=t10;
f_11430(t11,C_SCHEME_UNDEFINED);}}

/* k11437 in k11419 in a11416 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_11430(t7,t6);}

/* k11428 in k11419 in a11416 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_11430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#process-syntax-rules */
t2=C_retrieve(lf[230]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11413 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
t2=C_retrieve(lf[31]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[329],C_SCHEME_END_OF_LIST,t1);}

/* k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7741,2,t0,t1);}
t2=C_mutate((C_word*)lf[230]+1 /* (set! process-syntax-rules ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7743,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1240 ##sys#macro-environment */
t4=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9376,2,t0,t1);}
t2=C_mutate((C_word*)lf[266]+1 /* (set! default-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11411,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1245 ##sys#macro-environment */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k11409 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1245 make-parameter */
t2=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9380,2,t0,t1);}
t2=C_mutate((C_word*)lf[197]+1 /* (set! meta-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9384,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1246 make-parameter */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_FALSE);}

/* k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9384,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! current-module ...) */,t1);
t3=C_mutate(&lf[267] /* (set! module? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9392,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[76] /* (set! module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9398,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[268] /* (set! module-export-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9416,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[269] /* (set! set-module-defined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9425,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[270] /* (set! module-defined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9434,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[271] /* (set! module-exist-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9452,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[272] /* (set! module-defined-syntax-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9470,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[273]+1 /* (set! set-module-undefined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9479,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[274]+1 /* (set! module-undefined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9488,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[223] /* (set! module-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9506,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[222] /* (set! module-meta-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9524,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[275] /* (set! module-meta-expressions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9542,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[192] /* (set! module-vexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9560,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[193] /* (set! module-sexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9578,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[276] /* (set! make-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9587,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[194]+1 /* (set! find-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9593,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[281]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9633,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[282]+1 /* (set! register-meta-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9636,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate(&lf[283] /* (set! check-for-redef ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9656,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[286]+1 /* (set! register-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9677,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[289]+1 /* (set! register-syntax-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9766,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[77]+1 /* (set! register-undefined ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9843,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[292]+1 /* (set! register-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9865,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[215]+1 /* (set! mark-imported-symbols ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9933,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate(&lf[294] /* (set! module-indirect-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9992,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate(&lf[300] /* (set! merge-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10268,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[304]+1 /* (set! compiled-module-registration ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10340,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[305]+1 /* (set! register-compiled-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10626,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[309]+1 /* (set! register-primitive-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10746,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[288]+1 /* (set! find-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10837,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[313]+1 /* (set! finalize-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10922,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t34=C_set_block_item(lf[277] /* module-table */,0,C_SCHEME_END_OF_LIST);
t35=C_mutate((C_word*)lf[327]+1 /* (set! macro-subset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11369,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,C_SCHEME_UNDEFINED);}

/* ##sys#macro-subset in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11369,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11377,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1574 ##sys#macro-environment */
t4=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11375 in ##sys#macro-subset in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11377,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11379,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li164),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11379(t5,((C_word*)t0)[2],t1);}

/* loop in k11375 in ##sys#macro-subset in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_11379(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11379,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,((C_word*)t0)[3]));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11400,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1577 loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* k11398 in loop in k11375 in ##sys#macro-subset in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11400,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10922,3,t0,t1,t2);}
t3=f_9416(t2);
t4=f_9398(t2);
t5=f_9434(t2);
t6=f_9452(t2);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10938,a[2]=t4,a[3]=t3,a[4]=t6,a[5]=t5,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11354,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
t9=f_9470(t2);
/* map */
t10=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}

/* a11353 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11354,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11362,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1501 ##sys#macro-environment */
t4=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11360 in a11353 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11292,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11311,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1507 ##sys#macro-environment */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k11309 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11311,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11313,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li161),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11313(t5,((C_word*)t0)[2],t1);}

/* loop in k11309 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_11313(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11313,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11326,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11352,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1509 caar */
t5=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k11350 in loop in k11309 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1509 ##sys#find-export */
t2=C_retrieve(lf[288]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11324 in loop in k11309 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11326,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11337,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1510 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11313(t5,t3,t4);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1511 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11313(t3,((C_word*)t0)[3],t2);}}

/* k11335 in k11324 in loop in k11309 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11337,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a11291 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11292,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11304,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1505 ##sys#macro-environment */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k11302 in a11291 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10944,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t4=(C_truep(t3)?((C_word*)t0)[4]:((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t6,a[5]=t1,a[6]=((C_word)li159),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_11164(t8,t2,t4);}

/* loop in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_11164(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11164,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?t3:(C_word)C_i_car(t3));
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[5]))){
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1519 loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}
else{
t6=(C_word)C_i_assq(t5,((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11212,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11215,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t6,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_cdr(t6);
t10=t8;
f_11215(t10,(C_word)C_i_symbolp(t9));}
else{
t9=t8;
f_11215(t9,C_SCHEME_FALSE);}}}}

/* k11213 in loop in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_11215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11215,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11212(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1526 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k11266 in k11213 in loop in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11268,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_11227(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_11227(t4,C_SCHEME_FALSE);}}

/* k11225 in k11266 in k11213 in loop in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_11227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11227,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11230,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 1528 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[323],((C_word*)t0)[4],lf[324],t3);}
else{
if(C_truep(((C_word*)t0)[3])){
/* expand.scm: 1537 ##sys#module-rename */
t2=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11250,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11254,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1534 symbol->string */
t4=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}

/* k11252 in k11225 in k11266 in k11213 in loop in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1532 string-append */
t2=*((C_word*)lf[41]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[325],t1,lf[326]);}

/* k11248 in k11225 in k11266 in k11213 in loop in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1531 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11228 in k11225 in k11266 in k11213 in loop in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_11212(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* k11210 in loop in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11212,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11201,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1538 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11164(t5,t3,t4);}

/* k11199 in k11210 in loop in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11201,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11144,a[2]=((C_word*)t0)[2],a[3]=((C_word)li158),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11158,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1543 module-undefined-list */
t5=C_retrieve(lf[274]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k11156 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11143 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11144(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11144,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1542 ##sys#warn */
t3=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[322],t2);}}

/* k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11106,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11142,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1549 module-indirect-exports */
f_9992(t4,((C_word*)t0)[6]);}

/* k11140 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11105 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11106,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11134,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1547 ##sys#macro-environment */
t6=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}

/* k11132 in a11105 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 1548 ##sys#error */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],lf[321],t3);}}

/* k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11100,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1551 ##sys#macro-environment */
t4=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k11098 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11104,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1552 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k11102 in k11098 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11104,2,t0,t1);}
/* expand.scm: 1550 merge-se */
f_10268(((C_word*)t0)[4],(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10956,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 1554 ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}

/* k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11058,a[2]=((C_word*)t0)[2],a[3]=((C_word)li156),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a11057 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11058,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11062,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(t2);
/* expand.scm: 1557 merge-se */
f_10268(t3,(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[2]));}

/* k11060 in a11057 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11065,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11088,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11092,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1558 map-se */
f_3557(t5,t1);}

/* k11090 in k11060 in a11057 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11086 in k11060 in a11057 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11088,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[320],t2);
/* expand.scm: 1558 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* k11063 in k11060 in a11057 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_car(t2,((C_word*)t0)[2]));}

/* k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10962,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=f_9398(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11056,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k11054 in k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11056,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[314],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11048,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11052,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1564 map-se */
f_3557(t4,((C_word*)t0)[2]);}

/* k11050 in k11054 in k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11046 in k11054 in k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11048,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[315],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11040,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11044,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1565 map-se */
f_3557(t4,((C_word*)t0)[2]);}

/* k11042 in k11046 in k11054 in k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11038 in k11046 in k11054 in k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11040,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[316],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11036,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1566 map-se */
f_3557(t4,((C_word*)t0)[2]);}

/* k11034 in k11038 in k11046 in k11054 in k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11030 in k11038 in k11046 in k11054 in k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11032,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[317],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11028,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1567 map-se */
f_3557(t4,((C_word*)t0)[2]);}

/* k11026 in k11030 in k11038 in k11046 in k11054 in k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11022 in k11030 in k11038 in k11046 in k11054 in k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_11024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11024,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[318],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[319],t8);
/* expand.scm: 1561 dm */
t10=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t10))(3,t10,((C_word*)t0)[2],t9);}

/* k10960 in k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(10),t4);}

/* k10963 in k10960 in k10957 in k10954 in k10951 in k10948 in k10945 in k10942 in k10939 in k10936 in ##sys#finalize-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(11),t4);}

/* ##sys#find-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10837,5,t0,t1,t2,t3,t4);}
t5=f_9416(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10848,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t5);
if(C_truep(t7)){
/* expand.scm: 1487 module-exists-list */
t8=C_retrieve(lf[312]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t3);}
else{
t8=t6;
f_10848(2,t8,t5);}}

/* k10846 in ##sys#find-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10848,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10850,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li154),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_10850(t5,((C_word*)t0)[2],t1);}

/* loop in k10846 in ##sys#find-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_10850(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10850,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1491 caar */
t7=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1494 loop */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}}

/* k10897 in loop in k10846 in ##sys#find-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10899,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10895,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1492 cdar */
t5=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}
else{
t4=t3;
f_10878(t4,C_SCHEME_FALSE);}}}

/* k10893 in k10897 in loop in k10846 in ##sys#find-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_10878(t2,(C_word)C_i_memq(((C_word*)t0)[2],t1));}

/* k10876 in k10897 in loop in k10846 in ##sys#find-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_10878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1493 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10850(t3,((C_word*)t0)[4],t2);}}

/* ##sys#register-primitive-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_10746r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10746r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10746r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10750,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_10750(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_10750(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k10748 in ##sys#register-primitive-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10753,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1464 ##sys#macro-environment */
t3=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10751 in k10748 in ##sys#register-primitive-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10768,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10792,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10791 in k10751 in k10748 in ##sys#register-primitive-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10792,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10802,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10812,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 1471 ##sys#string-append */
t6=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[311],t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10810 in a10791 in k10751 in k10748 in ##sys#register-primitive-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1470 ##sys#string->symbol */
t2=C_retrieve(lf[73]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10800 in a10791 in k10751 in k10748 in ##sys#register-primitive-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10805,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1472 ##sys#put! */
t3=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[83],((C_word*)t0)[2]);}

/* k10803 in k10800 in a10791 in k10751 in k10748 in ##sys#register-primitive-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10805,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10766 in k10751 in k10748 in ##sys#register-primitive-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10772,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10774,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word)li151),tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10773 in k10766 in k10751 in k10748 in ##sys#register-primitive-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10774,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* expand.scm: 1479 ##sys#error */
t4=*((C_word*)lf[26]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[310],t2,((C_word*)t0)[2]);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10770 in k10766 in k10751 in k10748 in ##sys#register-primitive-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10772,2,t0,t1);}
t2=f_9587(C_a_i(&a,13),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve(lf[277]));
t5=C_mutate((C_word*)lf[277]+1 /* (set! module-table ...) */,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_10626,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10630,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10728,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t5);}

/* a10727 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10728,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10740,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 1437 ##sys#er-transformer */
t6=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k10738 in a10727 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10740,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10633,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10696,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10695 in k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10696,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10718,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_caddr(t2);
/* expand.scm: 1442 ##sys#er-transformer */
t8=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k10716 in a10695 in k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10718,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10631 in k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10633,2,t0,t1);}
t2=f_9587(C_a_i(&a,13),((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10639,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10690,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1447 ##sys#macro-environment */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k10688 in k10631 in k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1448 ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k10692 in k10688 in k10631 in k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10694,2,t0,t1);}
/* expand.scm: 1446 merge-se */
f_10268(((C_word*)t0)[6],(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10637 in k10631 in k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1450 ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k10640 in k10637 in k10631 in k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10678,a[2]=((C_word*)t0)[4],a[3]=((C_word)li147),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10677 in k10640 in k10637 in k10631 in k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10678(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10678,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}

/* k10643 in k10640 in k10637 in k10631 in k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10648,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10658,a[2]=((C_word*)t0)[3],a[3]=((C_word)li146),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10657 in k10643 in k10640 in k10637 in k10631 in k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10658,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_set_car(t4,((C_word*)t0)[2]));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k10646 in k10643 in k10640 in k10637 in k10631 in k10628 in ##sys#register-compiled-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10648,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[277]));
t4=C_mutate((C_word*)lf[277]+1 /* (set! module-table ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10340,3,t0,t1,t2);}
t3=f_9434(t2);
t4=f_9398(t2);
t5=f_9506(t2);
t6=f_9524(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10360,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10624,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t9=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t5,C_SCHEME_END_OF_LIST);}
else{
t8=t7;
f_10360(t8,C_SCHEME_END_OF_LIST);}}

/* k10622 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10624,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[279],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[308],t5);
t7=((C_word*)t0)[2];
f_10360(t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_10360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10360,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10364,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10368,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10594,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_10368(t4,C_SCHEME_END_OF_LIST);}}

/* k10592 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10594,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[279],t1);
t3=((C_word*)t0)[2];
f_10368(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_10368(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10368,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10372,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10576,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=f_9542(((C_word*)t0)[4]);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[22]),t5);}

/* k10574 in k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1415 reverse */
t2=*((C_word*)lf[92]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10374 in k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10376,2,t0,t1);}
t2=f_9398(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10489,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10491,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10564,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1423 module-indirect-exports */
f_9992(t8,((C_word*)t0)[5]);}

/* k10562 in k10374 in k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10490 in k10374 in k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[33],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10491,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[95],t7));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[95],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[95],t7);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[164],t12));}}

/* k10487 in k10374 in k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10483 in k10374 in k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10485,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=f_9560(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[95],t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10420,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10424,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li143),tmp=(C_word)a,a+=5,tmp);
t9=f_9578(((C_word*)t0)[7]);
/* map */
t10=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}

/* a10425 in k10483 in k10374 in k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10426,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(t3,((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10436,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=t5;
f_10436(2,t6,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1430 error */
t6=*((C_word*)lf[278]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,lf[220],lf[307],t3,((C_word*)t0)[2]);}}

/* k10434 in a10425 in k10483 in k10374 in k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10436,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t4,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[306],t7));}

/* k10422 in k10483 in k10374 in k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10418 in k10483 in k10374 in k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10420,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[305],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t9=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k10370 in k10366 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10362 in k10358 in ##sys#compiled-module-registration in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* merge-se in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_10268(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10268,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10272,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,*((C_word*)lf[67]+1),t2);}

/* k10270 in merge-se in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10275,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
/* expand.scm: 1399 dm */
t5=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[302],t3,lf[303],t4);}

/* k10273 in k10270 in merge-se in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10278,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10287,a[2]=t4,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10287(t6,t2,((C_word*)t0)[2]);}

/* loop in k10273 in k10270 in merge-se in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_10287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10287,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10326,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1403 caar */
t4=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k10324 in loop in k10273 in k10270 in merge-se in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10326,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(t1,t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1403 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10287(t4,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10318,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1404 loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10287(t6,t4,t5);}}

/* k10316 in k10324 in loop in k10273 in k10270 in merge-se in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10318,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10276 in k10273 in k10270 in merge-se in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10281,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(t1);
/* expand.scm: 1405 dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[301],t3);}

/* k10279 in k10276 in k10273 in k10270 in merge-se in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_9992(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9992,NULL,2,t1,t2);}
t3=f_9416(t2);
t4=f_9398(t2);
t5=f_9434(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10050,a[2]=t4,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t3);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10073,a[2]=t4,a[3]=t5,a[4]=t6,a[5]=t9,a[6]=((C_word)li139),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_10073(t11,t1,t3);}}

/* loop in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_10073(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10073,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_cdr(t2);
/* expand.scm: 1372 loop */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10100,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1374 cdar */
t5=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}}

/* k10098 in loop in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10100,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li138),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_10102(t5,((C_word*)t0)[2],t1);}

/* loop2 in k10098 in loop in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_10102(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10102,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 1375 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_10073(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1376 ##sys#macro-environment */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k10260 in loop2 in k10098 in loop in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10262,2,t0,t1);}
if(C_truep((C_word)C_i_assq(((C_word*)t0)[8],t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10125,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1377 warn */
t4=((C_word*)t0)[4];
f_10050(t4,t2,lf[297],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_cdr(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10168,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_10168(2,t7,t5);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1384 ##sys#module-rename */
t8=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,((C_word*)t0)[2]);}}
else{
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10250,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1386 ##sys#current-environment */
t6=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}}

/* k10248 in k10260 in loop2 in k10098 in loop in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10250,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10198,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 1389 loop2 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10102(t9,t7,t8);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10213,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1391 warn */
t6=((C_word*)t0)[2];
f_10050(t6,t4,lf[298],t5);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10231,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1394 warn */
t5=((C_word*)t0)[2];
f_10050(t5,t3,lf[299],t4);}}

/* k10229 in k10248 in k10260 in loop2 in k10098 in loop in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1395 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10102(t3,((C_word*)t0)[2],t2);}

/* k10211 in k10248 in k10260 in loop2 in k10098 in loop in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1392 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10102(t3,((C_word*)t0)[2],t2);}

/* k10196 in k10248 in k10260 in loop2 in k10098 in loop in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10198,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10166 in k10260 in loop2 in k10098 in loop in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10168,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10153,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1385 loop2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10102(t5,t3,t4);}

/* k10151 in k10166 in k10260 in loop2 in k10098 in loop in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10153,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10123 in k10260 in loop2 in k10098 in loop in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1378 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10102(t3,((C_word*)t0)[2],t2);}

/* warn in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_10050(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10050,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10058,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10062,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1366 symbol->string */
t6=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k10060 in warn in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1366 string-append */
t2=*((C_word*)lf[41]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[295],t1,lf[296]);}

/* k10056 in warn in module-indirect-exports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_10058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1365 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#mark-imported-symbols in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9933,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9939,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a9938 in ##sys#mark-imported-symbols in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9939(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9939,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9946,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_eqp(t5,t6);
t8=t3;
f_9946(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_9946(t5,C_SCHEME_FALSE);}}

/* k9944 in a9938 in ##sys#mark-imported-symbols in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_9946(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9946,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[293],t4);
/* expand.scm: 1350 dm */
t6=C_retrieve2(lf[7],"dm");
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9947 in k9944 in a9938 in ##sys#mark-imported-symbols in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1351 ##sys#put! */
t3=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t2,lf[85],C_SCHEME_TRUE);}

/* ##sys#register-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+69)){
C_save_and_reclaim((void*)tr4r,(void*)f_9865r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_9865r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9865r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(69);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9867,a[2]=t3,a[3]=t2,a[4]=((C_word)li132),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9880,a[2]=t5,a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9885,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-vexports29312950 */
t8=t1;
((C_proc2)C_retrieve_proc(t8))(2,t8,f_9885(C_a_i(&a,19),t7));}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-sexports29322946 */
t10=t1;
((C_proc2)C_retrieve_proc(t10))(2,t10,f_9880(C_a_i(&a,19),t6,t8));}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body29292938 */
t12=t1;
((C_proc2)C_retrieve_proc(t12))(2,t12,f_9867(C_a_i(&a,19),t5,t8,t10));}
else{
/* ##sys#error */
t12=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-vexports2931 in ##sys#register-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9885(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return(f_9880(C_a_i(&a,19),((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* def-sexports2932 in ##sys#register-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9880(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return(f_9867(C_a_i(&a,19),((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST));}

/* body2929 in ##sys#register-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9867(C_word *a,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t3=f_9587(C_a_i(&a,13),((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[277]));
t6=C_mutate((C_word*)lf[277]+1 /* (set! module-table ...) */,t5);
return(t3);}

/* ##sys#register-undefined in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9843,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9850,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1337 module-undefined-list */
t5=C_retrieve(lf[274]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k9848 in ##sys#register-undefined in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9850,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1339 set-module-undefined-list! */
t3=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* ##sys#register-syntax-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9766,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=f_9416(t3);
t6=(C_word)C_eqp(C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9776,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9776(2,t8,t6);}
else{
/* expand.scm: 1319 ##sys#find-export */
t8=C_retrieve(lf[288]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,t2,t3,C_SCHEME_TRUE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k9774 in ##sys#register-syntax-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9779,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1320 module-undefined-list */
t3=C_retrieve(lf[274]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}

/* k9777 in k9774 in ##sys#register-syntax-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9779,2,t0,t1);}
t2=f_9398(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],t1))){
/* expand.scm: 1323 ##sys#warn */
t4=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[291],((C_word*)t0)[5]);}
else{
t4=t3;
f_9785(2,t4,C_SCHEME_UNDEFINED);}}

/* k9783 in k9777 in k9774 in ##sys#register-syntax-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9824,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1324 ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9822 in k9783 in k9777 in k9774 in ##sys#register-syntax-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9828,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1324 ##sys#macro-environment */
t3=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9826 in k9822 in k9783 in k9777 in k9774 in ##sys#register-syntax-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1324 check-for-redef */
f_9656(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9786 in k9783 in k9777 in k9774 in ##sys#register-syntax-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1325 dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[290],((C_word*)t0)[5]);}

/* k9789 in k9786 in k9783 in k9777 in k9774 in ##sys#register-syntax-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9794,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[2]);
t4=f_9434(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
/* expand.scm: 1327 set-module-defined-list! */
f_9425(t2,((C_word*)t0)[6],t5);}
else{
t3=t2;
f_9794(2,t3,C_SCHEME_UNDEFINED);}}

/* k9792 in k9789 in k9786 in k9783 in k9777 in k9774 in ##sys#register-syntax-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9794,2,t0,t1);}
t2=f_9470(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[4];
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,C_fix(5),t3);}

/* ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9677,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=f_9416(t3);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9687,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_9687(2,t7,t5);}
else{
/* expand.scm: 1300 ##sys#find-export */
t7=C_retrieve(lf[288]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t2,t3,C_SCHEME_TRUE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k9685 in ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1301 module-undefined-list */
t3=C_retrieve(lf[274]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k9688 in k9685 in ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9693,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9753,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=f_9398(((C_word*)t0)[3]);
/* expand.scm: 1303 ##sys#module-rename */
t5=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[4],t4);}

/* k9751 in k9688 in k9685 in ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1302 ##sys#toplevel-definition-hook */
t2=C_retrieve(lf[281]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9691 in k9688 in k9685 in ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9749,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1306 ##sys#delq */
t4=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_9696(2,t3,C_SCHEME_UNDEFINED);}}

/* k9747 in k9691 in k9688 in k9685 in ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1306 set-module-undefined-list! */
t2=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9694 in k9691 in k9688 in k9685 in ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9735,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1307 ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9733 in k9694 in k9691 in k9688 in k9685 in ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9739,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1307 ##sys#macro-environment */
t3=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9737 in k9733 in k9694 in k9691 in k9688 in k9685 in ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1307 check-for-redef */
f_9656(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9697 in k9694 in k9691 in k9688 in k9685 in ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=f_9452(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(4),t4);}

/* k9700 in k9697 in k9694 in k9691 in k9688 in k9685 in ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9702,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1310 dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[287],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9706 in k9700 in k9697 in k9694 in k9691 in k9688 in k9685 in ##sys#register-export in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9708,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_FALSE);
t3=f_9434(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* expand.scm: 1311 set-module-defined-list! */
f_9425(((C_word*)t0)[2],((C_word*)t0)[3],t4);}

/* check-for-redef in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_9656(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9656,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(t2,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9663,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
/* expand.scm: 1293 ##sys#warn */
t7=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[285],t2);}
else{
t7=t6;
f_9663(2,t7,C_SCHEME_FALSE);}}

/* k9661 in check-for-redef in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
/* expand.scm: 1295 ##sys#warn */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[284],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#register-meta-expression in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9636(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9636,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9640,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1288 ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k9638 in ##sys#register-meta-expression in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9640,2,t0,t1);}
if(C_truep(t1)){
t2=f_9542(t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,C_fix(9),t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#toplevel-definition-hook in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9633,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}

/* ##sys#find-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9593(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_9593r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9593r(t0,t1,t2,t3);}}

static void C_ccall f_9593r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9597,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_9597(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_9597(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k9595 in ##sys#find-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[277]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
if(C_truep(t1)){
/* expand.scm: 1282 error */
t3=*((C_word*)lf[278]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[279],lf[280],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* make-module in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9587(C_word *a,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_stack_check;
return((C_word)C_a_i_record(&a,12,lf[220],t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,t4));}

/* module-sexports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9578(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(11)));}

/* module-vexports in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9560(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(10)));}

/* module-meta-expressions in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9542(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(9)));}

/* module-meta-import-forms in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9524(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(8)));}

/* module-import-forms in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9506(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(7)));}

/* module-undefined-list in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9488,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[220]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* set-module-undefined-list! in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9479,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* module-defined-syntax-list in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9470(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(5)));}

/* module-exist-list in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9452(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(4)));}

/* module-defined-list in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9434(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(3)));}

/* set-module-defined-list! in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_9425(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9425,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* module-export-list in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9416(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* module-name in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_9398(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(1)));}

/* module? in k9382 in k9378 in k9374 in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9392(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9392,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[220]));}

/* ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word ab[151],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7743,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_SCHEME_UNDEFINED;
t42=(*a=C_VECTOR_TYPE|1,a[1]=t41,tmp=(C_word)a,a+=2,tmp);
t43=C_SCHEME_UNDEFINED;
t44=(*a=C_VECTOR_TYPE|1,a[1]=t43,tmp=(C_word)a,a+=2,tmp);
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_SCHEME_UNDEFINED;
t56=(*a=C_VECTOR_TYPE|1,a[1]=t55,tmp=(C_word)a,a+=2,tmp);
t57=C_SCHEME_UNDEFINED;
t58=(*a=C_VECTOR_TYPE|1,a[1]=t57,tmp=(C_word)a,a+=2,tmp);
t59=C_SCHEME_UNDEFINED;
t60=(*a=C_VECTOR_TYPE|1,a[1]=t59,tmp=(C_word)a,a+=2,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_SCHEME_UNDEFINED;
t64=(*a=C_VECTOR_TYPE|1,a[1]=t63,tmp=(C_word)a,a+=2,tmp);
t65=C_SCHEME_UNDEFINED;
t66=(*a=C_VECTOR_TYPE|1,a[1]=t65,tmp=(C_word)a,a+=2,tmp);
t67=C_SCHEME_UNDEFINED;
t68=(*a=C_VECTOR_TYPE|1,a[1]=t67,tmp=(C_word)a,a+=2,tmp);
t69=C_SCHEME_UNDEFINED;
t70=(*a=C_VECTOR_TYPE|1,a[1]=t69,tmp=(C_word)a,a+=2,tmp);
t71=C_SCHEME_UNDEFINED;
t72=(*a=C_VECTOR_TYPE|1,a[1]=t71,tmp=(C_word)a,a+=2,tmp);
t73=C_SCHEME_UNDEFINED;
t74=(*a=C_VECTOR_TYPE|1,a[1]=t73,tmp=(C_word)a,a+=2,tmp);
t75=C_SCHEME_UNDEFINED;
t76=(*a=C_VECTOR_TYPE|1,a[1]=t75,tmp=(C_word)a,a+=2,tmp);
t77=C_SCHEME_UNDEFINED;
t78=(*a=C_VECTOR_TYPE|1,a[1]=t77,tmp=(C_word)a,a+=2,tmp);
t79=C_SCHEME_UNDEFINED;
t80=(*a=C_VECTOR_TYPE|1,a[1]=t79,tmp=(C_word)a,a+=2,tmp);
t81=C_SCHEME_UNDEFINED;
t82=(*a=C_VECTOR_TYPE|1,a[1]=t81,tmp=(C_word)a,a+=2,tmp);
t83=C_SCHEME_UNDEFINED;
t84=(*a=C_VECTOR_TYPE|1,a[1]=t83,tmp=(C_word)a,a+=2,tmp);
t85=C_SCHEME_UNDEFINED;
t86=(*a=C_VECTOR_TYPE|1,a[1]=t85,tmp=(C_word)a,a+=2,tmp);
t87=C_SCHEME_UNDEFINED;
t88=(*a=C_VECTOR_TYPE|1,a[1]=t87,tmp=(C_word)a,a+=2,tmp);
t89=C_SCHEME_UNDEFINED;
t90=(*a=C_VECTOR_TYPE|1,a[1]=t89,tmp=(C_word)a,a+=2,tmp);
t91=C_SCHEME_UNDEFINED;
t92=(*a=C_VECTOR_TYPE|1,a[1]=t91,tmp=(C_word)a,a+=2,tmp);
t93=C_SCHEME_UNDEFINED;
t94=(*a=C_VECTOR_TYPE|1,a[1]=t93,tmp=(C_word)a,a+=2,tmp);
t95=C_SCHEME_UNDEFINED;
t96=(*a=C_VECTOR_TYPE|1,a[1]=t95,tmp=(C_word)a,a+=2,tmp);
t97=C_SCHEME_UNDEFINED;
t98=(*a=C_VECTOR_TYPE|1,a[1]=t97,tmp=(C_word)a,a+=2,tmp);
t99=C_SCHEME_UNDEFINED;
t100=(*a=C_VECTOR_TYPE|1,a[1]=t99,tmp=(C_word)a,a+=2,tmp);
t101=C_SCHEME_UNDEFINED;
t102=(*a=C_VECTOR_TYPE|1,a[1]=t101,tmp=(C_word)a,a+=2,tmp);
t103=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7750,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=t98,a[6]=t100,a[7]=t94,a[8]=t102,a[9]=t2,a[10]=t96,a[11]=t86,a[12]=t84,a[13]=t4,a[14]=t82,a[15]=t88,a[16]=t92,a[17]=t90,a[18]=t80,a[19]=t78,a[20]=t76,a[21]=t74,a[22]=t72,a[23]=t70,a[24]=t68,a[25]=t66,a[26]=t64,a[27]=t62,a[28]=t60,a[29]=t58,a[30]=t56,a[31]=t54,a[32]=t52,a[33]=t50,a[34]=t48,a[35]=t46,a[36]=t44,a[37]=t42,a[38]=t40,a[39]=t38,a[40]=t36,a[41]=t34,a[42]=t32,a[43]=t30,a[44]=t28,a[45]=t26,a[46]=t24,a[47]=t22,a[48]=t20,a[49]=t18,a[50]=t16,a[51]=t14,a[52]=t12,a[53]=t10,a[54]=t8,tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t104=t5;
((C_proc3)C_retrieve_proc(t104))(3,t104,t103,lf[265]);}

/* k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7750,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[231]);
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[232]);
t5=C_mutate(((C_word *)((C_word*)t0)[51])+1,lf[233]);
t6=C_mutate(((C_word *)((C_word*)t0)[50])+1,lf[234]);
t7=C_mutate(((C_word *)((C_word*)t0)[49])+1,lf[235]);
t8=C_mutate(((C_word *)((C_word*)t0)[48])+1,lf[236]);
t9=C_mutate(((C_word *)((C_word*)t0)[47])+1,lf[237]);
t10=C_mutate(((C_word *)((C_word*)t0)[46])+1,lf[238]);
t11=C_mutate(((C_word *)((C_word*)t0)[45])+1,lf[239]);
t12=C_mutate(((C_word *)((C_word*)t0)[44])+1,lf[240]);
t13=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[47],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[48],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[45],a[13]=((C_word*)t0)[50],a[14]=((C_word*)t0)[49],a[15]=((C_word*)t0)[44],a[16]=((C_word*)t0)[46],a[17]=((C_word*)t0)[51],a[18]=((C_word*)t0)[10],a[19]=((C_word*)t0)[11],a[20]=((C_word*)t0)[53],a[21]=((C_word*)t0)[12],a[22]=((C_word*)t0)[13],a[23]=((C_word*)t0)[14],a[24]=((C_word*)t0)[15],a[25]=((C_word*)t0)[16],a[26]=((C_word*)t0)[17],a[27]=((C_word*)t0)[54],a[28]=((C_word*)t0)[18],a[29]=((C_word*)t0)[52],a[30]=((C_word*)t0)[19],a[31]=((C_word*)t0)[20],a[32]=((C_word*)t0)[21],a[33]=((C_word*)t0)[22],a[34]=((C_word*)t0)[23],a[35]=((C_word*)t0)[24],a[36]=((C_word*)t0)[25],a[37]=((C_word*)t0)[26],a[38]=((C_word*)t0)[27],a[39]=((C_word*)t0)[28],a[40]=((C_word*)t0)[29],a[41]=((C_word*)t0)[30],a[42]=((C_word*)t0)[31],a[43]=((C_word*)t0)[32],a[44]=((C_word*)t0)[33],a[45]=((C_word*)t0)[34],a[46]=((C_word*)t0)[35],a[47]=((C_word*)t0)[36],a[48]=((C_word*)t0)[37],a[49]=((C_word*)t0)[38],a[50]=((C_word*)t0)[39],a[51]=((C_word*)t0)[40],a[52]=((C_word*)t0)[41],a[53]=((C_word*)t0)[42],a[54]=((C_word*)t0)[43],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t14=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,lf[264]);}

/* k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7764,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[54],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[263]);}

/* k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7768,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[54],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[262]);}

/* k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7772,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[241]);
t4=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[53],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[54],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[261]);}

/* k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7777,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[242]);
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[243]);
t5=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[52],a[22]=((C_word*)t0)[53],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[54],a[34]=((C_word*)t0)[31],a[35]=((C_word*)t0)[32],a[36]=((C_word*)t0)[33],a[37]=((C_word*)t0)[34],a[38]=((C_word*)t0)[35],a[39]=((C_word*)t0)[36],a[40]=((C_word*)t0)[37],a[41]=((C_word*)t0)[38],a[42]=((C_word*)t0)[39],a[43]=((C_word*)t0)[40],a[44]=((C_word*)t0)[41],a[45]=((C_word*)t0)[42],a[46]=((C_word*)t0)[43],a[47]=((C_word*)t0)[44],a[48]=((C_word*)t0)[45],a[49]=((C_word*)t0)[46],a[50]=((C_word*)t0)[47],a[51]=((C_word*)t0)[48],a[52]=((C_word*)t0)[49],a[53]=((C_word*)t0)[50],a[54]=((C_word*)t0)[51],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[260]);}

/* k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7783,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[54],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[259]);}

/* k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7787,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[54],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7791,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[54],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[57]);}

/* k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7795,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[54],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[113]);}

/* k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7799,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[244]);
t4=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[53],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[54],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[164]);}

/* k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[258]);}

/* k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7808,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[21]);
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[245]);
t5=C_mutate(((C_word *)((C_word*)t0)[51])+1,lf[246]);
t6=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[52],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[53],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[54],a[23]=((C_word*)t0)[51],a[24]=((C_word*)t0)[20],a[25]=((C_word*)t0)[21],a[26]=((C_word*)t0)[22],a[27]=((C_word*)t0)[23],a[28]=((C_word*)t0)[24],a[29]=((C_word*)t0)[25],a[30]=((C_word*)t0)[26],a[31]=((C_word*)t0)[27],a[32]=((C_word*)t0)[28],a[33]=((C_word*)t0)[29],a[34]=((C_word*)t0)[30],a[35]=((C_word*)t0)[31],a[36]=((C_word*)t0)[32],a[37]=((C_word*)t0)[33],a[38]=((C_word*)t0)[34],a[39]=((C_word*)t0)[35],a[40]=((C_word*)t0)[36],a[41]=((C_word*)t0)[37],a[42]=((C_word*)t0)[38],a[43]=((C_word*)t0)[39],a[44]=((C_word*)t0)[40],a[45]=((C_word*)t0)[41],a[46]=((C_word*)t0)[42],a[47]=((C_word*)t0)[43],a[48]=((C_word*)t0)[44],a[49]=((C_word*)t0)[45],a[50]=((C_word*)t0)[46],a[51]=((C_word*)t0)[47],a[52]=((C_word*)t0)[48],a[53]=((C_word*)t0)[49],a[54]=((C_word*)t0)[50],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7815,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[247]);
t4=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[54],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[53],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[95]);}

/* k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7820,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[54],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[227]);}

/* k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7824,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|54,a[1]=(C_word)f_7828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[54],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],tmp=(C_word)a,a+=55,tmp);
/* r2215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[256]);}

/* k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7828,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[54])+1,t1);
t3=(*a=C_CLOSURE_TYPE|53,a[1]=(C_word)f_7832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[44],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[54],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],tmp=(C_word)a,a+=54,tmp);
/* r2215 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[255]);}

/* k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[129],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7832,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[53])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[52]);
t4=C_mutate(((C_word *)((C_word*)t0)[51])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7835,a[2]=((C_word*)t0)[41],a[3]=((C_word*)t0)[42],a[4]=((C_word*)t0)[52],a[5]=((C_word*)t0)[43],a[6]=((C_word*)t0)[44],a[7]=((C_word*)t0)[45],a[8]=((C_word*)t0)[46],a[9]=((C_word*)t0)[47],a[10]=((C_word*)t0)[48],a[11]=((C_word*)t0)[49],a[12]=((C_word*)t0)[50],a[13]=((C_word)li90),tmp=(C_word)a,a+=14,tmp));
t5=C_mutate(((C_word *)((C_word*)t0)[41])+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7929,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[46],a[4]=((C_word*)t0)[36],a[5]=((C_word*)t0)[37],a[6]=((C_word*)t0)[38],a[7]=((C_word*)t0)[39],a[8]=((C_word*)t0)[40],a[9]=((C_word)li92),tmp=(C_word)a,a+=10,tmp));
t6=C_mutate(((C_word *)((C_word*)t0)[35])+1,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8013,a[2]=((C_word*)t0)[27],a[3]=((C_word*)t0)[28],a[4]=((C_word*)t0)[29],a[5]=((C_word*)t0)[30],a[6]=((C_word*)t0)[31],a[7]=((C_word*)t0)[35],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[44],a[10]=((C_word*)t0)[40],a[11]=((C_word*)t0)[32],a[12]=((C_word*)t0)[53],a[13]=((C_word*)t0)[33],a[14]=((C_word*)t0)[50],a[15]=((C_word*)t0)[49],a[16]=((C_word*)t0)[34],a[17]=((C_word)li93),tmp=(C_word)a,a+=18,tmp));
t7=C_mutate(((C_word *)((C_word*)t0)[33])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8234,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[31],a[4]=((C_word*)t0)[44],a[5]=((C_word*)t0)[22],a[6]=((C_word*)t0)[40],a[7]=((C_word*)t0)[23],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[32],a[10]=((C_word*)t0)[24],a[11]=((C_word*)t0)[25],a[12]=((C_word*)t0)[26],a[13]=((C_word)li94),tmp=(C_word)a,a+=14,tmp));
t8=C_mutate(((C_word *)((C_word*)t0)[30])+1,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8352,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[35],a[6]=((C_word*)t0)[17],a[7]=((C_word*)t0)[18],a[8]=((C_word*)t0)[23],a[9]=((C_word*)t0)[22],a[10]=((C_word*)t0)[19],a[11]=((C_word*)t0)[20],a[12]=((C_word*)t0)[44],a[13]=((C_word*)t0)[40],a[14]=((C_word*)t0)[21],a[15]=((C_word*)t0)[53],a[16]=((C_word)li96),tmp=(C_word)a,a+=17,tmp));
t9=C_mutate(((C_word *)((C_word*)t0)[36])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8640,a[2]=((C_word*)t0)[27],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[31],a[7]=((C_word*)t0)[47],a[8]=((C_word*)t0)[36],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[43],a[11]=((C_word*)t0)[53],a[12]=((C_word*)t0)[34],a[13]=((C_word)li99),tmp=(C_word)a,a+=14,tmp));
t10=C_mutate(((C_word *)((C_word*)t0)[38])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8847,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[43],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[38],a[12]=((C_word*)t0)[49],a[13]=((C_word)li101),tmp=(C_word)a,a+=14,tmp));
t11=C_mutate(((C_word *)((C_word*)t0)[37])+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9101,a[2]=((C_word*)t0)[27],a[3]=((C_word*)t0)[37],a[4]=((C_word*)t0)[34],a[5]=((C_word)li102),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9174,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate(((C_word *)((C_word*)t0)[27])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9267,a[2]=((C_word*)t0)[4],a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9289,a[2]=((C_word*)t0)[14],a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate(((C_word *)((C_word*)t0)[8])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9315,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp));
t16=C_mutate(((C_word *)((C_word*)t0)[11])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9335,a[2]=((C_word*)t0)[14],a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp));
/* make-transformer2255 */
t17=((C_word*)((C_word*)t0)[51])[1];
((C_proc3)C_retrieve_proc(t17))(3,t17,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_9335 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9335(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9335,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9345,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li107),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9345(t7,t1,t3);}

/* loop */
static void C_fcall f_9345(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9345,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9352,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_9352(t5,(C_word)C_eqp(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_9352(t4,C_SCHEME_FALSE);}}

/* k9350 in loop */
static void C_fcall f_9352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop2584 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9345(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* f_9315 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9315,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9322,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* segment-template?2265 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9320 */
static void C_ccall f_9322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9322,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9329,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* segment-depth2266 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* k9327 in k9320 */
static void C_ccall f_9329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(1),t1));}

/* f_9289 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9289,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t4,((C_word*)t0)[2]));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_9267 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9267(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9267,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9274,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* segment-template?2265 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9272 */
static void C_ccall f_9274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* ##sys#syntax-error-hook */
t4=C_retrieve(lf[52]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],lf[254],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_9174 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9174,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9187,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,t5))){
t7=t6;
f_9187(t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_i_assq(t2,t4);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t7);
t9=t3;
t10=t6;
f_9187(t10,(C_word)C_fixnum_greater_or_equal_p(t8,t9));}
else{
t8=t6;
f_9187(t8,C_SCHEME_FALSE);}}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9216,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* segment-template?2265 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}

/* k9214 */
static void C_ccall f_9216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9216,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9227,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* free-meta-variables2263 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* free-meta-variables2263 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
t3=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9263 in k9214 */
static void C_ccall f_9265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2263 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9246 in k9214 */
static void C_ccall f_9248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2263 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9225 in k9214 */
static void C_ccall f_9227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2263 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9185 */
static void C_fcall f_9187(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9187,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]):((C_word*)t0)[2]));}

/* f_9101 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_9101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9101,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[4]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t4));}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9127,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* segment-pattern?2264 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k9125 */
static void C_ccall f_9127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9127,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* meta-variables2262 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9155,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* meta-variables2262 */
t5=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
t3=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9170 in k9125 */
static void C_ccall f_9172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2262 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9153 in k9125 */
static void C_ccall f_9155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2262 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8847 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_8847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8847,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(C_word)C_i_assq(t2,t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
t7=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
/* ##sys#syntax-error-hook */
t8=C_retrieve(lf[52]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t1,lf[251],t2);}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[250],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t8));}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t4,a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=t1,a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* segment-template?2265 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8892 */
static void C_ccall f_8894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8894,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8897,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* segment-depth2266 */
t3=((C_word*)((C_word*)t0)[5])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9055,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* process-template2261 */
t4=((C_word*)((C_word*)t0)[11])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[14],((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9088,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9092,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
t4=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[12]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}}}}

/* k9090 in k8892 */
static void C_ccall f_9092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2261 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9086 in k8892 */
static void C_ccall f_9088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9088,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k9053 in k8892 */
static void C_ccall f_9055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9063,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* process-template2261 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9061 in k9053 in k8892 */
static void C_ccall f_9063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9063,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t3));}

/* k8895 in k8892 */
static void C_ccall f_8897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8897,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8903,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* free-meta-variables2263 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,t2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k8901 in k8895 in k8892 */
static void C_ccall f_8903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8903,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* ##sys#syntax-error-hook */
t2=C_retrieve(lf[52]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[11],lf[252],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* process-template2261 */
t4=((C_word*)((C_word*)t0)[9])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k8913 in k8901 in k8895 in k8892 */
static void C_ccall f_8915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8918,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
if(C_truep((C_word)C_i_symbolp(t1))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_8981(t6,(C_word)C_eqp(t1,t5));}
else{
t5=t3;
f_8981(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8981(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8981(t4,C_SCHEME_FALSE);}}

/* k8979 in k8913 in k8901 in k8895 in k8892 */
static void C_fcall f_8981(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8981,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_8918(t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}

/* k8994 in k8979 in k8913 in k8901 in k8895 in k8892 */
static void C_ccall f_8996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8996,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_8918(t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_fcall f_8918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8918,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8921,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8952,a[2]=t4,a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8952(t6,t2,((C_word*)t0)[2],t1);}

/* doloop2502 in k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_fcall f_8952(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8952,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[50],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t11=t1;
t12=t6;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k8919 in k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_ccall f_8921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* segment-tail2267 */
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8948 in k8919 in k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_ccall f_8950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8950,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8942,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8946,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* segment-tail2267 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k8944 in k8948 in k8919 in k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_ccall f_8946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2261 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8940 in k8948 in k8919 in k8916 in k8913 in k8901 in k8895 in k8892 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8942,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[50],t3));}

/* f_8640 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_8640(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8640,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[12]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8664,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* mapit2409 */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=t4,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* segment-pattern?2264 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8668 */
static void C_ccall f_8670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8670,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8679,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word)li97),tmp=(C_word)a,a+=8,tmp);
/* process-pattern2260 */
t4=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[7],t2,((C_word*)((C_word*)t0)[12])[1],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[14]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8730,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[14]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
/* process-pattern2260 */
t6=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[13]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[14]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8770,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(2)))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[14],t4);
t6=t3;
f_8770(t6,(C_word)C_eqp(t5,((C_word*)t0)[2]));}
else{
t4=t3;
f_8770(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}}}

/* k8768 in k8668 */
static void C_fcall f_8770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8770,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8780,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
t3=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8793,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[3],a[9]=((C_word)li98),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_8793(t5,((C_word*)t0)[6],C_fix(0));}}

/* lp in k8768 in k8668 */
static void C_fcall f_8793(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8793,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[8]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8807,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_vector_ref(((C_word*)t0)[6],t2);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
/* process-pattern2260 */
t9=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,((C_word*)t0)[2]);}}

/* k8805 in lp in k8768 in k8668 */
static void C_ccall f_8807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8811,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2444 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8793(t4,t2,t3);}

/* k8809 in k8805 in lp in k8768 in k8668 */
static void C_ccall f_8811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[67]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8778 in k8768 in k8668 */
static void C_ccall f_8780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8780,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
/* process-pattern2260 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k8728 in k8668 */
static void C_ccall f_8730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8734,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
/* process-pattern2260 */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[2]);}

/* k8732 in k8728 in k8668 */
static void C_ccall f_8734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[67]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8678 in k8668 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8679,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8687,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],t2);
if(C_truep(t4)){
t5=t3;
f_8687(t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=t3;
f_8687(t11,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t10));}}

/* k8685 in a8678 in k8668 */
static void C_fcall f_8687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* mapit2409 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8662 */
static void C_ccall f_8664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8664,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t2));}

/* f_8352 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_8352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8352,4,t0,t1,t2,t3);}
t4=(C_word)C_i_vector_length(t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8359,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t4,a[13]=t1,a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t6=(C_word)C_fixnum_difference(t4,C_fix(1));
t7=(C_word)C_i_vector_ref(t3,t6);
t8=t5;
f_8359(t8,(C_word)C_eqp(t7,((C_word*)t0)[2]));}
else{
t6=t5;
f_8359(t6,C_SCHEME_FALSE);}}

/* k8357 */
static void C_fcall f_8359(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8359,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[16])[1],t5);
t7=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t4,a[16]=((C_word*)t0)[15],a[17]=t6,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t1)){
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_fixnum_difference(((C_word*)t0)[12],C_fix(2));
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=t7;
f_8398(t13,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t12));}
else{
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=t7;
f_8398(t12,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t11));}}

/* k8396 in k8357 */
static void C_fcall f_8398(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8398,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8402,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[17],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8406,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8408,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word)li95),tmp=(C_word)a,a+=17,tmp));
t7=((C_word*)t5)[1];
f_8408(t7,t3,C_fix(0));}

/* lp in k8396 in k8357 */
static void C_fcall f_8408(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8408,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[15]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t5=t2;
t6=(C_word)C_eqp(t5,t4);
t7=(C_truep(t6)?((C_word*)t0)[14]:C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t12);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8468,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t10,a[6]=((C_word*)t0)[10],a[7]=t13,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8472,a[2]=t14,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t17);
t19=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t20=(C_word)C_i_vector_ref(((C_word*)t0)[4],t19);
/* process-match2257 */
t21=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t21))(4,t21,t15,t18,t20);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8539,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t10);
t12=(C_word)C_i_vector_ref(((C_word*)t0)[4],t2);
/* process-match2257 */
t13=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t13))(4,t13,t8,t11,t12);}}}

/* k8537 in lp in k8396 in k8357 */
static void C_ccall f_8539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8543,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2380 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8408(t4,t2,t3);}

/* k8541 in k8537 in lp in k8396 in k8357 */
static void C_ccall f_8543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[67]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8470 in lp in k8396 in k8357 */
static void C_ccall f_8472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8472,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k8466 in lp in k8396 in k8357 */
static void C_ccall f_8468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8468,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}

/* k8404 in k8396 in k8357 */
static void C_ccall f_8406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8400 in k8396 in k8357 */
static void C_ccall f_8402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8402,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST));}

/* f_8234 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_8234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8234,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8238,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
/* process-match2257 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t6,t3);}

/* k8236 */
static void C_ccall f_8238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[75],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8238,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t8,t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t6,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t4,t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t21);
t23=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,(C_word)C_a_i_cons(&a,2,t22,C_SCHEME_END_OF_LIST));}}

/* f_8013 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[40],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8013,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_symbolp(t3))){
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[16]))){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[250],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[15])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[14])[1],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}
else{
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* segment-pattern?2264 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k8061 */
static void C_ccall f_8063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8063,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-segment-match2258 */
t3=((C_word*)((C_word*)t0)[14])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[13],((C_word*)t0)[12],t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8111,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8115,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t9);
t11=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-match2257 */
t12=((C_word*)((C_word*)t0)[6])[1];
((C_proc4)C_retrieve_proc(t12))(4,t12,t8,t10,t11);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[15]))){
/* process-vector-match2259 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[15]);}
else{
t2=(C_word)C_i_nullp(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8177(t4,t2);}
else{
t4=(C_word)C_booleanp(((C_word*)t0)[15]);
t5=t3;
f_8177(t5,(C_truep(t4)?t4:(C_word)C_charp(((C_word*)t0)[15])));}}}}}

/* k8175 in k8061 */
static void C_fcall f_8177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8177,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}}

/* k8113 in k8061 */
static void C_ccall f_8115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8119,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8123,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* process-match2257 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t5,t6);}

/* k8121 in k8113 in k8061 */
static void C_ccall f_8123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8117 in k8113 in k8061 */
static void C_ccall f_8119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8109 in k8061 */
static void C_ccall f_8111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8111,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* f_7929 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7929,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=t3;
f_7936(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_7936(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_7936(t4,C_SCHEME_FALSE);}}

/* k7934 */
static void C_fcall f_7936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7936,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* cdar */
t3=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[10]);}
else{
/* ##sys#syntax-error-hook */
t2=C_retrieve(lf[52]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],lf[249],((C_word*)t0)[10]);}}

/* k7937 in k7934 */
static void C_ccall f_7939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7939,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7988,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* process-match2257 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t1);}

/* k7986 in k7937 in k7934 */
static void C_ccall f_7988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7982 in k7937 in k7934 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7984,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7965,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7979,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
/* process-pattern2260 */
t5=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],t4);}

/* a7978 in k7982 in k7937 in k7934 */
static void C_ccall f_7979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7979,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7963 in k7982 in k7937 in k7934 */
static void C_ccall f_7965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7973,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7977,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* meta-variables2262 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_SCHEME_END_OF_LIST);}

/* k7975 in k7963 in k7982 in k7937 in k7934 */
static void C_ccall f_7977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2261 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k7971 in k7963 in k7982 in k7937 in k7934 */
static void C_ccall f_7973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7973,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* f_7835 in k7830 in k7826 in k7822 in k7818 in k7813 in k7806 in k7802 in k7797 in k7793 in k7789 in k7785 in k7781 in k7775 in k7770 in k7766 in k7762 in k7748 in ##sys#process-syntax-rules in k7739 in k7736 in k7733 in k7730 in k7727 in k7724 in k7721 in k7718 in k7715 in k7712 in k7709 in k7706 in k7703 in k7700 in k7697 in k7694 in k7691 in k7687 in k7684 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[38],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7835,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t10,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7879,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* map */
t13=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)((C_word*)t0)[2])[1],t2);}

/* k7877 */
static void C_ccall f_7879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7879,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[248],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k7873 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t7));}

/* ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6841,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6845,a[2]=t3,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=t6,a[7]=t1,a[8]=t4,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 724  r */
t10=t3;
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[228]);}

/* k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 725  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[227]);}

/* k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 726  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[226]);}

/* k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 727  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[225]);}

/* k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6856,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6865,a[2]=((C_word*)t0)[11],a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6908,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6995,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[11],a[11]=t4,a[12]=((C_word)li85),tmp=(C_word)a,a+=13,tmp));
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 824  ##sys#check-syntax */
t9=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,((C_word*)t0)[11],((C_word*)t0)[3],lf[224]);}

/* k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 825  ##sys#current-module */
t3=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7660,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9524(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 831  append */
t6=*((C_word*)lf[67]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7675,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9506(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 834  append */
t6=*((C_word*)lf[67]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t4,t5);}}
else{
t3=t2;
f_7459(2,t3,C_SCHEME_UNDEFINED);}}

/* k7673 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(7),t1);}

/* k7658 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(8),t1);}

/* k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7462,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li88),tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7464,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7468,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 837  import-spec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6995(t4,t3,t2);}

/* k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7468,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7477,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[219],t5);
/* expand.scm: 840  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t4,t6);}

/* k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_truep(((C_word*)t0)[2])?f_9398(((C_word*)t0)[2]):lf[216]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7635,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 841  map-se */
f_3557(t4,((C_word*)t0)[3]);}

/* k7633 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[218],t3);
/* expand.scm: 841  dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7483,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(((C_word*)t0)[2])?f_9398(((C_word*)t0)[2]):lf[216]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7612,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 842  map-se */
f_3557(t4,((C_word*)t0)[5]);}

/* k7610 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7612,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[217],t3);
/* expand.scm: 842  dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[2],t4);}

/* k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 843  ##sys#mark-imported-symbols */
t3=C_retrieve(lf[215]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7558,a[2]=((C_word*)t0)[3],a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7557 in k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7558,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7592,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 848  import-env */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7590 in a7557 in k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(((C_word*)t0)[3],t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
/* expand.scm: 850  ##sys#warn */
t5=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[2],lf[214],((C_word*)t0)[4]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7487 in k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7516,a[2]=((C_word*)t0)[6],a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7515 in k7487 in k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7516,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7556,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 854  macro-env */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7554 in a7515 in k7487 in k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* expand.scm: 856  ##sys#warn */
t7=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],lf[213],t6);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7490 in k7487 in k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7495,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7510,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7514,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 858  import-env */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7512 in k7490 in k7487 in k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 858  append */
t2=*((C_word*)lf[67]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7508 in k7490 in k7487 in k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 858  import-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7493 in k7490 in k7487 in k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7502,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7506,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 859  macro-env */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7504 in k7493 in k7490 in k7487 in k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 859  append */
t2=*((C_word*)lf[67]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7500 in k7493 in k7490 in k7487 in k7484 in k7481 in k7478 in k7475 in k7466 in a7463 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 859  macro-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7460 in k7457 in k7454 in k7451 in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[212]);}

/* import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6995(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6995,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 757  import-name */
t3=((C_word*)t0)[11];
f_6908(t3,t1,t2);}
else{
t3=(C_word)C_i_listp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t4)){
t6=t5;
f_7014(t6,t4);}
else{
t6=(C_word)C_i_length(t2);
t7=t5;
f_7014(t7,(C_word)C_fixnum_lessp(t6,C_fix(2)));}}}

/* k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_7014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7014,NULL,2,t0,t1);}
if(C_truep(t1)){
/* expand.scm: 759  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[12],((C_word*)t0)[11],lf[201],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* expand.scm: 762  import-spec */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6995(t5,t3,t4);}}

/* k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7023,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 765  c */
t6=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}

/* k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7035,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7038,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 766  ##sys#check-syntax */
t3=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[9],lf[202]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 777  c */
t4=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7115,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7118,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 778  ##sys#check-syntax */
t3=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[8],lf[203]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* expand.scm: 788  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7222,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7225,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 789  ##sys#check-syntax */
t3=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[9],lf[209]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7369,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 814  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7367 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7369,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7372,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 815  ##sys#check-syntax */
t3=C_retrieve(lf[63]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[210]);}
else{
/* expand.scm: 823  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[7],((C_word*)t0)[2],lf[211],((C_word*)t0)[4]);}}

/* k7370 in k7367 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7375,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* expand.scm: 816  tostr */
t4=((C_word*)t0)[2];
f_6865(t4,t2,t3);}

/* k7373 in k7370 in k7367 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7377,a[2]=t1,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7408,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k7406 in k7373 in k7370 in k7367 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7412,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7410 in k7406 in k7373 in k7370 in k7367 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7412,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ren in k7373 in k7370 in k7367 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7377(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7377,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7385,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7393,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7397,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* expand.scm: 820  ##sys#symbol->string */
t7=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* k7395 in ren in k7373 in k7370 in k7367 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 820  ##sys#string-append */
t2=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7391 in ren in k7373 in k7370 in k7367 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 819  ##sys#string->symbol */
t2=C_retrieve(lf[73]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7383 in ren in k7373 in k7370 in k7367 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7385,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k7223 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7225,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7234,a[2]=t4,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7234(t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in k7223 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_7234(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7234,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7250,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7255,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t9=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7311,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t3,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 798  caar */
t8=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7363,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=t2,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 805  caar */
t8=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}}

/* k7361 in loop in k7223 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7363,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7344,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 808  cdar */
t6=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 811  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7234(t6,((C_word*)t0)[4],t3,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k7342 in k7361 in loop in k7223 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7344,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7332,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 810  ##sys#delq */
t5=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7330 in k7342 in k7361 in loop in k7223 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 807  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7234(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7309 in loop in k7223 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7311,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7292,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 802  cdar */
t6=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 804  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7234(t6,((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2],t5,((C_word*)t0)[8]);}}

/* k7290 in k7309 in loop in k7223 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7292,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7280,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 803  ##sys#delq */
t5=C_retrieve(lf[207]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7278 in k7290 in k7309 in loop in k7223 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 800  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7234(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7254 in loop in k7223 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7255,3,t0,t1,t2);}
/* expand.scm: 795  ##sys#warn */
t3=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[205],t2);}

/* k7248 in loop in k7223 in k7220 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7250,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k7116 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7121,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7119 in k7116 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7121,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7126,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li81),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7126(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k7119 in k7116 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_7126(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7126,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7138,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7138(t7,t1,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7212,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 786  caar */
t5=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7210 in loop in k7119 in k7116 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7212,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 786  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7126(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 787  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7126(t5,((C_word*)t0)[3],t2,t4);}}

/* loop in loop in k7119 in k7116 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_7138(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7138,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7180,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 784  caar */
t5=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k7178 in loop in loop in k7119 in k7116 in k7113 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7180,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 784  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7138(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 785  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7138(t5,((C_word*)t0)[3],t2,t4);}}

/* k7036 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7041,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7039 in k7036 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_7041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7041,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7046,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li79),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7046(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k7039 in k7036 in k7033 in k7021 in k7012 in import-spec in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_7046(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7046,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_assq(t5,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* expand.scm: 772  loop */
t15=t1;
t16=t7;
t17=t8;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_assq(t7,((C_word*)t0)[2]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t8,t4);
/* expand.scm: 775  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t10;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
/* expand.scm: 776  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}}

/* import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6908(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6908,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6912,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 737  resolve */
t4=((C_word*)t0)[2];
f_6856(3,t4,t3,t2);}

/* k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6915,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 738  ##sys#find-module */
t3=C_retrieve(lf[194]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_SCHEME_FALSE);}

/* k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6915,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6918,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t3)[1])){
t5=t4;
f_6918(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6989,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6993,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 741  symbol->string */
t8=*((C_word*)lf[146]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[3]);}}

/* k6991 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 741  string-append */
t2=*((C_word*)lf[41]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[200]);}

/* k6987 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 740  ##sys#find-extension */
t2=C_retrieve(lf[199]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6930,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[80]);
t3=C_retrieve(lf[8]);
t4=C_retrieve(lf[9]);
t5=C_retrieve(lf[28]);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6936,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t3,a[8]=t4,a[9]=t5,a[10]=t9,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 745  ##sys#current-meta-environment */
t11=C_retrieve(lf[9]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}
else{
/* expand.scm: 750  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[198],((C_word*)t0)[3]);}}

/* k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6936,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 746  ##sys#meta-macro-environment */
t5=C_retrieve(lf[197]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6939,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6940,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word)li76),tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6972,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6978,a[2]=((C_word*)t0)[2],a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t7=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t4,t6,t4);}

/* a6977 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6978,2,t0,t1);}
/* expand.scm: 747  ##sys#load */
t2=C_retrieve(lf[195]);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k6970 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 748  ##sys#find-module */
t3=C_retrieve(lf[194]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6974 in k6970 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6918(2,t3,t2);}

/* swap1375 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* g137813791394 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6942 in swap1375 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* g137813791394 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[10])[1]);}

/* k6945 in k6942 in swap1375 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6947,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g138013811395 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6949 in k6945 in k6942 in swap1375 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6954,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g138013811395 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k6952 in k6949 in k6945 in k6942 in swap1375 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6954,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g138213831396 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6956 in k6952 in k6949 in k6945 in k6942 in swap1375 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g138213831396 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k6959 in k6956 in k6952 in k6949 in k6945 in k6942 in swap1375 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6961,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g138413851397 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6963 in k6959 in k6956 in k6952 in k6949 in k6945 in k6942 in swap1375 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6968,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g138413851397 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k6966 in k6963 in k6959 in k6956 in k6952 in k6949 in k6945 in k6942 in swap1375 in k6937 in k6934 in k6928 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6916 in k6913 in k6910 in import-name in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6918,2,t0,t1);}
t2=f_9560(((C_word*)((C_word*)t0)[3])[1]);
t3=f_9578(((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* tostr in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6865(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6865,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6878,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 732  keyword? */
t4=C_retrieve(lf[145]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k6876 in tostr in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6878,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6885,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 732  ##sys#symbol->string */
t3=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* expand.scm: 733  ##sys#symbol->string */
t2=C_retrieve(lf[190]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
/* expand.scm: 734  number->string */
C_number_to_string(3,0,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* expand.scm: 735  syntax-error */
t2=C_retrieve(lf[142]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[191]);}}}}

/* k6883 in k6876 in tostr in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 732  ##sys#string-append */
t2=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[189]);}

/* resolve in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6856(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6856,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6860,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 729  lookup */
f_3490(t3,t2,C_SCHEME_END_OF_LIST);}

/* k6858 in resolve in k6852 in k6849 in k6846 in k6843 in ##sys#expand-import in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##sys#er-transformer in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6547,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6549,a[2]=t2,a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp));}

/* f_6549 in ##sys#er-transformer in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6549(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6549,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6552,a[2]=t3,a[3]=t6,a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6815,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6678,a[2]=t4,a[3]=t8,a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 718  handler */
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t1,t2,t7,t9);}

/* compare */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6678,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6682,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_symbolp(t2);
t6=(C_truep(t5)?(C_word)C_i_symbolp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6711,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 689  ##sys#get */
t8=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t2,lf[12]);}
else{
t7=t4;
f_6682(t7,(C_word)C_eqp(t2,t3));}}

/* k6709 in compare */
static void C_ccall f_6711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6714(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6801,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 690  lookup2 */
f_6815(t3,C_fix(1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k6799 in k6709 in compare */
static void C_ccall f_6801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6714(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6712 in k6709 in compare */
static void C_fcall f_6714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6714,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 692  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[12]);}

/* k6715 in k6712 in k6709 in compare */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6720,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6720(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6795,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 693  lookup2 */
f_6815(t3,C_fix(2),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6793 in k6715 in k6712 in k6709 in compare */
static void C_ccall f_6795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6720(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6718 in k6715 in k6712 in k6709 in compare */
static void C_fcall f_6720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6720,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6739,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 697  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[83]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6766,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 699  ##sys#macro-environment */
t3=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}
else{
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 703  ##sys#macro-environment */
t3=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_6682(t2,(C_word)C_eqp(((C_word*)t0)[3],t1));}}}

/* k6787 in k6718 in k6715 in k6712 in k6709 in compare */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6682(t4,(C_word)C_eqp(((C_word*)t0)[2],t3));}
else{
t3=((C_word*)t0)[3];
f_6682(t3,C_SCHEME_FALSE);}}

/* k6764 in k6718 in k6715 in k6712 in k6709 in compare */
static void C_ccall f_6766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6682(t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[3];
f_6682(t3,C_SCHEME_FALSE);}}

/* k6737 in k6718 in k6715 in k6712 in k6709 in compare */
static void C_ccall f_6739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6739,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6746,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 698  ##sys#get */
t4=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],lf[83]);}

/* k6744 in k6737 in k6718 in k6715 in k6712 in k6709 in compare */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_6682(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k6680 in compare */
static void C_fcall f_6682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6682,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6685,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[46],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[186],t6);
/* expand.scm: 708  dd */
t8=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t8))(3,t8,t2,t7);}

/* k6683 in k6680 in compare */
static void C_ccall f_6685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup2 */
static void C_fcall f_6815(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6815,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6819,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 711  lookup */
f_3490(t5,t3,t4);}

/* k6817 in lookup2 */
static void C_ccall f_6819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6822,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t4=(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE);
t5=(C_truep(t4)?lf[14]:t1);
/* expand.scm: 712  dd */
t6=C_retrieve2(lf[6],"dd");
((C_proc9)C_retrieve_proc(t6))(9,t6,t2,lf[182],t3,lf[183],((C_word*)t0)[2],lf[184],t5,lf[185]);}

/* k6820 in k6817 in lookup2 */
static void C_ccall f_6822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* rename */
static void C_ccall f_6552(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6552,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6562,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[46],t6);
t8=(C_word)C_a_i_cons(&a,2,t2,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[178],t8);
/* expand.scm: 669  dd */
t10=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t10))(3,t10,t4,t9);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 671  lookup */
f_3490(t4,t2,((C_word*)t0)[2]);}}

/* k6586 in rename */
static void C_ccall f_6588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6588,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6600,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[46],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[179],t5);
/* expand.scm: 674  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6619,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 677  macro-alias */
f_3508(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6649,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 682  macro-alias */
f_3508(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6647 in k6586 in rename */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[46],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[181],t5);
/* expand.scm: 683  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}

/* k6650 in k6647 in k6586 in rename */
static void C_ccall f_6652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6652,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6617 in k6586 in rename */
static void C_ccall f_6619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[46],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[180],t5);
/* expand.scm: 678  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,t6);}

/* k6620 in k6617 in k6586 in rename */
static void C_ccall f_6622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6622,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6598 in k6586 in rename */
static void C_ccall f_6600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6560 in rename */
static void C_ccall f_6562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr5r,(void*)f_6085r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6085r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6085r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6087,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word)li65),tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6490,a[2]=t6,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6499,a[2]=t7,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-culprit9911149 */
t9=t8;
f_6499(t9,t1);}
else{
t9=(C_word)C_i_car(t5);
t10=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-se9921145 */
t11=t7;
f_6490(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body989998 */
t13=t6;
f_6087(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-culprit991 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6499,NULL,2,t0,t1);}
/* def-se9921145 */
t2=((C_word*)t0)[2];
f_6490(t2,t1,C_SCHEME_FALSE);}

/* def-se992 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6490(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6490,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6498,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 583  ##sys#current-environment */
t4=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6496 in def-se992 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body989998 */
t2=((C_word*)t0)[4];
f_6087(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6087(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6087,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6102,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word)li56),tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6090,a[2]=t4,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6133,a[2]=((C_word*)t0)[3],a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6189,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t3,a[6]=t6,a[7]=t7,a[8]=t5,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t9=C_mutate((C_word*)lf[139]+1 /* (set! syntax-error-culprit ...) */,t2);
t10=t8;
f_6218(t10,t9);}
else{
t9=t8;
f_6218(t9,C_SCHEME_UNDEFINED);}}

/* k6216 in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6218,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6223,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],a[8]=((C_word)li64),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6223(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k6216 in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6223(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a;
loop:
a=C_alloc(19);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6223,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t3))){
t4=(C_word)C_i_vector_ref(t3,C_fix(0));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6242,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_eqp(t5,C_fix(1));
if(C_truep(t9)){
t10=t8;
f_6242(t10,C_fix(1));}
else{
t10=(C_word)C_fixnum_greaterp(t5,C_fix(2));
t11=t8;
f_6242(t11,(C_truep(t10)?(C_word)C_i_vector_ref(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_immp(t3))){
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 636  err */
t5=((C_word*)t0)[7];
f_6102(t5,t1,lf[155]);}}
else{
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t3;
t5=(C_word)C_eqp(t4,lf[56]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t4,lf[156]);
if(C_truep(t6)){
/* expand.scm: 640  test */
t7=((C_word*)t0)[5];
f_6090(t7,t1,t2,*((C_word*)lf[157]+1),lf[158]);}
else{
t7=(C_word)C_eqp(t4,lf[159]);
if(C_truep(t7)){
/* expand.scm: 641  test */
t8=((C_word*)t0)[5];
f_6090(t8,t1,t2,*((C_word*)lf[160]+1),lf[161]);}
else{
t8=(C_word)C_eqp(t4,lf[162]);
if(C_truep(t8)){
/* expand.scm: 642  test */
t9=((C_word*)t0)[5];
f_6090(t9,t1,t2,*((C_word*)lf[160]+1),lf[163]);}
else{
t9=(C_word)C_eqp(t4,lf[164]);
if(C_truep(t9)){
/* expand.scm: 643  test */
t10=((C_word*)t0)[5];
f_6090(t10,t1,t2,((C_word*)t0)[4],lf[165]);}
else{
t10=(C_word)C_eqp(t4,lf[166]);
if(C_truep(t10)){
/* expand.scm: 644  test */
t11=((C_word*)t0)[5];
f_6090(t11,t1,t2,*((C_word*)lf[167]+1),lf[168]);}
else{
t11=(C_word)C_eqp(t4,lf[169]);
if(C_truep(t11)){
/* expand.scm: 645  test */
t12=((C_word*)t0)[5];
f_6090(t12,t1,t2,*((C_word*)lf[170]+1),lf[171]);}
else{
t12=(C_word)C_eqp(t4,lf[172]);
if(C_truep(t12)){
/* expand.scm: 646  test */
t13=((C_word*)t0)[5];
f_6090(t13,t1,t2,((C_word*)t0)[3],lf[173]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 648  test */
t14=((C_word*)t0)[5];
f_6090(t14,t1,t2,t13,lf[174]);}}}}}}}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6461,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 658  walk */
t26=t4;
t27=t5;
t28=t6;
t1=t26;
t2=t27;
t3=t28;
goto loop;}
else{
/* expand.scm: 656  err */
t4=((C_word*)t0)[7];
f_6102(t4,t1,lf[175]);}}
else{
/* expand.scm: 655  err */
t4=((C_word*)t0)[7];
f_6102(t4,t1,lf[176]);}}}}}

/* k6459 in walk in k6216 in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 659  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6223(t4,((C_word*)t0)[2],t2,t3);}

/* a6419 in walk in k6216 in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6420,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6424,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 651  lookup */
f_3490(t3,t2,((C_word*)t0)[2]);}
else{
t4=t3;
f_6424(2,t4,C_SCHEME_FALSE);}}

/* k6422 in a6419 in walk in k6216 in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}

/* k6240 in walk in k6216 in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6242,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6247,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li62),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6247(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop1102 in k6240 in walk in k6216 in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6247(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6247,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* expand.scm: 629  err */
t5=((C_word*)t0)[6];
f_6102(t5,t1,lf[152]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6266,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* expand.scm: 631  err */
t6=((C_word*)t0)[6];
f_6102(t6,t5,lf[153]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
/* expand.scm: 634  walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6223(t7,t5,t6,((C_word*)t0)[2]);}
else{
/* expand.scm: 633  err */
t6=((C_word*)t0)[6];
f_6102(t6,t5,lf[154]);}}}}

/* k6264 in doloop1102 in k6240 in walk in k6216 in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6247(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6189,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6195,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_6195(t2));}

/* loop in proper-list? in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static C_word C_fcall f_6195(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6133,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6137,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 598  ##sys#extended-lambda-list? */
t4=C_retrieve(lf[88]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6135 in lambda-list? in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6137,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6145,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6145(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k6135 in lambda-list? in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6145(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6145,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6165,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 601  keyword? */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 605  loop */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k6163 in loop in k6135 in lambda-list? in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6090(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6090,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6097,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 586  pred */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k6095 in test in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 586  err */
t2=((C_word*)t0)[3];
f_6102(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_6102(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6102,NULL,3,t0,t1,t2);}
t3=C_retrieve(lf[139]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 590  get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6104 in err in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6113,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6120,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 593  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6131,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 594  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k6129 in k6104 in err in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 594  string-append */
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[150],t1,lf[151],((C_word*)t0)[2]);}

/* k6118 in k6104 in err in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6124,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 593  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k6122 in k6118 in k6104 in err in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 593  string-append */
t2=((C_word*)t0)[5];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],lf[147],((C_word*)t0)[3],lf[148],t1,lf[149],((C_word*)t0)[2]);}

/* k6111 in k6104 in err in body989 in ##sys#check-syntax in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 591  ##sys#syntax-error-hook */
t2=C_retrieve(lf[52]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6049,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[138]))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6071,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 572  ##sys#hash-table-ref */
t5=C_retrieve(lf[144]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[138]),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6069 in get-line-number in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6038r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6038r(t0,t1,t2);}}

static void C_ccall f_6038r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6046,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 563  ##sys#strip-syntax */
t4=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6044 in ##sys#syntax-error-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],C_retrieve(lf[140]),lf[141],t1);}

/* ##sys#expand-curried-define in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5968,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5971,a[2]=t8,a[3]=t6,a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6031,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 552  loop */
t11=((C_word*)t8)[1];
f_5971(t11,t10,t2,t3);}

/* k6029 in ##sys#expand-curried-define in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6031,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5971(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5971,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_i_cdr(t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5997,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t9=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6024,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t3,C_SCHEME_END_OF_LIST);}}

/* k6022 in loop in ##sys#expand-curried-define in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6024,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* expand.scm: 551  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5971(t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k5995 in loop in ##sys#expand-curried-define in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5997,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[97],t2));}

/* match-expression in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5885(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5885,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5888,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5966,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 539  mwalk */
t11=((C_word*)t8)[1];
f_5888(t11,t10,t2,t3);}

/* k5964 in match-expression in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in match-expression in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5888(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5888,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5937,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 536  mwalk */
t13=t4;
t14=t5;
t15=t6;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_i_assq(t3,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t2,t5));}
else{
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[2]))){
t5=(C_word)C_a_i_cons(&a,2,t3,t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}}

/* k5935 in mwalk in match-expression in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 537  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5888(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5132r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5132r(t0,t1,t2,t3);}}

static void C_ccall f_5132r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5136,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 413  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5136(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5136,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5138,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t7,a[6]=((C_word)li43),tmp=(C_word)a,a+=7,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5398,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li45),tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5575,a[2]=t3,a[3]=t5,a[4]=t1,a[5]=((C_word)li48),tmp=(C_word)a,a+=6,tmp));
/* expand.scm: 520  expand */
t11=((C_word*)t7)[1];
f_5575(t11,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5575(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5575,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5581(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5581(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5581,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_i_car(t7):C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t1,a[7]=t6,a[8]=t5,a[9]=t8,a[10]=((C_word*)t0)[4],a[11]=t4,a[12]=t3,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t10)){
if(C_truep((C_word)C_i_symbolp(t10))){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5845,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 480  lookup */
f_3490(t12,t10,((C_word*)t0)[5]);}
else{
t12=t11;
f_5603(t12,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5603(t12,C_SCHEME_FALSE);}}
else{
/* expand.scm: 474  fini */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5138(t7,t1,t3,t4,t5,t6,t2);}}

/* k5843 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5603(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5603,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(C_word)C_eqp(lf[117],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5621,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 483  ##sys#check-syntax */
t4=C_retrieve(lf[63]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[117],((C_word*)t0)[5],lf[133],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t3=(C_word)C_eqp(lf[124],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5747,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 505  ##sys#check-syntax */
t5=C_retrieve(lf[63]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[124],((C_word*)t0)[5],lf[134],((C_word*)t0)[13]);}
else{
t4=(C_word)C_eqp(lf[118],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5759,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 508  ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[118],((C_word*)t0)[5],lf[135],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t5=(C_word)C_eqp(lf[116],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5787,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 511  ##sys#check-syntax */
t7=C_retrieve(lf[63]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t6,lf[116],((C_word*)t0)[5],lf[136],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t6=(C_word)C_i_memq(t1,((C_word*)t0)[12]);
t7=(C_truep(t6)?t6:(C_word)C_i_memq(t1,((C_word*)t0)[8]));
if(C_truep(t7)){
/* expand.scm: 514  fini */
t8=((C_word*)((C_word*)t0)[2])[1];
f_5138(t8,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5813,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 516  ##sys#expand-0 */
t9=C_retrieve(lf[37]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[5],((C_word*)t0)[13]);}}}}}}
else{
/* expand.scm: 481  fini */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5138(t2,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}}

/* k5811 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5813,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* expand.scm: 518  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_5138(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* expand.scm: 519  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5581(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k5785 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5794,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 512  ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k5792 in k5785 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 512  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5581(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5757 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5759,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* expand.scm: 509  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_5581(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k5745 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 506  fini/syntax */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5398(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5619 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5621,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5626,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li46),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5626(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k5619 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5626(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5626,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5673,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 495  ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[117],t2,lf[129],C_SCHEME_FALSE,((C_word*)t0)[8]);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5695,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 499  ##sys#check-syntax */
t6=C_retrieve(lf[63]);
((C_proc7)C_retrieve_proc(t6))(7,t6,t5,lf[117],t2,lf[130],C_SCHEME_FALSE,((C_word*)t0)[8]);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 487  ##sys#check-syntax */
t5=C_retrieve(lf[63]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t4,lf[117],t2,lf[132],C_SCHEME_FALSE,((C_word*)t0)[8]);}}

/* k5637 in loop2 in k5619 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5639,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[8]):lf[131]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* expand.scm: 488  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_5581(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5693 in loop2 in k5619 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5695,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k5720 in k5693 in loop2 in k5619 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5722,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
/* expand.scm: 500  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5581(t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5671 in loop2 in k5619 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 496  macro-alias */
f_3508(t2,lf[117],((C_word*)t0)[2]);}

/* k5682 in k5671 in loop2 in k5619 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5688,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* expand.scm: 497  ##sys#expand-curried-define */
t4=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5686 in k5682 in k5671 in loop2 in k5619 in k5601 in loop in expand in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5688,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 496  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5626(t3,((C_word*)t0)[2],t2);}

/* fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5398(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5398,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5406,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5408,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li44),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5408(t11,t7,t6,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5408(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(19);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5408,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5423,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 455  macro-alias */
f_3508(t5,lf[123],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5454,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_length(t7);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_fix(3),t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 460  caar */
t10=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}
else{
t9=t5;
f_5454(t9,C_SCHEME_FALSE);}}
else{
t7=t5;
f_5454(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 457  loop */
t12=t1;
t13=t2;
t14=t3;
t15=C_SCHEME_TRUE;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}}

/* k5555 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5553,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 461  caar */
t4=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
f_5454(t2,C_SCHEME_FALSE);}}

/* k5551 in k5555 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 461  lookup */
f_3490(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5541 in k5555 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5546,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5546(2,t3,t1);}
else{
/* expand.scm: 461  caar */
t3=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k5544 in k5541 in k5555 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5454(t2,(C_word)C_eqp(lf[124],t1));}

/* k5452 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5454,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5472,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5486,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 466  caadr */
t7=*((C_word*)lf[127]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}
else{
t6=t4;
f_5472(t6,t2);}}
else{
/* expand.scm: 470  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5408(t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_TRUE);}}

/* k5484 in k5452 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5498,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 466  macro-alias */
f_3508(t2,lf[126],((C_word*)t0)[2]);}

/* k5496 in k5484 in k5452 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 466  cdadr */
t3=*((C_word*)lf[125]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5504 in k5496 in k5484 in k5452 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5508 in k5504 in k5496 in k5484 in k5452 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5510,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
f_5472(t6,(C_word)C_a_i_cons(&a,2,lf[124],t5));}

/* k5470 in k5452 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5472,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* expand.scm: 463  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5408(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k5421 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5431,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5439,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 456  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5437 in k5421 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 456  map */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[122]+1),t1);}

/* k5429 in k5421 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5433 in k5429 in k5421 in loop in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5435,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k5404 in fini/syntax in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 452  fini */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5138(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5138(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5138,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5150,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li38),tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_5150(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5249,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 431  reverse */
t10=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}

/* k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5271,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5378,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5390,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[50]+1),t1,((C_word*)t0)[3]);}

/* k5388 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 434  ##sys#map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5377 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5378,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[121]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5275,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5360,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5376,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 436  reverse */
t6=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5374 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 436  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5359 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5360,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[70],t5));}

/* k5277 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5283,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5287,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5293,a[2]=((C_word*)t0)[5],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5354,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 446  reverse */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5352 in k5277 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5358,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 447  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5356 in k5352 in k5277 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 437  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5292 in k5277 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5293,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5297,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 438  ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[18]),t2);}

/* k5295 in a5292 in k5277 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5297,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5324,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5328,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5330,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 443  map */
t8=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a5329 in k5295 in a5292 in k5277 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5330,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[70],t5));}

/* k5326 in k5295 in a5292 in k5277 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5322 in k5295 in a5292 in k5277 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[120],t5));}

/* k5285 in k5277 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5291,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5289 in k5285 in k5277 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5281 in k5277 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5273 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5275,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[58],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5255,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[119],t5);
/* expand.scm: 449  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,t4,t6);}

/* k5253 in k5273 in k5269 in k5247 in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5150(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5150,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5173,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5239,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 425  lookup */
f_3490(t7,t6,((C_word*)t0)[4]);}
else{
t7=t5;
f_5173(t7,C_SCHEME_FALSE);}}
else{
t6=t5;
f_5173(t6,C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 419  macro-alias */
f_3508(t4,lf[116],((C_word*)t0)[4]);}}

/* k5162 in loop in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5164,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5237 in loop in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5239,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[117]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_5173(t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 426  lookup */
f_3490(t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k5230 in k5237 in loop in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_5173(t3,(C_word)C_eqp(t2,lf[118]));}

/* k5171 in loop in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5173,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5180,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 428  macro-alias */
f_3508(t2,lf[116],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]);
/* expand.scm: 430  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5150(t4,((C_word*)t0)[9],t2,t3);}}

/* k5178 in k5171 in loop in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5184,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5188,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 429  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5186 in k5178 in k5171 in loop in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5196,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 429  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5575(t3,t2,((C_word*)t0)[2]);}

/* k5194 in k5186 in k5178 in k5171 in loop in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5196,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* expand.scm: 429  ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5182 in k5178 in k5171 in loop in fini in k5134 in ##sys#canonicalize-body in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5184,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4542,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4545,a[2]=t2,a[3]=t4,a[4]=((C_word)li34),tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4562,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t10,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 320  macro-alias */
f_3508(t11,lf[113],t5);}

/* k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 322  macro-alias */
f_3508(t2,lf[112],((C_word*)t0)[4]);}

/* k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 323  macro-alias */
f_3508(t2,lf[111],((C_word*)t0)[4]);}

/* k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 324  macro-alias */
f_3508(t2,lf[110],((C_word*)t0)[4]);}

/* k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* expand.scm: 325  macro-alias */
f_3508(t2,lf[57],((C_word*)t0)[4]);}

/* k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4574,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word)li36),tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_4579(t5,((C_word*)t0)[3],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4579(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4579,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4593,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t5,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t4,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)((C_word*)t0)[13])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4846,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 333  reverse */
t9=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}
else{
/* expand.scm: 333  reverse */
t8=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* expand.scm: 361  err */
t7=((C_word*)t0)[4];
f_4545(t7,t1,lf[99]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4867,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[13])[1];
if(C_truep(t8)){
t9=t7;
f_4867(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t6);
t10=t7;
f_4867(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4890,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[3],a[11]=t2,a[12]=t6,a[13]=t7,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t7))){
/* expand.scm: 370  lookup */
f_3490(t8,t7,((C_word*)t0)[2]);}
else{
t9=t8;
f_4890(2,t9,C_SCHEME_FALSE);}}
else{
/* expand.scm: 367  err */
t7=((C_word*)t0)[4];
f_4545(t7,t1,lf[109]);}}}}

/* k4888 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[64],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4890,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[13]);
t3=(C_word)C_i_cdr(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t2,lf[90]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4905,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t6)){
t7=t5;
f_4905(t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4924,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 374  macro-alias */
f_3508(t7,lf[101],((C_word*)t0)[5]);}}
else{
t5=(C_word)C_eqp(t2,lf[89]);
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[11],C_fix(1)))){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[4],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_4942(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_4942(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 386  err */
t6=((C_word*)t0)[7];
f_4545(t6,((C_word*)t0)[9],lf[103]);}}
else{
t6=(C_word)C_eqp(t2,lf[91]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t8)){
t9=t7;
f_4988(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5007,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 388  macro-alias */
f_3508(t9,lf[101],((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t7=((C_word*)t0)[11];
switch(t7){
case C_fix(0):
t8=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
/* expand.scm: 395  loop */
t9=((C_word*)((C_word*)t0)[10])[1];
f_4579(t9,((C_word*)t0)[9],C_fix(0),t8,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3);
case C_fix(1):
t8=(C_word)C_a_i_list(&a,2,t2,C_SCHEME_FALSE);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[3]);
/* expand.scm: 396  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4579(t10,((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8],t9,C_SCHEME_END_OF_LIST,t3);
case C_fix(2):
/* expand.scm: 397  err */
t8=((C_word*)t0)[7];
f_4545(t8,((C_word*)t0)[9],lf[105]);
default:
t8=(C_word)C_a_i_list(&a,1,t2);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[2]);
/* expand.scm: 398  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4579(t10,((C_word*)t0)[9],C_fix(3),((C_word*)t0)[8],((C_word*)t0)[3],t9,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5069,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t8=(C_word)C_i_length(t2);
t9=t7;
f_5069(t9,(C_word)C_eqp(C_fix(2),t8));}
else{
t8=t7;
f_5069(t8,C_SCHEME_FALSE);}}}}}}

/* k5067 in k4888 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_5069(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5069,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* expand.scm: 401  err */
t3=((C_word*)t0)[9];
f_4545(t3,((C_word*)t0)[8],lf[106]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* expand.scm: 402  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4579(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* expand.scm: 403  err */
t3=((C_word*)t0)[9];
f_4545(t3,((C_word*)t0)[8],lf[107]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* expand.scm: 404  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4579(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* expand.scm: 405  err */
t2=((C_word*)t0)[9];
f_4545(t2,((C_word*)t0)[8],lf[108]);}}

/* k5005 in k4888 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4988(t3,t2);}

/* k4986 in k4888 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4988(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* expand.scm: 390  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_4579(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 391  err */
t2=((C_word*)t0)[2];
f_4545(t2,((C_word*)t0)[6],lf[104]);}}

/* k4940 in k4888 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4942,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4945,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_4945(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_4945(t6,t5);}}
else{
/* expand.scm: 385  err */
t2=((C_word*)t0)[2];
f_4545(t2,((C_word*)t0)[6],lf[102]);}}

/* k4943 in k4940 in k4888 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4945(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 384  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4579(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k4922 in k4888 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4905(t3,t2);}

/* k4903 in k4888 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4905(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* expand.scm: 376  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4579(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 377  err */
t3=((C_word*)t0)[2];
f_4545(t3,((C_word*)t0)[5],lf[100]);}}

/* k4865 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4867(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* expand.scm: 365  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4579(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k4844 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 333  ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4597,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t3=t2;
f_4597(t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[11],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4839,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 345  reverse */
t6=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}

/* k4837 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4765 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4766,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4835,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* expand.scm: 317  string->keyword */
t6=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k4833 in a4765 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4835,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4801,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4819,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t9=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t7=t5;
f_4801(t7,C_SCHEME_END_OF_LIST);}}

/* k4817 in k4833 in a4765 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4819,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=((C_word*)t0)[2];
f_4801(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4799 in k4833 in a4765 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4795 in k4833 in a4765 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4797,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[96],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k4758 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4764,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4762 in k4758 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4764,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4597(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4595 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4597,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4600,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[10]))){
t3=t2;
f_4600(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t4)){
t5=t3;
f_4609(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[10]);
t6=t3;
f_4609(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_4609(t5,C_SCHEME_FALSE);}}}}

/* k4607 in k4595 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4609,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 350  caar */
t3=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[5]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 354  reverse */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4712,a[2]=t4,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 357  reverse */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}}

/* k4710 in k4607 in k4595 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* expand.scm: 357  ##sys#append */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4702 in k4607 in k4595 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4706 in k4702 in k4607 in k4595 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4600(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4679 in k4607 in k4595 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4683 in k4679 in k4607 in k4595 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4685,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4600(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4634 in k4607 in k4595 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4656,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 350  cadar */
t3=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4654 in k4634 in k4607 in k4595 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4656,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4626 in k4654 in k4634 in k4607 in k4595 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4628,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4600(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4598 in k4595 in k4591 in loop in k4572 in k4569 in k4566 in k4563 in k4560 in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4600(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 332  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4545(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4545,NULL,3,t0,t1,t2);}
/* expand.scm: 316  errh */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4499,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4505,a[2]=t4,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4505(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4505(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4505,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[89]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4524,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4524(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[90]);
t7=t5;
f_4524(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[91])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4522 in loop in ##sys#extended-lambda-list? in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4524(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 310  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4505(t3,((C_word*)t0)[4],t2);}}

/* ##sys#expand in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4446r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4446r(t0,t1,t2,t3);}}

static void C_ccall f_4446r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4450,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 283  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4450(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4448 in ##sys#expand in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4450,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4455,a[2]=t3,a[3]=t1,a[4]=((C_word)li30),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4455(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4448 in ##sys#expand in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4455(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4455,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4461,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4467,a[2]=((C_word*)t0)[2],a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a4466 in loop in k4448 in ##sys#expand in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4467,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* expand.scm: 287  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4455(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a4460 in loop in k4448 in ##sys#expand in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4461,2,t0,t1);}
/* expand.scm: 285  ##sys#expand-0 */
t2=C_retrieve(lf[37]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4356,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4359,a[2]=t3,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4392,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 263  ##sys#qualified-symbol? */
t6=C_retrieve(lf[19]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k4390 in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 264  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[83]);}}

/* k4393 in k4390 in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4395,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4401,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 266  dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[81],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 268  ##sys#get */
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[85]);}}

/* k4405 in k4393 in k4390 in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4407,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 269  dm */
t3=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[82],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4444,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 271  ##sys#current-environment */
t3=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}}

/* k4442 in k4405 in k4393 in k4390 in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 273  dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[84],((C_word*)t0)[4]);}
else{
/* expand.scm: 278  mrename */
t3=((C_word*)t0)[3];
f_4359(t3,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k4417 in k4442 in k4405 in k4393 in k4390 in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4419,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t2))){
/* expand.scm: 276  mrename */
t3=((C_word*)t0)[4];
f_4359(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4434,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 277  ##sys#get */
t4=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[83]);}}

/* k4432 in k4417 in k4442 in k4405 in k4393 in k4390 in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4408 in k4405 in k4393 in k4390 in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4399 in k4393 in k4390 in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* mrename in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4359,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4363,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 257  ##sys#current-module */
t4=C_retrieve(lf[80]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k4361 in mrename in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4363,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=f_9398(t1);
/* expand.scm: 259  dm */
t4=C_retrieve2(lf[7],"dm");
((C_proc6)C_retrieve_proc(t4))(6,t4,t2,lf[78],((C_word*)t0)[3],lf[79],t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k4367 in k4361 in mrename in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4372,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4372(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 260  ##sys#register-undefined */
t3=C_retrieve(lf[77]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k4370 in k4367 in k4361 in mrename in ##sys#alias-global-hook in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_9398(((C_word*)t0)[4]);
/* expand.scm: 261  ##sys#module-rename */
t3=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* ##sys#module-rename in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4338,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4346,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 250  string-append */
t7=*((C_word*)lf[41]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t4,t5,lf[74],t6);}

/* k4344 in ##sys#module-rename in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 249  ##sys#string->symbol */
t2=C_retrieve(lf[73]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3856,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3859,a[2]=t3,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4038,a[2]=t4,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4155,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t7,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 215  lookup */
f_3490(t8,t6,t3);}
else{
/* expand.scm: 243  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* expand.scm: 244  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4155,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[7]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=t5;
f_4161(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4322,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4329,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 217  ##sys#macro-environment */
t8=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}}

/* k4327 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 217  lookup */
f_3490(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4320 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4161(t4,t3);}

/* k4159 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4161(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4161,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[57]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[58]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4170,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 219  ##sys#check-syntax */
t4=C_retrieve(lf[63]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[57],((C_word*)t0)[7],lf[65],C_SCHEME_FALSE,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4263,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t4,lf[68]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[70]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=t3;
f_4263(t6,(C_word)C_i_pairp(t5));}
else{
t5=t3;
f_4263(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4263(t5,C_SCHEME_FALSE);}}}

/* k4261 in k4159 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4263(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4263,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4269,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 236  ##sys#check-syntax */
t4=C_retrieve(lf[63]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[68],((C_word*)t0)[8],lf[69],C_SCHEME_FALSE,((C_word*)t0)[6]);}
else{
/* expand.scm: 242  expand */
t2=((C_word*)t0)[5];
f_4038(t2,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4267 in k4261 in k4159 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4276,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[66],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* expand.scm: 238  append */
t8=*((C_word*)lf[67]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t2,t5,t6,t7);}

/* k4274 in k4267 in k4261 in k4159 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 237  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k4168 in k4159 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4170,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4182,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 222  ##sys#check-syntax */
t4=C_retrieve(lf[63]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t3,lf[57],((C_word*)t0)[5],lf[64],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
/* expand.scm: 231  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4180 in k4168 in k4159 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4182,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4240,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4250,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a4249 in k4180 in k4168 in k4159 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4250,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k4238 in k4180 in k4168 in k4159 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4244,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k4242 in k4238 in k4180 in k4168 in k4159 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[59],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[60],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4204,a[2]=((C_word*)t0)[3],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4208,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 229  ##sys#map */
t12=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[62]+1),((C_word*)t0)[2]);}

/* k4206 in k4242 in k4238 in k4180 in k4168 in k4159 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4202 in k4242 in k4238 in k4180 in k4168 in k4159 in k4153 in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
/* expand.scm: 224  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4038(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4038,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4042,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4095,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 196  get */
t7=C_retrieve(lf[23]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,lf[12]);}

/* k4093 in expand in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_symbolp(t1);
t4=t2;
f_4098(t4,(C_truep(t3)?t1:lf[14]));}
else{
t3=t2;
f_4098(t3,lf[56]);}}

/* k4096 in k4093 in expand in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4098(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4098,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4120,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4124,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 201  map-se */
f_3557(t4,t5);}
else{
t3=t2;
f_4110(t3,((C_word*)t0)[2]);}}

/* k4122 in k4096 in k4093 in expand in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4118 in k4096 in k4093 in expand in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4120,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4110(t2,(C_word)C_a_i_cons(&a,2,lf[55],t1));}

/* k4108 in k4096 in k4093 in expand in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_4110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4110,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[54],t5);
/* expand.scm: 194  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[2],t6);}

/* k4040 in expand in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 208  call-handler */
t5=((C_word*)t0)[3];
f_3859(t5,t2,((C_word*)t0)[2],t3,((C_word*)t0)[6],t4);}
else{
/* expand.scm: 210  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[6],C_SCHEME_FALSE);}}
else{
/* expand.scm: 204  ##sys#syntax-error-hook */
t2=C_retrieve(lf[52]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],lf[53],((C_word*)t0)[6]);}}

/* k4062 in k4040 in expand in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 206  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_3859(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3859,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3863,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 161  dd */
t7=C_retrieve2(lf[6],"dd");
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[51],t2);}

/* k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4032,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4036,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 162  map-se */
f_3557(t4,((C_word*)t0)[3]);}

/* k4034 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4030 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4032,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[49],t1);
/* expand.scm: 162  dd */
t3=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3872,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li20),tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[48]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3874,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3880,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3987,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li19),tmp=(C_word)a,a+=9,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3986 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li16),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[2],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4013 in a3986 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4014r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4014r(t0,t1,t2);}}

static void C_ccall f_4014r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4020,a[2]=t2,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
/* k234239 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4019 in a4013 in a3986 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3992 in a3986 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3997,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 190  handler */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3995 in a3992 in a3986 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4000,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[46],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
/* expand.scm: 191  dd */
t6=C_retrieve2(lf[6],"dd");
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}

/* k3998 in k3995 in a3992 in a3986 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3879 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3880,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3886,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* k234239 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3885 in a3879 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3894,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[3],lf[39]))){
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=t3;
f_3897(t5,(C_word)C_i_memq(lf[45],t4));}
else{
t4=t3;
f_3897(t4,C_SCHEME_FALSE);}}

/* k3895 in a3885 in a3879 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_3897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3897,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3908,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3914,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3914(t8,t3,t4);}
else{
t2=((C_word*)t0)[3];
f_3894(t2,((C_word*)t0)[4]);}}

/* copy in k3895 in a3885 in a3879 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_3914(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3914,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_equalp(lf[44],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=t5;
f_3933(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_3933(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_3933(t6,C_SCHEME_FALSE);}}}

/* k3931 in copy in k3895 in a3885 in a3879 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_3933(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3933,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 182  string-append */
t5=*((C_word*)lf[41]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[42],t3,lf[43],t4);}
else{
/* expand.scm: 188  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3914(t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k3942 in k3931 in copy in k3895 in a3885 in a3879 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3944,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[40],t3));}

/* k3906 in k3895 in a3885 in a3879 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3908,2,t0,t1);}
t2=((C_word*)t0)[3];
f_3894(t2,(C_word)C_a_i_record(&a,3,lf[39],((C_word*)t0)[2],t1));}

/* k3892 in a3885 in a3879 in a3873 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_3894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 166  ##sys#abort */
t2=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3870 in k3864 in k3861 in call-handler in ##sys#expand-0 in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3847,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[36]);
/* expand.scm: 154  ##sys#unregister-macro */
t4=C_retrieve(lf[34]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* ##sys#unregister-macro in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3796,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3804,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3808,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 147  ##sys#macro-environment */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3806 in ##sys#unregister-macro in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3808,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3810,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3810(t5,((C_word*)t0)[2],t1);}

/* loop in k3806 in ##sys#unregister-macro in k3688 in k3486 in k3482 in k3455 */
static void C_fcall f_3810(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3810,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 149  caar */
t4=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}

/* k3843 in loop in k3806 in ##sys#unregister-macro in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3837,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 150  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3810(t6,t4,t5);}}

/* k3835 in k3843 in loop in k3806 in ##sys#unregister-macro in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3837,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3802 in ##sys#unregister-macro in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 145  ##sys#macro-environment */
t2=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* macro? in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3740r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3740r(t0,t1,t2,t3);}}

static void C_ccall f_3740r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3744,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 136  ##sys#current-environment */
t5=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3744(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3742 in macro? in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[3],lf[33]);
t3=(C_word)C_i_check_list_2(t1,lf[33]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 139  lookup */
f_3490(t4,((C_word*)t0)[3],t1);}

/* k3751 in k3742 in macro? in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3753,2,t0,t1);}
t2=(C_word)C_i_pairp(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3762,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3772,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 141  ##sys#macro-environment */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k3770 in k3751 in k3742 in macro? in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 141  lookup */
f_3490(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3760 in k3751 in k3742 in macro? in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE));}

/* ##sys#copy-macro in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3727,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3731,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3738,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 133  ##sys#macro-environment */
t6=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3736 in ##sys#copy-macro in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 133  lookup */
f_3490(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3729 in ##sys#copy-macro in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],C_retrieve(lf[31]),((C_word*)t0)[2],t1);}

/* ##sys#extend-macro-environment in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3694,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3698,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 122  ##sys#macro-environment */
t6=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3696 in ##sys#extend-macro-environment in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3701,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 123  lookup */
f_3490(t2,((C_word*)t0)[2],t1);}

/* k3699 in k3696 in ##sys#extend-macro-environment in k3688 in k3486 in k3482 in k3455 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3701,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_set_car(t1,((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(t1);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[4]));}
else{
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
/* expand.scm: 128  ##sys#macro-environment */
t4=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[5],t3);}}

/* ##sys#strip-syntax in k3486 in k3482 in k3455 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3587r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3587r(t0,t1,t2,t3);}}

static void C_ccall f_3587r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3591,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3591(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3591(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3589 in ##sys#strip-syntax in k3486 in k3482 in k3455 */
static void C_ccall f_3591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3591,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3596,a[2]=t3,a[3]=t1,a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3596(3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k3589 in ##sys#strip-syntax in k3486 in k3482 in k3455 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(16);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3596,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3606,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* expand.scm: 100  lookup */
f_3490(t3,t2,((C_word*)t0)[3]);}
else{
/* expand.scm: 101  get */
t4=C_retrieve(lf[23]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[12]);}}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* expand.scm: 106  walk */
t9=t3;
t10=t4;
t1=t9;
t2=t10;
c=3;
goto loop;}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3662,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3666,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 109  vector->list */
t5=*((C_word*)lf[25]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}}

/* k3664 in walk in k3589 in ##sys#strip-syntax in k3486 in k3482 in k3455 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3660 in walk in k3589 in ##sys#strip-syntax in k3486 in k3482 in k3455 */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 109  list->vector */
t2=*((C_word*)lf[24]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3635 in walk in k3589 in ##sys#strip-syntax in k3486 in k3482 in k3455 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3641,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 107  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3596(3,t4,t2,t3);}

/* k3639 in k3635 in walk in k3589 in ##sys#strip-syntax in k3486 in k3482 in k3455 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3641,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3604 in walk in k3589 in ##sys#strip-syntax in k3486 in k3482 in k3455 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_i_pairp(t1);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?((C_word*)t0)[2]:t1));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* map-se in k3486 in k3482 in k3455 */
static void C_fcall f_3557(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3557,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3563,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a3562 in map-se in k3486 in k3482 in k3455 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3563,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_symbolp(t4);
t6=(C_truep(t5)?(C_word)C_i_cdr(t2):lf[14]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t3,t6));}

/* macro-alias in k3486 in k3482 in k3455 */
static void C_fcall f_3508(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3508,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3515,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 75   ##sys#qualified-symbol? */
t5=C_retrieve(lf[19]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3513 in macro-alias in k3486 in k3482 in k3455 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3518(t3,t1);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(C_word)C_fixnum_greaterp(t4,C_fix(0));
t6=t2;
f_3518(t6,(C_truep(t5)?(C_word)C_eqp(C_make_character(35),(C_word)C_subchar(t3,C_fix(0))):C_SCHEME_FALSE));}}

/* k3516 in k3513 in macro-alias in k3486 in k3482 in k3455 */
static void C_fcall f_3518(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3518,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 81   gensym */
t3=C_retrieve(lf[18]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3519 in k3516 in k3513 in macro-alias in k3486 in k3482 in k3455 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3524,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 82   lookup */
f_3490(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k3522 in k3519 in k3516 in k3513 in macro-alias in k3486 in k3482 in k3455 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3524,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3530,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 83   ##sys#put! */
t4=C_retrieve(lf[17]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[12],t2);}

/* k3528 in k3522 in k3519 in k3516 in k3513 in macro-alias in k3486 in k3482 in k3455 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_pairp(((C_word*)t0)[2]);
t4=(C_truep(t3)?lf[14]:((C_word*)t0)[2]);
/* expand.scm: 84   dd */
t5=C_retrieve2(lf[6],"dd");
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[15],((C_word*)t0)[3],lf[16],t4);}

/* k3531 in k3528 in k3522 in k3519 in k3516 in k3513 in macro-alias in k3486 in k3482 in k3455 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup in k3486 in k3482 in k3455 */
static void C_fcall f_3490(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3490,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cdr(t4));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3503,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 71   ##sys#get */
t6=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[12]);}}

/* k3501 in lookup in k3486 in k3482 in k3455 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:C_SCHEME_FALSE));}

/* d in k3455 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3459r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3459r(t0,t1,t2,t3);}}

static void C_ccall f_3459r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_fudge(C_fix(13)))){
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 43   pp */
t4=C_retrieve(lf[4]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}
else{
C_apply(5,0,t1,*((C_word*)lf[5]+1),t2,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[854] = {
{"toplevelexpand.scm",(void*)C_expand_toplevel},
{"f_3457expand.scm",(void*)f_3457},
{"f_3484expand.scm",(void*)f_3484},
{"f_3488expand.scm",(void*)f_3488},
{"f_3690expand.scm",(void*)f_3690},
{"f_13471expand.scm",(void*)f_13471},
{"f_13469expand.scm",(void*)f_13469},
{"f_7686expand.scm",(void*)f_7686},
{"f_13461expand.scm",(void*)f_13461},
{"f_13459expand.scm",(void*)f_13459},
{"f_7689expand.scm",(void*)f_7689},
{"f_7693expand.scm",(void*)f_7693},
{"f_13319expand.scm",(void*)f_13319},
{"f_13329expand.scm",(void*)f_13329},
{"f_13345expand.scm",(void*)f_13345},
{"f_13348expand.scm",(void*)f_13348},
{"f_13376expand.scm",(void*)f_13376},
{"f_13351expand.scm",(void*)f_13351},
{"f_13398expand.scm",(void*)f_13398},
{"f_13401expand.scm",(void*)f_13401},
{"f_13447expand.scm",(void*)f_13447},
{"f_13404expand.scm",(void*)f_13404},
{"f_13427expand.scm",(void*)f_13427},
{"f_13439expand.scm",(void*)f_13439},
{"f_13385expand.scm",(void*)f_13385},
{"f_13388expand.scm",(void*)f_13388},
{"f_13395expand.scm",(void*)f_13395},
{"f_13317expand.scm",(void*)f_13317},
{"f_7696expand.scm",(void*)f_7696},
{"f_13260expand.scm",(void*)f_13260},
{"f_13289expand.scm",(void*)f_13289},
{"f_13309expand.scm",(void*)f_13309},
{"f_13313expand.scm",(void*)f_13313},
{"f_13258expand.scm",(void*)f_13258},
{"f_7699expand.scm",(void*)f_7699},
{"f_13170expand.scm",(void*)f_13170},
{"f_13195expand.scm",(void*)f_13195},
{"f_13202expand.scm",(void*)f_13202},
{"f_13222expand.scm",(void*)f_13222},
{"f_13242expand.scm",(void*)f_13242},
{"f_13246expand.scm",(void*)f_13246},
{"f_13168expand.scm",(void*)f_13168},
{"f_7702expand.scm",(void*)f_7702},
{"f_12837expand.scm",(void*)f_12837},
{"f_12844expand.scm",(void*)f_12844},
{"f_12847expand.scm",(void*)f_12847},
{"f_12850expand.scm",(void*)f_12850},
{"f_12853expand.scm",(void*)f_12853},
{"f_12856expand.scm",(void*)f_12856},
{"f_12859expand.scm",(void*)f_12859},
{"f_12862expand.scm",(void*)f_12862},
{"f_12867expand.scm",(void*)f_12867},
{"f_12883expand.scm",(void*)f_12883},
{"f_12889expand.scm",(void*)f_12889},
{"f_12931expand.scm",(void*)f_12931},
{"f_12999expand.scm",(void*)f_12999},
{"f_13124expand.scm",(void*)f_13124},
{"f_13120expand.scm",(void*)f_13120},
{"f_13002expand.scm",(void*)f_13002},
{"f_13057expand.scm",(void*)f_13057},
{"f_12934expand.scm",(void*)f_12934},
{"f_12973expand.scm",(void*)f_12973},
{"f_12925expand.scm",(void*)f_12925},
{"f_12896expand.scm",(void*)f_12896},
{"f_12835expand.scm",(void*)f_12835},
{"f_7705expand.scm",(void*)f_7705},
{"f_12667expand.scm",(void*)f_12667},
{"f_12671expand.scm",(void*)f_12671},
{"f_12680expand.scm",(void*)f_12680},
{"f_12683expand.scm",(void*)f_12683},
{"f_12686expand.scm",(void*)f_12686},
{"f_12689expand.scm",(void*)f_12689},
{"f_12692expand.scm",(void*)f_12692},
{"f_12713expand.scm",(void*)f_12713},
{"f_12729expand.scm",(void*)f_12729},
{"f_12735expand.scm",(void*)f_12735},
{"f_12791expand.scm",(void*)f_12791},
{"f_12789expand.scm",(void*)f_12789},
{"f_12785expand.scm",(void*)f_12785},
{"f_12777expand.scm",(void*)f_12777},
{"f_12773expand.scm",(void*)f_12773},
{"f_12742expand.scm",(void*)f_12742},
{"f_12711expand.scm",(void*)f_12711},
{"f_12665expand.scm",(void*)f_12665},
{"f_7708expand.scm",(void*)f_7708},
{"f_12598expand.scm",(void*)f_12598},
{"f_12602expand.scm",(void*)f_12602},
{"f_12611expand.scm",(void*)f_12611},
{"f_12616expand.scm",(void*)f_12616},
{"f_12653expand.scm",(void*)f_12653},
{"f_12634expand.scm",(void*)f_12634},
{"f_12596expand.scm",(void*)f_12596},
{"f_7711expand.scm",(void*)f_7711},
{"f_12416expand.scm",(void*)f_12416},
{"f_12420expand.scm",(void*)f_12420},
{"f_12432expand.scm",(void*)f_12432},
{"f_12435expand.scm",(void*)f_12435},
{"f_12438expand.scm",(void*)f_12438},
{"f_12441expand.scm",(void*)f_12441},
{"f_12576expand.scm",(void*)f_12576},
{"f_12456expand.scm",(void*)f_12456},
{"f_12574expand.scm",(void*)f_12574},
{"f_12483expand.scm",(void*)f_12483},
{"f_12564expand.scm",(void*)f_12564},
{"f_12499expand.scm",(void*)f_12499},
{"f_12521expand.scm",(void*)f_12521},
{"f_12519expand.scm",(void*)f_12519},
{"f_12515expand.scm",(void*)f_12515},
{"f_12414expand.scm",(void*)f_12414},
{"f_7714expand.scm",(void*)f_7714},
{"f_12021expand.scm",(void*)f_12021},
{"f_12025expand.scm",(void*)f_12025},
{"f_12028expand.scm",(void*)f_12028},
{"f_12031expand.scm",(void*)f_12031},
{"f_12034expand.scm",(void*)f_12034},
{"f_12403expand.scm",(void*)f_12403},
{"f_12315expand.scm",(void*)f_12315},
{"f_12319expand.scm",(void*)f_12319},
{"f_12344expand.scm",(void*)f_12344},
{"f_12390expand.scm",(void*)f_12390},
{"f_12375expand.scm",(void*)f_12375},
{"f_12046expand.scm",(void*)f_12046},
{"f_12093expand.scm",(void*)f_12093},
{"f_12140expand.scm",(void*)f_12140},
{"f_12301expand.scm",(void*)f_12301},
{"f_12309expand.scm",(void*)f_12309},
{"f_12287expand.scm",(void*)f_12287},
{"f_12276expand.scm",(void*)f_12276},
{"f_12284expand.scm",(void*)f_12284},
{"f_12261expand.scm",(void*)f_12261},
{"f_12249expand.scm",(void*)f_12249},
{"f_12230expand.scm",(void*)f_12230},
{"f_12188expand.scm",(void*)f_12188},
{"f_12165expand.scm",(void*)f_12165},
{"f_12119expand.scm",(void*)f_12119},
{"f_12068expand.scm",(void*)f_12068},
{"f_12064expand.scm",(void*)f_12064},
{"f_12036expand.scm",(void*)f_12036},
{"f_12044expand.scm",(void*)f_12044},
{"f_12019expand.scm",(void*)f_12019},
{"f_7717expand.scm",(void*)f_7717},
{"f_11988expand.scm",(void*)f_11988},
{"f_11992expand.scm",(void*)f_11992},
{"f_11986expand.scm",(void*)f_11986},
{"f_7720expand.scm",(void*)f_7720},
{"f_11704expand.scm",(void*)f_11704},
{"f_11711expand.scm",(void*)f_11711},
{"f_11714expand.scm",(void*)f_11714},
{"f_11717expand.scm",(void*)f_11717},
{"f_11720expand.scm",(void*)f_11720},
{"f_11723expand.scm",(void*)f_11723},
{"f_11885expand.scm",(void*)f_11885},
{"f_11938expand.scm",(void*)f_11938},
{"f_11960expand.scm",(void*)f_11960},
{"f_11967expand.scm",(void*)f_11967},
{"f_11954expand.scm",(void*)f_11954},
{"f_11901expand.scm",(void*)f_11901},
{"f_11899expand.scm",(void*)f_11899},
{"f_11735expand.scm",(void*)f_11735},
{"f_11766expand.scm",(void*)f_11766},
{"f_11812expand.scm",(void*)f_11812},
{"f_11862expand.scm",(void*)f_11862},
{"f_11869expand.scm",(void*)f_11869},
{"f_11827expand.scm",(void*)f_11827},
{"f_11841expand.scm",(void*)f_11841},
{"f_11784expand.scm",(void*)f_11784},
{"f_11795expand.scm",(void*)f_11795},
{"f_11725expand.scm",(void*)f_11725},
{"f_11702expand.scm",(void*)f_11702},
{"f_7723expand.scm",(void*)f_7723},
{"f_11683expand.scm",(void*)f_11683},
{"f_11681expand.scm",(void*)f_11681},
{"f_7726expand.scm",(void*)f_7726},
{"f_11662expand.scm",(void*)f_11662},
{"f_11660expand.scm",(void*)f_11660},
{"f_7729expand.scm",(void*)f_7729},
{"f_11611expand.scm",(void*)f_11611},
{"f_11615expand.scm",(void*)f_11615},
{"f_11652expand.scm",(void*)f_11652},
{"f_11645expand.scm",(void*)f_11645},
{"f_11638expand.scm",(void*)f_11638},
{"f_11609expand.scm",(void*)f_11609},
{"f_7732expand.scm",(void*)f_7732},
{"f_11557expand.scm",(void*)f_11557},
{"f_11561expand.scm",(void*)f_11561},
{"f_11564expand.scm",(void*)f_11564},
{"f_11601expand.scm",(void*)f_11601},
{"f_11567expand.scm",(void*)f_11567},
{"f_11582expand.scm",(void*)f_11582},
{"f_11586expand.scm",(void*)f_11586},
{"f_11555expand.scm",(void*)f_11555},
{"f_7735expand.scm",(void*)f_7735},
{"f_11454expand.scm",(void*)f_11454},
{"f_11461expand.scm",(void*)f_11461},
{"f_11464expand.scm",(void*)f_11464},
{"f_11484expand.scm",(void*)f_11484},
{"f_11506expand.scm",(void*)f_11506},
{"f_11491expand.scm",(void*)f_11491},
{"f_11467expand.scm",(void*)f_11467},
{"f_11482expand.scm",(void*)f_11482},
{"f_11474expand.scm",(void*)f_11474},
{"f_11470expand.scm",(void*)f_11470},
{"f_11452expand.scm",(void*)f_11452},
{"f_7738expand.scm",(void*)f_7738},
{"f_11417expand.scm",(void*)f_11417},
{"f_11421expand.scm",(void*)f_11421},
{"f_11439expand.scm",(void*)f_11439},
{"f_11430expand.scm",(void*)f_11430},
{"f_11415expand.scm",(void*)f_11415},
{"f_7741expand.scm",(void*)f_7741},
{"f_9376expand.scm",(void*)f_9376},
{"f_11411expand.scm",(void*)f_11411},
{"f_9380expand.scm",(void*)f_9380},
{"f_9384expand.scm",(void*)f_9384},
{"f_11369expand.scm",(void*)f_11369},
{"f_11377expand.scm",(void*)f_11377},
{"f_11379expand.scm",(void*)f_11379},
{"f_11400expand.scm",(void*)f_11400},
{"f_10922expand.scm",(void*)f_10922},
{"f_11354expand.scm",(void*)f_11354},
{"f_11362expand.scm",(void*)f_11362},
{"f_10938expand.scm",(void*)f_10938},
{"f_11311expand.scm",(void*)f_11311},
{"f_11313expand.scm",(void*)f_11313},
{"f_11352expand.scm",(void*)f_11352},
{"f_11326expand.scm",(void*)f_11326},
{"f_11337expand.scm",(void*)f_11337},
{"f_11292expand.scm",(void*)f_11292},
{"f_11304expand.scm",(void*)f_11304},
{"f_10941expand.scm",(void*)f_10941},
{"f_11164expand.scm",(void*)f_11164},
{"f_11215expand.scm",(void*)f_11215},
{"f_11268expand.scm",(void*)f_11268},
{"f_11227expand.scm",(void*)f_11227},
{"f_11254expand.scm",(void*)f_11254},
{"f_11250expand.scm",(void*)f_11250},
{"f_11230expand.scm",(void*)f_11230},
{"f_11212expand.scm",(void*)f_11212},
{"f_11201expand.scm",(void*)f_11201},
{"f_10944expand.scm",(void*)f_10944},
{"f_11158expand.scm",(void*)f_11158},
{"f_11144expand.scm",(void*)f_11144},
{"f_10947expand.scm",(void*)f_10947},
{"f_11142expand.scm",(void*)f_11142},
{"f_11106expand.scm",(void*)f_11106},
{"f_11134expand.scm",(void*)f_11134},
{"f_10950expand.scm",(void*)f_10950},
{"f_11100expand.scm",(void*)f_11100},
{"f_11104expand.scm",(void*)f_11104},
{"f_10953expand.scm",(void*)f_10953},
{"f_10956expand.scm",(void*)f_10956},
{"f_11058expand.scm",(void*)f_11058},
{"f_11062expand.scm",(void*)f_11062},
{"f_11092expand.scm",(void*)f_11092},
{"f_11088expand.scm",(void*)f_11088},
{"f_11065expand.scm",(void*)f_11065},
{"f_10959expand.scm",(void*)f_10959},
{"f_11056expand.scm",(void*)f_11056},
{"f_11052expand.scm",(void*)f_11052},
{"f_11048expand.scm",(void*)f_11048},
{"f_11044expand.scm",(void*)f_11044},
{"f_11040expand.scm",(void*)f_11040},
{"f_11036expand.scm",(void*)f_11036},
{"f_11032expand.scm",(void*)f_11032},
{"f_11028expand.scm",(void*)f_11028},
{"f_11024expand.scm",(void*)f_11024},
{"f_10962expand.scm",(void*)f_10962},
{"f_10965expand.scm",(void*)f_10965},
{"f_10837expand.scm",(void*)f_10837},
{"f_10848expand.scm",(void*)f_10848},
{"f_10850expand.scm",(void*)f_10850},
{"f_10899expand.scm",(void*)f_10899},
{"f_10895expand.scm",(void*)f_10895},
{"f_10878expand.scm",(void*)f_10878},
{"f_10746expand.scm",(void*)f_10746},
{"f_10750expand.scm",(void*)f_10750},
{"f_10753expand.scm",(void*)f_10753},
{"f_10792expand.scm",(void*)f_10792},
{"f_10812expand.scm",(void*)f_10812},
{"f_10802expand.scm",(void*)f_10802},
{"f_10805expand.scm",(void*)f_10805},
{"f_10768expand.scm",(void*)f_10768},
{"f_10774expand.scm",(void*)f_10774},
{"f_10772expand.scm",(void*)f_10772},
{"f_10626expand.scm",(void*)f_10626},
{"f_10728expand.scm",(void*)f_10728},
{"f_10740expand.scm",(void*)f_10740},
{"f_10630expand.scm",(void*)f_10630},
{"f_10696expand.scm",(void*)f_10696},
{"f_10718expand.scm",(void*)f_10718},
{"f_10633expand.scm",(void*)f_10633},
{"f_10690expand.scm",(void*)f_10690},
{"f_10694expand.scm",(void*)f_10694},
{"f_10639expand.scm",(void*)f_10639},
{"f_10642expand.scm",(void*)f_10642},
{"f_10678expand.scm",(void*)f_10678},
{"f_10645expand.scm",(void*)f_10645},
{"f_10658expand.scm",(void*)f_10658},
{"f_10648expand.scm",(void*)f_10648},
{"f_10340expand.scm",(void*)f_10340},
{"f_10624expand.scm",(void*)f_10624},
{"f_10360expand.scm",(void*)f_10360},
{"f_10594expand.scm",(void*)f_10594},
{"f_10368expand.scm",(void*)f_10368},
{"f_10576expand.scm",(void*)f_10576},
{"f_10376expand.scm",(void*)f_10376},
{"f_10564expand.scm",(void*)f_10564},
{"f_10491expand.scm",(void*)f_10491},
{"f_10489expand.scm",(void*)f_10489},
{"f_10485expand.scm",(void*)f_10485},
{"f_10426expand.scm",(void*)f_10426},
{"f_10436expand.scm",(void*)f_10436},
{"f_10424expand.scm",(void*)f_10424},
{"f_10420expand.scm",(void*)f_10420},
{"f_10372expand.scm",(void*)f_10372},
{"f_10364expand.scm",(void*)f_10364},
{"f_10268expand.scm",(void*)f_10268},
{"f_10272expand.scm",(void*)f_10272},
{"f_10275expand.scm",(void*)f_10275},
{"f_10287expand.scm",(void*)f_10287},
{"f_10326expand.scm",(void*)f_10326},
{"f_10318expand.scm",(void*)f_10318},
{"f_10278expand.scm",(void*)f_10278},
{"f_10281expand.scm",(void*)f_10281},
{"f_9992expand.scm",(void*)f_9992},
{"f_10073expand.scm",(void*)f_10073},
{"f_10100expand.scm",(void*)f_10100},
{"f_10102expand.scm",(void*)f_10102},
{"f_10262expand.scm",(void*)f_10262},
{"f_10250expand.scm",(void*)f_10250},
{"f_10231expand.scm",(void*)f_10231},
{"f_10213expand.scm",(void*)f_10213},
{"f_10198expand.scm",(void*)f_10198},
{"f_10168expand.scm",(void*)f_10168},
{"f_10153expand.scm",(void*)f_10153},
{"f_10125expand.scm",(void*)f_10125},
{"f_10050expand.scm",(void*)f_10050},
{"f_10062expand.scm",(void*)f_10062},
{"f_10058expand.scm",(void*)f_10058},
{"f_9933expand.scm",(void*)f_9933},
{"f_9939expand.scm",(void*)f_9939},
{"f_9946expand.scm",(void*)f_9946},
{"f_9949expand.scm",(void*)f_9949},
{"f_9865expand.scm",(void*)f_9865},
{"f_9885expand.scm",(void*)f_9885},
{"f_9880expand.scm",(void*)f_9880},
{"f_9867expand.scm",(void*)f_9867},
{"f_9843expand.scm",(void*)f_9843},
{"f_9850expand.scm",(void*)f_9850},
{"f_9766expand.scm",(void*)f_9766},
{"f_9776expand.scm",(void*)f_9776},
{"f_9779expand.scm",(void*)f_9779},
{"f_9785expand.scm",(void*)f_9785},
{"f_9824expand.scm",(void*)f_9824},
{"f_9828expand.scm",(void*)f_9828},
{"f_9788expand.scm",(void*)f_9788},
{"f_9791expand.scm",(void*)f_9791},
{"f_9794expand.scm",(void*)f_9794},
{"f_9677expand.scm",(void*)f_9677},
{"f_9687expand.scm",(void*)f_9687},
{"f_9690expand.scm",(void*)f_9690},
{"f_9753expand.scm",(void*)f_9753},
{"f_9693expand.scm",(void*)f_9693},
{"f_9749expand.scm",(void*)f_9749},
{"f_9696expand.scm",(void*)f_9696},
{"f_9735expand.scm",(void*)f_9735},
{"f_9739expand.scm",(void*)f_9739},
{"f_9699expand.scm",(void*)f_9699},
{"f_9702expand.scm",(void*)f_9702},
{"f_9708expand.scm",(void*)f_9708},
{"f_9656expand.scm",(void*)f_9656},
{"f_9663expand.scm",(void*)f_9663},
{"f_9636expand.scm",(void*)f_9636},
{"f_9640expand.scm",(void*)f_9640},
{"f_9633expand.scm",(void*)f_9633},
{"f_9593expand.scm",(void*)f_9593},
{"f_9597expand.scm",(void*)f_9597},
{"f_9587expand.scm",(void*)f_9587},
{"f_9578expand.scm",(void*)f_9578},
{"f_9560expand.scm",(void*)f_9560},
{"f_9542expand.scm",(void*)f_9542},
{"f_9524expand.scm",(void*)f_9524},
{"f_9506expand.scm",(void*)f_9506},
{"f_9488expand.scm",(void*)f_9488},
{"f_9479expand.scm",(void*)f_9479},
{"f_9470expand.scm",(void*)f_9470},
{"f_9452expand.scm",(void*)f_9452},
{"f_9434expand.scm",(void*)f_9434},
{"f_9425expand.scm",(void*)f_9425},
{"f_9416expand.scm",(void*)f_9416},
{"f_9398expand.scm",(void*)f_9398},
{"f_9392expand.scm",(void*)f_9392},
{"f_7743expand.scm",(void*)f_7743},
{"f_7750expand.scm",(void*)f_7750},
{"f_7764expand.scm",(void*)f_7764},
{"f_7768expand.scm",(void*)f_7768},
{"f_7772expand.scm",(void*)f_7772},
{"f_7777expand.scm",(void*)f_7777},
{"f_7783expand.scm",(void*)f_7783},
{"f_7787expand.scm",(void*)f_7787},
{"f_7791expand.scm",(void*)f_7791},
{"f_7795expand.scm",(void*)f_7795},
{"f_7799expand.scm",(void*)f_7799},
{"f_7804expand.scm",(void*)f_7804},
{"f_7808expand.scm",(void*)f_7808},
{"f_7815expand.scm",(void*)f_7815},
{"f_7820expand.scm",(void*)f_7820},
{"f_7824expand.scm",(void*)f_7824},
{"f_7828expand.scm",(void*)f_7828},
{"f_7832expand.scm",(void*)f_7832},
{"f_9335expand.scm",(void*)f_9335},
{"f_9345expand.scm",(void*)f_9345},
{"f_9352expand.scm",(void*)f_9352},
{"f_9315expand.scm",(void*)f_9315},
{"f_9322expand.scm",(void*)f_9322},
{"f_9329expand.scm",(void*)f_9329},
{"f_9289expand.scm",(void*)f_9289},
{"f_9267expand.scm",(void*)f_9267},
{"f_9274expand.scm",(void*)f_9274},
{"f_9174expand.scm",(void*)f_9174},
{"f_9216expand.scm",(void*)f_9216},
{"f_9265expand.scm",(void*)f_9265},
{"f_9248expand.scm",(void*)f_9248},
{"f_9227expand.scm",(void*)f_9227},
{"f_9187expand.scm",(void*)f_9187},
{"f_9101expand.scm",(void*)f_9101},
{"f_9127expand.scm",(void*)f_9127},
{"f_9172expand.scm",(void*)f_9172},
{"f_9155expand.scm",(void*)f_9155},
{"f_8847expand.scm",(void*)f_8847},
{"f_8894expand.scm",(void*)f_8894},
{"f_9092expand.scm",(void*)f_9092},
{"f_9088expand.scm",(void*)f_9088},
{"f_9055expand.scm",(void*)f_9055},
{"f_9063expand.scm",(void*)f_9063},
{"f_8897expand.scm",(void*)f_8897},
{"f_8903expand.scm",(void*)f_8903},
{"f_8915expand.scm",(void*)f_8915},
{"f_8981expand.scm",(void*)f_8981},
{"f_8996expand.scm",(void*)f_8996},
{"f_8918expand.scm",(void*)f_8918},
{"f_8952expand.scm",(void*)f_8952},
{"f_8921expand.scm",(void*)f_8921},
{"f_8950expand.scm",(void*)f_8950},
{"f_8946expand.scm",(void*)f_8946},
{"f_8942expand.scm",(void*)f_8942},
{"f_8640expand.scm",(void*)f_8640},
{"f_8670expand.scm",(void*)f_8670},
{"f_8770expand.scm",(void*)f_8770},
{"f_8793expand.scm",(void*)f_8793},
{"f_8807expand.scm",(void*)f_8807},
{"f_8811expand.scm",(void*)f_8811},
{"f_8780expand.scm",(void*)f_8780},
{"f_8730expand.scm",(void*)f_8730},
{"f_8734expand.scm",(void*)f_8734},
{"f_8679expand.scm",(void*)f_8679},
{"f_8687expand.scm",(void*)f_8687},
{"f_8664expand.scm",(void*)f_8664},
{"f_8352expand.scm",(void*)f_8352},
{"f_8359expand.scm",(void*)f_8359},
{"f_8398expand.scm",(void*)f_8398},
{"f_8408expand.scm",(void*)f_8408},
{"f_8539expand.scm",(void*)f_8539},
{"f_8543expand.scm",(void*)f_8543},
{"f_8472expand.scm",(void*)f_8472},
{"f_8468expand.scm",(void*)f_8468},
{"f_8406expand.scm",(void*)f_8406},
{"f_8402expand.scm",(void*)f_8402},
{"f_8234expand.scm",(void*)f_8234},
{"f_8238expand.scm",(void*)f_8238},
{"f_8013expand.scm",(void*)f_8013},
{"f_8063expand.scm",(void*)f_8063},
{"f_8177expand.scm",(void*)f_8177},
{"f_8115expand.scm",(void*)f_8115},
{"f_8123expand.scm",(void*)f_8123},
{"f_8119expand.scm",(void*)f_8119},
{"f_8111expand.scm",(void*)f_8111},
{"f_7929expand.scm",(void*)f_7929},
{"f_7936expand.scm",(void*)f_7936},
{"f_7939expand.scm",(void*)f_7939},
{"f_7988expand.scm",(void*)f_7988},
{"f_7984expand.scm",(void*)f_7984},
{"f_7979expand.scm",(void*)f_7979},
{"f_7965expand.scm",(void*)f_7965},
{"f_7977expand.scm",(void*)f_7977},
{"f_7973expand.scm",(void*)f_7973},
{"f_7835expand.scm",(void*)f_7835},
{"f_7879expand.scm",(void*)f_7879},
{"f_7875expand.scm",(void*)f_7875},
{"f_6841expand.scm",(void*)f_6841},
{"f_6845expand.scm",(void*)f_6845},
{"f_6848expand.scm",(void*)f_6848},
{"f_6851expand.scm",(void*)f_6851},
{"f_6854expand.scm",(void*)f_6854},
{"f_7453expand.scm",(void*)f_7453},
{"f_7456expand.scm",(void*)f_7456},
{"f_7675expand.scm",(void*)f_7675},
{"f_7660expand.scm",(void*)f_7660},
{"f_7459expand.scm",(void*)f_7459},
{"f_7464expand.scm",(void*)f_7464},
{"f_7468expand.scm",(void*)f_7468},
{"f_7477expand.scm",(void*)f_7477},
{"f_7635expand.scm",(void*)f_7635},
{"f_7480expand.scm",(void*)f_7480},
{"f_7612expand.scm",(void*)f_7612},
{"f_7483expand.scm",(void*)f_7483},
{"f_7486expand.scm",(void*)f_7486},
{"f_7558expand.scm",(void*)f_7558},
{"f_7592expand.scm",(void*)f_7592},
{"f_7489expand.scm",(void*)f_7489},
{"f_7516expand.scm",(void*)f_7516},
{"f_7556expand.scm",(void*)f_7556},
{"f_7492expand.scm",(void*)f_7492},
{"f_7514expand.scm",(void*)f_7514},
{"f_7510expand.scm",(void*)f_7510},
{"f_7495expand.scm",(void*)f_7495},
{"f_7506expand.scm",(void*)f_7506},
{"f_7502expand.scm",(void*)f_7502},
{"f_7462expand.scm",(void*)f_7462},
{"f_6995expand.scm",(void*)f_6995},
{"f_7014expand.scm",(void*)f_7014},
{"f_7023expand.scm",(void*)f_7023},
{"f_7035expand.scm",(void*)f_7035},
{"f_7115expand.scm",(void*)f_7115},
{"f_7222expand.scm",(void*)f_7222},
{"f_7369expand.scm",(void*)f_7369},
{"f_7372expand.scm",(void*)f_7372},
{"f_7375expand.scm",(void*)f_7375},
{"f_7408expand.scm",(void*)f_7408},
{"f_7412expand.scm",(void*)f_7412},
{"f_7377expand.scm",(void*)f_7377},
{"f_7397expand.scm",(void*)f_7397},
{"f_7393expand.scm",(void*)f_7393},
{"f_7385expand.scm",(void*)f_7385},
{"f_7225expand.scm",(void*)f_7225},
{"f_7234expand.scm",(void*)f_7234},
{"f_7363expand.scm",(void*)f_7363},
{"f_7344expand.scm",(void*)f_7344},
{"f_7332expand.scm",(void*)f_7332},
{"f_7311expand.scm",(void*)f_7311},
{"f_7292expand.scm",(void*)f_7292},
{"f_7280expand.scm",(void*)f_7280},
{"f_7255expand.scm",(void*)f_7255},
{"f_7250expand.scm",(void*)f_7250},
{"f_7118expand.scm",(void*)f_7118},
{"f_7121expand.scm",(void*)f_7121},
{"f_7126expand.scm",(void*)f_7126},
{"f_7212expand.scm",(void*)f_7212},
{"f_7138expand.scm",(void*)f_7138},
{"f_7180expand.scm",(void*)f_7180},
{"f_7038expand.scm",(void*)f_7038},
{"f_7041expand.scm",(void*)f_7041},
{"f_7046expand.scm",(void*)f_7046},
{"f_6908expand.scm",(void*)f_6908},
{"f_6912expand.scm",(void*)f_6912},
{"f_6915expand.scm",(void*)f_6915},
{"f_6993expand.scm",(void*)f_6993},
{"f_6989expand.scm",(void*)f_6989},
{"f_6930expand.scm",(void*)f_6930},
{"f_6936expand.scm",(void*)f_6936},
{"f_6939expand.scm",(void*)f_6939},
{"f_6978expand.scm",(void*)f_6978},
{"f_6972expand.scm",(void*)f_6972},
{"f_6976expand.scm",(void*)f_6976},
{"f_6940expand.scm",(void*)f_6940},
{"f_6944expand.scm",(void*)f_6944},
{"f_6947expand.scm",(void*)f_6947},
{"f_6951expand.scm",(void*)f_6951},
{"f_6954expand.scm",(void*)f_6954},
{"f_6958expand.scm",(void*)f_6958},
{"f_6961expand.scm",(void*)f_6961},
{"f_6965expand.scm",(void*)f_6965},
{"f_6968expand.scm",(void*)f_6968},
{"f_6918expand.scm",(void*)f_6918},
{"f_6865expand.scm",(void*)f_6865},
{"f_6878expand.scm",(void*)f_6878},
{"f_6885expand.scm",(void*)f_6885},
{"f_6856expand.scm",(void*)f_6856},
{"f_6860expand.scm",(void*)f_6860},
{"f_6547expand.scm",(void*)f_6547},
{"f_6549expand.scm",(void*)f_6549},
{"f_6678expand.scm",(void*)f_6678},
{"f_6711expand.scm",(void*)f_6711},
{"f_6801expand.scm",(void*)f_6801},
{"f_6714expand.scm",(void*)f_6714},
{"f_6717expand.scm",(void*)f_6717},
{"f_6795expand.scm",(void*)f_6795},
{"f_6720expand.scm",(void*)f_6720},
{"f_6789expand.scm",(void*)f_6789},
{"f_6766expand.scm",(void*)f_6766},
{"f_6739expand.scm",(void*)f_6739},
{"f_6746expand.scm",(void*)f_6746},
{"f_6682expand.scm",(void*)f_6682},
{"f_6685expand.scm",(void*)f_6685},
{"f_6815expand.scm",(void*)f_6815},
{"f_6819expand.scm",(void*)f_6819},
{"f_6822expand.scm",(void*)f_6822},
{"f_6552expand.scm",(void*)f_6552},
{"f_6588expand.scm",(void*)f_6588},
{"f_6649expand.scm",(void*)f_6649},
{"f_6652expand.scm",(void*)f_6652},
{"f_6619expand.scm",(void*)f_6619},
{"f_6622expand.scm",(void*)f_6622},
{"f_6600expand.scm",(void*)f_6600},
{"f_6562expand.scm",(void*)f_6562},
{"f_6085expand.scm",(void*)f_6085},
{"f_6499expand.scm",(void*)f_6499},
{"f_6490expand.scm",(void*)f_6490},
{"f_6498expand.scm",(void*)f_6498},
{"f_6087expand.scm",(void*)f_6087},
{"f_6218expand.scm",(void*)f_6218},
{"f_6223expand.scm",(void*)f_6223},
{"f_6461expand.scm",(void*)f_6461},
{"f_6420expand.scm",(void*)f_6420},
{"f_6424expand.scm",(void*)f_6424},
{"f_6242expand.scm",(void*)f_6242},
{"f_6247expand.scm",(void*)f_6247},
{"f_6266expand.scm",(void*)f_6266},
{"f_6189expand.scm",(void*)f_6189},
{"f_6195expand.scm",(void*)f_6195},
{"f_6133expand.scm",(void*)f_6133},
{"f_6137expand.scm",(void*)f_6137},
{"f_6145expand.scm",(void*)f_6145},
{"f_6165expand.scm",(void*)f_6165},
{"f_6090expand.scm",(void*)f_6090},
{"f_6097expand.scm",(void*)f_6097},
{"f_6102expand.scm",(void*)f_6102},
{"f_6106expand.scm",(void*)f_6106},
{"f_6131expand.scm",(void*)f_6131},
{"f_6120expand.scm",(void*)f_6120},
{"f_6124expand.scm",(void*)f_6124},
{"f_6113expand.scm",(void*)f_6113},
{"f_6049expand.scm",(void*)f_6049},
{"f_6071expand.scm",(void*)f_6071},
{"f_6038expand.scm",(void*)f_6038},
{"f_6046expand.scm",(void*)f_6046},
{"f_5968expand.scm",(void*)f_5968},
{"f_6031expand.scm",(void*)f_6031},
{"f_5971expand.scm",(void*)f_5971},
{"f_6024expand.scm",(void*)f_6024},
{"f_5997expand.scm",(void*)f_5997},
{"f_5885expand.scm",(void*)f_5885},
{"f_5966expand.scm",(void*)f_5966},
{"f_5888expand.scm",(void*)f_5888},
{"f_5937expand.scm",(void*)f_5937},
{"f_5132expand.scm",(void*)f_5132},
{"f_5136expand.scm",(void*)f_5136},
{"f_5575expand.scm",(void*)f_5575},
{"f_5581expand.scm",(void*)f_5581},
{"f_5845expand.scm",(void*)f_5845},
{"f_5603expand.scm",(void*)f_5603},
{"f_5813expand.scm",(void*)f_5813},
{"f_5787expand.scm",(void*)f_5787},
{"f_5794expand.scm",(void*)f_5794},
{"f_5759expand.scm",(void*)f_5759},
{"f_5747expand.scm",(void*)f_5747},
{"f_5621expand.scm",(void*)f_5621},
{"f_5626expand.scm",(void*)f_5626},
{"f_5639expand.scm",(void*)f_5639},
{"f_5695expand.scm",(void*)f_5695},
{"f_5722expand.scm",(void*)f_5722},
{"f_5673expand.scm",(void*)f_5673},
{"f_5684expand.scm",(void*)f_5684},
{"f_5688expand.scm",(void*)f_5688},
{"f_5398expand.scm",(void*)f_5398},
{"f_5408expand.scm",(void*)f_5408},
{"f_5557expand.scm",(void*)f_5557},
{"f_5553expand.scm",(void*)f_5553},
{"f_5543expand.scm",(void*)f_5543},
{"f_5546expand.scm",(void*)f_5546},
{"f_5454expand.scm",(void*)f_5454},
{"f_5486expand.scm",(void*)f_5486},
{"f_5498expand.scm",(void*)f_5498},
{"f_5506expand.scm",(void*)f_5506},
{"f_5510expand.scm",(void*)f_5510},
{"f_5472expand.scm",(void*)f_5472},
{"f_5423expand.scm",(void*)f_5423},
{"f_5439expand.scm",(void*)f_5439},
{"f_5431expand.scm",(void*)f_5431},
{"f_5435expand.scm",(void*)f_5435},
{"f_5406expand.scm",(void*)f_5406},
{"f_5138expand.scm",(void*)f_5138},
{"f_5249expand.scm",(void*)f_5249},
{"f_5390expand.scm",(void*)f_5390},
{"f_5378expand.scm",(void*)f_5378},
{"f_5271expand.scm",(void*)f_5271},
{"f_5376expand.scm",(void*)f_5376},
{"f_5360expand.scm",(void*)f_5360},
{"f_5279expand.scm",(void*)f_5279},
{"f_5354expand.scm",(void*)f_5354},
{"f_5358expand.scm",(void*)f_5358},
{"f_5293expand.scm",(void*)f_5293},
{"f_5297expand.scm",(void*)f_5297},
{"f_5330expand.scm",(void*)f_5330},
{"f_5328expand.scm",(void*)f_5328},
{"f_5324expand.scm",(void*)f_5324},
{"f_5287expand.scm",(void*)f_5287},
{"f_5291expand.scm",(void*)f_5291},
{"f_5283expand.scm",(void*)f_5283},
{"f_5275expand.scm",(void*)f_5275},
{"f_5255expand.scm",(void*)f_5255},
{"f_5150expand.scm",(void*)f_5150},
{"f_5164expand.scm",(void*)f_5164},
{"f_5239expand.scm",(void*)f_5239},
{"f_5232expand.scm",(void*)f_5232},
{"f_5173expand.scm",(void*)f_5173},
{"f_5180expand.scm",(void*)f_5180},
{"f_5188expand.scm",(void*)f_5188},
{"f_5196expand.scm",(void*)f_5196},
{"f_5184expand.scm",(void*)f_5184},
{"f_4542expand.scm",(void*)f_4542},
{"f_4562expand.scm",(void*)f_4562},
{"f_4565expand.scm",(void*)f_4565},
{"f_4568expand.scm",(void*)f_4568},
{"f_4571expand.scm",(void*)f_4571},
{"f_4574expand.scm",(void*)f_4574},
{"f_4579expand.scm",(void*)f_4579},
{"f_4890expand.scm",(void*)f_4890},
{"f_5069expand.scm",(void*)f_5069},
{"f_5007expand.scm",(void*)f_5007},
{"f_4988expand.scm",(void*)f_4988},
{"f_4942expand.scm",(void*)f_4942},
{"f_4945expand.scm",(void*)f_4945},
{"f_4924expand.scm",(void*)f_4924},
{"f_4905expand.scm",(void*)f_4905},
{"f_4867expand.scm",(void*)f_4867},
{"f_4846expand.scm",(void*)f_4846},
{"f_4593expand.scm",(void*)f_4593},
{"f_4839expand.scm",(void*)f_4839},
{"f_4766expand.scm",(void*)f_4766},
{"f_4835expand.scm",(void*)f_4835},
{"f_4819expand.scm",(void*)f_4819},
{"f_4801expand.scm",(void*)f_4801},
{"f_4797expand.scm",(void*)f_4797},
{"f_4760expand.scm",(void*)f_4760},
{"f_4764expand.scm",(void*)f_4764},
{"f_4597expand.scm",(void*)f_4597},
{"f_4609expand.scm",(void*)f_4609},
{"f_4712expand.scm",(void*)f_4712},
{"f_4704expand.scm",(void*)f_4704},
{"f_4708expand.scm",(void*)f_4708},
{"f_4681expand.scm",(void*)f_4681},
{"f_4685expand.scm",(void*)f_4685},
{"f_4636expand.scm",(void*)f_4636},
{"f_4656expand.scm",(void*)f_4656},
{"f_4628expand.scm",(void*)f_4628},
{"f_4600expand.scm",(void*)f_4600},
{"f_4545expand.scm",(void*)f_4545},
{"f_4499expand.scm",(void*)f_4499},
{"f_4505expand.scm",(void*)f_4505},
{"f_4524expand.scm",(void*)f_4524},
{"f_4446expand.scm",(void*)f_4446},
{"f_4450expand.scm",(void*)f_4450},
{"f_4455expand.scm",(void*)f_4455},
{"f_4467expand.scm",(void*)f_4467},
{"f_4461expand.scm",(void*)f_4461},
{"f_4356expand.scm",(void*)f_4356},
{"f_4392expand.scm",(void*)f_4392},
{"f_4395expand.scm",(void*)f_4395},
{"f_4407expand.scm",(void*)f_4407},
{"f_4444expand.scm",(void*)f_4444},
{"f_4419expand.scm",(void*)f_4419},
{"f_4434expand.scm",(void*)f_4434},
{"f_4410expand.scm",(void*)f_4410},
{"f_4401expand.scm",(void*)f_4401},
{"f_4359expand.scm",(void*)f_4359},
{"f_4363expand.scm",(void*)f_4363},
{"f_4369expand.scm",(void*)f_4369},
{"f_4372expand.scm",(void*)f_4372},
{"f_4338expand.scm",(void*)f_4338},
{"f_4346expand.scm",(void*)f_4346},
{"f_3856expand.scm",(void*)f_3856},
{"f_4155expand.scm",(void*)f_4155},
{"f_4329expand.scm",(void*)f_4329},
{"f_4322expand.scm",(void*)f_4322},
{"f_4161expand.scm",(void*)f_4161},
{"f_4263expand.scm",(void*)f_4263},
{"f_4269expand.scm",(void*)f_4269},
{"f_4276expand.scm",(void*)f_4276},
{"f_4170expand.scm",(void*)f_4170},
{"f_4182expand.scm",(void*)f_4182},
{"f_4250expand.scm",(void*)f_4250},
{"f_4240expand.scm",(void*)f_4240},
{"f_4244expand.scm",(void*)f_4244},
{"f_4208expand.scm",(void*)f_4208},
{"f_4204expand.scm",(void*)f_4204},
{"f_4038expand.scm",(void*)f_4038},
{"f_4095expand.scm",(void*)f_4095},
{"f_4098expand.scm",(void*)f_4098},
{"f_4124expand.scm",(void*)f_4124},
{"f_4120expand.scm",(void*)f_4120},
{"f_4110expand.scm",(void*)f_4110},
{"f_4042expand.scm",(void*)f_4042},
{"f_4064expand.scm",(void*)f_4064},
{"f_3859expand.scm",(void*)f_3859},
{"f_3863expand.scm",(void*)f_3863},
{"f_4036expand.scm",(void*)f_4036},
{"f_4032expand.scm",(void*)f_4032},
{"f_3866expand.scm",(void*)f_3866},
{"f_3874expand.scm",(void*)f_3874},
{"f_3987expand.scm",(void*)f_3987},
{"f_4014expand.scm",(void*)f_4014},
{"f_4020expand.scm",(void*)f_4020},
{"f_3993expand.scm",(void*)f_3993},
{"f_3997expand.scm",(void*)f_3997},
{"f_4000expand.scm",(void*)f_4000},
{"f_3880expand.scm",(void*)f_3880},
{"f_3886expand.scm",(void*)f_3886},
{"f_3897expand.scm",(void*)f_3897},
{"f_3914expand.scm",(void*)f_3914},
{"f_3933expand.scm",(void*)f_3933},
{"f_3944expand.scm",(void*)f_3944},
{"f_3908expand.scm",(void*)f_3908},
{"f_3894expand.scm",(void*)f_3894},
{"f_3872expand.scm",(void*)f_3872},
{"f_3847expand.scm",(void*)f_3847},
{"f_3796expand.scm",(void*)f_3796},
{"f_3808expand.scm",(void*)f_3808},
{"f_3810expand.scm",(void*)f_3810},
{"f_3845expand.scm",(void*)f_3845},
{"f_3837expand.scm",(void*)f_3837},
{"f_3804expand.scm",(void*)f_3804},
{"f_3740expand.scm",(void*)f_3740},
{"f_3744expand.scm",(void*)f_3744},
{"f_3753expand.scm",(void*)f_3753},
{"f_3772expand.scm",(void*)f_3772},
{"f_3762expand.scm",(void*)f_3762},
{"f_3727expand.scm",(void*)f_3727},
{"f_3738expand.scm",(void*)f_3738},
{"f_3731expand.scm",(void*)f_3731},
{"f_3694expand.scm",(void*)f_3694},
{"f_3698expand.scm",(void*)f_3698},
{"f_3701expand.scm",(void*)f_3701},
{"f_3587expand.scm",(void*)f_3587},
{"f_3591expand.scm",(void*)f_3591},
{"f_3596expand.scm",(void*)f_3596},
{"f_3666expand.scm",(void*)f_3666},
{"f_3662expand.scm",(void*)f_3662},
{"f_3637expand.scm",(void*)f_3637},
{"f_3641expand.scm",(void*)f_3641},
{"f_3606expand.scm",(void*)f_3606},
{"f_3557expand.scm",(void*)f_3557},
{"f_3563expand.scm",(void*)f_3563},
{"f_3508expand.scm",(void*)f_3508},
{"f_3515expand.scm",(void*)f_3515},
{"f_3518expand.scm",(void*)f_3518},
{"f_3521expand.scm",(void*)f_3521},
{"f_3524expand.scm",(void*)f_3524},
{"f_3530expand.scm",(void*)f_3530},
{"f_3533expand.scm",(void*)f_3533},
{"f_3490expand.scm",(void*)f_3490},
{"f_3503expand.scm",(void*)f_3503},
{"f_3459expand.scm",(void*)f_3459},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
