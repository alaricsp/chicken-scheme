/* Generated from expand.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-30 14:47
   Version 4.0.0x5 - SVN rev. 12341
   macosx-unix-gnu-ppc [ dload ptables applyhook ]
   compiled 2008-11-03 on apfel (Darwin)
   command line: expand.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file expand.c
   unit: expand
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[402];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,17),40,100,32,97,114,103,49,55,32,46,32,109,111,114,101,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,108,111,111,107,117,112,32,105,100,50,52,32,115,101,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,109,97,99,114,111,45,97,108,105,97,115,32,118,97,114,52,53,32,115,101,52,54,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,11),40,97,51,54,56,49,32,97,56,48,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,13),40,109,97,112,45,115,101,32,115,101,55,56,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,11),40,119,97,108,107,32,120,49,49,53,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,24),40,98,111,100,121,49,48,48,32,115,101,49,49,48,32,97,108,105,97,115,49,49,49,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,97,108,105,97,115,49,48,51,32,37,115,101,57,56,49,51,57,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,11),40,100,101,102,45,115,101,49,48,50,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,115,116,114,105,112,45,115,121,110,116,97,120,32,101,120,112,57,48,32,46,32,116,109,112,56,57,57,49,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,101,120,116,101,110,100,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,110,97,109,101,49,53,57,32,115,101,49,54,48,32,104,97,110,100,108,101,114,49,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,99,111,112,121,45,109,97,99,114,111,32,111,108,100,49,56,49,32,110,101,119,49,56,50,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,27),40,109,97,99,114,111,63,32,115,121,109,49,57,52,32,46,32,116,109,112,49,57,51,49,57,53,41,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,109,101,50,50,56,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,109,97,99,114,111,32,110,97,109,101,50,50,52,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,117,110,100,101,102,105,110,101,45,109,97,99,114,111,33,32,110,97,109,101,50,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,112,115,50,55,53,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,7),40,97,52,48,53,50,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,97,52,48,52,54,32,101,120,50,54,56,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,7),40,97,52,49,53,57,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,52,49,56,54,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,20),40,97,52,49,56,48,32,46,32,97,114,103,115,50,54,50,50,57,53,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,52,49,53,51,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,15),40,97,52,48,52,48,32,107,50,54,49,50,54,54,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,46),40,99,97,108,108,45,104,97,110,100,108,101,114,32,110,97,109,101,50,53,50,32,104,97,110,100,108,101,114,50,53,51,32,101,120,112,50,53,52,32,115,101,50,53,53,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,31),40,101,120,112,97,110,100,32,104,101,97,100,51,48,48,32,101,120,112,51,48,49,32,109,100,101,102,51,48,50,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,12),40,97,52,52,49,54,32,98,51,55,52,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,101,120,112,97,110,100,45,48,32,101,120,112,50,52,55,32,100,115,101,50,52,56,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,109,111,100,117,108,101,45,114,101,110,97,109,101,32,115,121,109,51,57,49,32,112,114,101,102,105,120,51,57,50,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,16),40,109,114,101,110,97,109,101,32,115,121,109,52,48,56,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,97,108,105,97,115,45,103,108,111,98,97,108,45,104,111,111,107,32,115,121,109,51,57,54,32,97,115,115,105,103,110,51,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,52,54,50,55,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,32),40,97,52,54,51,51,32,101,120,112,50,52,55,53,52,55,54,52,56,49,32,109,52,55,55,52,55,56,52,56,50,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,52,55,50,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,101,120,112,97,110,100,32,101,120,112,52,53,55,32,46,32,116,109,112,52,53,54,52,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,108,105,115,116,52,57,54,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,63,32,108,108,105,115,116,52,57,50,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,101,114,114,32,109,115,103,53,51,50,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,97,52,57,51,50,32,107,53,54,53,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,109,111,100,101,53,52,55,32,114,101,113,53,52,56,32,111,112,116,53,52,57,32,107,101,121,53,53,48,32,108,108,105,115,116,53,53,49,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,67),40,35,35,115,121,115,35,101,120,112,97,110,100,45,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,32,108,108,105,115,116,48,53,50,53,32,98,111,100,121,53,50,54,32,101,114,114,104,53,50,55,32,115,101,53,50,56,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,98,111,100,121,50,55,48,51,32,101,120,112,115,55,48,52,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,17),40,97,53,52,57,54,32,118,55,54,48,32,116,55,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,18),40,97,53,52,53,57,32,118,115,55,53,49,32,120,55,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,17),40,97,53,53,50,54,32,118,55,52,52,32,120,55,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,97,53,53,52,52,32,118,55,52,50,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,48),40,102,105,110,105,32,118,97,114,115,54,57,51,32,118,97,108,115,54,57,52,32,109,118,97,114,115,54,57,53,32,109,118,97,108,115,54,57,54,32,98,111,100,121,54,57,55,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,30),40,108,111,111,112,32,98,111,100,121,55,56,50,32,100,101,102,115,55,56,51,32,100,111,110,101,55,56,52,41,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,55),40,102,105,110,105,47,115,121,110,116,97,120,32,118,97,114,115,55,55,52,32,118,97,108,115,55,55,53,32,109,118,97,114,115,55,55,54,32,109,118,97,108,115,55,55,55,32,98,111,100,121,55,55,56,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,50,32,120,56,53,56,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,48),40,108,111,111,112,32,98,111,100,121,56,50,49,32,118,97,114,115,56,50,50,32,118,97,108,115,56,50,51,32,109,118,97,114,115,56,50,52,32,109,118,97,108,115,56,50,53,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,98,111,100,121,56,49,55,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,99,97,110,111,110,105,99,97,108,105,122,101,45,98,111,100,121,32,98,111,100,121,54,55,55,32,46,32,116,109,112,54,55,54,54,55,56,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,17),40,109,119,97,108,107,32,120,57,48,53,32,112,57,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,40),40,109,97,116,99,104,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,56,57,54,32,112,97,116,56,57,55,32,118,97,114,115,56,57,56,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,104,101,97,100,57,52,49,32,98,111,100,121,57,52,50,41,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,51),40,35,35,115,121,115,35,101,120,112,97,110,100,45,99,117,114,114,105,101,100,45,100,101,102,105,110,101,32,104,101,97,100,57,51,52,32,98,111,100,121,57,51,53,32,115,101,57,51,54,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,45,104,111,111,107,32,46,32,97,114,103,115,57,54,48,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,25),40,103,101,116,45,108,105,110,101,45,110,117,109,98,101,114,32,115,101,120,112,57,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,101,114,114,32,109,115,103,49,48,52,49,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,29),40,116,101,115,116,32,120,49,48,51,53,32,112,114,101,100,49,48,51,54,32,109,115,103,49,48,51,55,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,49,48,53,57,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,108,97,109,98,100,97,45,108,105,115,116,63,32,120,49,48,52,57,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,20),40,112,114,111,112,101,114,45,108,105,115,116,63,32,120,49,48,56,48,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,49,50,57,32,120,49,49,51,54,32,110,49,49,51,55,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,13),40,97,54,53,56,54,32,121,49,49,53,55,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,49,48,51,32,112,49,49,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,49,48,49,54,32,99,117,108,112,114,105,116,49,48,50,54,32,115,101,49,48,50,55,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,101,49,48,49,57,32,37,99,117,108,112,114,105,116,49,48,49,52,49,49,55,51,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,99,117,108,112,114,105,116,49,48,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,99,104,101,99,107,45,115,121,110,116,97,120,32,105,100,49,48,48,52,32,101,120,112,49,48,48,53,32,112,97,116,49,48,48,54,32,46,32,116,109,112,49,48,48,51,49,48,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,16),40,114,101,110,97,109,101,32,115,121,109,49,49,57,56,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,31),40,108,111,111,107,117,112,50,32,110,49,51,51,53,32,115,121,109,49,51,51,54,32,100,115,101,49,51,51,55,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,23),40,99,111,109,112,97,114,101,32,115,49,49,50,53,49,32,115,50,49,50,53,50,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,32),40,102,95,54,55,49,54,32,102,111,114,109,49,49,56,57,32,115,101,49,49,57,48,32,100,115,101,49,49,57,49,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,101,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,49,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,17),40,114,101,115,111,108,118,101,32,115,121,109,49,51,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,13),40,116,111,115,116,114,32,120,49,51,55,52,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,10),40,115,119,97,112,49,52,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,7),40,97,55,49,52,52,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,110,97,109,101,32,115,112,101,99,49,51,56,51,41,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,105,100,115,49,52,57,48,32,118,49,52,57,49,32,115,49,52,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,115,49,53,51,49,32,115,49,53,51,50,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,105,109,112,118,49,53,49,57,32,118,49,53,50,48,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,14),40,97,55,52,50,49,32,105,100,49,53,55,48,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,105,109,112,118,49,53,52,56,32,105,109,112,115,49,53,52,57,32,118,49,53,53,48,32,115,49,53,53,49,32,105,100,115,49,53,53,50,41,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,13),40,114,101,110,32,105,109,112,49,53,56,57,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,22),40,105,109,112,111,114,116,45,115,112,101,99,32,115,112,101,99,49,52,53,52,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,15),40,97,55,54,56,50,32,105,109,112,49,54,50,57,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,97,55,55,50,52,32,105,109,112,49,54,49,57,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,16),40,97,55,54,51,48,32,115,112,101,99,49,53,57,55,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,86),40,35,35,115,121,115,35,101,120,112,97,110,100,45,105,109,112,111,114,116,32,120,49,51,52,57,32,114,49,51,53,48,32,99,49,51,53,49,32,105,109,112,111,114,116,45,101,110,118,49,51,53,50,32,109,97,99,114,111,45,101,110,118,49,51,53,51,32,109,101,116,97,63,49,51,53,52,32,108,111,99,49,51,53,53,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,14),40,102,95,56,48,48,54,32,120,50,50,57,56,41,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,18),40,102,95,56,48,49,50,32,114,117,108,101,115,50,51,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,13),40,97,56,49,53,53,32,120,50,51,49,57,41,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,17),40,102,95,56,49,48,54,32,114,117,108,101,50,51,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,30),40,102,95,56,49,57,48,32,105,110,112,117,116,50,51,50,49,32,112,97,116,116,101,114,110,50,51,50,50,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,30),40,102,95,56,52,49,49,32,105,110,112,117,116,50,51,55,49,32,112,97,116,116,101,114,110,50,51,55,50,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,52,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,30),40,102,95,56,53,50,57,32,105,110,112,117,116,50,51,56,56,32,112,97,116,116,101,114,110,50,51,56,57,41,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,13),40,97,56,56,53,53,32,120,50,52,52,57,41,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,10),40,108,112,32,105,50,52,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,39),40,102,95,56,56,49,55,32,112,97,116,116,101,114,110,50,52,51,56,32,112,97,116,104,50,52,51,57,32,109,97,112,105,116,50,52,52,48,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,50,53,51,51,32,100,50,53,51,57,32,103,101,110,50,53,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,37),40,102,95,57,48,50,52,32,116,101,109,112,108,97,116,101,50,52,57,50,32,100,105,109,50,52,57,51,32,101,110,118,50,52,57,52,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,37),40,102,95,57,50,55,56,32,112,97,116,116,101,114,110,50,53,54,54,32,100,105,109,50,53,54,55,32,118,97,114,115,50,53,54,56,41,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,46),40,102,95,57,51,53,49,32,116,101,109,112,108,97,116,101,50,53,55,55,32,100,105,109,50,53,55,56,32,101,110,118,50,53,55,57,32,102,114,101,101,50,53,56,48,41,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,52,52,32,112,97,116,116,101,114,110,50,53,57,53,41,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,54,54,32,112,97,116,116,101,114,110,50,54,48,53,41,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,57,50,32,112,97,116,116,101,114,110,50,54,49,49,41,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,97,116,116,101,114,110,50,54,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,20),40,102,95,57,53,49,50,32,112,97,116,116,101,114,110,50,54,49,51,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,79),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,115,121,110,116,97,120,45,114,117,108,101,115,32,101,108,108,105,112,115,105,115,50,50,51,57,32,114,117,108,101,115,50,50,52,48,32,115,117,98,107,101,121,119,111,114,100,115,50,50,52,49,32,114,50,50,52,50,32,99,50,50,52,51,41,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,23),40,109,111,100,117,108,101,45,110,97,109,101,32,120,50,54,56,54,50,55,48,53,41,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,20),40,109,111,100,117,108,101,45,101,120,112,111,114,116,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,46),40,115,101,116,45,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,56,54,50,55,49,55,32,121,50,54,56,55,50,55,49,56,41,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,108,105,115,116,41,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,19),40,109,111,100,117,108,101,45,101,120,105,115,116,45,108,105,115,116,41,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,28),40,109,111,100,117,108,101,45,100,101,102,105,110,101,100,45,115,121,110,116,97,120,45,108,105,115,116,41,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,48),40,115,101,116,45,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,33,32,120,50,54,56,54,50,55,52,49,32,121,50,54,56,55,50,55,52,50,41};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,117,110,100,101,102,105,110,101,100,45,108,105,115,116,32,120,50,54,56,54,50,55,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,21),40,109,111,100,117,108,101,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,26),40,109,111,100,117,108,101,45,109,101,116,97,45,105,109,112,111,114,116,45,102,111,114,109,115,41,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,25),40,109,111,100,117,108,101,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,118,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,17),40,109,111,100,117,108,101,45,115,101,120,112,111,114,116,115,41,0,0,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,109,111,100,117,108,101,45,101,120,112,111,114,116,115,32,109,50,56,49,51,41,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,51),40,109,97,107,101,45,109,111,100,117,108,101,32,101,120,112,108,105,115,116,50,56,49,56,32,118,101,120,112,111,114,116,115,50,56,49,57,32,115,101,120,112,111,114,116,115,50,56,50,48,41,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,102,105,110,100,45,109,111,100,117,108,101,32,110,97,109,101,50,56,51,48,32,46,32,116,109,112,50,56,50,57,50,56,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,64),40,35,35,115,121,115,35,116,111,112,108,101,118,101,108,45,100,101,102,105,110,105,116,105,111,110,45,104,111,111,107,32,115,121,109,50,56,53,55,32,109,111,100,50,56,53,56,32,101,120,112,50,56,53,57,32,118,97,108,50,56,54,48,41};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,40),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,101,116,97,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,50,56,54,52,41};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,42),40,99,104,101,99,107,45,102,111,114,45,114,101,100,101,102,32,115,121,109,50,56,55,51,32,101,110,118,50,56,55,52,32,115,101,110,118,50,56,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,101,120,112,111,114,116,32,115,121,109,50,56,57,48,32,109,111,100,50,56,57,49,41,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,115,121,110,116,97,120,45,101,120,112,111,114,116,32,115,121,109,50,57,49,53,32,109,111,100,50,57,49,54,32,118,97,108,50,57,49,55,41,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,117,110,100,101,102,105,110,101,100,32,115,121,109,50,57,52,49,32,109,111,100,50,57,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,50,57,54,57,32,115,101,120,112,111,114,116,115,50,57,56,48,41,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,18),40,100,101,102,45,115,101,120,112,111,114,116,115,50,57,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,58),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,109,111,100,117,108,101,32,110,97,109,101,50,57,53,56,32,101,120,112,108,105,115,116,50,57,53,57,32,46,32,116,109,112,50,57,53,55,50,57,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,16),40,97,49,48,49,51,56,32,105,109,112,51,48,48,52,41};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,36),40,35,35,115,121,115,35,109,97,114,107,45,105,109,112,111,114,116,101,100,45,115,121,109,98,111,108,115,32,115,101,51,48,48,50,41,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,21),40,119,97,114,110,32,109,115,103,51,48,52,51,32,105,100,51,48,52,52,41,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,50,32,105,101,120,112,111,114,116,115,51,48,53,57,41,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,101,120,112,111,114,116,115,51,48,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,33),40,109,111,100,117,108,101,45,105,110,100,105,114,101,99,116,45,101,120,112,111,114,116,115,32,109,111,100,51,48,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,101,51,49,49,48,41,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,18),40,109,101,114,103,101,45,115,101,32,115,101,115,51,49,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,115,100,51,49,56,50,41,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,20),40,97,49,48,55,50,54,32,115,101,120,112,111,114,116,51,49,53,54,41,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,57,56,32,105,101,51,49,52,54,41,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,45,114,101,103,105,115,116,114,97,116,105,111,110,32,109,111,100,51,49,50,54,41,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,17),40,97,49,48,57,57,55,32,110,101,120,112,51,50,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,17),40,97,49,49,48,48,55,32,105,101,120,112,51,50,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,17),40,97,49,49,48,50,55,32,115,101,120,112,51,50,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,15),40,97,49,49,48,52,53,32,110,101,51,50,51,56,41,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,15),40,97,49,49,48,54,51,32,105,101,51,50,51,52,41,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,15),40,97,49,49,48,57,53,32,115,101,51,50,51,48,41,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,94),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,99,111,109,112,105,108,101,100,45,109,111,100,117,108,101,32,110,97,109,101,51,50,48,55,32,105,101,120,112,111,114,116,115,51,50,48,56,32,118,101,120,112,111,114,116,115,51,50,48,57,32,115,101,120,112,111,114,116,115,51,50,49,48,32,46,32,116,109,112,51,50,48,54,51,50,49,49,41,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,15),40,97,49,49,49,54,57,32,115,101,51,50,57,49,41,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,15),40,97,49,49,49,56,55,32,118,101,51,50,56,54,41,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,69),40,35,35,115,121,115,35,114,101,103,105,115,116,101,114,45,112,114,105,109,105,116,105,118,101,45,109,111,100,117,108,101,32,110,97,109,101,51,50,54,56,32,118,101,120,112,111,114,116,115,51,50,54,57,32,46,32,116,109,112,51,50,54,55,51,50,55,48,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,51,49,50,41,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,102,105,110,100,45,101,120,112,111,114,116,32,115,121,109,51,51,48,52,32,109,111,100,51,51,48,53,32,105,110,100,105,114,101,99,116,51,51,48,54,41};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,14),40,97,49,49,52,53,54,32,109,51,52,53,48,41,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,16),40,97,49,49,53,48,52,32,101,120,112,51,52,51,49,41};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,51,52,50,49,41,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,14),40,97,49,49,53,52,53,32,117,51,52,49,48,41,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,120,108,51,51,56,48,41,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,51,54,53,41,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,16),40,97,49,49,56,49,48,32,115,121,109,51,51,53,57,41};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,110,97,108,105,122,101,45,109,111,100,117,108,101,32,109,111,100,51,51,52,53,41,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,51,52,55,54,41,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,109,97,99,114,111,45,115,117,98,115,101,116,32,109,101,48,51,52,55,50,41,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,28),40,97,49,49,56,55,55,32,101,120,112,50,50,50,51,32,114,50,50,50,52,32,99,50,50,50,53,41,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,16),40,97,49,49,57,52,52,32,101,120,112,50,49,57,57,41};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,26),40,97,49,49,57,49,52,32,120,50,49,57,48,32,114,50,49,57,49,32,99,50,49,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,26),40,97,49,50,48,49,55,32,120,50,49,55,48,32,114,50,49,55,49,32,99,50,49,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,26),40,97,49,50,48,55,49,32,120,50,49,54,48,32,114,50,49,54,49,32,99,50,49,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,26),40,97,49,50,49,50,50,32,120,50,49,52,57,32,114,50,49,53,48,32,99,50,49,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,26),40,97,49,50,49,52,51,32,120,50,49,51,56,32,114,50,49,51,57,32,99,50,49,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,11),40,101,114,114,32,120,50,48,53,51,41,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,13),40,116,101,115,116,32,102,120,50,48,53,53,41,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,14),40,97,49,50,51,54,49,32,120,50,49,48,57,41,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,99,108,115,50,49,48,48,41};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,29),40,97,49,50,49,54,52,32,102,111,114,109,50,48,52,48,32,114,50,48,52,49,32,99,50,48,52,50,41,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,29),40,97,49,50,52,52,56,32,102,111,114,109,50,48,51,48,32,114,50,48,51,49,32,99,50,48,51,50,41,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,57,50,50,32,110,49,57,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,19),40,119,97,108,107,49,32,120,49,57,50,53,32,110,49,57,50,54,41,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,16),40,115,105,109,112,108,105,102,121,32,120,49,57,57,48,41};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,29),40,97,49,50,52,56,49,32,102,111,114,109,49,57,49,48,32,114,49,57,49,49,32,99,49,57,49,50,41,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,14),40,97,49,50,57,56,49,32,98,49,57,48,54,41,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,14),40,97,49,51,48,51,54,32,98,49,56,57,52,41,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,29),40,97,49,50,56,55,54,32,102,111,114,109,49,56,55,56,32,114,49,56,55,57,32,99,49,56,56,48,41,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,15),40,101,120,112,97,110,100,32,98,115,49,56,54,52,41,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,29),40,97,49,51,48,53,56,32,102,111,114,109,49,56,53,52,32,114,49,56,53,53,32,99,49,56,53,54,41,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,14),40,97,49,51,50,53,49,32,120,49,56,52,51,41,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,56,51,48,41,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,29),40,97,49,51,49,50,55,32,102,111,114,109,49,56,49,48,32,114,49,56,49,49,32,99,49,56,49,50,41,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,20),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,55,54,54,41,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,29),40,97,49,51,50,57,55,32,102,111,114,109,49,55,53,49,32,114,49,55,53,50,32,99,49,55,53,51,41,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,29),40,97,49,51,54,51,48,32,102,111,114,109,49,55,51,53,32,114,49,55,51,54,32,99,49,55,51,55,41,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,29),40,97,49,51,55,50,48,32,102,111,114,109,49,55,50,49,32,114,49,55,50,50,32,99,49,55,50,51,41,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,102,111,114,109,49,54,57,48,41,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,29),40,97,49,51,55,55,57,32,102,111,114,109,49,54,56,52,32,114,49,54,56,53,32,99,49,54,56,54,41,0,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,50),40,97,49,51,57,50,49,32,103,49,54,55,50,49,54,55,51,49,54,55,56,32,103,49,54,55,52,49,54,55,53,49,54,55,57,32,103,49,54,55,54,49,54,55,55,49,54,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,50),40,97,49,51,57,51,49,32,103,49,54,53,54,49,54,53,55,49,54,54,50,32,103,49,54,53,56,49,54,53,57,49,54,54,51,32,103,49,54,54,48,49,54,54,49,49,54,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_expand_toplevel)
C_externexport void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13932)
static void C_ccall f_13932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13930)
static void C_ccall f_13930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7853)
static void C_ccall f_7853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13922)
static void C_ccall f_13922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13920)
static void C_ccall f_13920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13780)
static void C_ccall f_13780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13790)
static void C_fcall f_13790(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13806)
static void C_ccall f_13806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13809)
static void C_ccall f_13809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13837)
static void C_ccall f_13837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13812)
static void C_ccall f_13812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13859)
static void C_ccall f_13859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13862)
static void C_ccall f_13862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13908)
static void C_ccall f_13908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13865)
static void C_ccall f_13865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13888)
static void C_ccall f_13888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13900)
static void C_ccall f_13900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13846)
static void C_ccall f_13846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13849)
static void C_ccall f_13849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13856)
static void C_ccall f_13856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13778)
static void C_ccall f_13778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13721)
static void C_ccall f_13721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13750)
static void C_ccall f_13750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13770)
static void C_ccall f_13770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13774)
static void C_ccall f_13774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13719)
static void C_ccall f_13719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13631)
static void C_ccall f_13631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13656)
static void C_ccall f_13656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13663)
static void C_ccall f_13663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13683)
static void C_ccall f_13683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13703)
static void C_ccall f_13703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13707)
static void C_ccall f_13707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13629)
static void C_ccall f_13629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13298)
static void C_ccall f_13298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13305)
static void C_ccall f_13305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13308)
static void C_ccall f_13308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13311)
static void C_ccall f_13311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13314)
static void C_ccall f_13314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13317)
static void C_ccall f_13317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13320)
static void C_ccall f_13320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13323)
static void C_ccall f_13323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13328)
static void C_fcall f_13328(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13344)
static void C_ccall f_13344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13350)
static void C_ccall f_13350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13392)
static void C_ccall f_13392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13460)
static void C_ccall f_13460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13585)
static void C_ccall f_13585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13581)
static void C_ccall f_13581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13463)
static void C_ccall f_13463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13518)
static void C_ccall f_13518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13395)
static void C_ccall f_13395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13434)
static void C_ccall f_13434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13386)
static void C_ccall f_13386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13357)
static void C_ccall f_13357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13296)
static void C_ccall f_13296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13128)
static void C_ccall f_13128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13132)
static void C_ccall f_13132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13141)
static void C_ccall f_13141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13144)
static void C_ccall f_13144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13147)
static void C_ccall f_13147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13150)
static void C_ccall f_13150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13153)
static void C_ccall f_13153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13174)
static void C_fcall f_13174(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13190)
static void C_ccall f_13190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13196)
static void C_ccall f_13196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13252)
static void C_ccall f_13252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13250)
static void C_ccall f_13250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13246)
static void C_ccall f_13246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13238)
static void C_ccall f_13238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13234)
static void C_ccall f_13234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13203)
static void C_ccall f_13203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13172)
static void C_ccall f_13172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13126)
static void C_ccall f_13126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13059)
static void C_ccall f_13059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13063)
static void C_ccall f_13063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13072)
static void C_ccall f_13072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13077)
static void C_fcall f_13077(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13114)
static void C_ccall f_13114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13095)
static void C_ccall f_13095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13057)
static void C_ccall f_13057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7878)
static void C_ccall f_7878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12877)
static void C_ccall f_12877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12881)
static void C_ccall f_12881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12893)
static void C_ccall f_12893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12896)
static void C_ccall f_12896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12899)
static void C_ccall f_12899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12902)
static void C_ccall f_12902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13037)
static void C_ccall f_13037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12917)
static void C_ccall f_12917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13035)
static void C_ccall f_13035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12944)
static void C_fcall f_12944(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13025)
static void C_ccall f_13025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12960)
static void C_fcall f_12960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12982)
static void C_ccall f_12982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12980)
static void C_ccall f_12980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12976)
static void C_ccall f_12976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12875)
static void C_ccall f_12875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12482)
static void C_ccall f_12482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12486)
static void C_ccall f_12486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12489)
static void C_ccall f_12489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12492)
static void C_ccall f_12492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12495)
static void C_ccall f_12495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12864)
static void C_ccall f_12864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12776)
static void C_fcall f_12776(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12780)
static void C_ccall f_12780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12805)
static void C_ccall f_12805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12851)
static void C_ccall f_12851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12836)
static void C_ccall f_12836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12507)
static void C_fcall f_12507(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12554)
static void C_ccall f_12554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12601)
static void C_ccall f_12601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12762)
static void C_ccall f_12762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12770)
static void C_ccall f_12770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12748)
static void C_ccall f_12748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12737)
static void C_ccall f_12737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12745)
static void C_ccall f_12745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12722)
static void C_ccall f_12722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12710)
static void C_ccall f_12710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12691)
static void C_ccall f_12691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12649)
static void C_ccall f_12649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12626)
static void C_ccall f_12626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12580)
static void C_ccall f_12580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12529)
static void C_ccall f_12529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12525)
static void C_ccall f_12525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12497)
static void C_fcall f_12497(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12505)
static void C_ccall f_12505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12480)
static void C_ccall f_12480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7884)
static void C_ccall f_7884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12449)
static void C_ccall f_12449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12453)
static void C_ccall f_12453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12447)
static void C_ccall f_12447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7887)
static void C_ccall f_7887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12165)
static void C_ccall f_12165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12172)
static void C_ccall f_12172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12175)
static void C_ccall f_12175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12178)
static void C_ccall f_12178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12181)
static void C_ccall f_12181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12184)
static void C_ccall f_12184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12346)
static void C_fcall f_12346(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12399)
static void C_ccall f_12399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12421)
static void C_ccall f_12421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12428)
static void C_ccall f_12428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12415)
static void C_ccall f_12415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12362)
static void C_ccall f_12362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12360)
static void C_ccall f_12360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12196)
static void C_fcall f_12196(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12227)
static void C_ccall f_12227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12273)
static void C_ccall f_12273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12323)
static void C_ccall f_12323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12330)
static void C_ccall f_12330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12288)
static void C_ccall f_12288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12302)
static void C_ccall f_12302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12245)
static void C_ccall f_12245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12256)
static void C_ccall f_12256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12186)
static void C_fcall f_12186(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12163)
static void C_ccall f_12163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12144)
static void C_ccall f_12144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12142)
static void C_ccall f_12142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12123)
static void C_ccall f_12123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12121)
static void C_ccall f_12121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12072)
static void C_ccall f_12072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12076)
static void C_ccall f_12076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12113)
static void C_ccall f_12113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12106)
static void C_ccall f_12106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12099)
static void C_ccall f_12099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12070)
static void C_ccall f_12070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_ccall f_7899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12018)
static void C_ccall f_12018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12022)
static void C_ccall f_12022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12025)
static void C_ccall f_12025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12062)
static void C_ccall f_12062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12028)
static void C_ccall f_12028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12043)
static void C_ccall f_12043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12047)
static void C_ccall f_12047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12016)
static void C_ccall f_12016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7902)
static void C_ccall f_7902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11915)
static void C_ccall f_11915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11922)
static void C_ccall f_11922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11925)
static void C_ccall f_11925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11945)
static void C_ccall f_11945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11967)
static C_word C_fcall f_11967(C_word t0);
C_noret_decl(f_11952)
static void C_fcall f_11952(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11959)
static void C_ccall f_11959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11928)
static void C_ccall f_11928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11943)
static void C_ccall f_11943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11935)
static void C_ccall f_11935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11931)
static void C_ccall f_11931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11913)
static void C_ccall f_11913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7905)
static void C_ccall f_7905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11878)
static void C_ccall f_11878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11882)
static void C_ccall f_11882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11900)
static void C_ccall f_11900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11891)
static void C_fcall f_11891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11876)
static void C_ccall f_11876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7908)
static void C_ccall f_7908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9553)
static void C_ccall f_9553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11872)
static void C_ccall f_11872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9557)
static void C_ccall f_9557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9561)
static void C_ccall f_9561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11830)
static void C_ccall f_11830(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11838)
static void C_ccall f_11838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11840)
static void C_fcall f_11840(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11861)
static void C_ccall f_11861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11318)
static void C_ccall f_11318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11325)
static void C_ccall f_11325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11811)
static void C_ccall f_11811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11823)
static void C_ccall f_11823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11334)
static void C_ccall f_11334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11768)
static void C_ccall f_11768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11770)
static void C_fcall f_11770(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11809)
static void C_ccall f_11809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11783)
static void C_ccall f_11783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11794)
static void C_ccall f_11794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11337)
static void C_ccall f_11337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11637)
static void C_fcall f_11637(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11688)
static void C_fcall f_11688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11742)
static void C_ccall f_11742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11700)
static void C_fcall f_11700(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11728)
static void C_ccall f_11728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11724)
static void C_ccall f_11724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11720)
static void C_ccall f_11720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11703)
static void C_ccall f_11703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11685)
static void C_ccall f_11685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11674)
static void C_ccall f_11674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11340)
static void C_ccall f_11340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11631)
static void C_ccall f_11631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11546)
static void C_ccall f_11546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11557)
static void C_ccall f_11557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11560)
static void C_ccall f_11560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11597)
static void C_fcall f_11597(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11623)
static void C_ccall f_11623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11611)
static void C_ccall f_11611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11615)
static void C_ccall f_11615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11595)
static void C_ccall f_11595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11591)
static void C_ccall f_11591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11584)
static void C_ccall f_11584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11580)
static void C_ccall f_11580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11576)
static void C_ccall f_11576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11343)
static void C_ccall f_11343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11346)
static void C_ccall f_11346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11541)
static void C_ccall f_11541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11505)
static void C_ccall f_11505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11533)
static void C_ccall f_11533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11349)
static void C_ccall f_11349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11499)
static void C_ccall f_11499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11503)
static void C_ccall f_11503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11352)
static void C_ccall f_11352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11355)
static void C_ccall f_11355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11457)
static void C_ccall f_11457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11461)
static void C_ccall f_11461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11491)
static void C_ccall f_11491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11487)
static void C_ccall f_11487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11464)
static void C_ccall f_11464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11358)
static void C_ccall f_11358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11379)
static void C_ccall f_11379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11455)
static void C_ccall f_11455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11451)
static void C_ccall f_11451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11447)
static void C_ccall f_11447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11443)
static void C_ccall f_11443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11439)
static void C_ccall f_11439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11435)
static void C_ccall f_11435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11431)
static void C_ccall f_11431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11427)
static void C_ccall f_11427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11423)
static void C_ccall f_11423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11361)
static void C_ccall f_11361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11364)
static void C_ccall f_11364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11233)
static void C_ccall f_11233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11244)
static void C_ccall f_11244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11246)
static void C_fcall f_11246(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11295)
static void C_ccall f_11295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11291)
static void C_ccall f_11291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11274)
static void C_fcall f_11274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11142)
static void C_ccall f_11142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_11142)
static void C_ccall f_11142r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11146)
static void C_ccall f_11146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11149)
static void C_ccall f_11149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11188)
static void C_ccall f_11188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11208)
static void C_ccall f_11208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11198)
static void C_ccall f_11198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11201)
static void C_ccall f_11201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11164)
static void C_ccall f_11164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11170)
static void C_ccall f_11170(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11168)
static void C_ccall f_11168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10934)
static void C_ccall f_10934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_10934)
static void C_ccall f_10934r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_10938)
static void C_ccall f_10938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11096)
static void C_ccall f_11096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11117)
static void C_ccall f_11117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10961)
static void C_ccall f_10961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10964)
static void C_ccall f_10964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11064)
static void C_ccall f_11064(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11086)
static void C_ccall f_11086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10967)
static void C_ccall f_10967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11046)
static void C_ccall f_11046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11058)
static void C_ccall f_11058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10970)
static void C_ccall f_10970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11040)
static void C_ccall f_11040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11044)
static void C_ccall f_11044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10976)
static void C_ccall f_10976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10979)
static void C_ccall f_10979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11028)
static void C_ccall f_11028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10982)
static void C_ccall f_10982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11008)
static void C_ccall f_11008(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10985)
static void C_ccall f_10985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10988)
static void C_ccall f_10988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10540)
static void C_ccall f_10540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10547)
static void C_ccall f_10547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10932)
static void C_ccall f_10932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10563)
static void C_fcall f_10563(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10902)
static void C_ccall f_10902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10571)
static void C_fcall f_10571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10884)
static void C_ccall f_10884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10579)
static void C_ccall f_10579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10880)
static void C_ccall f_10880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10872)
static void C_ccall f_10872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10799)
static void C_ccall f_10799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10797)
static void C_ccall f_10797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10793)
static void C_ccall f_10793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10727)
static void C_ccall f_10727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10774)
static void C_ccall f_10774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10759)
static void C_ccall f_10759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10725)
static void C_ccall f_10725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10721)
static void C_ccall f_10721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10647)
static void C_fcall f_10647(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10717)
static void C_ccall f_10717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10670)
static void C_ccall f_10670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10713)
static void C_ccall f_10713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10705)
static void C_ccall f_10705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10701)
static void C_ccall f_10701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10681)
static void C_ccall f_10681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10635)
static void C_ccall f_10635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10631)
static void C_ccall f_10631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10575)
static void C_ccall f_10575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10567)
static void C_ccall f_10567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10468)
static void C_fcall f_10468(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10472)
static void C_ccall f_10472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10475)
static void C_ccall f_10475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10487)
static void C_fcall f_10487(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10526)
static void C_ccall f_10526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10518)
static void C_ccall f_10518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10478)
static void C_ccall f_10478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10481)
static void C_ccall f_10481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10192)
static void C_fcall f_10192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10199)
static void C_ccall f_10199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10273)
static void C_fcall f_10273(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10300)
static void C_ccall f_10300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10302)
static void C_fcall f_10302(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10462)
static void C_ccall f_10462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10450)
static void C_ccall f_10450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10431)
static void C_ccall f_10431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10413)
static void C_ccall f_10413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10398)
static void C_ccall f_10398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10353)
static void C_ccall f_10353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10325)
static void C_ccall f_10325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10250)
static void C_fcall f_10250(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10262)
static void C_ccall f_10262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10258)
static void C_ccall f_10258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10133)
static void C_ccall f_10133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10139)
static void C_ccall f_10139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10146)
static void C_fcall f_10146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10149)
static void C_ccall f_10149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10065)
static void C_ccall f_10065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10065)
static void C_ccall f_10065r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10085)
static C_word C_fcall f_10085(C_word *a,C_word t0);
C_noret_decl(f_10080)
static C_word C_fcall f_10080(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_10067)
static C_word C_fcall f_10067(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_10043)
static void C_ccall f_10043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10050)
static void C_ccall f_10050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9962)
static void C_ccall f_9962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9972)
static void C_ccall f_9972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9975)
static void C_ccall f_9975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9978)
static void C_ccall f_9978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9981)
static void C_ccall f_9981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10024)
static void C_ccall f_10024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10028)
static void C_ccall f_10028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9984)
static void C_ccall f_9984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9987)
static void C_ccall f_9987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9990)
static void C_ccall f_9990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9873)
static void C_ccall f_9873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9883)
static void C_ccall f_9883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9886)
static void C_ccall f_9886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9953)
static void C_ccall f_9953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9949)
static void C_ccall f_9949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9889)
static void C_ccall f_9889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9945)
static void C_ccall f_9945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9892)
static void C_ccall f_9892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9931)
static void C_ccall f_9931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9935)
static void C_ccall f_9935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9895)
static void C_ccall f_9895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9898)
static void C_ccall f_9898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9904)
static void C_ccall f_9904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9852)
static void C_fcall f_9852(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9859)
static void C_ccall f_9859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9832)
static void C_ccall f_9832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9836)
static void C_ccall f_9836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9829)
static void C_ccall f_9829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9789)
static void C_ccall f_9789(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9789)
static void C_ccall f_9789r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9793)
static void C_ccall f_9793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9783)
static C_word C_fcall f_9783(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3);
C_noret_decl(f_9765)
static void C_ccall f_9765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9755)
static C_word C_fcall f_9755(C_word t0);
C_noret_decl(f_9737)
static C_word C_fcall f_9737(C_word t0);
C_noret_decl(f_9719)
static C_word C_fcall f_9719(C_word t0);
C_noret_decl(f_9701)
static C_word C_fcall f_9701(C_word t0);
C_noret_decl(f_9683)
static C_word C_fcall f_9683(C_word t0);
C_noret_decl(f_9665)
static void C_ccall f_9665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9656)
static void C_ccall f_9656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9647)
static C_word C_fcall f_9647(C_word t0);
C_noret_decl(f_9629)
static C_word C_fcall f_9629(C_word t0);
C_noret_decl(f_9611)
static C_word C_fcall f_9611(C_word t0);
C_noret_decl(f_9602)
static void C_fcall f_9602(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9593)
static C_word C_fcall f_9593(C_word t0);
C_noret_decl(f_9575)
static void C_ccall f_9575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7917)
static void C_ccall f_7917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7931)
static void C_ccall f_7931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7935)
static void C_ccall f_7935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7939)
static void C_ccall f_7939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7944)
static void C_ccall f_7944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7958)
static void C_ccall f_7958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7962)
static void C_ccall f_7962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7966)
static void C_ccall f_7966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7971)
static void C_ccall f_7971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7982)
static void C_ccall f_7982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7987)
static void C_ccall f_7987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7991)
static void C_ccall f_7991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7995)
static void C_ccall f_7995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7999)
static void C_ccall f_7999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8004)
static void C_ccall f_8004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9522)
static void C_fcall f_9522(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9529)
static void C_ccall f_9529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9492)
static void C_ccall f_9492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9499)
static void C_ccall f_9499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9506)
static void C_ccall f_9506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9466)
static void C_ccall f_9466(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9444)
static void C_ccall f_9444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9451)
static void C_ccall f_9451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9351)
static void C_ccall f_9351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9393)
static void C_ccall f_9393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9442)
static void C_ccall f_9442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9425)
static void C_ccall f_9425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9404)
static void C_ccall f_9404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9364)
static void C_fcall f_9364(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9278)
static void C_ccall f_9278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9304)
static void C_ccall f_9304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9349)
static void C_ccall f_9349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9332)
static void C_ccall f_9332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9024)
static void C_ccall f_9024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9071)
static void C_ccall f_9071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9269)
static void C_ccall f_9269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9265)
static void C_ccall f_9265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9232)
static void C_ccall f_9232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9240)
static void C_ccall f_9240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9074)
static void C_ccall f_9074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9080)
static void C_ccall f_9080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9092)
static void C_ccall f_9092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9158)
static void C_fcall f_9158(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9173)
static void C_ccall f_9173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9095)
static void C_fcall f_9095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9129)
static void C_fcall f_9129(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9098)
static void C_ccall f_9098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9127)
static void C_ccall f_9127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9123)
static void C_ccall f_9123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9119)
static void C_ccall f_9119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8817)
static void C_ccall f_8817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8847)
static void C_ccall f_8847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8947)
static void C_ccall f_8947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8970)
static void C_fcall f_8970(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8984)
static void C_ccall f_8984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8988)
static void C_ccall f_8988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8957)
static void C_ccall f_8957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8907)
static void C_ccall f_8907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8911)
static void C_ccall f_8911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8856)
static void C_ccall f_8856(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8864)
static void C_fcall f_8864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8841)
static void C_ccall f_8841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8529)
static void C_ccall f_8529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8536)
static void C_ccall f_8536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8575)
static void C_fcall f_8575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8585)
static void C_fcall f_8585(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8716)
static void C_ccall f_8716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8720)
static void C_ccall f_8720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8649)
static void C_ccall f_8649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8645)
static void C_ccall f_8645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8583)
static void C_ccall f_8583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8579)
static void C_ccall f_8579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8411)
static void C_ccall f_8411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8415)
static void C_ccall f_8415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8190)
static void C_ccall f_8190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8240)
static void C_ccall f_8240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8354)
static void C_fcall f_8354(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8292)
static void C_ccall f_8292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8300)
static void C_ccall f_8300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8296)
static void C_ccall f_8296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8288)
static void C_ccall f_8288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8106)
static void C_ccall f_8106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8113)
static void C_fcall f_8113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8116)
static void C_ccall f_8116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8165)
static void C_ccall f_8165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8161)
static void C_ccall f_8161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8156)
static void C_ccall f_8156(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8150)
static void C_ccall f_8150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8012)
static void C_ccall f_8012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8056)
static void C_ccall f_8056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8052)
static void C_ccall f_8052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8006)
static void C_ccall f_8006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7008)
static void C_ccall f_7008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7012)
static void C_ccall f_7012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7015)
static void C_ccall f_7015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7018)
static void C_ccall f_7018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7620)
static void C_ccall f_7620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7623)
static void C_ccall f_7623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7842)
static void C_ccall f_7842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7827)
static void C_ccall f_7827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7626)
static void C_ccall f_7626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7631)
static void C_ccall f_7631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7644)
static void C_ccall f_7644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7794)
static void C_ccall f_7794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7647)
static void C_ccall f_7647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7771)
static void C_ccall f_7771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7779)
static void C_ccall f_7779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7653)
static void C_ccall f_7653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7725)
static void C_ccall f_7725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7759)
static void C_ccall f_7759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7656)
static void C_ccall f_7656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7683)
static void C_ccall f_7683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7723)
static void C_ccall f_7723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7659)
static void C_ccall f_7659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7681)
static void C_ccall f_7681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7677)
static void C_ccall f_7677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7662)
static void C_ccall f_7662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7673)
static void C_ccall f_7673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7669)
static void C_ccall f_7669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7629)
static void C_ccall f_7629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7162)
static void C_fcall f_7162(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7181)
static void C_fcall f_7181(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7190)
static void C_ccall f_7190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7202)
static void C_ccall f_7202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7389)
static void C_ccall f_7389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static void C_ccall f_7536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7542)
static void C_ccall f_7542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_ccall f_7575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7579)
static void C_ccall f_7579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7544)
static void C_ccall f_7544(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7564)
static void C_ccall f_7564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7560)
static void C_ccall f_7560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7552)
static void C_ccall f_7552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7392)
static void C_ccall f_7392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7401)
static void C_fcall f_7401(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7511)
static void C_ccall f_7511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7499)
static void C_ccall f_7499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7478)
static void C_ccall f_7478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7459)
static void C_ccall f_7459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7417)
static void C_ccall f_7417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7285)
static void C_ccall f_7285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7293)
static void C_fcall f_7293(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7379)
static void C_ccall f_7379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7305)
static void C_fcall f_7305(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7213)
static void C_fcall f_7213(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7075)
static void C_fcall f_7075(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7079)
static void C_ccall f_7079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7082)
static void C_ccall f_7082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7156)
static void C_ccall f_7156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7097)
static void C_ccall f_7097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7103)
static void C_ccall f_7103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7145)
static void C_ccall f_7145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7139)
static void C_ccall f_7139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7143)
static void C_ccall f_7143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7107)
static void C_ccall f_7107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7114)
static void C_ccall f_7114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7118)
static void C_ccall f_7118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7132)
static void C_ccall f_7132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7135)
static void C_ccall f_7135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7085)
static void C_ccall f_7085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7032)
static void C_fcall f_7032(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7045)
static void C_ccall f_7045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7052)
static void C_ccall f_7052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6716)
static void C_ccall f_6716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6878)
static void C_ccall f_6878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6881)
static void C_fcall f_6881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6884)
static void C_ccall f_6884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6887)
static void C_fcall f_6887(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6849)
static void C_fcall f_6849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6982)
static void C_fcall f_6982(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6986)
static void C_ccall f_6986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6719)
static void C_ccall f_6719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6816)
static void C_ccall f_6816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6819)
static void C_ccall f_6819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6729)
static void C_ccall f_6729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6666)
static void C_fcall f_6666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6657)
static void C_fcall f_6657(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6254)
static void C_fcall f_6254(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6385)
static void C_fcall f_6385(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_fcall f_6390(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6628)
static void C_ccall f_6628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6587)
static void C_ccall f_6587(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6591)
static void C_ccall f_6591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6409)
static void C_fcall f_6409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6414)
static void C_fcall f_6414(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6433)
static void C_ccall f_6433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6362)
static C_word C_fcall f_6362(C_word t0);
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6312)
static void C_fcall f_6312(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_fcall f_6257(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6264)
static void C_ccall f_6264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6269)
static void C_fcall f_6269(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6273)
static void C_ccall f_6273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6298)
static void C_ccall f_6298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6287)
static void C_ccall f_6287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6216)
static void C_ccall f_6216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6238)
static void C_ccall f_6238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6213)
static void C_ccall f_6213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6135)
static void C_ccall f_6135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6138)
static void C_fcall f_6138(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6191)
static void C_ccall f_6191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6052)
static void C_fcall f_6052(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6055)
static void C_fcall f_6055(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6104)
static void C_ccall f_6104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5742)
static void C_fcall f_5742(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5748)
static void C_fcall f_5748(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5770)
static void C_fcall f_5770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5954)
static void C_ccall f_5954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5926)
static void C_ccall f_5926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5793)
static void C_fcall f_5793(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5840)
static void C_ccall f_5840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_ccall f_5855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5565)
static void C_fcall f_5565(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5575)
static void C_fcall f_5575(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_fcall f_5621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5639)
static void C_fcall f_5639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5606)
static void C_ccall f_5606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5460)
static void C_ccall f_5460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5495)
static void C_ccall f_5495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5491)
static void C_ccall f_5491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5317)
static void C_fcall f_5317(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5340)
static void C_fcall f_5340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4746)
static void C_fcall f_4746(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5236)
static void C_fcall f_5236(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_fcall f_5155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5109)
static void C_fcall f_5109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_fcall f_5112(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5072)
static void C_fcall f_5072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_fcall f_5034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4933)
static void C_ccall f_4933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_fcall f_4968(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_fcall f_4764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_fcall f_4776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4767)
static void C_fcall f_4767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4672)
static void C_fcall f_4672(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4691)
static void C_fcall f_4691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_fcall f_4622(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4611)
static void C_ccall f_4611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_fcall f_4526(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_fcall f_4328(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_fcall f_4430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4205)
static void C_fcall f_4205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4265)
static void C_fcall f_4265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_fcall f_4277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4026)
static void C_fcall f_4026(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4181)
static void C_ccall f_4181(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4181)
static void C_ccall f_4181r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4167)
static void C_ccall f_4167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_fcall f_4064(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4081)
static void C_fcall f_4081(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4100)
static void C_fcall f_4100(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_fcall f_4061(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_fcall f_3977(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3806)
static void C_fcall f_3806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3801)
static void C_fcall f_3801(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3708)
static void C_fcall f_3708(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3730)
static void C_fcall f_3730(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_fcall f_3676(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3627)
static void C_fcall f_3627(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_fcall f_3637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_fcall f_3609(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

C_noret_decl(trf_13790)
static void C_fcall trf_13790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13790(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13790(t0,t1,t2);}

C_noret_decl(trf_13328)
static void C_fcall trf_13328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13328(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13328(t0,t1,t2);}

C_noret_decl(trf_13174)
static void C_fcall trf_13174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13174(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13174(t0,t1,t2);}

C_noret_decl(trf_13077)
static void C_fcall trf_13077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13077(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13077(t0,t1,t2);}

C_noret_decl(trf_12944)
static void C_fcall trf_12944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12944(t0,t1);}

C_noret_decl(trf_12960)
static void C_fcall trf_12960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12960(t0,t1);}

C_noret_decl(trf_12776)
static void C_fcall trf_12776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12776(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12776(t0,t1,t2);}

C_noret_decl(trf_12507)
static void C_fcall trf_12507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12507(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12507(t0,t1,t2,t3);}

C_noret_decl(trf_12497)
static void C_fcall trf_12497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12497(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12497(t0,t1,t2,t3);}

C_noret_decl(trf_12346)
static void C_fcall trf_12346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12346(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12346(t0,t1,t2);}

C_noret_decl(trf_12196)
static void C_fcall trf_12196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12196(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12196(t0,t1,t2);}

C_noret_decl(trf_12186)
static void C_fcall trf_12186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12186(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12186(t0,t1,t2);}

C_noret_decl(trf_11952)
static void C_fcall trf_11952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11952(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11952(t0,t1);}

C_noret_decl(trf_11891)
static void C_fcall trf_11891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11891(t0,t1);}

C_noret_decl(trf_11840)
static void C_fcall trf_11840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11840(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11840(t0,t1,t2);}

C_noret_decl(trf_11770)
static void C_fcall trf_11770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11770(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11770(t0,t1,t2);}

C_noret_decl(trf_11637)
static void C_fcall trf_11637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11637(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11637(t0,t1,t2);}

C_noret_decl(trf_11688)
static void C_fcall trf_11688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11688(t0,t1);}

C_noret_decl(trf_11700)
static void C_fcall trf_11700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11700(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11700(t0,t1);}

C_noret_decl(trf_11597)
static void C_fcall trf_11597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11597(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11597(t0,t1,t2);}

C_noret_decl(trf_11246)
static void C_fcall trf_11246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11246(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11246(t0,t1,t2);}

C_noret_decl(trf_11274)
static void C_fcall trf_11274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11274(t0,t1);}

C_noret_decl(trf_10563)
static void C_fcall trf_10563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10563(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10563(t0,t1);}

C_noret_decl(trf_10571)
static void C_fcall trf_10571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10571(t0,t1);}

C_noret_decl(trf_10647)
static void C_fcall trf_10647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10647(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10647(t0,t1,t2);}

C_noret_decl(trf_10468)
static void C_fcall trf_10468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10468(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10468(t0,t1);}

C_noret_decl(trf_10487)
static void C_fcall trf_10487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10487(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10487(t0,t1,t2);}

C_noret_decl(trf_10192)
static void C_fcall trf_10192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10192(t0,t1);}

C_noret_decl(trf_10273)
static void C_fcall trf_10273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10273(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10273(t0,t1,t2);}

C_noret_decl(trf_10302)
static void C_fcall trf_10302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10302(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10302(t0,t1,t2);}

C_noret_decl(trf_10250)
static void C_fcall trf_10250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10250(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10250(t0,t1,t2,t3);}

C_noret_decl(trf_10146)
static void C_fcall trf_10146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10146(t0,t1);}

C_noret_decl(trf_9852)
static void C_fcall trf_9852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9852(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9852(t0,t1,t2,t3);}

C_noret_decl(trf_9602)
static void C_fcall trf_9602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9602(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9602(t0,t1,t2);}

C_noret_decl(trf_9522)
static void C_fcall trf_9522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9522(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9522(t0,t1,t2);}

C_noret_decl(trf_9364)
static void C_fcall trf_9364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9364(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9364(t0,t1);}

C_noret_decl(trf_9158)
static void C_fcall trf_9158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9158(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9158(t0,t1);}

C_noret_decl(trf_9095)
static void C_fcall trf_9095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9095(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9095(t0,t1);}

C_noret_decl(trf_9129)
static void C_fcall trf_9129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9129(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9129(t0,t1,t2,t3);}

C_noret_decl(trf_8970)
static void C_fcall trf_8970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8970(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8970(t0,t1,t2);}

C_noret_decl(trf_8864)
static void C_fcall trf_8864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8864(t0,t1);}

C_noret_decl(trf_8575)
static void C_fcall trf_8575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8575(t0,t1);}

C_noret_decl(trf_8585)
static void C_fcall trf_8585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8585(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8585(t0,t1,t2);}

C_noret_decl(trf_8354)
static void C_fcall trf_8354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8354(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8354(t0,t1);}

C_noret_decl(trf_8113)
static void C_fcall trf_8113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8113(t0,t1);}

C_noret_decl(trf_7162)
static void C_fcall trf_7162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7162(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7162(t0,t1,t2);}

C_noret_decl(trf_7181)
static void C_fcall trf_7181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7181(t0,t1);}

C_noret_decl(trf_7401)
static void C_fcall trf_7401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7401(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7401(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7293)
static void C_fcall trf_7293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7293(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7293(t0,t1,t2,t3);}

C_noret_decl(trf_7305)
static void C_fcall trf_7305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7305(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7305(t0,t1,t2,t3);}

C_noret_decl(trf_7213)
static void C_fcall trf_7213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7213(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7213(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7075)
static void C_fcall trf_7075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7075(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7075(t0,t1,t2);}

C_noret_decl(trf_7032)
static void C_fcall trf_7032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7032(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7032(t0,t1,t2);}

C_noret_decl(trf_6881)
static void C_fcall trf_6881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6881(t0,t1);}

C_noret_decl(trf_6887)
static void C_fcall trf_6887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6887(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6887(t0,t1);}

C_noret_decl(trf_6849)
static void C_fcall trf_6849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6849(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6849(t0,t1);}

C_noret_decl(trf_6982)
static void C_fcall trf_6982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6982(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6982(t0,t1,t2,t3);}

C_noret_decl(trf_6666)
static void C_fcall trf_6666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6666(t0,t1);}

C_noret_decl(trf_6657)
static void C_fcall trf_6657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6657(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6657(t0,t1,t2);}

C_noret_decl(trf_6254)
static void C_fcall trf_6254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6254(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6254(t0,t1,t2,t3);}

C_noret_decl(trf_6385)
static void C_fcall trf_6385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6385(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6385(t0,t1);}

C_noret_decl(trf_6390)
static void C_fcall trf_6390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6390(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6390(t0,t1,t2,t3);}

C_noret_decl(trf_6409)
static void C_fcall trf_6409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6409(t0,t1);}

C_noret_decl(trf_6414)
static void C_fcall trf_6414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6414(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6414(t0,t1,t2,t3);}

C_noret_decl(trf_6312)
static void C_fcall trf_6312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6312(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6312(t0,t1,t2);}

C_noret_decl(trf_6257)
static void C_fcall trf_6257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6257(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6257(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6269)
static void C_fcall trf_6269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6269(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6269(t0,t1,t2);}

C_noret_decl(trf_6138)
static void C_fcall trf_6138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6138(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6138(t0,t1,t2,t3);}

C_noret_decl(trf_6052)
static void C_fcall trf_6052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6052(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6052(t0,t1,t2,t3);}

C_noret_decl(trf_6055)
static void C_fcall trf_6055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6055(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6055(t0,t1,t2,t3);}

C_noret_decl(trf_5742)
static void C_fcall trf_5742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5742(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5742(t0,t1,t2);}

C_noret_decl(trf_5748)
static void C_fcall trf_5748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5748(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5748(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5770)
static void C_fcall trf_5770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5770(t0,t1);}

C_noret_decl(trf_5793)
static void C_fcall trf_5793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5793(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5793(t0,t1,t2);}

C_noret_decl(trf_5565)
static void C_fcall trf_5565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5565(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5565(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5575)
static void C_fcall trf_5575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5575(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5575(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5621)
static void C_fcall trf_5621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5621(t0,t1);}

C_noret_decl(trf_5639)
static void C_fcall trf_5639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5639(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5639(t0,t1);}

C_noret_decl(trf_5305)
static void C_fcall trf_5305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5305(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5305(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5317)
static void C_fcall trf_5317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5317(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5317(t0,t1,t2,t3);}

C_noret_decl(trf_5340)
static void C_fcall trf_5340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5340(t0,t1);}

C_noret_decl(trf_4746)
static void C_fcall trf_4746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4746(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4746(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5236)
static void C_fcall trf_5236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5236(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5236(t0,t1);}

C_noret_decl(trf_5155)
static void C_fcall trf_5155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5155(t0,t1);}

C_noret_decl(trf_5109)
static void C_fcall trf_5109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5109(t0,t1);}

C_noret_decl(trf_5112)
static void C_fcall trf_5112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5112(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5112(t0,t1);}

C_noret_decl(trf_5072)
static void C_fcall trf_5072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5072(t0,t1);}

C_noret_decl(trf_5034)
static void C_fcall trf_5034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5034(t0,t1);}

C_noret_decl(trf_4968)
static void C_fcall trf_4968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4968(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4968(t0,t1);}

C_noret_decl(trf_4764)
static void C_fcall trf_4764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4764(t0,t1);}

C_noret_decl(trf_4776)
static void C_fcall trf_4776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4776(t0,t1);}

C_noret_decl(trf_4767)
static void C_fcall trf_4767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4767(t0,t1);}

C_noret_decl(trf_4712)
static void C_fcall trf_4712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4712(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4712(t0,t1,t2);}

C_noret_decl(trf_4672)
static void C_fcall trf_4672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4672(t0,t1,t2);}

C_noret_decl(trf_4691)
static void C_fcall trf_4691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4691(t0,t1);}

C_noret_decl(trf_4622)
static void C_fcall trf_4622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4622(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4622(t0,t1,t2);}

C_noret_decl(trf_4526)
static void C_fcall trf_4526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4526(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4526(t0,t1,t2);}

C_noret_decl(trf_4328)
static void C_fcall trf_4328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4328(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4328(t0,t1);}

C_noret_decl(trf_4430)
static void C_fcall trf_4430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4430(t0,t1);}

C_noret_decl(trf_4205)
static void C_fcall trf_4205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4205(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4205(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4265)
static void C_fcall trf_4265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4265(t0,t1);}

C_noret_decl(trf_4277)
static void C_fcall trf_4277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4277(t0,t1);}

C_noret_decl(trf_4026)
static void C_fcall trf_4026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4026(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4026(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4064)
static void C_fcall trf_4064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4064(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4064(t0,t1);}

C_noret_decl(trf_4081)
static void C_fcall trf_4081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4081(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4081(t0,t1,t2);}

C_noret_decl(trf_4100)
static void C_fcall trf_4100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4100(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4100(t0,t1);}

C_noret_decl(trf_4061)
static void C_fcall trf_4061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4061(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4061(t0,t1);}

C_noret_decl(trf_3977)
static void C_fcall trf_3977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3977(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3977(t0,t1,t2);}

C_noret_decl(trf_3806)
static void C_fcall trf_3806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3806(t0,t1);}

C_noret_decl(trf_3801)
static void C_fcall trf_3801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3801(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3801(t0,t1,t2);}

C_noret_decl(trf_3708)
static void C_fcall trf_3708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3708(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3708(t0,t1,t2,t3);}

C_noret_decl(trf_3730)
static void C_fcall trf_3730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3730(t0,t1);}

C_noret_decl(trf_3676)
static void C_fcall trf_3676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3676(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3676(t0,t1);}

C_noret_decl(trf_3627)
static void C_fcall trf_3627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3627(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3627(t0,t1,t2);}

C_noret_decl(trf_3637)
static void C_fcall trf_3637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3637(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3637(t0,t1);}

C_noret_decl(trf_3609)
static void C_fcall trf_3609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3609(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3609(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_expand_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_expand_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("expand_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3794)){
C_save(t1);
C_rereclaim2(3794*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,402);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],12,"\003sysfeatures");
lf[4]=C_h_intern(&lf[4],2,"pp");
lf[5]=C_h_intern(&lf[5],5,"print");
lf[8]=C_h_intern(&lf[8],23,"\003syscurrent-environment");
lf[9]=C_h_intern(&lf[9],28,"\003syscurrent-meta-environment");
lf[11]=C_h_intern(&lf[11],7,"\003sysget");
lf[12]=C_h_intern(&lf[12],16,"\004coremacro-alias");
lf[14]=C_h_intern(&lf[14],7,"<macro>");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\011aliasing ");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\004 to ");
lf[17]=C_h_intern(&lf[17],8,"\003sysput!");
lf[18]=C_h_intern(&lf[18],6,"gensym");
lf[19]=C_h_intern(&lf[19],21,"\003sysqualified-symbol\077");
lf[21]=C_h_intern(&lf[21],7,"\003sysmap");
lf[22]=C_h_intern(&lf[22],16,"\003sysstrip-syntax");
lf[23]=C_h_intern(&lf[23],21,"\003sysalias-global-hook");
lf[24]=C_h_intern(&lf[24],3,"get");
lf[25]=C_h_intern(&lf[25],12,"list->vector");
lf[26]=C_h_intern(&lf[26],12,"vector->list");
lf[27]=C_h_intern(&lf[27],9,"\003syserror");
lf[28]=C_h_intern(&lf[28],12,"strip-syntax");
lf[29]=C_h_intern(&lf[29],21,"\003sysmacro-environment");
lf[30]=C_h_intern(&lf[30],29,"\003syschicken-macro-environment");
lf[31]=C_h_intern(&lf[31],33,"\003syschicken-ffi-macro-environment");
lf[32]=C_h_intern(&lf[32],28,"\003sysextend-macro-environment");
lf[33]=C_h_intern(&lf[33],14,"\003syscopy-macro");
lf[34]=C_h_intern(&lf[34],6,"macro\077");
lf[35]=C_h_intern(&lf[35],20,"\003sysunregister-macro");
lf[36]=C_h_intern(&lf[36],4,"caar");
lf[37]=C_h_intern(&lf[37],15,"undefine-macro!");
lf[38]=C_h_intern(&lf[38],12,"\003sysexpand-0");
lf[39]=C_h_intern(&lf[39],9,"\003sysabort");
lf[40]=C_h_intern(&lf[40],9,"condition");
lf[41]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[42]=C_h_intern(&lf[42],13,"string-append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[45]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[46]=C_h_intern(&lf[46],3,"exn");
lf[47]=C_h_intern(&lf[47],3,"-->");
lf[48]=C_h_intern(&lf[48],22,"with-exception-handler");
lf[49]=C_h_intern(&lf[49],30,"call-with-current-continuation");
lf[50]=C_h_intern(&lf[50],10,"\000STATIC-SE");
lf[51]=C_h_intern(&lf[51],10,"\003sysappend");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020invoking macro: ");
lf[53]=C_h_intern(&lf[53],21,"\003syssyntax-error-hook");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[55]=C_h_intern(&lf[55],7,"\000EXPAND");
lf[56]=C_h_intern(&lf[56],3,"\000SE");
lf[57]=C_h_intern(&lf[57],1,"_");
lf[58]=C_h_intern(&lf[58],3,"let");
lf[59]=C_h_intern(&lf[59],8,"\004corelet");
lf[60]=C_h_intern(&lf[60],16,"\004coreloop-lambda");
lf[61]=C_h_intern(&lf[61],11,"\004coreletrec");
lf[62]=C_h_intern(&lf[62],8,"\004coreapp");
lf[63]=C_h_intern(&lf[63],4,"cadr");
lf[64]=C_h_intern(&lf[64],16,"\003syscheck-syntax");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[66]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[67]=C_h_intern(&lf[67],10,"\003syssetter");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_h_intern(&lf[69],4,"set!");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],9,"\004coreset!");
lf[72]=C_h_intern(&lf[72],25,"\003sysenable-runtime-macros");
lf[73]=C_h_intern(&lf[73],17,"\003sysmodule-rename");
lf[74]=C_h_intern(&lf[74],18,"\003sysstring->symbol");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[77]=C_h_intern(&lf[77],22,"\003sysregister-undefined");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\025(ALIAS) global alias ");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[80]=C_h_intern(&lf[80],18,"\003syscurrent-module");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\023(ALIAS) primitive: ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\020(ALIAS) marked: ");
lf[83]=C_h_intern(&lf[83],14,"\004coreprimitive");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000 (ALIAS) in current environment: ");
lf[85]=C_h_intern(&lf[85],12,"\004corealiased");
lf[86]=C_h_intern(&lf[86],10,"\003sysexpand");
lf[87]=C_h_intern(&lf[87],6,"expand");
lf[88]=C_h_intern(&lf[88],25,"\003sysextended-lambda-list\077");
lf[89]=C_h_intern(&lf[89],6,"#!rest");
lf[90]=C_h_intern(&lf[90],10,"#!optional");
lf[91]=C_h_intern(&lf[91],5,"#!key");
lf[92]=C_h_intern(&lf[92],7,"reverse");
lf[93]=C_h_intern(&lf[93],31,"\003sysexpand-extended-lambda-list");
lf[94]=C_h_intern(&lf[94],5,"cadar");
lf[95]=C_h_intern(&lf[95],5,"quote");
lf[96]=C_h_intern(&lf[96],15,"\003sysget-keyword");
lf[97]=C_h_intern(&lf[97],11,"\004corelambda");
lf[98]=C_h_intern(&lf[98],15,"string->keyword");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[101]=C_h_intern(&lf[101],3,"tmp");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[110]=C_h_intern(&lf[110],14,"let-optionals*");
lf[111]=C_h_intern(&lf[111],13,"let-optionals");
lf[112]=C_h_intern(&lf[112],8,"optional");
lf[113]=C_h_intern(&lf[113],4,"let*");
lf[114]=C_h_intern(&lf[114],3,"map");
lf[115]=C_h_intern(&lf[115],21,"\003syscanonicalize-body");
lf[116]=C_h_intern(&lf[116],5,"begin");
lf[117]=C_h_intern(&lf[117],6,"define");
lf[118]=C_h_intern(&lf[118],13,"define-values");
lf[119]=C_h_intern(&lf[119],5,"\000BODY");
lf[120]=C_h_intern(&lf[120],20,"\003syscall-with-values");
lf[121]=C_h_intern(&lf[121],14,"\004coreundefined");
lf[122]=C_h_intern(&lf[122],3,"cdr");
lf[123]=C_h_intern(&lf[123],13,"letrec-syntax");
lf[124]=C_h_intern(&lf[124],13,"define-syntax");
lf[125]=C_h_intern(&lf[125],5,"cdadr");
lf[126]=C_h_intern(&lf[126],6,"lambda");
lf[127]=C_h_intern(&lf[127],5,"caadr");
lf[128]=C_h_intern(&lf[128],25,"\003sysexpand-curried-define");
lf[129]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[132]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-syntax\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[138]=C_h_intern(&lf[138],24,"\003sysline-number-database");
lf[139]=C_h_intern(&lf[139],24,"\003syssyntax-error-culprit");
lf[140]=C_h_intern(&lf[140],15,"\003syssignal-hook");
lf[141]=C_h_intern(&lf[141],13,"\000syntax-error");
lf[142]=C_h_intern(&lf[142],12,"syntax-error");
lf[143]=C_h_intern(&lf[143],15,"get-line-number");
lf[144]=C_h_intern(&lf[144],18,"\003syshash-table-ref");
lf[145]=C_h_intern(&lf[145],8,"keyword\077");
lf[146]=C_h_intern(&lf[146],14,"symbol->string");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[156]=C_h_intern(&lf[156],4,"pair");
lf[157]=C_h_intern(&lf[157],5,"pair\077");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[159]=C_h_intern(&lf[159],8,"variable");
lf[160]=C_h_intern(&lf[160],7,"symbol\077");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[162]=C_h_intern(&lf[162],6,"symbol");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[164]=C_h_intern(&lf[164],4,"list");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[166]=C_h_intern(&lf[166],6,"number");
lf[167]=C_h_intern(&lf[167],7,"number\077");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[169]=C_h_intern(&lf[169],6,"string");
lf[170]=C_h_intern(&lf[170],7,"string\077");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[172]=C_h_intern(&lf[172],11,"lambda-list");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[177]=C_h_intern(&lf[177],18,"\003syser-transformer");
lf[178]=C_h_intern(&lf[178],12,"\000RENAME/RENV");
lf[179]=C_h_intern(&lf[179],14,"\000RENAME/LOOKUP");
lf[180]=C_h_intern(&lf[180],20,"\000RENAME/LOOKUP/MACRO");
lf[181]=C_h_intern(&lf[181],7,"\000RENAME");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\016  (lookup/DSE ");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\005 --> ");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[186]=C_h_intern(&lf[186],8,"\000COMPARE");
lf[187]=C_h_intern(&lf[187],17,"\003sysexpand-import");
lf[188]=C_h_intern(&lf[188],17,"\003sysstring-append");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[190]=C_h_intern(&lf[190],18,"\003syssymbol->string");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid prefix");
lf[194]=C_h_intern(&lf[194],15,"\003sysfind-module");
lf[195]=C_h_intern(&lf[195],8,"\003sysload");
lf[196]=C_h_intern(&lf[196],16,"\003sysdynamic-wind");
lf[197]=C_h_intern(&lf[197],26,"\003sysmeta-macro-environment");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000$can not import from undefined module");
lf[199]=C_h_intern(&lf[199],18,"\003sysfind-extension");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\007.import");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[202]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[204]=C_h_intern(&lf[204],8,"\003syswarn");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\037renamed identifier not imported");
lf[206]=C_h_intern(&lf[206],12,"\003sysfor-each");
lf[207]=C_h_intern(&lf[207],8,"\003sysdelq");
lf[208]=C_h_intern(&lf[208],4,"cdar");
lf[209]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000");
lf[210]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid import specification");
lf[212]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000$re-importing already imported syntax");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\047re-importing already imported identfier");
lf[215]=C_h_intern(&lf[215],25,"\003sysmark-imported-symbols");
lf[216]=C_h_intern(&lf[216],2,"\000S");
lf[217]=C_h_intern(&lf[217],10,"<toplevel>");
lf[218]=C_h_intern(&lf[218],2,"\000V");
lf[219]=C_h_intern(&lf[219],7,"\000IMPORT");
lf[220]=C_h_intern(&lf[220],6,"module");
lf[221]=C_h_intern(&lf[221],14,"\003sysblock-set!");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[225]=C_h_intern(&lf[225],6,"prefix");
lf[226]=C_h_intern(&lf[226],6,"except");
lf[227]=C_h_intern(&lf[227],6,"rename");
lf[228]=C_h_intern(&lf[228],4,"only");
lf[229]=C_h_intern(&lf[229],29,"\003sysinitial-macro-environment");
lf[230]=C_h_intern(&lf[230],24,"\003sysprocess-syntax-rules");
lf[231]=C_h_intern(&lf[231],7,"\003syscar");
lf[232]=C_h_intern(&lf[232],7,"\003syscdr");
lf[233]=C_h_intern(&lf[233],11,"\003sysvector\077");
lf[234]=C_h_intern(&lf[234],17,"\003sysvector-length");
lf[235]=C_h_intern(&lf[235],14,"\003sysvector-ref");
lf[236]=C_h_intern(&lf[236],16,"\003sysvector->list");
lf[237]=C_h_intern(&lf[237],16,"\003syslist->vector");
lf[238]=C_h_intern(&lf[238],6,"\003sys>=");
lf[239]=C_h_intern(&lf[239],5,"\003sys=");
lf[240]=C_h_intern(&lf[240],5,"\003sys+");
lf[241]=C_h_intern(&lf[241],8,"\003syscons");
lf[242]=C_h_intern(&lf[242],7,"\003syseq\077");
lf[243]=C_h_intern(&lf[243],10,"\003sysequal\077");
lf[244]=C_h_intern(&lf[244],9,"\003syslist\077");
lf[245]=C_h_intern(&lf[245],9,"\003sysmap-n");
lf[246]=C_h_intern(&lf[246],9,"\003sysnull\077");
lf[247]=C_h_intern(&lf[247],9,"\003syspair\077");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\026ill-formed syntax rule");
lf[250]=C_h_intern(&lf[250],6,"syntax");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000,template dimension error (too few ellipses\077)");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\021too many ellipses");
lf[253]=C_h_intern(&lf[253],9,"\003sysapply");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000 segment matching not implemented");
lf[255]=C_h_intern(&lf[255],4,"temp");
lf[256]=C_h_intern(&lf[256],4,"tail");
lf[257]=C_h_intern(&lf[257],2,"or");
lf[258]=C_h_intern(&lf[258],4,"loop");
lf[259]=C_h_intern(&lf[259],1,"l");
lf[260]=C_h_intern(&lf[260],5,"input");
lf[261]=C_h_intern(&lf[261],4,"else");
lf[262]=C_h_intern(&lf[262],4,"cond");
lf[263]=C_h_intern(&lf[263],7,"compare");
lf[264]=C_h_intern(&lf[264],1,"i");
lf[265]=C_h_intern(&lf[265],3,"and");
lf[266]=C_h_intern(&lf[266],29,"\003sysdefault-macro-environment");
lf[272]=C_h_intern(&lf[272],26,"set-module-undefined-list!");
lf[273]=C_h_intern(&lf[273],21,"module-undefined-list");
lf[275]=C_h_intern(&lf[275],15,"\003sysmodule-name");
lf[276]=C_h_intern(&lf[276],18,"\003sysmodule-exports");
lf[278]=C_h_intern(&lf[278],16,"\003sysmodule-table");
lf[279]=C_h_intern(&lf[279],5,"error");
lf[280]=C_h_intern(&lf[280],6,"import");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\020module not found");
lf[282]=C_h_intern(&lf[282],28,"\003systoplevel-definition-hook");
lf[283]=C_h_intern(&lf[283],28,"\003sysregister-meta-expression");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\047redefinition of imported syntax binding");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000&redefinition of imported value binding");
lf[287]=C_h_intern(&lf[287],19,"\003sysregister-export");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\011defined: ");
lf[289]=C_h_intern(&lf[289],15,"\003sysfind-export");
lf[290]=C_h_intern(&lf[290],26,"\003sysregister-syntax-export");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\020defined syntax: ");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000!use of syntax precedes definition");
lf[293]=C_h_intern(&lf[293],19,"\003sysregister-module");
lf[294]=C_h_intern(&lf[294],8,"\000MARKING");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\014 in module `");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000!indirect export of syntax binding");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\033indirect reexport of syntax");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\042indirect export of unknown binding");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\024  merged has length ");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\010merging ");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\033 se\047s with total length of ");
lf[305]=C_h_intern(&lf[305],32,"\003syscompiled-module-registration");
lf[306]=C_h_intern(&lf[306],28,"\003sysregister-compiled-module");
lf[307]=C_h_intern(&lf[307],4,"cons");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\022re-exported syntax");
lf[309]=C_h_intern(&lf[309],4,"eval");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\0001can not find implementation of re-exported syntax");
lf[311]=C_h_intern(&lf[311],29,"\003sysregister-primitive-module");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\0001unknown macro referenced while registering module");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\002#%");
lf[314]=C_h_intern(&lf[314],18,"module-exists-list");
lf[315]=C_h_intern(&lf[315],19,"\003sysfinalize-module");
lf[316]=C_h_intern(&lf[316],6,"\000DLIST");
lf[317]=C_h_intern(&lf[317],7,"\000SDLIST");
lf[318]=C_h_intern(&lf[318],9,"\000IEXPORTS");
lf[319]=C_h_intern(&lf[319],9,"\000VEXPORTS");
lf[320]=C_h_intern(&lf[320],9,"\000SEXPORTS");
lf[321]=C_h_intern(&lf[321],8,"\000EXPORTS");
lf[322]=C_h_intern(&lf[322],6,"\000FIXUP");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000$(internal) indirect export not found");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\021module unresolved");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\027  suggesting: `(import ");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\002)\047");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\025  suggesting one of:\012");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\026Warning:     `(import ");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\003)\047\012");
lf[331]=C_h_intern(&lf[331],7,"\004coredb");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000(reference to possibly unbound identifier");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\015reexporting: ");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000 exported identifier for module `");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\026\047 has not been defined");
lf[337]=C_h_intern(&lf[337],16,"\003sysmacro-subset");
lf[338]=C_h_intern(&lf[338],14,"make-parameter");
lf[339]=C_h_intern(&lf[339],12,"syntax-rules");
lf[340]=C_h_intern(&lf[340],3,"...");
lf[341]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[342]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[343]=C_h_intern(&lf[343],6,"export");
lf[344]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000!`export\047 used outside module body");
lf[347]=C_h_intern(&lf[347],16,"begin-for-syntax");
lf[348]=C_h_intern(&lf[348],24,"\004coreelaborationtimeonly");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[350]=C_h_intern(&lf[350],11,"\004coremodule");
lf[351]=C_h_intern(&lf[351],1,"*");
lf[352]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[353]=C_h_intern(&lf[353],17,"require-extension");
lf[354]=C_h_intern(&lf[354],22,"\004corerequire-extension");
lf[355]=C_h_intern(&lf[355],15,"require-library");
lf[356]=C_h_intern(&lf[356],11,"cond-expand");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[358]=C_h_intern(&lf[358],12,"\003sysfeature\077");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[360]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[361]=C_h_intern(&lf[361],3,"not");
lf[362]=C_h_intern(&lf[362],5,"delay");
lf[363]=C_h_intern(&lf[363],16,"\003sysmake-promise");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[365]=C_h_intern(&lf[365],10,"quasiquote");
lf[366]=C_h_intern(&lf[366],8,"\003syslist");
lf[367]=C_h_intern(&lf[367],17,"%unquote-splicing");
lf[368]=C_h_intern(&lf[368],1,"a");
lf[369]=C_h_intern(&lf[369],1,"b");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[371]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[372]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[373]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[374]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[375]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[376]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[377]=C_h_intern(&lf[377],16,"unquote-splicing");
lf[378]=C_h_intern(&lf[378],7,"unquote");
lf[379]=C_h_intern(&lf[379],2,"do");
lf[380]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[381]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[382]=C_h_intern(&lf[382],2,"if");
lf[383]=C_h_intern(&lf[383],6,"doloop");
lf[384]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001"
"\000\000\000\001");
lf[385]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[386]=C_h_intern(&lf[386],4,"case");
lf[387]=C_h_intern(&lf[387],8,"\003syseqv\077");
lf[388]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[389]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[390]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[391]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[392]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[393]=C_h_intern(&lf[393],2,"=>");
lf[394]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[395]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[396]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[397]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[398]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[399]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[400]=C_h_intern(&lf[400],17,"import-for-syntax");
lf[401]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\020\000hygienic-macros\376\003\000\000\002\376\001\000\000\015\000syntax-rules\376\377\016");
C_register_lf2(lf,402,create_ptable());
t2=C_mutate(&lf[0] /* (set! c152 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 38   append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),t3,lf[401],C_retrieve(lf[2]));}

/* k3574 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3576,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! features ...) */,t1);
t3=C_mutate(&lf[3] /* (set! d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3578,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[6] /* (set! dd ...) */,C_retrieve2(lf[3],"d"));
t5=C_mutate(&lf[7] /* (set! dm ...) */,C_retrieve2(lf[3],"d"));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3603,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 69   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[338]))(3,*((C_word*)lf[338]+1),t6,C_SCHEME_END_OF_LIST);}

/* k3601 in k3574 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3603,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1 /* (set! current-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3607,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 70   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[338]))(3,*((C_word*)lf[338]+1),t3,C_SCHEME_END_OF_LIST);}

/* k3605 in k3601 in k3574 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* (set! current-meta-environment ...) */,t1);
t3=C_mutate(&lf[10] /* (set! lookup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[13] /* (set! macro-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3627,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[20] /* (set! map-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[22]+1 /* (set! strip-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3706,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[28]+1 /* (set! strip-syntax ...) */,C_retrieve(lf[22]));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3857,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 122  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[338]))(3,*((C_word*)lf[338]+1),t8,C_SCHEME_END_OF_LIST);}

/* k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3857,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! macro-environment ...) */,t1);
t3=C_set_block_item(lf[30] /* chicken-macro-environment */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[31] /* chicken-ffi-macro-environment */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[32]+1 /* (set! extend-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3861,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[33]+1 /* (set! copy-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3894,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[34]+1 /* (set! macro? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3907,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[35]+1 /* (set! unregister-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3963,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[37]+1 /* (set! undefine-macro! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4014,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[38]+1 /* (set! expand-0 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4023,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(lf[72] /* enable-runtime-macros */,0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[73]+1 /* (set! module-rename ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4505,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[23]+1 /* (set! alias-global-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4523,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[86]+1 /* (set! expand ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4613,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[87]+1 /* (set! expand ...) */,C_retrieve(lf[86]));
t16=C_mutate((C_word*)lf[88]+1 /* (set! extended-lambda-list? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4666,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[92]+1);
t18=C_retrieve(lf[18]);
t19=C_mutate((C_word*)lf[93]+1 /* (set! expand-extended-lambda-list ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4709,a[2]=t17,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[92]+1);
t21=*((C_word*)lf[114]+1);
t22=C_mutate((C_word*)lf[115]+1 /* (set! canonicalize-body ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5299,a[2]=t21,a[3]=t20,a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate(&lf[137] /* (set! match-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6052,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[128]+1 /* (set! expand-curried-define ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6135,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(lf[138] /* line-number-database */,0,C_SCHEME_FALSE);
t26=C_set_block_item(lf[139] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
t27=C_mutate((C_word*)lf[53]+1 /* (set! syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6205,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[142]+1 /* (set! syntax-error ...) */,C_retrieve(lf[53]));
t29=C_mutate((C_word*)lf[143]+1 /* (set! get-line-number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6216,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t30=*((C_word*)lf[42]+1);
t31=C_retrieve(lf[145]);
t32=C_retrieve(lf[143]);
t33=*((C_word*)lf[146]+1);
t34=C_mutate((C_word*)lf[64]+1 /* (set! check-syntax ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6252,a[2]=t31,a[3]=t32,a[4]=t33,a[5]=t30,a[6]=((C_word)li71),tmp=(C_word)a,a+=7,tmp));
t35=C_mutate((C_word*)lf[177]+1 /* (set! er-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6714,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[187]+1 /* (set! expand-import ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7008,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7853,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13930,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13932,a[2]=((C_word)li206),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 870  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t38,t39);}

/* a13931 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13932,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
((C_proc9)C_retrieve_symbol_proc(lf[187]))(9,*((C_word*)lf[187]+1),t1,t2,t3,t4,C_retrieve(lf[8]),C_retrieve(lf[29]),C_SCHEME_FALSE,lf[280]);}

/* k13928 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 868  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[280],C_SCHEME_END_OF_LIST,t1);}

/* k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7856,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13920,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13922,a[2]=((C_word)li205),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 876  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13921 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13922,5,t0,t1,t2,t3,t4);}
/* ##sys#expand-import */
((C_proc9)C_retrieve_symbol_proc(lf[187]))(9,*((C_word*)lf[187]+1),t1,t2,t3,t4,C_retrieve(lf[9]),C_retrieve(lf[197]),C_SCHEME_TRUE,lf[400]);}

/* k13918 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 874  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[400],C_SCHEME_END_OF_LIST,t1);}

/* k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 880  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}

/* k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=C_mutate((C_word*)lf[229]+1 /* (set! initial-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13778,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13780,a[2]=((C_word)li204),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 885  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t4,t5);}

/* a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13780,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13790,a[2]=t3,a[3]=t7,a[4]=((C_word)li203),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_13790(t9,t1,t5);}

/* loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_13790(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13790,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13846,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 896  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t6,lf[117],t3,lf[395]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13859,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 900  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t6,lf[117],t3,lf[397]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13806,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 891  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[117],t3,lf[162]);}}

/* k13804 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 892  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,lf[117],((C_word*)t0)[4],lf[399]);}

/* k13807 in k13804 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13837,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 893  ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t3);}

/* k13835 in k13807 in k13804 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 893  ##sys#register-export */
((C_proc4)C_retrieve_symbol_proc(lf[287]))(4,*((C_word*)lf[287]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13810 in k13807 in k13804 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13812,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):lf[398]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k13857 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 901  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,lf[117],((C_word*)t0)[3],lf[396]);}

/* k13860 in k13857 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13908,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 902  ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t4);}

/* k13906 in k13860 in k13857 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 902  ##sys#register-export */
((C_proc4)C_retrieve_symbol_proc(lf[287]))(4,*((C_word*)lf[287]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k13863 in k13860 in k13857 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13865,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13888,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 905  r */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k13886 in k13863 in k13860 in k13857 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13888,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13898 in k13886 in k13863 in k13860 in k13857 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13900,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k13844 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 897  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,lf[117],((C_word*)t0)[2],lf[394]);}

/* k13847 in k13844 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13856,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 898  ##sys#expand-curried-define */
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13854 in k13847 in k13844 in loop in a13779 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 898  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_13790(t2,((C_word*)t0)[2],t1);}

/* k13776 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 882  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[117],C_SCHEME_END_OF_LIST,t1);}

/* k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13719,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13721,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 910  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13720 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13721,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13750,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 919  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[382]);}}}

/* k13748 in a13720 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13770,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 919  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k13768 in k13748 in a13720 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13772 in k13768 in k13748 in a13720 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13774,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k13717 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 907  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[265],C_SCHEME_END_OF_LIST,t1);}

/* k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7869,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13629,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13631,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 924  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13630 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13631,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t5);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13656,a[2]=t3,a[3]=t6,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 933  r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[101]);}}}

/* k13654 in a13630 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 934  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k13661 in k13654 in a13630 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13663,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 935  r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[382]);}

/* k13681 in k13661 in k13654 in a13630 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 935  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13701 in k13681 in k13661 in k13654 in a13630 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13707,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k13705 in k13701 in k13681 in k13661 in k13654 in a13630 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13707,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t8));}

/* k13627 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 921  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[257],C_SCHEME_END_OF_LIST,t1);}

/* k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7872,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13296,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13298,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 940  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13298,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13305,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 943  r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[116]);}

/* k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 944  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 945  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[382]);}

/* k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 946  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[393]);}

/* k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 947  r */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 948  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 949  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[126]);}

/* k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13323,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_13328,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word)li199),tmp=(C_word)a,a+=13,tmp));
t5=((C_word*)t3)[1];
f_13328(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_13328(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13328,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_13344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=((C_word*)t0)[11],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* expand.scm: 955  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[262],t3,lf[391]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[392]);}}

/* k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_13350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* expand.scm: 956  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k13348 in k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13350,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13357,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13386,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 957  expand */
t5=((C_word*)((C_word*)t0)[9])[1];
f_13328(t5,t4,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_13392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[11]);
/* expand.scm: 958  c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}}

/* k13390 in k13348 in k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13392,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13395,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 959  r */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13460,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[12]))){
t3=(C_word)C_i_length(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t3,C_fix(4));
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[12]);
/* expand.scm: 965  c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,((C_word*)t0)[2],t5);}
else{
t5=t2;
f_13460(2,t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_13460(2,t3,C_SCHEME_FALSE);}}}

/* k13458 in k13390 in k13348 in k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13460,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13463,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 966  r */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[101]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13585,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k13583 in k13458 in k13390 in k13348 in k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13585,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13581,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 975  expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_13328(t4,t3,((C_word*)t0)[2]);}

/* k13579 in k13583 in k13458 in k13390 in k13348 in k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13581,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k13461 in k13458 in k13390 in k13348 in k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13463,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t10=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t11=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[253],t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13518,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t9,a[7]=t13,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 972  expand */
t15=((C_word*)((C_word*)t0)[3])[1];
f_13328(t15,t14,((C_word*)t0)[2]);}

/* k13516 in k13461 in k13458 in k13390 in k13348 in k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13518,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[382],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[120],t10));}

/* k13393 in k13390 in k13348 in k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13395,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13434,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 963  expand */
t10=((C_word*)((C_word*)t0)[3])[1];
f_13328(t10,t9,((C_word*)t0)[2]);}

/* k13432 in k13393 in k13390 in k13348 in k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13434,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t7));}

/* k13384 in k13348 in k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13386,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k13355 in k13348 in k13342 in expand in k13321 in k13318 in k13315 in k13312 in k13309 in k13306 in k13303 in a13297 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13357,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k13294 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 937  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[262],C_SCHEME_END_OF_LIST,t1);}

/* k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13126,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13128,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 980  ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13128,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13132,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 982  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[386],t2,lf[390]);}

/* k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13132,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13141,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 985  r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[101]);}

/* k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 986  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 987  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[382]);}

/* k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 988  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[257]);}

/* k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 990  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k13151 in k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13153,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13172,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13174,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word)li197),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_13174(t9,t5,((C_word*)t0)[2]);}

/* expand in k13151 in k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_13174(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13174,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=((C_word*)t0)[8],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 997  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[386],t3,lf[388]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[389]);}}

/* k13188 in expand in k13151 in k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13196,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 998  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k13194 in k13188 in expand in k13151 in k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13196,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13203,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13246,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13250,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13252,a[2]=((C_word*)t0)[2],a[3]=((C_word)li196),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1000 ##sys#map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a13251 in k13194 in k13188 in expand in k13151 in k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13252,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[387],t6));}

/* k13248 in k13194 in k13188 in expand in k13151 in k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k13244 in k13194 in k13188 in expand in k13151 in k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13246,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k13236 in k13244 in k13194 in k13188 in expand in k13151 in k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13238,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13234,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1003 expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_13174(t4,t3,((C_word*)t0)[2]);}

/* k13232 in k13236 in k13244 in k13194 in k13188 in expand in k13151 in k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13234,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k13201 in k13194 in k13188 in expand in k13151 in k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13203,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k13170 in k13151 in k13148 in k13145 in k13142 in k13139 in k13130 in a13127 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13172,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[58],t3));}

/* k13124 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 977  ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[386],C_SCHEME_END_OF_LIST,t1);}

/* k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13057,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13059,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1008 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a13058 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13059,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13063,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1010 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[113],t2,lf[385]);}

/* k13061 in a13058 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13063,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13072,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1013 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[58]);}

/* k13070 in k13061 in a13058 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13072,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13077,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li194),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_13077(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k13070 in k13061 in a13058 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_13077(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_13077,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13095,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13114,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1017 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k13112 in expand in k13070 in k13061 in a13058 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13114,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k13093 in expand in k13070 in k13061 in a13058 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13095,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k13055 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1005 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[113],C_SCHEME_END_OF_LIST,t1);}

/* k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12875,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12877,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1022 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12877,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12881,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1024 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[379],t2,lf[384]);}

/* k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12881,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12893,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1028 r */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[383]);}

/* k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1029 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1030 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[382]);}

/* k12897 in k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1031 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12900 in k12897 in k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13037,a[2]=((C_word)li192),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1032 ##sys#map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a13036 in k12900 in k12897 in k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13037,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k12915 in k12900 in k12897 in k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12917,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_12944(t6,lf[381]);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13035,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,C_SCHEME_END_OF_LIST);}}

/* k13033 in k12915 in k12900 in k12897 in k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13035,2,t0,t1);}
t2=((C_word*)t0)[3];
f_12944(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12942 in k12915 in k12900 in k12897 in k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_12944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12944,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12960,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_12960(t4,lf[380]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13025,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k13023 in k12942 in k12915 in k12900 in k12897 in k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_13025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13025,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[3];
f_12960(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k12958 in k12942 in k12915 in k12900 in k12897 in k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_12960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12960,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12980,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12982,a[2]=((C_word)li191),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1043 ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a12981 in k12958 in k12942 in k12915 in k12900 in k12897 in k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12982,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_car(t2));}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t7));}}

/* k12978 in k12958 in k12942 in k12915 in k12900 in k12897 in k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k12974 in k12958 in k12942 in k12915 in k12900 in k12897 in k12894 in k12891 in k12879 in a12876 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12976,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[62],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t12);
t14=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t13));}

/* k12873 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1019 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[379],C_SCHEME_END_OF_LIST,t1);}

/* k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12480,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12482,a[2]=((C_word)li190),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1052 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12482,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12486,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1054 r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[95]);}

/* k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1055 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[365]);}

/* k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1056 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[378]);}

/* k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1057 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[377]);}

/* k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12495,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12497,a[2]=t5,a[3]=t7,a[4]=((C_word)li187),tmp=(C_word)a,a+=5,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12507,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word)li188),tmp=(C_word)a,a+=9,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12776,a[2]=t7,a[3]=((C_word)li189),tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12864,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1107 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t11,lf[365],((C_word*)t0)[3],lf[376]);}

/* k12862 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1108 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12497(t3,((C_word*)t0)[2],t2,C_fix(0));}

/* simplify in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_12776(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12776,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12780,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1095 match-expression */
f_6052(t3,t2,lf[374],lf[375]);}

/* k12778 in simplify in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12780,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[368],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[366],t4);
/* expand.scm: 1096 simplify */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12776(t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1097 match-expression */
f_6052(t2,((C_word*)t0)[2],lf[372],lf[373]);}}

/* k12803 in k12778 in simplify in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12805,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[369],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_i_assq(lf[368],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1104 match-expression */
f_6052(t2,((C_word*)t0)[2],lf[370],lf[371]);}}

/* k12849 in k12803 in k12778 in simplify in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[368],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k12834 in k12803 in k12778 in simplify in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12836,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[366],t2);
/* expand.scm: 1101 simplify */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12776(t4,((C_word*)t0)[2],t3);}

/* walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_12507(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12507,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12525,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12529,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1061 vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t5,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=t3,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1066 c */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t4);}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4));}}}

/* k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12554,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12580,a[2]=t5,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
/* expand.scm: 1072 walk */
t8=((C_word*)((C_word*)t0)[6])[1];
f_12497(t8,t6,t2,t7);}}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2));}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1074 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k12599 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12601,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12626,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
t6=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1077 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_12497(t7,t4,t5,t6);}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12649,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1079 walk */
t4=((C_word*)((C_word*)t0)[5])[1];
f_12497(t4,t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12748,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1083 c */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12762,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1093 walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_12497(t3,t2,((C_word*)t0)[4],((C_word*)t0)[6]);}}}

/* k12760 in k12599 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12770,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1093 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12497(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12768 in k12760 in k12599 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12770,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12746 in k12599 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12748,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12691,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1087 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12497(t6,t5,((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12722,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
/* expand.scm: 1089 walk */
t7=((C_word*)((C_word*)t0)[4])[1];
f_12497(t7,t5,t3,t6);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12737,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1091 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_12497(t4,t3,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* k12735 in k12746 in k12599 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12745,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1091 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_12497(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12743 in k12735 in k12746 in k12599 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12745,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12720 in k12746 in k12599 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12722,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[367],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[366],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12710,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1090 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12497(t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12708 in k12720 in k12746 in k12599 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12710,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[241],t3));}

/* k12689 in k12746 in k12599 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12691,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[51],t3));}

/* k12647 in k12599 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12649,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[241],((C_word*)t0)[2],t1));}

/* k12624 in k12599 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12626,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[366],t3));}

/* k12578 in k12552 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12580,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[366],((C_word*)t0)[2],t1));}

/* k12527 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1061 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12497(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12523 in walk1 in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12525,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[237],t2));}

/* walk in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_12497(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12497,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12505,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1058 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12507(t5,t4,t2,t3);}

/* k12503 in walk in k12493 in k12490 in k12487 in k12484 in a12481 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1058 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12776(t2,((C_word*)t0)[2],t1);}

/* k12478 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1049 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[365],C_SCHEME_END_OF_LIST,t1);}

/* k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12449,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1113 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12448 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12449,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12453,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1115 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[362],t2,lf[364]);}

/* k12451 in a12448 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12453,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[126],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[363],t6));}

/* k12445 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1110 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[362],C_SCHEME_END_OF_LIST,t1);}

/* k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12163,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12165,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1121 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12165,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12172,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1124 r */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1125 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[361]);}

/* k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1126 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1127 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12184,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1128 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[265]);}

/* k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12186,a[2]=((C_word*)t0)[8],a[3]=((C_word)li181),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12196,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=t4,a[7]=t1,a[8]=((C_word)li182),tmp=(C_word)a,a+=9,tmp));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12346,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=((C_word)li184),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_12346(t9,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* expand in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_12346(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12346,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12360,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12362,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12399,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1165 c */
t8=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t6,((C_word*)t0)[3]);}
else{
/* expand.scm: 1163 err */
t6=((C_word*)t0)[2];
f_12186(t6,t1,t4);}}
else{
/* expand.scm: 1158 err */
t4=((C_word*)t0)[2];
f_12186(t4,t1,t2);}}}

/* k12397 in expand in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12399,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[360]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12415,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12421,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1170 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12196(t3,t2,((C_word*)t0)[2]);}}

/* k12419 in k12397 in expand in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12421,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12428,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
/* expand.scm: 1171 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12346(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k12426 in k12419 in k12397 in expand in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12428,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k12413 in k12397 in expand in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12415,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a12361 in expand in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12362,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k12358 in expand in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[27]+1),lf[359],t1);}

/* test in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_12196(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12196,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 1134 ##sys#feature? */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12227,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 1139 c */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[7],t3);}
else{
/* expand.scm: 1135 err */
t3=((C_word*)t0)[5];
f_12186(t3,t1,t2);}}}

/* k12225 in test in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12227,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12245,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[11]);
/* expand.scm: 1142 test */
t5=((C_word*)((C_word*)t0)[8])[1];
f_12196(t5,t3,t4);}
else{
/* expand.scm: 1144 err */
t3=((C_word*)t0)[7];
f_12186(t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 1145 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k12271 in k12225 in test in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12273,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[10]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12288,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 1148 test */
t5=((C_word*)((C_word*)t0)[7])[1];
f_12196(t5,t3,t4);}
else{
/* expand.scm: 1150 err */
t3=((C_word*)t0)[6];
f_12186(t3,((C_word*)t0)[9],((C_word*)t0)[5]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12323,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1151 c */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k12321 in k12271 in k12225 in test in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12323,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12330,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* expand.scm: 1151 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_12196(t4,t2,t3);}
else{
/* expand.scm: 1152 err */
t2=((C_word*)t0)[2];
f_12186(t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k12328 in k12321 in k12271 in k12225 in test in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k12286 in k12271 in k12225 in test in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12288,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12302,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}}

/* k12300 in k12286 in k12271 in k12225 in test in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12302,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1149 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12196(t3,((C_word*)t0)[2],t2);}

/* k12243 in k12225 in test in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12245,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12254 in k12243 in k12225 in test in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12256,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1143 test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12196(t3,((C_word*)t0)[2],t2);}

/* err in k12182 in k12179 in k12176 in k12173 in k12170 in a12164 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_12186(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12186,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[356],((C_word*)t0)[2]);
/* expand.scm: 1130 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[357],t2,t3);}

/* k12161 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1118 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[356],C_SCHEME_END_OF_LIST,t1);}

/* k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12142,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12144,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1176 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12143 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12144(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12144,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[354],t7));}

/* k12140 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1173 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[355],C_SCHEME_END_OF_LIST,t1);}

/* k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7896,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12121,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12123,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1184 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12122 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12123,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[354],t7));}

/* k12119 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1181 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[353],C_SCHEME_END_OF_LIST,t1);}

/* k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7899,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12070,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12072,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1192 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12071 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12072,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12076,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1194 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[220],t2,lf[352]);}

/* k12074 in a12071 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12076,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12106,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12113,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1197 r */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[351]);}

/* k12111 in k12074 in a12071 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* expand.scm: 1197 c */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k12104 in k12074 in a12071 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12106,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_TRUE:(C_word)C_i_caddr(((C_word*)t0)[4]));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdddr(((C_word*)t0)[4]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k12097 in k12104 in k12074 in a12071 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12099,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[350],t3));}

/* k12068 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1189 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[220],C_SCHEME_END_OF_LIST,t1);}

/* k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7902,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12016,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12018,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1205 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a12017 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12018,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12022,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1207 ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[347],t2,lf[349]);}

/* k12020 in a12017 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1208 ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t2);}

/* k12023 in k12020 in a12017 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12062,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_12028(2,t3,C_SCHEME_FALSE);}}

/* k12060 in k12023 in k12020 in a12017 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12062,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[116],t1);
/* expand.scm: 1209 ##sys#register-meta-expression */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),((C_word*)t0)[2],t2);}

/* k12026 in k12023 in k12020 in a12017 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1210 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[116]);}

/* k12041 in k12026 in k12023 in k12020 in a12017 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12047,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k12045 in k12041 in k12026 in k12023 in k12020 in a12017 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12047,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[348],t3));}

/* k12014 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_12016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1202 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[347],C_SCHEME_END_OF_LIST,t1);}

/* k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11913,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11915,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1215 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a11914 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11915,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11922,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1218 ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t6);}

/* k11920 in a11914 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11925,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_11925(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 1220 syntax-error */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),t2,lf[343],lf[346]);}}

/* k11923 in k11920 in a11914 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11945,a[2]=((C_word*)t0)[3],a[3]=((C_word)li175),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11944 in k11923 in k11920 in a11914 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11945,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11952,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t3;
f_11952(t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11967,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
t5=t3;
f_11952(t5,f_11967(t2));}}

/* loop in a11944 in k11923 in k11920 in a11914 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_11967(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_TRUE);}}
else{
return(C_SCHEME_TRUE);}}}

/* k11950 in a11944 in k11923 in k11920 in a11914 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_11952(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11952,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1229 module-name */
t3=C_retrieve2(lf[76],"module-name");
f_9575(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k11957 in k11950 in a11944 in k11923 in k11920 in a11914 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1229 syntax-error */
((C_proc6)C_retrieve_symbol_proc(lf[142]))(6,*((C_word*)lf[142]+1),((C_word*)t0)[3],lf[343],lf[345],((C_word*)t0)[2],t1);}

/* k11926 in k11923 in k11920 in a11914 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11931,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11935,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=f_9593(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11943,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_retrieve(lf[22]),((C_word*)t0)[2]);}

/* k11941 in k11926 in k11923 in k11920 in a11914 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1233 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11933 in k11926 in k11923 in k11920 in a11914 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(2),t1);}

/* k11929 in k11926 in k11923 in k11920 in a11914 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[344]);}

/* k11911 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1212 ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[343],C_SCHEME_END_OF_LIST,t1);}

/* k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7908,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11876,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11878,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
/* ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t3,t4);}

/* a11877 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11878,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11882,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t5,lf[339],t2,lf[342]);}

/* k11880 in a11877 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11882,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[5]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=lf[340];
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t7,a[6]=t9,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t4)[1]))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11900,a[2]=t10,a[3]=t7,a[4]=t4,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t11,lf[339],((C_word*)t0)[5],lf[341]);}
else{
t11=t10;
f_11891(t11,C_SCHEME_UNDEFINED);}}

/* k11898 in k11880 in a11877 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_11891(t7,t6);}

/* k11889 in k11880 in a11877 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_11891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#process-syntax-rules */
((C_proc7)C_retrieve_symbol_proc(lf[230]))(7,*((C_word*)lf[230]+1),((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11874 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#extend-macro-environment */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],lf[339],C_SCHEME_END_OF_LIST,t1);}

/* k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7908,2,t0,t1);}
t2=C_mutate((C_word*)lf[230]+1 /* (set! process-syntax-rules ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7910,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9553,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1245 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t3);}

/* k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9553,2,t0,t1);}
t2=C_mutate((C_word*)lf[266]+1 /* (set! default-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9557,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11872,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1250 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}

/* k11870 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1250 make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[338]))(3,*((C_word*)lf[338]+1),((C_word*)t0)[2],t1);}

/* k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9557,2,t0,t1);}
t2=C_mutate((C_word*)lf[197]+1 /* (set! meta-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9561,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1251 make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[338]))(3,*((C_word*)lf[338]+1),t3,C_SCHEME_FALSE);}

/* k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[96],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9561,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! current-module ...) */,t1);
t3=C_mutate(&lf[76] /* (set! module-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9575,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[267] /* (set! module-export-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9593,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[268] /* (set! set-module-defined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9602,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[269] /* (set! module-defined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9611,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[270] /* (set! module-exist-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9629,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[271] /* (set! module-defined-syntax-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9647,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[272]+1 /* (set! set-module-undefined-list! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9656,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[273]+1 /* (set! module-undefined-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9665,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[223] /* (set! module-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9683,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[222] /* (set! module-meta-import-forms ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9701,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[274] /* (set! module-meta-expressions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9719,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[192] /* (set! module-vexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9737,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[193] /* (set! module-sexports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9755,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[275]+1 /* (set! module-name ...) */,C_retrieve2(lf[76],"module-name"));
t17=C_mutate((C_word*)lf[276]+1 /* (set! module-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9765,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate(&lf[277] /* (set! make-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9783,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[194]+1 /* (set! find-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9789,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[282]+1 /* (set! toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9829,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[283]+1 /* (set! register-meta-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9832,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate(&lf[284] /* (set! check-for-redef ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9852,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[287]+1 /* (set! register-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9873,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[290]+1 /* (set! register-syntax-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9962,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[77]+1 /* (set! register-undefined ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10043,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[293]+1 /* (set! register-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10065,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[215]+1 /* (set! mark-imported-symbols ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10133,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate(&lf[295] /* (set! module-indirect-exports ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10192,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate(&lf[301] /* (set! merge-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10468,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[305]+1 /* (set! compiled-module-registration ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10540,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[306]+1 /* (set! register-compiled-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10934,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[311]+1 /* (set! register-primitive-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11142,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[289]+1 /* (set! find-export ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11233,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[315]+1 /* (set! finalize-module ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11318,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(lf[278] /* module-table */,0,C_SCHEME_END_OF_LIST);
t36=C_mutate((C_word*)lf[337]+1 /* (set! macro-subset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11830,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t37=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t37+1)))(2,t37,C_SCHEME_UNDEFINED);}

/* ##sys#macro-subset in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11830(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11830,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11838,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1640 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t3);}

/* k11836 in ##sys#macro-subset in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11838,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11840,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li171),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11840(t5,((C_word*)t0)[2],t1);}

/* loop in k11836 in ##sys#macro-subset in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_11840(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11840,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,((C_word*)t0)[3]));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11861,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* expand.scm: 1643 loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* k11859 in loop in k11836 in ##sys#macro-subset in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11861,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11318,3,t0,t1,t2);}
t3=f_9593(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11325,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1544 module-name */
t5=C_retrieve2(lf[76],"module-name");
f_9575(3,t5,t4,t2);}

/* k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11325,2,t0,t1);}
t2=f_9611(((C_word*)t0)[4]);
t3=f_9629(((C_word*)t0)[4]);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11334,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11811,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
t8=f_9647(((C_word*)t0)[4]);
/* map */
t9=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}

/* a11810 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11811,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11823,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1548 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}

/* k11821 in a11810 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_assq(((C_word*)t0)[2],t1));}

/* k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_11337(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11768,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1553 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}}

/* k11766 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11768,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11770,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li168),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11770(t5,((C_word*)t0)[2],t1);}

/* loop in k11766 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_11770(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11770,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11783,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11809,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1555 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,t2);}}

/* k11807 in loop in k11766 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1555 ##sys#find-export */
((C_proc5)C_retrieve_symbol_proc(lf[289]))(5,*((C_word*)lf[289]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11781 in loop in k11766 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11783,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11794,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1556 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11770(t5,t3,t4);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1557 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11770(t3,((C_word*)t0)[3],t2);}}

/* k11792 in k11781 in loop in k11766 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11794,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11340,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[3]:((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11637,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t6,a[6]=t1,a[7]=((C_word)li167),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_11637(t8,t2,t4);}

/* loop in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_11637(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11637,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?t3:(C_word)C_i_car(t3));
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[6]))){
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1565 loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}
else{
t6=(C_word)C_i_assq(t5,((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11685,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t6,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_cdr(t6);
t10=t8;
f_11688(t10,(C_word)C_i_symbolp(t9));}
else{
t9=t8;
f_11688(t9,C_SCHEME_FALSE);}}}}

/* k11686 in loop in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_11688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11688,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_11685(2,t2,(C_word)C_i_cdr(((C_word*)t0)[5]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1572 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t2);}}

/* k11740 in k11686 in loop in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11742,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_11700(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_11700(t4,C_SCHEME_FALSE);}}

/* k11698 in k11740 in k11686 in loop in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_11700(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11700,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11703,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* expand.scm: 1574 dm */
((C_proc6)C_retrieve2_symbol_proc(lf[7],"dm"))(6,lf[7],t2,lf[333],((C_word*)t0)[5],lf[334],t3);}
else{
if(C_truep(((C_word*)t0)[4])){
/* expand.scm: 1585 ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11720,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11724,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11728,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1581 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t5,((C_word*)t0)[3]);}}}

/* k11726 in k11698 in k11740 in k11686 in loop in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1579 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[335],t1,lf[336]);}

/* k11722 in k11698 in k11740 in k11686 in loop in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1578 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11718 in k11698 in k11740 in k11686 in loop in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_11685(2,t2,C_SCHEME_FALSE);}

/* k11701 in k11698 in k11740 in k11686 in loop in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_11685(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* k11683 in loop in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11685,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11674,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1586 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11637(t5,t3,t4);}

/* k11672 in k11683 in loop in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11674,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11546,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word)li166),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11631,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1607 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[273]))(3,*((C_word*)lf[273]+1),t4,((C_word*)t0)[8]);}

/* k11629 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11546,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11557,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1591 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),t4,lf[332],t2);}}

/* k11555 in a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11560,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1592 ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t2,((C_word*)t0)[2],lf[331]);}

/* k11558 in k11555 in a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11560,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11580,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11584,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1596 cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[94]+1)))(3,*((C_word*)lf[94]+1),t6,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11591,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11595,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11597,a[2]=t7,a[3]=((C_word)li165),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_11597(t9,t5,t1);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k11558 in k11555 in a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_11597(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11597,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[328]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11611,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11623,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1605 cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[94]+1)))(3,*((C_word*)lf[94]+1),t4,t2);}}

/* k11621 in loop in k11558 in k11555 in a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1605 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),((C_word*)t0)[2],t1);}

/* k11609 in loop in k11558 in k11555 in a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11615,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1606 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_11597(t4,t2,t3);}

/* k11613 in k11609 in loop in k11558 in k11555 in a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1604 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[42]+1)))(6,*((C_word*)lf[42]+1),((C_word*)t0)[3],lf[329],((C_word*)t0)[2],lf[330],t1);}

/* k11593 in k11558 in k11555 in a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1599 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[327],t1);}

/* k11589 in k11558 in k11555 in a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1598 ##sys#warn */
((C_proc3)C_retrieve_symbol_proc(lf[204]))(3,*((C_word*)lf[204]+1),((C_word*)t0)[2],t1);}

/* k11582 in k11558 in k11555 in a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1596 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),((C_word*)t0)[2],t1);}

/* k11578 in k11558 in k11555 in a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1595 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[325],t1,lf[326]);}

/* k11574 in k11558 in k11555 in a11545 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1594 ##sys#warn */
((C_proc3)C_retrieve_symbol_proc(lf[204]))(3,*((C_word*)lf[204]+1),((C_word*)t0)[2],t1);}

/* k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11346,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
/* expand.scm: 1609 ##sys#error */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[324],((C_word*)t0)[2]);}
else{
t3=t2;
f_11346(2,t3,C_SCHEME_UNDEFINED);}}

/* k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11505,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11541,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1615 module-indirect-exports */
f_10192(t4,((C_word*)t0)[6]);}

/* k11539 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11504 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11505,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11533,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1613 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t5);}}

/* k11531 in a11504 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 1614 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],lf[323],t3);}}

/* k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11499,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1617 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t3);}

/* k11497 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11503,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1618 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t2);}

/* k11501 in k11497 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11503,2,t0,t1);}
/* expand.scm: 1616 merge-se */
f_10468(((C_word*)t0)[4],(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11355,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 1620 ##sys#mark-imported-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),t2,((C_word*)t0)[4]);}

/* k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11358,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11457,a[2]=((C_word*)t0)[2],a[3]=((C_word)li163),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a11456 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11457,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11461,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(t2);
/* expand.scm: 1623 merge-se */
f_10468(t3,(C_word)C_a_i_list(&a,2,t4,((C_word*)t0)[2]));}

/* k11459 in a11456 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11464,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11487,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11491,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1624 map-se */
f_3676(t5,t1);}

/* k11489 in k11459 in a11456 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11485 in k11459 in a11456 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11487,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[322],t2);
/* expand.scm: 1624 dm */
((C_proc3)C_retrieve2_symbol_proc(lf[7],"dm"))(3,lf[7],((C_word*)t0)[2],t3);}

/* k11462 in k11459 in a11456 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_car(t2,((C_word*)t0)[2]));}

/* k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11361,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1628 module-name */
t4=C_retrieve2(lf[76],"module-name");
f_9575(3,t4,t3,((C_word*)t0)[7]);}

/* k11377 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k11453 in k11377 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11455,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[316],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11447,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11451,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1630 map-se */
f_3676(t4,((C_word*)t0)[2]);}

/* k11449 in k11453 in k11377 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11445 in k11453 in k11377 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11447,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[317],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11443,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1631 map-se */
f_3676(t4,((C_word*)t0)[2]);}

/* k11441 in k11445 in k11453 in k11377 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11437 in k11445 in k11453 in k11377 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11439,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[318],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11435,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1632 map-se */
f_3676(t4,((C_word*)t0)[2]);}

/* k11433 in k11437 in k11445 in k11453 in k11377 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11429 in k11437 in k11445 in k11453 in k11377 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11431,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[319],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11427,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1633 map-se */
f_3676(t4,((C_word*)t0)[2]);}

/* k11425 in k11429 in k11437 in k11445 in k11453 in k11377 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k11421 in k11429 in k11437 in k11445 in k11453 in k11377 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11423,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[320],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[321],t8);
/* expand.scm: 1627 dm */
((C_proc3)C_retrieve2_symbol_proc(lf[7],"dm"))(3,lf[7],((C_word*)t0)[2],t9);}

/* k11359 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11364,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(10),t4);}

/* k11362 in k11359 in k11356 in k11353 in k11350 in k11347 in k11344 in k11341 in k11338 in k11335 in k11332 in k11323 in ##sys#finalize-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_structure(t3,lf[220]);
/* ##sys#block-set! */
t6=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t2,t3,C_fix(11),t4);}

/* ##sys#find-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11233,5,t0,t1,t2,t3,t4);}
t5=f_9593(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11244,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t5);
if(C_truep(t7)){
/* expand.scm: 1533 module-exists-list */
((C_proc3)C_retrieve_symbol_proc(lf[314]))(3,*((C_word*)lf[314]+1),t6,t3);}
else{
t8=t6;
f_11244(2,t8,t5);}}

/* k11242 in ##sys#find-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11244,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11246,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li161),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_11246(t5,((C_word*)t0)[2],t1);}

/* loop in k11242 in ##sys#find-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_11246(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11246,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1537 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t6,t2);}
else{
t6=(C_word)C_i_cdr(t2);
/* expand.scm: 1540 loop */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}}

/* k11293 in loop in k11242 in ##sys#find-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11295,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11291,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1538 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t4,((C_word*)t0)[4]);}
else{
t4=t3;
f_11274(t4,C_SCHEME_FALSE);}}}

/* k11289 in k11293 in loop in k11242 in ##sys#find-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_11274(t2,(C_word)C_i_memq(((C_word*)t0)[2],t1));}

/* k11272 in k11293 in loop in k11242 in ##sys#find-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_11274(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1539 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11246(t3,((C_word*)t0)[4],t2);}}

/* ##sys#register-primitive-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_11142r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_11142r(t0,t1,t2,t3,t4);}}

static void C_ccall f_11142r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11146,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_11146(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_11146(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k11144 in ##sys#register-primitive-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11149,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1510 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}

/* k11147 in k11144 in ##sys#register-primitive-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11164,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11188,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11187 in k11147 in k11144 in ##sys#register-primitive-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11188,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11198,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11208,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 1517 ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[188]))(4,*((C_word*)lf[188]+1),t4,lf[313],t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11206 in a11187 in k11147 in k11144 in ##sys#register-primitive-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1516 ##sys#string->symbol */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),((C_word*)t0)[2],t1);}

/* k11196 in a11187 in k11147 in k11144 in ##sys#register-primitive-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11201,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1518 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[17]))(5,*((C_word*)lf[17]+1),t2,t1,lf[83],((C_word*)t0)[2]);}

/* k11199 in k11196 in a11187 in k11147 in k11144 in ##sys#register-primitive-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11201,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k11162 in k11147 in k11144 in ##sys#register-primitive-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11168,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11170,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word)li158),tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11169 in k11162 in k11147 in k11144 in ##sys#register-primitive-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11170(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11170,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* expand.scm: 1525 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[312],t2,((C_word*)t0)[2]);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11166 in k11162 in k11147 in k11144 in ##sys#register-primitive-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11168,2,t0,t1);}
t2=f_9783(C_a_i(&a,13),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve(lf[278]));
t5=C_mutate((C_word*)lf[278]+1 /* (set! module-table ...) */,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_10934r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_10934r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_10934r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10938,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t6))){
t8=t7;
f_10938(2,t8,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_i_cdr(t6);
if(C_truep((C_word)C_i_nullp(t8))){
t9=t7;
f_10938(2,t9,(C_word)C_i_car(t6));}
else{
/* ##sys#error */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}

/* k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10964,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11096,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11095 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11096,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10961,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1465 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t5);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11117,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 1475 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t4,t5);}}

/* k11115 in a11095 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11117,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10959 in a11095 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* expand.scm: 1468 ##sys#error */
t4=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],lf[280],lf[310],((C_word*)t0)[3]);}}

/* k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11064,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11063 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11064(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11064,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cadr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11086,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_caddr(t2);
/* expand.scm: 1480 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t6,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k11084 in a11063 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11086,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10970,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11046,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11045 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11046,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11058,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 1485 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),t4,t5);}

/* k11056 in a11045 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11058,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k10968 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10970,2,t0,t1);}
t2=f_9783(C_a_i(&a,13),((C_word*)t0)[6],C_SCHEME_END_OF_LIST,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10976,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11040,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1489 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}

/* k11038 in k10968 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1490 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t2);}

/* k11042 in k11038 in k10968 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11044,2,t0,t1);}
/* expand.scm: 1488 merge-se */
f_10468(((C_word*)t0)[7],(C_word)C_a_i_list(&a,6,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k10974 in k10968 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1492 ##sys#mark-imported-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),t2,((C_word*)t0)[3]);}

/* k10977 in k10974 in k10968 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11028,a[2]=((C_word*)t0)[5],a[3]=((C_word)li153),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11027 in k10977 in k10974 in k10968 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11028,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}

/* k10980 in k10977 in k10974 in k10968 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10985,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11008,a[2]=((C_word*)t0)[4],a[3]=((C_word)li152),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a11007 in k10980 in k10977 in k10974 in k10968 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_11008(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11008,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_set_car(t4,((C_word*)t0)[2]));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k10983 in k10980 in k10977 in k10974 in k10968 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10988,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10998,a[2]=((C_word*)t0)[3],a[3]=((C_word)li151),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10997 in k10983 in k10980 in k10977 in k10974 in k10968 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10998,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[2]));}

/* k10986 in k10983 in k10980 in k10977 in k10974 in k10968 in k10965 in k10962 in k10936 in ##sys#register-compiled-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10988,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve(lf[278]));
t4=C_mutate((C_word*)lf[278]+1 /* (set! module-table ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10540,3,t0,t1,t2);}
t3=f_9611(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10547,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1425 module-name */
t5=C_retrieve2(lf[76],"module-name");
f_9575(3,t5,t4,t2);}

/* k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10547,2,t0,t1);}
t2=f_9683(((C_word*)t0)[4]);
t3=f_9755(((C_word*)t0)[4]);
t4=f_9701(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10563,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10932,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,C_SCHEME_END_OF_LIST);}
else{
t6=t5;
f_10563(t6,C_SCHEME_END_OF_LIST);}}

/* k10930 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10932,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[280],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[95],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[309],t5);
t7=((C_word*)t0)[2];
f_10563(t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_10563(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10563,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10567,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10902,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_10571(t4,C_SCHEME_END_OF_LIST);}}

/* k10900 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10902,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[280],t1);
t3=((C_word*)t0)[2];
f_10571(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_10571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10571,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10575,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10884,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=f_9719(((C_word*)t0)[5]);
/* map */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[22]),t5);}

/* k10882 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1431 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[92]+1)))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t1);}

/* k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1433 module-name */
t3=C_retrieve2(lf[76],"module-name");
f_9575(3,t3,t2,((C_word*)t0)[6]);}

/* k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10880,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10797,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10799,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10872,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1439 module-indirect-exports */
f_10192(t7,((C_word*)t0)[7]);}

/* k10870 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10798 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10799,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[95],t7));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[95],t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[95],t7);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t8,t10);
t12=(C_word)C_a_i_cons(&a,2,t6,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[164],t12));}}

/* k10795 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10793,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=f_9737(((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[95],t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10721,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10725,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li148),tmp=(C_word)a,a+=5,tmp);
/* map */
t9=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,((C_word*)t0)[4]);}

/* a10726 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10727,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(t3,((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[95],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10759,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(t4);
/* expand.scm: 1446 ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),t8,t9);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10774,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1448 dm */
((C_proc5)C_retrieve2_symbol_proc(lf[7],"dm"))(5,lf[7],t5,lf[308],t3,((C_word*)t0)[2]);}}

/* k10772 in a10726 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10774,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[95],t2));}

/* k10757 in a10726 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10759,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[307],t3));}

/* k10723 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10719 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10721,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10631,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10635,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t5=t4;
f_10635(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=f_9647(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10647,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=((C_word)li147),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_10647(t9,t4,t5);}}

/* loop in k10719 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_10647(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10647,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10717,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1456 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,t2);}}

/* k10715 in loop in k10719 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10717,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,((C_word*)t0)[5]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1456 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10647(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1458 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[4]);}}

/* k10668 in k10715 in loop in k10719 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1459 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[3]);}

/* k10711 in k10668 in k10715 in loop in k10719 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10713,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10705,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 1459 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t5,((C_word*)t0)[3]);}

/* k10703 in k10711 in k10668 in k10715 in loop in k10719 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1459 ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[2],t1);}

/* k10699 in k10711 in k10668 in k10715 in loop in k10719 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10701,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[307],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10681,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1460 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_10647(t7,t5,t6);}

/* k10679 in k10699 in k10711 in k10668 in k10715 in loop in k10719 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10681,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10633 in k10719 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10629 in k10719 in k10791 in k10878 in k10577 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10631,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[164],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[306],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t10=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,((C_word*)t0)[3],((C_word*)t0)[2],t9);}

/* k10573 in k10569 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10565 in k10561 in k10545 in ##sys#compiled-module-registration in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* merge-se in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_10468(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10468,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10472,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,*((C_word*)lf[68]+1),t2);}

/* k10470 in merge-se in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10475,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_length(t1);
/* expand.scm: 1414 dm */
((C_proc6)C_retrieve2_symbol_proc(lf[7],"dm"))(6,lf[7],t2,lf[303],t3,lf[304],t4);}

/* k10473 in k10470 in merge-se in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10478,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10487,a[2]=t4,a[3]=((C_word)li145),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10487(t6,t2,((C_word*)t0)[2]);}

/* loop in k10473 in k10470 in merge-se in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_10487(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10487,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10526,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1418 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,t2);}}

/* k10524 in loop in k10473 in k10470 in merge-se in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10526,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_assq(t1,t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1418 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10487(t4,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10518,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1419 loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10487(t6,t4,t5);}}

/* k10516 in k10524 in loop in k10473 in k10470 in merge-se in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10518,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10476 in k10473 in k10470 in merge-se in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10481,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_length(t1);
/* expand.scm: 1420 dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t2,lf[302],t3);}

/* k10479 in k10476 in k10473 in k10470 in merge-se in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_10192(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10192,NULL,2,t1,t2);}
t3=f_9593(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10199,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1371 module-name */
t5=C_retrieve2(lf[76],"module-name");
f_9575(3,t5,t4,t2);}

/* k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10199,2,t0,t1);}
t2=f_9611(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10250,a[2]=t1,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10273,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=((C_word)li143),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_10273(t8,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* loop in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_10273(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10273,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_cdr(t2);
/* expand.scm: 1387 loop */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10300,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1389 cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t4,t2);}}}

/* k10298 in loop in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10300,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li142),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_10302(t5,((C_word*)t0)[2],t1);}

/* loop2 in k10298 in loop in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_10302(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10302,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 1390 loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_10273(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 1391 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}}

/* k10460 in loop2 in k10298 in loop in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10462,2,t0,t1);}
if(C_truep((C_word)C_i_assq(((C_word*)t0)[8],t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10325,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1392 warn */
t4=((C_word*)t0)[4];
f_10250(t4,t2,lf[298],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_cdr(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10368,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_10368(2,t7,t5);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[7]);
/* expand.scm: 1399 ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t6,t7,((C_word*)t0)[2]);}}
else{
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10450,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1401 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t5);}}}

/* k10448 in k10460 in loop2 in k10298 in loop in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10450,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10398,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 1404 loop2 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10302(t9,t7,t8);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10413,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1406 warn */
t6=((C_word*)t0)[2];
f_10250(t6,t4,lf[299],t5);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10431,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 1409 warn */
t5=((C_word*)t0)[2];
f_10250(t5,t3,lf[300],t4);}}

/* k10429 in k10448 in k10460 in loop2 in k10298 in loop in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1410 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10302(t3,((C_word*)t0)[2],t2);}

/* k10411 in k10448 in k10460 in loop2 in k10298 in loop in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1407 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10302(t3,((C_word*)t0)[2],t2);}

/* k10396 in k10448 in k10460 in loop2 in k10298 in loop in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10398,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10366 in k10460 in loop2 in k10298 in loop in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10368,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10353,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1400 loop2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10302(t5,t3,t4);}

/* k10351 in k10366 in k10460 in loop2 in k10298 in loop in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10353,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10323 in k10460 in loop2 in k10298 in loop in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 1393 loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10302(t3,((C_word*)t0)[2],t2);}

/* warn in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_10250(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10250,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10258,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10262,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1381 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t5,((C_word*)t0)[2]);}

/* k10260 in warn in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1381 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[42]+1)))(6,*((C_word*)lf[42]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[296],t1,lf[297]);}

/* k10256 in warn in k10197 in module-indirect-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1380 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#mark-imported-symbols in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10133,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10139,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a10138 in ##sys#mark-imported-symbols in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10139,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10146,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_eqp(t5,t6);
t8=t3;
f_10146(t8,(C_word)C_i_not(t7));}
else{
t5=t3;
f_10146(t5,C_SCHEME_FALSE);}}

/* k10144 in a10138 in ##sys#mark-imported-symbols in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_10146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10146,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[294],t4);
/* expand.scm: 1365 dm */
((C_proc3)C_retrieve2_symbol_proc(lf[7],"dm"))(3,lf[7],t2,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k10147 in k10144 in a10138 in ##sys#mark-imported-symbols in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 1366 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[17]))(5,*((C_word*)lf[17]+1),((C_word*)t0)[2],t2,lf[85],C_SCHEME_TRUE);}

/* ##sys#register-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+31)){
C_save_and_reclaim((void*)tr4r,(void*)f_10065r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10065r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10065r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(31);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10067,a[2]=t3,a[3]=t2,a[4]=((C_word)li136),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10080,a[2]=t5,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10085,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-vexports29712990 */
t8=t1;
((C_proc2)C_retrieve_proc(t8))(2,t8,f_10085(C_a_i(&a,19),t7));}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-sexports29722986 */
t10=t1;
((C_proc2)C_retrieve_proc(t10))(2,t10,f_10080(C_a_i(&a,19),t6,t8));}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body29692978 */
t12=t1;
((C_proc2)C_retrieve_proc(t12))(2,t12,f_10067(C_a_i(&a,19),t5,t8,t10));}
else{
/* ##sys#error */
t12=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-vexports2971 in ##sys#register-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_10085(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_stack_check;
return(f_10080(C_a_i(&a,19),((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}

/* def-sexports2972 in ##sys#register-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_10080(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return(f_10067(C_a_i(&a,19),((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST));}

/* body2969 in ##sys#register-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_10067(C_word *a,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t3=f_9783(C_a_i(&a,13),((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve(lf[278]));
t6=C_mutate((C_word*)lf[278]+1 /* (set! module-table ...) */,t5);
return(t3);}

/* ##sys#register-undefined in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10043,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10050,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1352 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[273]))(3,*((C_word*)lf[273]+1),t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k10048 in ##sys#register-undefined in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10050,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 1354 set-module-undefined-list! */
((C_proc4)C_retrieve_symbol_proc(lf[272]))(4,*((C_word*)lf[272]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* ##sys#register-syntax-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9962,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=f_9593(t3);
t6=(C_word)C_eqp(C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9972,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9972(2,t8,t6);}
else{
/* expand.scm: 1334 ##sys#find-export */
((C_proc5)C_retrieve_symbol_proc(lf[289]))(5,*((C_word*)lf[289]+1),t7,t2,t3,C_SCHEME_TRUE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k9970 in ##sys#register-syntax-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9975,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1335 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[273]))(3,*((C_word*)lf[273]+1),t2,((C_word*)t0)[3]);}

/* k9973 in k9970 in ##sys#register-syntax-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9978,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 1336 module-name */
t3=C_retrieve2(lf[76],"module-name");
f_9575(3,t3,t2,((C_word*)t0)[4]);}

/* k9976 in k9973 in k9970 in ##sys#register-syntax-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],((C_word*)t0)[2]))){
/* expand.scm: 1338 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),t2,lf[292],((C_word*)t0)[7]);}
else{
t3=t2;
f_9981(2,t3,C_SCHEME_UNDEFINED);}}

/* k9979 in k9976 in k9973 in k9970 in ##sys#register-syntax-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10024,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1339 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t3);}

/* k10022 in k9979 in k9976 in k9973 in k9970 in ##sys#register-syntax-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10028,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1339 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}

/* k10026 in k10022 in k9979 in k9976 in k9973 in k9970 in ##sys#register-syntax-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_10028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1339 check-for-redef */
f_9852(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9982 in k9979 in k9976 in k9973 in k9970 in ##sys#register-syntax-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 1340 dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t2,lf[291],((C_word*)t0)[6]);}

/* k9985 in k9982 in k9979 in k9976 in k9973 in k9970 in ##sys#register-syntax-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=f_9611(((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
/* expand.scm: 1342 set-module-defined-list! */
f_9602(t2,((C_word*)t0)[4],t5);}
else{
t3=t2;
f_9990(2,t3,C_SCHEME_UNDEFINED);}}

/* k9988 in k9985 in k9982 in k9979 in k9976 in k9973 in k9970 in ##sys#register-syntax-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9990,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=f_9647(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[3];
t7=(C_word)C_i_check_structure(t6,lf[220]);
/* ##sys#block-set! */
t8=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,t6,C_fix(5),t4);}

/* ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9873,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=f_9593(t3);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9883,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_9883(2,t7,t5);}
else{
/* expand.scm: 1315 ##sys#find-export */
((C_proc5)C_retrieve_symbol_proc(lf[289]))(5,*((C_word*)lf[289]+1),t6,t2,t3,C_SCHEME_TRUE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 1316 module-undefined-list */
((C_proc3)C_retrieve_symbol_proc(lf[273]))(3,*((C_word*)lf[273]+1),t2,((C_word*)t0)[3]);}

/* k9884 in k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9889,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9949,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9953,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1318 module-name */
t5=C_retrieve2(lf[76],"module-name");
f_9575(3,t5,t4,((C_word*)t0)[3]);}

/* k9951 in k9884 in k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1318 ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9947 in k9884 in k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1317 ##sys#toplevel-definition-hook */
((C_proc6)C_retrieve_symbol_proc(lf[282]))(6,*((C_word*)lf[282]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9887 in k9884 in k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9945,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1321 ##sys#delq */
((C_proc4)C_retrieve_symbol_proc(lf[207]))(4,*((C_word*)lf[207]+1),t3,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_9892(2,t3,C_SCHEME_UNDEFINED);}}

/* k9943 in k9887 in k9884 in k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1321 set-module-undefined-list! */
((C_proc4)C_retrieve_symbol_proc(lf[272]))(4,*((C_word*)lf[272]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9890 in k9887 in k9884 in k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9931,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1322 ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t3);}

/* k9929 in k9890 in k9887 in k9884 in k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9935,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1322 ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}

/* k9933 in k9929 in k9890 in k9887 in k9884 in k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 1322 check-for-redef */
f_9852(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9893 in k9890 in k9887 in k9884 in k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=f_9629(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(4),t4);}

/* k9896 in k9893 in k9890 in k9887 in k9884 in k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9898,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 1325 dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t2,lf[288],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9902 in k9896 in k9893 in k9890 in k9887 in k9884 in k9881 in ##sys#register-export in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9904,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_FALSE);
t3=f_9611(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* expand.scm: 1326 set-module-defined-list! */
f_9602(((C_word*)t0)[2],((C_word*)t0)[3],t4);}

/* check-for-redef in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_9852(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9852,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(t2,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9859,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
/* expand.scm: 1308 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),t6,lf[286],t2);}
else{
t7=t6;
f_9859(2,t7,C_SCHEME_FALSE);}}

/* k9857 in check-for-redef in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
/* expand.scm: 1310 ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),((C_word*)t0)[2],lf[285],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#register-meta-expression in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9832,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9836,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 1303 ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t3);}

/* k9834 in ##sys#register-meta-expression in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9836,2,t0,t1);}
if(C_truep(t1)){
t2=f_9719(t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_i_check_structure(t5,lf[220]);
/* ##sys#block-set! */
t7=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,C_fix(9),t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#toplevel-definition-hook in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9829,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}

/* ##sys#find-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9789(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_9789r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9789r(t0,t1,t2,t3);}}

static void C_ccall f_9789r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9793,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_9793(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_9793(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k9791 in ##sys#find-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[3],C_retrieve(lf[278]));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(t2));}
else{
if(C_truep(t1)){
/* expand.scm: 1295 error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[279]+1)))(5,*((C_word*)lf[279]+1),((C_word*)t0)[2],lf[280],lf[281],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* make-module in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_9783(C_word *a,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_stack_check;
return((C_word)C_a_i_record(&a,12,lf[220],t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,t4));}

/* ##sys#module-exports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9765,3,t0,t1,t2);}
t3=f_9593(t2);
t4=f_9737(t2);
t5=f_9755(t2);
/* expand.scm: 1285 values */
C_values(5,0,t1,t3,t4,t5);}

/* module-sexports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_9755(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(11)));}

/* module-vexports in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_9737(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(10)));}

/* module-meta-expressions in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_9719(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(9)));}

/* module-meta-import-forms in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_9701(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(8)));}

/* module-import-forms in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_9683(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(7)));}

/* module-undefined-list in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9665,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[220]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(6)));}

/* set-module-undefined-list! in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9656,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(6),t3);}

/* module-defined-syntax-list in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_9647(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(5)));}

/* module-exist-list in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_9629(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(4)));}

/* module-defined-list in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_9611(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(3)));}

/* set-module-defined-list! in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_9602(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9602,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t5=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* module-export-list in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_9593(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_check_structure(t1,lf[220]);
return((C_word)C_i_block_ref(t1,C_fix(2)));}

/* module-name in k9559 in k9555 in k9551 in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9575,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[220]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t2,C_fix(1)));}

/* ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word ab[158],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7910,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_SCHEME_UNDEFINED;
t42=(*a=C_VECTOR_TYPE|1,a[1]=t41,tmp=(C_word)a,a+=2,tmp);
t43=C_SCHEME_UNDEFINED;
t44=(*a=C_VECTOR_TYPE|1,a[1]=t43,tmp=(C_word)a,a+=2,tmp);
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_SCHEME_UNDEFINED;
t56=(*a=C_VECTOR_TYPE|1,a[1]=t55,tmp=(C_word)a,a+=2,tmp);
t57=C_SCHEME_UNDEFINED;
t58=(*a=C_VECTOR_TYPE|1,a[1]=t57,tmp=(C_word)a,a+=2,tmp);
t59=C_SCHEME_UNDEFINED;
t60=(*a=C_VECTOR_TYPE|1,a[1]=t59,tmp=(C_word)a,a+=2,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_SCHEME_UNDEFINED;
t64=(*a=C_VECTOR_TYPE|1,a[1]=t63,tmp=(C_word)a,a+=2,tmp);
t65=C_SCHEME_UNDEFINED;
t66=(*a=C_VECTOR_TYPE|1,a[1]=t65,tmp=(C_word)a,a+=2,tmp);
t67=C_SCHEME_UNDEFINED;
t68=(*a=C_VECTOR_TYPE|1,a[1]=t67,tmp=(C_word)a,a+=2,tmp);
t69=C_SCHEME_UNDEFINED;
t70=(*a=C_VECTOR_TYPE|1,a[1]=t69,tmp=(C_word)a,a+=2,tmp);
t71=C_SCHEME_UNDEFINED;
t72=(*a=C_VECTOR_TYPE|1,a[1]=t71,tmp=(C_word)a,a+=2,tmp);
t73=C_SCHEME_UNDEFINED;
t74=(*a=C_VECTOR_TYPE|1,a[1]=t73,tmp=(C_word)a,a+=2,tmp);
t75=C_SCHEME_UNDEFINED;
t76=(*a=C_VECTOR_TYPE|1,a[1]=t75,tmp=(C_word)a,a+=2,tmp);
t77=C_SCHEME_UNDEFINED;
t78=(*a=C_VECTOR_TYPE|1,a[1]=t77,tmp=(C_word)a,a+=2,tmp);
t79=C_SCHEME_UNDEFINED;
t80=(*a=C_VECTOR_TYPE|1,a[1]=t79,tmp=(C_word)a,a+=2,tmp);
t81=C_SCHEME_UNDEFINED;
t82=(*a=C_VECTOR_TYPE|1,a[1]=t81,tmp=(C_word)a,a+=2,tmp);
t83=C_SCHEME_UNDEFINED;
t84=(*a=C_VECTOR_TYPE|1,a[1]=t83,tmp=(C_word)a,a+=2,tmp);
t85=C_SCHEME_UNDEFINED;
t86=(*a=C_VECTOR_TYPE|1,a[1]=t85,tmp=(C_word)a,a+=2,tmp);
t87=C_SCHEME_UNDEFINED;
t88=(*a=C_VECTOR_TYPE|1,a[1]=t87,tmp=(C_word)a,a+=2,tmp);
t89=C_SCHEME_UNDEFINED;
t90=(*a=C_VECTOR_TYPE|1,a[1]=t89,tmp=(C_word)a,a+=2,tmp);
t91=C_SCHEME_UNDEFINED;
t92=(*a=C_VECTOR_TYPE|1,a[1]=t91,tmp=(C_word)a,a+=2,tmp);
t93=C_SCHEME_UNDEFINED;
t94=(*a=C_VECTOR_TYPE|1,a[1]=t93,tmp=(C_word)a,a+=2,tmp);
t95=C_SCHEME_UNDEFINED;
t96=(*a=C_VECTOR_TYPE|1,a[1]=t95,tmp=(C_word)a,a+=2,tmp);
t97=C_SCHEME_UNDEFINED;
t98=(*a=C_VECTOR_TYPE|1,a[1]=t97,tmp=(C_word)a,a+=2,tmp);
t99=C_SCHEME_UNDEFINED;
t100=(*a=C_VECTOR_TYPE|1,a[1]=t99,tmp=(C_word)a,a+=2,tmp);
t101=C_SCHEME_UNDEFINED;
t102=(*a=C_VECTOR_TYPE|1,a[1]=t101,tmp=(C_word)a,a+=2,tmp);
t103=C_SCHEME_UNDEFINED;
t104=(*a=C_VECTOR_TYPE|1,a[1]=t103,tmp=(C_word)a,a+=2,tmp);
t105=C_SCHEME_UNDEFINED;
t106=(*a=C_VECTOR_TYPE|1,a[1]=t105,tmp=(C_word)a,a+=2,tmp);
t107=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7917,a[2]=t2,a[3]=t5,a[4]=t3,a[5]=t1,a[6]=t102,a[7]=t104,a[8]=t98,a[9]=t106,a[10]=t100,a[11]=t90,a[12]=t88,a[13]=t4,a[14]=t86,a[15]=t92,a[16]=t96,a[17]=t94,a[18]=t84,a[19]=t82,a[20]=t6,a[21]=t80,a[22]=t78,a[23]=t76,a[24]=t74,a[25]=t72,a[26]=t70,a[27]=t68,a[28]=t66,a[29]=t64,a[30]=t62,a[31]=t60,a[32]=t58,a[33]=t56,a[34]=t54,a[35]=t52,a[36]=t50,a[37]=t48,a[38]=t46,a[39]=t44,a[40]=t42,a[41]=t40,a[42]=t38,a[43]=t36,a[44]=t34,a[45]=t32,a[46]=t30,a[47]=t28,a[48]=t26,a[49]=t24,a[50]=t22,a[51]=t20,a[52]=t18,a[53]=t16,a[54]=t14,a[55]=t12,a[56]=t10,a[57]=t8,tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t108=t5;
((C_proc3)C_retrieve_proc(t108))(3,t108,t107,lf[265]);}

/* k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7917,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[231]);
t4=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[232]);
t5=C_mutate(((C_word *)((C_word*)t0)[54])+1,lf[233]);
t6=C_mutate(((C_word *)((C_word*)t0)[53])+1,lf[234]);
t7=C_mutate(((C_word *)((C_word*)t0)[52])+1,lf[235]);
t8=C_mutate(((C_word *)((C_word*)t0)[51])+1,lf[236]);
t9=C_mutate(((C_word *)((C_word*)t0)[50])+1,lf[237]);
t10=C_mutate(((C_word *)((C_word*)t0)[49])+1,lf[238]);
t11=C_mutate(((C_word *)((C_word*)t0)[48])+1,lf[239]);
t12=C_mutate(((C_word *)((C_word*)t0)[47])+1,lf[240]);
t13=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[50],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[51],a[12]=((C_word*)t0)[48],a[13]=((C_word*)t0)[53],a[14]=((C_word*)t0)[52],a[15]=((C_word*)t0)[47],a[16]=((C_word*)t0)[49],a[17]=((C_word*)t0)[54],a[18]=((C_word*)t0)[10],a[19]=((C_word*)t0)[11],a[20]=((C_word*)t0)[56],a[21]=((C_word*)t0)[12],a[22]=((C_word*)t0)[13],a[23]=((C_word*)t0)[14],a[24]=((C_word*)t0)[15],a[25]=((C_word*)t0)[16],a[26]=((C_word*)t0)[17],a[27]=((C_word*)t0)[57],a[28]=((C_word*)t0)[18],a[29]=((C_word*)t0)[55],a[30]=((C_word*)t0)[19],a[31]=((C_word*)t0)[20],a[32]=((C_word*)t0)[21],a[33]=((C_word*)t0)[22],a[34]=((C_word*)t0)[23],a[35]=((C_word*)t0)[24],a[36]=((C_word*)t0)[25],a[37]=((C_word*)t0)[26],a[38]=((C_word*)t0)[27],a[39]=((C_word*)t0)[28],a[40]=((C_word*)t0)[29],a[41]=((C_word*)t0)[30],a[42]=((C_word*)t0)[31],a[43]=((C_word*)t0)[32],a[44]=((C_word*)t0)[33],a[45]=((C_word*)t0)[34],a[46]=((C_word*)t0)[35],a[47]=((C_word*)t0)[36],a[48]=((C_word*)t0)[37],a[49]=((C_word*)t0)[38],a[50]=((C_word*)t0)[39],a[51]=((C_word*)t0)[40],a[52]=((C_word*)t0)[41],a[53]=((C_word*)t0)[42],a[54]=((C_word*)t0)[43],a[55]=((C_word*)t0)[44],a[56]=((C_word*)t0)[45],a[57]=((C_word*)t0)[46],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t14=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,lf[264]);}

/* k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7931,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[57],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[263]);}

/* k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7935,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[57],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[262]);}

/* k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7939,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[241]);
t4=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[56],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[57],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],a[57]=((C_word*)t0)[55],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[261]);}

/* k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7944,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[242]);
t4=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[243]);
t5=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[55],a[22]=((C_word*)t0)[56],a[23]=((C_word*)t0)[21],a[24]=((C_word*)t0)[22],a[25]=((C_word*)t0)[23],a[26]=((C_word*)t0)[24],a[27]=((C_word*)t0)[25],a[28]=((C_word*)t0)[26],a[29]=((C_word*)t0)[27],a[30]=((C_word*)t0)[28],a[31]=((C_word*)t0)[29],a[32]=((C_word*)t0)[30],a[33]=((C_word*)t0)[57],a[34]=((C_word*)t0)[31],a[35]=((C_word*)t0)[32],a[36]=((C_word*)t0)[33],a[37]=((C_word*)t0)[34],a[38]=((C_word*)t0)[35],a[39]=((C_word*)t0)[36],a[40]=((C_word*)t0)[37],a[41]=((C_word*)t0)[38],a[42]=((C_word*)t0)[39],a[43]=((C_word*)t0)[40],a[44]=((C_word*)t0)[41],a[45]=((C_word*)t0)[42],a[46]=((C_word*)t0)[43],a[47]=((C_word*)t0)[44],a[48]=((C_word*)t0)[45],a[49]=((C_word*)t0)[46],a[50]=((C_word*)t0)[47],a[51]=((C_word*)t0)[48],a[52]=((C_word*)t0)[49],a[53]=((C_word*)t0)[50],a[54]=((C_word*)t0)[51],a[55]=((C_word*)t0)[52],a[56]=((C_word*)t0)[53],a[57]=((C_word*)t0)[54],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[260]);}

/* k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7950,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[57],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[259]);}

/* k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7954,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[57],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[126]);}

/* k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7958,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[57],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[58]);}

/* k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7962,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[57],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[113]);}

/* k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7966,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[244]);
t4=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[56],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[57],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],a[57]=((C_word*)t0)[55],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[164]);}

/* k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],a[55]=((C_word*)t0)[55],a[56]=((C_word*)t0)[56],a[57]=((C_word*)t0)[57],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[258]);}

/* k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7975,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[21]);
t4=C_mutate(((C_word *)((C_word*)t0)[55])+1,lf[245]);
t5=C_mutate(((C_word *)((C_word*)t0)[54])+1,lf[246]);
t6=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[55],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[56],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[57],a[23]=((C_word*)t0)[54],a[24]=((C_word*)t0)[20],a[25]=((C_word*)t0)[21],a[26]=((C_word*)t0)[22],a[27]=((C_word*)t0)[23],a[28]=((C_word*)t0)[24],a[29]=((C_word*)t0)[25],a[30]=((C_word*)t0)[26],a[31]=((C_word*)t0)[27],a[32]=((C_word*)t0)[28],a[33]=((C_word*)t0)[29],a[34]=((C_word*)t0)[30],a[35]=((C_word*)t0)[31],a[36]=((C_word*)t0)[32],a[37]=((C_word*)t0)[33],a[38]=((C_word*)t0)[34],a[39]=((C_word*)t0)[35],a[40]=((C_word*)t0)[36],a[41]=((C_word*)t0)[37],a[42]=((C_word*)t0)[38],a[43]=((C_word*)t0)[39],a[44]=((C_word*)t0)[40],a[45]=((C_word*)t0)[41],a[46]=((C_word*)t0)[42],a[47]=((C_word*)t0)[43],a[48]=((C_word*)t0)[44],a[49]=((C_word*)t0)[45],a[50]=((C_word*)t0)[46],a[51]=((C_word*)t0)[47],a[52]=((C_word*)t0)[48],a[53]=((C_word*)t0)[49],a[54]=((C_word*)t0)[50],a[55]=((C_word*)t0)[51],a[56]=((C_word*)t0)[52],a[57]=((C_word*)t0)[53],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[257]);}

/* k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7982,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[247]);
t4=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[57],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[56],a[33]=((C_word*)t0)[31],a[34]=((C_word*)t0)[32],a[35]=((C_word*)t0)[33],a[36]=((C_word*)t0)[34],a[37]=((C_word*)t0)[35],a[38]=((C_word*)t0)[36],a[39]=((C_word*)t0)[37],a[40]=((C_word*)t0)[38],a[41]=((C_word*)t0)[39],a[42]=((C_word*)t0)[40],a[43]=((C_word*)t0)[41],a[44]=((C_word*)t0)[42],a[45]=((C_word*)t0)[43],a[46]=((C_word*)t0)[44],a[47]=((C_word*)t0)[45],a[48]=((C_word*)t0)[46],a[49]=((C_word*)t0)[47],a[50]=((C_word*)t0)[48],a[51]=((C_word*)t0)[49],a[52]=((C_word*)t0)[50],a[53]=((C_word*)t0)[51],a[54]=((C_word*)t0)[52],a[55]=((C_word*)t0)[53],a[56]=((C_word*)t0)[54],a[57]=((C_word*)t0)[55],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[95]);}

/* k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7987,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[57],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],a[35]=((C_word*)t0)[34],a[36]=((C_word*)t0)[35],a[37]=((C_word*)t0)[36],a[38]=((C_word*)t0)[37],a[39]=((C_word*)t0)[38],a[40]=((C_word*)t0)[39],a[41]=((C_word*)t0)[40],a[42]=((C_word*)t0)[41],a[43]=((C_word*)t0)[42],a[44]=((C_word*)t0)[43],a[45]=((C_word*)t0)[44],a[46]=((C_word*)t0)[45],a[47]=((C_word*)t0)[46],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[227]);}

/* k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7991,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[57],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[256]);}

/* k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7995,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=(*a=C_CLOSURE_TYPE|57,a[1]=(C_word)f_7999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[57],a[48]=((C_word*)t0)[47],a[49]=((C_word*)t0)[48],a[50]=((C_word*)t0)[49],a[51]=((C_word*)t0)[50],a[52]=((C_word*)t0)[51],a[53]=((C_word*)t0)[52],a[54]=((C_word*)t0)[53],a[55]=((C_word*)t0)[54],a[56]=((C_word*)t0)[55],a[57]=((C_word*)t0)[56],tmp=(C_word)a,a+=58,tmp);
/* r2242 */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[255]);}

/* k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7999,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[57])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[56])+1,lf[53]);
t4=(*a=C_CLOSURE_TYPE|55,a[1]=(C_word)f_8004,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=((C_word*)t0)[22],a[21]=((C_word*)t0)[23],a[22]=((C_word*)t0)[24],a[23]=((C_word*)t0)[25],a[24]=((C_word*)t0)[26],a[25]=((C_word*)t0)[27],a[26]=((C_word*)t0)[28],a[27]=((C_word*)t0)[29],a[28]=((C_word*)t0)[30],a[29]=((C_word*)t0)[31],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[33],a[32]=((C_word*)t0)[57],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[56],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],a[53]=((C_word*)t0)[53],a[54]=((C_word*)t0)[54],a[55]=((C_word*)t0)[55],tmp=(C_word)a,a+=56,tmp);
/* r2242 */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_8004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[134],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8004,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[55])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[54])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8006,a[2]=((C_word*)t0)[55],a[3]=((C_word*)t0)[53],a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));
t4=C_mutate(((C_word *)((C_word*)t0)[52])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8012,a[2]=((C_word*)t0)[41],a[3]=((C_word*)t0)[42],a[4]=((C_word*)t0)[43],a[5]=((C_word*)t0)[44],a[6]=((C_word*)t0)[45],a[7]=((C_word*)t0)[46],a[8]=((C_word*)t0)[47],a[9]=((C_word*)t0)[48],a[10]=((C_word*)t0)[49],a[11]=((C_word*)t0)[50],a[12]=((C_word*)t0)[51],a[13]=((C_word)li94),tmp=(C_word)a,a+=14,tmp));
t5=C_mutate(((C_word *)((C_word*)t0)[41])+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8106,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[47],a[4]=((C_word*)t0)[36],a[5]=((C_word*)t0)[37],a[6]=((C_word*)t0)[38],a[7]=((C_word*)t0)[39],a[8]=((C_word*)t0)[40],a[9]=((C_word)li96),tmp=(C_word)a,a+=10,tmp));
t6=C_mutate(((C_word *)((C_word*)t0)[35])+1,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8190,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[27],a[4]=((C_word*)t0)[28],a[5]=((C_word*)t0)[29],a[6]=((C_word*)t0)[30],a[7]=((C_word*)t0)[35],a[8]=((C_word*)t0)[48],a[9]=((C_word*)t0)[45],a[10]=((C_word*)t0)[40],a[11]=((C_word*)t0)[31],a[12]=((C_word*)t0)[32],a[13]=((C_word*)t0)[33],a[14]=((C_word*)t0)[51],a[15]=((C_word*)t0)[50],a[16]=((C_word*)t0)[34],a[17]=((C_word)li97),tmp=(C_word)a,a+=18,tmp));
t7=C_mutate(((C_word *)((C_word*)t0)[33])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8411,a[2]=((C_word*)t0)[35],a[3]=((C_word*)t0)[30],a[4]=((C_word*)t0)[45],a[5]=((C_word*)t0)[21],a[6]=((C_word*)t0)[40],a[7]=((C_word*)t0)[22],a[8]=((C_word*)t0)[48],a[9]=((C_word*)t0)[31],a[10]=((C_word*)t0)[23],a[11]=((C_word*)t0)[24],a[12]=((C_word*)t0)[25],a[13]=((C_word)li98),tmp=(C_word)a,a+=14,tmp));
t8=C_mutate(((C_word *)((C_word*)t0)[29])+1,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8529,a[2]=((C_word*)t0)[54],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[35],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[22],a[9]=((C_word*)t0)[21],a[10]=((C_word*)t0)[18],a[11]=((C_word*)t0)[19],a[12]=((C_word*)t0)[45],a[13]=((C_word*)t0)[40],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[32],a[16]=((C_word)li100),tmp=(C_word)a,a+=17,tmp));
t9=C_mutate(((C_word *)((C_word*)t0)[36])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8817,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[54],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[30],a[7]=((C_word*)t0)[48],a[8]=((C_word*)t0)[36],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[44],a[11]=((C_word*)t0)[32],a[12]=((C_word*)t0)[34],a[13]=((C_word)li103),tmp=(C_word)a,a+=14,tmp));
t10=C_mutate(((C_word *)((C_word*)t0)[38])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9024,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[44],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[38],a[12]=((C_word*)t0)[50],a[13]=((C_word)li105),tmp=(C_word)a,a+=14,tmp));
t11=C_mutate(((C_word *)((C_word*)t0)[37])+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9278,a[2]=((C_word*)t0)[26],a[3]=((C_word*)t0)[37],a[4]=((C_word*)t0)[34],a[5]=((C_word)li106),tmp=(C_word)a,a+=6,tmp));
t12=C_mutate(((C_word *)((C_word*)t0)[9])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9351,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word)li107),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate(((C_word *)((C_word*)t0)[26])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9444,a[2]=((C_word*)t0)[4],a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9466,a[2]=((C_word*)t0)[54],a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate(((C_word *)((C_word*)t0)[8])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9492,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word)li110),tmp=(C_word)a,a+=5,tmp));
t16=C_mutate(((C_word *)((C_word*)t0)[11])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9512,a[2]=((C_word*)t0)[54],a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp));
/* make-transformer2284 */
t17=((C_word*)((C_word*)t0)[52])[1];
((C_proc3)C_retrieve_proc(t17))(3,t17,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_9512 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9512,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9522,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li111),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9522(t7,t1,t3);}

/* loop */
static void C_fcall f_9522(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9522,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9529,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
/* ellipsis?2283 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t4=t3;
f_9529(2,t4,C_SCHEME_FALSE);}}

/* k9527 in loop */
static void C_ccall f_9529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* loop2615 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9522(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* f_9492 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9492,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9499,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* segment-template?2294 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9497 */
static void C_ccall f_9499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9499,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9506,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* segment-depth2295 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}

/* k9504 in k9497 */
static void C_ccall f_9506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(1),t1));}

/* f_9466 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9466(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9466,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(t2);
/* ellipsis?2283 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_9444 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9444,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9451,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* segment-template?2294 */
t4=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k9449 */
static void C_ccall f_9451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),((C_word*)t0)[2],lf[254],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_9351 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9351,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9364,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t2,t5))){
t7=t6;
f_9364(t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_i_assq(t2,t4);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t7);
t9=t3;
t10=t6;
f_9364(t10,(C_word)C_fixnum_greater_or_equal_p(t8,t9));}
else{
t8=t6;
f_9364(t8,C_SCHEME_FALSE);}}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9393,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* segment-template?2294 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}

/* k9391 */
static void C_ccall f_9393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9393,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9404,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* free-meta-variables2292 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* free-meta-variables2292 */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9440 in k9391 */
static void C_ccall f_9442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2292 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9423 in k9391 */
static void C_ccall f_9425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2292 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9402 in k9391 */
static void C_ccall f_9404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* free-meta-variables2292 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9362 */
static void C_fcall f_9364(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9364,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]):((C_word*)t0)[2]));}

/* f_9278 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9278,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[4]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t4));}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9304,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* segment-pattern?2293 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k9302 */
static void C_ccall f_9304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9304,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* meta-variables2291 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9332,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* meta-variables2291 */
t5=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t2,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}}}

/* k9347 in k9302 */
static void C_ccall f_9349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2291 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9330 in k9302 */
static void C_ccall f_9332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* meta-variables2291 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_9024 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_9024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9024,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(C_word)C_i_assq(t2,t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
t7=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),t1,lf[251],t2);}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[250],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t8));}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t4,a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=t1,a[14]=t3,tmp=(C_word)a,a+=15,tmp);
/* segment-template?2294 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k9069 */
static void C_ccall f_9071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9071,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9074,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* segment-depth2295 */
t3=((C_word*)((C_word*)t0)[5])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9232,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[12]);
/* process-template2290 */
t4=((C_word*)((C_word*)t0)[11])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[14],((C_word*)t0)[10]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[12]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9269,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[14],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t3,((C_word*)t0)[12]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}}}}

/* k9267 in k9069 */
static void C_ccall f_9269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2290 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9263 in k9069 */
static void C_ccall f_9265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9265,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k9230 in k9069 */
static void C_ccall f_9232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9240,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* process-template2290 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9238 in k9230 in k9069 */
static void C_ccall f_9240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9240,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t3));}

/* k9072 in k9069 */
static void C_ccall f_9074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9074,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9080,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* free-meta-variables2292 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,t4,t2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k9078 in k9072 in k9069 */
static void C_ccall f_9080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9080,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),((C_word*)t0)[11],lf[252],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9092,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[10]);
/* process-template2290 */
t4=((C_word*)((C_word*)t0)[9])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k9090 in k9078 in k9072 in k9069 */
static void C_ccall f_9092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9095,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t4))){
if(C_truep((C_word)C_i_symbolp(t1))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_9158(t6,(C_word)C_eqp(t1,t5));}
else{
t5=t3;
f_9158(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_9158(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_9158(t4,C_SCHEME_FALSE);}}

/* k9156 in k9090 in k9078 in k9072 in k9069 */
static void C_fcall f_9158(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9158,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_9095(t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}

/* k9171 in k9156 in k9090 in k9078 in k9072 in k9069 */
static void C_ccall f_9173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9173,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_9095(t3,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t2));}

/* k9093 in k9090 in k9078 in k9072 in k9069 */
static void C_fcall f_9095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9095,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9098,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9129,a[2]=t4,a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9129(t6,t2,((C_word*)t0)[2],t1);}

/* doloop2533 in k9093 in k9090 in k9078 in k9072 in k9069 */
static void C_fcall f_9129(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9129,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[51],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[253],t8);
t11=t1;
t12=t6;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k9096 in k9093 in k9090 in k9078 in k9072 in k9069 */
static void C_ccall f_9098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* segment-tail2296 */
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9125 in k9096 in k9093 in k9090 in k9078 in k9072 in k9069 */
static void C_ccall f_9127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9127,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9119,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9123,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* segment-tail2296 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k9121 in k9125 in k9096 in k9093 in k9090 in k9078 in k9072 in k9069 */
static void C_ccall f_9123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2290 */
t2=((C_word*)((C_word*)t0)[5])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9117 in k9125 in k9096 in k9093 in k9090 in k9078 in k9072 in k9069 */
static void C_ccall f_9119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9119,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[51],t3));}

/* f_8817 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_8817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8817,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_symbolp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[12]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8841,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* mapit2440 */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=t4,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
/* segment-pattern?2293 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}

/* k8845 */
static void C_ccall f_8847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8847,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8856,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word)li101),tmp=(C_word)a,a+=8,tmp);
/* process-pattern2289 */
t4=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[7],t2,((C_word*)((C_word*)t0)[12])[1],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[14]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8907,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[14]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
/* process-pattern2289 */
t6=((C_word*)((C_word*)t0)[8])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[13]);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[14]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8947,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(2)))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[14],t4);
/* ellipsis?2283 */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t3,t5);}
else{
t4=t3;
f_8947(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}}}

/* k8945 in k8845 */
static void C_ccall f_8947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8947,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8957,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t2,((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8970,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[3],a[9]=((C_word)li102),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_8970(t5,((C_word*)t0)[6],C_fix(0));}}

/* lp in k8945 in k8845 */
static void C_fcall f_8970(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8970,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[8]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8984,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_vector_ref(((C_word*)t0)[6],t2);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
/* process-pattern2289 */
t9=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,((C_word*)t0)[2]);}}

/* k8982 in lp in k8945 in k8845 */
static void C_ccall f_8984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8988,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2475 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8970(t4,t2,t3);}

/* k8986 in k8982 in lp in k8945 in k8845 */
static void C_ccall f_8988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8955 in k8945 in k8845 */
static void C_ccall f_8957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8957,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
/* process-pattern2289 */
t4=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k8905 in k8845 */
static void C_ccall f_8907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8911,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
/* process-pattern2289 */
t6=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t5,((C_word*)t0)[2]);}

/* k8909 in k8905 in k8845 */
static void C_ccall f_8911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8855 in k8845 */
static void C_ccall f_8856(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8856,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8864,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],t2);
if(C_truep(t4)){
t5=t3;
f_8864(t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=t3;
f_8864(t11,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t10));}}

/* k8862 in a8855 in k8845 */
static void C_fcall f_8864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* mapit2440 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8839 */
static void C_ccall f_8841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8841,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t2));}

/* f_8529 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_8529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8529,4,t0,t1,t2,t3);}
t4=(C_word)C_i_vector_length(t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t4,a[13]=t1,a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(2)))){
t6=(C_word)C_fixnum_difference(t4,C_fix(1));
t7=(C_word)C_i_vector_ref(t3,t6);
/* ellipsis?2283 */
t8=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t8))(3,t8,t5,t7);}
else{
t6=t5;
f_8536(2,t6,C_SCHEME_FALSE);}}

/* k8534 */
static void C_ccall f_8536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8536,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[18],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[16])[1],t5);
t7=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8575,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t4,a[16]=((C_word*)t0)[15],a[17]=t6,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t1)){
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_fixnum_difference(((C_word*)t0)[12],C_fix(2));
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=t7;
f_8575(t13,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t12));}
else{
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[17])[1],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=t7;
f_8575(t12,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t11));}}

/* k8573 in k8534 */
static void C_fcall f_8575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8575,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8579,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[17],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8583,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8585,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word)li99),tmp=(C_word)a,a+=17,tmp));
t7=((C_word*)t5)[1];
f_8585(t7,t3,C_fix(0));}

/* lp in k8573 in k8534 */
static void C_fcall f_8585(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8585,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[15]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t5=t2;
t6=(C_word)C_eqp(t5,t4);
t7=(C_truep(t6)?((C_word*)t0)[14]:C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[15],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],t12);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8645,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t10,a[6]=((C_word*)t0)[10],a[7]=t13,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8649,a[2]=t14,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[13])[1],C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t17);
t19=(C_word)C_fixnum_difference(((C_word*)t0)[15],C_fix(2));
t20=(C_word)C_i_vector_ref(((C_word*)t0)[4],t19);
/* process-match2286 */
t21=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t21))(4,t21,t15,t18,t20);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8716,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t10);
t12=(C_word)C_i_vector_ref(((C_word*)t0)[4],t2);
/* process-match2286 */
t13=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t13))(4,t13,t8,t11,t12);}}}

/* k8714 in lp in k8573 in k8534 */
static void C_ccall f_8716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8720,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* lp2411 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8585(t4,t2,t3);}

/* k8718 in k8714 in lp in k8573 in k8534 */
static void C_ccall f_8720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8647 in lp in k8573 in k8534 */
static void C_ccall f_8649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8649,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k8643 in lp in k8573 in k8534 */
static void C_ccall f_8645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8645,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}

/* k8581 in k8573 in k8534 */
static void C_ccall f_8583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8577 in k8573 in k8534 */
static void C_ccall f_8579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8579,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST));}

/* f_8411 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_8411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8411,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8415,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
/* process-match2286 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t6,t3);}

/* k8413 */
static void C_ccall f_8415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8415,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t8,t13);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t14);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,t6,t16);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t17);
t19=(C_word)C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,t4,t19);
t21=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t21);
t23=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,(C_word)C_a_i_cons(&a,2,t22,C_SCHEME_END_OF_LIST));}}

/* f_8190 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_8190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8190,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_symbolp(t3))){
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[16]))){
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[250],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[15])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t2,t8);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[14])[1],t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}
else{
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
/* segment-pattern?2293 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}}

/* k8238 */
static void C_ccall f_8240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8240,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-segment-match2287 */
t3=((C_word*)((C_word*)t0)[14])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[13],((C_word*)t0)[12],t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8288,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=((C_word*)t0)[9],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8292,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[11],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t9);
t11=(C_word)C_i_car(((C_word*)t0)[15]);
/* process-match2286 */
t12=((C_word*)((C_word*)t0)[6])[1];
((C_proc4)C_retrieve_proc(t12))(4,t12,t8,t10,t11);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[15]))){
/* process-vector-match2288 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[15]);}
else{
t2=(C_word)C_i_nullp(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8354(t4,t2);}
else{
t4=(C_word)C_booleanp(((C_word*)t0)[15]);
t5=t3;
f_8354(t5,(C_truep(t4)?t4:(C_word)C_charp(((C_word*)t0)[15])));}}}}}

/* k8352 in k8238 */
static void C_fcall f_8354(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8354,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}}

/* k8290 in k8238 */
static void C_ccall f_8292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8296,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8300,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* process-match2286 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t5,t6);}

/* k8298 in k8290 in k8238 */
static void C_ccall f_8300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8294 in k8290 in k8238 */
static void C_ccall f_8296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8286 in k8238 */
static void C_ccall f_8288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8288,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* f_8106 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_8106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8106,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cddr(t2);
t6=t3;
f_8113(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_8113(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8113(t4,C_SCHEME_FALSE);}}

/* k8111 */
static void C_fcall f_8113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8113,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t2,((C_word*)t0)[10]);}
else{
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),((C_word*)t0)[7],lf[249],((C_word*)t0)[10]);}}

/* k8114 in k8111 */
static void C_ccall f_8116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8116,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8165,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* process-match2286 */
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t1);}

/* k8163 in k8114 in k8111 */
static void C_ccall f_8165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8159 in k8114 in k8111 */
static void C_ccall f_8161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8161,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8142,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8156,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* process-pattern2289 */
t5=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],t4);}

/* a8155 in k8159 in k8114 in k8111 */
static void C_ccall f_8156(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8156,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8140 in k8159 in k8114 in k8111 */
static void C_ccall f_8142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8150,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8154,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* meta-variables2291 */
t4=((C_word*)((C_word*)t0)[3])[1];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_SCHEME_END_OF_LIST);}

/* k8152 in k8140 in k8159 in k8114 in k8111 */
static void C_ccall f_8154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* process-template2290 */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k8148 in k8140 in k8159 in k8114 in k8111 */
static void C_ccall f_8150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8150,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* f_8012 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_8012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[38],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8012,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[12])[1],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[11])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[10])[1],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[9])[1],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[8])[1],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8052,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t10,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8056,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* map */
t13=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)((C_word*)t0)[2])[1],t2);}

/* k8054 */
static void C_ccall f_8056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8056,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[248],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t1,t7);}

/* k8050 */
static void C_ccall f_8052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8052,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t7));}

/* f_8006 in k8002 in k7997 in k7993 in k7989 in k7985 in k7980 in k7973 in k7969 in k7964 in k7960 in k7956 in k7952 in k7948 in k7942 in k7937 in k7933 in k7929 in k7915 in ##sys#process-syntax-rules in k7906 in k7903 in k7900 in k7897 in k7894 in k7891 in k7888 in k7885 in k7882 in k7879 in k7876 in k7873 in k7870 in k7867 in k7864 in k7861 in k7858 in k7854 in k7851 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_8006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8006,3,t0,t1,t2);}
/* c2243 */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7008,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7012,a[2]=t3,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=t6,a[7]=t1,a[8]=t4,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 729  r */
t10=t3;
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[228]);}

/* k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 730  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[227]);}

/* k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 731  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[226]);}

/* k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 732  r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[225]);}

/* k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7023,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7032,a[2]=((C_word*)t0)[11],a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7075,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7162,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[11],a[11]=t4,a[12]=((C_word)li88),tmp=(C_word)a,a+=13,tmp));
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 829  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t8,((C_word*)t0)[11],((C_word*)t0)[3],lf[224]);}

/* k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 830  ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t2);}

/* k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7827,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9701(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 836  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),t3,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7842,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=f_9683(t1);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 839  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),t3,t4,t5);}}
else{
t3=t2;
f_7626(2,t3,C_SCHEME_UNDEFINED);}}

/* k7840 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(7),t1);}

/* k7825 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_check_structure(t2,lf[220]);
/* ##sys#block-set! */
t4=*((C_word*)lf[221]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t2,C_fix(8),t1);}

/* k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7629,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li91),tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7631,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7635,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 842  import-spec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7162(t4,t3,t2);}

/* k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7644,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[219],t5);
/* expand.scm: 845  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t4,t6);}

/* k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7794,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* expand.scm: 846  module-name */
t4=C_retrieve2(lf[76],"module-name");
f_9575(3,t4,t3,((C_word*)t0)[2]);}
else{
t4=t3;
f_7794(2,t4,lf[217]);}}

/* k7792 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7802,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 846  map-se */
f_3676(t2,((C_word*)t0)[2]);}

/* k7800 in k7792 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7802,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[218],t3);
/* expand.scm: 846  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],((C_word*)t0)[2],t4);}

/* k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7650,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7771,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* expand.scm: 847  module-name */
t4=C_retrieve2(lf[76],"module-name");
f_9575(3,t4,t3,((C_word*)t0)[2]);}
else{
t4=t3;
f_7771(2,t4,lf[217]);}}

/* k7769 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7779,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 847  map-se */
f_3676(t2,((C_word*)t0)[2]);}

/* k7777 in k7769 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7779,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[216],t3);
/* expand.scm: 847  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],((C_word*)t0)[2],t4);}

/* k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 848  ##sys#mark-imported-symbols */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),t2,((C_word*)t0)[2]);}

/* k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7725,a[2]=((C_word*)t0)[3],a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7724 in k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7725,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7759,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 853  import-env */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7757 in a7724 in k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(((C_word*)t0)[3],t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
/* expand.scm: 855  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),((C_word*)t0)[2],lf[214],((C_word*)t0)[4]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7654 in k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7683,a[2]=((C_word*)t0)[6],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* a7682 in k7654 in k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7683,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7723,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 859  macro-env */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7721 in a7682 in k7654 in k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* expand.scm: 861  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),((C_word*)t0)[2],lf[213],t6);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7657 in k7654 in k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7662,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7677,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7681,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 863  import-env */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7679 in k7657 in k7654 in k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 863  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7675 in k7657 in k7654 in k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 863  import-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7660 in k7657 in k7654 in k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7669,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7673,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 864  macro-env */
t4=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7671 in k7660 in k7657 in k7654 in k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 864  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7667 in k7660 in k7657 in k7654 in k7651 in k7648 in k7645 in k7642 in k7633 in a7630 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 864  macro-env */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7627 in k7624 in k7621 in k7618 in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[212]);}

/* import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_7162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7162,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 762  import-name */
t3=((C_word*)t0)[11];
f_7075(t3,t1,t2);}
else{
t3=(C_word)C_i_listp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t4)){
t6=t5;
f_7181(t6,t4);}
else{
t6=(C_word)C_i_length(t2);
t7=t5;
f_7181(t7,(C_word)C_fixnum_lessp(t6,C_fix(2)));}}}

/* k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_7181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7181,NULL,2,t0,t1);}
if(C_truep(t1)){
/* expand.scm: 764  syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[142]))(5,*((C_word*)lf[142]+1),((C_word*)t0)[12],((C_word*)t0)[11],lf[201],((C_word*)t0)[10]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* expand.scm: 767  import-spec */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7162(t5,t3,t4);}}

/* k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7190,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[10]);
/* expand.scm: 770  c */
t6=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}

/* k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7202,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7205,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 771  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[7],((C_word*)t0)[9],lf[202]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 782  c */
t4=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7282,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7285,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 783  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[6],((C_word*)t0)[8],lf[203]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7389,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* expand.scm: 793  c */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7389,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7392,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 794  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[5],((C_word*)t0)[9],lf[209]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7536,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* expand.scm: 819  c */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k7534 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7536,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 820  ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[210]);}
else{
/* expand.scm: 828  syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[142]))(5,*((C_word*)lf[142]+1),((C_word*)t0)[7],((C_word*)t0)[2],lf[211],((C_word*)t0)[4]);}}

/* k7537 in k7534 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7542,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* expand.scm: 821  tostr */
t4=((C_word*)t0)[2];
f_7032(t4,t2,t3);}

/* k7540 in k7537 in k7534 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7544,a[2]=t1,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7575,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k7573 in k7540 in k7537 in k7534 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7579,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7577 in k7573 in k7540 in k7537 in k7534 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7579,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ren in k7540 in k7537 in k7534 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7544(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7544,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7552,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7560,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7564,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* expand.scm: 825  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[190]))(3,*((C_word*)lf[190]+1),t5,t6);}

/* k7562 in ren in k7540 in k7537 in k7534 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 825  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[188]))(4,*((C_word*)lf[188]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7558 in ren in k7540 in k7537 in k7534 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 824  ##sys#string->symbol */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),((C_word*)t0)[2],t1);}

/* k7550 in ren in k7540 in k7537 in k7534 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7552,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k7390 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7392,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7401,a[2]=t4,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7401(t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in k7390 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_7401(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7401,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7417,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7422,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t9=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t6);}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7478,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t3,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 803  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t7,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7530,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=t2,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 810  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t7,t2);}}

/* k7528 in loop in k7390 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7530,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7511,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 813  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 816  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7401(t6,((C_word*)t0)[4],t3,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k7509 in k7528 in loop in k7390 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7511,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7499,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 815  ##sys#delq */
((C_proc4)C_retrieve_symbol_proc(lf[207]))(4,*((C_word*)lf[207]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7497 in k7509 in k7528 in loop in k7390 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 812  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7401(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7476 in loop in k7390 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7478,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)t0)[8]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7459,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 807  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t5,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm: 809  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7401(t6,((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2],t5,((C_word*)t0)[8]);}}

/* k7457 in k7476 in loop in k7390 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7459,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7447,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 808  ##sys#delq */
((C_proc4)C_retrieve_symbol_proc(lf[207]))(4,*((C_word*)lf[207]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7445 in k7457 in k7476 in loop in k7390 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 805  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_7401(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7421 in loop in k7390 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7422(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7422,3,t0,t1,t2);}
/* expand.scm: 800  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[204]))(4,*((C_word*)lf[204]+1),t1,lf[205],t2);}

/* k7415 in loop in k7390 in k7387 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7417,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k7283 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7288,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7286 in k7283 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7288,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7293,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7293(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k7286 in k7283 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_7293(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7293,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7305,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7305(t7,t1,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7379,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 791  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,t2);}}

/* k7377 in loop in k7286 in k7283 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7379,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 791  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7293(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 792  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7293(t5,((C_word*)t0)[3],t2,t4);}}

/* loop in loop in k7286 in k7283 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_7305(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7305,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7347,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 789  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,t2);}}

/* k7345 in loop in loop in k7286 in k7283 in k7280 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7347,2,t0,t1);}
if(C_truep((C_word)C_i_memq(t1,((C_word*)t0)[6]))){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* expand.scm: 789  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7305(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* expand.scm: 790  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7305(t5,((C_word*)t0)[3],t2,t4);}}

/* k7203 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7208,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k7206 in k7203 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7208,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7213,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7213(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k7206 in k7203 in k7200 in k7188 in k7179 in import-spec in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_7213(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7213,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_assq(t5,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* expand.scm: 777  loop */
t15=t1;
t16=t7;
t17=t8;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_assq(t7,((C_word*)t0)[2]);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t8,t4);
/* expand.scm: 780  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t10;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
/* expand.scm: 781  loop */
t15=t1;
t16=t9;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}}

/* import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_7075(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7075,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7079,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 742  resolve */
t4=((C_word*)t0)[2];
f_7023(3,t4,t3,t2);}

/* k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7082,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 743  ##sys#find-module */
((C_proc4)C_retrieve_symbol_proc(lf[194]))(4,*((C_word*)lf[194]+1),t2,t1,C_SCHEME_FALSE);}

/* k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7082,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7085,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t3)[1])){
t5=t4;
f_7085(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7156,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7160,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 746  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t7,((C_word*)t0)[3]);}}

/* k7158 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 746  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),((C_word*)t0)[2],t1,lf[200]);}

/* k7154 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 745  ##sys#find-extension */
((C_proc4)C_retrieve_symbol_proc(lf[199]))(4,*((C_word*)lf[199]+1),((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7097,2,t0,t1);}
if(C_truep(t1)){
t2=C_retrieve(lf[80]);
t3=C_retrieve(lf[8]);
t4=C_retrieve(lf[9]);
t5=C_retrieve(lf[29]);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7103,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t3,a[8]=t4,a[9]=t5,a[10]=t9,a[11]=t7,tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 750  ##sys#current-meta-environment */
((C_proc2)C_retrieve_symbol_proc(lf[9]))(2,*((C_word*)lf[9]+1),t10);}
else{
/* expand.scm: 755  syntax-error */
((C_proc5)C_retrieve_symbol_proc(lf[142]))(5,*((C_word*)lf[142]+1),((C_word*)t0)[4],((C_word*)t0)[2],lf[198],((C_word*)t0)[3]);}}

/* k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7103,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 751  ##sys#meta-macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[197]))(2,*((C_word*)lf[197]+1),t4);}

/* k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7106,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7107,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word)li79),tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7145,a[2]=((C_word*)t0)[2],a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t7=*((C_word*)lf[196]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t4,t6,t4);}

/* a7144 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7145,2,t0,t1);}
/* expand.scm: 752  ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[195]))(5,*((C_word*)lf[195]+1),t1,((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7137 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 753  ##sys#find-module */
((C_proc3)C_retrieve_symbol_proc(lf[194]))(3,*((C_word*)lf[194]+1),t2,((C_word*)t0)[2]);}

/* k7141 in k7137 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7085(2,t3,t2);}

/* swap1402 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* g140514061421 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k7109 in swap1402 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* g140514061421 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[10])[1]);}

/* k7112 in k7109 in swap1402 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7114,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g140714081422 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7116 in k7112 in k7109 in swap1402 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g140714081422 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k7119 in k7116 in k7112 in k7109 in swap1402 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7121,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g140914101423 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7123 in k7119 in k7116 in k7112 in k7109 in swap1402 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7128,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g140914101423 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k7126 in k7123 in k7119 in k7116 in k7112 in k7109 in swap1402 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7128,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g141114121424 */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k7130 in k7126 in k7123 in k7119 in k7116 in k7112 in k7109 in swap1402 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7135,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g141114121424 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k7133 in k7130 in k7126 in k7123 in k7119 in k7116 in k7112 in k7109 in swap1402 in k7104 in k7101 in k7095 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7083 in k7080 in k7077 in import-name in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7085,2,t0,t1);}
t2=f_9737(((C_word*)((C_word*)t0)[3])[1]);
t3=f_9755(((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* tostr in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_7032(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7032,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7045,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 737  keyword? */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,t2);}}

/* k7043 in tostr in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7045,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7052,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 737  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[190]))(3,*((C_word*)lf[190]+1),t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* expand.scm: 738  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[190]))(3,*((C_word*)lf[190]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
/* expand.scm: 739  number->string */
C_number_to_string(3,0,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* expand.scm: 740  syntax-error */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),((C_word*)t0)[4],((C_word*)t0)[2],lf[191]);}}}}

/* k7050 in k7043 in tostr in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 737  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[188]))(4,*((C_word*)lf[188]+1),((C_word*)t0)[2],t1,lf[189]);}

/* resolve in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7023,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7027,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 734  lookup */
f_3609(t3,t2,C_SCHEME_END_OF_LIST);}

/* k7025 in resolve in k7019 in k7016 in k7013 in k7010 in ##sys#expand-import in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##sys#er-transformer in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6714,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6716,a[2]=t2,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));}

/* f_6716 in ##sys#er-transformer in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6716,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6719,a[2]=t3,a[3]=t6,a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6982,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6845,a[2]=t4,a[3]=t8,a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 723  handler */
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t1,t2,t7,t9);}

/* compare */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6845,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6849,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_symbolp(t2);
t6=(C_truep(t5)?(C_word)C_i_symbolp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6878,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 694  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t7,t2,lf[12]);}
else{
t7=t4;
f_6849(t7,(C_word)C_eqp(t2,t3));}}

/* k6876 in compare */
static void C_ccall f_6878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6881(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6968,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 695  lookup2 */
f_6982(t3,C_fix(1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k6966 in k6876 in compare */
static void C_ccall f_6968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6881(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6879 in k6876 in compare */
static void C_fcall f_6881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6881,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 697  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t2,((C_word*)t0)[4],lf[12]);}

/* k6882 in k6879 in k6876 in compare */
static void C_ccall f_6884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6887,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6887(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6962,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 698  lookup2 */
f_6982(t3,C_fix(2),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6960 in k6882 in k6879 in k6876 in compare */
static void C_ccall f_6962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6887(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k6885 in k6882 in k6879 in k6876 in compare */
static void C_fcall f_6887(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6887,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6906,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 702  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t2,((C_word*)t0)[3],lf[83]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6933,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 704  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}}
else{
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 708  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_6849(t2,(C_word)C_eqp(((C_word*)t0)[3],t1));}}}

/* k6954 in k6885 in k6882 in k6879 in k6876 in compare */
static void C_ccall f_6956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6849(t4,(C_word)C_eqp(((C_word*)t0)[2],t3));}
else{
t3=((C_word*)t0)[3];
f_6849(t3,C_SCHEME_FALSE);}}

/* k6931 in k6885 in k6882 in k6879 in k6876 in compare */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=((C_word*)t0)[3];
f_6849(t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[3];
f_6849(t3,C_SCHEME_FALSE);}}

/* k6904 in k6885 in k6882 in k6879 in k6876 in compare */
static void C_ccall f_6906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6906,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6913,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 703  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t3,((C_word*)t0)[3],lf[83]);}

/* k6911 in k6904 in k6885 in k6882 in k6879 in k6876 in compare */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
f_6849(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k6847 in compare */
static void C_fcall f_6849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6849,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6852,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[186],t6);
/* expand.scm: 713  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t2,t7);}

/* k6850 in k6847 in compare */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup2 */
static void C_fcall f_6982(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6982,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6986,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 716  lookup */
f_3609(t5,t3,t4);}

/* k6984 in lookup2 */
static void C_ccall f_6986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6989,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t4=(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE);
t5=(C_truep(t4)?lf[14]:t1);
/* expand.scm: 717  dd */
((C_proc9)C_retrieve2_symbol_proc(lf[6],"dd"))(9,lf[6],t2,lf[182],t3,lf[183],((C_word*)t0)[2],lf[184],t5,lf[185]);}

/* k6987 in k6984 in lookup2 */
static void C_ccall f_6989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* rename */
static void C_ccall f_6719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6719,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6729,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t3);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[47],t6);
t8=(C_word)C_a_i_cons(&a,2,t2,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[178],t8);
/* expand.scm: 674  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t4,t9);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 676  lookup */
f_3609(t4,t2,((C_word*)t0)[2]);}}

/* k6753 in rename */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6755,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6767,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[179],t5);
/* expand.scm: 679  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t2,t6);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6786,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 682  macro-alias */
f_3627(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6816,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 687  macro-alias */
f_3627(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6814 in k6753 in rename */
static void C_ccall f_6816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[181],t5);
/* expand.scm: 688  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t2,t6);}

/* k6817 in k6814 in k6753 in rename */
static void C_ccall f_6819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6819,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6784 in k6753 in rename */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[180],t5);
/* expand.scm: 683  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t2,t6);}

/* k6787 in k6784 in k6753 in rename */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6789,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* k6765 in k6753 in rename */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6727 in rename */
static void C_ccall f_6729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[2]));}

/* ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr5r,(void*)f_6252r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6252r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6252r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6254,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=((C_word)li68),tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6657,a[2]=t6,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6666,a[2]=t7,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-culprit10181176 */
t9=t8;
f_6666(t9,t1);}
else{
t9=(C_word)C_i_car(t5);
t10=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-se10191172 */
t11=t7;
f_6657(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* body10161025 */
t13=t6;
f_6254(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-culprit1018 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6666,NULL,2,t0,t1);}
/* def-se10191172 */
t2=((C_word*)t0)[2];
f_6657(t2,t1,C_SCHEME_FALSE);}

/* def-se1019 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6657(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6657,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6665,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 588  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t3);}

/* k6663 in def-se1019 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body10161025 */
t2=((C_word*)t0)[4];
f_6254(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6254(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6254,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6269,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word)li59),tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6257,a[2]=t4,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6300,a[2]=((C_word*)t0)[3],a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6356,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=t3,a[6]=t6,a[7]=t7,a[8]=t5,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t9=C_mutate((C_word*)lf[139]+1 /* (set! syntax-error-culprit ...) */,t2);
t10=t8;
f_6385(t10,t9);}
else{
t9=t8;
f_6385(t9,C_SCHEME_UNDEFINED);}}

/* k6383 in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6385(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6385,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=((C_word*)t0)[9],a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6390(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k6383 in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6390(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6390,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t3))){
t4=(C_word)C_i_vector_ref(t3,C_fix(0));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(1)):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6409,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_eqp(t5,C_fix(1));
if(C_truep(t9)){
t10=t8;
f_6409(t10,C_fix(1));}
else{
t10=(C_word)C_fixnum_greaterp(t5,C_fix(2));
t11=t8;
f_6409(t11,(C_truep(t10)?(C_word)C_i_vector_ref(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_immp(t3))){
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 641  err */
t5=((C_word*)t0)[7];
f_6269(t5,t1,lf[155]);}}
else{
if(C_truep((C_word)C_i_symbolp(t3))){
t4=t3;
t5=(C_word)C_eqp(t4,lf[57]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t4,lf[156]);
if(C_truep(t6)){
/* expand.scm: 645  test */
t7=((C_word*)t0)[5];
f_6257(t7,t1,t2,*((C_word*)lf[157]+1),lf[158]);}
else{
t7=(C_word)C_eqp(t4,lf[159]);
if(C_truep(t7)){
/* expand.scm: 646  test */
t8=((C_word*)t0)[5];
f_6257(t8,t1,t2,*((C_word*)lf[160]+1),lf[161]);}
else{
t8=(C_word)C_eqp(t4,lf[162]);
if(C_truep(t8)){
/* expand.scm: 647  test */
t9=((C_word*)t0)[5];
f_6257(t9,t1,t2,*((C_word*)lf[160]+1),lf[163]);}
else{
t9=(C_word)C_eqp(t4,lf[164]);
if(C_truep(t9)){
/* expand.scm: 648  test */
t10=((C_word*)t0)[5];
f_6257(t10,t1,t2,((C_word*)t0)[4],lf[165]);}
else{
t10=(C_word)C_eqp(t4,lf[166]);
if(C_truep(t10)){
/* expand.scm: 649  test */
t11=((C_word*)t0)[5];
f_6257(t11,t1,t2,*((C_word*)lf[167]+1),lf[168]);}
else{
t11=(C_word)C_eqp(t4,lf[169]);
if(C_truep(t11)){
/* expand.scm: 650  test */
t12=((C_word*)t0)[5];
f_6257(t12,t1,t2,*((C_word*)lf[170]+1),lf[171]);}
else{
t12=(C_word)C_eqp(t4,lf[172]);
if(C_truep(t12)){
/* expand.scm: 651  test */
t13=((C_word*)t0)[5];
f_6257(t13,t1,t2,((C_word*)t0)[3],lf[173]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6587,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li66),tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 653  test */
t14=((C_word*)t0)[5];
f_6257(t14,t1,t2,t13,lf[174]);}}}}}}}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6628,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 663  walk */
t26=t4;
t27=t5;
t28=t6;
t1=t26;
t2=t27;
t3=t28;
goto loop;}
else{
/* expand.scm: 661  err */
t4=((C_word*)t0)[7];
f_6269(t4,t1,lf[175]);}}
else{
/* expand.scm: 660  err */
t4=((C_word*)t0)[7];
f_6269(t4,t1,lf[176]);}}}}}

/* k6626 in walk in k6383 in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 664  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6390(t4,((C_word*)t0)[2],t2,t3);}

/* a6586 in walk in k6383 in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6587(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6587,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6591,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* expand.scm: 656  lookup */
f_3609(t3,t2,((C_word*)t0)[2]);}
else{
t4=t3;
f_6591(2,t4,C_SCHEME_FALSE);}}

/* k6589 in a6586 in walk in k6383 in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(t3,((C_word*)t0)[2]));}

/* k6407 in walk in k6383 in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6409,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6414,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li65),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6414(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop1129 in k6407 in walk in k6383 in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6414(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6414,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* expand.scm: 634  err */
t5=((C_word*)t0)[6];
f_6269(t5,t1,lf[152]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6433,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* expand.scm: 636  err */
t6=((C_word*)t0)[6];
f_6269(t6,t5,lf[153]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
/* expand.scm: 639  walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6390(t7,t5,t6,((C_word*)t0)[2]);}
else{
/* expand.scm: 638  err */
t6=((C_word*)t0)[6];
f_6269(t6,t5,lf[154]);}}}}

/* k6431 in doloop1129 in k6407 in walk in k6383 in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6414(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6356(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6356,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6362,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_6362(t2));}

/* loop in proper-list? in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static C_word C_fcall f_6362(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6300,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6304,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 603  ##sys#extended-lambda-list? */
((C_proc3)C_retrieve_symbol_proc(lf[88]))(3,*((C_word*)lf[88]+1),t3,t2);}

/* k6302 in lambda-list? in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6304,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6312,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6312(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k6302 in lambda-list? in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6312(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6312,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6332,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 606  keyword? */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_cdr(t2);
/* expand.scm: 610  loop */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}}

/* k6330 in loop in k6302 in lambda-list? in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6257(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6257,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6264,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 591  pred */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k6262 in test in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 591  err */
t2=((C_word*)t0)[3];
f_6269(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6269(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6269,NULL,3,t0,t1,t2);}
t3=C_retrieve(lf[139]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 595  get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6271 in err in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6280,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6287,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 598  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6298,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 599  symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k6296 in k6271 in err in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 599  string-append */
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[150],t1,lf[151],((C_word*)t0)[2]);}

/* k6285 in k6271 in err in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 598  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k6289 in k6285 in k6271 in err in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 598  string-append */
t2=((C_word*)t0)[5];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],lf[147],((C_word*)t0)[3],lf[148],t1,lf[149],((C_word*)t0)[2]);}

/* k6278 in k6271 in err in body1016 in ##sys#check-syntax in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 596  ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6216,3,t0,t1,t2);}
if(C_truep(C_retrieve(lf[138]))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6238,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 577  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[144]))(4,*((C_word*)lf[144]+1),t4,C_retrieve(lf[138]),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6236 in get-line-number in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6205(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6205r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6205r(t0,t1,t2);}}

static void C_ccall f_6205r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6213,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 568  ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),t3,t2);}

/* k6211 in ##sys#syntax-error-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],C_retrieve(lf[140]),lf[141],t1);}

/* ##sys#expand-curried-define in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6135,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6138,a[2]=t8,a[3]=t6,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6198,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 557  loop */
t11=((C_word*)t8)[1];
f_6138(t11,t10,t2,t3);}

/* k6196 in ##sys#expand-curried-define in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6198,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6138(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6138,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_car(t2);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_i_cdr(t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6164,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6191,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t8=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t3,C_SCHEME_END_OF_LIST);}}

/* k6189 in loop in ##sys#expand-curried-define in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6191,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* expand.scm: 556  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6138(t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k6162 in loop in ##sys#expand-curried-define in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6164,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[97],t2));}

/* match-expression in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6052(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6052,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6055,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6133,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 544  mwalk */
t11=((C_word*)t8)[1];
f_6055(t11,t10,t2,t3);}

/* k6131 in match-expression in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in match-expression in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_6055(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6055,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6104,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_car(t3);
/* expand.scm: 541  mwalk */
t13=t4;
t14=t5;
t15=t6;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_i_assq(t3,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_equalp(t2,t5));}
else{
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[2]))){
t5=(C_word)C_a_i_cons(&a,2,t3,t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t2,t3));}}}}

/* k6102 in mwalk in match-expression in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* expand.scm: 542  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6055(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5299r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5299r(t0,t1,t2,t3);}}

static void C_ccall f_5299r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5303,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 418  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5303(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5303,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5305,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t7,a[6]=((C_word)li46),tmp=(C_word)a,a+=7,tmp));
t9=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5565,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5742,a[2]=t3,a[3]=t5,a[4]=t1,a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
/* expand.scm: 525  expand */
t11=((C_word*)t7)[1];
f_5742(t11,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5742(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5742,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li50),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5748(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5748(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5748,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_i_car(t7):C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5770,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t1,a[7]=t6,a[8]=t5,a[9]=t8,a[10]=((C_word*)t0)[4],a[11]=t4,a[12]=t3,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t10)){
if(C_truep((C_word)C_i_symbolp(t10))){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6012,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 485  lookup */
f_3609(t12,t10,((C_word*)t0)[5]);}
else{
t12=t11;
f_5770(t12,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5770(t12,C_SCHEME_FALSE);}}
else{
/* expand.scm: 479  fini */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5305(t7,t1,t3,t4,t5,t6,t2);}}

/* k6010 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5770(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5770,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(C_word)C_eqp(lf[117],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5788,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 488  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t3,lf[117],((C_word*)t0)[5],lf[133],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t3=(C_word)C_eqp(lf[124],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 510  ##sys#check-syntax */
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),t4,lf[124],((C_word*)t0)[5],lf[134],((C_word*)t0)[13]);}
else{
t4=(C_word)C_eqp(lf[118],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5926,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 513  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t5,lf[118],((C_word*)t0)[5],lf[135],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t5=(C_word)C_eqp(lf[116],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5954,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 516  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t6,lf[116],((C_word*)t0)[5],lf[136],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t6=(C_word)C_i_memq(t1,((C_word*)t0)[12]);
t7=(C_truep(t6)?t6:(C_word)C_i_memq(t1,((C_word*)t0)[8]));
if(C_truep(t7)){
/* expand.scm: 519  fini */
t8=((C_word*)((C_word*)t0)[2])[1];
f_5305(t8,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5980,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 521  ##sys#expand-0 */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),t8,((C_word*)t0)[5],((C_word*)t0)[13]);}}}}}}
else{
/* expand.scm: 486  fini */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5305(t2,((C_word*)t0)[6],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[3]);}}

/* k5978 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5980,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* expand.scm: 523  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_5305(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* expand.scm: 524  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5748(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k5952 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5961,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 517  ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k5959 in k5952 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 517  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5748(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5924 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5926,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* expand.scm: 514  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_5748(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k5912 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 511  fini/syntax */
t2=((C_word*)((C_word*)t0)[8])[1];
f_5565(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5786 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5788,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5793,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li49),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5793(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k5786 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5793(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5793,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5840,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 500  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t5,lf[117],t2,lf[129],C_SCHEME_FALSE,((C_word*)t0)[8]);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5862,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 504  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t5,lf[117],t2,lf[130],C_SCHEME_FALSE,((C_word*)t0)[8]);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 492  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t4,lf[117],t2,lf[132],C_SCHEME_FALSE,((C_word*)t0)[8]);}}

/* k5804 in loop2 in k5786 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5806,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[8]):lf[131]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* expand.scm: 493  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_5748(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5860 in loop2 in k5786 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5862,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_i_cdr(((C_word*)t0)[10]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k5887 in k5860 in loop2 in k5786 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5889,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
/* expand.scm: 505  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5748(t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5838 in loop2 in k5786 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 501  macro-alias */
f_3627(t2,lf[117],((C_word*)t0)[2]);}

/* k5849 in k5838 in loop2 in k5786 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5855,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* expand.scm: 502  ##sys#expand-curried-define */
((C_proc5)C_retrieve_symbol_proc(lf[128]))(5,*((C_word*)lf[128]+1),t2,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5853 in k5849 in k5838 in loop2 in k5786 in k5768 in loop in expand in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5855,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* expand.scm: 501  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5793(t3,((C_word*)t0)[2],t2);}

/* fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5565(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5565,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5573,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5575,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5575(t11,t7,t6,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5575(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5575,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5590,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 460  macro-alias */
f_3627(t5,lf[123],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5621,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_length(t7);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_fix(3),t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5724,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 465  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t9,t2);}
else{
t9=t5;
f_5621(t9,C_SCHEME_FALSE);}}
else{
t7=t5;
f_5621(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 462  loop */
t12=t1;
t13=t2;
t14=t3;
t15=C_SCHEME_TRUE;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}}

/* k5722 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5724,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5720,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 466  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
f_5621(t2,C_SCHEME_FALSE);}}

/* k5718 in k5722 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 466  lookup */
f_3609(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5708 in k5722 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5713,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5713(2,t3,t1);}
else{
/* expand.scm: 466  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[2]);}}

/* k5711 in k5708 in k5722 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5621(t2,(C_word)C_eqp(lf[124],t1));}

/* k5619 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5621,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5639,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5653,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 471  caadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t6,t2);}
else{
t6=t4;
f_5639(t6,t2);}}
else{
/* expand.scm: 475  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5575(t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_TRUE);}}

/* k5651 in k5619 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5665,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 471  macro-alias */
f_3627(t2,lf[126],((C_word*)t0)[2]);}

/* k5663 in k5651 in k5619 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 471  cdadr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t2,((C_word*)t0)[2]);}

/* k5671 in k5663 in k5651 in k5619 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5675 in k5671 in k5663 in k5651 in k5619 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5677,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
f_5639(t6,(C_word)C_a_i_cons(&a,2,lf[124],t5));}

/* k5637 in k5619 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5639,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* expand.scm: 468  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5575(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k5588 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5606,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 461  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5604 in k5588 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 461  map */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[122]+1),t1);}

/* k5596 in k5588 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5602,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5600 in k5596 in k5588 in loop in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5602,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k5571 in fini/syntax in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 457  fini */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5305(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5305,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5317,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li41),tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_5317(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5416,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* expand.scm: 436  reverse */
t10=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}

/* k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5438,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5545,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5557,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[51]+1),t1,((C_word*)t0)[3]);}

/* k5555 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 439  ##sys#map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5544 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5545(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5545,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[121]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5446,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5527,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 441  reverse */
t6=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5541 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 441  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5526 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5527,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k5444 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5450,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5454,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5460,a[2]=((C_word*)t0)[5],a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 451  reverse */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5519 in k5444 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5525,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 452  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5523 in k5519 in k5444 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 442  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5459 in k5444 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5460,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5464,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 443  ##sys#map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[18]),t2);}

/* k5462 in a5459 in k5444 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5464,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[97],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5491,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5495,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5497,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 448  map */
t8=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t7,((C_word*)t0)[2],t1);}

/* a5496 in k5462 in a5459 in k5444 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5497,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[71],t5));}

/* k5493 in k5462 in a5459 in k5444 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5489 in k5462 in a5459 in k5444 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5491,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[120],t5));}

/* k5452 in k5444 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5458,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5456 in k5452 in k5444 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5448 in k5444 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5440 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5442,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[59],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5422,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[119],t5);
/* expand.scm: 454  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t4,t6);}

/* k5420 in k5440 in k5436 in k5414 in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5317(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5317,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5340,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5406,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 430  lookup */
f_3609(t7,t6,((C_word*)t0)[4]);}
else{
t7=t5;
f_5340(t7,C_SCHEME_FALSE);}}
else{
t6=t5;
f_5340(t6,C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5331,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 424  macro-alias */
f_3627(t4,lf[116],((C_word*)t0)[4]);}}

/* k5329 in loop in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5331,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k5404 in loop in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5406,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[117]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_5340(t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 431  lookup */
f_3609(t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k5397 in k5404 in loop in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_5340(t3,(C_word)C_eqp(t2,lf[118]));}

/* k5338 in loop in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5340(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5340,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 433  macro-alias */
f_3627(t2,lf[116],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]);
/* expand.scm: 435  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5317(t4,((C_word*)t0)[9],t2,t3);}}

/* k5345 in k5338 in loop in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5351,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 434  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5353 in k5345 in k5338 in loop in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5363,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 434  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5742(t3,t2,((C_word*)t0)[2]);}

/* k5361 in k5353 in k5345 in k5338 in loop in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5363,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* expand.scm: 434  ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5349 in k5345 in k5338 in loop in fini in k5301 in ##sys#canonicalize-body in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5351,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4709,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4712,a[2]=t2,a[3]=t4,a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4729,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t10,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
/* expand.scm: 325  macro-alias */
f_3627(t11,lf[113],t5);}

/* k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm: 327  macro-alias */
f_3627(t2,lf[112],((C_word*)t0)[4]);}

/* k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm: 328  macro-alias */
f_3627(t2,lf[111],((C_word*)t0)[4]);}

/* k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* expand.scm: 329  macro-alias */
f_3627(t2,lf[110],((C_word*)t0)[4]);}

/* k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* expand.scm: 330  macro-alias */
f_3627(t2,lf[58],((C_word*)t0)[4]);}

/* k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4741,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4746,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word)li39),tmp=(C_word)a,a+=15,tmp));
t5=((C_word*)t3)[1];
f_4746(t5,((C_word*)t0)[3],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4746(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4746,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t5,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t4,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)((C_word*)t0)[13])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 338  reverse */
t9=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}
else{
/* expand.scm: 338  reverse */
t8=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* expand.scm: 366  err */
t7=((C_word*)t0)[4];
f_4712(t7,t1,lf[99]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5034,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[13])[1];
if(C_truep(t8)){
t9=t7;
f_5034(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[13])+1,t6);
t10=t7;
f_5034(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5057,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[3],a[11]=t2,a[12]=t6,a[13]=t7,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t7))){
/* expand.scm: 375  lookup */
f_3609(t8,t7,((C_word*)t0)[2]);}
else{
t9=t8;
f_5057(2,t9,C_SCHEME_FALSE);}}
else{
/* expand.scm: 372  err */
t7=((C_word*)t0)[4];
f_4712(t7,t1,lf[109]);}}}}

/* k5055 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5057,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[13]);
t3=(C_word)C_i_cdr(((C_word*)t0)[12]);
t4=(C_word)C_eqp(t2,lf[90]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5072,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t6)){
t7=t5;
f_5072(t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5091,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 379  macro-alias */
f_3627(t7,lf[101],((C_word*)t0)[5]);}}
else{
t5=(C_word)C_eqp(t2,lf[89]);
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[11],C_fix(1)))){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5109,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[4],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_5109(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_5109(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm: 391  err */
t6=((C_word*)t0)[7];
f_4712(t6,((C_word*)t0)[9],lf[103]);}}
else{
t6=(C_word)C_eqp(t2,lf[91]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t8)){
t9=t7;
f_5155(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5174,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 393  macro-alias */
f_3627(t9,lf[101],((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t7=((C_word*)t0)[11];
switch(t7){
case C_fix(0):
t8=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
/* expand.scm: 400  loop */
t9=((C_word*)((C_word*)t0)[10])[1];
f_4746(t9,((C_word*)t0)[9],C_fix(0),t8,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3);
case C_fix(1):
t8=(C_word)C_a_i_list(&a,2,t2,C_SCHEME_FALSE);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[3]);
/* expand.scm: 401  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4746(t10,((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8],t9,C_SCHEME_END_OF_LIST,t3);
case C_fix(2):
/* expand.scm: 402  err */
t8=((C_word*)t0)[7];
f_4712(t8,((C_word*)t0)[9],lf[105]);
default:
t8=(C_word)C_a_i_list(&a,1,t2);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)t0)[2]);
/* expand.scm: 403  loop */
t10=((C_word*)((C_word*)t0)[10])[1];
f_4746(t10,((C_word*)t0)[9],C_fix(3),((C_word*)t0)[8],((C_word*)t0)[3],t9,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5236,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t8=(C_word)C_i_length(t2);
t9=t7;
f_5236(t9,(C_word)C_eqp(C_fix(2),t8));}
else{
t8=t7;
f_5236(t8,C_SCHEME_FALSE);}}}}}}

/* k5234 in k5055 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5236(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5236,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* expand.scm: 406  err */
t3=((C_word*)t0)[9];
f_4712(t3,((C_word*)t0)[8],lf[106]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* expand.scm: 407  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4746(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* expand.scm: 408  err */
t3=((C_word*)t0)[9];
f_4712(t3,((C_word*)t0)[8],lf[107]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* expand.scm: 409  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4746(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* expand.scm: 410  err */
t2=((C_word*)t0)[9];
f_4712(t2,((C_word*)t0)[8],lf[108]);}}

/* k5172 in k5055 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5155(t3,t2);}

/* k5153 in k5055 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* expand.scm: 395  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_4746(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 396  err */
t2=((C_word*)t0)[2];
f_4712(t2,((C_word*)t0)[6],lf[104]);}}

/* k5107 in k5055 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5109,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5112,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_5112(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_5112(t6,t5);}}
else{
/* expand.scm: 390  err */
t2=((C_word*)t0)[2];
f_4712(t2,((C_word*)t0)[6],lf[102]);}}

/* k5110 in k5107 in k5055 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5112(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* expand.scm: 389  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4746(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k5089 in k5055 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5072(t3,t2);}

/* k5070 in k5055 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* expand.scm: 381  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4746(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* expand.scm: 382  err */
t3=((C_word*)t0)[2];
f_4712(t3,((C_word*)t0)[5],lf[100]);}}

/* k5032 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_5034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* expand.scm: 370  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4746(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k5011 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 338  ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4764,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t3=t2;
f_4764(t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4927,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4933,a[2]=((C_word*)t0)[11],a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5006,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 350  reverse */
t6=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}

/* k5004 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4932 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4933,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5002,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* expand.scm: 322  string->keyword */
((C_proc3)C_retrieve_symbol_proc(lf[98]))(3,*((C_word*)lf[98]+1),t4,t5);}

/* k5000 in a4932 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5002,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[95],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4968,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4986,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t7=t5;
f_4968(t7,C_SCHEME_END_OF_LIST);}}

/* k4984 in k5000 in a4932 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4986,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[97],t2);
t4=((C_word*)t0)[2];
f_4968(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4966 in k5000 in a4932 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4968(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4962 in k5000 in a4932 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4964,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[96],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k4925 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4929 in k4925 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4931,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4764(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4762 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4764,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4767,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[10]))){
t3=t2;
f_4767(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t4=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t4)){
t5=t3;
f_4776(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[10]);
t6=t3;
f_4776(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_4776(t5,C_SCHEME_FALSE);}}}}

/* k4774 in k4762 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4776,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4803,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 355  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[5]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 359  reverse */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4879,a[2]=t4,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 362  reverse */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}}}

/* k4877 in k4774 in k4762 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4879,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* expand.scm: 362  ##sys#append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k4869 in k4774 in k4762 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4873 in k4869 in k4774 in k4762 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4875,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4767(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4846 in k4774 in k4762 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4850 in k4846 in k4774 in k4762 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4852,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_4767(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}

/* k4801 in k4774 in k4762 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 355  cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[94]+1)))(3,*((C_word*)lf[94]+1),t2,((C_word*)t0)[2]);}

/* k4821 in k4801 in k4774 in k4762 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4823,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[7])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4793 in k4821 in k4801 in k4774 in k4762 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4795,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4767(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k4765 in k4762 in k4758 in loop in k4739 in k4736 in k4733 in k4730 in k4727 in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 337  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4712,NULL,3,t0,t1,t2);}
/* expand.scm: 321  errh */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4666,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4672,a[2]=t4,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4672(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4672,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[89]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4691,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4691(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[90]);
t7=t5;
f_4691(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[91])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4689 in loop in ##sys#extended-lambda-list? in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 315  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4672(t3,((C_word*)t0)[4],t2);}}

/* ##sys#expand in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4613r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4613r(t0,t1,t2,t3);}}

static void C_ccall f_4613r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4617,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 288  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4617(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4615 in ##sys#expand in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4617,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4622,a[2]=t3,a[3]=t1,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4622(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4615 in ##sys#expand in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4622(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4622,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[2],a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a4633 in loop in k4615 in ##sys#expand in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4634,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* expand.scm: 292  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4622(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a4627 in loop in k4615 in ##sys#expand in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4628,2,t0,t1);}
/* expand.scm: 290  ##sys#expand-0 */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4523,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4526,a[2]=t3,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4559,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 268  ##sys#qualified-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t5,t2);}

/* k4557 in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 269  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t2,((C_word*)t0)[3],lf[83]);}}

/* k4560 in k4557 in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4562,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4568,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 271  dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t2,lf[81],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 273  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t2,((C_word*)t0)[3],lf[85]);}}

/* k4572 in k4560 in k4557 in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4574,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4577,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 274  dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t2,lf[82],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4611,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 276  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t2);}}

/* k4609 in k4572 in k4560 in k4557 in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4611,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4586,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 278  dm */
((C_proc4)C_retrieve2_symbol_proc(lf[7],"dm"))(4,lf[7],t3,lf[84],((C_word*)t0)[4]);}
else{
/* expand.scm: 283  mrename */
t3=((C_word*)t0)[3];
f_4526(t3,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k4584 in k4609 in k4572 in k4560 in k4557 in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4586,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t2))){
/* expand.scm: 281  mrename */
t3=((C_word*)t0)[4];
f_4526(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4601,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 282  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t3,t2,lf[83]);}}

/* k4599 in k4584 in k4609 in k4572 in k4560 in k4557 in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4575 in k4572 in k4560 in k4557 in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4566 in k4560 in k4557 in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* mrename in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4526(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4526,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4530,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 262  ##sys#current-module */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t3);}

/* k4528 in mrename in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4530,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4536,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4553,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 264  module-name */
t4=C_retrieve2(lf[76],"module-name");
f_9575(3,t4,t3,t1);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k4551 in k4528 in mrename in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 264  dm */
((C_proc6)C_retrieve2_symbol_proc(lf[7],"dm"))(6,lf[7],((C_word*)t0)[3],lf[78],((C_word*)t0)[2],lf[79],t1);}

/* k4534 in k4528 in mrename in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4539(2,t3,C_SCHEME_UNDEFINED);}
else{
/* expand.scm: 265  ##sys#register-undefined */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k4537 in k4534 in k4528 in mrename in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 266  module-name */
t3=C_retrieve2(lf[76],"module-name");
f_9575(3,t3,t2,((C_word*)t0)[2]);}

/* k4544 in k4537 in k4534 in k4528 in mrename in ##sys#alias-global-hook in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 266  ##sys#module-rename */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#module-rename in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4505,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4513,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
/* expand.scm: 255  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),t4,t5,lf[75],t6);}

/* k4511 in ##sys#module-rename in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 254  ##sys#string->symbol */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),((C_word*)t0)[2],t1);}

/* ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4023,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4026,a[2]=t3,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4205,a[2]=t4,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4322,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t7,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 220  lookup */
f_3609(t8,t6,t3);}
else{
/* expand.scm: 248  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* expand.scm: 249  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4322,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[7]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4328,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=t5;
f_4328(t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4489,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4496,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 222  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t7);}}

/* k4494 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 222  lookup */
f_3609(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4487 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?t1:((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4328(t4,t3);}

/* k4326 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4328(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4328,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[58]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 224  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t3,lf[58],((C_word*)t0)[7],lf[66],C_SCHEME_FALSE,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[8])[1];
if(C_truep((C_truep((C_word)C_eqp(t4,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[71]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=t3;
f_4430(t6,(C_word)C_i_pairp(t5));}
else{
t5=t3;
f_4430(t5,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4430(t5,C_SCHEME_FALSE);}}}

/* k4428 in k4326 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4430,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 241  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t3,lf[69],((C_word*)t0)[8],lf[70],C_SCHEME_FALSE,((C_word*)t0)[6]);}
else{
/* expand.scm: 247  expand */
t2=((C_word*)t0)[5];
f_4205(t2,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k4434 in k4428 in k4326 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,lf[67],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* expand.scm: 243  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[68]+1)))(5,*((C_word*)lf[68]+1),t2,t5,t6,t7);}

/* k4441 in k4434 in k4428 in k4326 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 242  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k4335 in k4326 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4337,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 227  ##sys#check-syntax */
((C_proc7)C_retrieve_symbol_proc(lf[64]))(7,*((C_word*)lf[64]+1),t3,lf[58],((C_word*)t0)[5],lf[65],C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
/* expand.scm: 236  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k4347 in k4335 in k4326 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4407,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4417,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a4416 in k4347 in k4335 in k4326 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4417,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k4405 in k4347 in k4335 in k4326 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k4409 in k4405 in k4347 in k4335 in k4326 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4411,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[60],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[61],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4371,a[2]=((C_word*)t0)[3],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4375,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 234  ##sys#map */
t12=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[63]+1),((C_word*)t0)[2]);}

/* k4373 in k4409 in k4405 in k4347 in k4335 in k4326 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4369 in k4409 in k4405 in k4347 in k4335 in k4326 in k4320 in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4371,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[62],t2);
/* expand.scm: 229  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4205,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4209,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4262,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 201  get */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t6,t2,lf[12]);}

/* k4260 in expand in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_symbolp(t1);
t4=t2;
f_4265(t4,(C_truep(t3)?t1:lf[14]));}
else{
t3=t2;
f_4265(t3,lf[57]);}}

/* k4263 in k4260 in expand in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4265,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4287,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4291,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* expand.scm: 206  map-se */
f_3676(t4,t5);}
else{
t3=t2;
f_4277(t3,((C_word*)t0)[2]);}}

/* k4289 in k4263 in k4260 in expand in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4285 in k4263 in k4260 in expand in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4287,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4277(t2,(C_word)C_a_i_cons(&a,2,lf[56],t1));}

/* k4275 in k4263 in k4260 in expand in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4277,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[55],t5);
/* expand.scm: 199  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],((C_word*)t0)[2],t6);}

/* k4207 in expand in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4209,2,t0,t1);}
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4231,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 213  call-handler */
t5=((C_word*)t0)[3];
f_4026(t5,t2,((C_word*)t0)[2],t3,((C_word*)t0)[6],t4);}
else{
/* expand.scm: 215  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[6],C_SCHEME_FALSE);}}
else{
/* expand.scm: 209  ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),((C_word*)t0)[4],lf[54],((C_word*)t0)[6]);}}

/* k4229 in k4207 in expand in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 211  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4026(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4026,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4030,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* expand.scm: 166  dd */
((C_proc4)C_retrieve2_symbol_proc(lf[6],"dd"))(4,lf[6],t6,lf[52],t2);}

/* k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4199,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4203,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 167  map-se */
f_3676(t4,((C_word*)t0)[3]);}

/* k4201 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4197 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4199,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[50],t1);
/* expand.scm: 167  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],((C_word*)t0)[2],t2);}

/* k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4039,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[49]+1)))(3,*((C_word*)lf[49]+1),t2,t3);}

/* a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4041,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4047,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4154,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li22),tmp=(C_word)a,a+=9,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[48]))(4,*((C_word*)lf[48]+1),t1,t3,t4);}

/* a4153 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4160,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li19),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4181,a[2]=((C_word*)t0)[2],a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4180 in a4153 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4181(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4181r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4181r(t0,t1,t2);}}

static void C_ccall f_4181r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4187,a[2]=t2,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* k261266 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4186 in a4180 in a4153 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4187,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4159 in a4153 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4164,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 195  handler */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4162 in a4159 in a4153 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4167,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[47],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
/* expand.scm: 196  dd */
((C_proc3)C_retrieve2_symbol_proc(lf[6],"dd"))(3,lf[6],t2,t5);}

/* k4165 in k4162 in a4159 in a4153 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4046 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4047,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
/* k261266 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4052 in a4046 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4061,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[3],lf[40]))){
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t5=t3;
f_4064(t5,(C_word)C_i_memq(lf[46],t4));}
else{
t4=t3;
f_4064(t4,C_SCHEME_FALSE);}}

/* k4062 in a4052 in a4046 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4064(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4064,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4075,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4081,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4081(t8,t3,t4);}
else{
t2=((C_word*)t0)[3];
f_4061(t2,((C_word*)t0)[4]);}}

/* copy in k4062 in a4052 in a4046 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4081(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4081,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_equalp(lf[45],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_i_car(t4);
t7=t5;
f_4100(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_4100(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_4100(t6,C_SCHEME_FALSE);}}}

/* k4098 in copy in k4062 in a4052 in a4046 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4100(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4100,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4111,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* expand.scm: 187  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[42]+1)))(6,*((C_word*)lf[42]+1),t2,lf[43],t3,lf[44],t4);}
else{
/* expand.scm: 193  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4081(t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k4109 in k4098 in copy in k4062 in a4052 in a4046 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4111,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[41],t3));}

/* k4073 in k4062 in a4052 in a4046 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4075,2,t0,t1);}
t2=((C_word*)t0)[3];
f_4061(t2,(C_word)C_a_i_record(&a,3,lf[40],((C_word*)t0)[2],t1));}

/* k4059 in a4052 in a4046 in a4040 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_4061(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 171  ##sys#abort */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t1);}

/* k4037 in k4031 in k4028 in call-handler in ##sys#expand-0 in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4014,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[37]);
/* expand.scm: 159  ##sys#unregister-macro */
((C_proc3)C_retrieve_symbol_proc(lf[35]))(3,*((C_word*)lf[35]+1),t1,t2);}

/* ##sys#unregister-macro in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3963,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3971,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3975,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 152  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}

/* k3973 in ##sys#unregister-macro in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3977,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3977(t5,((C_word*)t0)[2],t1);}

/* loop in k3973 in ##sys#unregister-macro in k3855 in k3605 in k3601 in k3574 */
static void C_fcall f_3977(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3977,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 154  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,t2);}}

/* k4010 in loop in k3973 in ##sys#unregister-macro in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4012,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4004,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 155  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3977(t6,t4,t5);}}

/* k4002 in k4010 in loop in k3973 in ##sys#unregister-macro in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3969 in ##sys#unregister-macro in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 150  ##sys#macro-environment */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),((C_word*)t0)[2],t1);}

/* macro? in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3907r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3907r(t0,t1,t2,t3);}}

static void C_ccall f_3907r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3911,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 141  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3911(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3909 in macro? in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3911,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[3],lf[34]);
t3=(C_word)C_i_check_list_2(t1,lf[34]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 144  lookup */
f_3609(t4,((C_word*)t0)[3],t1);}

/* k3918 in k3909 in macro? in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3920,2,t0,t1);}
t2=(C_word)C_i_pairp(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 146  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t4);}}

/* k3937 in k3918 in k3909 in macro? in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 146  lookup */
f_3609(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3927 in k3918 in k3909 in macro? in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_pairp(t1):C_SCHEME_FALSE));}

/* ##sys#copy-macro in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3894,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3898,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3905,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 138  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t5);}

/* k3903 in ##sys#copy-macro in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 138  lookup */
f_3609(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3896 in ##sys#copy-macro in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],C_retrieve(lf[32]),((C_word*)t0)[2],t1);}

/* ##sys#extend-macro-environment in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3861,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3865,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm: 127  ##sys#macro-environment */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t5);}

/* k3863 in ##sys#extend-macro-environment in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3868,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm: 128  lookup */
f_3609(t2,((C_word*)t0)[2],t1);}

/* k3866 in k3863 in ##sys#extend-macro-environment in k3855 in k3605 in k3601 in k3574 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_set_car(t1,((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(t1);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t3,((C_word*)t0)[4]));}
else{
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
/* expand.scm: 133  ##sys#macro-environment */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),((C_word*)t0)[5],t3);}}

/* ##sys#strip-syntax in k3605 in k3601 in k3574 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_3706r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3706r(t0,t1,t2,t3);}}

static void C_ccall f_3706r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3708,a[2]=t2,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3801,a[2]=t4,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3806,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-se102142 */
t7=t6;
f_3806(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-alias103138 */
t9=t5;
f_3801(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body100109 */
t11=t4;
f_3708(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-se102 in ##sys#strip-syntax in k3605 in k3601 in k3574 */
static void C_fcall f_3806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3806,NULL,2,t0,t1);}
/* def-alias103138 */
t2=((C_word*)t0)[2];
f_3801(t2,t1,C_SCHEME_FALSE);}

/* def-alias103 in ##sys#strip-syntax in k3605 in k3601 in k3574 */
static void C_fcall f_3801(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3801,NULL,3,t0,t1,t2);}
/* body100109 */
t3=((C_word*)t0)[2];
f_3708(t3,t1,t2,C_SCHEME_FALSE);}

/* body100 in ##sys#strip-syntax in k3605 in k3601 in k3574 */
static void C_fcall f_3708(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3708,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3714,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3714(3,t7,t1,((C_word*)t0)[2]);}

/* walk in body100 in ##sys#strip-syntax in k3605 in k3601 in k3574 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_3714,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* expand.scm: 103  lookup */
f_3609(t3,t2,((C_word*)t0)[3]);}
else{
/* expand.scm: 104  get */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t3,t2,lf[12]);}}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3771,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* expand.scm: 111  walk */
t9=t3;
t10=t4;
t1=t9;
t2=t10;
c=3;
goto loop;}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3796,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3800,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm: 114  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t4,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}}

/* k3798 in walk in body100 in ##sys#strip-syntax in k3605 in k3601 in k3574 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3794 in walk in body100 in ##sys#strip-syntax in k3605 in k3601 in k3574 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* expand.scm: 114  list->vector */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3769 in walk in body100 in ##sys#strip-syntax in k3605 in k3601 in k3574 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3775,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* expand.scm: 112  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3714(3,t4,t2,t3);}

/* k3773 in k3769 in walk in body100 in ##sys#strip-syntax in k3605 in k3601 in k3574 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3775,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3722 in walk in body100 in ##sys#strip-syntax in k3605 in k3601 in k3574 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3730,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[2]);
t4=t2;
f_3730(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3730(t3,C_SCHEME_FALSE);}}

/* k3728 in k3722 in walk in body100 in ##sys#strip-syntax in k3605 in k3601 in k3574 */
static void C_fcall f_3730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* expand.scm: 106  ##sys#alias-global-hook */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[2];
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[2]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?((C_word*)t0)[3]:((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}}

/* map-se in k3605 in k3601 in k3574 */
static void C_fcall f_3676(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3676,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3682,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a3681 in map-se in k3605 in k3601 in k3574 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3682,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_symbolp(t4);
t6=(C_truep(t5)?(C_word)C_i_cdr(t2):lf[14]);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t3,t6));}

/* macro-alias in k3605 in k3601 in k3574 */
static void C_fcall f_3627(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3627,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3634,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 78   ##sys#qualified-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t4,t2);}

/* k3632 in macro-alias in k3605 in k3601 in k3574 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3637(t3,t1);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(C_word)C_fixnum_greaterp(t4,C_fix(0));
t6=t2;
f_3637(t6,(C_truep(t5)?(C_word)C_eqp(C_make_character(35),(C_word)C_subchar(t3,C_fix(0))):C_SCHEME_FALSE));}}

/* k3635 in k3632 in macro-alias in k3605 in k3601 in k3574 */
static void C_fcall f_3637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3637,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 84   gensym */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[3]);}}

/* k3638 in k3635 in k3632 in macro-alias in k3605 in k3601 in k3574 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3643,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 85   lookup */
f_3609(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k3641 in k3638 in k3635 in k3632 in macro-alias in k3605 in k3601 in k3574 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3643,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3649,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm: 86   ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[17]))(5,*((C_word*)lf[17]+1),t3,((C_word*)t0)[2],lf[12],t2);}

/* k3647 in k3641 in k3638 in k3635 in k3632 in macro-alias in k3605 in k3601 in k3574 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3652,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_pairp(((C_word*)t0)[2]);
t4=(C_truep(t3)?lf[14]:((C_word*)t0)[2]);
/* expand.scm: 87   dd */
((C_proc6)C_retrieve2_symbol_proc(lf[6],"dd"))(6,lf[6],t2,lf[15],((C_word*)t0)[3],lf[16],t4);}

/* k3650 in k3647 in k3641 in k3638 in k3635 in k3632 in macro-alias in k3605 in k3601 in k3574 */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* lookup in k3605 in k3601 in k3574 */
static void C_fcall f_3609(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3609,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cdr(t4));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3622,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm: 74   ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t5,t2,lf[12]);}}

/* k3620 in lookup in k3605 in k3601 in k3574 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:C_SCHEME_FALSE));}

/* d in k3574 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3578r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3578r(t0,t1,t2,t3);}}

static void C_ccall f_3578r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_fudge(C_fix(13)))){
if(C_truep((C_word)C_i_nullp(t3))){
/* expand.scm: 43   pp */
((C_proc3)C_retrieve_symbol_proc(lf[4]))(3,*((C_word*)lf[4]+1),t1,t2);}
else{
C_apply(5,0,t1,*((C_word*)lf[5]+1),t2,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[899] = {
{"toplevel:expand_scm",(void*)C_expand_toplevel},
{"f_3576:expand_scm",(void*)f_3576},
{"f_3603:expand_scm",(void*)f_3603},
{"f_3607:expand_scm",(void*)f_3607},
{"f_3857:expand_scm",(void*)f_3857},
{"f_13932:expand_scm",(void*)f_13932},
{"f_13930:expand_scm",(void*)f_13930},
{"f_7853:expand_scm",(void*)f_7853},
{"f_13922:expand_scm",(void*)f_13922},
{"f_13920:expand_scm",(void*)f_13920},
{"f_7856:expand_scm",(void*)f_7856},
{"f_7860:expand_scm",(void*)f_7860},
{"f_13780:expand_scm",(void*)f_13780},
{"f_13790:expand_scm",(void*)f_13790},
{"f_13806:expand_scm",(void*)f_13806},
{"f_13809:expand_scm",(void*)f_13809},
{"f_13837:expand_scm",(void*)f_13837},
{"f_13812:expand_scm",(void*)f_13812},
{"f_13859:expand_scm",(void*)f_13859},
{"f_13862:expand_scm",(void*)f_13862},
{"f_13908:expand_scm",(void*)f_13908},
{"f_13865:expand_scm",(void*)f_13865},
{"f_13888:expand_scm",(void*)f_13888},
{"f_13900:expand_scm",(void*)f_13900},
{"f_13846:expand_scm",(void*)f_13846},
{"f_13849:expand_scm",(void*)f_13849},
{"f_13856:expand_scm",(void*)f_13856},
{"f_13778:expand_scm",(void*)f_13778},
{"f_7863:expand_scm",(void*)f_7863},
{"f_13721:expand_scm",(void*)f_13721},
{"f_13750:expand_scm",(void*)f_13750},
{"f_13770:expand_scm",(void*)f_13770},
{"f_13774:expand_scm",(void*)f_13774},
{"f_13719:expand_scm",(void*)f_13719},
{"f_7866:expand_scm",(void*)f_7866},
{"f_13631:expand_scm",(void*)f_13631},
{"f_13656:expand_scm",(void*)f_13656},
{"f_13663:expand_scm",(void*)f_13663},
{"f_13683:expand_scm",(void*)f_13683},
{"f_13703:expand_scm",(void*)f_13703},
{"f_13707:expand_scm",(void*)f_13707},
{"f_13629:expand_scm",(void*)f_13629},
{"f_7869:expand_scm",(void*)f_7869},
{"f_13298:expand_scm",(void*)f_13298},
{"f_13305:expand_scm",(void*)f_13305},
{"f_13308:expand_scm",(void*)f_13308},
{"f_13311:expand_scm",(void*)f_13311},
{"f_13314:expand_scm",(void*)f_13314},
{"f_13317:expand_scm",(void*)f_13317},
{"f_13320:expand_scm",(void*)f_13320},
{"f_13323:expand_scm",(void*)f_13323},
{"f_13328:expand_scm",(void*)f_13328},
{"f_13344:expand_scm",(void*)f_13344},
{"f_13350:expand_scm",(void*)f_13350},
{"f_13392:expand_scm",(void*)f_13392},
{"f_13460:expand_scm",(void*)f_13460},
{"f_13585:expand_scm",(void*)f_13585},
{"f_13581:expand_scm",(void*)f_13581},
{"f_13463:expand_scm",(void*)f_13463},
{"f_13518:expand_scm",(void*)f_13518},
{"f_13395:expand_scm",(void*)f_13395},
{"f_13434:expand_scm",(void*)f_13434},
{"f_13386:expand_scm",(void*)f_13386},
{"f_13357:expand_scm",(void*)f_13357},
{"f_13296:expand_scm",(void*)f_13296},
{"f_7872:expand_scm",(void*)f_7872},
{"f_13128:expand_scm",(void*)f_13128},
{"f_13132:expand_scm",(void*)f_13132},
{"f_13141:expand_scm",(void*)f_13141},
{"f_13144:expand_scm",(void*)f_13144},
{"f_13147:expand_scm",(void*)f_13147},
{"f_13150:expand_scm",(void*)f_13150},
{"f_13153:expand_scm",(void*)f_13153},
{"f_13174:expand_scm",(void*)f_13174},
{"f_13190:expand_scm",(void*)f_13190},
{"f_13196:expand_scm",(void*)f_13196},
{"f_13252:expand_scm",(void*)f_13252},
{"f_13250:expand_scm",(void*)f_13250},
{"f_13246:expand_scm",(void*)f_13246},
{"f_13238:expand_scm",(void*)f_13238},
{"f_13234:expand_scm",(void*)f_13234},
{"f_13203:expand_scm",(void*)f_13203},
{"f_13172:expand_scm",(void*)f_13172},
{"f_13126:expand_scm",(void*)f_13126},
{"f_7875:expand_scm",(void*)f_7875},
{"f_13059:expand_scm",(void*)f_13059},
{"f_13063:expand_scm",(void*)f_13063},
{"f_13072:expand_scm",(void*)f_13072},
{"f_13077:expand_scm",(void*)f_13077},
{"f_13114:expand_scm",(void*)f_13114},
{"f_13095:expand_scm",(void*)f_13095},
{"f_13057:expand_scm",(void*)f_13057},
{"f_7878:expand_scm",(void*)f_7878},
{"f_12877:expand_scm",(void*)f_12877},
{"f_12881:expand_scm",(void*)f_12881},
{"f_12893:expand_scm",(void*)f_12893},
{"f_12896:expand_scm",(void*)f_12896},
{"f_12899:expand_scm",(void*)f_12899},
{"f_12902:expand_scm",(void*)f_12902},
{"f_13037:expand_scm",(void*)f_13037},
{"f_12917:expand_scm",(void*)f_12917},
{"f_13035:expand_scm",(void*)f_13035},
{"f_12944:expand_scm",(void*)f_12944},
{"f_13025:expand_scm",(void*)f_13025},
{"f_12960:expand_scm",(void*)f_12960},
{"f_12982:expand_scm",(void*)f_12982},
{"f_12980:expand_scm",(void*)f_12980},
{"f_12976:expand_scm",(void*)f_12976},
{"f_12875:expand_scm",(void*)f_12875},
{"f_7881:expand_scm",(void*)f_7881},
{"f_12482:expand_scm",(void*)f_12482},
{"f_12486:expand_scm",(void*)f_12486},
{"f_12489:expand_scm",(void*)f_12489},
{"f_12492:expand_scm",(void*)f_12492},
{"f_12495:expand_scm",(void*)f_12495},
{"f_12864:expand_scm",(void*)f_12864},
{"f_12776:expand_scm",(void*)f_12776},
{"f_12780:expand_scm",(void*)f_12780},
{"f_12805:expand_scm",(void*)f_12805},
{"f_12851:expand_scm",(void*)f_12851},
{"f_12836:expand_scm",(void*)f_12836},
{"f_12507:expand_scm",(void*)f_12507},
{"f_12554:expand_scm",(void*)f_12554},
{"f_12601:expand_scm",(void*)f_12601},
{"f_12762:expand_scm",(void*)f_12762},
{"f_12770:expand_scm",(void*)f_12770},
{"f_12748:expand_scm",(void*)f_12748},
{"f_12737:expand_scm",(void*)f_12737},
{"f_12745:expand_scm",(void*)f_12745},
{"f_12722:expand_scm",(void*)f_12722},
{"f_12710:expand_scm",(void*)f_12710},
{"f_12691:expand_scm",(void*)f_12691},
{"f_12649:expand_scm",(void*)f_12649},
{"f_12626:expand_scm",(void*)f_12626},
{"f_12580:expand_scm",(void*)f_12580},
{"f_12529:expand_scm",(void*)f_12529},
{"f_12525:expand_scm",(void*)f_12525},
{"f_12497:expand_scm",(void*)f_12497},
{"f_12505:expand_scm",(void*)f_12505},
{"f_12480:expand_scm",(void*)f_12480},
{"f_7884:expand_scm",(void*)f_7884},
{"f_12449:expand_scm",(void*)f_12449},
{"f_12453:expand_scm",(void*)f_12453},
{"f_12447:expand_scm",(void*)f_12447},
{"f_7887:expand_scm",(void*)f_7887},
{"f_12165:expand_scm",(void*)f_12165},
{"f_12172:expand_scm",(void*)f_12172},
{"f_12175:expand_scm",(void*)f_12175},
{"f_12178:expand_scm",(void*)f_12178},
{"f_12181:expand_scm",(void*)f_12181},
{"f_12184:expand_scm",(void*)f_12184},
{"f_12346:expand_scm",(void*)f_12346},
{"f_12399:expand_scm",(void*)f_12399},
{"f_12421:expand_scm",(void*)f_12421},
{"f_12428:expand_scm",(void*)f_12428},
{"f_12415:expand_scm",(void*)f_12415},
{"f_12362:expand_scm",(void*)f_12362},
{"f_12360:expand_scm",(void*)f_12360},
{"f_12196:expand_scm",(void*)f_12196},
{"f_12227:expand_scm",(void*)f_12227},
{"f_12273:expand_scm",(void*)f_12273},
{"f_12323:expand_scm",(void*)f_12323},
{"f_12330:expand_scm",(void*)f_12330},
{"f_12288:expand_scm",(void*)f_12288},
{"f_12302:expand_scm",(void*)f_12302},
{"f_12245:expand_scm",(void*)f_12245},
{"f_12256:expand_scm",(void*)f_12256},
{"f_12186:expand_scm",(void*)f_12186},
{"f_12163:expand_scm",(void*)f_12163},
{"f_7890:expand_scm",(void*)f_7890},
{"f_12144:expand_scm",(void*)f_12144},
{"f_12142:expand_scm",(void*)f_12142},
{"f_7893:expand_scm",(void*)f_7893},
{"f_12123:expand_scm",(void*)f_12123},
{"f_12121:expand_scm",(void*)f_12121},
{"f_7896:expand_scm",(void*)f_7896},
{"f_12072:expand_scm",(void*)f_12072},
{"f_12076:expand_scm",(void*)f_12076},
{"f_12113:expand_scm",(void*)f_12113},
{"f_12106:expand_scm",(void*)f_12106},
{"f_12099:expand_scm",(void*)f_12099},
{"f_12070:expand_scm",(void*)f_12070},
{"f_7899:expand_scm",(void*)f_7899},
{"f_12018:expand_scm",(void*)f_12018},
{"f_12022:expand_scm",(void*)f_12022},
{"f_12025:expand_scm",(void*)f_12025},
{"f_12062:expand_scm",(void*)f_12062},
{"f_12028:expand_scm",(void*)f_12028},
{"f_12043:expand_scm",(void*)f_12043},
{"f_12047:expand_scm",(void*)f_12047},
{"f_12016:expand_scm",(void*)f_12016},
{"f_7902:expand_scm",(void*)f_7902},
{"f_11915:expand_scm",(void*)f_11915},
{"f_11922:expand_scm",(void*)f_11922},
{"f_11925:expand_scm",(void*)f_11925},
{"f_11945:expand_scm",(void*)f_11945},
{"f_11967:expand_scm",(void*)f_11967},
{"f_11952:expand_scm",(void*)f_11952},
{"f_11959:expand_scm",(void*)f_11959},
{"f_11928:expand_scm",(void*)f_11928},
{"f_11943:expand_scm",(void*)f_11943},
{"f_11935:expand_scm",(void*)f_11935},
{"f_11931:expand_scm",(void*)f_11931},
{"f_11913:expand_scm",(void*)f_11913},
{"f_7905:expand_scm",(void*)f_7905},
{"f_11878:expand_scm",(void*)f_11878},
{"f_11882:expand_scm",(void*)f_11882},
{"f_11900:expand_scm",(void*)f_11900},
{"f_11891:expand_scm",(void*)f_11891},
{"f_11876:expand_scm",(void*)f_11876},
{"f_7908:expand_scm",(void*)f_7908},
{"f_9553:expand_scm",(void*)f_9553},
{"f_11872:expand_scm",(void*)f_11872},
{"f_9557:expand_scm",(void*)f_9557},
{"f_9561:expand_scm",(void*)f_9561},
{"f_11830:expand_scm",(void*)f_11830},
{"f_11838:expand_scm",(void*)f_11838},
{"f_11840:expand_scm",(void*)f_11840},
{"f_11861:expand_scm",(void*)f_11861},
{"f_11318:expand_scm",(void*)f_11318},
{"f_11325:expand_scm",(void*)f_11325},
{"f_11811:expand_scm",(void*)f_11811},
{"f_11823:expand_scm",(void*)f_11823},
{"f_11334:expand_scm",(void*)f_11334},
{"f_11768:expand_scm",(void*)f_11768},
{"f_11770:expand_scm",(void*)f_11770},
{"f_11809:expand_scm",(void*)f_11809},
{"f_11783:expand_scm",(void*)f_11783},
{"f_11794:expand_scm",(void*)f_11794},
{"f_11337:expand_scm",(void*)f_11337},
{"f_11637:expand_scm",(void*)f_11637},
{"f_11688:expand_scm",(void*)f_11688},
{"f_11742:expand_scm",(void*)f_11742},
{"f_11700:expand_scm",(void*)f_11700},
{"f_11728:expand_scm",(void*)f_11728},
{"f_11724:expand_scm",(void*)f_11724},
{"f_11720:expand_scm",(void*)f_11720},
{"f_11703:expand_scm",(void*)f_11703},
{"f_11685:expand_scm",(void*)f_11685},
{"f_11674:expand_scm",(void*)f_11674},
{"f_11340:expand_scm",(void*)f_11340},
{"f_11631:expand_scm",(void*)f_11631},
{"f_11546:expand_scm",(void*)f_11546},
{"f_11557:expand_scm",(void*)f_11557},
{"f_11560:expand_scm",(void*)f_11560},
{"f_11597:expand_scm",(void*)f_11597},
{"f_11623:expand_scm",(void*)f_11623},
{"f_11611:expand_scm",(void*)f_11611},
{"f_11615:expand_scm",(void*)f_11615},
{"f_11595:expand_scm",(void*)f_11595},
{"f_11591:expand_scm",(void*)f_11591},
{"f_11584:expand_scm",(void*)f_11584},
{"f_11580:expand_scm",(void*)f_11580},
{"f_11576:expand_scm",(void*)f_11576},
{"f_11343:expand_scm",(void*)f_11343},
{"f_11346:expand_scm",(void*)f_11346},
{"f_11541:expand_scm",(void*)f_11541},
{"f_11505:expand_scm",(void*)f_11505},
{"f_11533:expand_scm",(void*)f_11533},
{"f_11349:expand_scm",(void*)f_11349},
{"f_11499:expand_scm",(void*)f_11499},
{"f_11503:expand_scm",(void*)f_11503},
{"f_11352:expand_scm",(void*)f_11352},
{"f_11355:expand_scm",(void*)f_11355},
{"f_11457:expand_scm",(void*)f_11457},
{"f_11461:expand_scm",(void*)f_11461},
{"f_11491:expand_scm",(void*)f_11491},
{"f_11487:expand_scm",(void*)f_11487},
{"f_11464:expand_scm",(void*)f_11464},
{"f_11358:expand_scm",(void*)f_11358},
{"f_11379:expand_scm",(void*)f_11379},
{"f_11455:expand_scm",(void*)f_11455},
{"f_11451:expand_scm",(void*)f_11451},
{"f_11447:expand_scm",(void*)f_11447},
{"f_11443:expand_scm",(void*)f_11443},
{"f_11439:expand_scm",(void*)f_11439},
{"f_11435:expand_scm",(void*)f_11435},
{"f_11431:expand_scm",(void*)f_11431},
{"f_11427:expand_scm",(void*)f_11427},
{"f_11423:expand_scm",(void*)f_11423},
{"f_11361:expand_scm",(void*)f_11361},
{"f_11364:expand_scm",(void*)f_11364},
{"f_11233:expand_scm",(void*)f_11233},
{"f_11244:expand_scm",(void*)f_11244},
{"f_11246:expand_scm",(void*)f_11246},
{"f_11295:expand_scm",(void*)f_11295},
{"f_11291:expand_scm",(void*)f_11291},
{"f_11274:expand_scm",(void*)f_11274},
{"f_11142:expand_scm",(void*)f_11142},
{"f_11146:expand_scm",(void*)f_11146},
{"f_11149:expand_scm",(void*)f_11149},
{"f_11188:expand_scm",(void*)f_11188},
{"f_11208:expand_scm",(void*)f_11208},
{"f_11198:expand_scm",(void*)f_11198},
{"f_11201:expand_scm",(void*)f_11201},
{"f_11164:expand_scm",(void*)f_11164},
{"f_11170:expand_scm",(void*)f_11170},
{"f_11168:expand_scm",(void*)f_11168},
{"f_10934:expand_scm",(void*)f_10934},
{"f_10938:expand_scm",(void*)f_10938},
{"f_11096:expand_scm",(void*)f_11096},
{"f_11117:expand_scm",(void*)f_11117},
{"f_10961:expand_scm",(void*)f_10961},
{"f_10964:expand_scm",(void*)f_10964},
{"f_11064:expand_scm",(void*)f_11064},
{"f_11086:expand_scm",(void*)f_11086},
{"f_10967:expand_scm",(void*)f_10967},
{"f_11046:expand_scm",(void*)f_11046},
{"f_11058:expand_scm",(void*)f_11058},
{"f_10970:expand_scm",(void*)f_10970},
{"f_11040:expand_scm",(void*)f_11040},
{"f_11044:expand_scm",(void*)f_11044},
{"f_10976:expand_scm",(void*)f_10976},
{"f_10979:expand_scm",(void*)f_10979},
{"f_11028:expand_scm",(void*)f_11028},
{"f_10982:expand_scm",(void*)f_10982},
{"f_11008:expand_scm",(void*)f_11008},
{"f_10985:expand_scm",(void*)f_10985},
{"f_10998:expand_scm",(void*)f_10998},
{"f_10988:expand_scm",(void*)f_10988},
{"f_10540:expand_scm",(void*)f_10540},
{"f_10547:expand_scm",(void*)f_10547},
{"f_10932:expand_scm",(void*)f_10932},
{"f_10563:expand_scm",(void*)f_10563},
{"f_10902:expand_scm",(void*)f_10902},
{"f_10571:expand_scm",(void*)f_10571},
{"f_10884:expand_scm",(void*)f_10884},
{"f_10579:expand_scm",(void*)f_10579},
{"f_10880:expand_scm",(void*)f_10880},
{"f_10872:expand_scm",(void*)f_10872},
{"f_10799:expand_scm",(void*)f_10799},
{"f_10797:expand_scm",(void*)f_10797},
{"f_10793:expand_scm",(void*)f_10793},
{"f_10727:expand_scm",(void*)f_10727},
{"f_10774:expand_scm",(void*)f_10774},
{"f_10759:expand_scm",(void*)f_10759},
{"f_10725:expand_scm",(void*)f_10725},
{"f_10721:expand_scm",(void*)f_10721},
{"f_10647:expand_scm",(void*)f_10647},
{"f_10717:expand_scm",(void*)f_10717},
{"f_10670:expand_scm",(void*)f_10670},
{"f_10713:expand_scm",(void*)f_10713},
{"f_10705:expand_scm",(void*)f_10705},
{"f_10701:expand_scm",(void*)f_10701},
{"f_10681:expand_scm",(void*)f_10681},
{"f_10635:expand_scm",(void*)f_10635},
{"f_10631:expand_scm",(void*)f_10631},
{"f_10575:expand_scm",(void*)f_10575},
{"f_10567:expand_scm",(void*)f_10567},
{"f_10468:expand_scm",(void*)f_10468},
{"f_10472:expand_scm",(void*)f_10472},
{"f_10475:expand_scm",(void*)f_10475},
{"f_10487:expand_scm",(void*)f_10487},
{"f_10526:expand_scm",(void*)f_10526},
{"f_10518:expand_scm",(void*)f_10518},
{"f_10478:expand_scm",(void*)f_10478},
{"f_10481:expand_scm",(void*)f_10481},
{"f_10192:expand_scm",(void*)f_10192},
{"f_10199:expand_scm",(void*)f_10199},
{"f_10273:expand_scm",(void*)f_10273},
{"f_10300:expand_scm",(void*)f_10300},
{"f_10302:expand_scm",(void*)f_10302},
{"f_10462:expand_scm",(void*)f_10462},
{"f_10450:expand_scm",(void*)f_10450},
{"f_10431:expand_scm",(void*)f_10431},
{"f_10413:expand_scm",(void*)f_10413},
{"f_10398:expand_scm",(void*)f_10398},
{"f_10368:expand_scm",(void*)f_10368},
{"f_10353:expand_scm",(void*)f_10353},
{"f_10325:expand_scm",(void*)f_10325},
{"f_10250:expand_scm",(void*)f_10250},
{"f_10262:expand_scm",(void*)f_10262},
{"f_10258:expand_scm",(void*)f_10258},
{"f_10133:expand_scm",(void*)f_10133},
{"f_10139:expand_scm",(void*)f_10139},
{"f_10146:expand_scm",(void*)f_10146},
{"f_10149:expand_scm",(void*)f_10149},
{"f_10065:expand_scm",(void*)f_10065},
{"f_10085:expand_scm",(void*)f_10085},
{"f_10080:expand_scm",(void*)f_10080},
{"f_10067:expand_scm",(void*)f_10067},
{"f_10043:expand_scm",(void*)f_10043},
{"f_10050:expand_scm",(void*)f_10050},
{"f_9962:expand_scm",(void*)f_9962},
{"f_9972:expand_scm",(void*)f_9972},
{"f_9975:expand_scm",(void*)f_9975},
{"f_9978:expand_scm",(void*)f_9978},
{"f_9981:expand_scm",(void*)f_9981},
{"f_10024:expand_scm",(void*)f_10024},
{"f_10028:expand_scm",(void*)f_10028},
{"f_9984:expand_scm",(void*)f_9984},
{"f_9987:expand_scm",(void*)f_9987},
{"f_9990:expand_scm",(void*)f_9990},
{"f_9873:expand_scm",(void*)f_9873},
{"f_9883:expand_scm",(void*)f_9883},
{"f_9886:expand_scm",(void*)f_9886},
{"f_9953:expand_scm",(void*)f_9953},
{"f_9949:expand_scm",(void*)f_9949},
{"f_9889:expand_scm",(void*)f_9889},
{"f_9945:expand_scm",(void*)f_9945},
{"f_9892:expand_scm",(void*)f_9892},
{"f_9931:expand_scm",(void*)f_9931},
{"f_9935:expand_scm",(void*)f_9935},
{"f_9895:expand_scm",(void*)f_9895},
{"f_9898:expand_scm",(void*)f_9898},
{"f_9904:expand_scm",(void*)f_9904},
{"f_9852:expand_scm",(void*)f_9852},
{"f_9859:expand_scm",(void*)f_9859},
{"f_9832:expand_scm",(void*)f_9832},
{"f_9836:expand_scm",(void*)f_9836},
{"f_9829:expand_scm",(void*)f_9829},
{"f_9789:expand_scm",(void*)f_9789},
{"f_9793:expand_scm",(void*)f_9793},
{"f_9783:expand_scm",(void*)f_9783},
{"f_9765:expand_scm",(void*)f_9765},
{"f_9755:expand_scm",(void*)f_9755},
{"f_9737:expand_scm",(void*)f_9737},
{"f_9719:expand_scm",(void*)f_9719},
{"f_9701:expand_scm",(void*)f_9701},
{"f_9683:expand_scm",(void*)f_9683},
{"f_9665:expand_scm",(void*)f_9665},
{"f_9656:expand_scm",(void*)f_9656},
{"f_9647:expand_scm",(void*)f_9647},
{"f_9629:expand_scm",(void*)f_9629},
{"f_9611:expand_scm",(void*)f_9611},
{"f_9602:expand_scm",(void*)f_9602},
{"f_9593:expand_scm",(void*)f_9593},
{"f_9575:expand_scm",(void*)f_9575},
{"f_7910:expand_scm",(void*)f_7910},
{"f_7917:expand_scm",(void*)f_7917},
{"f_7931:expand_scm",(void*)f_7931},
{"f_7935:expand_scm",(void*)f_7935},
{"f_7939:expand_scm",(void*)f_7939},
{"f_7944:expand_scm",(void*)f_7944},
{"f_7950:expand_scm",(void*)f_7950},
{"f_7954:expand_scm",(void*)f_7954},
{"f_7958:expand_scm",(void*)f_7958},
{"f_7962:expand_scm",(void*)f_7962},
{"f_7966:expand_scm",(void*)f_7966},
{"f_7971:expand_scm",(void*)f_7971},
{"f_7975:expand_scm",(void*)f_7975},
{"f_7982:expand_scm",(void*)f_7982},
{"f_7987:expand_scm",(void*)f_7987},
{"f_7991:expand_scm",(void*)f_7991},
{"f_7995:expand_scm",(void*)f_7995},
{"f_7999:expand_scm",(void*)f_7999},
{"f_8004:expand_scm",(void*)f_8004},
{"f_9512:expand_scm",(void*)f_9512},
{"f_9522:expand_scm",(void*)f_9522},
{"f_9529:expand_scm",(void*)f_9529},
{"f_9492:expand_scm",(void*)f_9492},
{"f_9499:expand_scm",(void*)f_9499},
{"f_9506:expand_scm",(void*)f_9506},
{"f_9466:expand_scm",(void*)f_9466},
{"f_9444:expand_scm",(void*)f_9444},
{"f_9451:expand_scm",(void*)f_9451},
{"f_9351:expand_scm",(void*)f_9351},
{"f_9393:expand_scm",(void*)f_9393},
{"f_9442:expand_scm",(void*)f_9442},
{"f_9425:expand_scm",(void*)f_9425},
{"f_9404:expand_scm",(void*)f_9404},
{"f_9364:expand_scm",(void*)f_9364},
{"f_9278:expand_scm",(void*)f_9278},
{"f_9304:expand_scm",(void*)f_9304},
{"f_9349:expand_scm",(void*)f_9349},
{"f_9332:expand_scm",(void*)f_9332},
{"f_9024:expand_scm",(void*)f_9024},
{"f_9071:expand_scm",(void*)f_9071},
{"f_9269:expand_scm",(void*)f_9269},
{"f_9265:expand_scm",(void*)f_9265},
{"f_9232:expand_scm",(void*)f_9232},
{"f_9240:expand_scm",(void*)f_9240},
{"f_9074:expand_scm",(void*)f_9074},
{"f_9080:expand_scm",(void*)f_9080},
{"f_9092:expand_scm",(void*)f_9092},
{"f_9158:expand_scm",(void*)f_9158},
{"f_9173:expand_scm",(void*)f_9173},
{"f_9095:expand_scm",(void*)f_9095},
{"f_9129:expand_scm",(void*)f_9129},
{"f_9098:expand_scm",(void*)f_9098},
{"f_9127:expand_scm",(void*)f_9127},
{"f_9123:expand_scm",(void*)f_9123},
{"f_9119:expand_scm",(void*)f_9119},
{"f_8817:expand_scm",(void*)f_8817},
{"f_8847:expand_scm",(void*)f_8847},
{"f_8947:expand_scm",(void*)f_8947},
{"f_8970:expand_scm",(void*)f_8970},
{"f_8984:expand_scm",(void*)f_8984},
{"f_8988:expand_scm",(void*)f_8988},
{"f_8957:expand_scm",(void*)f_8957},
{"f_8907:expand_scm",(void*)f_8907},
{"f_8911:expand_scm",(void*)f_8911},
{"f_8856:expand_scm",(void*)f_8856},
{"f_8864:expand_scm",(void*)f_8864},
{"f_8841:expand_scm",(void*)f_8841},
{"f_8529:expand_scm",(void*)f_8529},
{"f_8536:expand_scm",(void*)f_8536},
{"f_8575:expand_scm",(void*)f_8575},
{"f_8585:expand_scm",(void*)f_8585},
{"f_8716:expand_scm",(void*)f_8716},
{"f_8720:expand_scm",(void*)f_8720},
{"f_8649:expand_scm",(void*)f_8649},
{"f_8645:expand_scm",(void*)f_8645},
{"f_8583:expand_scm",(void*)f_8583},
{"f_8579:expand_scm",(void*)f_8579},
{"f_8411:expand_scm",(void*)f_8411},
{"f_8415:expand_scm",(void*)f_8415},
{"f_8190:expand_scm",(void*)f_8190},
{"f_8240:expand_scm",(void*)f_8240},
{"f_8354:expand_scm",(void*)f_8354},
{"f_8292:expand_scm",(void*)f_8292},
{"f_8300:expand_scm",(void*)f_8300},
{"f_8296:expand_scm",(void*)f_8296},
{"f_8288:expand_scm",(void*)f_8288},
{"f_8106:expand_scm",(void*)f_8106},
{"f_8113:expand_scm",(void*)f_8113},
{"f_8116:expand_scm",(void*)f_8116},
{"f_8165:expand_scm",(void*)f_8165},
{"f_8161:expand_scm",(void*)f_8161},
{"f_8156:expand_scm",(void*)f_8156},
{"f_8142:expand_scm",(void*)f_8142},
{"f_8154:expand_scm",(void*)f_8154},
{"f_8150:expand_scm",(void*)f_8150},
{"f_8012:expand_scm",(void*)f_8012},
{"f_8056:expand_scm",(void*)f_8056},
{"f_8052:expand_scm",(void*)f_8052},
{"f_8006:expand_scm",(void*)f_8006},
{"f_7008:expand_scm",(void*)f_7008},
{"f_7012:expand_scm",(void*)f_7012},
{"f_7015:expand_scm",(void*)f_7015},
{"f_7018:expand_scm",(void*)f_7018},
{"f_7021:expand_scm",(void*)f_7021},
{"f_7620:expand_scm",(void*)f_7620},
{"f_7623:expand_scm",(void*)f_7623},
{"f_7842:expand_scm",(void*)f_7842},
{"f_7827:expand_scm",(void*)f_7827},
{"f_7626:expand_scm",(void*)f_7626},
{"f_7631:expand_scm",(void*)f_7631},
{"f_7635:expand_scm",(void*)f_7635},
{"f_7644:expand_scm",(void*)f_7644},
{"f_7794:expand_scm",(void*)f_7794},
{"f_7802:expand_scm",(void*)f_7802},
{"f_7647:expand_scm",(void*)f_7647},
{"f_7771:expand_scm",(void*)f_7771},
{"f_7779:expand_scm",(void*)f_7779},
{"f_7650:expand_scm",(void*)f_7650},
{"f_7653:expand_scm",(void*)f_7653},
{"f_7725:expand_scm",(void*)f_7725},
{"f_7759:expand_scm",(void*)f_7759},
{"f_7656:expand_scm",(void*)f_7656},
{"f_7683:expand_scm",(void*)f_7683},
{"f_7723:expand_scm",(void*)f_7723},
{"f_7659:expand_scm",(void*)f_7659},
{"f_7681:expand_scm",(void*)f_7681},
{"f_7677:expand_scm",(void*)f_7677},
{"f_7662:expand_scm",(void*)f_7662},
{"f_7673:expand_scm",(void*)f_7673},
{"f_7669:expand_scm",(void*)f_7669},
{"f_7629:expand_scm",(void*)f_7629},
{"f_7162:expand_scm",(void*)f_7162},
{"f_7181:expand_scm",(void*)f_7181},
{"f_7190:expand_scm",(void*)f_7190},
{"f_7202:expand_scm",(void*)f_7202},
{"f_7282:expand_scm",(void*)f_7282},
{"f_7389:expand_scm",(void*)f_7389},
{"f_7536:expand_scm",(void*)f_7536},
{"f_7539:expand_scm",(void*)f_7539},
{"f_7542:expand_scm",(void*)f_7542},
{"f_7575:expand_scm",(void*)f_7575},
{"f_7579:expand_scm",(void*)f_7579},
{"f_7544:expand_scm",(void*)f_7544},
{"f_7564:expand_scm",(void*)f_7564},
{"f_7560:expand_scm",(void*)f_7560},
{"f_7552:expand_scm",(void*)f_7552},
{"f_7392:expand_scm",(void*)f_7392},
{"f_7401:expand_scm",(void*)f_7401},
{"f_7530:expand_scm",(void*)f_7530},
{"f_7511:expand_scm",(void*)f_7511},
{"f_7499:expand_scm",(void*)f_7499},
{"f_7478:expand_scm",(void*)f_7478},
{"f_7459:expand_scm",(void*)f_7459},
{"f_7447:expand_scm",(void*)f_7447},
{"f_7422:expand_scm",(void*)f_7422},
{"f_7417:expand_scm",(void*)f_7417},
{"f_7285:expand_scm",(void*)f_7285},
{"f_7288:expand_scm",(void*)f_7288},
{"f_7293:expand_scm",(void*)f_7293},
{"f_7379:expand_scm",(void*)f_7379},
{"f_7305:expand_scm",(void*)f_7305},
{"f_7347:expand_scm",(void*)f_7347},
{"f_7205:expand_scm",(void*)f_7205},
{"f_7208:expand_scm",(void*)f_7208},
{"f_7213:expand_scm",(void*)f_7213},
{"f_7075:expand_scm",(void*)f_7075},
{"f_7079:expand_scm",(void*)f_7079},
{"f_7082:expand_scm",(void*)f_7082},
{"f_7160:expand_scm",(void*)f_7160},
{"f_7156:expand_scm",(void*)f_7156},
{"f_7097:expand_scm",(void*)f_7097},
{"f_7103:expand_scm",(void*)f_7103},
{"f_7106:expand_scm",(void*)f_7106},
{"f_7145:expand_scm",(void*)f_7145},
{"f_7139:expand_scm",(void*)f_7139},
{"f_7143:expand_scm",(void*)f_7143},
{"f_7107:expand_scm",(void*)f_7107},
{"f_7111:expand_scm",(void*)f_7111},
{"f_7114:expand_scm",(void*)f_7114},
{"f_7118:expand_scm",(void*)f_7118},
{"f_7121:expand_scm",(void*)f_7121},
{"f_7125:expand_scm",(void*)f_7125},
{"f_7128:expand_scm",(void*)f_7128},
{"f_7132:expand_scm",(void*)f_7132},
{"f_7135:expand_scm",(void*)f_7135},
{"f_7085:expand_scm",(void*)f_7085},
{"f_7032:expand_scm",(void*)f_7032},
{"f_7045:expand_scm",(void*)f_7045},
{"f_7052:expand_scm",(void*)f_7052},
{"f_7023:expand_scm",(void*)f_7023},
{"f_7027:expand_scm",(void*)f_7027},
{"f_6714:expand_scm",(void*)f_6714},
{"f_6716:expand_scm",(void*)f_6716},
{"f_6845:expand_scm",(void*)f_6845},
{"f_6878:expand_scm",(void*)f_6878},
{"f_6968:expand_scm",(void*)f_6968},
{"f_6881:expand_scm",(void*)f_6881},
{"f_6884:expand_scm",(void*)f_6884},
{"f_6962:expand_scm",(void*)f_6962},
{"f_6887:expand_scm",(void*)f_6887},
{"f_6956:expand_scm",(void*)f_6956},
{"f_6933:expand_scm",(void*)f_6933},
{"f_6906:expand_scm",(void*)f_6906},
{"f_6913:expand_scm",(void*)f_6913},
{"f_6849:expand_scm",(void*)f_6849},
{"f_6852:expand_scm",(void*)f_6852},
{"f_6982:expand_scm",(void*)f_6982},
{"f_6986:expand_scm",(void*)f_6986},
{"f_6989:expand_scm",(void*)f_6989},
{"f_6719:expand_scm",(void*)f_6719},
{"f_6755:expand_scm",(void*)f_6755},
{"f_6816:expand_scm",(void*)f_6816},
{"f_6819:expand_scm",(void*)f_6819},
{"f_6786:expand_scm",(void*)f_6786},
{"f_6789:expand_scm",(void*)f_6789},
{"f_6767:expand_scm",(void*)f_6767},
{"f_6729:expand_scm",(void*)f_6729},
{"f_6252:expand_scm",(void*)f_6252},
{"f_6666:expand_scm",(void*)f_6666},
{"f_6657:expand_scm",(void*)f_6657},
{"f_6665:expand_scm",(void*)f_6665},
{"f_6254:expand_scm",(void*)f_6254},
{"f_6385:expand_scm",(void*)f_6385},
{"f_6390:expand_scm",(void*)f_6390},
{"f_6628:expand_scm",(void*)f_6628},
{"f_6587:expand_scm",(void*)f_6587},
{"f_6591:expand_scm",(void*)f_6591},
{"f_6409:expand_scm",(void*)f_6409},
{"f_6414:expand_scm",(void*)f_6414},
{"f_6433:expand_scm",(void*)f_6433},
{"f_6356:expand_scm",(void*)f_6356},
{"f_6362:expand_scm",(void*)f_6362},
{"f_6300:expand_scm",(void*)f_6300},
{"f_6304:expand_scm",(void*)f_6304},
{"f_6312:expand_scm",(void*)f_6312},
{"f_6332:expand_scm",(void*)f_6332},
{"f_6257:expand_scm",(void*)f_6257},
{"f_6264:expand_scm",(void*)f_6264},
{"f_6269:expand_scm",(void*)f_6269},
{"f_6273:expand_scm",(void*)f_6273},
{"f_6298:expand_scm",(void*)f_6298},
{"f_6287:expand_scm",(void*)f_6287},
{"f_6291:expand_scm",(void*)f_6291},
{"f_6280:expand_scm",(void*)f_6280},
{"f_6216:expand_scm",(void*)f_6216},
{"f_6238:expand_scm",(void*)f_6238},
{"f_6205:expand_scm",(void*)f_6205},
{"f_6213:expand_scm",(void*)f_6213},
{"f_6135:expand_scm",(void*)f_6135},
{"f_6198:expand_scm",(void*)f_6198},
{"f_6138:expand_scm",(void*)f_6138},
{"f_6191:expand_scm",(void*)f_6191},
{"f_6164:expand_scm",(void*)f_6164},
{"f_6052:expand_scm",(void*)f_6052},
{"f_6133:expand_scm",(void*)f_6133},
{"f_6055:expand_scm",(void*)f_6055},
{"f_6104:expand_scm",(void*)f_6104},
{"f_5299:expand_scm",(void*)f_5299},
{"f_5303:expand_scm",(void*)f_5303},
{"f_5742:expand_scm",(void*)f_5742},
{"f_5748:expand_scm",(void*)f_5748},
{"f_6012:expand_scm",(void*)f_6012},
{"f_5770:expand_scm",(void*)f_5770},
{"f_5980:expand_scm",(void*)f_5980},
{"f_5954:expand_scm",(void*)f_5954},
{"f_5961:expand_scm",(void*)f_5961},
{"f_5926:expand_scm",(void*)f_5926},
{"f_5914:expand_scm",(void*)f_5914},
{"f_5788:expand_scm",(void*)f_5788},
{"f_5793:expand_scm",(void*)f_5793},
{"f_5806:expand_scm",(void*)f_5806},
{"f_5862:expand_scm",(void*)f_5862},
{"f_5889:expand_scm",(void*)f_5889},
{"f_5840:expand_scm",(void*)f_5840},
{"f_5851:expand_scm",(void*)f_5851},
{"f_5855:expand_scm",(void*)f_5855},
{"f_5565:expand_scm",(void*)f_5565},
{"f_5575:expand_scm",(void*)f_5575},
{"f_5724:expand_scm",(void*)f_5724},
{"f_5720:expand_scm",(void*)f_5720},
{"f_5710:expand_scm",(void*)f_5710},
{"f_5713:expand_scm",(void*)f_5713},
{"f_5621:expand_scm",(void*)f_5621},
{"f_5653:expand_scm",(void*)f_5653},
{"f_5665:expand_scm",(void*)f_5665},
{"f_5673:expand_scm",(void*)f_5673},
{"f_5677:expand_scm",(void*)f_5677},
{"f_5639:expand_scm",(void*)f_5639},
{"f_5590:expand_scm",(void*)f_5590},
{"f_5606:expand_scm",(void*)f_5606},
{"f_5598:expand_scm",(void*)f_5598},
{"f_5602:expand_scm",(void*)f_5602},
{"f_5573:expand_scm",(void*)f_5573},
{"f_5305:expand_scm",(void*)f_5305},
{"f_5416:expand_scm",(void*)f_5416},
{"f_5557:expand_scm",(void*)f_5557},
{"f_5545:expand_scm",(void*)f_5545},
{"f_5438:expand_scm",(void*)f_5438},
{"f_5543:expand_scm",(void*)f_5543},
{"f_5527:expand_scm",(void*)f_5527},
{"f_5446:expand_scm",(void*)f_5446},
{"f_5521:expand_scm",(void*)f_5521},
{"f_5525:expand_scm",(void*)f_5525},
{"f_5460:expand_scm",(void*)f_5460},
{"f_5464:expand_scm",(void*)f_5464},
{"f_5497:expand_scm",(void*)f_5497},
{"f_5495:expand_scm",(void*)f_5495},
{"f_5491:expand_scm",(void*)f_5491},
{"f_5454:expand_scm",(void*)f_5454},
{"f_5458:expand_scm",(void*)f_5458},
{"f_5450:expand_scm",(void*)f_5450},
{"f_5442:expand_scm",(void*)f_5442},
{"f_5422:expand_scm",(void*)f_5422},
{"f_5317:expand_scm",(void*)f_5317},
{"f_5331:expand_scm",(void*)f_5331},
{"f_5406:expand_scm",(void*)f_5406},
{"f_5399:expand_scm",(void*)f_5399},
{"f_5340:expand_scm",(void*)f_5340},
{"f_5347:expand_scm",(void*)f_5347},
{"f_5355:expand_scm",(void*)f_5355},
{"f_5363:expand_scm",(void*)f_5363},
{"f_5351:expand_scm",(void*)f_5351},
{"f_4709:expand_scm",(void*)f_4709},
{"f_4729:expand_scm",(void*)f_4729},
{"f_4732:expand_scm",(void*)f_4732},
{"f_4735:expand_scm",(void*)f_4735},
{"f_4738:expand_scm",(void*)f_4738},
{"f_4741:expand_scm",(void*)f_4741},
{"f_4746:expand_scm",(void*)f_4746},
{"f_5057:expand_scm",(void*)f_5057},
{"f_5236:expand_scm",(void*)f_5236},
{"f_5174:expand_scm",(void*)f_5174},
{"f_5155:expand_scm",(void*)f_5155},
{"f_5109:expand_scm",(void*)f_5109},
{"f_5112:expand_scm",(void*)f_5112},
{"f_5091:expand_scm",(void*)f_5091},
{"f_5072:expand_scm",(void*)f_5072},
{"f_5034:expand_scm",(void*)f_5034},
{"f_5013:expand_scm",(void*)f_5013},
{"f_4760:expand_scm",(void*)f_4760},
{"f_5006:expand_scm",(void*)f_5006},
{"f_4933:expand_scm",(void*)f_4933},
{"f_5002:expand_scm",(void*)f_5002},
{"f_4986:expand_scm",(void*)f_4986},
{"f_4968:expand_scm",(void*)f_4968},
{"f_4964:expand_scm",(void*)f_4964},
{"f_4927:expand_scm",(void*)f_4927},
{"f_4931:expand_scm",(void*)f_4931},
{"f_4764:expand_scm",(void*)f_4764},
{"f_4776:expand_scm",(void*)f_4776},
{"f_4879:expand_scm",(void*)f_4879},
{"f_4871:expand_scm",(void*)f_4871},
{"f_4875:expand_scm",(void*)f_4875},
{"f_4848:expand_scm",(void*)f_4848},
{"f_4852:expand_scm",(void*)f_4852},
{"f_4803:expand_scm",(void*)f_4803},
{"f_4823:expand_scm",(void*)f_4823},
{"f_4795:expand_scm",(void*)f_4795},
{"f_4767:expand_scm",(void*)f_4767},
{"f_4712:expand_scm",(void*)f_4712},
{"f_4666:expand_scm",(void*)f_4666},
{"f_4672:expand_scm",(void*)f_4672},
{"f_4691:expand_scm",(void*)f_4691},
{"f_4613:expand_scm",(void*)f_4613},
{"f_4617:expand_scm",(void*)f_4617},
{"f_4622:expand_scm",(void*)f_4622},
{"f_4634:expand_scm",(void*)f_4634},
{"f_4628:expand_scm",(void*)f_4628},
{"f_4523:expand_scm",(void*)f_4523},
{"f_4559:expand_scm",(void*)f_4559},
{"f_4562:expand_scm",(void*)f_4562},
{"f_4574:expand_scm",(void*)f_4574},
{"f_4611:expand_scm",(void*)f_4611},
{"f_4586:expand_scm",(void*)f_4586},
{"f_4601:expand_scm",(void*)f_4601},
{"f_4577:expand_scm",(void*)f_4577},
{"f_4568:expand_scm",(void*)f_4568},
{"f_4526:expand_scm",(void*)f_4526},
{"f_4530:expand_scm",(void*)f_4530},
{"f_4553:expand_scm",(void*)f_4553},
{"f_4536:expand_scm",(void*)f_4536},
{"f_4539:expand_scm",(void*)f_4539},
{"f_4546:expand_scm",(void*)f_4546},
{"f_4505:expand_scm",(void*)f_4505},
{"f_4513:expand_scm",(void*)f_4513},
{"f_4023:expand_scm",(void*)f_4023},
{"f_4322:expand_scm",(void*)f_4322},
{"f_4496:expand_scm",(void*)f_4496},
{"f_4489:expand_scm",(void*)f_4489},
{"f_4328:expand_scm",(void*)f_4328},
{"f_4430:expand_scm",(void*)f_4430},
{"f_4436:expand_scm",(void*)f_4436},
{"f_4443:expand_scm",(void*)f_4443},
{"f_4337:expand_scm",(void*)f_4337},
{"f_4349:expand_scm",(void*)f_4349},
{"f_4417:expand_scm",(void*)f_4417},
{"f_4407:expand_scm",(void*)f_4407},
{"f_4411:expand_scm",(void*)f_4411},
{"f_4375:expand_scm",(void*)f_4375},
{"f_4371:expand_scm",(void*)f_4371},
{"f_4205:expand_scm",(void*)f_4205},
{"f_4262:expand_scm",(void*)f_4262},
{"f_4265:expand_scm",(void*)f_4265},
{"f_4291:expand_scm",(void*)f_4291},
{"f_4287:expand_scm",(void*)f_4287},
{"f_4277:expand_scm",(void*)f_4277},
{"f_4209:expand_scm",(void*)f_4209},
{"f_4231:expand_scm",(void*)f_4231},
{"f_4026:expand_scm",(void*)f_4026},
{"f_4030:expand_scm",(void*)f_4030},
{"f_4203:expand_scm",(void*)f_4203},
{"f_4199:expand_scm",(void*)f_4199},
{"f_4033:expand_scm",(void*)f_4033},
{"f_4041:expand_scm",(void*)f_4041},
{"f_4154:expand_scm",(void*)f_4154},
{"f_4181:expand_scm",(void*)f_4181},
{"f_4187:expand_scm",(void*)f_4187},
{"f_4160:expand_scm",(void*)f_4160},
{"f_4164:expand_scm",(void*)f_4164},
{"f_4167:expand_scm",(void*)f_4167},
{"f_4047:expand_scm",(void*)f_4047},
{"f_4053:expand_scm",(void*)f_4053},
{"f_4064:expand_scm",(void*)f_4064},
{"f_4081:expand_scm",(void*)f_4081},
{"f_4100:expand_scm",(void*)f_4100},
{"f_4111:expand_scm",(void*)f_4111},
{"f_4075:expand_scm",(void*)f_4075},
{"f_4061:expand_scm",(void*)f_4061},
{"f_4039:expand_scm",(void*)f_4039},
{"f_4014:expand_scm",(void*)f_4014},
{"f_3963:expand_scm",(void*)f_3963},
{"f_3975:expand_scm",(void*)f_3975},
{"f_3977:expand_scm",(void*)f_3977},
{"f_4012:expand_scm",(void*)f_4012},
{"f_4004:expand_scm",(void*)f_4004},
{"f_3971:expand_scm",(void*)f_3971},
{"f_3907:expand_scm",(void*)f_3907},
{"f_3911:expand_scm",(void*)f_3911},
{"f_3920:expand_scm",(void*)f_3920},
{"f_3939:expand_scm",(void*)f_3939},
{"f_3929:expand_scm",(void*)f_3929},
{"f_3894:expand_scm",(void*)f_3894},
{"f_3905:expand_scm",(void*)f_3905},
{"f_3898:expand_scm",(void*)f_3898},
{"f_3861:expand_scm",(void*)f_3861},
{"f_3865:expand_scm",(void*)f_3865},
{"f_3868:expand_scm",(void*)f_3868},
{"f_3706:expand_scm",(void*)f_3706},
{"f_3806:expand_scm",(void*)f_3806},
{"f_3801:expand_scm",(void*)f_3801},
{"f_3708:expand_scm",(void*)f_3708},
{"f_3714:expand_scm",(void*)f_3714},
{"f_3800:expand_scm",(void*)f_3800},
{"f_3796:expand_scm",(void*)f_3796},
{"f_3771:expand_scm",(void*)f_3771},
{"f_3775:expand_scm",(void*)f_3775},
{"f_3724:expand_scm",(void*)f_3724},
{"f_3730:expand_scm",(void*)f_3730},
{"f_3676:expand_scm",(void*)f_3676},
{"f_3682:expand_scm",(void*)f_3682},
{"f_3627:expand_scm",(void*)f_3627},
{"f_3634:expand_scm",(void*)f_3634},
{"f_3637:expand_scm",(void*)f_3637},
{"f_3640:expand_scm",(void*)f_3640},
{"f_3643:expand_scm",(void*)f_3643},
{"f_3649:expand_scm",(void*)f_3649},
{"f_3652:expand_scm",(void*)f_3652},
{"f_3609:expand_scm",(void*)f_3609},
{"f_3622:expand_scm",(void*)f_3622},
{"f_3578:expand_scm",(void*)f_3578},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
